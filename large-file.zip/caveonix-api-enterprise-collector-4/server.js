const cors = require('cors');
const express = require('express');
const cookieParser = require('cookie-parser');
const { get } = require('lodash');
const helmet = require('helmet');
const morgan = require('morgan');
const rp = require('request-promise');
const sslRootCAs = require('ssl-root-cas');
const timeout = require('connect-timeout');

const config = require('./configure').get();
const DbConnection = require('./config/db.conf');
const logger = require('./utils/logger').logger;

const helpMiddleware = require('./app/middlewares/help.middleware');

const loggerLabel = '';

class CaveonixEcApi {
  async setupApp() {
    const app = express();
    const server = require('./createServer')(app);
    const isAppliance = require('./utils/isAppliance');

    rp.debug = get(config, 'development') === 'true' ? get(config, 'log_outbound_request') : false;

    if (isAppliance()) {
      app.get('/test/isAppliance', (req, res) => res.json(isAppliance()));
    }

    // setting the timeout of the server
    //TODO check the purpose of this vs  line 46
    server.setTimeout(3600000);

    // SSL CONFIG
    sslRootCAs.inject();
    try {
      logger.profile('start up', { label: loggerLabel });
      logger.info('initializing', { label: loggerLabel });
      await this.setupDB();
      await this.setupMiddleware(app);
      await this.setupRoutes(app);
      await this.setupVersion(app);
      await this.setupErrors(app);
      logger.info('cav-api started', { label: loggerLabel });
      logger.profile('start up', { label: loggerLabel });

      const PORT = process.env.PORT || config.port || 3000;
      server.listen(PORT);
      logger.info(`Listening on 127.0.0.1:${PORT}`, { label: loggerLabel });
    } catch (error) {
      logger.error('Error occurred during initialization', { loggerLabel, error });
      process.exit(-1);
    }
  }

  setupMiddleware(app) {
    app.use(helmet());
    app.use(cors());
    app.use(timeout(3600000));
    app.use(cookieParser());
    app.use(morgan('tiny', {
      stream: {
        write: (message) => logger.debug(message.trim())
      }
    }));
    require('./config/middleware')(app, express);
  }

  setupVersion(app) {
    logger.debug('setting up version', { label: loggerLabel });
    const version = config.version || 'dev';
    app.use('/version', function (req, res) {
      logger.info(`'got version ${version}'`, { label: loggerLabel });
      res.json({
        version
      });
    });
  }

  setupErrors(app) {
    logger.debug('setting up errors', { label: loggerLabel });

    // errors
    app.use(function (req, res, next) {
      res.status(404);

      res.json({
        error: 'Not found'
      });
    });

  }

  async setupDB() {
    logger.debug('setting up database', { label: loggerLabel });
    await DbConnection.dbInit();
    await DbConnection.registerModels();
  }

  /**
   * Sets up all the various paths of routes
   * @param app
   */
  setupRoutes(app) {
    logger.debug('setting up routes', { label: loggerLabel });
    const healthCheck = require('./utils/healthStatus');
    const Router = require('./app/Router');
    const protectedRouter = express.Router({ mergeParams: true });
    const internalRouter = express.Router({ mergeParams: true });

    // main routes
    Router.forEach(route => {
      const routeMiddleware = get(route, 'middleware');
      const routePath = get(route, 'path');
      if (get(route, 'permissionCheck')) {
        route.handler.param(route.permissionCheck.param, route.permissionCheck.func);
      }
      if (get(route, 'protected')) {
        logger.silly(`adding protected path: ${routePath}`);
        protectedRouter.use(routePath, ...routeMiddleware, route.handler);
      }
      if (get(route, 'internal')) {
        logger.silly(`adding internal path: ${routePath}`);
        internalRouter.use(routePath, ...routeMiddleware, route.handler);
      }
      if (!get(route, 'protected') && !get(route, 'internal')) {
        logger.silly(`adding path: ${routePath}`);
        app.use(routePath, ...routeMiddleware, route.handler);
      }
    });

    // api health status
    app.get('/api/status', async (req, res) => {
      return res.json({ status: 'alive' });
    });

    // passport user authentication
    const passport = require('./config/passport.conf');
    app.use(
        '/api',
        ...[
          passport.authenticate(['jwt-bearer'], {
            session: false,
            failWithError: true
          }),
          (err, req, res, next) => {
            if (err) {
              const error = {
                error: err.name,
                message: err.message
              };

              const statusCode = err.status || err.statusCode || 500;
              return res.status(statusCode).json(error);
            }
            return next();
          }
        ],
        protectedRouter
    );

    app.use(
      '/echelp',
      helpMiddleware(),
      express.static('../help/echelp')
    );
    app.use(
      '/download-package',
      helpMiddleware(),
      express.static('../help/download-package')
    );
  }
}

const caveonixApi = new CaveonixEcApi();
caveonixApi.setupApp();
