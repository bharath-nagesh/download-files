const expect = require('chai').expect
let services = require('../../app/services')

xdescribe('vendor service', function () {
    this.timeout(100000);
    it('create', () => {

        let params = {
            name: 'vendor_test',
            is_Active: true
        }
        return services.vendorService.create(params)
            .then((vendor) => {
                vendorId = vendor.id
                vendorName = vendor.name
                expect(vendor.name).to.be.equal(params.name)
                expect(vendor.isActive).to.be.equal(params.is_Active)
                return Promise.resolve()
            })
    })

    it('getVendor', () => {
        return services.vendorService.getVendor(vendorId,null)
            .then((vendor) => {
                expect(vendor.id).to.be.equal(vendorId)
                expect(vendor.isActive).to.be.equal(true)
                return Promise.resolve()
            })
    })

    it('getAllVendors', () => {
        let limit = 10;
        let offset = 0;
        return services.vendorService.getAllVendors()
            .then((vendor) => {
                vendor.forEach(element => {
                    expect(element.isActive).to.not.be.equal('false')
                });
                expect(vendor).to.exist;
                return Promise.resolve()
            })
    })

    it('deleteById', () => {
        return services.vendorService.deleteById(vendorId)
            .then(() => {
                return services.vendorService.getVendor(vendorId,null)
                .then((vendor) => {
                        expect(vendor.isActive).to.be.equal(false)
                        return Promise.resolve()
                    })
            })
    })
  
})