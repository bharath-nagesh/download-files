const expect = require('chai').expect
let services = require('../../app/services')
let models = require('../../app/models');
const LocationService = require('../../app/apis/location/location.service');

describe('authorizationInfo service', function () {
    this.timeout(100000);
    let authorizationInfoId;
    let organizationId;
    let limit = 10;
    let offset = 0;
    let hostingProviderId1;
    let hostingProviderId2;
    let locationId;
    before(function() {
        return models.Organization.findAll({where: {is_active: {$ne: 'false'}}, order: [['id', 'ASC']]}).then(allOrganization =>{
            organizationId = allOrganization[1].id;
        });
    });
    it('get all authorizationInfo', function () {
        return services.authorizationInfoService.getAllAuthorizationInfo(organizationId, limit, offset)
            .then(result => {
                result.forEach(element => {
                    expect(element.is_active).to.not.be.equal('false');
                });
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('get all authorizationInfo count', function () {
        return services.authorizationInfoService.getAllAuthorizationInfo(organizationId, null, null)
            .then(result => {
                return services.authorizationInfoService.getAuthorizationInfoCount(organizationId).then(count => {
                    expect(count).to.equal(result.length);
                });
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    });

    it('create authorizationInfo', function () {
        const locationService = new LocationService();
        return services.hostingProviderService.getAllHostingProvider(null, null, limit, offset).then(allHostingProvider =>{
            return locationService.getAllLocations(limit, offset).then(allLocations =>{
                hostingProviderId1 = allHostingProvider[0].id;
                hostingProviderId2 = allHostingProvider[1].id;
                locationId = allLocations[0].id;

                let params = {
                    hosting_providers_id: hostingProviderId1,
                    location_id: locationId,
                    organization_id: organizationId,
                    isActive: 'enabled'
                }
                return services.authorizationInfoService.create(params)
                    .then(result => {
                        authorizationInfoId = result.id;
                        expect(result.isActive).to.be.equal(params.isActive);
                        expect(result.organization_id).to.be.equal(params.organization_id);
                        expect(result.hosting_providers_id).to.be.equal(params.hosting_providers_id);
                        expect(result.location_id).to.be.equal(params.location_id);
                    }).catch(err => {
                        console.log(err);
                        expect(err).to.be.equal(err);
                    })
            })
        })
    });

    it('update authorizationInfo', function () {
        let params = {
            hosting_providers_id: hostingProviderId2,
            location_id: locationId,
            organization_id: organizationId,
            isActive: 'disabled'
        }
        return services.authorizationInfoService.updateAuthorizationInfo(authorizationInfoId, params)
            .then(result => {
                expect(result.isActive).to.not.be.equal('enabled');
                expect(result.organization_id).to.be.equal(params.organization_id);
                expect(result.hosting_providers_id).to.not.be.equal(hostingProviderId1);
                expect(result.location_id).to.be.equal(params.location_id);
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    });

    it('get authorizationInfo by id and organization_id',function () {

        return services.authorizationInfoService.getAuthorizationInfo(organizationId, authorizationInfoId)
            .then((result) => {
                expect(result).to.exist;
                expect(result.isActive).to.not.be.equal('enabled');
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('delete authorizationInfo by id',function () {

        return services.authorizationInfoService.deleteById(authorizationInfoId)
            .then((result) => {
                expect(result.isActive).to.be.equal(false)
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })
})

