const expect = require('chai').expect;
let services = require('../../app/services');
let models = require('../../app/models');

describe('org service', function () {
  this.timeout(100000);
  let orgId;
  let organizationId;
  let limit = 10;
  let offset = 0;
  before(function () {
    return models.Organization.findAll({
      where: {is_active: {$ne: 'false'}},
      order: [['id', 'ASC']]
    }).then(allOrganization => {
      organizationId = allOrganization[1].id;
    });
  });

  it('get org chain', function () {

    return services.orgService.getOrgChain(organizationId)
      .then(result => {
        result.forEach(element => {
          expect(element.is_active).to.not.be.equal('false');
        });
      }).catch(err => {
        console.log(err);
        expect(err).to.be.equal(err);
      });
  }).timeout(100000);

  it('get Provider->Sub-Organizations->Sub-Organization Chain with type=organization and listParam=false', function () {

    return services.orgService.getProvider_SubOrg_SubOrgChain(organizationId, 'organization', limit, offset, 'false')
      .then(result => {
        result.forEach(element => {
          expect(element.is_active).to.not.be.equal('false');
          expect(element.is_active).to.not.be.equal('disabled');
        });
      }).catch(err => {
        console.log(err);
        expect(err).to.be.equal(err);
      });
  }).timeout(100000);

  it('get Provider->Sub-Organizations->Sub-Organization Chain with type=organization and listParam=true', function () {

    return services.orgService.getProvider_SubOrg_SubOrgChain(organizationId, 'organization', limit, offset, 'true')
      .then(result => {
        result.forEach(element => {
          expect(element.is_active).to.not.be.equal('false');
        });
      }).catch(err => {
        console.log(err);
        expect(err).to.be.equal(err);
      });
  }).timeout(100000);

  it('get Provider->Sub-Organizations->Sub-Organization Chain with type=Sub-Organization and listParam=false', function () {

    return services.orgService.getProvider_SubOrg_SubOrgChain(organizationId, 'sub-organization', limit, offset, 'false')
      .then(result => {
        result.forEach(element => {
          expect(element.is_active).to.not.be.equal('false');
          expect(element.is_active).to.not.be.equal('disabled');
        });
      }).catch(err => {
        console.log(err);
        expect(err).to.be.equal(err);
      });
  }).timeout(100000);

  it('get Provider->Sub-Organizations->Sub-Organization Chain with type=Sub-Organization and listParam=true', function () {

    return services.orgService.getProvider_SubOrg_SubOrgChain(organizationId, 'sub-organization', limit, offset, 'true')
      .then(result => {
        result.forEach(element => {
          expect(element.is_active).to.not.be.equal('false');
        });
      }).catch(err => {
        console.log(err);
        expect(err).to.be.equal(err);
      });
  }).timeout(100000);

  it('get Provider->Sub-Organizations->Sub-Organization Chain and All Organizatrions with listParam=false', function () {

    return services.orgService.getProvider_Org_SubOrgChain(organizationId, limit, offset, 'false')
      .then(result => {
        result.forEach(element => {
          expect(element.is_active).to.not.be.equal('false');
          expect(element.is_active).to.not.be.equal('disabled');
        });
      }).catch(err => {
        console.log(err);
        expect(err).to.be.equal(err);
      });
  });

  it('get Provider->Sub-Organizations->Sub-Organization Chain and All Organizatrions with listParam=true', function () {

    return services.orgService.getProvider_Org_SubOrgChain(organizationId, limit, offset, 'true')
      .then(result => {
        result.forEach(element => {
          expect(element.is_active).to.not.be.equal('false');
        });
      }).catch(err => {
        console.log(err);
        expect(err).to.be.equal(err);
      });
  });

  it('get organization by Id', function () {

    return services.orgService.getOrganizationById(organizationId)
      .then((org) => {
        expect(org).to.exist;
        expect(org.is_active).to.not.be.equal('false');
        return Promise.resolve();
      });
  });

  it('create new top level org', () => {

    let params = {
      name: 'test top level organization',
      type: 'Organization'

    };
    return services.orgService.createOrganization(params)
      .then((org) => {
        orgId = org.id;
        expect(org.name).to.be.equal(params.name);
        expect(org.type).to.be.equal(params.type);
        expect(org.isActive).to.be.equal('true');
        expect(org.type).to.not.be.equal('Provider');
        expect(org.bia_value).to.be.equal('1');
        return Promise.resolve();
      }).catch(err => {
        console.log(err);
        expect(err).to.be.equal(err);
      });
  });

  xit('update new top level org', () => {

    let params = {
      name: 'test top level org Update',
      type: 'Organization'

    };
    return services.orgService.updateOrg(orgId, params)
      .then((org) => {
        orgId = org.id;
        expect(org.name).to.be.equal(params.name);
        expect(org.type).to.be.equal(params.type);
        expect(org.isActive).to.be.equal(true);
        expect(org.type).to.not.be.equal('Provider');
        expect(org.bia_value).to.be.equal('1');
        return Promise.resolve();
      }).catch(err => {
        console.log(err);
        expect(err).to.be.equal(err);
      });
  });

  it('find first level organizations and sub-organizations', function () {

    return services.orgService.find_FirstLevel_Org_SubOrg()
      .then(result => {
        expect(result).to.exist;
      }).catch(err => {
        console.log(err);
        expect(err).to.be.equal(err);
      });
  });

  it('get top level organizations', function () {

    return services.orgService.getTopLevelOrgs()
      .then(result => {
        result.forEach(element => {
          expect(element.type).to.be.equal('Organization');
        });
      }).catch(err => {
        console.log(err);
        expect(err).to.be.equal(err);
      });
  });

  it('get all scan types with scanType=all', function () {

    return services.orgService.getAllScanTypes('all')
      .then(result => {
        result.forEach(element => {
          expect(element.isActive).to.not.be.equal('false');
          expect(element.isActive).to.not.be.equal('disabled');
        });
      }).catch(err => {
        console.log(err);
        expect(err).to.be.equal(err);
      });
  });

  it('get all scan types with scanType=scap', function () {

    return services.orgService.getAllScanTypes('scap')
      .then(result => {
        result.forEach(element => {
          expect(element.isActive).to.not.be.equal('false');
          expect(element.isActive).to.not.be.equal('disabled');
        });
      }).catch(err => {
        console.log(err);
        expect(err).to.be.equal(err);
      });
  });

  it('get all certificates of org id', function () {

    return services.orgService.getCertificate(organizationId)
      .then(result => {
        expect(result).to.exist;
      }).catch(err => {
        console.log(err);
        expect(err).to.be.equal(err);
      });
  });

  it('update caveo license', function () {

    return services.orgService.getLicense(organizationId).then(existingLicense => {
      return models.User.findAll({where: {is_active: {$ne: 'false'}}, order: [['id', 'ASC']]}).then(allUsers => {
        let userId = allUsers[0].id;
        return models.UserSessionInfo.findOne({
          where: {
            user_id: userId,
            organization_id: organizationId,
            is_active: true
          }
        }).then(userSessionInfo => {
          let sessionId = userSessionInfo.session_id;
          let key = existingLicense[0].license_key;

          let params = {
            userToken: sessionId,
            userId: userId,
            organization_id: organizationId,
            key: key
          };
          return services.orgService.updateCaveoLicense(params, function (err, done) {
            if (err) {
              expect(err).to.exist;
              expect(done).to.be.equal(false);
            } else {
              expect(err).to.be.equal(false);
              expect(done).to.exist;
            }
          });
        });
      });
    });
  });

  it('get license', function () {

    return services.orgService.getLicense(organizationId)
      .then(result => {
        expect(result[0].is_active).to.be.equal(true);
      }).catch(err => {
        console.log(err);
        expect(err).to.be.equal(err);
      });
  });

  it('delete new top level org', () => {

    return services.orgService.getOrganizationById(orgId)
      .then((org) => {
        return services.orgService.deleteOrg(org.id);
      }).then((org) => {
        expect(org.isActive).to.be.equal(false);
        return Promise.resolve();
      }).catch(err => {
        console.log(err);
        expect(err).to.be.equal(err);
      });
  });

});
