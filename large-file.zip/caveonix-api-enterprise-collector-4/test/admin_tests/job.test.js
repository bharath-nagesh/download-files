const expect = require('chai').expect
let services = require('../../app/services')
let models = require('../../app/models');

describe('job service', function () {
    this.timeout(100000);
    let scheduleId;
    let organizationId;
    let limit = 10;
    let offset = 0;
    let assetRepoId;
    let userId;
    let jobId;
    let sessionId;
    let modifyScheduleJob;
    let createScheduleJob;
    let deleteScheduleJob;
    before(function() {
        return models.Organization.findAll({where: {is_active: {$ne: 'false'}}, order: [['id', 'ASC']]}).then(allOrganization =>{
            organizationId = allOrganization[1].id;
        });
    });
    it('get all jobs with org_type=sub-organization', function () {
        return services.jobService.getAllJobs('sub-organization', limit, offset)
            .then(result => {
                result.forEach(element => {
                    expect(element.is_active).to.not.be.equal('false');
                });
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('get all jobs with org_typ=provider', function () {
        return services.jobService.getAllJobs('provider', limit, offset)
            .then(result => {
                result.forEach(element => {
                    expect(element.is_active).to.not.be.equal('false');
                });
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('get all jobs Schedule', function () {
        return services.jobService.getAllJobSchedule(organizationId, limit, offset)
            .then(result => {
                result.forEach(element => {
                    expect(element.is_active).to.not.be.equal('false');
                });
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('get all jobs count', function () {
        return services.jobService.getAllJobSchedule(organizationId, null, null)
            .then(result => {
                return services.jobService.getJobsCount(organizationId).then(count => {
                    expect(count).to.equal(result.length);
                });
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    });

    it('create job', function () {
        return services.assetRepoEndpointService.getAllAssetRepoEndpoints(organizationId, limit, offset, null).then(allAssetRepoEndpoints =>{
            return models.User.findAll({ where: { is_active: {$ne: 'false'}}, order: [['id', 'ASC']]}).then(allUsers =>{
                assetRepoId = allAssetRepoEndpoints[0].id;
                userId = allUsers[1].id;

                let params = {
                    name: 'NewTestTask',
                    type_name: 'vCenter',
                    scan_type: '',
                    user_id: userId,
                    asset_repo_id: assetRepoId,
                    cron_expression: '0 0 2 ? * 2',
                    isActive: 'enabled'
                }
                return services.jobService.createJob(organizationId, params.name, userId, params)
                    .then(result => {
                        createScheduleJob = result;
                        scheduleId = result.id;
                        expect(result.isActive).to.be.equal(params.isActive);
                        expect(result.asset_repo_id).to.be.equal(params.asset_repo_id);
                        expect(result.user_id).to.be.equal(params.user_id);
                        expect(result.name).to.be.equal(params.name);
                    }).catch(err => {
                        console.log(err);
                        expect(err).to.be.equal(err);
                    })
            })
        })
    });

    it('update job', function () {
        let params = {
            name: 'NewTestTask',
            type_name: 'vCenter',
            scan_type: '',
            user_id: userId,
            asset_repo_id: assetRepoId,
            cron_expression: '0 0 2 ? * 2',
            isActive: 'disabled'
        }
        return services.jobService.updateJob(organizationId, scheduleId, params)
            .then(result => {
                modifyScheduleJob = result;
                expect(result.isActive).to.not.be.equal('enabled');
                expect(result.asset_repo_id).to.be.equal(params.asset_repo_id);
                expect(result.user_id).to.be.equal(params.user_id);
                expect(result.name).to.be.equal(params.name);
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    });


    it('view scheduled job',function () {
        return models.Job.findOne({where: {name: 'vCenter'}}).then(jobDetails =>{
            jobId = jobDetails.id;
            return services.jobService.viewScheduledJob(jobId, scheduleId)
            .then((result) => {
                expect(result).to.exist;
                expect(result.isActive).to.not.be.equal('enabled');
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
        })
    })

    it('view scheduled jobs',function () {

        return models.Job.findOne({where: {name: 'vCenter'}}).then(jobDetails =>{
            jobId = jobDetails.id;
            return services.jobService.viewScheduledJobs(jobId, scheduleId)
            .then((result) => {
                expect(result).to.exist;
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
        })
    })

    it('get schedule by id',function () {

        return services.jobService.getJob(scheduleId, organizationId)
        .then((result) => {
            expect(result).to.exist;
            expect(result.isActive).to.not.be.equal('enabled');
        }).catch(err => {
            console.log(err);
            expect(err).to.be.equal(err);
        })
    })

    xit('start vCenter extract', function () {
        return models.UserSessionInfo.findOne({where: {user_id: userId, organization_id: organizationId, is_active: true}}).then(userSessionInfo =>{
            sessionId = userSessionInfo.session_id;

            let params = {
                userToken: sessionId,
                userId: userId,
                orgId: organizationId,
                softwareExtract: false,
                vCenterId: assetRepoId,
                type: 'vCenter'
            }
            return services.jobService.startvCenterExtract(params)
                .then(result => {
                    expect(result).to.be.undefined;
                }).catch(err => {
                    console.log(err);
                    expect(err).to.be.equal(err);
                })
        })
    });

    it('start VCD extract', function () {

        let params = {
            userToken: sessionId,
            userId: userId,
            orgId: organizationId,
            softwareExtract: false,
            type: 'VCD'
        }
        return services.jobService.startVCDExtract(params)
            .then(result => {
                expect(result).to.be.undefined;
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    });

    it('start SCAP extract', function () {

        let params = {
            userToken: sessionId,
            userId: userId,
            orgId: organizationId,
            scanType:'Vulnerability,Patch,XCCDF',
            type: 'SCAP'
        }
        return services.jobService.startOrgAssetScan(params)
            .then(result => {
                expect(result).to.be.undefined;
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    });

    it('start NSX extract', function () {

        let params = {
            userToken: sessionId,
            userId: userId,
            orgId: organizationId,
            scanType:'Flows',
            type: 'NSX'
        }
        return services.jobService.startNSXScan(params)
            .then(result => {
                expect(result).to.be.undefined;
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    });

    it('start Software extract', function () {

        let params = {
            userToken: sessionId,
            userId: userId,
            orgId: organizationId,
            type: 'Software'
        }
        return services.jobService.startSoftwareExtract(params)
            .then(result => {
                expect(result).to.be.undefined;
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    });

    it('start Log extract', function () {

        let params = {
            userToken: sessionId,
            userId: userId,
            orgId: organizationId,
            type: 'LogExtract'
        }
        return services.jobService.startLogExtract(params)
            .then(result => {
                expect(result).to.be.undefined;
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    });

    it('start AMQP extract', function () {

        let params = {
            userToken: sessionId,
            userId: userId,
            orgId: organizationId,
            type: 'mq'
        }
        return services.jobService.startAMQPExtract(params)
            .then(result => {
                expect(result).to.be.undefined;
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    });

    it('create modify schedule job with createModifyJob= Create', function () {

        return services.jobService.createModifyScheduleJob(createScheduleJob, userId, sessionId, 'Create', modifyScheduleJob.name, 'vCenter')
            .then(result => {
                expect(result).to.be.undefined;
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    });

    it('create modify schedule job with createModifyJob= Modify', function () {

        return services.jobService.createModifyScheduleJob(createScheduleJob, userId, sessionId, 'Modify', modifyScheduleJob.name, 'vCenter')
            .then(result => {
                expect(result).to.be.undefined;
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    });

    it('create modify schedule job with createModifyJob= unSchedule', function () {

        return services.jobService.createModifyScheduleJob(modifyScheduleJob, userId, sessionId, 'unSchedule', modifyScheduleJob.name, 'vCenter')
            .then(result => {
                expect(result).to.be.undefined;
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    });

    it('delete schedule by id',function () {

        return services.jobService.deleteScheduledById(scheduleId)
            .then((result) => {
                deleteScheduleJob = result
                expect(result.isActive).to.be.equal(false)
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('create modify schedule job with createModifyJob= Delete', function () {

        return services.jobService.createModifyScheduleJob(deleteScheduleJob, userId, sessionId, 'Delete', modifyScheduleJob.name, 'vCenter')
            .then(result => {
                expect(result).to.be.undefined;
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    });
})

