const expect = require('chai').expect
let services = require('../../app/services')

describe('hostingProvider service', function () {
    this.timeout(100000);
    let limit = 10;
    let offset = 0;
    let hostingProviderId;
    let hostingProviderName;
    it('create', () => {
        let params = {
            name: 'TestHostingProvider13',
            description: 'test',
            pocEmail: 'Hosting@caveonix.com',
            hostingType: 'Internet',
            pocName: 'Test',
            pocPhone: '909-09090-9'
        }
        return services.hostingProviderService.create(params)
            .then((hostingProvider) => {
                hostingProviderId = hostingProvider.id
                hostingProviderName = hostingProvider.name
                expect(hostingProvider.name).to.be.equal(params.name)
                expect(hostingProvider.description).to.be.equal(params.description)
                expect(hostingProvider.pocEmail).to.be.equal(params.pocEmail)
                expect(hostingProvider.hostingType).to.be.equal(params.hostingType)
                expect(hostingProvider.pocName).to.be.equal(params.pocName)
                expect(hostingProvider.pocPhone).to.be.equal(params.pocPhone)
                return Promise.resolve()
            })
    })

    it('updateHostingProvider', () => {
        let params = {
            name: 'TestHostingProvider100',
            description: 'test',
            pocEmail: 'Hosting@caveonix.com',
            hostingType: 'Internet',
            pocName: 'Test',
            pocPhone: '909-09090-9'
        }
        return services.hostingProviderService.updateHostingProvider(hostingProviderId, params)
            .then((hostingProvider) => {
                hostingProviderName = hostingProvider.name
                expect(hostingProvider.name).to.be.equal(params.name)
                expect(hostingProvider.description).to.be.equal(params.description)
                expect(hostingProvider.pocEmail).to.be.equal(params.pocEmail)
                expect(hostingProvider.hostingType).to.be.equal(params.hostingType)
                expect(hostingProvider.pocName).to.be.equal(params.pocName)
                expect(hostingProvider.pocPhone).to.be.equal(params.pocPhone)
                return Promise.resolve()
            })
    })

    it('getHostingProvider', () => {
        return services.hostingProviderService.getHostingProvider(hostingProviderId, null)
            .then((hostingProvider) => {
                expect(hostingProvider).to.exist;
                expect(hostingProvider.isActive).to.not.be.equal('false')
                return Promise.resolve()
            })
    })

    it('getAllHostingProvider', () => {
        return services.hostingProviderService.getAllHostingProvider(hostingProviderId, null, limit, offset)
            .then((hostingProvider) => {
                expect(hostingProvider).to.exist;
                hostingProvider.forEach(element => {
                    expect(element.isActive).to.not.be.equal('false')
                });
                return Promise.resolve()
            })
    })

    it('getHostingProviderCount', () => {
        return services.hostingProviderService.getAllHostingProvider(hostingProviderId, null, null, null)
            .then(result => {
                return services.hostingProviderService.getHostingProviderCount()
                    .then((hostingProvider) => {
                        expect(hostingProvider).to.exist;
                        expect(hostingProvider.isActive).to.not.be.equal('false')
                        expect(hostingProvider).to.equal(result.length);
                        return Promise.resolve()
                    })
            });
    })

    it('getHostingProviderbyName', () => {
        return services.hostingProviderService.getHostingProviderbyName(hostingProviderName, null)
            .then((hostingProvider) => {
                expect(hostingProvider).to.exist;
                expect(hostingProvider.isActive).to.not.be.equal('false')
                return Promise.resolve()
            })
    })

    it('checkUserExists', () => {
        let idArr = [];
        let ctr = 0;
        return services.hostingProviderService.checkUserExists(hostingProviderName).then(hostingProvider => {
            hostingProvider.filter(object => {
                idArr[ctr] = object.dataValues.name;
                expect(idArr[ctr]).to.be.equal(hostingProviderName)
                ctr++;
                return Promise.resolve()
            })
            expect(hostingProvider.isActive).to.not.be.equal('false')
        })
    })

    it('deleteById', () => {
        return services.hostingProviderService.deleteById(hostingProviderId)
            .then(() => {
                return services.hostingProviderService.getHostingProvider(hostingProviderId, null)
                    .then((update) => {
                        expect(update.isActive).to.be.equal('false')
                        return Promise.resolve()
                    })
            })
    })

})
