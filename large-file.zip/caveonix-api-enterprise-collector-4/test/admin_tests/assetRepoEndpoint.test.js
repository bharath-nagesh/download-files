const expect = require('chai').expect
let services = require('../../app/services')
let models = require('../../app/models');
const LocationService = require('../../app/apis/location/location.service');

describe('assetRepoEndpoint service', function () {
    this.timeout(100000);
    let assetRepoEndpointId;
    let organizationId;
    let limit = 10;
    let offset = 0;
    let hostingProviderId;
    let locationId;
    before(function() {
        return models.Organization.findAll({where: {is_active: {$ne: 'false'}}, order: [['id', 'ASC']]}).then(allOrganization =>{
            organizationId = allOrganization[1].id;
        });
    });

    it('get all assetRepoEndpoints with type= All', function () {

        return services.assetRepoEndpointService.getAllAssetRepoEndpoints(organizationId, limit, offset, 'All')
            .then(result => {
                result.forEach(element => {
                    expect(element.isActive).to.not.be.equal('false');
                });
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('get all assetRepoEndpoints', function () {

        return services.assetRepoEndpointService.getAllAssetRepoEndpoints(organizationId, limit, offset, null)
            .then(result => {
                result.forEach(element => {
                    expect(element.isActive).to.not.be.equal('false');
                });
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('get all assetRepoEndpoint count with type= All', function () {

        return services.assetRepoEndpointService.getAllAssetRepoEndpoints(organizationId,null, null, 'All')
            .then(result => {
                return services.assetRepoEndpointService.getAssetRepoEndpointsCount(organizationId, 'All').then(count => {
                    expect(count).to.equal(result.length);
                });
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    });

    it('get all assetRepoEndpoint count', function () {

        return services.assetRepoEndpointService.getAllAssetRepoEndpoints(organizationId, null, null, null)
            .then(result => {
                return services.assetRepoEndpointService.getAssetRepoEndpointsCount(organizationId, null).then(count => {
                    expect(count).to.equal(result.length);
                });
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    });

    it('create assetRepoEndpoint', function () {
      const locationService = new LocationService();
      return services.hostingProviderService.getAllHostingProvider(null, null, limit, offset).then(allHostingProvider =>{
            return locationService.getAllLocations(limit, offset).then(allLocations =>{
                hostingProviderId = allHostingProvider[0].id;
                locationId = allLocations[0].id;

                let params = {
                    connectionName: 'http://10.2.2.2',
                    hosting_provider_id: hostingProviderId,
                    isActive: 'enabled',
                    location_id: locationId,
                    password: 'mqadminpassword',
                    type_id: 2,
                    username: 'v@caveonix.com'
                }
                return services.assetRepoEndpointService.create(organizationId, params)
                    .then(result => {
                        assetRepoEndpointId = result.id;
                        expect(result.connectionName).to.be.equal(params.connectionName);
                        expect(result.isActive).to.be.equal(params.isActive);
                        expect(result.username).to.be.equal(params.username);
                        expect(result.hosting_provider_id).to.be.equal(params.hosting_provider_id);
                        expect(result.location_id).to.be.equal(params.location_id);
                    }).catch(err => {
                        console.log(err);
                        expect(err).to.be.equal(err);
                    })
            })
        })
    });

    it('update assetRepoEndpoint details', function () {
        let params = {
            connectionName: 'http://10.2.2.222',
            hosting_provider_id: hostingProviderId,
            isActive: 'enabled',
            location_id: locationId,
            password: 'mqadminpassword',
            type_id: 2,
            username: 'v@caveonix.com'
        }
        return services.assetRepoEndpointService.updateAssetRepoEndpoint(assetRepoEndpointId, params, organizationId)
            .then(result => {
                expect(result.connectionName).to.not.be.equal('http://10.2.2.2');
                expect(result.isActive).to.be.equal(params.isActive);
                expect(result.username).to.be.equal(params.username);
                expect(result.hosting_provider_id).to.be.equal(params.hosting_provider_id);
                expect(result.location_id).to.be.equal(params.location_id);
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    });

    it('get assetRepoEndpoint by Id', function () {

        return services.assetRepoEndpointService.getAssetRepoEndpoint(assetRepoEndpointId, organizationId)
            .then(result => {
                expect(result).to.exist;
                expect(result.connectionName).to.not.be.equal('http://10.2.2.2');
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('get all assetRepoEndpoint types', function () {

        return services.assetRepoEndpointService.getAssetRepoEndpointTypes(limit, offset)
            .then(result => {
                result.forEach(element => {
                    expect(element.isActive).to.not.be.equal('false');
                });
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('get all assetRepoEndpoint types count', function () {

        return services.assetRepoEndpointService.getAssetRepoEndpointTypes(limit, offset)
            .then(result => {
                return services.assetRepoEndpointService.getAssetRepoEndpointTypesCount().then(count => {
                    expect(count).to.equal(result.length);
                });
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    });

    it('get all assetRepoEndpointMembers by assetRepoEndpoint Id', function () {

        return services.assetRepoEndpointService.getAssetRepoEndpointMembersById(assetRepoEndpointId, organizationId)
            .then(result => {
                expect(result).to.exist;
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('delete assetRepoEndpoint details by id',function () {

        return services.assetRepoEndpointService.deleteById(assetRepoEndpointId, organizationId)
            .then((result) => {
                expect(result.isActive).to.be.equal(false);
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })
})

