const expect = require('chai').expect
let services = require('../../app/services')
let models = require('../../app/models');

describe('kibanaDashboard service', function () {
    this.timeout(100000);
    let organizationId;
    before(function() {
        return models.Organization.findAll({where: {is_active: {$ne: 'false'}}, order: [['id', 'ASC']]}).then(allOrganization =>{
            organizationId = allOrganization[1].id;
        });  
    });

    it('get kibana dashboard', function () {

        return services.kibanaDashBoardService
        .getDashBoard(organizationId, function(err, data){
            if(err){
                console.log(err)
                expect(err).to.exist;
            }else{
                expect(data).to.exist;
            }
        });
    }); 
});

