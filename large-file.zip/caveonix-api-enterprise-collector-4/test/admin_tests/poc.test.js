const expect = require('chai').expect
let services = require('../../app/services')

describe('poc service', function () {
    this.timeout(100000);
    let pocId;
    let orgId = 0;
    xit('create', () => {
        let params = {
            firstName: 'Test',
            lastName: 'Test',
            cellNumber: '1234567890',
            email: 1,
            isActive: 'enabled'
        }
        return services.pocService.create(orgId, params)
            .then((poc) => {
                pocId = poc.id
                expect(poc.firstName).to.be.equal(params.firstName)
                expect(poc.lastName).to.be.equal(params.lastName)
                expect(poc.isActive).to.be.equal(params.isActive)
                return Promise.resolve()
            })
    })

    xit('getPocById', () => {
        return services.pocService.getPoc(pocId, null)
            .then((poc) => {
                expect(poc).to.exist;
                expect(poc.isActive).to.not.be.equal(false)
                return Promise.resolve()
            })
    })

    xit('deleteById', () => {
        return services.pocService.deleteById(pocId)
            .then(() => {
                return services.pocService.getPoc(pocId, null)
                    .then((update) => {
                        expect(update.isActive).to.be.equal(false)
                        return Promise.resolve()
                    })
            })
    })

})