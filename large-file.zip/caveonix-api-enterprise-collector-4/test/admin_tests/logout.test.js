const expect = require('chai').expect;
let services = require('../../app/services');

describe('logout service', function () {
  this.timeout(100000);
  let createdAt;
  let params = {
    id: 2,
    Organization: {organization_id: 1},
    isActive: true
  };

  xit('logout Session', () => {
    let token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6Miwib3JnYW5pemF0aW9uSWQiOjAsImlhdCI6MTUyODQ2NzcyMywiZXhwIjoxNTI4NTEwOTIzfQ.fxTQJjoStyVJULHGIt39EVzHxu0jR0yGH1fDEW6XVic';
    return services.loginService.addLoginData(params, token)
      .then((userSessionInfo) => {
        return services.logoutService.logoutSession(userSessionInfo.user_id)
          .then((logoutInfo) => {
            expect(logoutInfo.user_id).to.be.equal(params.id);
            return Promise.resolve();
          });
      });
  });

  it('get logout Session', () => {
    let token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6Miwib3JnYW5pemF0aW9uSWQiOjAsImlhdCI6MTUyODQ2NzcyMywiZXhwIjoxNTI4NTEwOTIzfQ.fxTQJjoStyVJULHGIt39EVzHxu0jR0yGH1fDEW6XVic';
    return services.logoutService.getUserSessionInfo(params.id)
      .then((logoutInfo) => {
        expect(logoutInfo.user_id).to.be.equal(params.id);
        return Promise.resolve();
      });
  });

});
