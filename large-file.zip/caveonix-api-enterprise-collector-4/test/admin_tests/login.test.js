const expect = require('chai').expect;
let services = require('../../app/services');

describe('login service', function () {
  this.timeout(100000);
  let createdAt;
  let params = {
    id: 1,
    Organization: {organization_id: 0},
    isActive: true
  };

  xit('create Login Data', () => {
    let token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6Miwib3JnYW5pemF0aW9uSWQiOjAsImlhdCI6MTUyODQ2NzcyMywiZXhwIjoxNTI4NTEwOTIzfQ.fxTQJjoStyVJULHGIt39EVzHxu0jR0yGH1fDEW6XVic';
    return services.loginService.addLoginData(params, token)
      .then((userSessionInfo) => {
        createdAt = userSessionInfo.created_at;
        expect(userSessionInfo.user_id).to.be.equal(params.id);
        return Promise.resolve();
      });
  });

  xit('get user session info', () => {
    return services.loginService.getUserSessionInfo(params.id, createdAt)
      .then((userSessionInfo) => {
        expect(userSessionInfo.user_id).to.be.equal(params.id);
        return Promise.resolve();
      });
  });

});
