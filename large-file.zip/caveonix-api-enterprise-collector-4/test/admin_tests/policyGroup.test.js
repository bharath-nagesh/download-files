const expect = require('chai').expect;
let services = require('../../app/services');

describe('subApplication service', function () {
  this.timeout(100000);
  let orgId = 0;
  let limit = 10;
  let offset = 0;
  let policyGroupId;
  let policyGroupName;
  xit('create', () => {
    let params = {
      name: 'New Sub-application_test1',
      applicationgroupId: 0,
      assets: '13,30,20',
      sequence_num: 1,
      isActive: 'enabled'
    };
    return services.policyGroupService.create(orgId, params)
      .then((policyGroup) => {
        policyGroupId = policyGroup.id;
        policyGroupName = policyGroup.name;
        expect(policyGroup.name).to.be.equal(params.name);
        expect(policyGroup.sequence_num).to.be.equal(params.sequence_num);
        expect(policyGroup.isActive).to.be.equal(params.isActive);
        expect(policyGroup.isActive).to.not.be.equal(false);
        return Promise.resolve();
      });
  });

  xit('update', () => {
    let params = {
      name: 'New Sub-application_test1',
      applicationgroupId: 0,
      assets: '13,30,20',
      sequence_num: 1,
      isActive: 'enabled'
    };
    return services.policyGroupService.update(params, policyGroupId, orgId)
      .then((policyGroup) => {
        policyGroupId = policyGroup.id;
        policyGroupName = policyGroup.name;
        expect(policyGroup.name).to.be.equal(params.name);
        expect(policyGroup.sequence_num).to.be.equal(params.sequence_num);
        expect(policyGroup.isActive).to.be.equal(params.isActive);
        return Promise.resolve();
      });
  });

  xit('getPolicyGroup', () => {
    return services.policyGroupService.getPolicyGroup(policyGroupId, null)
      .then((update) => {
        expect(update.isActive).to.not.be.equal(false);
        return Promise.resolve();
      });
  });

  xit('getAllPolicyGroup_listParam=null', () => {
    let listParam;
    return services.policyGroupService.getAllPolicyGroup(orgId, listParam = null, limit, offset)
      .then((policyGroup) => {
        expect(policyGroup).to.exist;
        policyGroup.forEach(element => {
          expect(element.isActive).to.not.be.equal('false');
        });

        return Promise.resolve();
      });
  })

  xit('getAllPolicyGroup_listParam=false', () => {
    return services.policyGroupService.getAllPolicyGroup(orgId, false, limit, offset)
      .then((policyGroup) => {
        expect(policyGroup).to.exist;
        policyGroup.forEach(element => {
          expect(policyGroup.isActive).to.not.be.equal('disabled');
          expect(policyGroup.isActive).to.not.be.equal('false');
        });
        return Promise.resolve();
      });
  })

  it('getAllPolicyGroupCount_listParam=null', () => {
    let listParam;
    return services.policyGroupService.getAllPolicyGroup(orgId, listParam = null, null, null)
      .then((result) => {
        return services.policyGroupService.getAllPolicyGroupCount(orgId, listParam = null)
          .then((policyGroup) => {
            expect(policyGroup).to.exist;
            // expect(subApplication).to.be([{count: `${result.length}`}]);
            expect(policyGroup.isActive).to.not.be.equal('false');
            return Promise.resolve();
          });
      });
  }).timeout(100000);

  it('getAllPolicyGroupCount_listParam=false', () => {
    let listParam;
    return services.policyGroupService.getAllPolicyGroup(orgId, listParam = false, null, null)
      .then((result) => {
        return services.policyGroupService.getAllPolicyGroupCount(orgId, listParam = false)
          .then((policyGroup) => {
            expect(policyGroup).to.exist;
            // expect(subApplication).to.be([{count: `${result.length}`}]);
            expect(policyGroup.isActive).to.not.be.equal('disabled');
            expect(policyGroup.isActive).to.not.be.equal('false');
            return Promise.resolve();
          });
      });
  }).timeout(100000);

  xit('addAssetToPolicyGroup', () => {
    let assetId = '13,30,20';
    return services.policyGroupService.addAssetToPolicyGroup(policyGroupId, assetId)
      .then((update) => {
        expect(update.isActive).to.not.be.equal(false);
        return Promise.resolve();
      });
  });

  xit('removeAssetToPolicyGroup', () => {
    let assetId = '13,30,20';
    return services.policyGroupService.removeAssetToPolicyGroup(policyGroupId, assetId)
      .then((update) => {
        expect(update.isActive).to.not.be.equal(false);
        return Promise.resolve();
      });
  });

  xit('deleteById', () => {
    return services.policyGroupService.deleteById(policyGroupId)
      .then(() => {
        return services.policyGroupService.getPolicyGroup(policyGroupId, null)
          .then((update) => {
            expect(update.isActive).to.be.equal(false);
            return Promise.resolve();
          });
      });
  });

});
