const expect = require('chai').expect;
let services = require('../../app/services');

describe('orgMembers service', function () {
  this.timeout(100000);
  // let orgId = 0;
  // let userId = 1;
  // let roleId = 1;
  let limit = 10;
  let offset = 0;

  xit('add Organization Member', () => {
    return services.orgMemberService.addOrgUser(orgId, userId, roleId)
      .then((orgMember) => {
        expect(orgMember).to.be.exist;
        return Promise.resolve();
      }).catch(err => {
        console.log(err);
        expect(err).to.be.equal(err);
      });
  });

  xit('update Organization Member', () => {
    return services.orgMemberService.updateOrgUser(orgId, userId, roleId)
      .then((orgMember) => {
        expect(orgMember.organization_id).to.be.equal(orgId);
        expect(orgMember.role_id).to.be.equal(roleId);
        expect(orgMember.user_id).to.be.equal(userId);
        return Promise.resolve();
      }).catch(err => {
        console.log(err);
        expect(err).to.be.equal(err);
      });
  });

  xit('get Organization Users', () => {
    return services.orgMemberService.getOrgUsers(orgId, true, limit, offset)
      .then((orgMember) => {
        orgMember.forEach(element => {
          expect(element.isActive).to.not.be.equal(false);
        });
      }).catch(err => {
        console.log(err);
        expect(err).to.be.equal(err);
      });
  });

  xit('get Organization Users count', () => {
    return services.orgMemberService.getOrgUsers(orgId, true, null, null)
      .then((orgMember) => {
        return services.orgMemberService.getOrgUsersCount(orgId, true)
          .then((count) => {
            expect(orgMember.length).to.be.equal(count);
          });
      }).catch(err => {
        console.log(err);
        expect(err).to.be.equal(err);
      });
  });

  // it('delete Organization Users', () => {
  //     return services.orgMemberService.deleteOrgUser(orgId, userId)
  //         .then((orgMember) => {
  //             expect(orgMember.organization_id).to.be.equal(orgId)
  //             expect(orgMember.user_id).to.be.equal(userId)
  //         }).catch(err => {
  //             console.log(err);
  //             expect(err).to.be.equal(err);
  //         })
  // })
});
