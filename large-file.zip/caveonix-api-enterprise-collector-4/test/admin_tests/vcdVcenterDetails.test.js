const expect = require('chai').expect
let services = require('../../app/services')

describe('vcdVcenterDetails service', function () {
    this.timeout(100000);
    let orgId;
    let vcdVcenterDetailId;
    let vcenter_url;
    let limit = 10;
    let offset = 0;

    it('getAllVcdVcenterDetails', () => {   
        return services.vcdVcenterDetailsService.getAllVcdVcenterDetails(null, limit, offset)
            .then((vcdVcenterDetails) => {
                vcdVcenterDetailId = vcdVcenterDetails[0].id
                orgId=vcdVcenterDetails[0].organization_id
                vcenter_url = vcdVcenterDetails[0].vcenter_url
                expect(vcdVcenterDetails).to.exist;
                return Promise.resolve()
            })
    })

    it('getVcdVcenterDetailsId', () => {
        return services.vcdVcenterDetailsService.getVcdVcenterDetailsId(vcdVcenterDetailId,orgId)
        .then((vcdVcenterDetails) => {
            vcenter_url = vcdVcenterDetails.vcenter_url
            expect(vcdVcenterDetails.organization_id).to.be.equal(orgId)
            return Promise.resolve()
        })
    })
   
    it('getVcdVcenterDetails', () => {
            return services.vcdVcenterDetailsService.getVcdVcenterDetails(vcdVcenterDetailId,orgId)
            .then((vcdVcenterDetails) => {
                expect(vcdVcenterDetails).to.exist;
                return Promise.resolve()
            })
    })
    
    it('updateVcdVcenterDetailsById', () => {
        let params = {
            location_id: 0,
            hosting_provider_id: 0,
            vcenter_url: 'https://10.1.15.2:443/sdk',
            asset_repo_endpoint_vcd_id: 6
        }
        return services.vcdVcenterDetailsService.updateVcdVcenterDetailsById(vcdVcenterDetailId, params,orgId)
            .then((vcdVcenterDetails) => {
                return services.vcdVcenterDetailsService.getVcdVcenterDetailsId(vcdVcenterDetailId,orgId)
                 .then((details) => {
                      expect(details.location_id).to.be.equal(params.location_id)
                      expect(details.hosting_provider_id).to.be.equal(params.hosting_provider_id)
                      expect(details.vcenter_url).to.be.equal(params.vcenter_url)
                      expect(details.asset_repo_endpoint_vcd_id).to.be.equal(params.asset_repo_endpoint_vcd_id)
                      return Promise.resolve()
            })
        })
    })

   it('getVcdVcenterDetailsByName', () => {
    return services.vcdVcenterDetailsService.getVcdVcenterDetailsByName(vcenter_url)
        .then((vcdVcenterDetails) => {
            expect(vcdVcenterDetails).to.exist;
            return Promise.resolve()
        })
    })

    it('getVcdVcenterDetailsCount', () => {
        let orgId=0;
        return services.vcdVcenterDetailsService.getAllVcdVcenterDetails(orgId, null, null)
        .then((vcdVcenterDetails) => {
                return services.vcdVcenterDetailsService.getVcdVcenterDetailsCount(orgId)
                    .then((result) => {
                        //expect(result).to.be.equal(vcdVcenterDetails.length)
                        expect(result).to.exist;
                        return Promise.resolve()
                    })
            });
    })
})


