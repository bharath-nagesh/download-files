const expect = require('chai').expect
let services = require('../../app/services')

xdescribe('asset service', function () {
    this.timeout(100000);
    let limit = 1000;
    let offset = 0;
    let orgId = 0;
    let assetId;
    
    let name;
    let macAddress;
    let vmId;

    it('get all asset', () => {
        return services.assetService.getAssetsForOrg(orgId)
            .then((asset) => {
                assetId = asset[0].id;
                name = asset[0].name;
                macAddress = asset[0].macAddress;
                vmId = asset[0].vmId;
                expect(asset[0].organization_id).to.be.equal(orgId);
                return Promise.resolve()
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('get all asset count', () => {
        return services.assetService.getAssetsForOrg(orgId)
            .then((asset) => {
                return services.assetService.getAssetCount(orgId)
                    .then((count) => {
                        expect(asset.length).to.be.equal(count)
                    })
                return Promise.resolve()
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('get asset', () => {
        return services.assetService.getAsset(assetId)
            .then((asset) => {
                expect(asset.name).to.be.equal(name)
                expect(asset.macAddress).to.be.equal(macAddress)
               // expect(asset.vmid).to.be.equal(vmid)
                return Promise.resolve()
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('get All asset', () => {
        return services.assetService.getAllAsset(orgId, limit, offset)
            .then((asset) => {
                asset.forEach(element => {
                    expect(element.isActive).to.not.be.equal(false);
                });
                return Promise.resolve()
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('get Asset For Application', () => {
        return services.assetService.getAssetForApplication(orgId, limit, offset)
            .then((asset) => {
                asset.forEach(element => {
                    expect(element.isActive).to.not.be.equal(false);
                });
                return Promise.resolve()
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('get Asset count For Application', () => {
        return services.assetService.getAssetForApplication(orgId, null, null)
            .then((asset) => {
                return services.assetService.getAssetForApplicationCount(orgId)
                    .then((count) => {
                        expect(asset.length).to.be.equal(count)
                    })
                return Promise.resolve()
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('get all Organizations', () => {
        return services.assetService.getAllOrganizations(limit, offset)
            .then((asset) => {
                asset.forEach(element => {
                    expect(element.isActive).to.not.be.equal(false);
                });
                return Promise.resolve()
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('get Asset count ', () => {
        return services.assetService.getAllAsset(orgId, null, null)
            .then((asset) => {
                return services.assetService.getAssetCountForOrg(orgId)
                    .then((count) => {
                        expect(asset.length).to.be.equal(count)
                    })
                return Promise.resolve()
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('get asset detail', () => {
        return services.assetService.getAssetDetail(assetId)
            .then((asset) => {
                expect(asset.asset_id).to.be.equal(assetId)
                return Promise.resolve()
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('get Asset Network', () => {
        return services.assetService.getAssetNetwork(assetId)
            .then((asset) => {
                expect(asset.physicalAssetNetworks[0].asset_id).to.be.equal(assetId)
                return Promise.resolve()
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('get VM Asset Network', () => {
        return services.assetService.getVMAssetNetwork(assetId)
            .then((asset) => {
                expect(asset[0].asset_id).to.be.equal(assetId)
                return Promise.resolve()
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('get Physical Asset Network', () => {
        return services.assetService.getPhysicalAssetNetwork(assetId)
            .then((asset) => {
                expect(asset[0].asset_id).to.be.equal(assetId)
                return Promise.resolve()
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('change Asset Organization', () => {
        update = {
            'organization_id': 1000,
            'assets': "98,28"
        };
        return services.assetService.changeAssetOrganization(update.assets, update, orgId)
            .then((asset) => {
                expect(asset).to.be.exist;
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('change Asset Location', () => {
        update = {
            'organization_id': 1000,
            'assets': "98,28"
        };
        return services.assetService.changeAssetLocation(update.assets, update, orgId)
            .then((asset) => {
                expect(asset).to.be.exist;
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('check Asset EnvMember', () => {
        return services.assetService.checkAssetEnvMember(assetId)
            .then((asset) => {
                expect(asset.asset_id).to.be.equal(assetId)
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

  
})