const expect = require('chai').expect
let services = require('../../app/services')

describe('os service', function () {
    this.timeout(100000);
    let name;
    let osId;
    it('create', () => {
        let params = {
            name: 'test',
            isActive: true
        }
        return services.osService.create(params)
            .then((os) => {
                name = os.name;
                osId = os.id
                expect(os.name).to.be.equal(params.name)
                expect(os.isActive).to.be.equal(params.isActive)
                return Promise.resolve()
            })
    })

    it('getosById', () => {
        return services.osService.getOs(osId, null)
            .then((update) => {
                expect(update.id).to.be.equal(osId)
                return Promise.resolve()
            })
    })

    it('getAllOs', () => {
        return services.osService.getAllOs()
            .then((update) => {
                expect(update).to.exist;
                update.forEach(element => {
                    expect(element.isActive).to.not.be.equal('false')
                });
              
                return Promise.resolve()
            })
    })

    it('deleteById', () => {
        return services.osService.deleteById(osId)
            .then(() => {
                return services.osService.getOs(osId, null)
                    .then((update) => {
                        expect(update.isActive).to.be.equal(false)
                        return Promise.resolve()
                    })
            })
    })

})