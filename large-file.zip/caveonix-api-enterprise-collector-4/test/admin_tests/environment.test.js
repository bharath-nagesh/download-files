const expect = require('chai').expect
let services = require('../../app/services')

describe('environment service', function () {
    this.timeout(100000);
    let  environmentId;
    let environmentName;
    it('create', () => {

        let params = {
            name: 'Test_Env11',
            score: 10
        }
        return services.environmentService.create(params)
            .then((environment) => {
                environmentName=environment.name;
                environmentId = environment.id
                expect(environment.name).to.be.equal(params.name)
                expect(environment.score).to.be.equal(params.score)
                return Promise.resolve()
            })
    })

/*
    it('updateEnvironment', () => {
        let params = {
            name: 'test91',
            score: 10
        }
        return EnvironmentRoutes.updateEnvironment(environmentId, params)
            .then((environment) => {
                environmentName=environment.name;
                expect(environment.name).to.be.equal(params.name)
                expect(environment.score).to.be.equal(params.score)
                return Promise.resolve()
            })
    })
*/

    it('getEnvironment', () => {
        return services.environmentService.getEnvironment(environmentId, null)
            .then((environment) => {
                expect(environment).to.exist;
                return Promise.resolve()
            })
    })

    it('getAllEnvironment', () => {
        let limit = 10;
        let offset = 0;
        return services.environmentService.getAllEnvironment(limit, offset)
            .then((environment) => {
                expect(environment).to.exist;
                environment.forEach(element => {
                    expect(element.isActive).to.not.be.equal('false')
                });

                return Promise.resolve()
            })
    })

    it('getEnvironmentCount', () => {
        let limit = 10;
        let offset = 0;
        return services.environmentService.getAllEnvironment(null, null)
            .then(result => {
                return services.environmentService.getEnvironmentCount()
                    .then((environment) => {
                        expect(environment).to.exist;
                        expect(environment.isActive).to.not.be.equal('false')
                        expect(environment).to.equal(result.length);
                        return Promise.resolve()
                    })
            });
    })

    it('getEnvironmentByName', () => {
        return services.environmentService.getEnvironmentByName(environmentName)
            .then((environment) => {
                expect(environment).to.exist;
                expect(environment.isActive).to.not.be.equal(false)
                return Promise.resolve()
            })
    })

    it('deleteById', () => {
        return services.environmentService.deleteById(environmentId)
            .then(() => {
                return services.environmentService.getEnvironment(environmentId, null)
                    .then((update) => {
                        expect(update.isActive).to.be.equal('false')
                        return Promise.resolve()
                    })
            })
    })
})
