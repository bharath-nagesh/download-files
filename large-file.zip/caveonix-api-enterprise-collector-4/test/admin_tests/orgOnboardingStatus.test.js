const expect = require('chai').expect
let services = require('../../app/services')

describe('orgOnboardingStatus service', function () {
    this.timeout(100000);
    let orgId = 0;
    let params = {
        onboarding_step_id: 1,
        status: 'In Progress'
    }
   // it('update Organization Onboarding Status', () => {
    //     return services.orgOnboardingStatusService.updateOrgOnboardingStatus(orgId, params)
    //         .then((orgOnboardingStatus) => {
    //             expect(orgOnboardingStatus.onboarding_step_id).to.be.equal(params.onboarding_step_id)
    //             expect(orgOnboardingStatus.status).to.be.equal(params.status)
    //             return Promise.resolve()
    //         })
    // })
    xit('get Organization Onboarding Status', () => {
        return services.orgOnboardingStatusService.getOrgOnboardingStatus(orgId)
            .then((orgOnboardingStatus) => {
                expect(orgOnboardingStatus.onboarding_step_id).to.be.equal(params.onboarding_step_id)
                expect(orgOnboardingStatus.status).to.be.equal(params.status)
                return Promise.resolve()
            })
    })
})
