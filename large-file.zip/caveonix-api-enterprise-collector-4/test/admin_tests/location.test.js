const expect = require('chai').expect;
const LocationService = require('../../app/apis/location/location.service');
const locationService = new LocationService();

describe('location service', function () {
  this.timeout(100000);
  let locationId;
  let locationName;
  let limit = 1000;
  let offset = 0;

  it('create locations', () => {
    let params = {
      name: 'testMocha',
      addressLine1: 'some random address',
      addressLine2: 'line 2',
      city: 'city',
      country: 'country',
      email: 'mocha@test.com',
      state: 'CA',
      zip: 12345,
      isActive: true
    };
    return locationService.create(params)
      .then((location) => {
        locationId = location.id;
        locationName = location.name;
        expect(location.name).to.be.equal(params.name);
        expect(location.email).to.be.equal(params.email);
        expect(location.city).to.be.equal(params.city);
        expect(location.country).to.be.equal(params.country);
        return Promise.resolve();
      });
  });

  it('update locations', () => {
    let params = {
      name: 'testMocha',
      addressLine1: 'some random address',
      addressLine2: 'line 2',
      city: 'city',
      country: 'country',
      email: 'mocha@test.com',
      state: 'CA',
      zip: 12345,
      isActive: true
    };
    return locationService.updateLocation(locationId, params)
      .then((location) => {
        expect(location.name).to.be.equal(params.name);
        expect(location.email).to.be.equal(params.email);
        expect(location.city).to.be.equal(params.city);
        expect(location.country).to.be.equal(params.country);
        return Promise.resolve();
      });
  });

  it('get location by id', () => {
    return locationService.getLocation(locationId)
      .then((location) => {
        expect(location.id).to.be.equal(locationId);
        return Promise.resolve();
      });
  });

  it('get locations by name', () => {
    return locationService.getLocationByName(locationName)
      .then((location) => {
        expect(location.name).to.be.equal(locationName);
        return Promise.resolve();
      });
  });

  it('get all locations', () => {
    return locationService.getAllLocations(limit, offset)
      .then((locations) => {
        locations.forEach(element => {
          expect(element.isActive).to.not.be.equal(false);
        });
        return Promise.resolve();
      });
  });

  it('get locations count', () => {
    return locationService.getAllLocations(null, null)
      .then((locations) => {
        return locationService.getAllLocationsCount()
          .then((count) => {
            expect(locations.length).to.be.equal(count);
          });
      }).catch(err => {
        console.log(err);
        expect(err).to.be.equal(err);
      });
  });

  it('delete locations', () => {
    return locationService.deleteById(locationId)
      .then((location) => {
        expect(location.isActive).to.be.equal(false);
      });
    return Promise.resolve();
  });

});
