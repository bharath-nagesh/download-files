const expect = require('chai').expect;
let services = require('../../app/services');

describe('role service', function () {
  this.timeout(100000);
  let orgId = 0;
  let limit = 10;
  let offset = 0;
  let roleId;
  let roleName;
  it('createRole', () => {
    let params = {
      name: 'Test_Role111',
      description: 'test',
      isActive: 'enabled',
      modulePermissions: '[{"moduleId":6,"permissions":"CRUD"},{"moduleId":2,"permissions":"CRUD"}]'
    };
    return services.roleService.createRole(orgId, params.name, params.description, params.isActive, params.modulePermissions = [])
      .then((role) => {
        roleId = role.id;
        roleName = role.name;
        expect(role.name).to.be.equal(params.name);
        expect(role.description).to.be.equal(params.description);
        expect(role.isActive).to.be.equal(params.isActive);
        return Promise.resolve();
      });
  });

  it('updateRole', () => {
    let orgId = 1;
    let params = {
      name: 'Tesr_Role112',
      description: 'test',
      isActive: 'enabled',
      modulePermissions: '[{"moduleId":6,"permissions":"CRUD"},{"moduleId":2,"permissions":"CRUD"}]'
    };
    return services.roleService.updateRole(roleId, orgId, params.name, params.description, params.isActive, params.modulePermissions = [])
      .then((role) => {
        roleId = role.id;
        roleName = role.name;
        expect(role.name).to.be.equal(params.name);
        expect(role.description).to.be.equal(params.description);
        expect(role.isActive).to.be.equal(params.isActive);
        return Promise.resolve();
      });
  });

  it('getRoleActions', () => {
    return services.roleService.getRoleActions(roleId, orgId)
      .then((role) => {
        expect(role).to.exist;
        expect(role.isActive).to.not.be.equal('false');
        return Promise.resolve();
      });
  });

  it('getRole', () => {
    return services.roleService.getRole(roleId, orgId, null)
      .then((role) => {
        expect(role).to.exist;
        expect(role.isActive).to.not.be.equal('false');
        return Promise.resolve();
      });
  });

  it('getUsersByRoleId', () => {
    return services.roleService.getUsersByRoleId(roleId, orgId)
      .then((role) => {
        expect(role).to.exist;
        expect(role.isActive).to.not.be.equal('false');
        return Promise.resolve();
      });
  });

  it('deleteById', () => {
    return services.roleService.deleteRole(roleId, orgId)
      .then(() => {
        return services.roleService.getRole(roleId, orgId, null)
          .then((role) => {
            expect(role.isActive).to.be.equal('false');
            return Promise.resolve();
          });
      });
  });

  xit('getAllRoles_listParam=null', () => {
    let listParam;
    return services.roleService.getAllRoles(orgId = null, roleId = null, listParam = null, limit = null, offset = null)
      .then((role) => {
        role.forEach(element => {
          expect(role).to.exist;
          expect(element.isActive).to.not.be.equal('false');
          return Promise.resolve();
        });
      });
  });

  xit('getAllRoles_listParam=false', () => {
    let listParam;
    return services.roleService.getAllRoles(orgId = null, roleId = null, listParam = false, limit = null, offset = null)
      .then((role) => {
        role.forEach(element => {
          expect(role).to.exist;
          expect(element.isActive).to.not.be.equal('disabled');
          expect(element.isActive).to.not.be.equal('false');
          return Promise.resolve();
        });
      });
  });
  it('getModuleList', () => {
    return services.roleService.getModuleList(limit, offset)
      .then((role) => {
        expect(role).to.exist;
        expect(role.isActive).to.not.be.equal('false');
        return Promise.resolve();
      });
  });

  it('getModuleCount', () => {
    return services.roleService.getModuleList(limit, offset)
      .then(result => {
        return services.roleService.getModuleCount()
          .then((modulecount) => {
            expect(modulecount).to.exist;
            expect(modulecount).to.equal(result.length);
            return Promise.resolve();
          });
      });
  });

});
