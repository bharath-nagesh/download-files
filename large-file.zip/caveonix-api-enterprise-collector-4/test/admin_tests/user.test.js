const expect = require('chai').expect;
let services = require('../../app/services');

describe('user service', function () {
  this.timeout(100000);
  let orgId;
  let limit = 10;
  let offset = 0;
  let userId;
  let username;

  xit('createUser', () => {
    let params = {
      username: 'testuser1_9@Test.Com',
      firstName: 'test',
      lastName: 'test',
      role_id: 5,
      organization_id: 0,
      isActive: 'enabled',
      password: 'Test@12345'
    };
    return services.userService.createUser(params.username, params.password, params.firstName, params.lastName, orgId, params.role_id, params.organization_id, params.isActive, params)
      .then((user) => {
        userId = user.id;
        username = user.username;
        expect(user.username).to.be.equal(params.username);
        expect(user.firstName).to.be.equal(params.firstName);
        expect(user.lastName).to.be.equal(params.lastName);
        expect(user.isActive).to.be.equal(params.isActive);
        return Promise.resolve();
      });
  });

  xit('updateUser', () => {

    let params = {
      username: 'testuser1_9@Test.Com',
      firstName: 'test',
      lastName: 'test',
      role_id: 5,
      organization_id: 0,
      isActive: 'enabled',
      password: 'Test@12345'
    };
    return services.userService.updateUser(userId, null, params)
      .then((user) => {
        userId = user.id;
        username = user.username;
        expect(user.username).to.be.equal(params.username);
        expect(user.firstName).to.be.equal(params.firstName);
        expect(user.lastName).to.be.equal(params.lastName);
        expect(user.isActive).to.be.equal(params.isActive);
        return Promise.resolve();
      });
  });

  xit('getUser', () => {
    return services.userService.getUser(userId, null)
      .then((user) => {
        expect(user).to.exist;
        expect(user.isActive).to.not.be.equal(false);
        return Promise.resolve();
      });
  });

  xit('deleteUser', () => {
    return services.userService.deleteUser(userId, null)
      .then(() => {
        return services.userService.getUser(userId, null)
          .then((update) => {
            expect(update.isActive).to.be.equal(false);
            return Promise.resolve();
          });
      });
  });
});
