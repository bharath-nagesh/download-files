const expect = require('chai').expect
let services = require('../../app/services')
let models = require('../../app/models');

describe('assetRemoteAccessDetailMember service', function () {
    this.timeout(100000);
    let organizationId;
    let limit = 10;
    let offset = 0;
    let assetId;
    let remoteAccessDetailId1;
    let remoteAccessDetailId2;
    before(function() {
        return models.Organization.findAll({where: {is_active: {$ne: 'false'}}, order: [['id', 'ASC']]}).then(allOrganization =>{
            organizationId = allOrganization[1].id;
        });  
    })

    it('get all asset Remote Access Detail Members', function () {
        return services.assetRemoteAccessDetailMembersService.getAllAssetRemoteAccessDetailMembers(organizationId, limit, offset)
            .then(result => {
                expect(result).to.exist; 
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })  
    })

    it('get all asset Remote Access Detail Members count', function () {
        return services.assetRemoteAccessDetailMembersService.getAllAssetRemoteAccessDetailMembers(organizationId, null, null)
            .then(result => {
                return services.assetRemoteAccessDetailMembersService.getAssetRemoteAccessDetailMembersCount(organizationId, null).then(count => {
                    expect(count).to.equal(result.length);
                });
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })  
    })

    xit('create asset Remote Access Detail Member', function () {
        return services.assetService.getAllAsset(organizationId, limit, offset).then(allAsset => {
            return services.remoteAccessDetailService.getAllRemoteAccessDetails(organizationId, limit, offset).then(allRemoteAccessDetails =>{
                assetId = allAsset[0].id;
                remoteAccessDetailId1 = allRemoteAccessDetails[0].id;
                remoteAccessDetailId2 = allRemoteAccessDetails[1].id;

                let params = {
                    assetId: assetId,
                    remoteAccessDetailId: remoteAccessDetailId1
                }
                return services.assetRemoteAccessDetailMembersService.createAssetRemoteAccessDetailMembers(organizationId, params)
                    .then(result => {
                        expect(result.assetId).to.be.equal(assetId);
                        expect(result.remoteAccessDetailId).to.be.equal(remoteAccessDetailId1);
                }).catch(err => {
                    console.log(err);
                    expect(err).to.be.equal(err);
                })  
            });
        });
    })

    it('update asset Remote Access Detail Member', function () {
            let params = {
                remoteAccessDetailId: remoteAccessDetailId2
            }
            return services.assetRemoteAccessDetailMembersService.updateAssetRemoteAccessDetailMembers(assetId, params)
                .then(result => {
                    expect(result.assetId).to.be.equal(assetId);
                    expect(result.remoteAccessDetailId).to.not.be.equal(remoteAccessDetailId1);
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })  
    });

    it('delete asset Remote Access Detail Member',function () {

        return services.assetRemoteAccessDetailMembersService.deleteByIdAssetRemoteAccessDetailMembers(assetId)
            .then((result) => {
                return models.AssetRemoteAccessDetailMembers.findOne({where: { asset_id: assetId}}).then(AssetRemoteAccessDetailMember => {
                    expect(AssetRemoteAccessDetailMember).to.be.equal(null)
                })
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })  
    });
})

