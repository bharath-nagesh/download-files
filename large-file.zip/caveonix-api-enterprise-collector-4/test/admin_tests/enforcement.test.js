const expect = require('chai').expect
let services = require('../../app/services')
let mochaAsync = require('./../../utils/mochaAsync')
var rp = require('request-promise');
let config =  require('../../configure').get()
let port = config.port || 1337
let logger = require('./../../utils/logger').logger.child({
  sub_name: 'IdentityService-enforcement.service',

});

xdescribe('enforcement service', function() {
  let orgId, token, user;
  before(async () => {
    let res = await rp
      .post(`http://localhost:${port}/auth/login`,
        {'json':true,body:{ username: 'orgadmin@caveonix.com', password: 'test' }})


        user = res.user
        token = res.token
        orgId = user.Organization.organization_id


  });

  it('get security group', async ()=> {

    let res=await  services.enforcementService._getSecurityGroups(user.id,token,orgId)
    expect(res).to.not.be.null
  })
  it('get security tags', async ()=> {

    let res = await services.enforcementService._getSecurityTags(user.id,token,orgId)
    logger.info({res},'the res')
    expect(res).to.not.be.null

  })

  it('create security tags', async ()=> {
let tags = ['tester_lester_1']
    let res = await services.enforcementService._createOrUpdateSecurityTags(user.id,token,orgId,tags,['1'])
    logger.info({res},'the res')
    expect(res).to.not.be.null

  })

  it('detatch security tags', async ()=> {
    let tags = ['tester_lester_1']
    let res = await services.enforcementService._detatchSecurityTags(user.id,token,orgId,tags,['1'])
    logger.info({res},'the res')
    expect(res).to.not.be.null

  })

  it('delete security tags', async ()=> {
    let tags = ['tester_lester_1']
    let res = await services.enforcementService._deleteSecurityTags(user.id,token,orgId,tags)
    logger.info({res},'the res')
    expect(res).to.not.be.null

  })

  it('quarantine', async ()=> {
    let tags = ['tester_lester_1']
    let res = 1
    // let res = await services.enforcementService._quarantine(user.id,token,orgId,type,ids,tags)
    logger.info({res},'the res')
    expect(res).to.not.be.null

  })
  it('unquarantine', async ()=> {
    let tags = ['tester_lester_1']
    let res = 1
    // let res = await services.enforcementService._unquarantine(user.id,token,orgId,type,ids)
    logger.info({res},'the res')
    expect(res).to.not.be.null

  })
})
