const expect = require('chai').expect
let services = require('../../app/services')

describe('softwareTag service', function () {
    this.timeout(100000);
    let orgId = 0;
    let limit = 10;
    let offset = 0;
    let softwareTagId;
    let softwareTagName;
    xit('getAllSoftwareTag', () => {
        return services.softwareTagService.getAllSoftwareTag(orgId, limit, offset)
            .then((softwareTag) => {
                softwareTagId = softwareTag[0].dataValues.id
                softwareTagName = softwareTag[0].dataValues.name
                expect(softwareTag).to.exist;
                softwareTag.forEach(element => {
                    expect(element.isActive).to.not.be.equal('false')
                });
              
                return Promise.resolve()
            })
    });

    it('getAllSoftwareTagCount', () => {
        return services.softwareTagService.getAllSoftwareTag(orgId, null, null)
            .then(result => {
                return services.softwareTagService.getAllSoftwareTagCount(orgId)
                    .then((softwareTag) => {
                        expect(softwareTag).to.exist;
                        return Promise.resolve()
                    })
            });
    });

    xit('getSoftwareTag', () => {
        return services.softwareTagService.getSoftwareTag(softwareTagId, null)
            .then((result) => {
                expect(result).to.exist;
                expect(result.id).to.be.equal(softwareTagId)
                expect(result.isActive).to.not.be.equal('false')
                return Promise.resolve()
            })
    })

    xit('getSoftwareTagByName', () => {
        return services.softwareTagService.getSoftwareTagByName(softwareTagName)
            .then((result) => {
                expect(result).to.exist;
                expect(result.isActive).to.not.be.equal('false')
                return Promise.resolve()
            })
    })

    
})