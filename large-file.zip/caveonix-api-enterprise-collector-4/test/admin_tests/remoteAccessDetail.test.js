const expect = require('chai').expect;
let services = require('../../app/services');

describe('remoteAccessDetail service', function () {
  this.timeout(200000);
  let orgId;
  let limit = 10;
  let offset = 0;
  let remoteAccessDetailId;
  it('create', () => {
    let params = {
      connectionName: 'test_remoteAccessDetails7',
      linuxSPUsername: 'LinuxUser6@caveonix.com',
      linuxSPPassword: 'test',
      windowsSPUsername: 'windowsUser6@caveonix.com',
      windowsSPPassword: 'test',
      salt: 'test',
      type: 'asset',
      organization_id: 0,
      location_id: 0,
      hosting_provider_id: 0,
      assets: '44,52,48',
      isActive: 'enabled'
    };
    return services.remoteAccessDetailService.create(orgId, params)
      .then((remoteAccessDetail) => {
        remoteAccessDetailId = remoteAccessDetail.id;
        connectionName = remoteAccessDetail.connectionName;
        orgId = remoteAccessDetail.organization_id;
        expect(remoteAccessDetail.connectionName).to.be.equal(params.connectionName);
        expect(remoteAccessDetail.linuxSPUsername).to.be.equal(params.linuxSPUsername);
        expect(remoteAccessDetail.windowsSPUsername).to.be.equal(params.windowsSPUsername);
        expect(remoteAccessDetail.salt).to.be.equal(params.salt);
        expect(remoteAccessDetail.organization_id).to.be.equal(params.organization_id);
        expect(remoteAccessDetail.location_id).to.be.equal(params.location_id);
        expect(remoteAccessDetail.hosting_provider_id).to.be.equal(params.hosting_provider_id);
        expect(remoteAccessDetail.isActive).to.be.equal(params.isActive);
        return Promise.resolve();
      });
  });

  xit('updateRemoteAccessDetail', () => {
    let params = {
      connectionName: 'test_remoteAccessDetails71234',
      linuxSPUsername: 'LinuxUser161@caveonix.com',
      linuxSPPassword: 'test',
      windowsSPUsername: 'windowsUser611@caveonix.com',
      windowsSPPassword: 'test',
      salt: 'test',
      type: 'asset',
      organization_id: 0,
      location_id: 0,
      hosting_provider_id: 0,
      assets: '44,52,48',
      isActive: 'enabled'
    };
    return services.remoteAccessDetailService.updateRemoteAccessDetail(remoteAccessDetailId, orgId, params)
      .then((remoteAccessDetail) => {
        remoteAccessDetailId = remoteAccessDetail.id;
        connectionName = remoteAccessDetail.connectionName;
        expect(remoteAccessDetail.connectionName).to.be.equal(params.connectionName);
        expect(remoteAccessDetail.linuxSPUsername).to.be.equal(params.linuxSPUsername);
        expect(remoteAccessDetail.windowsSPUsername).to.be.equal(params.windowsSPUsername);
        expect(remoteAccessDetail.salt).to.be.equal(params.salt);
        expect(remoteAccessDetail.organization_id).to.be.equal(params.organization_id);
        expect(remoteAccessDetail.location_id).to.be.equal(params.location_id);
        expect(remoteAccessDetail.hosting_provider_id).to.be.equal(params.hosting_provider_id);
        expect(remoteAccessDetail.isActive).to.be.equal(params.isActive);
        return Promise.resolve();
      });
  });

  it('getRemoteAccessDetailbyId', () => {
    return services.remoteAccessDetailService.getRemoteAccessDetail(remoteAccessDetailId, orgId, null)
      .then((remoteAccessDetail) => {
        expect(remoteAccessDetail).to.exist;
        expect(remoteAccessDetail.id).to.be.equal(remoteAccessDetailId);
        expect(remoteAccessDetail.organization_id).to.be.equal(orgId);
        expect(remoteAccessDetail.isActive).to.not.be.equal('false');
        return Promise.resolve();
      });
  });

  it('getAllRemoteAccessDetails', () => {
    return services.remoteAccessDetailService.getAllRemoteAccessDetails(orgId, limit, offset)
      .then((remoteAccessDetail) => {
        remoteAccessDetail.forEach(element => {
          expect(element.isActive).to.not.be.equal('false');
        });
        expect(remoteAccessDetail).to.exist;
        return Promise.resolve();
      });
  }).timeout(100000);

  it('getRemoteAccessDetailsCount', () => {
    let orgId = 0;
    return services.remoteAccessDetailService.getAllRemoteAccessDetails(orgId, null, null)
      .then((result) => {
        return services.remoteAccessDetailService.getRemoteAccessDetailsCount(orgId)
          .then((remoteAccessDetail) => {
            expect(remoteAccessDetail).to.exist;
            expect(remoteAccessDetail.isActive).to.not.be.equal('false');
            expect(remoteAccessDetail).to.equal(result.length);
            return Promise.resolve();
          });
      });
  }).timeout(200000);

  it('getRemoteAccessDetails', () => {
    return services.remoteAccessDetailService.getRemoteAccessDetails(remoteAccessDetailId, null)
      .then((remoteAccessDetail) => {
        expect(remoteAccessDetail).to.exist;
        expect(remoteAccessDetail.isActive).to.not.be.equal(false);
        return Promise.resolve();
      });
  });

  it('deleteById', () => {
    return services.remoteAccessDetailService.deleteById(remoteAccessDetailId)
      .then(() => {
        return services.remoteAccessDetailService.getRemoteAccessDetails(remoteAccessDetailId, null)
          .then((update) => {
            expect(update.isActive).to.be.equal(false);
            return Promise.resolve();
          });
      });
  });

});
