const expect = require('chai').expect
let services = require('../../app/services')
let models = require('../../app/models');

describe('application service', function () {
    this.timeout(100000);
    let applicationTagId;
    let organizationId;
    let certificates;
    let policyGroup;
    let limit = 10;
    let offset = 0;
    let certificateId;
    let appCertControlMember;
    let control1;
    before(function() {
        return models.Organization.findAll({where: {is_active: {$ne: 'false'}}, order: [['id', 'ASC']]}).then(allOrganization =>{
            organizationId = allOrganization[1].id;
        });
    });
    it('get all applicationTags with listparam false', function () {
        return services.applicationTagService.getAllApplicationTag(organizationId, limit, offset, false)
            .then(result => {
                result.forEach(element => {
                    expect(element.is_active).to.not.be.equal('false');
                    expect(element.is_active).to.not.be.equal('disabled');
                });
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('get all applicationTags with listparam true', function () {
        return services.applicationTagService.getAllApplicationTag(organizationId, limit, offset, true)
            .then(result => {
                result.forEach(element => {
                    expect(element.is_active).to.not.be.equal('false');
                });
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('get all application  count with listparam false', function () {
        return services.applicationTagService.getAllApplicationTag(organizationId, null, null, false)
            .then(result => {
                return services.applicationTagService.getApplicationTagCount(organizationId, false).then(count => {
                    expect(count).to.equal(result.length);
                });
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    });

    it('get all application  count with listparam true', function () {
        return services.applicationTagService.getAllApplicationTag(organizationId, null, null, true)
            .then(result => {
                return services.applicationTagService.getApplicationTagCount(organizationId, false).then(count => {
                    expect(count).to.equal(result.length);
                });
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    });

    it('create new application', function () {
        return services.orgService.getCertificate(organizationId).then(allCertificates =>{
            return services.policyGroupService.getAllPolicyGroup(organizationId,false,limit,offset).then(allPolicyGroup =>{
                certificateId = allCertificates[0].id;
                certificates = ''+allCertificates[0].id+','+allCertificates[1].id+'';
                policyGroup = ''+allPolicyGroup[0].id+','+allPolicyGroup[1].id+'';
                let params = {
                    certificates: certificates,
                    impact_level: 1,
                    isActive: 'enabled',
                    name: 'New Application_test',
                    policyGroup: policyGroup
                }
                return services.applicationTagService.create(organizationId,params)
                    .then(result => {
                        applicationTagId = result.id;
                        expect(result.name).to.be.equal(params.name);
                        expect(result.isActive).to.be.equal(params.isActive);
                    });
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
        });
    });

    it('update application', function () {
        let params = {
            certificates: certificates,
            impact_level: 1,
            isActive: 'enabled',
            name: 'New Application Update_test',
            policyGroup: policyGroup
        }
        return services.applicationTagService.updateApplicationTagById(applicationTagId, params, organizationId)
            .then(result => {
                expect(result.name).to.be.equal(params.name);
                expect(result.isActive).to.be.equal(params.isActive);
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    });

    it('get application details by application id and organization_id',function () {

        return services.applicationTagService.getApplicationTag(applicationTagId, organizationId)
            .then((result) => {
                expect(result).to.exist;
                expect(result.name).to.not.be.equal('New Application');
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('get application details by organization_id',function () {

        return services.applicationTagService.getApplicationTagsForOrg(organizationId)
            .then((result) => {
                expect(result).to.exist;
                result.forEach(element => {
                    expect(element.is_active).to.not.be.equal('false');
                });
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('get application policy source members by application id',function () {

        return services.applicationTagService.getApplicationPolicySourceMembers(applicationTagId)
            .then((result) => {
                expect(result).to.exist;
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    xit('get all controls',function () {

        return services.applicationTagService.getControls(organizationId, limit, offset, 'nesa')
            .then((result) => {
                expect(result).to.exist;
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    xit('get all controls count', function () {
        return services.applicationTagService.getControls(organizationId, null, null, 'nesa')
            .then(result => {
                return services.applicationTagService.getControlsCount(organizationId, 'nesa').then(count => {
                    expect(count).to.equal(result.length);
                });
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    });

    it('get all controls by application id and certificate id',function () {

        return services.applicationTagService.getApplicationTagControls(applicationTagId, certificateId)
            .then((result) => {
                expect(result).to.exist;
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('get all controls by application id = all and certificate id',function () {

        return services.applicationTagService.getApplicationTagControls('all', certificateId)
            .then((result) => {
                expect(result).to.exist;
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    xit('create application certificate controls members', function () {
        return models.Certificates.findOne({ where: { id: certificateId } }).then(Certificate => {
            return services.applicationTagService.getControls(organizationId, null, null, Certificate.name.toLowerCase()).then(allcontrols =>{
                control1 = allcontrols[1];
                let control2 = allcontrols[2];
                let params = {
                    application_tag_id:applicationTagId,
                    certificate_id:certificateId,
                    controls:[
                        {
                            control_id: control1.name,
                            implementation_status:"",
                            notes:"",
                            attachment_type:"",
                            attachment:""
                        },
                        {
                            control_id: control2.name,
                            implementation_status:"",
                            notes:"",
                            attachment_type:"",
                            attachment:""
                        }
                    ]
                }
                return services.applicationTagService.createAppCertificateControlMember(applicationTagId, params)
                    .then(result => {
                        appCertControlMember = result[0];
                        result.forEach(element => {
                            expect(element.application_id).to.be.equal(params.application_tag_id);
                            expect(element.certificate_id).to.be.equal(params.certificate_id);
                        });
                    }).catch(err => {
                        console.log(err);
                        expect(err).to.be.equal(err);
                    })
            });
        });
    });

    xit('update application certificate controls members', function () {
        let params = {
            implementation_status:'Implemented'
        }
        return services.applicationTagService.updateAppCertificateControlMember(applicationTagId, certificateId, control1.name, params)
            .then(result => {
                return services.applicationTagService.getAppCertificateControlMember(applicationTagId, certificateId, control1.name).then(controlMemberDetail =>{
                    expect(controlMemberDetail.implementation_status).to.be.equal('Implemented');
                })
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    });

    xit('get application certificate controls member',function () {

        return services.applicationTagService.getAppCertificateControlMember(applicationTagId, certificateId, control1.name)
            .then((result) => {
                expect(result).to.exist;
                expect(result.implementation_status).to.be.equal('Implemented');
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('get all applications of any certificate id',function () {

        return services.applicationTagService.getCertificateApplicationTagDetails(certificateId)
            .then((result) => {
                expect(result).to.exist;
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('delete application details by application id and orgId',function () {

        return services.applicationTagService.deleteApplicationTagById(applicationTagId, organizationId)
            .then((result) => {
                expect(result.isActive).to.be.equal('false')
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })
})

