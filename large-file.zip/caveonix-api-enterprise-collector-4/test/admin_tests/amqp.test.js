const expect = require('chai').expect
let services = require('../../app/services')
let models = require('../../app/models');

xdescribe('amqp service', function () {
    this.timeout(100000);
    let amqpId;
    let organizationId;
    let limit = 10;
    let offset = 0;
    before(function() {
        return models.Organization.findAll({where: {is_active: {$ne: 'false'}}, order: [['id', 'ASC']]}).then(allOrganization =>{
            organizationId = allOrganization[1].id;
        });
    });
    it('get all amqp details', function () {
        return services.amqpService.getAmqpDetailsByOrgId(organizationId, limit, offset)
            .then(result => {
                result.forEach(element => {
                    expect(element.is_active).to.not.be.equal('false');
                });
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    }).timeout(100000);

    it('get all amqp details count', function () {
        return services.amqpService.getAmqpDetailsByOrgId(organizationId, null, null)
            .then(result => {
                return services.amqpService.getAmqpDetailsCount(organizationId).then(count => {
                    expect(count).to.equal(result.length);
                });
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    }).timeout(100000);

    it('create amqp details', function () {
        let params = {
            host_name: '10.1.8.589',
            port: 5672,
            virtual_host: 'Caveonix',
            user_name: 'mqadmin',
            password: 'mqadminpassword',
            source_manager_id: 1,
            organization_id: organizationId
        }
        return services.amqpService.create(params)
            .then(result => {
                amqpId = result.id;
                expect(result.host_name).to.be.equal(params.host_name);
                expect(result.port).to.be.equal(params.port);
                expect(result.virtual_host).to.be.equal(params.virtual_host);
                expect(result.user_name).to.be.equal(params.user_name);
                expect(result.source_manager_id).to.be.equal(params.source_manager_id);
                expect(result.organization_id).to.be.equal(params.organization_id);
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    });

    it('update amqp details', function () {
        let params = {
            host_name: '10.1.8.599',
            port: 5672,
            virtual_host: 'Caveonix',
            user_name: 'mqadmin',
            password: 'mqadminpassword',
            source_manager_id: 1,
            organization_id: organizationId
        }
        return services.amqpService.updateAmqpDetailsById(amqpId, params, organizationId)
            .then(result => {
                amqpId = result.id;
                expect(result.host_name).to.be.equal(params.host_name);
                expect(result.port).to.be.equal(params.port);
                expect(result.virtual_host).to.be.equal(params.virtual_host);
                expect(result.user_name).to.be.equal(params.user_name);
                expect(result.source_manager_id).to.be.equal(params.source_manager_id);
                expect(result.organization_id).to.be.equal(params.organization_id);
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    });

    it('get amqp details by amqp id and organization_id',function () {

        return services.amqpService.getAmqpDetailsId(amqpId, organizationId)
            .then((result) => {
                expect(result).to.exist;
                expect(result.type).to.not.be.equal('10.1.8.4');
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })

    it('delete amqp details by amqp id',function () {

        return services.amqpService.deleteById(amqpId)
            .then((result) => {
                expect(result.is_active).to.be.equal('false')
            }).catch(err => {
                console.log(err);
                expect(err).to.be.equal(err);
            })
    })
})

