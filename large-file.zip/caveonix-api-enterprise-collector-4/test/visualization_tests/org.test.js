const expect = require('chai').expect
const request = require('superagent')
let definitions = require('../../app/definitions/org.js')
let config =  require('../../configure').get()
let port = config.port || 1337
let token,orgId = 1
xdescribe('org widgets', function() {
  this.timeout(60000)
  before((done) => {
    request
      .post(`localhost:${port}/auth/login`)
      .send({ username: 'orgadmin@caveonix.com', password: 'test' })
      .then(res => {

        let user = res.body.user
        token = res.body.token
        orgId = user.Organization.organization_id
        done()
      })
  })

  for (let i = 0; i < definitions.length; i++) {

    let def = definitions[i]
    console.log(def)
    describe(`${def.name}`, function () {
      let selectors = Object.keys(def.sql)
      let routeTemplate = def.route
      if(Array.isArray(routeTemplate)){
        routeTemplate = routeTemplate[1]
      }
      let route = routeTemplate
        .split('/')
        .map(str => {
          if (str === ':orgId') return orgId
          else if (str === ':cciId') return 'CCI-000213'
          else if (str === ':cveId') return 'CVE-2013-4527'
          else return str
        })
        .join('/')
      for (let j = 0; j < selectors.length; j++) {
        let selector = selectors[j]
        it(`${route}?selector=${selector} should return 200`, () => {
          return request
            .get(`localhost:${port}/api/organization/${route}?selector=${selector}`)

            .set('Authorization', `bearer ${token}`)

            .then(data => {
              expect(data.status).to.equal(200)
              return Promise.resolve()
            }).catch(error => {
              error.message = `${route}?selector=${selector} `
              return Promise.reject(error)
            })
        })
      }
    })

  }
})
