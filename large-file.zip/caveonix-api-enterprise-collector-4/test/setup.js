const {each} = require('lodash');
const glob = require('glob-fs')();
const configSetter = require('../config.js');
const fs = require('fs');
const path = require('path');
const Mocha = require('mocha');
const config = {
  db_url: 'postgres://GenesisAdmin:Genes1sAdm1n@10.1.8.14/postgres',
  environment: 'development',
  open_cpu_uri: 'http://localhost:8004',
  es_url: '10.1.8.4:9200',
  name: 'e2c',
  port: 7331,
  secret: 'secret',
  it_worked: 'YES'
};

//configSetter.set(config);

// ~~~~~~~~~~~~~~ ^^^ CONFIG SET UP ^^^ ~~~~~~~~~~

/*
const walkSync = function (dir, filelist) {
  const path = require('path');
  const fs = require('fs');
  const files = fs.readdirSync(dir);
  filelist = filelist || [];
  files.forEach(function (file) {
    if (fs.statSync(path.join(dir, file)).isDirectory()) {
      filelist = walkSync(path.join(dir, file), filelist);
    } else {
      filelist.push(path.join(dir, file));
    }
  });
  return filelist;
};
*/
// ~~~~~~~~~~~~~~~~~ ^^ helper func ^^ ~~~~~~~~~~~~~~
// require('../server');
const mocha = new Mocha();

const searchPath = __dirname.startsWith('/snapshot/') ? `/snapshot/` : `${__dirname}/..`;
const files = glob.readdirSync('**/*.test.js', { cwd: searchPath });

each(files, filePath => {
  mocha.addFile(filePath);
});

mocha.run((failures) => {
  process.on('exit', () => {
    console.log(failures);
  });
});
