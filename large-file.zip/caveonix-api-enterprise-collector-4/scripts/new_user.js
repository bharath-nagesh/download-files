// let s = require('../server');
var args = require('commander');

args
  .version('0.1')
  .option('-n, --username <username>', "new user's username ")
  .option('-o, --orgId <orgId>', "new user's organization_id ")
  .option('-p, --password <password>', "new user's password ")
  .option('-f, --firstName <firstName>', "new user's firstName ")
  .option('-l, --lastName <lastName>', "new user's lastName ")
  .option('-r, --roleId <roleId>', "new user's roleId ")

  .parse(process.argv);
console.log(process.argv);
let { username, orgId, firstName, lastName, password, roleId } = args;
let services = require('../app/services');
services.userService
  .createUser(username, password, firstName, lastName, roleId, orgId, true)
  .then(user => {
    console.log(`username:${user.username}, password_hash: ${user.password}`);
  })
  .catch(error => {
    console.log(error);
    console.log('missing parameters. one of { username,password,firstname,lastname } is missing');
    console.log({ username, orgId, firstName, lastName, password, roleId });
    process.exit(-1);
  });

process.exit(0);
