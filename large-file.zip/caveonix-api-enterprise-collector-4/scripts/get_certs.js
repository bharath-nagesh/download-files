let sslRootCAs = require('ssl-root-cas')

sslRootCAs.inject()