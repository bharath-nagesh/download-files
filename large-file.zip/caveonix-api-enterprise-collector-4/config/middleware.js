

let bodyParser = require('body-parser');
let methodOverride = require('method-override');
let path = require('path');
let compression = require('compression');
let errorHandler = require('errorhandler');

let config =  require('../configure').get();

module.exports = function(app) {
  let environment = process.env.NODE_ENV || config.environment || 'development';

  if (environment == 'production') {
    app.use(compression());
  } else if (environment == 'development') {
    app.use(errorHandler());
  }
  app.disable('etag');
  app.use(bodyParser.json({limit: '100mb'}));
  app.use(
    bodyParser.urlencoded({limit: '100mb',
      extended: true
    })
  );
  app.use(methodOverride());
};
