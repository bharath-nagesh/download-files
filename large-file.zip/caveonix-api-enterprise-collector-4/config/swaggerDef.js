module.exports = {
  info: {
    title: 'Caveonix Risk Foresight API',
    version: '2.3.0',
    description: 'API endpoints for the Risk Foresight application'
  },
  basePath: '/',
  components: {
    securitySchemes: {
      bearerAuth: {
        type: 'http',
        scheme: 'bearer',
        bearerFormat: 'JWT'
      }
    }
  },
  openapi: '3.0.2',
  security: [{
    bearerAuth: []
  }]
};
