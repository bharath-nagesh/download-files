const { each, get, includes, has } = require('lodash');
const Sequelize = require('sequelize');

const config = require('./../configure').get();
const glob = require('glob-fs')();
const KeyGenerator = require('../utils/generateKeys');
const Op = Sequelize.Op;
const isAppliance = require('../utils/isAppliance');
const logger = require('../utils/logger').logger;

// Local class variables
let dbConnection = null;
const models = {};
const loggerLabel = 'DatabaseConfigurator';

const applianceIncludeList = [
  'AuthorizationInfo',
  'AssetDetail',
  'AssetVMNetwork',
  'AssetRemoteAccessDetailMembers',
  'AssetRepoEndpointMembers',
  'AssetRepoEndpoint',
  'AssetRepoType',
  'Asset',
  'CaveoAgents',
  'CaveoLicense',
  'ScanAudit', // job status
  'Job',
  'MasterNode',
  'OrgMembers', //org_user_role_members',
  'Organization',
  'RemoteAccessDetail',
  'AssetRemoteAccessDetailMembers',
  'ScanType',
  'ScheduleTask',
  'session_info',
  'UserSessionInfo',
  'User',
  'VcdVcenterDetails',
  'VcenterResourceMappings',
  'SecurityHubDetail',
  'Role'
];
const { belongsToMany, hasOne, hasMany, belongsTo } = Sequelize.Model;
Sequelize.Model.belongsToMany = function (target, options) {
  this._belongsToMany = belongsToMany;
  const throughDisabled = get(options, 'through.applianceDisabled');
  if (!target.applianceDisabled && !throughDisabled) {
    this._belongsToMany(target, options);
  }
};
Sequelize.Model.hasMany = function (target, options) {
  this._hasMany = hasMany;
  if (!target.applianceDisabled) {
    this._hasMany(target, options);
  }
};
Sequelize.Model.hasOne = function (target, options) {
  this._hasOne = hasOne;

  if (!target.applianceDisabled) {
    this._hasOne(target, options);
  }
};
Sequelize.Model.belongsTo = function (target, options) {
  this._belongsTo = belongsTo;
  if (!target.applianceDisabled) {
    this._belongsTo(target, options);
  }
};
module.exports = class DatabaseConfigurator {
  /**
   * Initializes the database connection using the config file
   * @returns {Promise<void>}
   */
  static async dbInit() {
    const keyGenerator = new KeyGenerator();
    const decryptedPassword = await keyGenerator.decryptKeys(config.db_password);
    const dbConfig = {
      host: config.db_host,
      dialect: 'postgres',
      operatorsAliases,
      logging: config.db_logging ? console.log : false,
      pool: {
        max: get(config, 'db_max_connections', 15),
        min: get(config, 'db_min_connections', 0),
        idle: get(config, 'db_idle_connection_time', 1000),
        acquire: get(config, 'db_acquire_connection_time', 10000),
        evict: get(config, 'db_evict_time', 1000)
      },
      dialectOptions: {
        ssl: get(config, 'db_ssl', false)
      }
    };
    if (config.db_read_hosts && config.db_read_hosts.length > 0) {
      dbConfig.replication = {
        write: {
          host: config.db_host,
          username: config.db_username,
          password: decryptedPassword
        },
        read: []
      };
      config.db_read_hosts.forEach(element => {
        dbConfig.replication.read.push({
          host: element,
          username: config.db_username,
          password: decryptedPassword
        });
      });
    }

    const sequelize = new Sequelize(config.db_name || 'postgres', config.db_username, decryptedPassword, dbConfig);
    try {
      await sequelize.authenticate();
    } catch (error) {
      logger.error('Error Connecting to Database', { error, loggerLabel });
      throw new Error(`Error Connecting to Database: ${error.message}`);
    }
    dbConnection = sequelize;
  }

  /**
   * Registers and sets up the associations of all models that are named with the '*.model.js' pattern
   * @returns {Promise<void>}
   */
  static async registerModels() {
    const searchPath = __dirname.startsWith('/snapshot/') ? `/snapshot/` : `${__dirname}/..`;
    const files = await glob.readdirSync('**/*.model.js', { cwd: searchPath });
    logger.debug('registering models', { loggerLabel });
    // creating the model map
    each(files, filePath => {
      const currentModel = require(`${searchPath}/${filePath}`);
      // const userDbModel = require(`${searchPath}/${filePath}`);
      const applianceDisabled = (isAppliance() && !includes(applianceIncludeList, currentModel.name));
      currentModel.applianceDisabled = applianceDisabled;
      if (!applianceDisabled) {
        if (has(currentModel, 'name') && has(currentModel, 'init')) {
          currentModel.init(dbConnection);
        }
      }
      models[currentModel.name] = currentModel;

    });

    // iterating and associating if possible
    each(models, model => {
      const applianceDisabled = (isAppliance() && !includes(applianceIncludeList, model.name));
      if (!applianceDisabled && has(model, 'associate')) {
        model.associate(models);
      }
    });
  }

  /**
   * Returns a model with the specified name, if one exists
   * @param name
   * @returns {null}
   */

  static getAllModels() {
    return models;
  }

  static getConnection() {

    return dbConnection;
  }

};

const operatorsAliases = Op ? {
  $eq: Op.eq,
  $ne: Op.ne,
  $gte: Op.gte,
  $gt: Op.gt,
  $lte: Op.lte,
  $lt: Op.lt,
  $not: Op.not,
  $in: Op.in,
  $notIn: Op.notIn,
  $is: Op.is,
  $like: Op.like,
  $notLike: Op.notLike,
  $iLike: Op.iLike,
  $notILike: Op.notILike,
  $regexp: Op.regexp,
  $notRegexp: Op.notRegexp,
  $iRegexp: Op.iRegexp,
  $notIRegexp: Op.notIRegexp,
  $between: Op.between,
  $notBetween: Op.notBetween,
  $overlap: Op.overlap,
  $contains: Op.contains,
  $contained: Op.contained,
  $adjacent: Op.adjacent,
  $strictLeft: Op.strictLeft,
  $strictRight: Op.strictRight,
  $noExtendRight: Op.noExtendRight,
  $noExtendLeft: Op.noExtendLeft,
  $and: Op.and,
  $or: Op.or,
  $any: Op.any,
  $all: Op.all,
  $values: Op.values,
  $col: Op.col
} : {};
