const ActiveDirectoryStrategy = require('@caveonix/passport-activedirectory');
const ActiveDirectory = require('@caveonix/activedirectory');

const config = require('./../configure').get();
const CustomStrategy = require('passport-custom');
const { get } = require('lodash');
const isAppliance = require('../utils/isAppliance');
const jwt = require('jsonwebtoken');
const JwtBearerStrategy = require('passport-http-bearer').Strategy;
const LocalStrategy = require('passport-local').Strategy;
const logger = require('./.././utils/logger').logger.child({});
const User = require('../app/apis/user/user.model');
const Organization = require('../app/apis/organization/organization.model');
const OrgMembers = require('../app/apis/organization/orgMembers.model');
const OrgLicense = require('../app/apis/organization/orgLicense.model');
const AssetRepoEndpoint = require('../app/apis/assetRepoEndpoint/assetRepoEndpoint.model');
const Certificates = require('../app/apis/certificates/certificates.model');
const ProductOfferings = require('../app/apis/productOfferings/product_offerings.model');
const Role = require('../app/apis/roles/role.model');
const KeyGenerator = require('../utils/generateKeys');
const LoginService = require('../app/apis/auth/login.service');
const loginService = new LoginService();
const OrgService = require('../app/apis/organization/org.service');
const orgService = new OrgService();
const passport = require('passport');
const SECRET = require('../utils/secret');
const sequelize = require('../config/db.conf').getConnection();

const loggerLabel = 'PassportConf';

const verifyFunc = async function (profile, ad, done) {
  if (!profile) return done(null);
  if (!profile._json) profile._json = profile;
  if (!profile.name) {
    profile.name = {
      givenName: profile.givenName || 'N/A',
      familyName: profile.familyNvame || profile.sn || 'N/A'
    };
  }

  const potentialUser = await User.findOne({
    where: {
      username: sequelize.where(sequelize.fn('LOWER', sequelize.col('username')), sequelize.fn('lower', profile._json.userPrincipalName))
    },
    include: [
      {
        model: OrgMembers,
        as: 'OrgMemberships',
        include: [{
          model: Organization,
          include: [
            { model: Certificates, through: { attributes: [] } },
            {
              model: ProductOfferings,
              through: { attributes: [] }
            }]
        }, { model: Role, include: [{ all: true }] }]
      }]
  });

  if (!potentialUser) return done(null);
  await User.update({ firstName:profile.givenName,lastName:profile.sn },{ where:{ username: sequelize.where(sequelize.fn('LOWER', sequelize.col('username')), sequelize.fn('lower', profile._json.userPrincipalName)) } });
  const userObj = potentialUser.toJSON();
  const orgObj = userObj.OrgMemberships[0];
  const orgChain = await orgService.getOrgChain(orgObj.organization_id, true);
  orgObj.orgChain = orgChain;
  userObj.organization = orgObj.Organization;
  userObj.organization.organization_id = orgObj.Organization.id;
  userObj.role = orgObj.Role;
  userObj.productOfferings = get(userObj.organization, 'ProductOfferings');
  delete userObj.organization.ProductOfferings;
  userObj.certificates = get(userObj.organization, 'Certificates');
  delete userObj.organization.Certificates;
  return done(null, userObj);
};

passport.use('custom', new CustomStrategy(
  async function (req, done) {
    logger.silly('attempting to login custom user', { loggerLabel });

    // Do your custom user finding logic here, or set to false based on req object
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '1';
    if(typeof config.checkActiveDirectoryCertificate === 'boolean' && config.checkActiveDirectoryCertificate === false){
      process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    }
    const username = req.body.username;
    const password = req.body.password;
    let domain = null;
    const userData = await User.findOne({ where: { username: sequelize.where(sequelize.fn('LOWER', sequelize.col('username')), sequelize.fn('lower', username)),active_directory_id:{ $ne:null },isActive:{ $in:['enabled','true'] } } });
    if (!userData) return done(null);
    if (username.includes('\\')) domain = username.split('\\')[0];
    else if (username.includes('@')) domain = username.split('@')[1];
    if (!domain) return done(null);
    const domainSplit = domain.split('.');
    let baseDN = domainSplit.map( a => { return `DC=${a}`; }).join(',');
    const adData = await AssetRepoEndpoint.findOne({ where: { key: sequelize.where(sequelize.fn('LOWER', sequelize.col('key')), sequelize.fn('lower', baseDN)), is_active:{ $in:['true','enabled'] } } });
    if (!adData) return done(null);
    const keyGenerator = new KeyGenerator();
    const newPass = await keyGenerator.decryptKeys(adData.password);
    if(adData.key) baseDN = adData.key;
    const ad = new ActiveDirectory({
      username: adData.username,
      password: newPass,
      baseDN,
      url: adData.connectionName
    });
    const auth = await new Promise((resolve, reject) => {
      ad.authenticate(username, password, function (err, auth) {
        if (err) {
          resolve(null);
        } else if (auth) {
          resolve(true);
        } else {
          resolve(null);
        }
      });
    });
    if (!auth) return done(null);
    const profile = await new Promise((resolve, reject) => {
      ad.findUser(username, (error, user) => {
        resolve(user);
      });
    });
    try {
      verifyFunc(profile, ad, done);
    } catch (error) {
      logger.error('error in callback', { error, loggerLabel });
    }
  }
));

// Login
passport.use('login', new LocalStrategy(
  {
    usernameField: 'username',
    passwordField: 'password',
    passReqToCallback: true
  },
  async (req, uname, pw, done) => {
    try {
      logger.silly('attempting to login user', { loggerLabel });

      let organizationInclude = [];
      if (!isAppliance()) {
        organizationInclude = [
          {
            model: Certificates,
            through: { attributes: [] }
          },
          { model: ProductOfferings, through: { attributes: [] } },
          { model: OrgLicense }
        ];
      }

      const userOptions = {
        where: {
          username: sequelize.where(sequelize.fn('LOWER', sequelize.col('username')), sequelize.fn('lower', uname)),
          active_directory_id:{ $eq:null },
          $or: [
            { isActive: { $eq: 'true' } },
            { isActive: { $eq: 'enabled' } }
          ]
        },
        include: [
          {
            model: OrgMembers,
            as: 'OrgMemberships',
            include: [
              {
                model: Organization,
                include: organizationInclude
              },
              {
                model: Role,
                include: [{ all: true }]
              }
            ]
          }
        ]
      };

      const user = await User.findOne(userOptions);

      if (!user) {
        return done(null, false, {
          loginMessage: {
            email: 'Sorry, there is no account associated with this email.'
          }
        });
      }
      if (!user.validPassword(pw, user)) {
        return done(
          null,
          false,
          {
            loginMessage: {
              password: 'Invalid password for this account.'
            }
          }
        );
      }

      let loginInfo = user.toJSON();
      delete loginInfo.password;

      // if the user role is mssp or msp their org needs to be added
      const userRole = get(user, 'OrgMemberships[0].Role.name');
      if(userRole === 'billing'){
        return done('You are not authorized to login. Please contact the administrator!');
      }
      if (userRole === 'mssp_owner' || userRole === 'msp_owner') {
        loginInfo = await loginService.addManagedOrgs(loginInfo);
      }

      // setting up the login information for the UI
      const userOrg = get(loginInfo, 'OrgMemberships[0]');
      delete loginInfo.OrgMemberships;
      const orgChain = await Organization.getOrgChain(userOrg.Organization.id);
      loginInfo.organization = userOrg.Organization;
      loginInfo.productOfferings = get(loginInfo.organization, 'ProductOfferings');
      delete loginInfo.organization.ProductOfferings;
      loginInfo.orgChain = orgChain;
      loginInfo.certificates = get(loginInfo.organization, 'Certificates');
      delete loginInfo.organization.Certificates;

      loginInfo.role = userOrg.Role;
      delete loginInfo.role.Users;

      return done(null, loginInfo);
    } catch (error) {
      logger.error('error in login', { error, loggerLabel });
      done(null, false, {
        error: error
      });
    }
  })
);

// Es Login
passport.use('esLogin', new LocalStrategy(
  {
    userameField: 'username',
    passwordField: 'password',
    passReqToCallback: true
  },
  async (req, uname, pw, done) => {
    try {
      logger.silly({ username: uname, orgId: req.body.organizationId }, 'attempting to login user');
      const user = await User.findOne({
        where: {
          username: sequelize.where(sequelize.fn('LOWER', sequelize.col('username')), sequelize.fn('lower', uname)),
          $or: [{ isActive: { $eq: 'true' } }, { isActive: { $eq: 'enabled' } }]
        }
      });
      logger.silly({ user }, 'in callback from user findone');
      if (!user) {
        return done(null, false, { loginMessage: { email: 'Sorry, there is no account associated with this email.' } });
      }
      if (!user.validPassword(pw)) {
        return done(null, false, { loginMessage: { password: 'Invalid password for this account.' } });
      }
      const userObj = user.toJSON();
      return done(null, userObj);
    } catch (e) {
      logger.error({ error: e, stack: e.stack }, 'error in login');
      done(null, false, { error: e });
    }
  })
);

// deserialize user
passport.deserializeUser((sessionUser, done) => {
  logger.silly({ sessionUser }, 'called deserial');

  done(null, sessionUser);
});

// serialize user
passport.serializeUser((user, done) => {
  logger.silly({ user }, 'called serial');
  const sessionUser = {
    username: user.username,
    password: user.password,
    organizationId: user.Organization.id,
    id: user.id
  };

  done(null, sessionUser);
});

passport.use(
  'jwt-bearer',
  new JwtBearerStrategy(SECRET, async function (token, done) {
    let decoded = '';
    try {
      if (config.forensics_enabled && config.forensics_enabled === true) {
        const newToken = token.split('^^');
        decoded = jwt.verify(newToken[0], SECRET);
      } else {
        decoded = jwt.verify(token, SECRET);
      }
    } catch (e) {
      // 440 represents session timeout
      e.status = 440;
      e.statusText = 'Session Timeout';
      return done(e);
    }
    try {
      const user = await User.findByPk(decoded.id, {
        include: [
          {
            model: Organization,
            as: 'Organizations',
            where: { id: decoded.organizationId },
            required: false
          },
          {
            model: OrgMembers,
            as: 'OrgMemberships',
            include: [
              { model: Role }
            ]
          }
        ]
      });
      if (!user) {
        logger.error('no user found');
        return done(null, false);
      }
      let userObj = user.toJSON();
      if (user.OrgMemberships[0].Role.name === 'mssp_owner' || user.OrgMemberships[0].Role.name === 'msp_owner') {
        userObj = await loginService.addManagedOrgs(userObj);
      }

      return done(null, userObj, token);
    } catch (err) {
      logger.silly(
        {
          err,
          stack: err.stack
        },
        'error occurred finding user in db'
      );
      return done(err);
    }
  })
);

module.exports = passport;
