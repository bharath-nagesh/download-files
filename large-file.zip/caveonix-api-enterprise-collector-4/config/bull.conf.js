const Queue = require('bull');
const config = require('../configure').get();
const logger = require('../utils/logger').logger.child({
  sub_name: 'IdentityService-jobHandler'
});

class JobQueueFactory {
  constructor() {
    this.redis_url = config.redis_url;
    this.queueMap = {};
  }

  createQueueObject(name, processor = null) {
    const queue = new Queue(name, this.redis_url);
    logger.silly('creating queue');
    return { name, queue, processor };
  }

  async produceJob(name, jobDetails, delay = 0) {
    logger.silly('adding job');
    const queueData = this.queueMap[name] || this.createQueueObject(name, null);
    this.queueMap[name] = queueData;
    delay = delay * 1000;
    return queueData.queue.add(name, jobDetails, { removeOnComplete: 100, delay });
  }

  async registerConsumer(name, processorFunc) {
    logger.silly('registering consumer');
    const queueData = this.queueMap[name] || this.createQueueObject(name, null);
    this.queueMap[name] = queueData;
    if (!queueData.processor) {
      queueData.processor = processorFunc;
      return queueData.queue.process(name, (jobInfo) => processorFunc(jobInfo.data));
    }
    return;
  }
}

// const jq = new JobQueueFactory();
//
// jq.registerConsumer('test', async (job) => {
//     console.log(`process 1 job details: ${JSON.stringify(job)}`);
//     return;
//   }
// );
// jq.registerConsumer('test', async (job) => {
//     console.log(`process 2 job details: ${JSON.stringify(job)}`);
//     return;
//   }
// );
// for (let i = 0; i < 10; i++) {
//   setTimeout(() => jq.produceJob('test', { message: `this is a test ${i}` }), i * 1000);
//
// }

module.exports = new JobQueueFactory();
