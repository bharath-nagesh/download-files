const { exec } = require('pkg');
const fs = require('fs');
const isAppliance = 'module.exports = () => false;';
fs.writeFileSync('./utils/isAppliance.js', isAppliance);
exec(['--options', 'max-old-space-size=4096','.', '--target', 'macos,linux']);
