module.exports = function(id) {
  if ((!id && !id==0)|| id==null || isNaN(id)) return true;

  return false;
};
