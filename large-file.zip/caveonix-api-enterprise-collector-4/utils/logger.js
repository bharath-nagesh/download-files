const config = require('../configure').get();
const { createLogger, format, transports } = require('winston');
const { colorize, combine, errors, simple, timestamp, json, printf } = format;
const { get, has, toLower, toUpper } = require('lodash');
const level = get(config, 'log_level', 'info');
const moment = require('moment');

let instance;
let auditInstance;

class LoggerService {
  /**
   * Creates and returns a newly configured logger
   * @returns {Logger}
   */
  createLogger(auditLog) {
    const myFormat = printf((data) => LoggerService.getFormat(data, auditLog));

    const logger = createLogger({
      level,
      format: combine(
          timestamp(),
          json(),
          errors()
      ),
      transports: LoggerService.getTransports(auditLog)
    });

    //
    // If we're not in production then log to the `console` with the format:
    // `${info.level}: ${info.message} JSON.stringify({ ...rest }) `
    //
    if (get(process, 'env.NODE_ENV') !== 'production') {
      logger.add(new transports.Console({
        format: combine(
            colorize(),
            simple(),
            errors({ stack: true }),
            myFormat
        )
      }));
    }

    return logger;
  }

  /**
   * Returns the instance of the logger
   * @param {boolean} [auditLog] returns the audit logger if true
   * @returns {LoggerService}
   */
  static getInstance(auditLog) {
    if ((!instance && !auditLog) || (!auditInstance && auditLog)) {
      const tempLogger = new LoggerService();
      if (!auditLog ) {
        instance = tempLogger.createLogger();
      } else if (auditLog) {
        auditInstance = tempLogger.createLogger(true);
      }
    }

    return !auditLog ? instance : auditInstance;
  }

  /**
   * Convenience method for emitting a log
   * @param {string} type
   * @param {string} message
   * @param {string} [label]
   * @param {Error} [error]
   */
  static sendLog(type, message, label= '', error=null) {
    if (type && message) {
      const config = {};

      if (label) {
        config.label = label;
      }

      if (error) {
        config.error = error;
      }

      instance.log(type, message, config);
    }
  }

  /**
   * Returns a formatted log string based on the type of logger
   * @param {string} level
   * @param {string} message
   * @param {string} label
   * @param {string} loggerLabel
   * @param {string} timestamp
   * @param {string} durationMs
   * @param {Error} error
   * @param {string} action
   * @param {string} user
   * @param {string} auditLog
   * @returns {string}
   */
  static getFormat({ level, message, label, loggerLabel, timestamp, durationMs, error, action, user }, auditLog) {
    let string = '';
    label = label || loggerLabel;
    const currentLabel = label ? ` [36m${label}[0m ` : ' ';
    if (!auditLog) {
      durationMs = durationMs ? ` took ${durationMs}ms` : '';
      const stack = has(error, 'stack') ? `\n${error.stack}` : '';
      string = `[38;5;75mcav-ec[0m ${moment(timestamp).format('MM/DD/YYYY hh:mm:ss')} ${level}${currentLabel}${message}${durationMs}${stack}`;
    } else {
      action = action ? `[31m${toUpper(action)}[0m` : ' ';
      user = user ? `[34m${user}[0m` : ' ';
      string = `[38;5;75mcav-ec[0m ${moment(timestamp).format('MM/DD/YYYY hh:mm:ss')} ${user}${currentLabel}${action} ${message}`;
    }
    return string;
  }

  /**
   * Returns the transports based on the type of logger we are dealing with
   * @param {string} auditLog
   * @returns {*[]}
   */
  static getTransports(auditLog) {
    return !auditLog ? [
      new transports.File({ filename: 'error.log', level: 'error' }),
      new transports.File({ filename: 'combined.log' })
    ] : [
      new transports.File({ filename: 'audit.log', level: 'debug' })
    ];
  }

  /**
   * Returns a logger wrapper that handles both the regular logger and audit logger
   * @returns {LoggerService}
   */
  static getWrapper() {
    const wrapperInstance = this.getInstance();
    const wrapperAuditInstance = this.getInstance(true);

    return {
      profile: (message, config) => this.wrapperHelper(wrapperInstance.info, wrapperAuditInstance.debug, message, config),
      info: (message, config) => this.wrapperHelper(wrapperInstance.info, wrapperAuditInstance.debug, message, config),
      debug: (message, config) => this.wrapperHelper(wrapperInstance.debug, wrapperAuditInstance.debug, message, config),
      error: (message, config) => this.wrapperHelper(wrapperInstance.error, wrapperAuditInstance.error, message, config),
      silly: (message, config) => this.wrapperHelper(wrapperInstance.silly, wrapperAuditInstance.silly, message, config)
    };
  }

  /**
   * Helper method that calls the actual logger if the conditions are right
   * @param instanceCallback
   * @param auditInstanceCallback
   * @param message
   * @param config
   */
  static wrapperHelper(instanceCallback, auditInstanceCallback, message, config) {
    if (instanceCallback) {
      instanceCallback(message, config);
    }

    if (auditInstanceCallback && ['create', 'update', 'delete', 'login', 'logout'].includes(toLower(get(config, 'action')))) {
      config.source = 'Caveonix';
      auditInstanceCallback(message, config);
    }
  }
}

module.exports = {
  auditLogger: LoggerService.getInstance(true),
  class: LoggerService,
  logger: LoggerService.getInstance(),
  loggerWrapper: LoggerService.getWrapper()
};
