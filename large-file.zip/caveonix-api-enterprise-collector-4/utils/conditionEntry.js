const { cloneDeep, includes } = require('lodash');
module.exports = function (c = {}) {
  const conditions = cloneDeep(c);
  const { not = {} } = conditions;
  delete conditions.not;
  if (conditions.undefined) delete conditions.undefined;
  const conditionStringArr = Object.entries(conditions).map(([key, value]) => {
    if (!Array.isArray(value)) {
      if (value == '' || value == undefined) {
        return `1=1`;
      }
      //FIXME replacing the : with _ is a major hack and needs to be replaced at a later date ~~ Chris
      return typeof value !== 'string' ? `${key} = ${value}` : (includes(value, ':') ? `${key} LIKE '${value.replace(/:/g,'_')}'` : `(${key} = '${value}' or ${key} = '${value.toLowerCase()}' or ${key} = '${value.toUpperCase()}')`);
    }
    //IS ARRAY
    if (value.length == 0) return `${key} is NULL and ${key} is NOT NULL`;
    return `(${value
      .map(filterVariable => typeof filterVariable !== 'string' ? `${key} = ${filterVariable}` : (includes(filterVariable, ':') ? `${key} LIKE '${filterVariable.replace(/:/g,'_')}'` : `(${key} = '${filterVariable}' or ${key} = '${filterVariable.toLowerCase()}' or ${key} = '${filterVariable.toUpperCase()}')`))
      .join(' or ')})`;
  });

  const notFilterString = Object.entries(not).map(([key, value]) => {
    if (!Array.isArray(value)) {
      if (value == '' || value == undefined) {
        return `1=1`;
      }
      return typeof value !== 'string' ? `${key} != ${value}` : `(${key} != '${value}' and ${key} != '${value.toLowerCase()}' and ${key} != '${value.toUpperCase()}')`;
    }
    //IS ARRAY
    if (value.length == 0) return `${key} is NULL and ${key} is NOT NULL`;
    return `(${value
      .map(filterVariable => typeof filterVariable !== 'string' ? `${key} != ${filterVariable}` : `${key} != '${filterVariable}' and ${key} != '${filterVariable.toLowerCase()}' and ${key} != '${filterVariable.toUpperCase()}'`)
      .join(' and ')})`;
  });
  return [...conditionStringArr, ...notFilterString];
};
