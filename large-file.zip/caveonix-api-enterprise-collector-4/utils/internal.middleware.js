let db = require('../app/models')
let logger = require('./logger').logger.child({
  src: true,
  sub_name: 'internal.middleware'

})
// Authorization: token
module.exports = async function(req,res,next){
  try {
    //user id
    // org id

    let session = await
    db.UserSessionInfo.findOne({where: {session_id: req.headers.authorization}})
    if (session) {
      logger.info('login successful')
      return next()
    } else {
      logger.error({ip:req.ip},'unauthorized internal endpoint')

      return res.sendStatus(401)
    }
  }
  catch(error){
    logger.error({error,stack:error.stack},'error occurred')
    return res.sendStatus(401)
  }
}
