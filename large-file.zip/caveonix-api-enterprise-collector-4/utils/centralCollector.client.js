const requestPromise = require('request-promise');
const CaveoAgents = require('../app/models/caveoAgents.model');
const isAppliance = require('../utils/isAppliance');
const { get } = require('lodash');
const logger = require('./logger').logger;
const config = require('../configure').get();

const SERVICETYPE = 'ec';
const agentName = 'EC';
let activeAgent = null;
const ccApiVersion = 'v1';
const uriPrefix = `${SERVICETYPE}/api/${ccApiVersion}`;
const cc_timeout = config.cc_timeout || 15000;

const loggerLabel = 'CentralCollectorClient';

module.exports = class CentralCollectorClient {

  static async getCentralCollectorAddress() {
    if (activeAgent) return activeAgent.ipAddress;
    activeAgent = await CaveoAgents.findOne({
      where: {
        agent_name: CaveoAgents.sequelize.where(CaveoAgents.sequelize.col('agent_name'), agentName),
        is_active: isAppliance() ? 'true' : 'leader'
      }
    });
    if (!activeAgent) {
      const e = new Error('Central Collector Unavailable');
      e.status = 503;
      throw e;
    }
    return activeAgent.ipAddress;
  }

  static async checkCentralCollectorStatus() {
    const activeAgent = await CentralCollectorClient.getCentralCollectorAddress();
    return requestPromise.get(`${activeAgent}/${uriPrefix}/status/`, {
      rejectUnauthorized: false,
      timeout: cc_timeout
    });
  }

  static async checkLicense(userToken, userId, orgId, fqdn = '') {
    if (isAppliance()) return [true, ''];
    const address = await CentralCollectorClient.getCentralCollectorAddress();

    const url = `${address}/${uriPrefix}/checkLicense/`;
    const formData = {
      userToken,
      userId,
      orgId,
      fqdn
    };
    try {

      const { result, message } = await requestPromise.post(url, {
        formData,
        json: true,
        rejectUnauthorized: false,
        timeout: cc_timeout
      });

      return [result, message];
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred. validating license');
      throw error;
    }
  }

  static async getLicenseInfo() {
    const address = await CentralCollectorClient.getCentralCollectorAddress();
    const url = `${address}/${uriPrefix}/showLicense/`;
    try {
      const licenseInfo = await requestPromise.get({ url, json: true, rejectUnauthorized: false, timeout: cc_timeout });
      return licenseInfo;
    } catch (error) {
      let errMessage = 'Central Collector Error';
      let errStatus = 400;
      if ((error.status && error.status == 503) || error.message.includes('ECONNREFUSED')) {
        errMessage = 'Central Collector Unavailable. Please Contact your Caveonix Administrator';
        errStatus = 503;
      } else if (error.message.includes('ETIMEDOUT')) {
        errMessage = 'Central Collector Timeout Error';
        errStatus = 400;
      }
      const e = new Error(errMessage);
      e.status = errStatus;
      logger.error(errMessage, { error});
      throw e;
    }
  }

  static async getCurrentUsage() {
    const address = await CentralCollectorClient.getCentralCollectorAddress();
    try {
      const url = `${address}/${uriPrefix}/currentUsage/`;
      const d = await requestPromise.get({ url, rejectUnauthorized: false, timeout: cc_timeout });
      return d;
    } catch (error) {
      let errMessage = 'Central Collector Error';
      let errStatus = 400;
      if ((error.status && error.status == 503) || error.message.includes('ECONNREFUSED')) {
        errMessage = 'Central Collector Unavailable. Please Contact your Caveonix Administrator';
        errStatus = 503;
      } else if (error.message.includes('ETIMEDOUT')) {
        errMessage = 'Central Collector Timeout Error';
        errStatus = 400;
      }
      const e = new Error(errMessage);
      e.status = errStatus;
      logger.error({ error, stack: error.stack }, errMessage);
      throw e;
    }

  }

  static async CentralCollectorConnectionCheck() {
    const centralCollectorIpAddress = await CentralCollectorClient.getCentralCollectorAddress();
    if (!centralCollectorIpAddress) {
      logger.silly('There are no central collectors available.');
      const error = new Error('There are no central collectors available.');
      error.status = 503;
      throw error;
    }
    return centralCollectorIpAddress;

  }
};
