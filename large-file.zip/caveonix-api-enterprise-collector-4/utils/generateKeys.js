const { exec } = require('child_process');
const logger = require('./logger').logger.child({
  sub_name: 'IdentityService-keyGenerator.service'

});
module.exports = class GenerateKeys {
  constructor() {
    exec('java -version', (err, stdout, stderr) => {
      if (err) {
        logger.error('err: ', err);
        process.exit(-1);
      }
    });
  }

  generateKeys(key, salt = null) {
    return new Promise((resolve, reject) => {
      if (!key) {
        logger.error('no key passed');
        return resolve(null);
      }
      const command = salt ? `java -cp ./utils/ GenerateKeys encrypt password "${key}" ${salt}` : `java -cp ./utils/ GenerateKeys encrypt password "${key}"`;
      exec(command, (err, stdout, stderr) => {
        if (err) {
          logger.error('err: ', err);
          // node couldn't execute the command
          return reject(err);
        }
        const str = stdout.trim();
        return resolve(str);
      });
    });
  }

  decryptKeys(key, salt = null, type = null) {
    return new Promise((resolve, reject) => {
      if (!key) {
        logger.error('no key passed');
        return resolve(null);
      }
      const command = `java -cp ./utils/ GenerateKeys decrypt password "${key}" ${salt} ${type}`;
      exec(command, (err, stdout, stderr) => {
        if (err) {
          logger.error('err: ', err);
          // node couldn't execute the command
          return reject(err);
        }
        const str = stdout.trim();
        return resolve(str);
      });
    });
  }
};
