const dbConnection = require('../config/db.conf').getConnection();
const CentralCollectorClient = require('./centralCollector.client');
const logger = require('./logger').logger;
module.exports = async function () {
  let apiHealthy = false;
  let dbHealthy = false;
  let ccHealthy = false;
  try {
    await dbConnection.authenticate();
    dbHealthy = true;
  } catch (error) {
    logger.error({ error, stack: error.stack }, 'error occurred checking db health');
    return { apiHealthy, dbHealthy, dbError: error, ccHealthy: 'Unknown' };
  }
  try {
    const status = await CentralCollectorClient.checkCentralCollectorStatus();
    ccHealthy = true;
    logger.info({ status }, 'cc status');
  } catch (error) {
    logger.error({ error, stack: error.stack }, 'error occurred checking db health');
    return { apiHealthy, dbHealthy, ccError: error, ccHealthy };
  }
  apiHealthy = true;
  return { apiHealthy, dbHealthy, ccHealthy };
};
