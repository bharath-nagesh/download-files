let _ = require('lodash')
let logger = require('./logger').logger.child()
module.exports = class Cache {
  constructor(ttl){
    this.memory = {}
    this.ttl = ttl
  }
  set(key,value, ttl = null){
    ttl = ttl || this.ttl
    this.memory[key] = value
    logger.info({key},'setting key')
  }
  get(key){
    let val = this.memory[key]
    // if(val) val = _.cloneDeep(val)
    logger.info({key,is_null: val == null},'is cache miss?')
    return val
  }
}
