const _ = require('lodash');
const mapConditions = require('./conditionEntry');
module.exports = function (acceptedConditions, ...conditions) {
  if (!Array.isArray(acceptedConditions)) return mapConditions(acceptedConditions);
  return mapConditions(_.pickBy(_.merge(...conditions), (value, conditionName) => acceptedConditions.includes(conditionName)));

};

/* Usage of ConditionFilter

{whereCondition(
  conditionFilter(['organization_name','source'] , condition),
  where.common.orgChainFilter,
  `o.type IN ('Organization','Provider')`
)}

{whereCondition(
  conditionFilter(condition),
  where.common.orgChainFilter,
  `o.type IN ('Organization','Provider')`
)}
*/
