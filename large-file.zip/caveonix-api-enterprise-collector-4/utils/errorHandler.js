const logger = require('./.././utils/logger').logger;
const config = require('../configure').get();
const { get } = require('lodash');

/**
 * Handles errors in a centralized fashion
 * @param req
 * @param res
 * @param error
 * @param errorObj
 * @returns {*}
 */
module.exports = (req, res, error, errorObj = null) => {
  if (checkError(error) && get(config, 'development')) {
    logger.error('malformed error. exiting application in dev mode', { error });
    res.status(500).send('malformed error returned from api');
    process.exit(-1);
  }

  // setting the status
  const status = get(error, 'status') || get(error, 'statusCode') || 500;
  if (status === 500) {
    return res.status(status).send('Internal Server Error');
  }
  const message = get(error, 'message');
  errorObj = errorObj ? Object.assign({}, errorObj, { message }) : message;
  return res.status(status).json(errorObj);
};

function checkError(error) {
  // todo look into what is going on here
  const message = get(error, 'message', '');
  if (message) {
    try {
      return (message.includes('??') || message.includes('!!') || typeof message === 'object' || get(error, 'status') === 500);
    } catch (e) {
      logger.error('errors', { error });
      return false;
    }
  }
}
