const cronstrue = require('cronstrue');
const cron = require('cron');
const moment = require('moment');

module.exports = function (expression) {
  try {
    cronstrue.toString(expression);
    let cronSplit = expression.split(' ');
    const seconds = cronSplit[0];
    if (seconds === '*') {
      const err = new Error('seconds must be a number in cron expression');
      err.status = 400;
      throw err;
    }
    const newCron = (cronSplit.slice(0, 5)).join(' ');
    const job = cron.job(newCron);
    const dates = job.nextDates(2).map(date => {
      return moment(date.toString());
    });
    const timeDiff = dates[1].diff(dates[0],'minutes');

    if (isNaN(timeDiff) || parseInt(timeDiff) < 10) {
      const err = new Error('minutes can not be less than 10 in cron expresion');
      err.status = 400;
      throw err;
    }
  } catch (error) {
    if(error.status && error.status === 400) throw error;
    const err = new Error('invalid cron expression');
    err.status = 400;
    throw err;
  }
  return true;
};
