function checkMultiSpace(name) {
  const str = name ? name.trim() : '';
  return str.replace(/\s\s+/g, ' ');
}

function removeAllSpaces(name) {
  const str = name ? name.trim() : '';
  return str.replace(/\s\s+/g, '');
}

module.exports.checkMultiSpace = checkMultiSpace;
module.exports.removeAllSpaces = removeAllSpaces;
