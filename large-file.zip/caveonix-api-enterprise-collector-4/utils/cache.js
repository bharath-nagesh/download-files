const config = require('../configure.js').get();
const logger = require('./../utils/logger').logger;
const MemoryCache = require('memory-cache');
const { promisify } = require('util');
const redis = require('redis');
const KeyGenerator = require('./generateKeys');

const loggerLabel = 'CacheService';

module.exports = class CacheService {
  constructor(stdTTL = 3600000) {
    this.stdTTL = config.demo ? stdTTL : 86400;
    this.cache = new MemoryCache.Cache();
    this.keyGenerator = new KeyGenerator();
  }

  async _init(){
    if (config.redis_cache == false) {

      this._redisGet = async () => null;
      this._redisSet = async () => null;
    } else {
      const redisOptions = {};
      const redisDecrPassword = await this.keyGenerator.decryptKeys(config.redis_password);
      redisOptions.host = config.redis_host;
      redisOptions.password = redisDecrPassword;
      redisOptions.port = config.redis_port || 6379;
      redisOptions.enable_offline_queue = false; // This is will no hold connection if redis is down.
      if (config.redis_tls) {
        redisOptions.tls = {
          rejectUnauthorized: false,
          enableTrace: true
        };
      }
      this.redis = redis.createClient(redisOptions);
      this.redis.on('error', (error) => {
        logger.error({ error, stack: error }, 'error occurred');
      });

      this._redisGet = promisify(this.redis.get).bind(this.redis);
      this._redisSet = promisify(this.redis.set).bind(this.redis);
    }
  }

  get(key) {
    logger.silly('getting cache', { loggerLabel });
    return this.getLocal(key).then(data => {
      if (data) {
        return Promise.resolve(data);
      } else {
        return this.getRemote(key).then(data => {
          return this.setLocal(key, data, this.stdTTL).then(() => {
            return Promise.resolve(data);
          });
        });
      }
    });
  }

  async set(key, obj, ttl = this.stdTTL) {
    logger.silly('setting cache', { loggerLabel });
    if(obj == 'undefined') return null;
    const data = config.redis_cache ? await new Promise((resolve, reject) => {
      this.setLocal(key, obj, ttl);
      this.setRemote(key, obj, ttl).then((data) => {
        resolve(data);
      });
      setTimeout(() => resolve(false),5000);
    }) : false;
    if(!data) return false;
    const d = await this.get(key);
    logger.info({ d }, 'the set data');
    return data;
  }

  async getRemote(key) {
    logger.silly('getting remote cache', { loggerLabel });
    try {
      const data = config.redis_cache ? await new Promise((resolve, reject) => {
        this._redisGet(key).then((data) => {
          resolve(data);
        });
        setTimeout(() => resolve(false),5000);
      }) : false;
      if(!data) return false;
      logger.silly({ data, key }, 'return val of remote cache');
      const retval = JSON.parse(data);
      return retval;
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      throw error;
    }
  }

  setRemote(key, obj, ttl = this.stdTTL) {
    logger.silly('setting remote cache', { loggerLabel });
    if (typeof obj !== 'string') obj = JSON.stringify(obj);
    return this._redisSet(key, obj, 'EX', this.stdTTL);
  }

  async getLocal(key) {
    // return Promise.resolve(this.cache.get(key));
    return null;
  }

  async setLocal(key, obj, ttl = this.stdTTL) {
    // return Promise.resolve(this.cache.put(key, obj, ttl));
    return null;
  }
};
