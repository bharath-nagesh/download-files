module.exports = (name) => {
  if (name == null) {
    return true;
  }
  const str = name.trim();
  return !str || str === 'null';
};
