const NETWORK_STORE_TYPE_ES = 'elasticsearch';
const NETWORK_STORE_TYPE_SOLR = 'solr';
