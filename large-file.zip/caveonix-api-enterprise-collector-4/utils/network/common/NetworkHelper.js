const logger = require('../../logger.js').logger.child({});
const config = require('../../../configure').get();

class NetworkHelper {
  static getNetworkStoreTypeFromConfig() {
    if (!('network_store_type' in config)) {
      logger.warn('network_store_type is not defined in config.json.  Using default of elasticsearch');
      return 'elasticsearch';
    }
    return (config.network_store_type);
  }
}

module.exports = NetworkHelper;
