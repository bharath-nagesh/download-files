class NetworkGenericCache {

  constructor(defaultLifespanIn=60000) {
    this.defaultLifespan = defaultLifespanIn;
    this.keyToObjectHashMap = {};
  }

  get(key) {
    let retval = null;
    if (key in this.keyToObjectHashMap) {
      let storedObject = this.keyToObjectHashMap[key];
      retval = storedObject.retval;
      if (this._isLifeSpanExceeded(storedObject)) {
        return null;
      }
    }
    return retval;
  }

  exists(key) {
    if (key in this.keyToObjectHashMap) {
      let storedObject = this.keyToObjectHashMap[key];
      if (this._isLifeSpanExceeded(storedObject)) {
        return false;
      }
      return true;
    }
    return false;
  }

  put(key, value) {
    let storedObject = {};
    storedObject.retval = value;
    storedObject.timestamp = Date.now();
    storedObject.lifespan = this.defaultLifespan;
    this.keyToObjectHashMap[key] = storedObject;
  }

  purge() {
    const keys = Object.keys(this.keyToObjectHashMap);
    for (const key of keys) {
      let storedObject = this.keyToObjectHashMap[key];
      if (this._isLifeSpanExceeded(storedObject)) {
        delete this.keyToObjectHashMap[key];
      }
    }
  }

  hashAString(stringToHash) {
    var hash = 0, i, chr;
    for (i = 0; i < stringToHash.length; i++) {
      chr   = stringToHash.charCodeAt(i);
      hash  = ((hash << 5) - hash) + chr;
      hash |= 0; // Convert to 32bit integer
    }
    return hash;
  }

  _isLifeSpanExceeded(storedObject) {
    if (!storedObject) {
      return true;
    }
    const timestamp = storedObject.timestamp | 0;
    const lifespan = storedObject.lifespan | 0;
    const curTimestamp = Date.now();
    if ((curTimestamp - timestamp) < (lifespan)) {
      return false;
    }
    return true;
  }

}

module.exports = NetworkGenericCache;
