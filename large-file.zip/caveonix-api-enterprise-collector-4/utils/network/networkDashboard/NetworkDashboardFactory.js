const logger = require('../../logger.js').logger.child({});
const networkHelper = require('../common/NetworkHelper');
const implementation = require('./implementation');
class NetworkDashboardFactory {
  //
  // Call this method to create a NetworkDashboard object of the correct network type.  All NetworkDashboards SHALL conform to the interface defined by NetworkDashboardInterface
  static createNetworkDashboard(assetGroups, hostPort, userName, userPass, token = null, authToken = null, log = 'warning', networkStoreType = null) {
    if (networkStoreType === null) {
      networkStoreType = networkHelper.getNetworkStoreTypeFromConfig();
    }
    const ImplementationClass = implementation[networkStoreType];
    // if the network networkSourceType is missing from the network implementations then inform the user of their error
    if (!ImplementationClass) {
      logger.error({ type: networkStoreType }, 'Unsupported network data store for NetworkDashboardFactory, NetworkDashboard object not created.');
      const error = new Error('Unsupported network data store for NetworkDashboardFactory, NetworkDashboard object not created.');
      error.status = 404;
      throw error;
    }
    return new ImplementationClass(assetGroups, hostPort, userName, userPass, token, authToken, log);
  }
}

module.exports = NetworkDashboardFactory;
