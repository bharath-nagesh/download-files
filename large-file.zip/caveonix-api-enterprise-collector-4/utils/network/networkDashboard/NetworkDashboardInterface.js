const logger = require('../../logger.js').logger.child({});

//
// This is an abstract class that defines the required interface for any NetworkDashboard implementation.
// All methods in this class SHALL be overriden by the implementation and not called by the implementation.
class NetworkDashboardInterface {
  // ============================================================================================
  // Creation function - called once, and only once, immediately after constructor.
  // ============================================================================================
  // params must include
  //   Input:
  //      assetGroups -
  //                      [
  //                          {
  //                              containerName: <name Of container>,
  //                              members:    {
  //                                              options:{
  //                                                  location:   <location id from which the assets come>,
  //                                                  serviceProvider: <service provider id from which the assets come>,
  //                                                  organization:    <organization id from which the assets come>
  //                                                  },
  //                                             objects: [
  //                                                        uuid: <instance uuid of asset>,
  //                                                        ...
  //                                                      ]
  //                                          }
  //                          },
  //                          ...
  //                      ]
  //      hostPort -- ElasticSearch host:port address (e.g.  localhost:9200)
  //      log -- (optional) the log level for elasticSearch client library
  constructor(assetGroups, hostPort,userName,UserPass, token = null, authToken = null, log = 'warning') {
    logger.silly('Base implementation for NetworkDashboard called for constructor ');
  }

  // ============================================================================================
  // PUBLIC functions - available from instantiated object.  The 'this' variable is available
  // ============================================================================================

  // ----------------------------------
  // getMostRecentDateWithData
  //   Will provide the most recent date that has dashboard data
  getMostRecentDateWithData(target = 'policies', organization = '*', location = '*', serviceProvider = '*') {
    logger.error('Base implementation for NetworkDashboard called for getMostRecentDateWithData called.  This' +
      ' should have been overridden by implementation');
  }

  // ----------------------------------
  // calculateTotalTrafficFlow
  //   Works on the assetGroups set for the Class
  //
  //  Input:
  //      date - a Date object for the date to calculate total traffic for
  //
  //  Output (a number of bytes that represent all traffic flowing to/from assets in the assetGroups):
  //      {
  //          number:
  //          percentChange:
  //          message:  <optional human-readable message>
  //      }
  //
  //   If there is no data for the provided date then the output is:
  // {
  //   "number": 0,
  //   "percentChange": 0
  // }
  //
  // NOTE: this does not fail if cannot get % change due to missing data, percentChange will be null
  calculateTotalTrafficFlow(date = new Date(), secondDate, timeFrame = 'daily') {
    logger.error('Base implementation for NetworkDashboard called for calculateTotalTrafficFlow called.  This' +
      ' should have been overridden by implementation');
  }

  // ----------------------------------
  // calculateTotalPolicies
  //   Works on the assetGroups set for the Class
  //
  //  Input:
  //      date - the most recent UTC date for which to calculate the
  //
  //  Output (a number of policies that represent in the assetGroups):
  //      {
  //          number:
  //          percentChange:
  //          message:  <optional human-readable message>
  //      }
  //
  // If there is no data for the day provided:
  // {
  //   "number": 0,
  //   "percentChange": 0
  // }
  //
  // NOTE: this does not fail if cannot get % change due to missing data, percentChange will be null
  calculateTotalPolicies(date = new Date(), secondDate, timeFrame = 'daily') {
    logger.error('Base implementation for NetworkDashboard called for calculateTotalPolicies called.  This' +
      ' should have been overridden by implementation');
  }

  // ----------------------------------
  // calculateTotalPolicies
  //   Works on the assetGroups set for the Class
  //
  //  Input:
  //      date - the most recent UTC date for which to calculate the
  //
  //  Output (a number of firewall rules that represent in the assetGroups):
  //      {
  //          number:
  //          percentChange:
  //          message:  <optional human-readable message>
  //      }
  //
  // If there is no data for the day provided:
  // {
  //   "number": 0,
  //   "percentChange": 0
  // }
  //
  // NOTE: this does not fail if cannot get % change due to missing data, percentChange will be null
  calculateTotalFirewallRules(date = new Date(), secondDate, timeFrame = 'daily') {
    logger.error('Base implementation for NetworkDashboard called for calculateTotalFirewallRules called.  This' +
      ' should have been overridden by implementation');
  }

  // ----------------------------------
  // calculateTotalSecurityGroups
  //   Works on the assetGroups set for the Class
  //
  //  Input:
  //      date - the most recent UTC date for which to calculate the
  //
  //  Output (a number of policies that represent in the assetGroups):
  //      {
  //          number:
  //          percentChange:
  //          message:  <optional human-readable message>
  //      }
  //
  //   If there is no data for the day provided:
  // {
  //   "number": 0,
  //   "percentChange": 0
  // }
  //
  // NOTE: this does not fail if cannot get % change due to missing data, percentChange will be null
  calculateTotalSecurityGroups(date = new Date(), secondDate, timeFrame = 'daily') {
    logger.error('Base implementation for NetworkDashboard called for calculateTotalSecurityGroups called.  This' +
      ' should have been overridden by implementation');
  }
}

module.exports = NetworkDashboardInterface;
