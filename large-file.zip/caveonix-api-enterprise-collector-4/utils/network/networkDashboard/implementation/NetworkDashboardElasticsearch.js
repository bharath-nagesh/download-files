const NetworkDashboardInterface = require('../NetworkDashboardInterface');
const elasticsearch = require('elasticsearch');
const config = require('../../../../configure').get();
const NetworkUtilsFactory = require('../../networkUtils/NetworkUtilsFactory');
const NetworkUtils = NetworkUtilsFactory.createNetworkUtils();
var url = require('url');
const convert = require('convert-units');
const logger = require('../../../logger.js').logger.child({ });

// -- Root name for flow index (i.e. caveonetwork-0-1-1-<ROOT NAME>-2019--8-21)
let NON_AGGREGATE_INDEX_ROOT_NAME = 'flows' // This is a non-aggregated daily flow index, every flow delivered has its own doc
let AGGREGATE_INDEX_ROOT_NAME = 'aggregate_flows' // this is an aggregated daily flow index, every 5-tuple has its own doc
let TARGET_FLOW_INDEX_ROOT_NAME = NON_AGGREGATE_INDEX_ROOT_NAME

class NetworkDashboardElasticsearch extends NetworkDashboardInterface {
  // ============================================================================================
  // Creation function - called once, and only once, immediately after constructor.
  // ============================================================================================

  // params must include
  //   Input:
  //      assetGroups -
  //                      [
  //                          {
  //                              containerName: <name Of container>,
  //                              members:    {
  //                                              options:{
  //                                                  location:   <location id from which the assets come>,
  //                                                  serviceProvider: <service provider id from which the assets come>,
  //                                                  organization:    <organization id from which the assets come>
  //                                                  },
  //                                             objects: [
  //                                                        uuid: <instance uuid of asset>,
  //                                                        ...
  //                                                      ]
  //                                          }
  //                          },
  //                          ...
  //                      ]
  //      hostPort -- ElasticSearch host:port address (e.g.  localhost:9200)
  //      log -- (optional) the log level for elasticSearch client library
  constructor(assetGroups, hostPort,userName,userPass, token = null, authToken = null, log = 'warning') {
    super(assetGroups, hostPort,userName,userPass, token, authToken, log);
    logger.silly('Enter NetworkDashboard constructor');
    var q = url.parse(hostPort, true);
    this.hostPort = hostPort;
    this.assetGroups = assetGroups;
    if (config.forensics_enabled == true) {
      this.client = new elasticsearch.Client({
        host:{
          protocol: q.protocol,
          host: q.host.split(':')[0],
          port: q.port,
          headers: {
            RiskForesight: token,
            Authorization: authToken
          }
        },
        log: log
      });
    }else{
      this.client = new elasticsearch.Client({
        host: q.protocol+'//'+userName+':'+userPass+'@'+q.host+'/',
        log: log
      });
    }
    if (this.client == null) {
      logger.error('Unable to create elasticsearch client.');
    }
    this._resetIndexAndBatches();

    logger.silly('Exit NetworkDashboard constructor');
  }

  // ============================================================================================
  // PUBLIC functions - available from instantiated object.  The 'this' variable is available
  // ============================================================================================

  // ----------------------------------
  // getMostRecentDateWithData
  //   Will provide the most recent date that has dashboard data
  getMostRecentDateWithData(target = 'policies', organization = '*', location = '*', serviceProvider = '*') {
    if (target === 'policies') {
      return NetworkUtils.getMostRecentMultipleDatesWithData(this.client, 'secpolicies', organization, location, serviceProvider);
    } else if ((target == NON_AGGREGATE_INDEX_ROOT_NAME) || (target == TARGET_FLOW_INDEX_ROOT_NAME)) {
      return NetworkUtils.getMostRecentMultipleDatesWithData(this.client, TARGET_FLOW_INDEX_ROOT_NAME, organization, location, serviceProvider);
    } else {
      return Promise.reject('Unknown target sent');
    }

  }

  // ----------------------------------
  // calculateTotalTrafficFlow
  //   Works on the assetGroups set for the Class
  //
  //  Input:
  //      date - a Date object for the date to calculate total traffic for
  //
  //  Output (a number of bytes that represent all traffic flowing to/from assets in the assetGroups):
  //      {
  //          number:
  //          percentChange:
  //          message:  <optional human-readable message>
  //      }
  //
  //   If there is no data for the provided date then the output is:
  // {
  //   "number": 0,
  //   "percentChange": 0
  // }
  //
  // NOTE: this does not fail if cannot get % change due to missing data, percentChange will be null

  calculateTotalTrafficFlow(date = new Date(), secondDate, timeFrame = 'daily') {
    logger.silly({ assetGroups: this.assetGroups }, 'Enter calculateTotalTrafficFlow');

    return new Promise((resolve, reject) => {
      if (date == null) {
        logger.silly('No date provided.');
        reject('No date provided.');
      }
      if (timeFrame != 'daily') {
        logger.silly({ timeFrame }, 'timeFrame provided is not supported');
        reject('timeFrame provided is not supported');
      }

      // --- if assetGroups is empty then return empty list
      if (this.assetGroups != null && this.assetGroups.length <= 0) {
        resolve({ number: 0, unit: 'GB', percentChange: 0 });
      } else {
        if(!secondDate){
          secondDate = 0;
        }
        let secondDateTotalBytes = 0;
        let firstDateTotalBytes = 0;
        // secondDate.setDate(secondDate.getDate() - 1);
        logger.silly({ date, secondDate }, 'first and second date');

        let allUuids = this._collectAllUuids();
        logger.silly(allUuids, 'In calculateTotalTrafficFlow, gathered all uuids');
        this._calculateTotalTrafficBytesForOneDate(date, allUuids)
          .then(firstDateResult => {
            logger.silly({ date, firstDateResult }, 'Success getting total bytes for first date');
            firstDateTotalBytes = firstDateResult;
            this._calculateTotalTrafficBytesForOneDate(secondDate, allUuids)
              .then(secondDateResult => {
                secondDateTotalBytes = secondDateResult;
                logger.silly(
                  {
                    secondDate,
                    secondDateTotalBytes: secondDateTotalBytes
                  },
                  'Success getting total bytes for second date'
                );
                let change = 0;
                change = NetworkUtils.calculatePercentageChange(firstDateTotalBytes, secondDateTotalBytes);
                let result = convert(firstDateTotalBytes).from('b').toBest()
                result.number = Math.round(result.val * 100)/100
                result.percentChange = change
                resolve(result);
              })
              .catch(error => {
                logger.silly({ error:error.message }, 'Error calculating value for previous date (for % change)');
                let result = {
                  number: firstDateTotalBytes,
                  percentChange: null,
                  message: 'Insufficient past data to calculate percent change.'
                };
                resolve(result);
              });
          })
          .catch(error => {
            logger.silly({ error:error.message }, 'Error calculating value for target date');
            reject(error);
          });
      }
    });
  }

  // ----------------------------------
  // calculateTotalPolicies
  //   Works on the assetGroups set for the Class
  //
  //  Input:
  //      date - the most recent UTC date for which to calculate the
  //
  //  Output (a number of policies that represent in the assetGroups):
  //      {
  //          number:
  //          percentChange:
  //          message:  <optional human-readable message>
  //      }
  //
  // If there is no data for the day provided:
  // {
  //   "number": 0,
  //   "percentChange": 0
  // }
  //
  // NOTE: this does not fail if cannot get % change due to missing data, percentChange will be null

  calculateTotalPolicies(date = new Date(), secondDate, timeFrame = 'daily') {
    logger.silly({ assetGroups: this.assetGroups }, 'Enter calculateTotalPolicies');

    return new Promise((resolve, reject) => {
      if (date == null) {
        logger.silly('No date provided.');
        reject('No date provided.');
      }
      if (timeFrame != 'daily') {
        logger.silly({ timeFrame }, 'timeFrame provided is not supported');
        reject('timeFrame provided is not supported');
      }

      // --- if assetGroups is empty then return empty list
      if (this.assetGroups != null && this.assetGroups.length <= 0) {
        resolve({ number: 0, percentChange: 0 });
      } else {
        if(!secondDate){
          secondDate = 0;
        }
        let secondDateTotalSecurityPolicies = 0;
        let firstDateTotalSecurityPolicies = 0;
        // secondDate.setDate(secondDate.getDate() - 1);
        logger.silly({ date, secondDate }, 'first and second date');

        this._calculateTotalSecurityPoliciesForOneDate(date)
          .then(firstDateResult => {
            logger.silly({ date, firstDateResult }, 'Success getting total policies for first date');
            firstDateTotalSecurityPolicies = firstDateResult;
            this._calculateTotalSecurityPoliciesForOneDate(secondDate)
              .then(secondDateResult => {
                secondDateTotalSecurityPolicies = secondDateResult;
                logger.silly(
                  {
                    secondDate,
                    secondDateTotalBytes: secondDateTotalSecurityPolicies
                  },
                  'Success getting total policies for second date'
                );
                let change = 0;
                change = NetworkUtils.calculatePercentageChange(firstDateTotalSecurityPolicies, secondDateTotalSecurityPolicies);
                let result = { number: firstDateTotalSecurityPolicies, percentChange: change };
                resolve(result);
              })
              .catch(error => {
                logger.silly({ error:error.message }, 'Error calculating value for previous date (for % change)');
                let result = {
                  number: firstDateTotalSecurityPolicies,
                  percentChange: null,
                  message: 'Insufficient past data to calculate percent change.'
                };
                resolve(result);
              });
          })
          .catch(error => {
            logger.silly({ error:error.message }, 'Error calculating value for target date');
            reject(error);
          });
      }
    });
  }


  // ----------------------------------
  // calculateTotalPolicies
  //   Works on the assetGroups set for the Class
  //
  //  Input:
  //      date - the most recent UTC date for which to calculate the
  //
  //  Output (a number of firewall rules that represent in the assetGroups):
  //      {
  //          number:
  //          percentChange:
  //          message:  <optional human-readable message>
  //      }
  //
  // If there is no data for the day provided:
  // {
  //   "number": 0,
  //   "percentChange": 0
  // }
  //
  // NOTE: this does not fail if cannot get % change due to missing data, percentChange will be null

  calculateTotalFirewallRules(date = new Date(), secondDate, timeFrame = 'daily') {
    logger.silly({ assetGroups: this.assetGroups }, 'Enter calculateTotalFirewallRules');

    return new Promise((resolve, reject) => {
      if (date == null) {
        logger.silly('No date provided.');
        reject('No date provided.');
      }
      if (timeFrame != 'daily') {
        logger.silly({ timeFrame }, 'timeFrame provided is not supported');
        reject('timeFrame provided is not supported');
      }

      // --- if assetGroups is empty then return empty list
      if (this.assetGroups != null && this.assetGroups.length <= 0) {
        resolve({ number: 0, percentChange: 0 });
      } else {
        if(!secondDate){
          secondDate = 0;
        }
        let secondDateTotalFirewallRules = 0;
        let firstDateTotalFirewallRules = 0;
        // secondDate.setDate(secondDate.getDate() - 1);
        logger.silly({ date, secondDate }, 'first and second date');

        this._calculateTotalFirewallRulesForOneDate(date)
          .then(firstDateResult => {
            logger.silly({ date, firstDateResult }, 'Success getting total firewall rules for first date');
            firstDateTotalFirewallRules = firstDateResult;
            this._calculateTotalFirewallRulesForOneDate(secondDate)
              .then(secondDateResult => {
                secondDateTotalFirewallRules = secondDateResult;
                logger.silly(
                  {
                    secondDate,
                    secondDateTotalBytes: secondDateTotalFirewallRules
                  },
                  'Success getting total firewall rules for second date'
                );
                let change = 0;
                change = NetworkUtils.calculatePercentageChange(firstDateTotalFirewallRules, secondDateTotalFirewallRules);
                let result = { number: firstDateTotalFirewallRules, percentChange: change };
                resolve(result);
              })
              .catch(error => {
                logger.silly({ error:error.message }, 'Error calculating value for previous date (for % change)');
                let result = {
                  number: firstDateTotalFirewallRules,
                  percentChange: null,
                  message: 'Insufficient past data to calculate percent change.'
                };
                resolve(result);
              });
          })
          .catch(error => {
            logger.silly({ error:error.message }, 'Error calculating value for target date');
            reject(error);
          });
      }
    });
  }

  // ----------------------------------
  // calculateTotalSecurityGroups
  //   Works on the assetGroups set for the Class
  //
  //  Input:
  //      date - the most recent UTC date for which to calculate the
  //
  //  Output (a number of policies that represent in the assetGroups):
  //      {
  //          number:
  //          percentChange:
  //          message:  <optional human-readable message>
  //      }
  //
  //   If there is no data for the day provided:
  // {
  //   "number": 0,
  //   "percentChange": 0
  // }
  //
  // NOTE: this does not fail if cannot get % change due to missing data, percentChange will be null

  calculateTotalSecurityGroups(date = new Date(), secondDate, timeFrame = 'daily') {
    logger.silly({ assetGroups: this.assetGroups }, 'Enter calculateTotalSecurityGroups');

    return new Promise((resolve, reject) => {
      if (date == null) {
        logger.silly('No date provided.');
        reject('No date provided.');
      }
      if (timeFrame != 'daily') {
        logger.silly({ timeFrame }, 'timeFrame provided is not supported');
        reject('timeFrame provided is not supported');
      }

      // --- if assetGroups is empty then return empty list
      if (this.assetGroups != null && this.assetGroups.length <= 0) {
        resolve({ number: 0, percentChange: 0 });
      } else {
        if(!secondDate){
          secondDate = 0;
        }
        let secondDateTotalSecurityGroups = 0;
        let firstDateTotalSecurityGroups = 0;
        // secondDate.setDate(secondDate.getDate() - 1);
        logger.silly({ date, secondDate }, 'first and second date');

        this._calculateTotalSecurityGroupsForOneDate(date)
          .then(firstDateResult => {
            logger.silly({ date, firstDateResult }, 'Success getting total security groups for first date');
            firstDateTotalSecurityGroups = firstDateResult;
            this._calculateTotalSecurityGroupsForOneDate(secondDate)
              .then(secondDateResult => {
                secondDateTotalSecurityGroups = secondDateResult;
                logger.silly(
                  {
                    secondDate,
                    secondDateTotalBytes: secondDateTotalSecurityGroups
                  },
                  'Success getting total security groups for second date'
                );
                let change = 0;
                change = NetworkUtils.calculatePercentageChange(firstDateTotalSecurityGroups, secondDateTotalSecurityGroups);
                let result = { number: firstDateTotalSecurityGroups, percentChange: change };
                resolve(result);
              })
              .catch(error => {
                logger.silly({ error:error.message }, 'Error calculating value for previous date (for % change)');
                let result = {
                  number: firstDateTotalSecurityGroups,
                  percentChange: null,
                  message: 'Insufficient past data to calculate percent change.'
                };
                resolve(result);
              });
          })
          .catch(error => {
            logger.silly({ error:error.message }, 'Error calculating value for target date');
            reject(error);
          });
      }
    });
  }

  // ============================================================================================
  // STATIC functions - available directly from Class, no object needed, the this is not available
  // ============================================================================================


  // ============================================================================================
  // PRIVATE functions - shall begin with '_', do NOT access outside this class.
  // ============================================================================================


  // ---------------------------------
  //  Goes through all the assetGroup members and collecs all the UUIDs of each member into a single list
  _collectAllUuids() {
    logger.silly('Enter _collectAllUuids');
    if (this.allUuids == null) {
      this.allUuids = [];
      for (let i = 0; i < this.assetGroups.length; i++) {
        if ('members' in this.assetGroups[i]) {
          if ('objects' in this.assetGroups[i].members) {
            let memberObjects = this.assetGroups[i].members.objects;
            if (memberObjects != null) {
              this.allUuids = this.allUuids.concat(memberObjects);
            }
          }
        }
      }
    }
    return this.allUuids;
  }

  // -------------------------------------------------
  // _calculateTotalTrafficBytesForOneDate
  //   Calculates the total bytes for a specific date
  //
  //  Input:
  //      date - a Date object for which yyyy-mm-dd is to be returned
  //
  //  Output (a string representing the Date object):
  //      <integer> - total bytes transferred on that date
  //
  async _calculateTotalTrafficBytesForOneDate(date, uuids) {
    try {
      logger.silly({ date, uuids, assetGroups: this.assetGroups }, 'Enter _calculateTotalTrafficBytesForOneDate');

      let yyyymmdd = null;
      if (date == null) {
        logger.silly('No date provided.');
        throw 'No date provided.';
      }

      yyyymmdd = NetworkUtils.getYYYY_MM_DD(date);

      await this._calculateIndexesAndBatches(this.client, yyyymmdd, TARGET_FLOW_INDEX_ROOT_NAME, this.indexAndBatchesForFlows)

      let result = await NetworkUtils.retrieveTotalTrafficForIndexesAndBatches(this.client,
          this.indexAndBatchesForFlows[yyyymmdd].collectionBatches,
          this.indexAndBatchesForFlows[yyyymmdd].indexes, uuids);

      return result.totalBytes;
    } catch(error) {
      logger.error({error: error.message, stack: error.stack}, 'Error in _calculateTotalTrafficBytesForOneDate');
      throw error;
    }
  }

  // -------------------------------------------------
  // _calculateTotalSecurityPoliciesForOneDate
  //   Calculates the total policies for a specific date
  //
  //  Input:
  //      date - a Date object for which yyyy-mm-dd is to be returned
  //
  //  Output (a string representing the Date object):
  //      <integer> - total security policies on that date
  //
  async _calculateTotalSecurityPoliciesForOneDate(date) {
    try {
      logger.silly({date, assetGroups: this.assetGroups}, 'Enter _calculateTotalSecurityPoliciesForOneDate');

      let yyyymmdd = null;
      if (date == null) {
        logger.silly('No date provided.');
        throw 'No date provided.';
      }

      yyyymmdd = NetworkUtils.getYYYY_MM_DD(date);
      await this._calculateIndexesAndBatches(this.client, yyyymmdd, 'secpolicies', this.indexAndBatchesForPolicies)

      let policyCount = 0
      if (!this.indexAndBatchesForPolicies || !this.indexAndBatchesForPolicies[yyyymmdd]) {
        logger.warn({date}, 'No indexes or batches for this date, returning zero policyCount in _calculateTotalSecurityPoliciesForOneDate')
      } else {
        let body = await NetworkUtils.countRecords(
          this.client,
          this.indexAndBatchesForPolicies[yyyymmdd].indexes,
          this.indexAndBatchesForPolicies[yyyymmdd].collectionBatches,
          'name.keyword'
        );

        logger.silly({date, body}, 'Success in _calculateTotalSecurityPoliciesForOneDate');
        // TODO: parse out the count of security policies
        policyCount = body;
      }
      return policyCount;

    } catch (error) {
      logger.silly({ date, error }, 'Error in _calculateTotalSecurityPoliciesForOneDate during elasticsearch search');
      throw error;
    }

  }



  // -------------------------------------------------
  // _calculateTotalFirewallRulesForOneDate
  //   Calculates the total firewall rules for a specific date
  //
  //  Input:
  //      date - a Date object for which yyyy-mm-dd is to be returned
  //
  //  Output (a string representing the Date object):
  //      <integer> - total security firewall rules on that date
  //
  async _calculateTotalFirewallRulesForOneDate(date) {
    try {
      logger.silly({date, assetGroups: this.assetGroups}, 'Enter _calculateTotalFirewallRulesForOneDate');

      let yyyymmdd = null;
      if (date == null) {
        logger.silly('No date provided.');
        throw 'No date provided.';
      }
      yyyymmdd = NetworkUtils.getYYYY_MM_DD(date);
      await this._calculateIndexesAndBatches(this.client, yyyymmdd, 'dfwrules', this.indexAndBatchesForDfwRules)
      let firewallRuleCount = 0
      if (!this.indexAndBatchesForDfwRules || !this.indexAndBatchesForDfwRules[yyyymmdd]) {
        logger.warn({date}, 'No indexes or batches for this date, returning zero firewallRuleCount in _calculateTotalFirewallRulesForOneDate')
      } else {
        let body = await NetworkUtils.countRecords(
          this.client,
          this.indexAndBatchesForDfwRules[yyyymmdd].indexes,
          this.indexAndBatchesForDfwRules[yyyymmdd].collectionBatches,
          'id'
        );

        logger.silly({date, body}, 'Success in _calculateTotalFirewallRulesForOneDate');
        firewallRuleCount = body;
      }
      return firewallRuleCount;
    } catch (error) {
      logger.silly({ date, error }, 'Error in _calculateTotalFirewallRulesForOneDate during elasticsearch search');
      throw error;
    }

  }


  // -------------------------------------------------
  // _calculateTotalSecurityGroupsForOneDate
  //   Calculates the total security groups for a specific date
  //
  //  Input:
  //      date - a Date object for which yyyy-mm-dd is to be returned
  //
  //  Output (a string representing the Date object):
  //      <integer> - total security groups on that date
  //
 async  _calculateTotalSecurityGroupsForOneDate(date) {
    try {
      logger.silly({date, assetGroups: this.assetGroups}, 'Enter _calculateTotalSecurityGroupsForOneDate');

      let yyyymmdd = null;
      if (date == null) {
        logger.silly('No date provided.');
        throw 'No date provided.';
      }

      yyyymmdd = NetworkUtils.getYYYY_MM_DD(date);
      await this._calculateIndexesAndBatches(this.client, yyyymmdd, 'secgroups', this.indexAndBatchesForSecurityGroups)
      let groupCount = 0
      if (!this.indexAndBatchesForSecurityGroups || !this.indexAndBatchesForSecurityGroups[yyyymmdd]) {
        logger.warn({date}, 'No indexes or batches for this date, returning zero groupCount in _calculateTotalSecurityGroupsForOneDate')
      } else {
        let body = await NetworkUtils.countRecords(
          this.client,
          this.indexAndBatchesForSecurityGroups[yyyymmdd].indexes,
          this.indexAndBatchesForSecurityGroups[yyyymmdd].collectionBatches,
          'objectId'
        );

        logger.silly({date, body}, 'Success in _calculateTotalSecurityGroupsForOneDate');
        groupCount = body;
      }
      return groupCount;
    } catch(error) {
      logger.silly({ date, error }, 'Error in _calculateTotalSecurityGroupsForOneDate during elasticsearch search');
      throw error;
    }
  }

  // -------------------------------------------------
  // _calculateIndexesAndBatches
  //   Creates the this.curCollectionBatches variable
  //
  //  Input:
  //      esClient - an ElasticSearch Cleint
  //      yyyymmdd - the date to collect indexes and collection batches for
  //      type - the index type to collect indexes and collection batches for (secpolicies, flows, dfwrules, etc)
  //      indexAndBatches -
  //
  //  Output (a number of policies that represent in the assetGroups):
  //      <none>, but this.indexesAndBatchs[yyyymmdd].collectionBatches and .indexes will be set up for use
  //
  async _calculateIndexesAndBatches(esClient, yyyymmdd, type, indexAndBatches) {
    logger.silly({ yyyymmdd, type, indexAndBatches: indexAndBatches }, 'Enter _calculateIndexesAndBatches');

    try {
      let curCollectionBatches = null;
      let curIndexes = null;
      let curIndexAndBatches = indexAndBatches[yyyymmdd];
      logger.silly({yyyymmdd, curIndexAndBatches}, 'determining the available index and batches for date');
      if (curIndexAndBatches != null) {
        curCollectionBatches = curIndexAndBatches.collectionBatches;
        curIndexes = curIndexAndBatches.indexes;
      }
      if (curCollectionBatches == null) {
        curCollectionBatches = [];
        if (curIndexes == null) {
          curIndexes = [];
          curIndexes = await Promise.all(this.assetGroups.map(async (assetGroup) => {
            let location = assetGroup.members.options.location;
            let serviceProvider = assetGroup.members.options.serviceProvider;
            let organization = assetGroup.members.options.organization;
            if (type && type.includes('flow')) {
              return NetworkUtils.selectFlowIndexRootName(esClient, organization, location, serviceProvider, yyyymmdd)
                .then((type) => {
                  return `caveonetwork-${organization}-${location}-${serviceProvider}-${type}-${yyyymmdd}`
                })
            }
            let index = `caveonetwork-${organization}-${location}-${serviceProvider}-${type}-${yyyymmdd}`;
            return index
          }))
        }
        logger.silly({curIndexes}, 'In _calculateIndexesAndBatches, finding collectionBatches for these indexes');
        await NetworkUtils.getMostRecentCollectionBatchForIndexList(this.client, curIndexes, curCollectionBatches)
        logger.silly({curCollectionBatches, curIndexes}, 'Success in _collectAllCollectionBatches');

        let indexAndBatchesValue = {
          collectionBatches: curCollectionBatches,
          indexes: curIndexes
        };
        indexAndBatches[yyyymmdd] = indexAndBatchesValue;
        return
      } else {
        return
      }
    } catch (e) {
      logger.silly({e}, 'Failed in _calculateCollectionBatches')
      throw e
    }
  }

  // -------------------------------------------------------------------
  // _resetNetworkFlowData
  //   Resets to empty all the index and collectionBatches.  Usually done at init time as well as when
  //      the assetGroups definition changes.
  //
  //  Input:
  //      <none>
  //
  //  Output:
  //      <none>
  //
  _resetIndexAndBatches() {
    this.indexAndBatchesForFlows = {};
    this.indexAndBatchesForPolicies = {};
    this.indexAndBatchesForSecurityGroups = {};
    this.indexAndBatchesForDfwRules = {};
  }
}

module.exports = NetworkDashboardElasticsearch;
