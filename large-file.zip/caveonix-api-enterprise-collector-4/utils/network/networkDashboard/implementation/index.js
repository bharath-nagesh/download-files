const elasticsearch = require('./NetworkDashboardElasticsearch');
module.exports = { elasticsearch };
