const logger = require('../../logger.js').logger.child({});
const networkHelper = require('../common/NetworkHelper');
const implementation = require('./implementation');
class NetworkFlowsFactory {
  //
  // Call this method to create a NetworkFlows object of the correct network type.  All NetworkFlowss SHALL conform to the interface defined by NetworkFlowsInterface
  static createNetworkFlows(assetGroups, hostPort, userName, userPass, cache = null, refresh = false, token = null, authToken = null, log = 'warning', networkStoreType = null) {
    if (networkStoreType === null) {
      networkStoreType = networkHelper.getNetworkStoreTypeFromConfig();
    }
    const ImplementationClass = implementation[networkStoreType];
    // if the network networkSourceType is missing from the network implementations then inform the user of their error
    if (!ImplementationClass) {
      logger.error({ type: networkStoreType }, 'Unsupported network data store for NetworkFlowsFactory, NetworkFlows object not created.');
      const error = new Error('Unsupported network data store for NetworkFlowsFactory, NetworkFlows object not created.');
      error.status = 404;
      throw error;
    }
    return new ImplementationClass(assetGroups, hostPort, userName, userPass, cache, refresh, token, authToken, log);
  }
}

module.exports = NetworkFlowsFactory;
