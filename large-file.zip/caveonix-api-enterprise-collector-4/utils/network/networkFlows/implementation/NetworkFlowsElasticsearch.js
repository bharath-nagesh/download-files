const crypto = require('crypto');
const elasticsearch = require('elasticsearch');
const NetworkFlowsInterface = require('../NetworkFlowsInterface');
const config = require('../../../../configure').get();
const AgentKeepAlive = require('agentkeepalive');
const url = require('url');
const convert = require('convert-units');
const AgentKeepAliveHTTPS = require('agentkeepalive').HttpsAgent;
const logger = require('../../../logger.js').logger.child({});
const NetworkUtilsFactory = require('../../networkUtils/NetworkUtilsFactory');
const NetworkUtils = NetworkUtilsFactory.createNetworkUtils();

// -- Root name for flow index (i.e. caveonetwork-0-1-1-<ROOT NAME>-2019--8-21)
const NON_AGGREGATE_INDEX_ROOT_NAME = 'flows'; // This is a non-aggregated daily flow index, every flow delivered has its own doc
const AGGREGATE_INDEX_ROOT_NAME = 'aggregate_flows'; // this is an aggregated daily flow index, every 5-tuple has its own doc
const AGG_SIZE_FOR_SOURCE_DEST = 10000;
const DEFAULT_AGGREGATION_PAGE_SIZE = 100;
const DEFAULT_MAX_OPEN_SCROLL_CONTEXT = 1500; // this is the max number of open search contexts allowed
const DEFAULT_ACTIVE_SCROLL_ID_RATE_LIMIT = 200; // the number of active scroll ids needs to be below this to begin another scroll
const DEFAULT_ACTIVE_SCROLL_ID_WAIT_BASE_MSEC=300; // the number of milliseconds to wait on each check to see if active scroll id count is less than limit - this wait occurs at least once before starting a new scroll
const DEFAULT_ACTIVE_SCROLL_ID_WAIT_JITTER_MAX_MSEC=250; // the max number of random milliseconds to add to base to cause each new scroll id to be created at slightly different time.
const DEFAULT_ACTIVE_SCROLL_ID_MAX_WAIT_LOOPS=10; // we will never wait longer than this many loops, avoids deadlock

const DEFAULT_FLOWS_OFFSET = 0; // when retrieving raw flows this is the default starting index returned
const DEFAULT_FLOWS_LIMIT = 10000; // when retrieving raw flows this is the default number of flow records returned

class NetworkFlowsElasticsearch extends NetworkFlowsInterface {
  // ============================================================================================
  // Creation function - called once, and only once, immediately after constructor.
  // ============================================================================================

  // params must include
  // NOTE: containerName MUST be unique within this list of assetGroups
  //   Input:
  //      assetGroups -
  //                      [
  //                          {
  //                              containerName: <name Of container>,
  //                              members:    {
  //                                              options:{
  //                                                  location:   <location id from which the assets come>,
  //                                                  serviceProvider: <service provider id from which the assets come>,
  //                                                  organization:    <organization id from which the assets come> or [<org id>, ...]
  //                                                  },
  //                                             objects: [
  //                                                        uuid: <instance uuid of asset>,
  //                                                        ...
  //                                                      ]
  //                                          }
  //                          },
  //                          ...
  //                      ]
  //      hostPort -- ElasticSearch host:port address (e.g.  localhost:9200)
  //      log -- (optional) the log level for elasticSearch client library
  //      cache -- (optional) an object that supports get and set.  If present then it will be used to store/retrieve the results of certain time-consuming calls
  //      refresh -- (optional)  if true then data will not be retrieved from cache, but instead will be recalculated.  if false, then retrieval from cache will be attempted
  constructor(assetGroups, hostPort, userName, userPass, cache = null, refresh = false, token = null, authToken = null, log = 'warning') {
    super(assetGroups, hostPort, userName, userPass, token, authToken, log);
    logger.silly('Enter NetworkFlows constructor');
    this.TARGET_FLOW_INDEX_ROOT_NAME = AGGREGATE_INDEX_ROOT_NAME; // This is the index to be targeted by the code
    this.USE_SERVICE_PORT = false;
    this.TARGET_PORT = 'destinationPort';
    this.cache = cache;
    this.refresh = refresh;
    const q = url.parse(hostPort, true);
    this.hostPort = hostPort;
    this.assetGroups = assetGroups;
    this.es_UserName = userName;
    this.es_UserPassword = userPass;
    this.timeout = (config.elastic_timeout_in_seconds * 1000) || 300000;
    this.scrollIdCount = 0;
    this.activeScrollIdRateLimit = config.active_scroll_id_rate_limit || DEFAULT_ACTIVE_SCROLL_ID_RATE_LIMIT;
    this.activeScrollIdWaitJitterMax = config.active_scroll_id_wait_jitter_max_msec || DEFAULT_ACTIVE_SCROLL_ID_WAIT_JITTER_MAX_MSEC;
    this.activeScrollIdWaitBase = config.active_scroll_id_wait_base_msec || DEFAULT_ACTIVE_SCROLL_ID_WAIT_BASE_MSEC;
    this.activeScrollIdMaxWaitLoops = config.active_scroll_id_max_wait_loops || DEFAULT_ACTIVE_SCROLL_ID_MAX_WAIT_LOOPS;
    if (config.forensics_enabled == true) {
      this.headers = {
        RiskForesight: token,
        Authorization: authToken.includes('Basic') ? authToken : `Basic ${authToken}`
      };
      this.client = new elasticsearch.Client({
        host: {
          protocol: q.protocol,
          host: q.host.split(':')[0],
          port: q.port,
          headers: this.headers
        },
        log: log,
        maxSockets: 100,
        requestTimeout: this.timeout,
        createNodeAgent: (connection, config) => {
          if (this.hostPort.indexOf('https:') >= 0) {
            config.protocol = 'https:';
            return new AgentKeepAliveHTTPS(connection.makeAgentConfig(config));
          } else {
            return new AgentKeepAlive(connection.makeAgentConfig(config));
          }
        }
      });
      this.client.rfHeaders = this.headers;
    } else {
      this.client = new elasticsearch.Client({
        host: q.protocol + '//' + userName + ':' + userPass + '@' + q.host + '/',
        log: log,
        maxSockets: 100,
        requestTimeout: 600000,
        createNodeAgent: (connection, config) => {
          if (this.hostPort.indexOf('https:') >= 0) {
            config.protocol = 'https:';
            return new AgentKeepAliveHTTPS(connection.makeAgentConfig(config));
          } else {
            return new AgentKeepAlive(connection.makeAgentConfig(config));
          }
        }
      });
    }

    // --- set cluster settings from defaults or config file
    const maxOpenScrollContext = (config.max_open_scroll_context) || DEFAULT_MAX_OPEN_SCROLL_CONTEXT;
    let clusterSettings = {};
    let clusterBody = {
      persistent: {"search.max_open_scroll_context": maxOpenScrollContext},
      transient: {"search.max_open_scroll_context": maxOpenScrollContext}
    };
    clusterSettings.body=clusterBody;
    this.client.cluster.putSettings(clusterSettings);

    if (this.client == null) {
      logger.error('Unable to create elasticsearch client.');
    }
    this._resetNetworkFlowData();

    // --- create a hash to describe the networkflow object - used for caching
    const stringOfUniqueValues = JSON.stringify(assetGroups) + hostPort;
    this.cacheKey = crypto.createHash('md5').update(stringOfUniqueValues).digest('hex');
    logger.info({cacheKey: this.cacheKey}, 'Creating NetworkFlow object and its unique hashkey root for caching');


    logger.silly('Exit NetworkFlows constructor');
  }

  // ============================================================================================
  // PUBLIC functions - available from instantiated object.  The 'this' variable is available
  // ============================================================================================

  // ----------------------------------
  // getMostRecentDateWithData
  //   Will provide the most recent date that has flows data
  getMostRecentDateWithData(organization = '*', location = '*', serviceProvider = '*') {
    return NetworkUtils.getMostRecentDateWithData(this.client, this.TARGET_FLOW_INDEX_ROOT_NAME, organization, location, serviceProvider);
  }

  // ----------------------------------
  // calculateRibbons
  //   Will provide statistics and a list of network ribbons between groups of assets.
  //
  //   Input:
  //      date -   The UTC date to begin searching for links.  Format:  YYYY-MM-DD
  //      timeFrame - The period of time over which to calculate links (it looks for links that occurred during the
  //                  time frame.   The time frame is from the startDate backwards in time.
  //
  //  Output (an object with a list of source groups and the ribbons from them to other groups):
  //  {
  //    totalBytes: <number of bytes transferred between the unique list of assets, not the containers.
  //                    This might be less than
  //                    totalBytesBetweenContainers if an asset exists in more than one container>
  //    totalBytesForContainers: <number of bytes sent between, within, to internet or external for all these containers,
  //                               may be larger than totalBytes because assets may be in more than one container>,
  //    intraBytes: <number of bytes sent between assets in the same containers>,
  //    interBytes: <number of bytes sent between assets in different containers>,
  //    internetBytes: <number of bytes sent from unique list of assets to internet>,
  //    internetForContainers: <number of bytes from assets in containers to internet, may be larger than internetBytes
  //                                 because assets may be in more than one container>
  //    externalBytes: <number of bytes sent from unique list of assets to an IP that is not container or internet>
  //    externalForContainers:  <number of bytes from assets in containers to an IP that is not container or internet,
  //                                    may be larger than externalBytes because assets may be in more than one container>
  //     containers:  [
  //                      {
  //                          containerName: <name of container>,
  //                          totalBytes: <number of bytes sent from this container>,
  //                          intraBytes: <number of bytes sent between assets within this container>,
  //                          interBytes: <number of bytes sent from this container to another container>,
  //                          internetBytes: <number of bytes sent from this container to internet>,
  //                          externalBytes: <number of bytes sent from this container that was not to another
  //                                              container and not to the internet>
  //                          ribbons:
  //                              [
  //                                  {
  //                                      destination:  <containerName>,
  //                                      bytes: <bytes from source container to this destination container>
  //                                  },
  //                                  ...
  //                                  {
  //                                      destination: INTERNET,
  //                                      bytes: <bytes from source container sent to internet
  //                                  },
  //                                  {
  //                                      destination: EXTERNAL,
  //                                      bytes: <bytes from source container sent to neither internet or another container>
  //                                  }
  //                              ]
  //                      },
  //                      ...
  //                      {
  //                          containerName: INTERNET,
  //                          <same as other containers (see above), but this is for traffic from Internet>
  //                      },
  //                      {
  //                          containerName: EXTERNAL,
  //                          <same as other containers (see above), but this is for traffic from External sources>
  //                      },
  //                ]
  // }
  //
  //
  //  If there is no data for the date provided the data structure above is returned with empty/0 values
  async getNetworkDataForAsset(orgId, vmId, date = null) {
    if (!date) date = await this.getMostRecentDateWithData(orgId);
    return this._flowsForVmListFromAggFlowsOnlyWithOrgIdAndDate(this.client, orgId, vmId, date);
  }

  async _flowsForVmListFromAggFlowsOnlyWithOrgIdAndDate(esClient, orgId, uuids, date = new Date(), from = 0, size = 1000) {
    logger.silly({ uuids }, 'Enter _flowsForVmList');
    if (date == null) {
      logger.silly('No date provided.');
      throw new Error('No date provided.');
    }
    const yyyymmdd = NetworkUtils.getYYYY_MM_DD(date, false);
    const oneIndex = `caveonetwork-${orgId}-*-*-aggregate_flows-${yyyymmdd}`;
    const indexes = [oneIndex];

    try {
      const body = await esClient
        .search({
          //headers:esClient.rfHeaders,
          index: indexes,
          from: from,
          size: size,
          ignoreUnavailable: true,
          body: {
            query: {
              bool: {
                filter: {
                  bool: {
                    should: [{ terms: { sourceUuid: uuids } }, { terms: { destinationUuid: uuids } }]
                  }
                }
              }
            }
          }
        });
      logger.silly({ indexes }, 'Success retrieving in _flowsForVmListFromAggFlowsOnly');
      return body.hits.hits;
    } catch (error) {
      logger.silly({ error: error.message }, 'Error in _flowsForVmListFromAggFlowsOnly');
      throw error;
    }
  }

  async calculateRibbons(date = new Date(), timeFrame = 'day') {
    logger.silly({ assetGroups: this.assetGroups }, 'Enter calculateRibbons');
    try {
      let yyyymmdd = null;
      if (date == null) {
        logger.silly('No date provided.');
        throw new Error('No date provided.');
      }
      if (timeFrame != 'day') {
        logger.silly({ timeFrame }, 'timeFrame provided is not supported');
        throw new Error('timeFrame provided is not supported');
      }


      // --- get the target date in yyyymmdd format
      yyyymmdd = NetworkUtils.getYYYY_MM_DD(date, false);
      
      // --- if assetGroups is empty then return empty list
      if (this.assetGroups != null && this.assetGroups.length <= 0) {
        const ribbonResult = {
          totalBytes: 0,
          totalBytesForContainers: 0,
          intraBytes: 0,
          interBytes: 0,
          internetBytes: 0,
          internetForContainers: 0,
          externalBytes: 0,
          externalForContainers: 0,
          blockedBytes: 0,
          allowedBytes: 0,
          portMap: {},
          containers: []
        };
        this.flowsList[yyyymmdd] = [];
        this.ribbonResults[yyyymmdd] = ribbonResult;
        return ribbonResult;
      }


      // --- make sure ribbonResults and flowsList is initialized
      if (this.ribbonResult == null) {
        this.ribbonResult = {};
      }
      if (this.flowsList == null) {
        this.flowsList = {};
      }
      if (this.flowsList[yyyymmdd] == null) {
        this.flowsList[yyyymmdd] = [];
      }

      // --- If this is not a refresh, then attempt to obtain data from cache
      let data = null;
      const cacheKeyWithDate = this.cacheKey+'@'+yyyymmdd;
      if ((this.cache !== null) && (!this.refresh)) {
        data = await this.cache.get(cacheKeyWithDate);
      }

      // --- if found in cache return the data
      if (data) {
        this.flowsList[yyyymmdd] = data.flowsList;
        this.ribbonResult[yyyymmdd] = data.ribbonResults;
        return this.ribbonResult[yyyymmdd];
      }

      // --- if not in cache then calculate ribbonsResult and flowsList
      // --- init variables needed for calculation
      const containers = this.assetGroups;
      const thePromises = [];
      const ribbonResult = {
        totalBytes: 0,
        totalBytesForContainers: 0,
        intraBytes: 0,
        interBytes: 0,
        internetBytes: 0,
        internetForContainers: 0,
        externalBytes: 0,
        externalForContainers: 0,
        blockedBytes: 0,
        allowedBytes: 0,
        portMap: {},
        containers: []
      };

      // --- determine the target indexes and collection batches
      const allIndexes = await this._getAllIndexes(yyyymmdd, this.TARGET_FLOW_INDEX_ROOT_NAME, this.indexAndBatchesForFlows);
      this.TARGET_PORT = await NetworkUtils.selectTargetPortField(this.client, allIndexes);
      const allCollectionBatches = await this._collectAllCollectionBatches(allIndexes);

      // --- determine the target vmids
      const uuids = this._collectAllUuids();

      // --- get the total traffic object
      const result = await NetworkUtils.retrieveTotalTrafficForIndexesAndBatches(this.client,
        allCollectionBatches, allIndexes, uuids);

      // --- get all the ribbons and flows between all containers and between containers and internet/external
      for (let i = 0; i < containers.length; i++) {
        thePromises.push(this._calculateRibbonsForOneContainer(yyyymmdd, containers[i], containers, ribbonResult.containers));
      }
      thePromises.push(this._calculateRibbonsForFlowType(yyyymmdd, containers, 'EXTERNAL', ribbonResult.containers));
      thePromises.push(this._calculateRibbonsForFlowType(yyyymmdd, containers, 'INTERNET', ribbonResult.containers));
      const byteTotalsForOneContainerCalls = await Promise.all(thePromises);

      // --- clean the flow list of duplicates
      const cleanFlowsList = this.flowsList[yyyymmdd].filter((arr, index, self) =>
          index === self.findIndex((t) => (
              t.asset === arr.asset &&
              t.container === arr.container &&
              t.securityPolicy === arr.securityPolicy &&
              t.ruleId === arr.ruleId &&
              t.ruleName === arr.ruleName &&
              t.sourceGroup === arr.sourceGroup &&
              t.sourcePort === arr.sourcePort &&
              t.destinationGroup === arr.destinationGroup &&
              t.destinationPort === arr.destinationPort &&
              t.source === arr.source &&
              t.destination === arr.destination &&
              t.action === arr.action
          )));
      this.flowsList[yyyymmdd] = cleanFlowsList;

      // --- calculate the total traffic statistics from each container
      const startingValue = {
        intra: 0,
        inter: 0,
        total: 0,
        totalBytesForContainers: 0,
        internet: 0,
        internetForContainers: 0,
        external: 0,
        externalForContainers: 0,
        allowed: 0,
        blocked: 0,
        portMap: {}
      };
      const byteTotals = byteTotalsForOneContainerCalls.reduce((prev, current) => {
        logger.silly({ prev, current }, 'Enter function to combine');
        const x = prev;
        if (current != null) {
          x.intra = prev.intra + current.intra;
          x.inter = prev.inter + current.inter;
          x.totalBytesForContainers = prev.totalBytesForContainers + current.total;
          x.internetForContainers = prev.internetForContainers + current.internet;
          x.externalForContainers = prev.externalForContainers + current.external;
          x.allowed = prev.allowed + current.allowed;
          x.blocked = prev.blocked + current.blocked;
          x.portMap = this._mergePortMaps(prev.portMap, current.portMap);
        }
        logger.silly({ x }, 'Exit function to combine');
        return x;
      }, startingValue);

      // --- create the final ribbonResult object to be sent back
      ribbonResult.totalBytes = result.totalBytes;
      ribbonResult.totalBytesForContainers = byteTotals.totalBytesForContainers;
      ribbonResult.intraBytes = byteTotals.intra;
      ribbonResult.interBytes = byteTotals.inter;
      ribbonResult.internetBytes = result.totalInternet;
      ribbonResult.internetForContainers = byteTotals.internetForContainers;
      ribbonResult.externalBytes = result.totalExternal;
      ribbonResult.externalForContainers = byteTotals.externalForContainers;
      ribbonResult.allowedBytes = byteTotals.allowed;
      ribbonResult.blockedBytes = byteTotals.blocked;
      ribbonResult.portMap = byteTotals.portMap;
      this.ribbonResults[yyyymmdd] = ribbonResult;

      // --- Update the cache with ribbons and flows for this date (we update regardless of whether this is a refresh or not)
      if (this.cache !== null) {
        const data = {};
        data.flowsList = this.flowsList[yyyymmdd];
        data.ribbonResults = this.ribbonResults[yyyymmdd];
        let cacheSetResult = await this.cache.set(cacheKeyWithDate, data, 1000 * 60 * 60 /* 1 hr */);
        logger.info({cacheSetResult, cacheKeyWithDate}, 'Result from setting cache for flows');
      }

      // --- return just the ribbons (not flows)
      return this.ribbonResults[yyyymmdd];

    } catch (error) {
      logger.error({ error: error.message, stack: error.stack }, 'Error while calculating ribbons and flows');
      throw error;
    }
  }

  // ----------------------------------
  // calculateTrafficOverTime
  //   Will provide a list of dayes and the incoming number of bytes and outgoing number of bytes.
  //
  //   Input:
  //      mostRecentDate -   The most recent UTC date for which to provide incoming/outgoing bytes.  Format:  YYYY-MM-DD
  //      aggregatePeriod - The length of time over which to aggregate the sums of incoming/outgoing bytes: daily,
  //                          weekly, monthly, quarterly, yearly
  //      numberOfAggregationPeriods -  How many aggregation periods to provide
  //
  //  Output (a list of links to draw between assetGroups):
  //      [
  //          {
  //           date: yyyy-mm-dd,
  //           dateAsEpochWithMilliseconds: <long int>
  //           incomingBytes: <number of incoming bytes>,
  //           outgoingBytes: <number of outgoing bytes>
  //          }
  //      ]
  //
  // For days that have no data there will be no entry.  For days that have data there will be an entry, it
  //   is possible that the values will be 0 for that day.  This typically means there was data but it
  //   is incomplete.
  //
  // NOTE: Not using CACHE
  // NOTE: NO CACHE
  async calculateTrafficOverTime(startDate = new Date(), timeFrame = 'day') {
    logger.silly('Enter calculateTrafficOverTimedate');
    if (startDate == null) {
      logger.silly('No startDate provided.');
      reject('No startDate provided.');
    }
    if (timeFrame != 'day') {
      logger.silly({ timeFrame }, 'timeFrame provided is not supported');
      reject('timeFrame provided is not supported');
    }

    // --- if assetGroups is empty then return empty list
    try {
      if (this.assetGroups != null && this.assetGroups.length <= 0) {
        return [];
      } else {
        const allUuids = this._collectAllUuids();
        const allIndexes = await this._getWildcardIndexes(startDate, this.TARGET_FLOW_INDEX_ROOT_NAME, 0);
        const allCollectionBatches = await this._collectAllCollectionBatches(allIndexes);

        const body = await this._trafficFlowOverTime(this.client, allIndexes, allCollectionBatches, allUuids, timeFrame);

        // TODO: parse this into result
        const finalResult = [];
        if ('aggregations' in body) {
          const buckets = body.aggregations.trafficOverTime.buckets;
          for (let i = 0; i < buckets.length; i++) {
            const newEntry = {};
            newEntry.date = buckets[i].key_as_string;
            newEntry.dateAsEpochWithMilliseconds = buckets[i].key;
            newEntry.incomingBytes = convert(buckets[i].incoming.value).from('B').to('KB');
            newEntry.incomingBytes = Math.round(newEntry.incomingBytes * 100) / 100;
            newEntry.outgoingBytes = convert(buckets[i].outgoing.value).from('B').to('KB');
            newEntry.outgoingBytes = Math.round(newEntry.outgoingBytes * 100) / 100;
            finalResult.push(newEntry);
          }
        }

        return finalResult;
      }
    } catch (error) {
      logger.silly({ error: error.message, stack: error.stack }, 'Error in calculateTrafficOverTime');
      throw error;
    }

  }

  // ----------------------------------
  // statisitics
  //   For the assets of the object, it calculates a list of statistics
  //
  //  Input:
  //      date -   The UTC date to begin calculation.  Format:  YYYY-MM-DD
  //      timeFrame - The period of time over which to calculate.   The time frame is from the date backwards in time.
  //
  //  Output (a json object with a set of statistic values):
  //      {
  //          totalTraffic: <number of bytes transferred>,
  //          intraBytes:  <number of bytes between assets within groups>,
  //          intraPercentage:  <percentage of totalTraffic that is intraGroup>,
  //          interBytes:  <number of bytes between assets in different groups>,
  //          interPercentage:  <percentage of totalTraffic that is interGroup>,
  //          externalBytes:  <number of bytes between assets and external entities>,
  //          exeternalPercentage:  <percentage of totalTraffice that is external>,
  //          internetBytes:  <number of bytes between assets and internet entities>,
  //          internetPercentage:  <percentage of totalTraffice that is internet>,
  //          totalFlows:  <number of flows>,
  //          totalFlowBytes:  <number of bytes for totalFlows>
  //      }
  //
  //  The output if there is no data for the day provided there will be zeros (0) for the values.
  // NOTE: USING CACHE
  // NOTE: CACHE
  statistics(startDate = new Date(), timeFrame = 'day') {
    logger.silly('Enter statistics');

    return new Promise((resolve, reject) => {
      if (startDate == null) {
        logger.silly('No startDate provided.');
        reject('No startDate provided.');
      }
      if (timeFrame != 'day') {
        logger.silly({ timeFrame }, 'timeFrame provided is not supported');
        reject('timeFrame provided is not supported');
      }
      // --- if assetGroups is empty then return empty list
      if (this.assetGroups != null && this.assetGroups.length <= 0) {
        const retResult = {};
        retResult.totalFlows = convert(0).from('B').toBest();
        retResult.totalFlows.number = retResult.totalFlows.val;
        retResult.totalFlowsPercentage = 0;
        retResult.totalTraffic = convert(0).from('B').toBest();
        retResult.totalTraffic.number = retResult.totalTraffic.val;
        retResult.totalTrafficPercentage = 0;
        retResult.intraBytes = convert(0).from('B').toBest();
        retResult.intraBytes.number = retResult.intraBytes.val;
        retResult.intraPercentage = 0;
        retResult.interBytes = convert(0).from('B').toBest();
        retResult.interBytes.number = retResult.interBytes.val;
        retResult.interPercentage = 0;
        retResult.externalBytes = convert(0).from('B').toBest();
        retResult.externalBytes.number = retResult.externalBytes.val;
        retResult.externalPercentage = 0;
        retResult.internetBytes = convert(0).from('B').toBest();
        retResult.internetBytes.number = retResult.internetBytes.val;
        retResult.internetPercentage = 0;
        resolve(retResult);
      } else {
        const prevDate = new Date(startDate.valueOf() - 1000 * 3600 * 24); // work around bug in Date, subtracting 1 day does not work in some corner cases, using 24 hours does work
        logger.silly({ prevDate, startDate }, 'checking prevDate');

        const yyyymmdd = NetworkUtils.getYYYY_MM_DD(startDate);
        const yyyymmddPrev = NetworkUtils.getYYYY_MM_DD(prevDate);
        const datePromises = [];

        if (this.ribbonResults[yyyymmdd] == null) {
          datePromises[0] = this.calculateRibbons(startDate);
        } else {
          logger.info('CACHE!!!!!!!');
          datePromises[0] = Promise.resolve();
        }

        if (this.ribbonResults[yyyymmddPrev] == null) {
          datePromises[1] = this.calculateRibbons(prevDate);
        } else {
          logger.info('CACHE PREV!!!!!!!');
          datePromises[1] = Promise.resolve();
        }

        datePromises[2] = this._getTotalFlows(startDate);
        datePromises[3] = this._getTotalFlows(prevDate);

        logger.silly('About to wait for date promises');
        const retResult = {};

        Promise.all(datePromises)
          .then(results => {
            logger.silly({ results }, 'In statistics, datePromises completed');
            const currentRibbonResults = this.ribbonResults[yyyymmdd];
            const previousRibbonResults = this.ribbonResults[yyyymmddPrev];
            let currentTotalFlows = 0;
            let previousTotalFlows = 0;
            for (let i = 0; i < results.length; i++) {
              const oneResult = results[i];

              if (oneResult && 'totalFlowCount' in oneResult) {
                if (oneResult.yyyymmdd === yyyymmdd) {
                  currentTotalFlows = oneResult.totalFlowCount;
                } else if (oneResult.yyyymmdd === yyyymmddPrev) {
                  previousTotalFlows = oneResult.totalFlowCount;
                } else {
                  logger.warn({ yyyymmdd: oneResult.yyyymmdd }, 'Unrecognized yyyymmdd while parsing total flows');
                }
              }
            }

            logger.silly({
              currentRibbonResults,
              previousRibbonResults
            }, 'In statistics have current and prev results');
            retResult.totalFlows = { number: currentTotalFlows, unit: 'flows' };
            retResult.totalFlowsPercentage = NetworkUtils.calculatePercentageChange(currentTotalFlows, previousTotalFlows);
            logger.silly({ currentTotalFlows, previousTotalFlows }, 'total flows');
            retResult.totalTraffic = convert(currentRibbonResults.totalBytes).from('B').toBest();
            retResult.totalTraffic.number = Math.round(retResult.totalTraffic.val * 100) / 100;
            retResult.totalTrafficPercentage = NetworkUtils.calculatePercentageChange(currentRibbonResults.totalBytes, previousRibbonResults.totalBytes);
            logger.silly({
              cur: currentRibbonResults.totalBytes,
              prev: previousRibbonResults.totalBytes
            }, 'total bytes');
            retResult.intraBytes = convert(currentRibbonResults.intraBytes).from('B').toBest();
            retResult.intraBytes.number = Math.round(retResult.intraBytes.val * 100) / 100;

            logger.silly({ cur: currentRibbonResults.intraBytes, prev: previousRibbonResults.intraBytes }, 'intra');
            retResult.intraPercentage = NetworkUtils.calculatePercentageChange(currentRibbonResults.intraBytes, previousRibbonResults.intraBytes);
            retResult.interBytes = convert(currentRibbonResults.interBytes).from('B').toBest();
            retResult.interBytes.number = Math.round(retResult.interBytes.val * 100) / 100;
            logger.silly({ cur: currentRibbonResults.interBytes, prev: previousRibbonResults.interBytes }, 'inter');
            retResult.interPercentage = NetworkUtils.calculatePercentageChange(currentRibbonResults.interBytes, previousRibbonResults.interBytes);
            retResult.externalBytes = convert(currentRibbonResults.externalBytes).from('B').toBest();
            retResult.externalBytes.number = Math.round(retResult.externalBytes.val * 100) / 100;
            logger.silly(
              {
                cur: currentRibbonResults.externalBytes,
                prev: previousRibbonResults.externalBytes
              },
              'external'
            );
            retResult.externalPercentage = NetworkUtils.calculatePercentageChange(currentRibbonResults.externalBytes, previousRibbonResults.externalBytes);
            retResult.internetBytes = convert(currentRibbonResults.internetBytes).from('B').toBest();
            retResult.internetBytes.number = Math.round(retResult.internetBytes.val * 100) / 100;
            logger.silly(
              {
                cur: currentRibbonResults.internetBytes,
                prev: previousRibbonResults.internetBytes
              },
              'internet'
            );
            retResult.internetPercentage = NetworkUtils.calculatePercentageChange(currentRibbonResults.internetBytes, previousRibbonResults.internetBytes);
            logger.silly({ ribbonResult: this.ribbonResults }, 'statistics success!!');
            resolve(retResult);
          })
          .catch(error => {
            logger.silly({ error: error.message }, 'statistics fail!!');
            reject(error);
          });
      }
    }).catch(error => {
      logger.error({ error: error.message, stack: error.stack }, 'Error in statistics');
      Promise.reject(error);
    });
  }

  // ----------------------------------
  // sortFlowsByPort
  //   For the assets of the object, it produces a list of network ports sorted by number of bytes passed on that port
  //
  //  Input:
  //      date -   The UTC date to begin calculation.  Format:  YYYY-MM-DD
  //      timeFrame - The period of time over which to calculate.   The time frame is from the date backwards in time.
  //
  //  Output (an array of ports sorted from the port with the most bytes to the least bytes):
  //      [
  //        {
  //          port: <port number>,
  //          bytes:  <bytes passed on this port>
  //        },
  //        ...
  //      ]
  //
  //   If the day provided has no data then the output is an empty list:  []
  // NOTE: NO CACHE
  async sortFlowsByPort(startDate = new Date(), timeFrame = 'day') {
    logger.silly('Enter sortFlowsByPort');

    if (startDate == null) {
      logger.silly('No startDate provided.');
      throw new Error('No startDate provided.');
    }
    if (timeFrame !== 'day') {
      logger.silly({ timeFrame }, 'timeFrame provided is not supported');
      throw new Error('timeFrame provided is not supported');
    }
    try {
      // --- if assetGroups is empty then return empty list
      if (this.assetGroups != null && this.assetGroups.length <= 0) {
        return [];
      } else {
        // --- if assetGroups is not empty then do processing
        const yyyymmdd = NetworkUtils.getYYYY_MM_DD(startDate);
        const allUuids = this._collectAllUuids();
        const allIndexes = await this._getAllIndexes(yyyymmdd, this.TARGET_FLOW_INDEX_ROOT_NAME, this.indexAndBatchesForFlows);
        this.TARGET_PORT = await NetworkUtils.selectTargetPortField(this.client, allIndexes);
        const allCollectionBatches = await this._collectAllCollectionBatches(allIndexes);

        const targetPortField = this.TARGET_PORT;
        const body = await this._sortFlowBytesBy(this.client, allIndexes, allCollectionBatches, allUuids, timeFrame, targetPortField);
        logger.silly({ body }, 'Success in sortFlowsByPort');
        let retval = [];
        if ('aggregations' in body) {
          const buckets = body.aggregations.sortBy.buckets;
          for (let i = 0; i < buckets.length; i++) {
            const bucket = buckets[i];
            const onePortsInfo = {};
            if (bucket.key !== 0) {
              onePortsInfo.port = bucket.key;
              onePortsInfo.bytes = bucket.totalBytes.value;
              retval.push(onePortsInfo);
            }
          }
        }
        retval = retval
          .sort((elem1, elem2) => {
            return elem2.number - elem1.bytes.number;
          })
          .slice(0, 10);

        const bestUnits = this._selectBestUnitsForArrayOfObjects(retval, 'bytes');
        const updatedRetval = [];
        for (let i = 0; i < retval.length; i++) {
          const onePortsInfo = retval[i];
          onePortsInfo.bytes = convert(onePortsInfo.bytes).from('B').to(bestUnits);
          onePortsInfo.number = Math.round(onePortsInfo.bytes * 100) / 100;
          onePortsInfo.units = bestUnits;
          updatedRetval.push(onePortsInfo);
        }
        // --- sort descending...
        updatedRetval.sort((a, b) => b.number - a.number);
        return (updatedRetval);
      }
    } catch (error) {
      logger.error({ error: error.message }, 'Error in sortFlowsByPort');
      throw error;
    }
  }

  // ----------------------------------
  // sortFlowsByContainer
  //   For the assets of the object, it produces a list of containers sorted by number of bytes passed on that group,
  //     and provides breakdown of total bytes by incoming and outgoing
  //
  //  Input:
  //      date -   The UTC date to begin calculation.  Format:  YYYY-MM-DD
  //      timeFrame - The period of time over which to calculate.   The time frame is from the date backwards in time.
  //
  //  Output (an array of ports sorted from the port with the most bytes to the least bytes):
  //      [
  //        {
  //          container: <containerName from assetGroups>,
  //          incoming: <incoming bytes passed to the group>,
  //          outgoing: <outgoing bytes passed from the group>
  //        },
  //        ...
  //      ]

  //                          {
  //                              containerName: <name Of container>,
  //                              members:    {
  //                                              options:{
  //                                                  location:   <location id from which the assets come>,
  //                                                  serviceProvider: <service provider id from which the assets come>,
  //                                                  organization:    <organization id from which the assets come>
  //                                                  },
  //                                             objects: [
  //                                                        uuid: <instance uuid of asset>,
  //                                                        ...
  //                                                      ]
  //                                          }
  //                          }
  //
  //  If there is no data for the day provided then the output is displayed by this example:
  //   [
  //     {
  //       "container": "SAP",
  //       "incoming": 0,
  //       "outgoing": 0,
  //       "total": 0
  //     },
  // {
  //   "container": "ERP",
  //   "incoming": 0,
  //   "outgoing": 0,
  //   "total": 0
  // },
  // {
  //   "container": "Oracle",
  //   "incoming": 0,
  //   "outgoing": 0,
  //   "total": 0
  // }
  // ]
  // NOTE: NO CACHE
  async sortFlowsByContainer(startDate = new Date(), timeFrame = 'day') {
    try {
      logger.silly('Enter sortFlowsByContainer');
      if (startDate == null) {
        logger.silly('No startDate provided.');
        throw 'No startDate provided.';
      }
      if (timeFrame !== 'day') {
        logger.silly({ timeFrame }, 'timeFrame provided is not supported');
        throw 'timeFrame provided is not supported';
      }

      // --- if assetGroups is empty then return empty list
      if (this.assetGroups != null && this.assetGroups.length <= 0) {
        return [];
      } else {
        const yyyymmdd = NetworkUtils.getYYYY_MM_DD(startDate);
        const thePromises = [];
        const allIndexes = await this._getAllIndexes(yyyymmdd, this.TARGET_FLOW_INDEX_ROOT_NAME, this.indexAndBatchesForFlows);
        this.TARGET_PORT = await NetworkUtils.selectTargetPortField(this.client, allIndexes);
        for (let i = 0; i < this.assetGroups.length; i++) {
          const container = this.assetGroups[i];
          thePromises.push(this._getFlowsForOneContainer(yyyymmdd, container));
        }

        const results = await Promise.all(thePromises);
        try {
          logger.silly({ results }, 'Retrieved data in sortFlowsByContainer');
          const retval = [];
          for (let i = 0; i < results.length; i++) {
            const oneResult = results[i];
            const newEntry = {};
            newEntry.container = oneResult.container;
            if ('aggregations' in oneResult) {
              newEntry.incoming = convert(oneResult.aggregations.incoming.value).from('b').to('Kb');
              newEntry.incoming_number = Math.round(newEntry.incoming * 100) / 100;
              newEntry.outgoing = convert(oneResult.aggregations.outgoing.value).from('b').to('Kb');
              newEntry.outgoing_number = Math.round(newEntry.outgoing * 100) / 100;
              newEntry.total = convert(oneResult.aggregations.total.value).from('b').to('Kb');
              newEntry.total_number = Math.round(newEntry.total * 100) / 100;
            } else {
              newEntry.incoming = convert(0).from('b').to('Kb');
              newEntry.incoming_number = Math.round(newEntry.incoming * 100) / 100;
              newEntry.outgoing = convert(0).from('b').to('Kb');
              newEntry.outgoing_number = Math.round(newEntry.outgoing * 100) / 100;
              newEntry.total = convert(0).from('b').to('Kb');
              newEntry.total_number = Math.round(newEntry.total * 100) / 100;
            }
            retval.push(newEntry);
          }
          retval.sort(function (a, b) {
            return b.total_number - a.total_number;
          });
          return retval;
        } catch (error) {
          logger.silly({ error: error.message }, 'Error in sortFlowsByContainer');
          throw error;
        }
      }
    } catch (error) {
      logger.error({ error: error.message }, 'Error in sortFlowsByContainer');
      throw error;
    }
  }

  // ---------------------------------
  // output:
  //      [
  //       {container: name
  //        flows: [
  //                       {ruleId: xxxxx, src: xxxxxx, dst: xxxxxx, srcUuid: xxxxx, dstUuid: xxxxx,
  //                         protocol: xxxx, port: xxxxx, blocked: xxxxxx, policy: xxxxxx,
  //                         outgoingBytes: xxxxx, incomingBytes: xxxxx, startTime: xxxx, endTime: xxxxx},...
  //              ]
  //       },...
  //     ]
  //
  //  If there is no data for the day provided:
  //
  //   [
  //     {
  //       "container": "Boston",
  //       "flows": []
  //     },
  // {
  //   "container": "London",
  //   "flows": []
  // }
  // ]
  //
  // NOTE: NO CACHE
  async getRawFlows(startDate = new Date(),  offset = DEFAULT_FLOWS_OFFSET, limit = DEFAULT_FLOWS_LIMIT) {
    logger.silly('Enter getFlows');
    try {
      if (startDate == null) {
        logger.silly('No startDate provided.');
        throw('No startDate provided.');
      }

      if (this.flowsList == null) {
        this.flowsList = {};
      }

      // --- if assetGroups is empty then return empty list
      if (this.assetGroups != null && this.assetGroups.length <= 0) {
        return([]);
      }

      const yyyymmdd = NetworkUtils.getYYYY_MM_DD(startDate);

      // --- if not refreshing, then attempt to get the data from cache if possible, otherwise get data from elasticsearch and then put it into cache
      let data = null;
      if ((this.cache !== null) && (!this.refresh)) {
        const cacheKeyWithDate = this.cacheKey+'@'+yyyymmdd;
        data = await this.cache.get(cacheKeyWithDate);
        if (data) {
          this.flowsList[yyyymmdd] = data.flowsList;
          data = this.flowsList[yyyymmdd];
        }
      }
      if ((data == null) || !data) {
        await this.calculateRibbons(startDate); // calculateRibbons will update cache as needed and set this.flowsList[yyyymmdd]
        data = this.flowsList[yyyymmdd];
      }
      if ((data == null) || !data) {
        return([]);
      }

      const finalResult = data.slice(offset, offset+limit)
      // --- return only the limit number of records after the requested offset
      return(finalResult);
    } catch(error) {
      logger.error({ error: error.message }, 'Error in getRawFlows');
      throw(error);
    }
  }

  // ============================================================================================
  // STATIC functions - available directly from Class, no object needed, the this is not available
  // ============================================================================================

  // ============================================================================================
  // PRIVATE functions - shall begin with '_', do NOT access outside this class.
  // ============================================================================================

  // -------------------------------------------------------------------
  // _resetNetworkFlowData
  //   Resets to empty all the index and collectionBatches.  Usually done at init time as well as when
  //      the assetGroups definition changes.
  //
  //  Input:
  //      <none>
  //
  //  Output:
  //      <none>
  //
  _resetNetworkFlowData() {
    this.indexAndBatchesForFlows = {};
    this.allUuids = null;
    this.ribbonResults = {};
    this.flowsList = {};
  }

  //
  // INPUT:  array of objects where each object has a key with name that matches keyNameOfNumber
  // OUTPUT:  'B', 'KB', 'MB', 'GB' or 'TB' based on average
  _selectBestUnitsForArrayOfObjects(arrayOfObjects, keyNameOfNumber) {
    let bestUnits = 'B';
    let sum = 0;
    let max = 0;
    for (let i = 0; i < arrayOfObjects.length; i++) {
      const val = arrayOfObjects[i][keyNameOfNumber];
      sum += val;
      if (val > max) {
        max = val;
      }
    }
    const avg = sum / arrayOfObjects.length;
    if (avg <= 1000000) {
      bestUnits = 'KB';
    } else if (avg <= 1000000000) {
      bestUnits = 'MB';
    } else if (avg <= 1000000000000) {
      bestUnits = 'GB';
    } else if (avg <= 1000000000000000) {
      bestUnits = 'TB';
    }
    return bestUnits;
  }

  async _getFlowsForOneContainer(yyyymmdd, container) {
    try {
      logger.silly('Enter _getFlowsForOneContainer');
      const targetUuids = container.members.objects;
      const location = container.members.options.location;
      const serviceProvider = container.members.options.serviceProvider;
      let organization = container.members.options.organization;
      if (!Array.isArray(organization)){
        organization = [organization];
      }
      const indexes = [];
      for (const orgId of organization) {
        const flowRootName = await NetworkUtils.selectFlowIndexRootName(this.client, orgId, location, serviceProvider, yyyymmdd);
        const oneIndex = ['caveonetwork-' + orgId + '-' + location + '-' + serviceProvider + '-' + flowRootName + '*-' + yyyymmdd];
        indexes.push(oneIndex);
      }
      const collectionBatches = await this._collectAllCollectionBatches(indexes);
      const result = await this._trafficFlow(this.client, indexes, collectionBatches, targetUuids);
      logger.silly({ result }, '...In _getFlowsFroOneContainer, success getting trafficFlow');
      result.container = container.containerName;
      return result;
    } catch (error) {
      logger.silly({ error }, 'Error in _getFlowsForOneContainer');
      throw error;
    }
  }

  _getRawFlowsForOneContainer(yyyymmdd, container, from, size) {
    logger.silly('Enter _getRawFlowsForOneContainer');
    return new Promise((resolve, reject) => {
      const targetUuids = container.members.objects;
      const location = container.members.options.location;
      const serviceProvider = container.members.options.serviceProvider;
      let organization = container.members.options.organization;
      if (!Array.isArray(organization)){
        organization = [organization];
      }
      const indexes = [];
      for (const orgId of organization) {
        const oneIndex = ['caveonetwork-' + orgId + '-' + location + '-' + serviceProvider + '-' + this.FLOW_INDEX_ROOT_NAME + '*-' + yyyymmdd];
        indexes.push(oneIndex);
      }

      this._collectAllCollectionBatches(indexes)
        .then(collectionBatches => {
          return this._rawFlows(this.client, indexes, collectionBatches, targetUuids, from, size);
        })
        .then(result => {
          logger.silly({ result }, '...In _getRawFlowsForOneContainer, success getting raw flows');
          result.container = container.containerName;
          result.flows = result;
          resolve(result);
        })
        .catch(error => {
          logger.silly({ error: error.message }, 'Error in _getRawFlowsForOneContainer ');
          reject(error);
        });
    });
  }

  // --------------------------------
  async _getTotalFlows(startDate) {
    try {
      logger.silly('Enter _getTotalFlows');
      const yyyymmdd = NetworkUtils.getYYYY_MM_DD(startDate);
      const allUuids = this._collectAllUuids();
      const allIndexes = await this._getAllIndexes(yyyymmdd, this.TARGET_FLOW_INDEX_ROOT_NAME, this.indexAndBatchesForFlows);
      let allCollectionBatches = await this._collectAllCollectionBatches(allIndexes);
      allCollectionBatches = allCollectionBatches.filter(elem => {
        return elem;
      });
      const body = await this._countFlows(this.client, allIndexes, allCollectionBatches, allUuids);
      logger.silly({ body }, 'Success in _getTotalFlows');
      const retval = {};
      retval.yyyymmdd = yyyymmdd;
      retval.totalFlowCount = body.count;
      return retval;
    } catch (error) {
      logger.silly({ error: error }, 'Error in _getTotalFlows');
      throw error;
    }
  }

  // --------------------------------
  //  Creates a list of month-based wildcard indexes to cover all assetGroup members from a date backwards
  //      some number of days
  //  This handles the possibility of crossing month and date boundaries
  async _getWildcardIndexes(date, type, numberOfDaysInPast) {
    try {
      logger.silly({ date, type, numberOfDaysInPast }, 'Enter _getWildcardIndexes');
      const retIndexes = [];
      const pastDate = new Date(date.valueOf() - ((1000 * 3600 * 24) * numberOfDaysInPast)); // work around bug in Date, subtracting 1 day does not work in some corner cases, using 24 hours does work
      const pastYear = pastDate.getUTCFullYear();
      const pastMonth = pastDate.getUTCMonth();
      const curYear = date.getUTCFullYear();
      const curMonth = date.getUTCMonth();

      for (let i = 0; i < this.assetGroups.length; i++) {
        const location = this.assetGroups[i].members.options.location;
        const serviceProvider = this.assetGroups[i].members.options.serviceProvider;
        let organizationIn = this.assetGroups[i].members.options.organization;
        if (!Array.isArray(organizationIn)){
          organizationIn = [organizationIn];
        }

        for (const organization of organizationIn) {
          let startMonthWildcard = pastMonth;
          if (pastYear < curYear) {
            startMonthWildcard = 0;
            for (let year = pastYear; year < curYear; year++) {
              const yyyymmdd = year + '-*-*';
              if (type && (type.includes('flows'))) {
                type = await NetworkUtils.selectFlowIndexRootName(this.client,
                    organization, location, serviceProvider, yyyymmdd);
              }
              const index = 'caveonetwork-' + organization + '-' + location
                  + '-' + serviceProvider + '-' + type + '*-' + yyyymmdd;
              logger.silly({index},
                  '..In _calculateIndexesAndBatches, annual wildcard index created');
              retIndexes.push(index);
            }
          }
          for (let month = startMonthWildcard; month <= curMonth; month++) {
            let monthNumber = month + 1;
            if (monthNumber < 10) {
              monthNumber = '0' + monthNumber;
            }
            const yyyymmdd = curYear + '-' + monthNumber + '-*';
            if (type && (type.includes('flows'))) {
              type = await NetworkUtils.selectFlowIndexRootName(this.client,
                  organization, location, serviceProvider, yyyymmdd);
            }
            const index = 'caveonetwork-' + organization + '-' + location + '-'
                + serviceProvider + '-' + type + '*-' + yyyymmdd;
            logger.silly({index},
                '..In _calculateIndexesAndBatches, monthly wildcard index created');
            retIndexes.push(index);
          }
        }
      }
      return retIndexes;
    } catch (e) {
      logger.error({ e }, 'Error in _getWildcardIndexes');
      throw e;
    }
  }

  // --------------------------------
  //  Creates a list of  indexes to cover all assetGroup members
  //      some number of days
  //  This handles the possibility of crossing month and date boundaries
  async _getAllIndexes(yyyymmdd, type, indexAndBatches) {
    try {
      logger.silly({ yyyymmdd, type, indexAndBatches }, 'Enter _getAllIndexes');
      let curIndexes = null;
      const curIndexAndBatches = indexAndBatches[yyyymmdd];
      logger.silly({ yyyymmdd, curIndexAndBatches }, 'determining the available index and batches for key');
      if (curIndexAndBatches != null) {
        curIndexes = curIndexAndBatches.indexes;
      }

      if (curIndexes == null) {
        curIndexes = [];

        logger.silly({
          yyyymmdd,
          assetGroupLength: this.assetGroups.length
        }, '..In _getIndexes, about to create indexes');
        for (let i = 0; i < this.assetGroups.length; i++) {
          logger.silly({ assetGroupName: this.assetGroups[i].containerName }, '..In _getIndexes, determining if should create index');
          const location = this.assetGroups[i].members.options.location;
          const serviceProvider = this.assetGroups[i].members.options.serviceProvider;
          let organizationIn = this.assetGroups[i].members.options.organization;
          if (!Array.isArray(organizationIn)){
            organizationIn = [organizationIn];
          }

          for (const organization of organizationIn) {
            // type = 'flows*'
            if (type && (type.includes('flows'))) {
              type = await NetworkUtils.selectFlowIndexRootName(this.client,
                  organization, location, serviceProvider, yyyymmdd);
            }
            const index = 'caveonetwork-' + organization + '-' + location + '-'
                + serviceProvider + '-' + type + '*-' + yyyymmdd;
            logger.silly({index}, '..In _getIndexes, index created');
            curIndexes.push(index);
          }
        }
      }
      return curIndexes;
    } catch (error) {
      logger.error({ error }, 'Error in _getAllIndexes');
      throw error;
    }
  }

  // ---------------------------------
  //  Goes through all the assetGroup members and collecs all the UUIDs of each member into a single list
  _collectAllUuids() {
    logger.silly('Enter _collectAllUuids');
    if (this.allUuids == null) {
      this.allUuids = [];
      for (let i = 0; i < this.assetGroups.length; i++) {
        this.allUuids = this.allUuids.concat(this.assetGroups[i].members.objects);
      }
    }
    return this.allUuids;
  }

  // ----------------------------------
  // _calculateRibbonsForOneContainer
  //   Will provide a list of network ribbons from one container to a list of other containers.
  //   Will also calculate from srcContainer to EXTERNAL and to INTERNET
  //
  //   Input:
  //      yyyymmdd -   The UTC date to use for determining ribbons
  //      srcContainer - the information for the one container to calculate ribbons for:
  //                      {
  //                              containerName: <name Of container>,
  //                              members:    {
  //                                              options:{
  //                                                  location:   <location id from which the assets come>,
  //                                                  serviceProvider: <service provider id from which the assets come>,
  //                                                  organization:    <organization id from which the assets come>
  //                                                  },
  //                                             objects: [
  //                                                        uuid: <instance uuid of asset>,
  //                                                        ...
  //                                                      ]
  //                                          }
  //                          }
  //      containers - the list of destination containers (same format as srcContainer) to find ribbons to
  //      ribbonsForAllContainers - an array to which result of this function will be added
  //
  //  Side-effect - ribbonResult will insert an object into ribbonResult array that describes
  //                the flows for the srcContainer:
  //          {
  //              containerName: <name of container or EXTERNAL or INTERNET>,
  //              intraBytes: <number of bytes from asset in srcContainter to another asset in srcContainer>,
  //              interBytes: <number of bytes from srcContainer to other containers>,
  //              totalBytes: <total number of bytes from srcContainer>,
  //              internetBytes: <number of bytes from srcContainer to the internet>,
  //              externalBytes: <number of bytes from srcContainer to any that are not internet and not other containers>
  //              ribbons:
  //                      [
  //                          {
  //                              destination:  <containerName or EXTERNAL or INTERNET>,
  //                              bytes: <bytes from source container to this destination>
  //                          },
  //                          ...
  //                      ]
  //          },
  //
  //  Output:
  //      {intra: <number of bytes from asset in srcContainter to another asset in srcContainer>,
  //       inter: <number of bytes from srcContainer to other containers>,
  //       total: <total number of bytes from srcContainer>,
  //       internet: <number of bytes from srcContainer to the internet>,
  //       external: <number of bytes from srcContainer to any that are not internet and not other containers>}

  _calculateRibbonsForOneContainer(yyyymmdd, srcContainer, containers, ribbonsForAllContainers) {
    logger.silly('Enter _calculateRibbonsForOneContainer');
    logger.silly({
      yyyymmdd,
      srcContainer,
      containers,
      ribbonsForAllContainers
    }, 'Enter _calculateRibbonsForOneContainer');
    return new Promise((resolve, reject) => {
      const thePromises = [];
      const ribbonResult = {
        containerName: srcContainer.containerName,
        totalBytes: 0,
        intraBytes: 0,
        interBytes: 0,
        internetBytes: 0,
        externalBytes: 0,
        blockedBytes: 0,
        allowedBytes: 0,
        portMap: {},
        ribbons: []
      };
      for (let i = 0; i < containers.length; i++) {
        thePromises.push(this._calculateRibbonsFromContainerToContainer(yyyymmdd, srcContainer, containers[i], ribbonResult));
      }
      thePromises.push(this._calculateRibbonsFromContainerToFlowType(yyyymmdd, srcContainer, 'EXTERNAL', ribbonResult));
      thePromises.push(this._calculateRibbonsFromContainerToFlowType(yyyymmdd, srcContainer, 'INTERNET', ribbonResult));
      Promise.all(thePromises)
        .then(byteTotalsOfFromContainerToContainerCalls => {
          logger.silly({
            byteTotalsOfFromContainerToContainerCalls,
            ribbonResult
          }, 'Success at calculating ribbons for one container');
          const startingValue = {
            intra: 0,
            inter: 0,
            total: 0,
            internet: 0,
            external: 0,
            blocked: 0,
            allowed: 0,
            portMap: {},
            flowsList: []
          };
          let flowsForOneContainer = [];
          const byteTotals = byteTotalsOfFromContainerToContainerCalls.reduce((prev, current) => {
            logger.silly({ prev, current }, 'Enter function to combine');
            const x = prev;
            if (current != null) {
              let flowListBuffer = [];
              x.intra = prev.intra + current.intra;
              x.inter = prev.inter + current.inter;
              x.total = prev.total + current.total;
              x.internet = prev.internet + current.internet;
              x.external = prev.external + current.external;
              x.allowed = prev.allowed + current.allowed;
              x.blocked = prev.blocked + current.blocked;
              if (current.flowsList.length <= 0) {
                flowListBuffer = [];
              } else {
                flowListBuffer = current.flowsList;
              }
              flowsForOneContainer = flowsForOneContainer.concat(flowListBuffer);
              logger.silly({ prev: prev.portMap, current: current.portMap }, 'Calling _mergePortMaps');
              x.portMap = this._mergePortMaps(prev.portMap, current.portMap);
            }
            logger.silly({ x }, 'Exit function to combine');
            return x;
          }, startingValue);

          if (this.flowsList[yyyymmdd] != null) {
            this.flowsList[yyyymmdd] = this.flowsList[yyyymmdd].concat(flowsForOneContainer);
          } else {
            this.flowsList[yyyymmdd] = flowsForOneContainer;
          }

          // --- update ribbonResult sums
          ribbonResult.totalBytes = byteTotals.total;
          ribbonResult.intraBytes = byteTotals.intra;
          ribbonResult.interBytes = byteTotals.inter;
          ribbonResult.internetBytes = byteTotals.internet;
          ribbonResult.externalBytes = byteTotals.external;
          ribbonResult.allowedBytes = byteTotals.allowed;
          ribbonResult.blockedBytes = byteTotals.blocked;
          ribbonResult.portMap = byteTotals.portMap;

          ribbonsForAllContainers.push(ribbonResult);

          logger.silly({ byteTotals }, 'Leaving _calculateRibbonsForOneContainer');
          resolve(byteTotals);
        })
        .catch(error => {
          logger.silly({ error: error.message, yyyymmdd, srcContainer }, 'Error in _calculateRibbonsForOneContainer');
          reject(error);
        });
    });
  }

  _mergePortMaps(targetPortMap, newPortMap) {
    logger.silly({ targetPortMap, newPortMap }, 'Enter _mergePortMaps');
    for (const portIdx in newPortMap) {
      if (targetPortMap[portIdx] != null) {
        targetPortMap[portIdx] = targetPortMap[portIdx] + newPortMap[portIdx];
      } else {
        targetPortMap[portIdx] = newPortMap[portIdx];
      }
    }
    return targetPortMap;
  }

  // ----------------------------------
  // _calculateRibbonsForFlowType
  //   Will provide a list of network ribbons from EXTERNAL or INTERNET to a list of other containers.
  //
  //   Input:
  //      yyyymmdd -   The UTC date to use for determining ribbons
  //      flowType - EXTERNAL or INTERNET
  //      containers - the list of destination containers (same format as srcContainer) to find ribbons to
  //      ribbonsForAllContainers - an array to which result of this function will be added
  //
  //  Side-effect - ribbonResult will insert an object into ribbonResult array that describes
  //                the flows for the srcContainer:
  //          {
  //              containerName: <name of container or EXTERNAL or INTERNET>,
  //              intraBytes: <number of bytes from asset in srcContainter to another asset in srcContainer>,
  //              interBytes: <number of bytes from srcContainer to other containers>,
  //              totalBytes: <total number of bytes from srcContainer>,
  //              internetBytes: <number of bytes from srcContainer to the internet>,
  //              externalBytes: <number of bytes from srcContainer to any that are not internet and not other containers>
  //              ribbons:
  //                      [
  //                          {
  //                              destination:  <containerName or EXTERNAL or INTERNET>,
  //                              bytes: <bytes from source container to this destination>
  //                          },
  //                          ...
  //                      ]
  //          },
  //
  //  Output:
  //      {intra: <number of bytes from asset in srcContainter to another asset in srcContainer>,
  //       inter: <number of bytes from srcContainer to other containers>,
  //       total: <total number of bytes from srcContainer>,
  //       internet: <number of bytes from srcContainer to the internet>,
  //       external: <number of bytes from srcContainer to any that are not internet and not other containers>}
  async _calculateRibbonsForFlowType(yyyymmdd, containers, flowType, ribbonsForAllContainers) {
    logger.silly('Enter _calculateRibbonsForFlowType');
    logger.silly({ yyyymmdd, containers, ribbonsForAllContainers }, 'Enter _calculateRibbonsForFlowType');
    const thePromises = [];
    const ribbonResult = {
      containerName: flowType,
      totalBytes: 0,
      intraBytes: 0,
      interBytes: 0,
      internetBytes: 0,
      externalBytes: 0,
      allowed: 0,
      blocked: 0,
      portMap: {},
      ribbons: []
    };
    try {
      for (let i = 0; i < containers.length; i++) {
        thePromises.push(this._calculateRibbonsFromFlowTypeToContainer(yyyymmdd, flowType, containers[i], ribbonResult));
      }
      const byteTotalsOfFlowType = await Promise.all(thePromises);
      logger.silly({ byteTotalsOfFlowType, ribbonResult }, 'Success at calculating ribbons for one flow type');
      const startingValue = {
        intra: 0,
        inter: 0,
        total: 0,
        internet: 0,
        external: 0,
        allowed: 0,
        blocked: 0,
        portMap: {},
        flowsList: []
      };
      const byteTotals = byteTotalsOfFlowType.reduce((prev, current) => {
        logger.silly({ prev, current }, 'Enter function to combine');
        const x = prev;
        if (current != null) {
          let flowListBuffer = [];
          x.intra = prev.intra + current.intra;
          x.inter = prev.inter + current.inter;
          x.total = prev.total + current.total;
          x.internet = prev.internet + current.internet;
          x.external = prev.external + current.external;
          x.allowed = prev.allowed + current.allowed;
          x.blocked = prev.blocked + current.blocked;
          x.portMap = this._mergePortMaps(prev.portMap, current.portMap);
          logger.silly({
            preveFlowList: prev.flowsList,
            currentFlowLIst: current.flowsList
          }, 'concatting flowsList for flow type');

          if (current.flowsList.length <= 0) {
            flowListBuffer = [];
          } else {
            flowListBuffer = current.flowsList;
          }
          if (this.flowsList[yyyymmdd] != null) {
            this.flowsList[yyyymmdd] = this.flowsList[yyyymmdd].concat(flowListBuffer);
          } else {
            this.flowsList[yyyymmdd] = flowListBuffer;
          }
        }
        logger.silly({ x }, 'Exit function to combine');
        return x;
      }, startingValue);
      ribbonResult.totalBytes = byteTotals.total;
      ribbonResult.intraBytes = byteTotals.intra;
      ribbonResult.interBytes = byteTotals.inter;
      ribbonResult.internetBytes = byteTotals.internet;
      ribbonResult.externalBytes = byteTotals.external;
      ribbonResult.allowedBytes = byteTotals.allowed;
      ribbonResult.blockedBytes = byteTotals.blocked;
      ribbonResult.portMap = byteTotals.portMap;

      ribbonsForAllContainers.push(ribbonResult);
      return byteTotals;
    } catch (error) {
      logger.silly({ error: error.message, yyyymmdd, flowType }, 'Error in _calculateRibbonsForFlowType');
      throw error;
    }
  }

  // ----------------------------------
  // _calculateRibbonsFromContainerToContainer
  //   Will provide a list of network ribbons from one container to another container
  //
  //   Input:
  //      yyyymmdd -   The UTC date to use for determining ribbons
  //      srcContainer - Information about source container
  //      dstContainer - Information about destination container
  //      ribbonsForAllContainers - an array to which result of this function will be added
  //
  //  Side-effect - ribbonResult will insert an object into ribbons array of ribbonResult array that describes
  //                the flows for the srcContainer and destination container:
  //          {
  //              containerName: <name of container or EXTERNAL or INTERNET>,
  //              intraBytes: <number of bytes from asset in srcContainter to another asset in srcContainer>,
  //              interBytes: <number of bytes from srcContainer to other containers>,
  //              totalBytes: <total number of bytes from srcContainer>,
  //              internetBytes: <number of bytes from srcContainer to the internet>,
  //              externalBytes: <number of bytes from srcContainer to any that are not internet and not other containers>
  //              ribbons:
  //                      [
  //                          {
  //                              destination:  <containerName or EXTERNAL or INTERNET>,
  //                              bytes: <bytes from source container to this destination>
  //                          },
  //                          ...
  //                      ]
  //          },
  //
  //  Output:
  //      {intra: <number of bytes from asset in srcContainter to another asset in srcContainer>,
  //       inter: <number of bytes from srcContainer to other containers>,
  //       total: <total number of bytes from srcContainer>,
  //       internet: <number of bytes from srcContainer to the internet>,
  //       external: <number of bytes from srcContainer to any that are not internet and not other containers>}
  _calculateRibbonsFromContainerToContainer(yyyymmdd, srcContainer, dstContainer, ribbonsForOneContainer) {
    logger.silly('Enter _calculateRibbonsFromContainerToContainer');
    logger.silly({
      yyyymmdd,
      srcContainer,
      dstContainer,
      ribbonsForOneContainer
    }, 'Enter _calculateRibbonsFromContainerToContainer');
    return new Promise((resolve, reject) => {
      const srcKey = yyyymmdd + ':' + srcContainer.containerName;

      logger.silly({ srcKey }, 'In _calculateRibbonsFromContainerToContainer,calculated srcKey');
      let srcIndexAndBatches = null;
      let byteTotals = { intra: 0, inter: 0, total: 0, internet: 0, external: 0, blocked: 0, allowed: 0 };
      this._calculateIndexesAndBatches(yyyymmdd, srcContainer.containerName, this.TARGET_FLOW_INDEX_ROOT_NAME, this.indexAndBatchesForFlows)
        .then(() => {
          srcIndexAndBatches = this.indexAndBatchesForFlows[srcKey];
          return this._ribbonsFromSourceToDestination(
            this.client,
            srcIndexAndBatches.indexes,
            srcIndexAndBatches.collectionBatches,
            srcContainer.members.objects,
            dstContainer.members.objects,
            srcContainer.containerName,
            dstContainer.containerName
          );
        })
        .then(body => {
          logger.silly({ yyyymmdd, body }, 'Success getting src to dst in _calculateRibbonsBetweenContainers');
          // body could be empty here - destination has no flows

          if (body == null) {
            logger.silly(
              { sourceContainer: srcContainer.containerName, destinationContainer: dstContainer.containerName },
              'No flows from source to destination, leaving out results for this destination'
            );
            byteTotals = {
              intra: 0,
              inter: 0,
              total: 0,
              internet: 0,
              external: 0,
              blocked: 0,
              allowed: 0,
              portMap: {},
              flowsList: []
            };
          } else {
            if (srcContainer.containerName === dstContainer.containerName) {
              byteTotals = {
                intra: body.bytes,
                inter: 0,
                total: body.bytes,
                internet: 0,
                external: 0,
                blocked: body.details.blocked.bytes,
                allowed: body.details.allowed.bytes,
                portMap: {},
                flowsList: body.flowsList
              };
            } else {
              byteTotals = {
                intra: 0,
                inter: body.bytes,
                total: body.bytes,
                internet: 0,
                external: 0,
                blocked: body.details.blocked.bytes,
                allowed: body.details.allowed.bytes,
                portMap: {},
                flowsList: body.flowsList
              };
            }
            body.flowsList = null;
            this._updatePortMap(byteTotals.portMap, body.details.ports);
            logger.silly({ srcKey, byteTotals }, 'In _calculateRibbonsFromContainerToContainer');
            ribbonsForOneContainer.ribbons.push(body);
          }
          resolve(byteTotals);
        })
        .catch(error => {
          logger.silly(
            { error: error.message, yyyymmdd, srcContainer, dstContainer },
            'Error in _calculateRibbonsFromContainerToContainer during elasticsearch search'
          );
          reject(error);
        });
    });
  }

  _updatePortMap(portMap, ports) {
    logger.silly({ portMap, ports }, 'Enter _updatePortMap');
    for (let i = 0; i < ports.length; i++) {
      const port = ports[i];
      if (portMap[port.port] != null) {
        portMap[port.port] = portMap[port.port] + port.total.bytes;
      } else {
        portMap[port.port] = port.total.bytes;
      }
    }
    logger.silly({ portMap }, 'Exiting _updatePortMap');
  }

  _calculateRibbonsFromContainerToFlowType(yyyymmdd, srcContainer, flowType, ribbonsForOneContainer) {
    logger.silly({
      yyyymmdd,
      srcContainer,
      flowType,
      ribbonsForOneContainer
    }, 'Enter _calculateRibbonsFromContainerToFlowType');
    return new Promise((resolve, reject) => {
      const srcKey = yyyymmdd + ':' + srcContainer.containerName;

      logger.silly({ srcKey }, 'In _calculateRibbonsFromContainerToFlowType,calculated srcKey');
      let srcIndexAndBatches = null;
      this._calculateIndexesAndBatches(yyyymmdd, srcContainer.containerName, this.TARGET_FLOW_INDEX_ROOT_NAME, this.indexAndBatchesForFlows)
        .then(() => {
          srcIndexAndBatches = this.indexAndBatchesForFlows[srcKey];
          return this._ribbonsFromSourceToFlowType(
            this.client,
            srcIndexAndBatches.indexes,
            srcIndexAndBatches.collectionBatches,
            srcContainer.members.objects,
            srcContainer.containerName,
            flowType
          );
        })
        .then(body => {
          logger.silly({
            yyyymmdd,
            body
          }, 'Success getting src to flow type in _calculateRibbonsFromContainerToFlowType');
          // result from _calculateRibbonsFromFlowTypeToCOntainer could be null (if no flows)
          let byteTotals = { intra: 0, inter: 0, total: 0, internet: 0, external: 0, blocked: 0, allowed: 0 };
          if (body == null) {
            byteTotals = {
              intra: 0,
              inter: 0,
              total: 0,
              internet: 0,
              external: 0,
              blocked: 0,
              allowed: 0,
              portMap: {},
              flowsList: []
            };
          } else {
            if (flowType === 'EXTERNAL') {
              byteTotals = {
                intra: 0,
                inter: 0,
                total: body.bytes,
                internet: 0,
                external: body.bytes,
                blocked: body.details.blocked.bytes,
                allowed: body.details.allowed.bytes,
                portMap: {},
                flowsList: body.flowsList
              };
            } else if (flowType === 'INTERNET') {
              byteTotals = {
                intra: 0,
                inter: 0,
                total: body.bytes,
                internet: body.bytes,
                external: 0,
                blocked: body.details.blocked.bytes,
                allowed: body.details.allowed.bytes,
                portMap: {},
                flowsList: body.flowsList
              };
            }
            body.flowsList = null;
            this._updatePortMap(byteTotals.portMap, body.details.ports);
            logger.silly({ srcKey, byteTotals }, 'In _calculateRibbonsFromContainerToFlowType');
            ribbonsForOneContainer.ribbons.push(body);
          }
          resolve(byteTotals);
        })
        .catch(error => {
          // logger.error({
          //   error: error.message,
          //   yyyymmdd,
          //   srcContainer,
          //   stack: error.stack
          // }, 'Error in _calculateRibbonsFromContainerToFlowType during elasticsearch search');
          reject(error);
        });
    });
  }

  _calculateRibbonsFromFlowTypeToContainer(yyyymmdd, flowType, dstContainer, ribbonsForOneContainer) {
    logger.silly('Enter _calculateRibbonsFromFlowTypeToContainer');
    logger.silly({
      yyyymmdd,
      dstContainer,
      flowType,
      ribbonsForOneContainer
    }, 'Enter _calculateRibbonsFromFlowTypeToContainer');
    return new Promise((resolve, reject) => {
      const srcKey = yyyymmdd + ':' + dstContainer.containerName;

      logger.silly({ srcKey }, 'In _calculateRibbonsFromFlowTypeToContainer,calculated srcKey');
      let dstIndexAndBatches = null;
      this._calculateIndexesAndBatches(yyyymmdd, dstContainer.containerName, this.TARGET_FLOW_INDEX_ROOT_NAME, this.indexAndBatchesForFlows)
        .then(() => {
          dstIndexAndBatches = this.indexAndBatchesForFlows[srcKey];
          return this._ribbonsFromFlowTypeToDestination(
            this.client,
            dstIndexAndBatches.indexes,
            dstIndexAndBatches.collectionBatches,
            dstContainer.members.objects,
            dstContainer.containerName,
            flowType
          );
        })
        .then(body => {
          // result from _calculateRibbonsFromFlowTypeToCOntainer could be null (if no flows)
          let byteTotals = { intra: 0, inter: 0, total: 0, internet: 0, external: 0, blocked: 0, allowed: 0 };
          if (body == null) {
            byteTotals = {
              intra: 0,
              inter: 0,
              total: 0,
              internet: 0,
              external: 0,
              blocked: 0,
              allowed: 0,
              portMap: {},
              flowsList: []
            };
          } else {
            logger.silly(
              {
                yyyymmdd,
                body
              },
              'Success getting flow type to destination in _calculateRibbonsFromFlowTypeToContainer'
            );
            if (flowType === 'EXTERNAL') {
              byteTotals = {
                intra: 0,
                inter: 0,
                total: body.bytes,
                internet: 0,
                external: body.bytes,
                blocked: body.details.blocked.bytes,
                allowed: body.details.allowed.bytes,
                portMap: {},
                flowsList: body.flowsList
              };
            } else if (flowType == 'INTERNET') {
              byteTotals = {
                intra: 0,
                inter: 0,
                total: body.bytes,
                internet: body.bytes,
                external: 0,
                blocked: body.details.blocked.bytes,
                allowed: body.details.allowed.bytes,
                portMap: {},
                flowsList: body.flowsList
              };
            }
            body.flowsList = null;
            this._updatePortMap(byteTotals.portMap, body.details.ports);
            logger.silly({ srcKey, byteTotals }, 'In _calculateRibbonsFromFlowTypeToContainer');
            ribbonsForOneContainer.ribbons.push(body);
          }
          resolve(byteTotals);
        })
        .catch(error => {
          // logger.error(
          //   { error: error.message, yyyymmdd, flowType, dstContainer },
          //   'Error in _calculateRibbonsFromFlowTypeToContainer during elasticsearch search'
          // );
          reject(error);
        });
    });
  }

  async _ribbonsFromSourceToDestination(esClient, srcIndex, srcCollectionBatches, sourceUuids, destinationUuids, sourceName, destinationName, includeEphemeralPorts=true) {
    logger.silly('Enter _ribbonsFromSourceToDestination TURKEY');
    logger.silly({
      srcIndex,
      srcCollectionBatches,
      sourceName,
      destinationName
    }, 'Enter _ribbonsFromSourceToDestination TURKEY');
    try {
      logger.silly({ srcIndex, srcCollectionBatches, sourceUuids, destinationUuids, destinationName });
      // let aggsJson = this._aggBytesOnly()
      srcCollectionBatches = srcCollectionBatches.filter(a => a);

      const pageSize = (config.aggregation_page_size) || DEFAULT_AGGREGATION_PAGE_SIZE;
      const aggsJson = this._aggDetails(pageSize);
      const mustTerms = [
        { terms: { sourceUuid: sourceUuids } },
        { terms: { destinationUuid: destinationUuids } },
        { terms: { collectionBatch: srcCollectionBatches } },
        { match: { 'flowConnect': 'VM-VM' } }
      ];
      mustTerms.push(NetworkUtils.getPortRangeEsCheck('sourceCollectionToDestinationCollection', includeEphemeralPorts));
      const searchJson = {
        //headers:esClient.rfHeaders,
        index: srcIndex,
        scroll: '10s',
        size: 1000,
        body: {
          query: {
            bool: {
              filter: [
                {
                  bool:
                    {
                      must: mustTerms
                    }
                }
              ]
            }
          },
          aggs: aggsJson
        }
      };

      // --- rate limit the number of scroll requests that are active simultaneously
      await this._waitForActiveScrollIdRateLimit();

      this._incrementActiveScrollIdCount('source-to-dest');
      // --- do the elasticsearch search and aggregation
      const body = await esClient.search(searchJson);
      const result = await this._aggDetailsParser(esClient, sourceName, destinationName, body, searchJson);
      return result;
    } catch(error)  {
      this._decrementActiveScrollIdCount('source-to-dest')
      logger.error({ error: error.message }, 'Error (in _ribbonsFromSourceToDestination) getting ribbons from source to destination');
      throw error;
    };
  }

  async _waitForActiveScrollIdRateLimit() {
    logger.silly({scrollIdCount: this.scrollIdCount, activeScrollIdRateLimit: this.activeScrollIdRateLimit}, 'WAITING FOR ACTIVE SCROLL ID LIMIT');
    const jitter = Math.floor(Math.random() * this.activeScrollIdWaitJitterMax);  // put jitter in wait so that if multiple requests arrive at same time they start in staggered fashion
    let loopCount = 0;
    do {
      await new Promise(r => setTimeout(r, (this.activeScrollIdWaitBase+jitter)));
      loopCount += 1;
    } while ((this.scrollIdCount > this.activeScrollIdRateLimit) && (loopCount < this.activeScrollIdMaxWaitLoops));
    //TODO:  The loopCount < this.activeScrollIdMaxWaitLoops is a hack.  It is needed because the context of scroll ids is
    //TODO:    global to ElasticSearch but the context of the values in this method are local to this instance of NetworkFlowsElasticSearch.
  }
  _incrementActiveScrollIdCount(sourceOfRequest) {
    this.scrollIdCount += 1;
    logger.silly({scrollIdCount: this.scrollIdCount, sourceOfRequest}, 'Increment active scroll Id count');
  }
  _decrementActiveScrollIdCount(sourceOfRequest) {
    if (this.scrollIdCount > 1) this.scrollIdCount -= 1;
    logger.silly({scrollIdCount: this.scrollIdCount, sourceOfRequest}, 'Decrement active scroll Id count');
  }
  _aggDetails(pageSize) {
    const targetPortField = this.TARGET_PORT;
    return {
      flowCount: { value_count: { field: 'flowConnect' } },
      incoming: { sum: { field: 'sourceBytes' } },
      outgoing: { sum: { field: 'destinationBytes' } },
      blocked: {
        terms: { field: 'blocked', size: 3 },
        aggs: {
          incoming: { sum: { field: 'sourceBytes' } },
          outgoing: { sum: { field: 'destinationBytes' } }
        }
      },
      port: {
        composite: {
          size: pageSize,
          sources: [
            { port: { terms: { field: targetPortField } } }
          ]
        },
        aggs: {
          incoming: { sum: { field: 'sourceBytes' } },
          outgoing: { sum: { field: 'destinationBytes' } },
          blocked: {
            terms: { field: 'blocked', size: 3 },
            aggs: {
              incoming: { sum: { field: 'sourceBytes' } },
              outgoing: { sum: { field: 'destinationBytes' } },
              policy: {
                top_hits: {
                  size: 1,
                  _source: {
                    includes: ['policyType',
                      'policyName', 'ruleId', 'ruleName', 'ruleDescription','assetRepoId']
                  }
                }
              },
              source: { terms: { field: 'source', size: AGG_SIZE_FOR_SOURCE_DEST } },
              destination: { terms: { field: 'destination', size: AGG_SIZE_FOR_SOURCE_DEST } }
            }
          }
        }
      }
    };
  }

  async _getAllIpsForOneFieldForOnePort(esClient, searchJsonIn, portNumber, blockedValue, fieldName) {

    const pageSize = AGG_SIZE_FOR_SOURCE_DEST;
    const searchJson = this._modifySearchJsonToGetAllValuesForOneFieldForOnePort(searchJsonIn, portNumber, blockedValue, fieldName, pageSize);

    let aggregationData = null;
    let ipAggResults = [];
    // --- do initial query
    let body = await esClient.search(searchJson);
    if (!body.aggregations) {
      return [];
    }
    aggregationData = body.aggregations;
    ipAggResults = ipAggResults.concat(aggregationData.endpoint.buckets);
    // --- gather all pages of the aggregation data
    while (aggregationData.endpoint.after_key) {
      searchJson.size = 0;
      delete searchJson.scroll;
      logger.info({ pageSize, afterKey: aggregationData.endpoint.after_key }, 'Collected page of aggregation data for IPs');
      searchJson.body.aggs = this._aggDetailsNextPageForEndpoint(pageSize, aggregationData.endpoint.after_key, fieldName);
      body = await esClient.search(searchJson);
      if (body.aggregations) {
        aggregationData = body.aggregations;
        ipAggResults = ipAggResults.concat(aggregationData.endpoint.buckets);
      }
    }
    return ipAggResults;
  }

  _modifySearchJsonToGetAllValuesForOneFieldForOnePort(searchJsonIn, portNumber, blockedValue, fieldName, pageSize) {
    const searchJsonForOnePort = JSON.parse(JSON.stringify(searchJsonIn)); //clone
    const query = searchJsonForOnePort.body.query;
    const mustTerms = query.bool.filter[0].bool.must;
    const mustPortTermMatch = {};
    const targetPortField = this.TARGET_PORT;
    mustPortTermMatch[targetPortField] = portNumber;
    mustTerms.push({ match: mustPortTermMatch });
    mustTerms.push({ match: { blocked: blockedValue } });
    searchJsonForOnePort.body.aggs = this._aggDetailsForOneField(pageSize, fieldName);
    return searchJsonForOnePort;
  }

  _aggDetailsNextPageForEndpoint(pageSize, afterKey, fieldName) {
    const aggDetails = this._aggDetailsForOneField(pageSize, fieldName);
    aggDetails.endpoint.composite.after = afterKey;
    return aggDetails;
  }

  _aggDetailsForOneField(pageSize, fieldName) {
    const aggSource = {};
    aggSource[fieldName] = { terms: { field: fieldName } };
    return {
      endpoint: {
        composite: {
          size: pageSize,
          sources: [
            aggSource
          ]
        }
      }
    };
  }

  // --- Get next page of agg results
  //
  // INPUT:
  //     pageSize - number of records to request for each page
  //     afterKey - A JSONObject containing keys for the composite elements:
  //          Example:  {
  //                      "destinationPort": "36217",
  //                      "source": "10.1.2.3",
  //                      "destination": "10.1.13.30"
  //                    }
  _aggDetailsNextPage(pageSize, afterKey) {
    const aggDetails = this._aggDetails(pageSize);
    aggDetails.port.composite.after = afterKey;
    return aggDetails;
  }

  //
  //   OUTPUT:
  //      null
  //  OR
  //      {
  //        destination: <name of destination container>,
  //        bytes: <total bytes into and out of destination container>,
  //        details:
  //          {
  //            allBlocked:  true/false (true if allowed/bytes is 0 and blocked/bytes > 0, otherwise false)
  //            total:
  //              {
  //                < same as for allowed, but for totals >
  //                allowedBytes: <same as allowed/bytes>
  //                blockedBytes: <same as blocked/bytes>
  //              }
  //            allowed:
  //              {
  //                bytes:  < total bytes allowed by policy>
  //                incoming: <bytes inbound>
  //                outgoing: <bytes outbound>
  //                internetBytes: <bytes to or from internet>
  //                externalBytes: <bytes to or from 'external' IP addresses>
  //                intraBytes: <bytes between VMs in same container>
  //                interBytes:  <all bytes that don't meet the other conditions>
  //              }
  //            blocked:
  //              {
  //                <same as for allowed, but for blocked>
  //              }
  //            ports:
  //              [
  //                {
  //                  port: port number
  //
  //                  total:
  //                    {
  //                     < same as blocked, but for total bytes >
  //                     allBlocked:  true/false (true if allowed/bytes is 0 and blocked/bytes > 0, otherwise false)
  //                     allowedBytes: <same as blocked/bytes>
  //                     blockedBytes: <same as allowed/bytes>
  //                    },
  //                  blocked:
  //                    {
  //                     bytes: bytes in/out
  //                     incoming: bytes incoming
  //                     outgoing: bytes outbound
  //                     intraBytes: bytes between VMS in same container
  //                     interBytes: bytes betwee
  //                     internetBytes:  bytes to or from internet
  //                     externalBytes:  bytes to or from 'external' IP addresses
  //                      policy:
  //                          {
  //                            type: <type of policy: UNKNOWN, ...>
  //                            name: <name of policy>
  //                            ruleId: <id of dfw rule applied to this flow>+  //                            ruleName:  <name of dfw rule applied to this flow>
  //                            ruleDescription:  <description of dfw rule applied to this flow>
  //                          }
  //                      sourceIps: [<ip address>,...]
  //                      destinationIps: [<ip address>, ...]
  //                    },
  //                  allowed:
  //                    {
  //                        <same as blocked, but for allowed bytes>
  //                    }
  //                },...
  //              ]
  //          }
  //        flowsList:
  //          [
  //            {
  //               destinationPort: curElement.servicePort,
  //               policyName: curElement.policyName,
  //               destination: curElement.destination,
  //               direction: curElement.direction,
  //               source: curElement.source,
  //               endTimeFormatted: curElement.endTimeFormatted,
  //               sourceBytes: curElement.sourceBytes,
  //               startTimeFormatted: curElement.startTimeFormatted,
  //               protocol: curElement.protocol,
  //               blocked: curElement.blocked,
  //               sourceUuid: curElement.sourceUuid,
  //               destinationUuid: curElement.destinationUuid,
  //               ruleName: curElement.ruleName,
  //               ruleId: curElement.ruleId,
  //               destinationBytes: curElement.destinationBytes,
  //               flowClass: flowClass,
  //               assetRepoId: curElement.assetRepoId
  //             }
  //          ]
  //      }
  //
  async _aggDetailsParser(esClient, sourceName, destinationName, body, searchJson) {
    logger.silly('Enter _aggDetailsParser');
    logger.silly({ sourceName, destinationName }, 'Enter _aggDetailsParser');
    if (!body || !body.hits || !body.hits.hits || (body.hits.hits.length <= 0)) {
      // no search results
      logger.silly({sourceName, destinationName},'No search hits');
      // close the scroll id
      if (!body._scroll_id) {
        logger.debug('scroll_id is null in _aggDetailsParser, not clearing it!');
      } else {
        logger.silly({scroll_id: body._scroll_id}, 'EPHEMERAL: *deleting scroll id');
        const bodyParam = {};
        bodyParam.scroll_id = body._scroll_id;
        const parameter = {
          body: bodyParam
        };
        this._decrementActiveScrollIdCount('aggDetailsParser-no-data');
        await esClient.clearScroll(parameter);
        logger.silly({scroll_id:body._scroll_id}, 'scroll_id deleted');
      }
      return null;
    }
    let aggregationData = null;
    if (body.aggregations) {
      aggregationData = body.aggregations;
    }
    const details = {};
    details.total = {};
    details.allowed = {};
    details.blocked = {};
    const flowClass = this._categorizeFlowClass(sourceName, destinationName);
    let done = false;
    const flowsMap = {};
    let flowsProcessed = 0;

    const scroll_id = body._scroll_id;
    logger.info({scroll_id}, '  In _aggDetailsParser, Initial scroll id ');

    // --- process the scroll
      do {
        if (body.hits.hits.length > 0) {
          logger.silly({hitsLength: body.hits.hits.length}, 'In _aggDetailsParser, about to parse hits into flowsMap');
          const flowsListBuffer = body.hits.hits;
          flowsListBuffer.map(obj => {
            flowsProcessed += 1;
            logger.silly({flowsProcessed}, 'Mapping');
            const curElement = obj._source;
            let flowsMapKey =
              curElement.sourceUuid +
              ':' +
              curElement.destinationUuid +
              ':' +
              curElement.source +
              ':' +
              curElement.destination +
              ':' +
              curElement.direction +
              ':' +
              curElement.destinationPort +
              ':' +
              curElement.protocol +
              ':' +
              curElement.blocked +
              ':' +
              curElement.ruleId +
              ':' +
              curElement.ruleName +
              ':' +
              curElement.policyName;
            if (this.TARGET_PORT === 'servicePort') {
              flowsMapKey =
                curElement.sourceUuid +
                ':' +
                curElement.destinationUuid +
                ':' +
                curElement.source +
                ':' +
                curElement.destination +
                ':' +
                curElement.direction +
                ':' +
                curElement.servicePort +
                ':' +
                curElement.protocol +
                ':' +
                curElement.blocked +
                ':' +
                curElement.ruleId +
                ':' +
                curElement.ruleName +
                ':' +
                curElement.policyName;
            }
            const existingElement = flowsMap[flowsMapKey];
            let newElement = null;
            if (existingElement != null) {
              logger.silly('Mapping, map hit');
              existingElement.destinationBytes += curElement.destinationBytes;
              existingElement.sourceBytes += curElement.sourceBytes;
              const existingElementStartDate = new Date(existingElement.startTimeFormatted);
              const curElementStartDate = new Date(curElement.startTimeFormatted);
              if (existingElementStartDate.getTime() > curElementStartDate.getTime()) {
                existingElement.startTimeFormatted = curElement.startTimeFormatted;
              }
              const existingElementEndDate = new Date(existingElement.endTimeFormatted);
              const curElementEndDate = new Date(curElement.endTimeFormatted);
              if (existingElementEndDate.getTime() < curElementEndDate.getTime()) {
                existingElement.endTimeFormatted = curElement.endTimeFormatted;
              }
              newElement = existingElement;

              logger.silly('Mapping, map hit processed');
            } else {
              logger.silly('--> Mapping, map miss');
              newElement = {
                destinationPort: curElement.destinationPort,
                policyName: curElement.policyName,
                destination: curElement.destination,
                direction: curElement.direction,
                source: curElement.source,
                endTimeFormatted: curElement.endTimeFormatted,
                sourceBytes: curElement.sourceBytes,
                startTimeFormatted: curElement.startTimeFormatted,
                protocol: curElement.protocol,
                blocked: curElement.blocked,
                sourceUuid: curElement.sourceUuid,
                destinationUuid: curElement.destinationUuid,
                ruleName: curElement.ruleName,
                ruleId: curElement.ruleId,
                destinationBytes: curElement.destinationBytes,
                flowClass: flowClass,
                assetRepoId: curElement.assetRepoId
              };

              if (this.TARGET_PORT === 'servicePort') {
                newElement = {
                  destinationPort: curElement.servicePort,
                  policyName: curElement.policyName,
                  destination: curElement.destination,
                  direction: curElement.direction,
                  source: curElement.source,
                  endTimeFormatted: curElement.endTimeFormatted,
                  sourceBytes: curElement.sourceBytes,
                  startTimeFormatted: curElement.startTimeFormatted,
                  protocol: curElement.protocol,
                  blocked: curElement.blocked,
                  sourceUuid: curElement.sourceUuid,
                  destinationUuid: curElement.destinationUuid,
                  ruleName: curElement.ruleName,
                  ruleId: curElement.ruleId,
                  destinationBytes: curElement.destinationBytes,
                  flowClass: flowClass,
                  assetRepoId: curElement.assetRepoId
                };
              }
            }
            flowsMap[flowsMapKey] = newElement;
          });
          logger.silly('Done parsing hits into flowsMap');
        }
        if (body.hits.total > flowsProcessed) {
          done = false;
          try {
            logger.silly(
              {
                totalToCollect: body.hits.total,
                collectedSoFar: flowsProcessed,
                uniqueFlows: Object.keys(flowsMap).length
              },
              'Not done collecting data, using ES Scroll API to get more data'
            );
            body = await esClient.scroll({scrollId: scroll_id, scroll: '10s'});
            logger.debug({scroll_id: body._scroll_id}, 'new scroll id');
          } catch (e) {
            logger.error({exception: e.stack}, 'Exception while scrolling through ElasticSearch data results for flows.');
          }
        } else {
          logger.silly(
            {
              totalToCollect: body.hits.total,
              collectedSoFar: flowsProcessed,
              uniqueFlows: Object.keys(flowsMap).length
            },
            'Finished collecting data from ES Scroll API'
          );
          done = true;

          logger.debug({scroll: body._scroll_id}, 'scroll id getting deleted');
          try {
            if (!body._scroll_id) {
              logger.debug('scroll_id is null in _aggDetailsParser, not clearing it!');
              this._decrementActiveScrollIdCount('aggDetailsParser-data-collected')
            } else {
              logger.silly({scroll_id: body._scroll_id}, ' deleting scroll id');
              const bodyParam = {};
              bodyParam.scroll_id = body._scroll_id;
              const parameter = {
                body: bodyParam
              };
              this._decrementActiveScrollIdCount('aggDetailsParser-data-collected')
              await esClient.clearScroll(parameter);
              logger.silly({scroll_id:body._scroll_id}, 'scroll_id deleted');
            }
          } catch (error) {
            logger.error({error, stack: error.stack}, 'error occurred deleting scroll id');
            this._decrementActiveScrollIdCount('aggDetailsParser-data-collected');
          }
        }
      } while (!done);
    const flowsList = Object.values(flowsMap);
    logger.silly({
      flowsListLength: Object.keys(flowsMap).length,
      flowsList_length: flowsList.length
    }, 'In _aggDetailsParser, flowsList created');

    // ----------------------------------------------------
    //   Process aggregation data
    // ----------------------------------------------------
    // ---- initialize aggregation output data

    details.total.bytes = 0;
    details.total.incoming = 0;
    details.total.outgoing = 0;
    details.total.internetBytes = 0;
    details.total.externalBytes = 0;
    details.total.intraBytes = 0;
    details.total.interBytes = 0;
    details.total.allowedBytes = 0;
    details.total.blockedBytes = 0;
    details.allBlocked = false;

    details.allowed.bytes = 0;
    details.allowed.incoming = 0;
    details.allowed.outgoing = 0;
    details.allowed.internetBytes = 0;
    details.allowed.externalBytes = 0;
    details.allowed.intraBytes = 0;
    details.allowed.interBytes = 0;
    details.blocked.bytes = 0;
    details.blocked.incoming = 0;
    details.blocked.outgoing = 0;
    details.blocked.internetBytes = 0;
    details.blocked.externalBytes = 0;
    details.blocked.intraBytes = 0;
    details.blocked.interBytes = 0;

    details.allowed = {
      bytes: 0,
      incoming: 0,
      outgoing: 0,
      intraBytes: 0,
      interBytes: 0,
      internetBytes: 0,
      externalBytes: 0
    };
    details.blocked = {
      bytes: 0,
      incoming: 0,
      outgoing: 0,
      intraBytes: 0,
      interBytes: 0,
      internetBytes: 0,
      externalBytes: 0
    };

    details.ports = [];

    if (aggregationData) {
      // --- process the non-paged aggregation results
      //aggregationData = oneAggPage.aggregations
      details.total.bytes += (aggregationData.incoming.value);
      details.total.incoming += aggregationData.incoming.value;
      details.total.outgoing += aggregationData.outgoing.value;
      this._categorizeBytes(sourceName, destinationName, details.total, details.total.bytes);

      // blocked and allowed stats
      // --- Now process all aggregation data

      const blockedBuckets = aggregationData.blocked.buckets;
      for (let blockedIdx = 0; blockedIdx < blockedBuckets.length; blockedIdx++) {
        const bucket = blockedBuckets[blockedIdx];
        if (bucket.key == 0) {
          details.allowed.bytes += (bucket.outgoing.value);
          details.allowed.incoming += bucket.incoming.value;
          details.allowed.outgoing += bucket.outgoing.value;
          this._categorizeBytes(sourceName, destinationName, details.allowed, details.allowed.bytes);
        } else if (bucket.key == 1) {
          details.blocked.bytes += (bucket.incoming.value);
          details.blocked.incoming += bucket.incoming.value;
          details.blocked.outgoing += bucket.outgoing.value;
          this._categorizeBytes(sourceName, destinationName, details.blocked, details.blocked.bytes);
        }
      }

      details.total.allowedBytes = details.allowed.bytes;
      details.total.blockedBytes = details.blocked.bytes;
      details.allBlocked = details.allowed.bytes <= 0 && details.blocked.bytes > 0;
      // --- Get all pages for paged aggregation data
      const aggPages = [];
      aggPages.push(body);

      // --- gather all pages of the aggregation data
      while (aggregationData.port.after_key) {
        searchJson.size = 0;
        delete searchJson.scroll;
        const pageSize = (config.aggregation_page_size) || DEFAULT_AGGREGATION_PAGE_SIZE;
        logger.silly({ pageSize, afterKey: aggregationData.port.after_key }, 'Collected page of aggregation data');
        searchJson.body.aggs = this._aggDetailsNextPage(pageSize, aggregationData.port.after_key);
        body = await esClient.search(searchJson);
        if (body.aggregations) {
          aggregationData = body.aggregations;
          aggPages.push(body);
        }
      }

      // --- process the paged results - from composite aggregation
      let oneAggPage = {};
      for (let x = 0; x < aggPages.length; x++) {
        oneAggPage = aggPages[x].aggregations;
        const portBuckets = oneAggPage.port.buckets;
        for (let portIdx = 0; portIdx < portBuckets.length; portIdx++) {
          const newElement = {};
          newElement.total = {
            bytes: 0,
            incoming: 0,
            outgoing: 0,
            intraBytes: 0,
            interBytes: 0,
            internetBytes: 0,
            externalBytes: 0,
            allowedBytes: 0,
            blockedBytes: 0
          };
          newElement.blocked = {
            bytes: 0,
            incoming: 0,
            outgoing: 0,
            intraBytes: 0,
            interBytes: 0,
            internetBytes: 0,
            externalBytes: 0,
            policy: { type: 'UNKNOWN', name: '' },
            sourceIps: [],
            destinationIps: []
          };
          newElement.allowed = {
            bytes: 0,
            incoming: 0,
            outgoing: 0,
            intraBytes: 0,
            interBytes: 0,
            internetBytes: 0,
            externalBytes: 0,
            policy: { type: 'UNKNOWN', name: '' },
            sourceIps: [],
            destinationIps: []
          };
          const portBucket = portBuckets[portIdx];
          newElement.port = portBucket.key.port;
          newElement.total.bytes = portBucket.incoming.value;
          newElement.total.incoming = portBucket.incoming.value;
          newElement.total.outgoing = portBucket.outgoing.value;
          this._categorizeBytes(sourceName, destinationName, newElement.total, newElement.total.bytes);

          const blockedBuckets = portBucket.blocked.buckets;
          for (let blockIdx = 0; blockIdx < blockedBuckets.length; blockIdx++) {
            const blockBucket = blockedBuckets[blockIdx];
            // --- Test if there are more distinct source or destination than aggregation processes and get them.
            if (blockBucket.source.buckets.length >= AGG_SIZE_FOR_SOURCE_DEST) {
              // --- do a paged query to retrieve all of the source IP addresses for the current port and blocked value
              logger.warn({ port: newElement.port, AGG_SIZE_FOR_SOURCE_DEST }, 'More than max ( AGG_SIZE_FOR_SOURCE_DEST ) source ip addresses for port, retrieving all with a paged aggregation. ');
              blockBucket.source.buckets = await this._getAllIpsForOneFieldForOnePort(esClient, searchJson, portBucket.key.port, blockBucket.key, 'source');
            }
            if (blockBucket.destination.buckets.length >= AGG_SIZE_FOR_SOURCE_DEST) {
              // --- do a paged query to retrieve all of the destination IP addresses for the current port and blocked value
              logger.warn({ port: newElement.port, AGG_SIZE_FOR_SOURCE_DEST }, 'More than max ( AGG_SIZE_FOR_SOURCE_DEST ) destination ip addresses for port, retrieving all with a paged aggregation. ');
              blockBucket.destination.buckets = await this._getAllIpsForOneFieldForOnePort(esClient, searchJson, portBucket.key.port, blockBucket.key, 'destination');
            }
            // --- Process the data into required format
            if (blockBucket.key === 0) {
              newElement.allowed.bytes = blockBucket.outgoing.value;
              newElement.allowed.incoming = blockBucket.incoming.value;
              newElement.allowed.outgoing = blockBucket.outgoing.value;
              this._categorizeBytes(sourceName, destinationName, newElement.allowed, newElement.allowed.bytes);
              const newPolicy = { type: 'UNKNOWN', name: '' };
              newPolicy.type = blockBucket.policy.hits.hits[0]._source.policyType;
              newPolicy.name = blockBucket.policy.hits.hits[0]._source.policyName;
              newPolicy.ruleId = blockBucket.policy.hits.hits[0]._source.ruleId;
              newPolicy.ruleName = blockBucket.policy.hits.hits[0]._source.ruleName;
              newPolicy.ruleDescription = blockBucket.policy.hits.hits[0]._source.ruleDescription;
              newElement.allowed.policy = newPolicy;
              if (blockBucket.source.buckets.length > AGG_SIZE_FOR_SOURCE_DEST) {
                //TODO: Add code to do a paged query to retrieve the source IP addresses for the current port
                logger.warn({ port: newElement.port }, 'More than max ( AGG_SIZE_FOR_SOURCE_DEST ) source ip addresses for port, only processing AGG_SIZE_FOR_SOURCE_DEST of them. ');
              }
              if (blockBucket.destination.buckets.length > AGG_SIZE_FOR_SOURCE_DEST) {
                //TODO: Add code to do a paged query to retrieve the destination IP addresses for the current port
                logger.warn({ port: newElement.port }, 'More than max ( AGG_SIZE_FOR_SOURCE_DEST ) destination ip addresses for port, only processing AGG_SIZE_FOR_SOURCE_DEST of them. ');
              }
              newElement.allowed.sourceIps = blockBucket.source.buckets.map(function (item) {
                return item['key'];
              });
              newElement.allowed.destinationIps = blockBucket.destination.buckets.map(function (item) {
                return item['key'];
              });
            } else if (blockBucket.key === 1) {
              newElement.blocked.bytes = blockBucket.incoming.value;
              newElement.blocked.incoming = blockBucket.incoming.value;
              newElement.blocked.outgoing = blockBucket.outgoing.value;
              this._categorizeBytes(sourceName, destinationName, newElement.blocked, newElement.blocked.bytes);
              const newPolicy = { type: 'UNKNOWN', name: '' };
              newPolicy.type = blockBucket.policy.hits.hits[0]._source.policyType;
              newPolicy.name = blockBucket.policy.hits.hits[0]._source.policyName;
              newPolicy.ruleId = blockBucket.policy.hits.hits[0]._source.ruleId;
              newPolicy.ruleName = blockBucket.policy.hits.hits[0]._source.ruleName;
              newPolicy.ruleDescription = blockBucket.policy.hits.hits[0]._source.ruleDescription;
              newElement.blocked.policy = newPolicy;
              newElement.blocked.sourceIps = blockBucket.source.buckets.map(function (item) {
                return item['key'];
              });
              newElement.blocked.destinationIps = blockBucket.destination.buckets.map(function (item) {
                return item['key'];
              });
            }
          }
          newElement.total.allowedBytes = newElement.allowed.bytes;
          newElement.total.blockedBytes = newElement.blocked.bytes;
          newElement.allBlocked = newElement.allowed.bytes <= 0 && newElement.blocked.bytes > 0;
          details.ports.push(newElement);
        }
      }

      let result = null;
      if (aggregationData.outgoing.value + aggregationData.incoming.value <= 0) {
        result = null;
        logger.warn({
          sourceName,
          destinationName
        }, 'Zero flows from source to destination, returning null from _aggDetails Parser');
      } else {
        result = {
          destination: destinationName,
          bytes: aggregationData.incoming.value,
          details: details,
          flowsList: flowsList
        };
      }

      logger.silly({ sourceName, destinationName, result }, 'Exit _aggDetailsParser');
      logger.silly('Exit _aggDetailsParser');
      return result;
    } else {
      const error = new Error('service not available');
      error.status = 503;
      // logger.warn({
      //   sourceName,
      //   destinationName
      // }, 'No Aggregation data (flows) from source to destination, returning null from _aggDetails Parser');
      const result = null;
      return result;
      // throw error;
    }
  }

  _categorizeFlowClass(sourceName, destinationName) {
    if (sourceName === 'INTERNET' || destinationName === 'INTERNET') {
      return 'INTERNET';
    } else if (sourceName === 'EXTERNAL' || destinationName === 'EXTERNAL') {
      return 'EXTERNAL';
    } else if (sourceName === destinationName) {
      return 'INTRA';
    } else {
      return 'INTER';
    }
  }

  _categorizeBytes(sourceName, destinationName, storeHere, byteCount) {
    if (sourceName === 'INTERNET' || destinationName === 'INTERNET') {
      storeHere.internetBytes += byteCount;
    } else if (sourceName === 'EXTERNAL' || destinationName === 'EXTERNAL') {
      storeHere.externalBytes += byteCount;
    } else if (sourceName === destinationName) {
      storeHere.intraBytes += byteCount;
    } else {
      storeHere.interBytes += byteCount;
    }
  }

  async _ribbonsFromSourceToFlowType(esClient, srcIndex, srcCollectionBatches, sourceUuids, sourceName, flowType, includeEphemeralPorts = true) {
    srcCollectionBatches = srcCollectionBatches.filter(a => a);
    try {
      const pageSize = (config.aggregation_page_size) || DEFAULT_AGGREGATION_PAGE_SIZE;
      const aggsJson = this._aggDetails(pageSize);
      const mustTerms = [
        {terms: {sourceUuid: sourceUuids}},
        {terms: {collectionBatch: srcCollectionBatches}},
        //                  { match: { blocked: 0 } },
        {match: {flowConnect: flowType}}
      ];
      mustTerms.push(NetworkUtils.getPortRangeEsCheck('sourceCollectionToFlowType', includeEphemeralPorts));
      const searchJson = {
        //headers:esClient.rfHeaders,
        index: srcIndex,
        scroll: '10s',
        size: 1000,
        body: {
          query: {
            bool: {
              filter: [
                {
                  bool: {
                    must: mustTerms
                  }
                }
              ]
            }
          },
          aggs: aggsJson
        }
      };

      // --- rate limit the number of active scrolls
      await this._waitForActiveScrollIdRateLimit();

      this._incrementActiveScrollIdCount('source-to-type');

      const body = await esClient.search(searchJson);

      logger.silly({body, srcIndex, sourceName, flowType}, 'Success getting ribbons from source for flow type');
      // let result = {destination: flowType, bytes: aggregationData.sourceBytes.value}
      const result = await this._aggDetailsParser(esClient, sourceName, flowType, body, searchJson);
      return(result);
    } catch(error) {
        this._decrementActiveScrollIdCount('source-to-type')
        logger.silly({ error: error.message }, 'Error (in _ribbonsFromSourceToFlowType) getting ribbons from source for flow type');
        throw error;
    }
  }

  async _ribbonsFromFlowTypeToDestination(esClient, dstIndex, dstCollectionBatches, dstUuids, destinationName, flowType, includeEphemeralPorts=false) {
    try {
      logger.silly('Enter _ribbonsFromFlowTypeToDestination');
      logger.silly({
        dstIndex,
        dstCollectionBatches,
        destinationName,
        flowType
      }, 'Enter _ribbonsFromFlowTypeToDestination');
      const pageSize = (config.aggregation_page_size) || DEFAULT_AGGREGATION_PAGE_SIZE;
      const aggsJson = this._aggDetails(pageSize);
      dstCollectionBatches = dstCollectionBatches.filter(a => a);
      const mustTerms = [
        {terms: {destinationUuid: dstUuids}},
        {terms: {collectionBatch: dstCollectionBatches}},
        //                  { match: { blocked: 0 } },
        {match: {flowConnect: flowType}}
      ];
      mustTerms.push(NetworkUtils.getPortRangeEsCheck('flowTypeToDestinationCollection', includeEphemeralPorts));
      const searchJson = {
        //headers:esClient.rfHeaders,
        index: dstIndex,
        scroll: '10s',
        size: 1000,
        body: {
          query: {
            bool: {
              filter: [
                {
                  bool: {
                    must: mustTerms
                  }
                }
              ]
            }
          },
          aggs: aggsJson
        }
      };

      // --- rate limit the number of active scrolls
      await this._waitForActiveScrollIdRateLimit();

      this._incrementActiveScrollIdCount('type-to-dest');
      const body = await esClient.search(searchJson);

      logger.silly({
        body,
        dstIndex,
        destinationName,
        flowType
      }, 'Success getting ribbons from source for flow type');
      // let result = {destination: destinationName, bytes: body.aggregations.sourceBytes.value}
      const result = await this._aggDetailsParser(esClient, flowType, destinationName, body, searchJson);
      return(result);
    } catch(error) {
      this._decrementActiveScrollIdCount('type-to-dest')
      logger.silly({error: error.message}, 'Error (in _ribbonsFromFlowTypeToDestination) getting ribbons from source for flow type');
      throw error;
    }
  }

  // aggs: {
  //    flowCount : { value_count : { field : "flowConnect" }},
  //    sourceBytes: {sum: {field: 'sourceBytes'}}
  // }

  _trafficFlowOverTime(esClient, indexes, collectionBatches, uuids, timeInterval) {
    logger.silly({ timeInterval, uuids, indexes, collectionBatches }, 'Enter _trafficFlowOverTime');
    return new Promise((resolve, reject) => {
      collectionBatches = collectionBatches.filter(elem => {
        return elem;
      });
      const searchTerm = {
        //headers:esClient.rfHeaders,
        index: indexes,
        size: 0,
        ignoreUnavailable: true,
        body: {
          query: {
            bool: {
              filter: {
                bool: {
                  must: [
                    { terms: { collectionBatch: collectionBatches } },
                    { match: { blocked: 0 } }
                  ],
                  must_not: [{ match: { flowConnect: 'CONTROL' } }],
                  should: [{ terms: { sourceUuid: uuids } }, { terms: { destinationUuid: uuids } }]
                }
              }
            }
          },
          aggs: {
            trafficOverTime: {
              date_histogram: {
                field: 'collectionTime',
                interval: timeInterval,
                format: 'yyyy-MM-dd'
              },
              aggs: {
                incoming: { sum: { field: 'sourceBytes' } },
                outgoing: { sum: { field: 'destinationBytes' } }
              }
            }
          }
        }
      };
      esClient
        .search(searchTerm)
        .then(body => {
          logger.silly({ body, indexes }, 'Success retrieving in _trafficFlowOverTime');
          // TODO parse the body into result
          const result = body;
          resolve(result);
        })
        .catch(error => {
          logger.silly({ error: error.message }, 'Error in _trafficFlowOverTime');
          reject(error);
        });
    });
  }

  _sortFlowBytesBy(esClient, indexes, collectionBatches, uuids, timeInterval, sortByField, includeEphemeralPorts = true) {
    logger.silly({ timeInterval, uuids, indexes, collectionBatches, sortByField }, 'Enter _sortFlowBytesBy');
    collectionBatches = collectionBatches.filter(elem => {
      return elem;
    });
    const mustTerms = [
      { terms: { collectionBatch: collectionBatches } },
      { match: { blocked: 0 } },
      { bool: { should: [{ terms: { sourceUuid: uuids } }, { terms: { destinationUuid: uuids } }] } }
    ];
    mustTerms.push(NetworkUtils.getPortRangeEsCheck('sortFlowBytesBy', includeEphemeralPorts));
    const searchQuery = {
      //headers:esClient.rfHeaders,
      index: indexes,
      size: 0,
      ignoreUnavailable: true,
      body: {
        query: {
          bool: {
            filter: {
              bool: {
                must: mustTerms,
                must_not: [{ match: { flowConnect: 'CONTROL' } }]
              }
            }
          }
        },
        aggs: {
          // eslint-disable-next-line quotes
          totalBytes: { sum: { script: 'doc[\'sourceBytes\'].value' } },
          destinationBytes: { sum: { field: 'destinationBytes' } },
          sortBy: {
            terms: { field: sortByField, size: 1000 },
            aggs: {
              // eslint-disable-next-line quotes
              totalBytes: { sum: { script: 'doc[\'sourceBytes\'].value' } },
              destinationBytes: { sum: { field: 'destinationBytes' } },
              sorting: { bucket_sort: { sort: [{ totalBytes: { order: 'desc' } }] } }
            }
          }
        }
      }
    };
    return new Promise((resolve, reject) => {
      esClient
        .search(searchQuery)
        .then(body => {
          logger.silly({ body, indexes }, 'Success retrieving in _sortFlowBytesBy');
          // TODO parse the body into result
          const result = body;
          resolve(result);
        })
        .catch(error => {
          logger.silly({ error: error.message, stack: error.stack }, 'Error in _sortFlowBytesBy');
          reject(error);
        });
    });
  }

  _trafficFlow(esClient, indexes, collectionBatches, uuids) {
    logger.silly({ uuids, indexes, collectionBatches }, 'Enter _trafficFlow');
    collectionBatches = collectionBatches.filter(a => a);

    return new Promise((resolve, reject) => {
      esClient
        .search({
          //headers:esClient.rfHeaders,
          index: indexes,
          size: 0,
          ignoreUnavailable: true,
          body: {
            query: {
              bool: {
                filter: {
                  bool: {
                    must: [
                      { terms: { collectionBatch: collectionBatches } },
                      { match: { blocked: 0 } }],
                    must_not: [{ match: { flowConnect: 'CONTROL' } }],
                    should: [{ terms: { sourceUuid: uuids } }, { terms: { destinationUuid: uuids } }]
                  }
                }
              }
            },
            aggs: {
              flowCount: { value_count: { field: 'flowConnect' } },
              incoming: { sum: { field: 'sourceBytes' } },
              outgoing: { sum: { field: 'destinationBytes' } },
              // eslint-disable-next-line quotes
              total: { sum: { script: 'doc[\'sourceBytes\'].value + doc[\'destinationBytes\'].value' } }
            }
          }
        })
        .then(body => {
          logger.silly({ body, indexes }, 'Success retrieving in _trafficFlow');
          const result = body;
          resolve(result);
        })
        .catch(error => {
          logger.silly({ error: error.message }, 'Error in _trafficFlow');
          reject(error);
        });
    });
  }

  _rawFlows(esClient, indexes, collectionBatches, uuids, from, size) {
    logger.silly({ uuids, indexes, collectionBatches }, 'Enter _rawFlows');
    return new Promise((resolve, reject) => {
      esClient
        .search({
          //headers:esClient.rfHeaders,
          index: indexes,
          from: from,
          size: size,
          ignoreUnavailable: true,
          _source_includes: [
            'ruleId',
            'ruleName',
            'source',
            'destination',
            'sourceUuid',
            'destinationUuid',
            'protocol',
            'destinationPort',
            'servicePort',
            'blocked',
            'policyName',
            'sourceBytes',
            'destinationBytes',
            'startTimeFormatted',
            'endTimeFormatted'
          ],
          body: {
            query: {
              bool: {
                filter: {
                  bool: {
                    must: [{ terms: { collectionBatch: collectionBatches } }],
                    must_not: [{ match: { flowConnect: 'CONTROL' } }],
                    should: [{ terms: { sourceUuid: uuids } }, { terms: { destinationUuid: uuids } }]
                  }
                }
              }
            }
          }
        })
        .then(body => {
          logger.silly({ indexes }, 'Success retrieving in _rawFlows');
          const result = body.hits.hits;
          resolve(result);
        })
        .catch(error => {
          logger.silly({ error: error.message }, 'Error in _rawFlows');
          reject(error);
        });
    });
  }

  // ------------------------------------------------------

  _countFlows(esClient, indexes, collectionBatches, uuids) {
    logger.silly({ uuids, indexes, collectionBatches }, 'Enter _countFlows');
    collectionBatches = collectionBatches.filter(elem => {
      return elem;
    });
    return new Promise((resolve, reject) => {
      esClient
        .count({
          index: indexes,
          body: {
            query: {
              bool: {
                filter: {
                  bool: {
                    must: [
                      { terms: { collectionBatch: collectionBatches } },
                      { match: { blocked: 0 } }],
                    must_not: [{ match: { flowConnect: 'CONTROL' } }],
                    should: [{ terms: { sourceUuid: uuids } }, { terms: { destinationUuid: uuids } }]
                  }
                }
              }
            }
          }
        })
        .then(body => {
          logger.silly({ body, indexes }, 'Success retrieving in _countFlows');
          const result = body;
          resolve(result);
        })
        .catch(error => {
          logger.silly({ error: error.message }, 'Error in _countFlows');
          reject(error);
        });
    });
  }

  // -------------------------------------------------
  // _calculateIndexesAndBatches
  //   Creates the this.curCollectionBatches variable
  //
  //  Input:
  //      yyyymmdd - the date to create indexes for, must be a string in format yyyy-mm-dd
  //      type - a string inserted into the index name (e.g. 'flows', 'secgroups', etc)
  //      indexAndBatches - an map where each entry is indexed by the key yyyymmdd and the value associated
  //            with the key is {indexes:[], collectionBatches:[]}
  //
  //  Output (a number of policies that represent in the assetGroups):
  //      <none>, but this.indexesAndBatchs[yyyymmdd].collectionBatches and .indexes will be set up for use
  //
  async _calculateIndexesAndBatches(yyyymmdd, containerName, type, indexAndBatches) {
    try {
      logger.silly({ yyyymmdd, containerName, type, indexAndBatches }, 'Enter _calculateIndexesAndBatches');
      let curCollectionBatches = null;
      let curIndexes = null;
      const key = yyyymmdd + ':' + containerName;
      const curIndexAndBatches = indexAndBatches[key];
      logger.silly({ key, curIndexAndBatches }, 'determining the available index and batches for key');

      // fixme this doesn't do anything since the variable is local to the if
      if (curIndexAndBatches != null) {
        curCollectionBatches = curIndexAndBatches.collectionBatches;
        curIndexes = curIndexAndBatches.indexes;
      }
      if (curCollectionBatches == null) {
        curCollectionBatches = [];
        if (curIndexes == null) {
          curIndexes = [];

          logger.silly({
            key,
            assetGroupLength: this.assetGroups.length
          }, '..In _calculateIndexesAndBatches, about to create indexes');
          for (let i = 0; i < this.assetGroups.length; i++) {
            logger.silly({
              key,
              assetGroupName: this.assetGroups[i].containerName,
              containerName
            }, '..In _calculateIndexesAndBatches, determining if should create index');
            if (this.assetGroups[i].containerName === containerName) {
              const location = this.assetGroups[i].members.options.location;
              const serviceProvider = this.assetGroups[i].members.options.serviceProvider;
              let organizationIn = this.assetGroups[i].members.options.organization;

              if (!Array.isArray(organizationIn)){
                organizationIn = [organizationIn];
              }

              for (const organization of organizationIn) {
                if (type && type.includes('flow')) {
                  // logger.warn({ type, containerName }, 'BEFORE selectFlowIndexRootName in _calculateIndexesAndBatches');
                  type = await NetworkUtils.selectFlowIndexRootName(this.client,
                      organization, location, serviceProvider, yyyymmdd);
                  // logger.warn({ type, containerName }, 'AFTER selectFlowIndexRootName in _calculateIndexesAndBatches');
                }
                // logger.warn({
                //   type,
                //   containerName
                // }, 'AFTER/AFTER selectFlowIndexRootName in _calculateIndexesAndBatches');
                const index = 'caveonetwork-' + organization + '-' + location
                    + '-' + serviceProvider + '-' + type + '*-' + yyyymmdd;
                logger.silly({key, index},
                    '..In _calculateIndexesAndBatches, index created');
                //TODO:  Is this correct?  I think it is a comma delimited string...not an array
                curIndexes.push(index);
              }
            }
          }
        }
        logger.silly({ curIndexes }, 'In _calculateIndexesAndBatches, finding collectionBatches for these indexes');
        await NetworkUtils.getMostRecentCollectionBatchForIndexList(this.client, curIndexes, curCollectionBatches);
        logger.silly({ key, curCollectionBatches, curIndexes }, 'Success in _calculateIndexesAndBatches');
        const indexAndBatchesValue = {
          collectionBatches: curCollectionBatches,
          indexes: curIndexes
        };
        indexAndBatches[key] = indexAndBatchesValue;
        // logger.info(
        //   {
        //     indexAndBatchesValue,
        //     key,
        //     indexAndBatchesForDate: indexAndBatches[key],
        //     indexes: indexAndBatches[key].indexes,
        //     batches: indexAndBatches[key].collectionBatches
        //   },
        //   'Resolving in NetworkFlows._calculateIndexesAndBatches'
        // );
        return;
      } else {
        return;
      }
    } catch (error) {
      logger.silly({ error, stack: error.stack }, 'Error in _calculateIndexesAndBatches');
      throw error;
    }
  }

  async _collectAllCollectionBatches(curIndexes) {
    logger.silly({ curIndexes }, 'Enter _collectAllCollectionBatches');

    try {
      const curCollectionBatches = [];
      logger.silly({ curIndexes }, 'In _collectAllCollectionBatches, finding collectionBatches for these indexes');
      await NetworkUtils.getMostRecentCollectionBatchForIndexList(this.client, curIndexes, curCollectionBatches);
      logger.silly({ curCollectionBatches, curIndexes }, 'Success in _collectAllCollectionBatches');
      return curCollectionBatches;

    } catch (error) {
      logger.silly({ error: error.message }, 'Failed waiting for all promises in _collectAllCollectionBatches');
      throw error;
    }
  }

}

module.exports = NetworkFlowsElasticsearch;
