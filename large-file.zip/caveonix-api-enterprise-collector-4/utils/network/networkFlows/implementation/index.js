const elasticsearch = require('./NetworkFlowsElasticsearch');
module.exports = { elasticsearch };
