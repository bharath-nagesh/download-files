const logger = require('../../logger.js').logger.child({});

class NetworkFlowsInterface {
  // ============================================================================================
  // Creation function - called once, and only once, immediately after constructor.
  // ============================================================================================

  // params must include
  // NOTE: containerName MUST be unique within this list of assetGroups
  //   Input:
  //      assetGroups -
  //                      [
  //                          {
  //                              containerName: <name Of container>,
  //                              members:    {
  //                                              options:{
  //                                                  location:   <location id from which the assets come>,
  //                                                  serviceProvider: <service provider id from which the assets come>,
  //                                                  organization:    <organization id from which the assets come>
  //                                                  },
  //                                             objects: [
  //                                                        uuid: <instance uuid of asset>,
  //                                                        ...
  //                                                      ]
  //                                          }
  //                          },
  //                          ...
  //                      ]
  //      hostPort -- ElasticSearch host:port address (e.g.  localhost:9200)
  //      log -- (optional) the log level for elasticSearch client library
  //      cache -- used to cache results for quicker response times on second and subsequent calls for a time period
  //      refresh -- (optional)  if true then data will not be retrieved from cache, but instead will be recalculated.  if false, then retrieval from cache will be attempted
  constructor(assetGroups, hostPort, userName, UserPass, cache = null, refresh = false, token = null, authToken = null, log = 'warning') {
    logger.silly('Base implementation for NetworkFlows called for constructor');
  }

  // ============================================================================================
  // PUBLIC functions - available from instantiated object.  The 'this' variable is available
  // ============================================================================================

  // ----------------------------------
  // getMostRecentDateWithData
  //   Will provide the most recent date that has flows data
  getMostRecentDateWithData(organization = '*', location = '*', serviceProvider = '*') {
    logger.error('Base implementation for NetworkFlows called for createNetworkFlows called.  This' +
      ' should have been overridden by implementation');
  }

  // ----------------------------------
  // calculateRibbons
  //   Will provide statistics and a list of network ribbons between groups of assets.
  //
  //   Input:
  //      date -   The UTC date to begin searching for links.  Format:  YYYY-MM-DD
  //      timeFrame - The period of time over which to calculate links (it looks for links that occurred during the
  //                  time frame.   The time frame is from the startDate backwards in time.
  //
  //  Output (an object with a list of source groups and the ribbons from them to other groups):
  //  {
  //    totalBytes: <number of bytes transferred between the unique list of assets, not the containers.
  //                    This might be less than
  //                    totalBytesBetweenContainers if an asset exists in more than one container>
  //    totalBytesForContainers: <number of bytes sent between, within, to internet or external for all these containers,
  //                               may be larger than totalBytes because assets may be in more than one container>,
  //    intraBytes: <number of bytes sent between assets in the same containers>,
  //    interBytes: <number of bytes sent between assets in different containers>,
  //    internetBytes: <number of bytes sent from unique list of assets to internet>,
  //    internetForContainers: <number of bytes from assets in containers to internet, may be larger than internetBytes
  //                                 because assets may be in more than one container>
  //    externalBytes: <number of bytes sent from unique list of assets to an IP that is not container or internet>
  //    externalForContainers:  <number of bytes from assets in containers to an IP that is not container or internet,
  //                                    may be larger than externalBytes because assets may be in more than one container>
  //     containers:  [
  //                      {
  //                          containerName: <name of container>,
  //                          totalBytes: <number of bytes sent from this container>,
  //                          intraBytes: <number of bytes sent between assets within this container>,
  //                          interBytes: <number of bytes sent from this container to another container>,
  //                          internetBytes: <number of bytes sent from this container to internet>,
  //                          externalBytes: <number of bytes sent from this container that was not to another
  //                                              container and not to the internet>
  //                          ribbons:
  //                              [
  //                                  {
  //                                      destination:  <containerName>,
  //                                      bytes: <bytes from source container to this destination container>
  //                                  },
  //                                  ...
  //                                  {
  //                                      destination: INTERNET,
  //                                      bytes: <bytes from source container sent to internet
  //                                  },
  //                                  {
  //                                      destination: EXTERNAL,
  //                                      bytes: <bytes from source container sent to neither internet or another container>
  //                                  }
  //                              ]
  //                      },
  //                      ...
  //                      {
  //                          containerName: INTERNET,
  //                          <same as other containers (see above), but this is for traffic from Internet>
  //                      },
  //                      {
  //                          containerName: EXTERNAL,
  //                          <same as other containers (see above), but this is for traffic from External sources>
  //                      },
  //                ]
  // }
  //
  //
  //  If there is no data for the date provided the data structure above is returned with empty/0 values
  async getNetworkDataForAsset(orgId, vmId, date = null) {
    logger.error('Base implementation for NetworkFlows called for createNetworkFlows called.  This' +
      ' should have been overridden by implementation');
  }

  async calculateRibbons(date = new Date(), timeFrame = 'day') {
    logger.error('Base implementation for NetworkFlows called for createNetworkFlows called.  This' +
      ' should have been overridden by implementation');
  }

  // ----------------------------------
  // calculateTrafficOverTime
  //   Will provide a list of dayes and the incoming number of bytes and outgoing number of bytes.
  //
  //   Input:
  //      mostRecentDate -   The most recent UTC date for which to provide incoming/outgoing bytes.  Format:  YYYY-MM-DD
  //      aggregatePeriod - The length of time over which to aggregate the sums of incoming/outgoing bytes: daily,
  //                          weekly, monthly, quarterly, yearly
  //      numberOfAggregationPeriods -  How many aggregation periods to provide
  //
  //  Output (a list of links to draw between assetGroups):
  //      [
  //          {
  //           date: yyyy-mm-dd,
  //           dateAsEpochWithMilliseconds: <long int>
  //           incomingBytes: <number of incoming bytes>,
  //           outgoingBytes: <number of outgoing bytes>
  //          }
  //      ]
  //
  // For days that have no data there will be no entry.  For days that have data there will be an entry, it
  //   is possible that the values will be 0 for that day.  This typically means there was data but it
  //   is incomplete.
  //
  // NOTE: Not using CACHE
  // NOTE: NO CACHE
  async calculateTrafficOverTime(startDate = new Date(), timeFrame = 'day') {
    logger.error('Base implementation for NetworkFlows called for createNetworkFlows called.  This' +
      ' should have been overridden by implementation');
  }

  // ----------------------------------
  // statisitics
  //   For the assets of the object, it calculates a list of statistics
  //
  //  Input:
  //      date -   The UTC date to begin calculation.  Format:  YYYY-MM-DD
  //      timeFrame - The period of time over which to calculate.   The time frame is from the date backwards in time.
  //
  //  Output (a json object with a set of statistic values):
  //      {
  //          totalTraffic: <number of bytes transferred>,
  //          intraBytes:  <number of bytes between assets within groups>,
  //          intraPercentage:  <percentage of totalTraffic that is intraGroup>,
  //          interBytes:  <number of bytes between assets in different groups>,
  //          interPercentage:  <percentage of totalTraffic that is interGroup>,
  //          externalBytes:  <number of bytes between assets and external entities>,
  //          exeternalPercentage:  <percentage of totalTraffice that is external>,
  //          internetBytes:  <number of bytes between assets and internet entities>,
  //          internetPercentage:  <percentage of totalTraffice that is internet>,
  //          totalFlows:  <number of flows>,
  //          totalFlowBytes:  <number of bytes for totalFlows>
  //      }
  //
  //  The output if there is no data for the day provided there will be zeros (0) for the values.
  // NOTE: USING CACHE
  // NOTE: CACHE
  statistics(startDate = new Date(), timeFrame = 'day') {
    logger.error('Base implementation for NetworkFlows called for createNetworkFlows called.  This' +
      ' should have been overridden by implementation');
  }

  // ----------------------------------
  // sortFlowsByPort
  //   For the assets of the object, it produces a list of network ports sorted by number of bytes passed on that port
  //
  //  Input:
  //      date -   The UTC date to begin calculation.  Format:  YYYY-MM-DD
  //      timeFrame - The period of time over which to calculate.   The time frame is from the date backwards in time.
  //
  //  Output (an array of ports sorted from the port with the most bytes to the least bytes):
  //      [
  //        {
  //          port: <port number>,
  //          bytes:  <bytes passed on this port>
  //        },
  //        ...
  //      ]
  //
  //   If the day provided has no data then the output is an empty list:  []
  // NOTE: NO CACHE
  async sortFlowsByPort(startDate = new Date(), timeFrame = 'day') {
    logger.error('Base implementation for NetworkFlows called for createNetworkFlows called.  This' +
      ' should have been overridden by implementation');
  }

  // ----------------------------------
  // sortFlowsByContainer
  //   For the assets of the object, it produces a list of containers sorted by number of bytes passed on that group,
  //     and provides breakdown of total bytes by incoming and outgoing
  //
  //  Input:
  //      date -   The UTC date to begin calculation.  Format:  YYYY-MM-DD
  //      timeFrame - The period of time over which to calculate.   The time frame is from the date backwards in time.
  //
  //  Output (an array of ports sorted from the port with the most bytes to the least bytes):
  //      [
  //        {
  //          container: <containerName from assetGroups>,
  //          incoming: <incoming bytes passed to the group>,
  //          outgoing: <outgoing bytes passed from the group>
  //        },
  //        ...
  //      ]

  //                          {
  //                              containerName: <name Of container>,
  //                              members:    {
  //                                              options:{
  //                                                  location:   <location id from which the assets come>,
  //                                                  serviceProvider: <service provider id from which the assets come>,
  //                                                  organization:    <organization id from which the assets come>
  //                                                  },
  //                                             objects: [
  //                                                        uuid: <instance uuid of asset>,
  //                                                        ...
  //                                                      ]
  //                                          }
  //                          }
  //
  //  If there is no data for the day provided then the output is displayed by this example:
  //   [
  //     {
  //       "container": "SAP",
  //       "incoming": 0,
  //       "outgoing": 0,
  //       "total": 0
  //     },
  // {
  //   "container": "ERP",
  //   "incoming": 0,
  //   "outgoing": 0,
  //   "total": 0
  // },
  // {
  //   "container": "Oracle",
  //   "incoming": 0,
  //   "outgoing": 0,
  //   "total": 0
  // }
  // ]
  // NOTE: NO CACHE
  async sortFlowsByContainer(startDate = new Date(), timeFrame = 'day') {
    logger.error('Base implementation for NetworkFlows called for sortFlowsByContainer called.  This' +
      ' should have been overridden by implementation');
  }

  // ---------------------------------
  // output:
  //      [
  //       {container: name
  //        flows: [
  //                       {ruleId: xxxxx, src: xxxxxx, dst: xxxxxx, srcUuid: xxxxx, dstUuid: xxxxx,
  //                         protocol: xxxx, port: xxxxx, blocked: xxxxxx, policy: xxxxxx,
  //                         outgoingBytes: xxxxx, incomingBytes: xxxxx, startTime: xxxx, endTime: xxxxx},...
  //              ]
  //       },...
  //     ]
  //
  //  If there is no data for the day provided:
  //
  //   [
  //     {
  //       "container": "Boston",
  //       "flows": []
  //     },
  // {
  //   "container": "London",
  //   "flows": []
  // }
  // ]
  //
  // NOTE: NO CACHE
  getRawFlows(startDate = new Date(), from = 0, size = 100) {
    logger.error('Base implementation for NetworkFlows called for getRawFlows called.  This' +
      ' should have been overridden by implementation');
  }
}

module.exports = NetworkFlowsInterface;
