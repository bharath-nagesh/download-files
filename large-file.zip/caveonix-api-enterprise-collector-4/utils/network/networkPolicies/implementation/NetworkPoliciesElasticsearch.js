const elasticsearch = require('elasticsearch');
const config = require('../../../../configure').get();
const { get } = require('lodash');
const NetworkPoliciesInterface = require('../NetworkPoliciesInterface');
const NetworkFlowsFactory = require('../../networkFlows/NetworkFlowsFactory');
const NetworkDashboardFactory = require('../../networkDashboard/NetworkDashboardFactory');
const NetworkUtilsFactory = require('../../networkUtils/NetworkUtilsFactory');
const NetworkUtils = NetworkUtilsFactory.createNetworkUtils();
var url = require('url');
const logger = require('../../../logger.js').logger.child({
});

class NetworkPoliciesElasticsearch extends NetworkPoliciesInterface {
  // ============================================================================================
  // CONSTRUCTOR function - called when an object is instantiated.
  // ============================================================================================

  // params must include
  //   Input:
  //      assetGroups -
  //                      [
  //                          {
  //                              groupName: <name Of assetGroup>,
  //                              members:    [
  //                                              {
  //                                                  location:   <location id from which the assets come>
  //                                                  serviceProvider:   <service provider id from which the assets come>
  //                                                  organization:    <organization id from which the assets come>
  //                                                  assets: [
  //                                                              uuid: <instance uuid of asset>,
  //                                                              ...
  //                                                          ]
  //                                              },
  //                                              ...
  //                                          ]
  //                          },
  //                          ...
  //                      ]
  //      hostPort -- ElasticSearch host:port address (e.g.  localhost:9200)
  //      log -- (optional) the log level for elasticSearch client library
  constructor(assetGroups, hostPort,userName,userPass, token = null, authToken = null, log = 'warning') {
    super(assetGroups, hostPort, userName, userPass, token, authToken, log);
    logger.silly('Enter NetworkPolicies constructor');
    var q = url.parse(hostPort, true);
    this.hostPort = hostPort;
    this.assetGroups = assetGroups;
    this.es_UserName=userName;
    this.es_UserPassword=userPass;
    this.timeout = (config.elastic_timeout_in_seconds * 1000) || 300000;
    if (config.forensics_enabled == true) {
      this.client = new elasticsearch.Client({
        host:{
          protocol: q.protocol,
          host: q.host.split(':')[0],
          port: q.port,
          headers: {
            Authorization: token,
            RiskForesight: token
          }
        },
        log: log,
        maxSockets: 100,
        requestTimeout: this.timeout
      });
    }else{
      this.client = new elasticsearch.Client({
        host: q.protocol+'//'+userName+':'+userPass+'@'+q.host+'/',
        log: log
      });
    }

    if (this.client == null) {
      logger.error('Unable to create elasticsearch client.');
    }
    this._resetNetworkPolicyData();

    logger.silly('Exit NetworkPolicies constructor');
  }

  // ============================================================================================
  // PUBLIC functions - available from instantiated object.  The 'this' variable is available
  // ============================================================================================

  // ----------------------------------
  // getMostRecentDateWithData
  //   Will provide the most recent date that has policy data
  getMostRecentDateWithData(organization = '*', location = '*', serviceProvider = '*') {
    return NetworkUtils.getMostRecentDateWithData(this.client, 'secpolicies', organization, location, serviceProvider);
  }

  // ----------------------------------
  // calculatePolicy
  //   Will provide the security policies applied to groups of assets
  //
  //  Input:
  //      date -  <the UTC date to calculate policy for.  Format:  YYYY-MM-DD, special value: 'NOW' will be for
  //                current date>
  //
  //  Output (a recursive set of bubbles to draw for assetGroups):
  //      [
  //          {
  //           type:  <"asset", "policy", "secGroup", "appGroup">,
  //           name:  <name of the object>,
  //           children:  [
  //                          {
  //                              type: <"asset", "securityPolicy", "securityGroup", "container">,
  //                              name: <name of the object>,
  //                              distributedFirewallRules: [ <only present if type is "policy">
  //
  //                              children:   [
  //                                          ... continues this recursion until all objects described
  //                                          ]
  //                          },
  //                          ...
  //                      ]
  //          },
  //          ...
  //      ]
  //
  //  If the date provided has no data then the output is similar to this example:
  // {
  //   "totalFirewallRuleCount": 0,
  //   "policyRuleCountArray": [],
  //   "policyDfwSectionArray": [],
  //   "policyAllowRuleCountArray": [],
  //   "policyDenyRuleCountArray": [],
  //   "policyPortsArray": [],
  //   "policySourcePortsArray": [],
  //   "policyAssetsArray": [],
  //   "policyFirewallRulesMap": {},
  //   "policyAssetCountArray": [],
  //   "totalAssetsNotCoveredByPolicy": 5,
  //   "secGroupMapOfAssets": {},
  //   "assetMap": {
  //     "502741d6-259e-7e76-cf17-ccca5fa3f1c4": {
  //       "name": "502741d6-259e-7e76-cf17-ccca5fa3f1c4",
  //       "type": "asset",
  //       "container": "SAP"
  //     },
  //     "fakeUuid1": {
  //       "name": "fakeUuid1",
  //       "type": "asset",
  //       "container": "SAP"
  //     },
  //     "fakeUuid2": {
  //       "name": "fakeUuid2",
  //       "type": "asset",
  //       "container": "SAP"
  //     },
  //     "50270e63-371f-c23a-21a7-b13fe64a405f": {
  //       "name": "50270e63-371f-c23a-21a7-b13fe64a405f",
  //       "type": "asset",
  //       "container": "ERP"
  //     },
  //     "5027243d-3422-72a0-87b3-a41ffd4f78f0": {
  //       "name": "5027243d-3422-72a0-87b3-a41ffd4f78f0",
  //       "type": "asset",
  //       "container": "Oracle"
  //     }
  //   },
  //   "policies": [
  //     {
  //       "type": "container",
  //       "name": "SAP",
  //       "children": []
  //     },
  //     {
  //       "type": "container",
  //       "name": "ERP",
  //       "children": []
  //     },
  //     {
  //       "type": "container",
  //       "name": "Oracle",
  //       "children": []
  //     }
  //     ]
  // }

  async calculatePolicy(startDate = new Date(), timeFrame = 'day') {
    logger.silly({ startDate }, 'Enter calculatePolicy');

    if (startDate == null) {
      logger.silly('No startDate provided.');
      throw new Error('No startDate provided.');
    }
    if (timeFrame != 'day') {
      logger.silly({ timeFrame }, 'timeFrame provided is not supported');
      throw new Error('timeFrame provided is not supported');
    }
    let yyyymmdd;
    try {
      yyyymmdd = NetworkUtils.getYYYY_MM_DD(startDate);
    } catch (e) {
      logger.error({ e, stack: e.stack }, 'error occurred calculate policy getting date');
      throw e;
    }
    // --- if assetGroups is empty then return empty list
    if (this.assetGroups != null && this.assetGroups.length <= 0) {
      // Cache the results for potential later use
      const retval = {};
      retval.totalFirewallRuleCount = 0;
      retval.policyRuleCountArray = [];
      retval.policyDfwSectionArray = [];
      retval.policyPortsArray = [];
      retval.policySourcePortsArray = [];
      retval.policyAssetsArray = [];
      retval.policyFirewallRulesMap = {};
      retval.policyAssetCountArray = [];
      retval.totalAssetsNotCoveredByPolicy = 0;
      retval.secGroupMapOfAssets = {};
      retval.assetMap = {};
      retval.policies = [];
      this.policyResults[yyyymmdd] = retval;
      return retval;
    } else {
      try {
        const thePromises = [];
        const policyStats = {};
        policyStats.policyFirewallRuleCountMap = {};
        policyStats.policyFirewallRules = {};
        policyStats.policyFirewallRulesMap = {};
        policyStats.policyAssetCountsMap = {};
        policyStats.policyAssetCountMap = {};
        policyStats.UuidsCoveredByPolicySet = {};
        policyStats.allUuidsSet = {};
        policyStats.policyAssetsMap = {};
        policyStats.policyRuleCountMap = {};
        policyStats.policyDfwSectionMap = {};
        policyStats.policyAllowRuleCountMap = {};
        policyStats.policyDenyRuleCountMap = {};
        policyStats.policyPortsMap = {};
        policyStats.policySourcePortsMap = {};
        policyStats.secGroupMapOfAssets = {};
        policyStats.assetMap = {};

        const allIndexes = this._getAllIndexes(yyyymmdd, 'secpolicies', this.indexAndBatchesForFlows);
        const allCollectionBatches = await this._collectAllCollectionBatches(allIndexes);

        logger.silly({ allIndexes, allCollectionBatches }, 'Calling _retrieveUniquePolicyNames');
        const securityPolicyNames = await this._retrieveUniquePolicyNames(this.client, allIndexes, allCollectionBatches);

        logger.silly({ securityPolicyNames }, 'Success in getting policy names');
        for (let i = 0; i < securityPolicyNames.length; i++) {
          const name = securityPolicyNames[i];
          policyStats.policyAssetsMap[name] = [];
          policyStats.policyRuleCountMap[name] = 0;
          policyStats.policyDfwSectionMap[name] = '';
          policyStats.policyAllowRuleCountMap[name] = 0;
          policyStats.policyDenyRuleCountMap[name] = 0;
          policyStats.policyPortsMap[name] = [];
          policyStats.policySourcePortsMap[name] = [];
          policyStats.policyFirewallRules[name] = [];
          policyStats.policyFirewallRulesMap[name] = [];
          policyStats.policyFirewallRuleCountMap[name] = 0;
          policyStats.policyAssetCountsMap[name] = 0;
          policyStats.policyAssetCountMap[name] = 0;
        }
        logger.silly({ policyAssetsMap: policyStats.policyAssetsMap }, 'initial policy assets map');

        logger.silly('Starting loop in calculatePolicy');

        // Retrieve the policies for each container, this has a side-effect of altering policyStats
        for (let i = 0; i < this.assetGroups.length; i++) {
          const container = this.assetGroups[i];
          thePromises.push(this._getPoliciesForOneContainer(yyyymmdd, container, policyStats));
        }

        //  Wait for results of retrieval, then process the policies
        const results = await Promise.all(thePromises);

        logger.silly({ results }, 'Retrieved data in calculatePolicy');
        const retvalPolicies = [];

        // Create one output element per container
        for (let i = 0; i < results.length; i++) {
          const oneResult = results[i];
          const newEntry = {};
          newEntry.type = 'container';
          newEntry.policyNames = oneResult.policyNames;
          newEntry.firewallRuleNames = oneResult.firewallRuleNames;
          newEntry.name = oneResult.container;
          newEntry.totalAssets = oneResult.totalAssets;
          newEntry.totalAssetsNotCoveredByPolicy = oneResult.totalAssetsNotCoveredByPolicy;
          newEntry.children = oneResult.policies;
          retvalPolicies.push(newEntry);
        }

        // Calculate and add total firewall rule count
        let totalFirewallRuleCount = 0;
        for (const onePolicy in policyStats.policyFirewallRuleCountMap) {
          totalFirewallRuleCount += policyStats.policyFirewallRuleCountMap[onePolicy];
        }
        const retval = {};
        retval.totalFirewallRuleCount = totalFirewallRuleCount;

        // Calculate and add count of firewall rules by security policy
        const policyRuleCountArray = Object.keys(policyStats.policyRuleCountMap).map(function (key) {
          return { name: key, firewallRuleCount: policyStats.policyRuleCountMap[key] };
        });
        policyRuleCountArray.sort(function (a, b) {
          return b.firewallRuleCount - a.firewallRuleCount;
        });
        retval.policyRuleCountArray = policyRuleCountArray;

        // Convert map to array for dfwsections
        const policyDfwSectionArray = Object.keys(policyStats.policyDfwSectionMap).map(function (key) {
          return { name: key, dfwSection: policyStats.policyDfwSectionMap[key] };
        });
        retval.policyDfwSectionArray = policyDfwSectionArray;

        // Convert map to array for dfwsections
        const policyAllowRuleCountArray = Object.keys(policyStats.policyAllowRuleCountMap).map(function (key) {
          return { name: key, allowRuleCount: policyStats.policyAllowRuleCountMap[key] };
        });
        retval.policyAllowRuleCountArray = policyAllowRuleCountArray;

        // Convert map to array for dfwsections
        const policyDenyRuleCountArray = Object.keys(policyStats.policyDenyRuleCountMap).map(function (key) {
          return { name: key, denyRuleCount: policyStats.policyDenyRuleCountMap[key] };
        });
        retval.policyDenyRuleCountArray = policyDenyRuleCountArray;

        // Convert map to array for ports
        const policyPortsArray = Object.keys(policyStats.policyPortsMap).map(function (key) {
          return { name: key, ports: policyStats.policyPortsMap[key] };
        });
        retval.policyPortsArray = policyPortsArray;

        // Convert map to array for source ports
        const policySourcePortsArray = Object.keys(policyStats.policySourcePortsMap).map(function (key) {
          return { name: key, sourcePorts: policyStats.policySourcePortsMap[key] };
        });
        retval.policySourcePortsArray = policySourcePortsArray;

        // ----- Convert asset map to array for assets
        const policyAssetsArray = Object.keys(policyStats.policyAssetsMap).map(function (key) {
          // Remove duplicates from asset array
          const tempAssetSet = new Set(policyStats.policyAssetsMap[key]);
          const tempAssetArray = Array.from(tempAssetSet);
          policyStats.policyAssetCountMap[key] = tempAssetArray.length;
          return {
            name: key,
            firewallRuleCount: policyStats.policyRuleCountMap[key],
            assets: tempAssetArray
          };
        });
        retval.policyAssetsArray = policyAssetsArray;

        // ----- save policy / firewall rules map
        // Add the security group map with only unique values
        const trimmedFirewallMap = {};
        for (const firewallPolicyName in policyStats.policyFirewallRules) {
          if (policyStats.policyFirewallRules[firewallPolicyName] == null) {
            policyStats.policyFirewallRules[firewallPolicyName] = [];
          }
          let tempList = policyStats.policyFirewallRules[firewallPolicyName];
          const newList = tempList.map(function (element) {
            return element._source;
          });
          const tempSet = new Set(newList);
          tempList = Array.from(tempSet);
          trimmedFirewallMap[firewallPolicyName] = tempList;
        }
        retval.policyFirewallRulesMap = trimmedFirewallMap;

        // Calculate and add count of assets by security policy
        const policyAssetCountArray = Object.keys(policyStats.policyAssetCountMap).map(function (key) {
          return { name: key, assetCount: policyStats.policyAssetCountMap[key] };
        });
        policyAssetCountArray.sort(function (a, b) {
          return b.assetCount - a.assetCount;
        });
        retval.policyAssetCountArray = policyAssetCountArray;

        // Calculate the total assets that are not covered by any security policy
        retval.totalAssetsNotCoveredByPolicy = Object.keys(policyStats.allUuidsSet).length - Object.keys(policyStats.UuidsCoveredByPolicySet).length;

        logger.silly({
          totalAssets: Object.keys(policyStats.allUuidsSet).length,
          assetsCoveredByPolicy: Object.keys(policyStats.UuidsCoveredByPolicySet).length
        },
        'Calculate assets not covered by policy by (totalAssets - assetsCoveredByPolicy)');

        logger.silly({
          allUuidsSet: policyStats.allUuidsSet,
          size: Object.keys(policyStats.allUuidsSet).length
        }, 'allUuidsSet');
        logger.silly(
          {
            UuidsCoveredByPolicySet: policyStats.UuidsCoveredByPolicySet,
            size: Object.keys(policyStats.UuidsCoveredByPolicySet).length
          },
          'UuidsCOveredByPolicySet'
        );

        // Add the security group map with only unique values
        const trimmedSecGroupMap = {};
        for (const securityGroup in policyStats.secGroupMapOfAssets) {
          let tempList = policyStats.secGroupMapOfAssets[securityGroup];
          const tempSet = new Set(tempList);
          tempList = Array.from(tempSet);
          const newEntry = tempList.map(function (element) {
            return element.name;
          });
          trimmedSecGroupMap[securityGroup] = newEntry;
        }
        retval.secGroupMapOfAssets = trimmedSecGroupMap;

        retval.assetMap = policyStats.assetMap;

        // Add the policies list to return value
        retval.policies = retvalPolicies;

        // Cache the results for potential later use
        this.policyResults[yyyymmdd] = retval;
        logger.silly({ retval }, 'Done in calculatePolicy');
        return retval;
      } catch (error) {
        logger.silly({ error: error.message, stack: error.stack }, 'Error in calculatePolicy');
        throw error;
      }

    }
  }

  // ----------------------------------
  // sortFlowsByPort
  //   Same as for NetworkFlows - see NetworkFlows
  //
  //   If the data provided has no data then the output is an empty list:  []
  //
  sortFlowsByPort(date = 'NOW', token = null, authToken = null) {
    logger.silly('Enter sortFlowsByPort (for policies)');
    // --- if assetGroups is empty then return empty list
    if (this.assetGroups != null && this.assetGroups.length <= 0) {
      return Promise.resolve([]);
    } else {
      const netFlow = NetworkFlowsFactory.createNetworkFlows(this.assetGroups, this.hostPort,this.es_UserName,this.es_UserPassword, null, false, token, authToken);
      return netFlow.sortFlowsByPort(date);
    }
  }

  // ----------------------------------
  // statisitics
  //   For the assets of the object, it calculates a list of statistics
  //
  //  Input:
  //      date -   The UTC date to begin calculation.  Format:  YYYY-MM-DD
  //      timeFrame - The period of time over which to calculate.   The time frame is from the date backwards in time.
  //
  //  Output (a json object with a set of statistic values):
  //      {
  //          numberOfSecurityPolicies: <number of security policies>,
  //          numberOfSecurityGroups:  <number of security groups>,
  //          numberOfFirewallRules:  <number of firewall rules>,
  //          numberOfAssetsNotCoveredByAPolicy:  <number of assets>
  //      }
  //
  //
  //  The output if the day provided has no data then the output will be like this example:
  // {
  //   "totalPolicies": 0,
  //   "totalSecurityGroups": 0,
  //   "totalFirewallRules": 0,
  //   "totalAssetsNotCoveredByPolicy": 5
  // }

  async statisticsForPolicyRisk(startDate = new Date(), token = null, authToken = null, timeFrame = 'day') {
    if (this.assetGroups == null) {
      logger.silly({ startDate }, 'Enter statistics (for policy risk) - now assetGroups defined, it is null');
    } else {
      logger.silly({ assetGroups: this.assetGroups, startDate }, 'Enter statistics (for policy risk)');
    }

    if (startDate == null) {
      logger.silly('No startDate provided.');
      const e = new Error('No startDate provided.');
      e.status = 405;
      throw e;
    }
    if (timeFrame != 'day') {
      logger.silly({ timeFrame }, 'timeFrame provided is not supported');
      const e = new Error('timeFrame provided is not supported');
      e.status = 405;
      throw e;
    }

    let yyyymmdd;
    try {
      yyyymmdd = NetworkUtils.getYYYY_MM_DD(startDate);
    } catch (e) {
      logger.error({ e, stack: e.stack }, 'error occured');
      e.status = 500;
      throw e;
    }
    // --- if assetGroups is empty then return empty list
    if (this.assetGroups != null && this.assetGroups.length <= 0) {
      const retResult = {};
      retResult.totalPolicies = 0;
      retResult.totalSecurityGroups = 0;
      retResult.totalFirewallRules = 0;
      retResult.totalAssetsNotCoveredByPolicy = 0;
      return retResult;
    } else {
      const thePromises = [];
      const networkDashboard = NetworkDashboardFactory.createNetworkDashboard(this.assetGroups, this.hostPort, this.es_UserName, this.es_UserPassword, token, authToken);
      thePromises[0] = networkDashboard.calculateTotalPolicies(startDate);
      thePromises[1] = networkDashboard.calculateTotalSecurityGroups(startDate);
      thePromises[2] = networkDashboard.calculateTotalFirewallRules(startDate);
      if (this.policyResults[yyyymmdd] == null) {
        thePromises[3] = this.calculatePolicy(startDate);
      } else {
        thePromises[3] = this.policyResults[yyyymmdd];
      }

      logger.silly('About to wait for the promises');
      const retResult = {};
      try {
        const results = await Promise.all(thePromises);

        logger.silly({ results }, 'In statistics, thePromises completed');
        const totalPolicies = results[0].number;
        const totalSecurityGroups = results[1].number;
        const totalFirewallRules = results[2].number;
        const totalAssetsNotCoveredByPolicy = results[3].totalAssetsNotCoveredByPolicy;

        retResult.totalPolicies = totalPolicies;
        logger.silly({ totalPolicies }, 'total policies');
        retResult.totalSecurityGroups = totalSecurityGroups;
        logger.silly({ totalSecurityGroups }, 'total security groups');
        retResult.totalFirewallRules = totalFirewallRules;
        logger.silly({ totalFirewallRules }, 'total Firewall Rules');
        retResult.totalAssetsNotCoveredByPolicy = totalAssetsNotCoveredByPolicy;
        logger.silly({ totalAssetsNotCoveredByPolicy }, 'total Uuids not covered by security policy');

        logger.silly({ retResult }, 'policies statistics success!!');
        return retResult;

      } catch (error) {
        logger.silly({ error: error.message }, 'policies statistics fail!!');
        error.status = 500;
        throw error;
      }

    }
  }

  // ----------------------------------
  // Sort SecurityPolicy by Asset
  //   For the assets of the object, it calculates a list of security policies sorted by the number of assets in
  //      security policy
  //
  //  Input:
  //      date -   The UTC date to begin calculation.  Format:  YYYY-MM-DD
  //
  //  Output (an array of security policies sorted from most assets in security group to least):
  //      [
  //        {
  //          securityPolicy: <security policy name>,
  //          assetCount:  <number of assets in this security policy>
  //        },
  //        ...
  //      ]
  //
  //   If no data available for the given day then the return value is an empty list:
  //      []

  sortSecurityPolicyByAsset(startDate = new Date(), timeFrame = 'day') {
    logger.silly('Enter sortSecurityPolicyByAsset (for policies)');

    return new Promise((resolve, reject) => {
      if (startDate == null) {
        logger.silly('No startDate provided.');
        reject('No startDate provided.');
      }
      if (timeFrame != 'day') {
        logger.silly({ timeFrame }, 'timeFrame provided is not supported');
        reject('timeFrame provided is not supported');
      }

      // --- if assetGroups is empty then return empty list
      if (this.assetGroups != null && this.assetGroups.length <= 0) {
        return resolve([]);
      } else {
        const yyyymmdd = NetworkUtils.getYYYY_MM_DD(startDate);

        let thePromise = null;
        if (this.policyResults[yyyymmdd] == null) {
          thePromise = this.calculatePolicy(startDate);
        } else {
          thePromise = Promise.resolve(this.policyResults[yyyymmdd]);
        }

        thePromise
          .then(result => {
            logger.silly({ result }, 'In sortSecurityPolicyByAsset, success on promise!!!!!!');

            const retval = result.policyAssetCountArray;
            resolve(retval);
          })
          .catch(error => {
            logger.silly({ error: error.message }, 'Error in sortSecurityPolicyByAsset');
            reject(error);
          });
      }
    });
  }

  // ----------------------------------
  // Sort Application groups by security policy
  //   For the application groups, it calculates a list of application groups sorted by the number of security
  //      policies that apply to the assets of those application groups
  //
  //  Input:
  //      date -   The UTC date to begin calculation.  Format:  YYYY-MM-DD
  //
  //  Output (an array of application groups sorted from most security policies to least):
  //      [
  //        {
  //          application: <application group name>,
  //          policyCount:  <number of security policies that apply to this application>
  //        },
  //        ...
  //      ]
  //
  //   If no data available for the given day then the return value is an empty list:
  //      []

  sortAppGroupBySecurityPolicy(startDate = new Date(), timeFrame = 'day') {
    logger.silly('Enter sortAppGroupBySecurityPolicy (for policies)');

    return new Promise((resolve, reject) => {
      if (startDate == null) {
        logger.silly('No startDate provided.');
        reject('No startDate provided.');
      }
      if (timeFrame != 'day') {
        logger.silly({ timeFrame }, 'timeFrame provided is not supported');
        reject('timeFrame provided is not supported');
      }

      // --- if assetGroups is empty then return empty list
      if (this.assetGroups != null && this.assetGroups.length <= 0) {
        return resolve([]);
      } else {
        const yyyymmdd = NetworkUtils.getYYYY_MM_DD(startDate);

        let thePromise = null;
        if (this.policyResults[yyyymmdd] == null) {
          thePromise = this.calculatePolicy(startDate);
        } else {
          thePromise = Promise.resolve(this.policyResults[yyyymmdd]);
        }

        thePromise
          .then(result => {
            logger.silly({ result }, 'In sortAppGroupBySecurityPolicy, success on promise!!!!!!');
            const appGroupPolicyInfo = result.policies;
            const retval = [];
            for (let i = 0; i < appGroupPolicyInfo.length; i++) {
              const oneAppGroupPolicyInfo = appGroupPolicyInfo[i];
              const policyNames = oneAppGroupPolicyInfo.policyNames;
              const newEntry = {};
              newEntry.application = oneAppGroupPolicyInfo.name;
              newEntry.policyCount = policyNames.length;
              retval.push(newEntry);
            }
            retval.sort((obj1,obj2) => { return obj2.policyCount - obj1.policyCount; });
            resolve(retval);
          })
          .catch(error => {
            logger.silly({ error: error.message }, 'Error in sortAppGroupBySecurityPolicy');
            reject(error);
          });
      }
    });
  }

  // ----------------------------------
  // assetsBySecurityPolicy
  //
  //
  //   If no data available for the given day then the return value is an empty list:
  //      []
  assetsBySecurityPolicy(startDate = 'NOW', timeFrame = 'day') {
    logger.warn({ assetGroups: this.assetGroups }, 'Enter getAssetsBySecurityPolicy');

    return new Promise((resolve, reject) => {
      if (startDate == null) {
        logger.silly('No startDate provided.');
        reject('No startDate provided.');
      }
      if (timeFrame != 'day') {
        logger.silly({ timeFrame }, 'timeFrame provided is not supported');
        reject('timeFrame provided is not supported');
      }

      // --- if assetGroups is empty then return empty list
      if (this.assetGroups != null && this.assetGroups.length <= 0) {
        return resolve([]);
      } else {
        const yyyymmdd = NetworkUtils.getYYYY_MM_DD(startDate);

        let thePromise = null;
        if (this.policyResults[yyyymmdd] == null) {
          thePromise = this.calculatePolicy(startDate);
        } else {
          thePromise = Promise.resolve(this.policyResults[yyyymmdd]);
        }

        thePromise
          .then(result => {
            logger.silly({ result }, 'In assetsBySecurityPolicy, success on promise!!!!!!');

            const retval = result.policyAssetsArray;
            resolve(retval);
          })
          .catch(error => {
            logger.silly({ error: error.message }, 'Error in assetsBySecurityPolicy');
            reject(error);
          });
      }
    });
  }

  // ----------------------------------
  // statisticsForPolicyCompliance
  //
  // If no data for the provided date the output is:
  // body: {
  //   "countOfFirewallRules": 0,
  //   "countOfPolicies": 0,
  //   "countOfRulesThatAllow": 0,
  //   "countOfRulesThatDeny": 0,
  //   "countOfPorts": 0,
  //   "countOfSourcePorts": 0
  // }
  statisticsForPolicyCompliance(startDate = 'NOW', token = null, authToken = null, timeFrame = 'day') {
    logger.silly({ assetGroups: this.assetGroups }, 'Enter statisticsForPolicyCompliance');

    return new Promise((resolve, reject) => {
      if (startDate == null) {
        logger.silly('No startDate provided.');
        reject('No startDate provided.');
      }
      if (timeFrame != 'day') {
        logger.silly({ timeFrame }, 'timeFrame provided is not supported');
        reject('timeFrame provided is not supported');
      }

      // --- if assetGroups is empty then return empty list
      if (this.assetGroups != null && this.assetGroups.length <= 0) {
        const retval = {
          countOfFirewallRules: 0,
          countOfPolicies: 0,
          countOfRulesThatAllow: 0,
          countOfRulesThatDeny: 0,
          countOfPorts: 0,
          countOfSourcePorts: 0
        };
        return resolve(retval);
      } else {
        const yyyymmdd = NetworkUtils.getYYYY_MM_DD(startDate);
        const allIndexes = this._getAllIndexes(yyyymmdd, 'dfwrules', this.indexAndBatchesForFlows);
        this._collectAllCollectionBatches(allIndexes)
          .then(allCollectionBatches => {
            const thePromises = [];
            const networkDashboard = NetworkDashboardFactory.createNetworkDashboard(this.assetGroups, this.hostPort,this.es_UserName,this.es_UserPassword, token, authToken);
            thePromises[0] = networkDashboard.calculateTotalPolicies(startDate);
            thePromises[1] = this._countDfwRulesThatAllowAndDeny(this.client, allIndexes, allCollectionBatches);
            thePromises[2] = networkDashboard.calculateTotalFirewallRules(startDate);
            thePromises[3] = this._retrievePortsFromFirewalls(this.client, allIndexes, allCollectionBatches);
            logger.silly('About to wait for the promises');
            Promise.all(thePromises)
              .then(result => {
                logger.silly({ result }, 'In statisticsForPolicyCompliance, success on promise!!!!!!');

                const retval = {
                  countOfFirewallRules: 0,
                  countOfPolicies: 0,
                  countOfRulesThatAllow: 0,
                  countOfRulesThatDeny: 0,
                  countOfPorts: 0,
                  countOfSourcePorts: 0
                };
                retval.countOfFirewallRules = result[2].number;
                retval.countOfPolicies = result[0].number;
                // ---- Create list of dfwsections
                retval.countOfRulesThatAllow = result[1].allowCount;
                retval.countOfRulesThatDeny = result[1].denyCount;

                // --- New way of getting port count and source port count (gets count of all ports)
                retval.countOfPorts = result[3].ports.length;
                retval.countOfSourcePorts = result[3].sourcePorts.length;

                resolve(retval);
              })
              .catch(error => {
                logger.silly({ error: error.message }, 'Error in statisticsForPolicyCompliance');
                reject(error);
              });
          })
          .catch( error => {
            logger.silly({ error: error.message }, 'Error in statisticsForPolicyCompliance');
            reject(error);
          });
      }
    });
  }

  // ============================================================================================
  // STATIC functions - available directly from Class, no object needed, the this is not available
  // ============================================================================================

  // ============================================================================================
  // PRIVATE functions - shall begin with '_', do NOT access outside this class.
  // ============================================================================================

  // -------------------------------------
  // Input:
  //     curAssetName - string -  name of current asset, can be ''
  //     curContainer - string - name of current containter, can be ''
  //     curPolicyName - string - name of current policy that contains the firewall rules
  //     firewallRules - array of json objects where each object is the json object from the dfwRules elasticsearch index
  // Returns a list of json objects where each json object is:
  //  {
  //    asset: curAssetName,
  //    container: curContainer,
  //    securityPolicy: curPolicyName,
  //    ruleId: fwId,
  //    ruleName: fwName,
  //    sourceGroup: curSourceName,
  //    sourcePort: fwSourcePorts,
  //    destinationGroup: curDestinationName,
  //    destinationPort: fwDestinationPorts,
  //    action: fwAction
  // }
  _transformFirewallRulesToListOfRecords(curAssetName, curContainer, curPolicyName, firewallRules, secGroupMapOfAssets) {
    const retval = [];

    if ((firewallRules == null) || (firewallRules.length <= 0)) {
      logger.silly({ firewallRules }, ' Empty firewall rules in _transformFirewallRulesToListOfRecords');
      firewallRules = [];
      let policyName = curPolicyName;
      if (policyName === '') {
        policyName = 'none';
      }
      let targetAsset = curAssetName;
      if (targetAsset === '') {
        targetAsset = 'none';
      }
      let targetContainer = curContainer;
      if (targetContainer === '') {
        targetContainer = 'none';
      }
      const newEntry = {
        asset: targetAsset,
        container: targetContainer,
        securityPolicy: policyName,
        ruleId: 'none',
        ruleName: 'none',
        sourceGroup: 'none',
        sourcePort: 'none',
        destinationGroup: 'none',
        destinationPort: 'none',
        source: 'none',
        destination: 'none',
        action: 'none'
      };
      retval.push(newEntry);
      logger.silly({ newEntry }, 'NewEntry for entry with no firewall rules');
    } else {
      logger.silly({ numOfRulesToTransform: firewallRules.length });
      for (let fwIdx = 0; fwIdx < firewallRules.length; fwIdx++) {
        const curFirewallRule = firewallRules[fwIdx];
        const fwId = curFirewallRule.id;
        const fwName = curFirewallRule.name;
        const fwAction = curFirewallRule.action;
        let fwSources = [{ name: 'any' }];
        let fwDestinations = [{ name: 'any' }];
        let fwServices = [];
        let secondaryAssets = [''];

        // -- get the source groups (otherwise it uses default set above)
        if (('sources_flattened' in curFirewallRule) && (curFirewallRule.sources_flattened.length > 0)) {
          fwSources = curFirewallRule.sources_flattened;
        }
        // -- get the destination groups (otherwise it uses default set above)
        if (('destinations_flattened' in curFirewallRule) && (curFirewallRule.destinations_flattened.length > 0)) {
          fwDestinations = curFirewallRule.destinations_flattened;
        }
        // -- get the services (ports) (otherwise it uses default set above)
        if (('services_flattened' in curFirewallRule) && (curFirewallRule.services_flattened.length > 0)) {
          fwServices = curFirewallRule.services_flattened;
        }

        //--- determine direction for firewall (toward or away from asset)

        let secondaryGroupIs = 'source';
        // if no policy then the secondary group is the destination of the dfw rule
        if (curPolicyName === '') {
          secondaryGroupIs = 'destination';
        }
        for (let srcIdx = 0; srcIdx < fwSources.length; srcIdx++) {
          const curSource = fwSources[srcIdx];
          const curSourceName = curSource.name;
          if ((curPolicyName !== '') && (curSourceName == curPolicyName)) {
            secondaryGroupIs = 'destination';
          }
        }

        //--- loop through the source groups
        logger.silly({ numOfSourceGroups: fwSources.length }, '_transformFirewallRulesToListOfRecords');
        for (let srcIdx = 0; srcIdx < fwSources.length; srcIdx++) {

          logger.silly({ srcIdx }, 'Processing firewall source...');
          const curSource = fwSources[srcIdx];
          const curSourceName = curSource.name;
          if (secondaryGroupIs == 'source') {
            secondaryAssets = this._getSecondaryAssets(curSource, secGroupMapOfAssets);
          }

          // --- loop through the destination groups
          logger.silly({ numOfDestinationGroups: fwDestinations.length }, '_transformFirewallRulesToListOfRecords');
          for (let dstIdx = 0; dstIdx < fwDestinations.length; dstIdx++) {
            const curDestination = fwDestinations[dstIdx];
            const curDestinationName = curDestination.name;
            if (secondaryGroupIs == 'destination') {
              secondaryAssets = this._getSecondaryAssets(curDestination, secGroupMapOfAssets);
            }

            // --- loop through the assets of the secondary endpoint creating one entry for every asset
            logger.silly({ numOfSecondaryAssets: secondaryAssets.length }, '_transformFirewallRulesToListOfRecords');

            // --- If secondaryAssets is empty or null (which can happen when the security group has an empty
            //      membersAsVms list, then set it to one 'none' element so that the associated
            //       policy/dfw rule is still in list.
            if ((secondaryAssets == null) || (secondaryAssets.length == 0)) {
              secondaryAssets = [];
              secondaryAssets.push('');
            }

            // --- Create one entry per secondary asset
            for (let secondaryIdx = 0; secondaryIdx < secondaryAssets.length; secondaryIdx++) {
              let targetAsset = curAssetName;
              let targetContainer = curContainer;
              let secondaryAssetIpOrUuid = secondaryAssets[secondaryIdx];
              if (secondaryAssetIpOrUuid == null) secondaryAssetIpOrUuid = '';
              if (targetAsset == null) targetAsset = '';

              let sourceIpOrUuid = '';
              let destinationIpOrUuid = '';
              if (secondaryGroupIs == 'source') {
                sourceIpOrUuid = secondaryAssetIpOrUuid;
                destinationIpOrUuid = targetAsset;
              } else {
                sourceIpOrUuid = targetAsset;
                destinationIpOrUuid = secondaryAssetIpOrUuid;
              }

              // -- set empty source to any or none depending on the source group
              if ((sourceIpOrUuid === '') && (curSourceName === 'any')) {
                sourceIpOrUuid = 'any';
              } else if ((sourceIpOrUuid === '') && (curSourceName !== 'any')) {
                sourceIpOrUuid = 'none';
              }
              // -- set empty destination to any or none depending on the destination group
              if ((destinationIpOrUuid === '') && (curDestinationName === 'any')) {
                destinationIpOrUuid = 'any';
              } else if ((destinationIpOrUuid === '') && (curDestinationName !== 'any')) {
                destinationIpOrUuid = 'none';
              }
              // -- set empty targetAsset and targetContainer to 'any' if both source/dest are 'any' otherwise
              //    set to 'none'.  This is to follow intuition of user - if there is a dfw rule from/to a group
              //    with 'any' then the target asset indicates which assets are in the most constrained group
              if ((destinationIpOrUuid === 'any') && (sourceIpOrUuid === 'any')) {
                if (targetAsset === '') {
                  targetAsset = 'any';
                }
                if (targetContainer === '') {
                  targetContainer = 'any';
                }
              } else {
                if (targetAsset === '') {
                  targetAsset = 'none';
                }
                if (targetContainer === '') {
                  targetContainer = 'none';
                }
              }

              if (fwServices.length <= 0) {
                logger.silly('Zero services in _transformFirewallRulesToListOfRecords');
                const fwSourcePorts = 'any';
                const fwDestinationPorts = 'any';
                let policyName = curPolicyName;
                if (policyName === '') {
                  policyName = 'none';
                }
                const newEntry = {
                  asset: targetAsset,
                  container: targetContainer,
                  securityPolicy: policyName,
                  ruleId: fwId,
                  ruleName: fwName,
                  sourceGroup: curSourceName,
                  sourcePort: fwSourcePorts,
                  destinationGroup: curDestinationName,
                  destinationPort: fwDestinationPorts,
                  source: sourceIpOrUuid,
                  destination: destinationIpOrUuid,
                  action: fwAction.toLowerCase()
                };
                retval.push(newEntry);
              } else {
                // --- loop through the services for the firewall rule, creating one entry for every service
                logger.silly({ numOfServices: fwServices.length }, '_transformFirewallRulesToListOfRecords');
                for (let svcIdx = 0; svcIdx < fwServices.length; svcIdx++) {
                  const curSvc = fwServices[svcIdx];
                  let fwSourcePorts = 'any';
                  let fwDestinationPorts = 'any';
                  if ('port' in curSvc) {
                    if (curSvc.port.length > 0) {
                      fwDestinationPorts = curSvc.port;
                    }
                    if ('source_port' in curSvc) {
                      if (curSvc.source_port.length > 0) {
                        fwSourcePorts = curSvc.source_port;
                      }
                    }
                    let policyName = curPolicyName;
                    if (policyName === '') {
                      policyName = 'none';
                    }
                    const newEntry = {
                      asset: targetAsset,
                      container: targetContainer,
                      securityPolicy: policyName,
                      ruleId: fwId,
                      ruleName: fwName,
                      sourceGroup: curSourceName,
                      sourcePort: fwSourcePorts,
                      destinationGroup: curDestinationName,
                      destinationPort: fwDestinationPorts,
                      source: sourceIpOrUuid,
                      destination: destinationIpOrUuid,
                      action: fwAction.toLowerCase()
                    };
                    retval.push(newEntry);
                  }
                }
              }
            }
          }
        }
      }
    }
    return retval;
  }

  // ----------------------------------
  _getSecondaryAssets(secondaryGroup, secGroupMapOfAssets) {
    let secondaryAssets = null;
    let membersAsIps = null;
    if ((secondaryGroup != null) && ('name' in secondaryGroup) && ((secondaryGroup['name']==='any') || (secondaryGroup['name']==='none'))) {
      secondaryAssets = [];
      secondaryAssets.push('');
      return secondaryAssets;
    }
    if (get(secondaryGroup, 'type') == 'SecurityGroup') {
      if (secondaryGroup && (secondaryGroup.value in secGroupMapOfAssets)) {
        secondaryAssets = secGroupMapOfAssets[secondaryGroup.value];
      }
      if (secondaryGroup && ('membersAsIps' in secondaryGroup)) {
        membersAsIps = secondaryGroup.membersAsIps;
      }
      if ((secondaryAssets == null) && (membersAsIps == null)) {
        secondaryAssets = [];
        secondaryAssets.push('');
      } else if ((secondaryAssets == null) && (membersAsIps)) {
        secondaryAssets = membersAsIps;
      }
    } else if (get(secondaryGroup, 'type') == 'IPSet') {
      if (secondaryGroup && ('membersAsIps' in secondaryGroup)) {
        membersAsIps = secondaryGroup.membersAsIps;
      }
      if (membersAsIps == null) {
        secondaryAssets = [];
        secondaryAssets.push('');
        return secondaryAssets;
      } else {
        secondaryAssets = membersAsIps;
      }
    } else if (secondaryGroup) {
      secondaryAssets = [];
      secondaryAssets.push(secondaryGroup.type);
    }
    return secondaryAssets;
  }

  // ---------------------------------
  //  Goes through all the assetGroup members and collecs all the UUIDs of each member into a single list
  _collectAllUuids() {
    logger.silly('Enter _collectAllUuids');
    if (this.allUuids == null) {
      this.allUuids = [];
      for (let i = 0; i < this.assetGroups.length; i++) {
        this.allUuids = this.allUuids.concat(this.assetGroups[i].members.objects);
      }
    }
    return this.allUuids;
  }

  // --------------------------------
  //  Creates a list of  indexes to cover all assetGroup members
  //      some number of days
  //  This handles the possibility of crossing month and date boundaries
  _getAllIndexes(yyyymmdd, type, indexAndBatches) {
    logger.silly({ yyyymmdd, type, indexAndBatches }, 'Enter _getAllIndexes');
    let curIndexes = null;
    const curIndexAndBatches = indexAndBatches[yyyymmdd];
    logger.silly({ yyyymmdd, curIndexAndBatches }, 'determining the available index and batches for key');
    if (curIndexAndBatches != null) {
      curIndexes = curIndexAndBatches.indexes;
    }

    if (curIndexes == null) {
      curIndexes = [];

      logger.silly({ yyyymmdd, assetGroupLength: this.assetGroups.length }, '..In _getIndexes, about to create indexes');
      for (let i = 0; i < this.assetGroups.length; i++) {
        logger.silly({ assetGroupName: this.assetGroups[i].containerName }, '..In _getIndexes, determining if should create index');
        const location = this.assetGroups[i].members.options.location;
        const serviceProvider = this.assetGroups[i].members.options.serviceProvider;
        const organization = this.assetGroups[i].members.options.organization;
        const index = 'caveonetwork-' + organization + '-' + location + '-' + serviceProvider + '-' + type + '-' + yyyymmdd;

        logger.silly({ index }, '..In _getIndexes, index created');
        curIndexes.push(index);
      }
    }

    curIndexes = Array.from(new Set(curIndexes));
    return curIndexes;
  }

  _getCountOfFirewallRulesForOneContainer(yyyymmdd, container) {
    logger.silly({ yyyymmdd, container }, 'Enter _getCountOfFirewallRulesForOneContainer');
    return new Promise((resolve, reject) => {
      const targetUuids = container.members.objects;
      const location = container.members.options.location;
      const serviceProvider = container.members.options.serviceProvider;
      const organization = container.members.options.organization;
      const secGroupIndex = ['caveonetwork-' + organization + '-' + location + '-' + serviceProvider + '-' + 'secgroups' + '-' + yyyymmdd];
      const dfwRuleIndex = ['caveonetwork-' + organization + '-' + location + '-' + serviceProvider + '-' + 'dfwrules' + '-' + yyyymmdd];
      let collectionBatches = [];
      logger.silly({ secGroupIndex: dfwRuleIndex }, '...in _getCountOfFirewallRulesForOneContainer, ' + 'about to get collection batches');

      this._collectAllCollectionBatches(secGroupIndex)
        .then(collectionBatchesOut => {
          collectionBatches = collectionBatchesOut;
          logger.silly({ collectionBatches }, '...In _getCountOfFirewallRulesForOneContainer, got collectionBatches');

          // ---- Get the security groups for the assets in this container
          return this._retrieveSecurityGroupsForUuids(this.client, secGroupIndex, collectionBatches, targetUuids);
        })
        .then(result => {
          let thePromises = [];
          for (let i = 0; i < result.length; i++) {
            thePromises.push(this._retrieveCountOfFirewallRulesForSecurityGroups(this.client, dfwRuleIndex, collectionBatches, secGroups));
          }

          logger.silly({ thePromises }, 'Success in _getCountOfFirewallRulesForOneContainer');
          resolve(result);
        })
        .catch(error => {
          logger.silly({ error: error.message }, 'Error in _getCountOfFirewallRulesForOneContainer');
          reject(error);
        });
    });
  }

  _getCountOfUuidsWithoutPolicyForOneContainer(yyyymmdd, container) {
    logger.silly({ yyyymmdd, container }, 'Enter _getCountOfUuidsWithoutPolicyForOneContainer');
    return new Promise((resolve, reject) => {
      const location = container.members.options.location;
      const serviceProvider = container.members.options.serviceProvider;
      const organization = container.members.options.organization;
      const dfwRuleIndex = ['caveonetwork-' + organization + '-' + location + '-' + serviceProvider + '-' + 'dfwrules' + '-' + yyyymmdd];
      let collectionBatches = [];
      logger.silly({ secGroupIndex: dfwRuleIndex }, '...in _getCountOfUuidsWithoutPolicyForOneContainer, ' + 'about to get collection batches');
      this._collectAllCollectionBatches(dfwRuleIndex)
        .then(collectionBatchesOut => {
          collectionBatches = collectionBatchesOut;
          logger.silly({ collectionBatches }, '...In _getCountOfUuidsWithoutPolicyForOneContainer, ' + 'got collectionBatches');

          // ---- Get the security groups for the assets in this container
          return this._retrieveCountOfUuidsNotCoveredByAnySecurityPolicyForOneContainer(this.client, dfwRuleIndex, collectionBatches);
        })
        .then(result => {
          logger.silly({ error }, 'Success in _getCountOfUuidsWithoutPolicyForOneContainer');
          resolve(result);
        })
        .catch(error => {
          logger.silly({ error: error.message }, 'Error in _getCountOfUuidsWithoutPolicyForOneContainer');
          reject(error);
        });
    });
  }

  // -------------------------------------------------------------------
  // _resetNetworkPolicyData
  //   Resets to empty all the index and collectionBatches.  Usually done at init time as well as when
  //      the assetGroups definition changes.
  //
  //  Input:
  //      <none>
  //
  //  Output:
  //      <none>
  //
  _resetNetworkPolicyData() {
    this.indexAndBatchesForFlows = {};
    this.allUuids = null;
    this.policyResults = {};
  }

  // ------------------------------------------
  async _getPoliciesForOneContainer(yyyymmdd, container, policyStats) {
    logger.silly({ yyyymmdd, container }, 'Enter _getPoliciesForOneContainer');
    const targetUuids = container.members.objects;
    const secGroupChildren = [];
    let retPolicies = {};
    const assetMap = {};
    const assetsCoveredByPolicyMap = {};
    const secGroupMap = {};
    const policyWithParentMap = {};
    const policyWithoutParentMap = {};
    const containerStats = {
      policyNames: [],
      firewallNames: []
    };
    retPolicies.container = container.containerName;
    for (let i = 0; i < targetUuids.length; i++) {
      const oneChild = {};
      oneChild.name = targetUuids[i];
      oneChild.type = 'asset';
      oneChild.container = container.containerName;
      logger.silly({ oneChild, container }, 'adding asset to assetMap');
      assetMap[targetUuids[i]] = oneChild;
      policyStats.assetMap[targetUuids[i]] = oneChild;
      policyStats.allUuidsSet[targetUuids[i]] = 1;
    }
    const location = container.members.options.location;
    const serviceProvider = container.members.options.serviceProvider;
    const organization = container.members.options.organization;
    const secGroupIndex = ['caveonetwork-' + organization + '-' + location + '-' + serviceProvider + '-' + 'secgroups' + '-' + yyyymmdd];
    const secPolicyIndex = ['caveonetwork-' + organization + '-' + location + '-' + serviceProvider + '-' + 'secpolicies' + '-' + yyyymmdd];
    let collectionBatches = [];
    logger.silly({ secGroupIndex }, '...in _getPoliciesForOneContainer, about to get collection batches');
    const collectionBatchesOut = await this._collectAllCollectionBatches(secGroupIndex);
    collectionBatches = collectionBatchesOut;
    logger.silly({ collectionBatches }, '...In _getPoliciesForOneContainer, got collectionBatches');
    try{
      // ---- Get the security groups for the assets in this container
      const result = await this._retrieveSecurityGroupsForUuids(this.client, secGroupIndex, collectionBatches, targetUuids);

      // ---- PARSE Security Groups
      logger.silly({ result }, '...In _getPoliciesForOneContainer, success getting groups for asset uuids');
      // --- loop on security groups
      for (let i = 0; i < result.info.length; i++) {
        const curResult = result.info[i];
        const oneSecgroup = {};
        oneSecgroup.type = 'securityGroup';
        oneSecgroup.name = curResult.name;
        oneSecgroup.allAssetCount = curResult.membersAsVms.length;
        oneSecgroup.children = [];
        const curMembers = curResult.membersAsVms;
        for (let j = 0; j < curMembers.length; j++) {
          logger.silly({ j, curMember: curMembers[j].instanceUuid, assetMap }, '...In _getPoliciesForOneContainer looping on vm members of secgroup');
          if (curMembers[j].instanceUuid in assetMap) {
            oneSecgroup.children.push(assetMap[curMembers[j].instanceUuid]);
          }
        }
        secGroupChildren.push(oneSecgroup);
        secGroupMap[curResult.objectId] = oneSecgroup;
        if (curResult.objectId in policyStats.secGroupMapOfAssets) {
          policyStats.secGroupMapOfAssets[curResult.objectId] = policyStats.secGroupMapOfAssets[curResult.objectId].concat(oneSecgroup.children);
        } else {
          policyStats.secGroupMapOfAssets[curResult.objectId] = oneSecgroup.children;
        }
      }
      logger.silly({ secGroupChildren, secGroupMap }, '...In _getPoliciesForOneContainer, children created');

      // ---- GET Security Policies for groups
      // return (this._retrieveSecurityPoliciesForGroups(this.client, secPolicyIndex, collectionBatches, result.ids))
      const secGroupSet = {};
      for (let x = 0; x < result.info.length; x++) {
        secGroupSet[result.info[x].objectId] = result.info[x];
      }
      const securityPoliciesWithFirewalls = await this._getSecurityPoliciesWithFirewallRulesForGroups(this.client,
        secPolicyIndex, collectionBatches, result.ids, secGroupSet);

      logger.silly({ result: securityPoliciesWithFirewalls }, '...In _getPoliciesForOneContainer, success getting policies for groups');
      const policiesToParse = securityPoliciesWithFirewalls.info;
      // ---- GET parents of Policies
      const parentChildPolicies = await this._resolveParentChildPolicies(
        this.client,
        secPolicyIndex,
        collectionBatches,
        policiesToParse,
        policyWithParentMap,
        policyWithoutParentMap,
        secGroupMap,
        policyStats,
        containerStats
      );

      logger.silly({ result: parentChildPolicies, policyWithParentMap, policyWithoutParentMap }, '...In _getPoliciesForOneContainer, success getting parents of policies');
      // -- go through the parentChildPolicies and get the total assets covered by policies
      for (let resultIdx = 0; resultIdx<parentChildPolicies.length; resultIdx++) {
        const aPolicyDefinition = parentChildPolicies[resultIdx];
        logger.silly({ aPolicyDefinition }, 'Looping on policys after resolving parentChild, one policy');
        if (aPolicyDefinition.hasOwnProperty('allAssets')) {
          logger.silly(' ... policy has allAssets');
          const allAssets = aPolicyDefinition.allAssets;
          logger.silly({ allAssets }, ' ... looping on all Assets for policy');
          for (let assetIdx = 0; assetIdx < allAssets.length; assetIdx++ ) {
            const oneAsset = allAssets[assetIdx];
            logger.silly({ oneAsset }, '... adding name to assetsCoveredByPolicyMap');
            if (oneAsset.hasOwnProperty('name')) {
              assetsCoveredByPolicyMap[oneAsset.name] = 1;
              policyStats.UuidsCoveredByPolicySet[oneAsset.name] = 1;
            }
          }
        }
      }
      for (const onePolicy in policyWithParentMap) {
        if ('firewallRuleCount' in policyWithParentMap[onePolicy]) {
          policyStats.policyFirewallRuleCountMap[onePolicy] = policyWithParentMap[onePolicy].firewallRuleCount;
        }
      }

      for (const onePolicy in policyWithoutParentMap) {
        if ('firewallRuleCount' in policyWithoutParentMap[onePolicy]) {
          policyStats.policyFirewallRuleCountMap[onePolicy] = policyWithoutParentMap[onePolicy].firewallRuleCount;
        }
      }

      retPolicies = {};
      retPolicies.container = container.containerName;
      retPolicies.totalAssets = Object.keys(assetMap).length;
      retPolicies.totalAssetsNotCoveredByPolicy = Object.keys(assetMap).length - Object.keys(assetsCoveredByPolicyMap).length;
      //add code for firewall rule names and policy names
      retPolicies.firewallRuleNames = containerStats.firewallNames;
      retPolicies.policyNames = containerStats.policyNames;
      logger.silly(
        {
          ContainerName: container.containerName,
          containerAssetCount: Object.keys(assetMap).length,
          containerAssetCoveredByPolicy: Object.keys(assetsCoveredByPolicyMap).length
        },
        '--------->>>>>  Calcs for container assetsCoveredByPolicy'
      );

      // Add the assets without policies as children of a special security policy under top level container
      const caveonixPolicyNameForAssetsWithoutPolicy = 'Assets Without Any Policy';
      const caveonixPolicyForAssetsWithoutPolicy = {
        type: 'securityPolicy',
        name: caveonixPolicyNameForAssetsWithoutPolicy,
        dfwSection: '',
        allowCount: 0,
        denyCount: 0,
        ports: [],
        sourcePorts: [],
        firewallRules: [],
        firewallRuleCount: 0,
        allAssetCount: 0,
        allAssets: [],
        children: [],
        policyCountOnAssets: 0,
        accumulatedFirewallRuleCountOnAssets: 0
      };
      for (let i = 0; i < targetUuids.length; i++) {
        const targetUuid = targetUuids[i];
        if (!(targetUuid in assetsCoveredByPolicyMap)) {
          const oneChild = {
            name: targetUuid,
            type: 'asset',
            container: container.containerName
          };
          caveonixPolicyForAssetsWithoutPolicy.allAssetCount += 1;
          caveonixPolicyForAssetsWithoutPolicy.allAssets.push(oneChild);
          caveonixPolicyForAssetsWithoutPolicy.children.push(oneChild);
        }
      }
      if (caveonixPolicyForAssetsWithoutPolicy.allAssetCount > 0) {
        if (policyStats.policyAssetsMap[caveonixPolicyForAssetsWithoutPolicy.name] == null) {
          policyStats.policyAssetsMap[caveonixPolicyForAssetsWithoutPolicy.name] = caveonixPolicyForAssetsWithoutPolicy.allAssets;
        } else {
          policyStats.policyAssetsMap[caveonixPolicyForAssetsWithoutPolicy.name] = policyStats.policyAssetsMap[
            caveonixPolicyForAssetsWithoutPolicy.name
          ].concat(caveonixPolicyForAssetsWithoutPolicy.allAssets);
        }
        parentChildPolicies.push(caveonixPolicyForAssetsWithoutPolicy);
      }
      policyStats.policyRuleCountMap[caveonixPolicyForAssetsWithoutPolicy.name] = 0;
      retPolicies.policies = parentChildPolicies;
      logger.silly({ policyStats }, 'Exiting _getPoliciesForOneContainer');
      return retPolicies;
    }catch(error) {
      logger.silly({ error: error.message }, 'Error in _getPoliciesForOneContainer ');
      throw error;
    }
  }

  // -------------------------------------
  // input:
  // output:
  _resolveParentChildPolicies(
    esClient,
    indexes,
    collectionBatches,
    policiesToParse,
    policyWithParentMap,
    policyWithoutParentMap,
    secGroupMap,
    policyStats,
    containerStats
  ) {
    logger.silly({ indexes, collectionBatches, policiesToParse, secGroupMap }, 'Enter _resolveParentChildPolicies');
    return new Promise((resolve, reject) => {
      // Split into policies with parent and those without parent
      const policiesWithParentToProcessMap = {};
      for (let i = 0; i < policiesToParse.length; i++) {
        const curPolicy = policiesToParse[i];
        if ('parent' in curPolicy) {
          if (!(curPolicy.objectId in policyWithParentMap)) {
            policyWithParentMap[curPolicy.objectId] = curPolicy;
          }

          if (!(curPolicy.objectId in policiesWithParentToProcessMap)) {
            policiesWithParentToProcessMap[curPolicy.objectId] = curPolicy;
          }
        } else {
          if (!(curPolicy.objectId in policyWithoutParentMap)) {
            policyWithoutParentMap[curPolicy.objectId] = curPolicy;
          }
        }
      }

      logger.silly({ policyWithParentMap, policyWithoutParentMap }, 'RESOLVE - finished splitting');

      // Go through policy with parent and find its parent policy
      policiesToParse = [];
      const policiesToGet = [];
      const policiesToGetMap = {};
      for (const objectId in policiesWithParentToProcessMap) {
        const curPolicy = policiesWithParentToProcessMap[objectId];
        logger.silly({ curPolicy }, 'RESOLVE - top of loop on policy with parent');
        let parentPolicy = null;
        if (curPolicy.parent.objectId in policyWithoutParentMap) {
          parentPolicy = policyWithoutParentMap[curPolicy.parent.objectId];
        } else if (curPolicy.parent.objectId in policyWithParentMap) {
          parentPolicy = policyWithParentMap[curPolicy.parent.objectId];
        } else {
          logger.silly({ policiesToParse }, 'RESOLVE - Did not find parent of curPolicy so going to retrieve it and parse again');
          policiesToGet.push(curPolicy.parent.objectId);
          policiesToParse.push(curPolicy);
          policiesToGetMap[curPolicy.parent.objectId] = curPolicy.parent;
        }
        // if we found parent policy in current lists then add curPolicy to the children for parent policy
        if (parentPolicy != null) {
          if (!('children' in parentPolicy)) {
            parentPolicy.children = [];
          }
          logger.silly({ parentPolicy, curPolicy }, 'RESOLVE - adding child');
          parentPolicy.children.push(curPolicy);
          // TODO:  increment the parentPolicy asset count here
        }
      }

      if (policiesToGet.length != policiesToParse.length) {
        logger.warning(
          { policiesToGet, policiesToParse },
          'Unexpected: the length of policiesToGet and policiesToParse are different.  It is possible' + ' that the policy tree will be incomplete'
        );
      }

      // Get any new policies that are parents of existing policies that we don't currently have
      if (policiesToGet.length > 0) {
        logger.silly({ policiesToGet }, 'In RESOLVE - getting missing policies');
        this._getSecurityPoliciesWithFirewallRulesForPolicyIds(esClient, indexes, collectionBatches, policiesToGet)
          .then(result => {
            logger.silly({ result }, 'Successfully returned from _getSecurityPoliciesWithFirewallRulesForPolicyIds');

            for (let i = 0; i < policiesToGet.length; i++) {
              const curPolicyId = policiesToGet[i];
              if (!(curPolicyId in result.ids)) {
                logger.warn({ curPolicyId }, 'Missing policy definition, creating a filler for it');
                const missingInfo = policiesToGetMap[curPolicyId];
                result.info.push(missingInfo);
              }
            }

            const newPolicies = result.info;
            policiesToParse = policiesToParse.concat(newPolicies);
            logger.silly({ policiesToParse }, 'In RESOLVE - Recursing');
            return this._resolveParentChildPolicies(
              esClient,
              indexes,
              collectionBatches,
              policiesToParse,
              policyWithParentMap,
              policyWithoutParentMap,
              secGroupMap,
              policyStats,
              containerStats
            );
          })
          .then(result => {
            resolve(result);
          })
          .catch(error => {
            logger.silly({ error: error.message }, 'Error while _resolveParentChildPolicies ');
            reject(error);
          });
      } else {
        logger.silly('RESOLVE - No more policies to get, flattening');
        const retval = this._flattenSecurityPolicies(
          policyWithoutParentMap,
          policyWithParentMap,
          policyWithoutParentMap,
          secGroupMap,
          policyStats,
          containerStats,
          0,
          0,
          [],
          []
        );
        logger.silly('RESOLVE - done flattening, calling resolve on promise');
        resolve(retval);
      }
    });
  }

  // ------------------------------------
  _flattenSecurityPolicies(
    policiesToFlatten,
    policyWithParentMap,
    policyWithoutParentMap,
    secGroupMap,
    policyStats,
    containerStats,
    policyCountOnAssets,
    accumulatedFirewallCount,
    policyNamesOnAssets,
    firewallNamesOnAssets
  ) {
    logger.silly({ policiesToFlatten }, 'Enter _flattenSecurityPolicies');
    const retval = [];
    for (const curPolicyIdx in policiesToFlatten) {
      const curPolicy = policiesToFlatten[curPolicyIdx];
      logger.silly({ curPolicy }, ' FLATTEN:  Top of outer loop');
      const newEntry = {};
      newEntry.type = 'securityPolicy';
      newEntry.name = curPolicy.name;
      newEntry.policyNamesOnAssets = [curPolicy.name];
      newEntry.dfwSection = '';
      newEntry.allowCount = 0;
      if ('allowCount' in curPolicy) {
        newEntry.allowCount = curPolicy.allowCount;
      }
      newEntry.denyCount = 0;
      if ('denyCount' in curPolicy) {
        newEntry.denyCount = curPolicy.denyCount;
      }
      newEntry.ports = [];
      if ('ports' in curPolicy) {
        newEntry.ports = curPolicy.ports;
      }

      newEntry.sourcePorts = [];
      if ('sourcePorts' in curPolicy) {
        newEntry.sourcePorts = curPolicy.sourcePorts;
      }

      if ('dfwSectionName' in curPolicy) {
        newEntry.dfwSection = curPolicy.dfwSectionName;
      }
      newEntry.firewallRules = curPolicy.firewallRules;
      if (curPolicy.firewallRules) {
        newEntry.firewallNamesOnAssets = curPolicy.firewallRules.map(obj => {
          if (obj != null && obj.hasOwnProperty('_source') && obj._source.hasOwnProperty('name')) {
            return obj._source.name;
          }
        });
      } else {
        newEntry.firewallNamesOnAssets = [];
      }

      newEntry.firewallRuleCount = 0;
      if ('firewallRuleCount' in curPolicy) {
        newEntry.firewallRuleCount = curPolicy.firewallRuleCount;
      }
      newEntry.allAssetCount = 0;
      newEntry.allAssets = [];
      newEntry.children = [];
      newEntry.policyCountOnAssets = policyCountOnAssets + 1;
      newEntry.accumulatedFirewallRuleCountOnAssets = accumulatedFirewallCount + newEntry.firewallRuleCount;
      newEntry.firewallNamesOnAssets = firewallNamesOnAssets.concat(newEntry.firewallNamesOnAssets);
      newEntry.policyNamesOnAssets = policyNamesOnAssets.concat(newEntry.policyNamesOnAssets);

      // -- Add security group children to current policy
      if ('securityGroupBindings' in curPolicy) {
        logger.silly(' FLATTEN - processing securityGroupBindings');
        // -- Add security group children of this policy
        for (let i = 0; i < curPolicy.securityGroupBindings.length; i++) {
          logger.silly({ i }, ' FLATTEN:  Top of inner loop');
          const curSecGroupBinding = curPolicy.securityGroupBindings[i];
          logger.silly(
            {
              i,
              curSecGroupBinding,
              objectId: curSecGroupBinding.objectId,
              secGroupMap
            },
            ' in loop'
          );
          if (curSecGroupBinding.objectId in secGroupMap) {
            const objectId = curSecGroupBinding.objectId;
            logger.silly({ curSecGroupBinding, secGroupMap, objectId }, ' in loop, adding child to secPolicy');
            newEntry.children.push(secGroupMap[curSecGroupBinding.objectId]);
            if ('children' in secGroupMap[curSecGroupBinding.objectId]) {
              newEntry.allAssets = newEntry.allAssets.concat(secGroupMap[curSecGroupBinding.objectId].children);
            }
          }
        }
      }

      // -- Add security policy children to current policy
      if ('children' in curPolicy) {
        logger.silly(' FLATTEN: flattening policy children');
        newEntry.children = newEntry.children.concat(
          this._flattenSecurityPolicies(
            curPolicy.children,
            policyWithParentMap,
            policyWithoutParentMap,
            secGroupMap,
            policyStats,
            containerStats,
            newEntry.policyCountOnAssets,
            newEntry.accumulatedFirewallRuleCountOnAssets,
            newEntry.policyNamesOnAssets,
            newEntry.firewallNamesOnAssets
          )
        );
      }

      // -- Calculate the allAssetCount and allAssets array from children of new entry
      for (let i = 0; i < newEntry.children.length; i++) {
        const oneChild = newEntry.children[i];
        newEntry.allAssetCount += oneChild.allAssetCount;
        if (oneChild.allAssets != null) {
          newEntry.allAssets = newEntry.allAssets.concat(oneChild.allAssets);
        }
      }

      // Remove duplicates from asset array
      const tempAssetSet = new Set(newEntry.allAssets);
      newEntry.allAssets = Array.from(tempAssetSet);
      newEntry.allAssetCount = newEntry.allAssets.length;

      // Remove duplicates from firewallNamesOnAssets
      const tempFirewallNameSet = new Set(newEntry.firewallNamesOnAssets);
      newEntry.firewallNamesOnAssets = Array.from(tempFirewallNameSet);

      // Remove duplicates from policyNamesOnAssets
      const tempPolicyNameSet = new Set(newEntry.policyNamesOnAssets);
      newEntry.policyNamesOnAssets = Array.from(tempPolicyNameSet);

      // Update the global policyStats
      policyStats.policyRuleCountMap[newEntry.name] = newEntry.firewallRuleCount;
      policyStats.policyFirewallRules[newEntry.name] = newEntry.firewallRules;
      policyStats.policyAllowRuleCountMap[newEntry.name] = newEntry.allowCount;
      policyStats.policyDenyRuleCountMap[newEntry.name] = newEntry.denyCount;
      policyStats.policyDfwSectionMap[newEntry.name] = newEntry.dfwSection;
      policyStats.policySourcePortsMap[newEntry.name] = newEntry.sourcePorts;
      policyStats.policyPortsMap[newEntry.name] = newEntry.ports;
      if (policyStats.policyAssetsMap[newEntry.name] == null) {
        policyStats.policyAssetsMap[newEntry.name] = newEntry.allAssets;
      } else {
        policyStats.policyAssetsMap[newEntry.name] = policyStats.policyAssetsMap[newEntry.name].concat(newEntry.allAssets);
      }
      if (containerStats.policyNames == null) {
        containerStats.policyNames = newEntry.policyNamesOnAssets;
      } else {
        containerStats.policyNames = containerStats.policyNames.concat(newEntry.policyNamesOnAssets);
      }
      if (containerStats.firewallNames == null) {
        containerStats.firewallNames = newEntry.firewallNamesOnAssets;
      } else {
        containerStats.firewallNames = containerStats.firewallNames.concat(newEntry.firewallNamesOnAssets);
      }

      logger.silly({ newEntry }, 'FLATTEN: adding newEntry to retval');
      retval.push(newEntry);
    }
    logger.silly({ retval }, 'Exit _flattenSecurityPolicies');
    return retval;
  }

  // ------------------------------------
  _retrieveSecurityPolicies(esClient, indexes, collectionBatches, policyObjectIds) {
    logger.silly({ policyObjectIds, indexes, collectionBatches }, 'Enter _retrieveSecurityPolicies');
    return new Promise((resolve, reject) => {
      esClient
        .search({
          size: 5000,
          index: indexes,
          ignoreUnavailable: true,
          _source: [
            'parent.name',
            'parent.description',
            'parent.objectId',
            'name',
            'description',
            'objectId',
            'dfwSectionName',
            'precedence',
            'securityGroupBindings.objectId',
            'securityGroupBindings.name',
            'dfwSectionName'
          ],
          body: {
            query: {
              bool: {
                filter: {
                  bool: {
                    must: [{ terms: { collectionBatch: collectionBatches } }, { terms: { objectId: policyObjectIds } }]
                  }
                }
              }
            }
          }
        })
        .then(body => {
          logger.silly({ body, indexes }, 'Success retrieving in _retrieveSecurityPolicies');
          const retval = {};
          const secPolicySet = new Set();
          const secPolicyInfo = [];
          let prevSecPolicyIdSize = 0;
          for (let i = 0; i < body.hits.hits.length; i++) {
            const oneHit = body.hits.hits[i];
            secPolicySet.add(oneHit._source.objectId);
            if (secPolicySet.size > prevSecPolicyIdSize) {
              prevSecPolicyIdSize = secPolicySet.size;
              secPolicyInfo.push(oneHit._source);
            }
          }
          retval.ids = Array.from(secPolicySet);
          retval.info = secPolicyInfo;
          resolve(retval);
        })
        .catch(error => {
          logger.silly({ error: error.message }, 'Error in _retrieveSecurityPolicies');
          reject(error);
        });
    });
  }

  _retrieveSecurityGroupsForUuids(esClient, indexes, collectionBatches, uuids) {
    logger.silly({ uuids, indexes, collectionBatches }, 'Enter _retrieveSecurityGroupsForUuids');
    return new Promise((resolve, reject) => {
      return esClient
        .search({
          size: 5000,
          index: indexes,
          ignoreUnavailable: true,
          filterPath: 'hits.hits._source.*',
          _source_excludes: [
            'objectTypeName',
            'type',
            'extendedAttributes',
            'inheritanceAllowed',
            'dynamicMemberDefinition',
            'universalRevision',
            'revision',
            'isUniversal',
            'scope',
            'clientHandle',
            'membersAsVnics',
            'nodeId',
            'members'
          ],
          _source: ['name', 'description', 'objectId', 'membersAsVms.instanceUuid'],
          body: {
            query: {
              bool: {
                filter: {
                  bool: {
                    must: [
                      { terms: { collectionBatch: collectionBatches } },
                      {
                        nested: {
                          path: 'membersAsVms',
                          query: { terms: { 'membersAsVms.instanceUuid': uuids } }
                        }
                      }
                    ]
                  }
                }
              }
            }
          }
        })
        .then(body => {
          logger.silly({ body, uuids }, 'Success retrieving in _retrieveSecurityGroupsForUuids');
          const retval = {};
          const secgroupIdSet = new Set();
          const secgroupInfo = [];
          let prevSecGroupIdSize = 0;
          const hits = body.hits;
          if (!hits) {
            retval.ids = [];
            retval.info = [];
            retval.set = new Set();

            return resolve(retval);
          }
          for (let i = 0; i < hits.hits.length; i++) {
            const oneHit = body.hits.hits[i];
            secgroupIdSet.add(oneHit._source.objectId);
            if (secgroupIdSet.size > prevSecGroupIdSize) {
              prevSecGroupIdSize = secgroupIdSet.size;
              secgroupInfo.push(oneHit._source);
            }
          }
          retval.ids = Array.from(secgroupIdSet);
          retval.info = secgroupInfo;
          return resolve(retval);
        })
        .catch(error => {
          logger.error({ error: error.message, stack: error.stack }, 'Error in _retrieveSecurityGroupsForUuids');
          return reject(error);
        });
    });
  }

  // returns a list of security policies with flattened firewall rules
  // result.info = policies
  // result.ids = [id, ... id]
  _getSecurityPoliciesWithFirewallRulesForGroups(esClient, secPoliciesIndexes, collectionBatches, secGroups, secGroupSet) {

    logger.silly({ secGroups, indexes: secPoliciesIndexes, collectionBatches, secGroupSet }, 'Enter _getSecurityPoliciesWithFirewallRulesForGroups');
    const secGroupsLocal = [];
    for (let i = 0; i < secGroups.length; i++) {
      secGroupsLocal.push(secGroups[i]);
    }
    return new Promise((resolve, reject) => {
      const retvalue = {};
      retvalue.info = [];
      retvalue.ids = [];
      const dfwRulesIndexes = [];
      for (let i = 0; i < secPoliciesIndexes.length; i++) {
        dfwRulesIndexes.push(secPoliciesIndexes[i].replace('secpolicies', 'dfwrules'));
      }
      this._retrieveSecurityPoliciesForGroups(esClient, secPoliciesIndexes, collectionBatches, secGroups)
        .then(result => {
          const thePromises = [];
          logger.silly({ result }, ' In DFWFIRWALL, retrieved the policies for groups');
          // For each security group in secGroups that is not in any of the result then create a fake security policy that wraps that security group
          // Format of the entry to create is:
          //          parent.name: '',  parent.description: '', parent.objectId: '', name: <sec group name>, description: <sec group desc>,
          //          objectId: <seg group objectId>, dfwSectionName: ?????, precedence: ?????, securityGroupBindings.objectId: <sec group objectId>
          //          securityGroupBindings.name: <sec group name>
          const secGroupInPolicySet = new Set();
          // --- Collect a list of unique secGroup Ids represented in the returned policies
          for (let i = 0; i < result.info.length; i++) {
            const oneSecPolicy = result.info[i];
            const secGroupBindings = oneSecPolicy.securityGroupBindings;
            for (let x = 0; x < secGroupBindings.length; x++) {
              const oneSecGroupBinding = secGroupBindings[x];
              const oneSecGroupObjectId = oneSecGroupBinding['objectId'];
              secGroupInPolicySet.add(oneSecGroupObjectId);
            }
          }
          // --- Go through the provided list of sec groups and remove the ones found in sec policies
          const secGroupsNotInAPolicySet = new Set();
          for (let x = 0; x < secGroupsLocal.length; x++) {
            const oneSecGroupId = secGroupsLocal[x];
            if (!(oneSecGroupId in secGroupInPolicySet)) {
              secGroupsNotInAPolicySet.add(oneSecGroupId);
            }
          }
          // --- get the firewall rules for those security groups within security policy
          for (let i = 0; i < result.info.length; i++) {
            thePromises[i] = this._getFirewallRulesForOnePolicy(esClient, dfwRulesIndexes, collectionBatches, result.info[i]);
          }
          Promise.all(thePromises)
            .then(results => {
              // --- Go through all the security groups not in a security policy and add a 'fake' security policy
              //     with the same name as security group.
              //     In the absence of an NSX security policy our definition of a policy is all dfw rules that
              //     have the same security group as an endpoint define a policy for that security group.
              const secGroupsNotInAPolicyArray = Array.from(secGroupsNotInAPolicySet);
              const morePromises = [];
              for (let x = 0; x < secGroupsNotInAPolicyArray.length; x++) {
                const oneSecGroupId = secGroupsNotInAPolicyArray[x];
                const oneSecGroup = secGroupSet[oneSecGroupId];
                const newResult = {};
                const securityGroupBindings = [];
                const oneSecGroupBinding = {};
                oneSecGroupBinding.name = oneSecGroup.name;
                oneSecGroupBinding.objectId = oneSecGroupId;
                securityGroupBindings.push(oneSecGroupBinding);
                newResult.securityGroupBindings = securityGroupBindings;
                newResult.name = oneSecGroup.name;
                newResult.description = 'Caveonix-pseudo policy defined by underlying security group';
                newResult.precedence = 1; // Just making up a number to put here.
                newResult.objectId = 'securitygroup-fake-id-'+this._uuidv4(); // what to put here for fake policy?, trying empty string since there is no policy object defined
                morePromises[x] = this._getFirewallRulesForOneGroup(esClient, dfwRulesIndexes, collectionBatches, newResult, oneSecGroupId);
                // There is no dfwSectionName associated with a single security group so we leave it out.  The rest of the
                //    code is robust enough to deal with this missing key
                //    newResult.dfwSectionName = ''
              }
              Promise.all(morePromises)
                .then(moreResults => {
                  for (let x=0; x<moreResults.length; x++) {
                    result.info.push(moreResults[x]);
                    result.ids.push(moreResults[x].objectId);
                  }
                  logger.silly({ results, result }, 'DFWRULES! success returning result');
                  resolve(result);
                })
                .catch(error => {
                  logger.silly({ error: error.message }, 'Error in _getSecurityPoliciesWithFirewallRulesForGroups while resolving more promises');
                  reject(error);
                });
            })
            .catch(error => {
              logger.silly({ error: error.message }, 'Error in _getSecurityPoliciesWithFirewallRulesForGroups while resolving promises');
              reject(error);
            });
        })
        .catch(error => {
          logger.silly({ error: error.message }, 'Error in _getSecurityPoliciesWithFirewallRulesForGroups');
          reject(error);
        });
    });
  }

  _uuidv4() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      var r = Math.random() * 16 | 0; var v = c == 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }

  _getSecurityPoliciesWithFirewallRulesForPolicyIds(esClient, secPoliciesIndexes, collectionBatches, policyObjectIds) {
    logger.silly({ policyObjectIds, secPoliciesIndexes, collectionBatches }, 'Enter _getSecurityPoliciesWithFirewallRulesForPolicyIds');
    return new Promise((resolve, reject) => {
      const retvalue = {};
      retvalue.info = [];
      retvalue.ids = [];
      const dfwRulesIndexes = [];
      for (let i = 0; i < secPoliciesIndexes.length; i++) {
        dfwRulesIndexes.push(secPoliciesIndexes[i].replace('secpolicies', 'dfwrules'));
      }
      this._retrieveSecurityPolicies(esClient, secPoliciesIndexes, collectionBatches, policyObjectIds)
        .then(result => {
          const thePromises = [];
          logger.silly({ result }, ' In DFWFIRWALL, retrieved the policies for object ids');
          for (let i = 0; i < result.info.length; i++) {
            thePromises[i] = this._getFirewallRulesForOnePolicy(esClient, dfwRulesIndexes, collectionBatches, result.info[i]);
          }
          Promise.all(thePromises)
            .then(results => {
              logger.silly({ results, result }, 'DFWRULES2! success returning result');
              resolve(result);
            })
            .catch(error => {
              logger.silly({ error: error.message }, 'Error in _getSecurityPoliciesWithFirewallRulesForPolicyIds while resolving promises');
              reject(error);
            });
        })
        .catch(error => {
          logger.silly({ error: error.message }, 'Error in _getSecurityPoliciesWithFirewallRulesForPolicyIds');
          reject(error);
        });
    });
  }

  _getFirewallRulesForOnePolicy(esClient, indexes, collectionBatches, onePolicy) {
    logger.silly({ indexes, collectionBatches, onePolicy }, 'Enter _getFirewallRulesForOnePolicy');
    return new Promise((resolve, reject) => {
      let dfwSectionName = onePolicy.dfwSectionName;
      if(!dfwSectionName)dfwSectionName='';
      this._retrieveFirewallRulesForDfwSection(esClient, indexes, collectionBatches, dfwSectionName)
        .then(result => {
          logger.silly({ result }, '!!!!!!! got fwrules');
          onePolicy.firewallRules = result.fwrules;
          onePolicy.firewallRuleCount = result.fwrules.length;
          onePolicy.allowCount = result.allowCount;
          onePolicy.denyCount = result.denyCount;
          onePolicy.ports = result.ports;
          onePolicy.sourcePorts = result.sourcePorts;
          resolve(onePolicy);
        })
        .catch(error => {
          logger.silly({ error: error.message }, 'Error in _getFirewallRulesForOnePolicy');
          reject(error);
        });
    });
  }

  _getFirewallRulesForOneGroup(esClient, indexes, collectionBatches, onePseudoPolicyFromGroup, oneSecGroupId) {
    logger.silly({ indexes, collectionBatches, onePseudoPolicyFromGroup, oneSecGroupId }, 'Enter _getFirewallRulesForOneGroup');
    const oneSecGroupList = [];
    oneSecGroupList.push(oneSecGroupId);
    return new Promise((resolve, reject) => {
      this._retrieveDfwRulesForOneSecurityGroup(esClient, indexes, collectionBatches, oneSecGroupList)
        .then(result => {
          logger.silly({ result }, '!!!!!!! got fwrules');
          onePseudoPolicyFromGroup.firewallRules = result.fwrules;
          onePseudoPolicyFromGroup.firewallRuleCount = result.fwrules.length;
          onePseudoPolicyFromGroup.allowCount = result.allowCount;
          onePseudoPolicyFromGroup.denyCount = result.denyCount;
          onePseudoPolicyFromGroup.ports = result.ports;
          onePseudoPolicyFromGroup.sourcePorts = result.sourcePorts;
          resolve(onePseudoPolicyFromGroup);
        })
        .catch(error => {
          logger.silly({ error: error.message }, 'Error in _getFirewallRulesForOneGroup');
          reject(error);
        });
    });
  }

  _retrieveFirewallRulesForDfwSection(esClient, indexes, collectionBatches, dfwSectionName) {
    logger.silly({ dfwSectionName, indexes, collectionBatches }, 'Enter _retrieveFirewallRulesForDfwSection');
    return new Promise((resolve, reject) => {
      esClient
        .search({
          size: 5000,
          index: indexes,
          ignoreUnavailable: true,
          _source: [
            'sources_flattened.name',
            'sources_flattened.type',
            'sources_flattened.value',
            'sources_flattened.membersAsVms',
            'sources_flattened.membersAsIps',
            'destinations_flattened.name',
            'destinations_flattened.type',
            'destinations_flattened.value',
            'destinations_flattened.membersAsVms',
            'destinations_flattened.membersAsIps',
            'services_flattened.transport',
            'services_flattened.port',
            'name',
            'action',
            'direction',
            'disabled',
            'id'
          ],
          body: {
            query: {
              bool: {
                filter: {
                  bool: {
                    must: [{ terms: { collectionBatch: collectionBatches } }, { terms: { section_name: [dfwSectionName] } }]
                  }
                }
              }
            },
            aggs: {
              actionCount: {
                terms: { field: 'action', size: 3 }
              },
              services: {
                nested: {
                  path: 'services_flattened'
                },
                aggs: {
                  uniquePorts: { terms: { field: 'services_flattened.port', size: 500 } },

                  uniqueSourcePorts: { terms: { field: 'services_flattened.source_port', size: 500 } }
                }
              }
            }
          }
        })
        .then(body => {
          logger.silly({ body, indexes }, 'Success retrieving in _retrieveFirewallRulesForDfwSection');
          const retval = {
            fwrules: [],
            allowCount: 0,
            denyCount: 0,
            ports: [],
            sourcePorts: []
          };
          if ('hits' in body) {
            if ('hits' in body.hits) {
              retval.fwrules = body.hits.hits;
            }
          }
          if ('aggregations' in body) {
            if ('actionCount' in body.aggregations) {
              for (let i = 0; i < body.aggregations.actionCount.buckets.length; i++) {
                const bucket = body.aggregations.actionCount.buckets[i];
                if (bucket.key.toLowerCase() === 'allow') retval.allowCount += bucket.doc_count;
                else if (bucket.key.toLowerCase() === 'deny') retval.denyCount += bucket.doc_count;
              }
            }
            if ('aggregations' in body) {
              if ('services' in body.aggregations) {
                if ('uniquePorts' in body.aggregations.services) {
                  if ('buckets' in body.aggregations.services.uniquePorts) {
                    retval.ports = body.aggregations.services.uniquePorts.buckets;
                  }
                }

                if ('uniqueSourcePorts' in body.aggregations.services) {
                  if ('buckets' in body.aggregations.services.uniqueSourcePorts) {
                    retval.sourcePorts = body.aggregations.services.uniqueSourcePorts.buckets;
                  }
                }
              }
            }
          }
          resolve(retval);
        })
        .catch(error => {
          logger.silly({ error: error.message }, 'Error in _retrieveFirewallRulesForDfwSection');
          reject(error);
        });
    });
  }

  _retrieveDfwRulesForOneSecurityGroup(esClient, indexes, collectionBatches, securityGroupId) {
    logger.silly({ indexes, collectionBatches, securityGroupId }, 'Enter _retrieveDfwRulesForOneSecurityGroup');
    return new Promise((resolve, reject) => {
      if (this._arrayIsEmpty(securityGroupId)) {
        const retval = {
          fwrules: [],
          allowCount: 0,
          denyCount: 0,
          ports: [],
          sourcePorts: []
        };
        resolve(retval);
      } else {
        esClient
          .search({
            size: 5000,
            index: indexes,
            ignoreUnavailable: true,
            _source: [
              'sources_flattened.name',
              'sources_flattened.type',
              'sources_flattened.value',
              'sources_flattened.membersAsVms',
              'sources_flattened.membersAsIps',
              'destinations_flattened.name',
              'destinations_flattened.type',
              'destinations_flattened.value',
              'destinations_flattened.membersAsVms',
              'destinations_flattened.membersAsIps',
              'services_flattened.transport',
              'services_flattened.port',
              'name',
              'action',
              'direction',
              'disabled',
              'id'
            ],
            body: {
              query: {
                bool: {
                  should: [
                    {
                      bool: {
                        must: [
                          { terms: { collectionBatch: collectionBatches } },
                          {
                            nested: {
                              path: 'sources_flattened',
                              query: { terms: { 'sources_flattened.value': securityGroupId } }
                            }
                          }
                        ]
                      }
                    },
                    {
                      bool: {
                        must: [
                          { terms: { collectionBatch: collectionBatches } },
                          {
                            nested: {
                              path: 'destinations_flattened',
                              query: { terms: { 'destinations_flattened.value': securityGroupId } }
                            }
                          }
                        ]
                      }
                    }
                  ]
                }
              },
              aggs: {
                actionCount: {
                  terms: { field: 'action', size: 3 }
                },
                services: {
                  nested: {
                    path: 'services_flattened'
                  },
                  aggs: {
                    uniquePorts: { terms: { field: 'services_flattened.port', size: 500 } },
                    uniqueSourcePorts: { terms: { field: 'services_flattened.source_port', size: 500 } }
                  }
                }
              }
            }
          })
          .then(body => {
            logger.silly({ body, indexes }, 'Success retrieving in _retrieveDfwRulesForOneSecurityGroup');
            const retval = {
              fwrules: [],
              allowCount: 0,
              denyCount: 0,
              ports: [],
              sourcePorts: []
            };
            if ('hits' in body) {
              if ('hits' in body.hits) {
                retval.fwrules = body.hits.hits;
              }
            }
            if ('aggregations' in body) {
              if ('actionCount' in body.aggregations) {
                for (let i = 0; i < body.aggregations.actionCount.buckets.length; i++) {
                  const bucket = body.aggregations.actionCount.buckets[i];
                  if (bucket.key.toLowerCase() === 'allow') retval.allowCount += bucket.doc_count;
                  else if (bucket.key.toLowerCase() === 'deny') retval.denyCount += bucket.doc_count;
                }
              }
              if ('aggregations' in body) {
                if ('services' in body.aggregations) {
                  if ('uniquePorts' in body.aggregations.services) {
                    if ('buckets' in body.aggregations.services.uniquePorts) {
                      retval.ports = body.aggregations.services.uniquePorts.buckets;
                    }
                  }

                  if ('uniqueSourcePorts' in body.aggregations.services) {
                    if ('buckets' in body.aggregations.services.uniqueSourcePorts) {
                      retval.sourcePorts = body.aggregations.services.uniqueSourcePorts.buckets;
                    }
                  }
                }
              }
            }
            resolve(retval);
          })
          .catch(error => {
            logger.silly({ error: error.message }, 'Error in _retrieveDfwRulesForOneSecurityGroup');
            reject(error);
          });
      }
    });
  }

  //------------------------------
  // Returns
  //   {
  //    ports: [xxx, xxxx,...],
  //    sourcePorts: [xxxx, xxxx, ...]
  //   }
  _retrievePortsFromFirewalls(esClient, indexes, collectionBatches) {
    logger.silly({ indexes, collectionBatches }, 'Enter _retrievePortsFromFirewalls');
    return new Promise((resolve, reject) => {
      esClient
        .search({
          size: 0,
          index: indexes,
          ignoreUnavailable: true,
          body: {
            query: {
              bool: {
                filter: {
                  bool: {
                    must: [{ terms: { collectionBatch: collectionBatches } }]
                  }
                }
              }
            },
            aggs: {
              services: {
                nested: {
                  path: 'services_flattened'
                },
                aggs: {
                  uniquePorts: { terms: { field: 'services_flattened.port', size: 500 } },

                  uniqueSourcePorts: { terms: { field: 'services_flattened.source_port', size: 500 } }
                }
              }
            }
          }
        })
        .then(body => {
          logger.silly({ body, indexes }, 'Success retrieving in _retrievePortsFromFirewalls');
          const retval = {
            ports: [],
            sourcePorts: []
          };
          if ('aggregations' in body) {
            if ('aggregations' in body) {
              if ('services' in body.aggregations) {
                if ('uniquePorts' in body.aggregations.services) {
                  if ('buckets' in body.aggregations.services.uniquePorts) {
                    retval.ports = body.aggregations.services.uniquePorts.buckets;
                  }
                }

                if ('uniqueSourcePorts' in body.aggregations.services) {
                  if ('buckets' in body.aggregations.services.uniqueSourcePorts) {
                    retval.sourcePorts = body.aggregations.services.uniqueSourcePorts.buckets;
                  }
                }
              }
            }
          }
          resolve(retval);
        })
        .catch(error => {
          logger.silly({ error: error.message }, 'Error in _retrieveFirewallRulesForDfwSection');
          reject(error);
        });
    });
  }

  _retrieveSecurityPoliciesForGroups(esClient, indexes, collectionBatches, secgroups) {
    logger.silly({ secgroups, indexes, collectionBatches }, 'Enter _retrieveSecurityPoliciesForGroups');
    return new Promise((resolve, reject) => {
      if (this._arrayIsEmpty(secgroups)) {
        const retval = {};
        retval.ids = [];
        retval.info = [];
        resolve(retval);
      } else {
        esClient
          .search({
            size: 5000,
            index: indexes,
            ignoreUnavailable: true,
            _source: [
              'parent.name',
              'parent.description',
              'parent.objectId',
              'name',
              'description',
              'objectId',
              'dfwSectionName',
              'precedence',
              'securityGroupBindings.objectId',
              'securityGroupBindings.name',
              'dfwSectionName'
            ],
            body: {
              query: {
                bool: {
                  filter: {
                    bool: {
                      must: [
                        { terms: { collectionBatch: collectionBatches } },
                        {
                          nested: {
                            path: 'securityGroupBindings',
                            query: { terms: { 'securityGroupBindings.objectId': secgroups } }
                          }
                        }
                      ]
                    }
                  }
                }
              }
            }
          })
          .then(body => {
            logger.silly({ body, indexes }, 'Success retrieving in _retrieveSecurityPoliciesForGroups');
            const retval = {};
            const secPolicySet = new Set();
            const secPolicyInfo = [];
            let prevSecPolicyIdSize = 0;
            for (let i = 0; i < body.hits.hits.length; i++) {
              const oneHit = body.hits.hits[i];
              secPolicySet.add(oneHit._source.objectId);
              if (secPolicySet.size > prevSecPolicyIdSize) {
                prevSecPolicyIdSize = secPolicySet.size;
                secPolicyInfo.push(oneHit._source);
              }
            }
            retval.ids = Array.from(secPolicySet);
            retval.info = secPolicyInfo;
            resolve(retval);
          })
          .catch(error => {
            logger.silly({ error: error.message }, 'Error in _retrieveSecurityPoliciesForGroups');
            reject(error);
          });
      }
    });
  }

  _arrayIsEmpty(arr) {
    if (!arr) {
      return true;
    } else if (arr.every(element => ((element === null) || (typeof element === 'undefined')))) {
      return true;
    }
    return false;
  }

  _collectAllCollectionBatches(curIndexes) {
    logger.silly({ curIndexes }, 'Enter _collectAllCollectionBatches');

    return new Promise((resolve, reject) => {
      const curCollectionBatches = [];
      logger.silly({ curIndexes }, 'In _collectAllCollectionBatches, finding collectionBatches for these indexes');
      // let thePromises = []
      // for (let i = 0; i < curIndexes.length; i++) {
      //     thePromises.push(NetworkUtils.getMostRecentCollectionBatch(this.client, curIndexes[i],
      //         curCollectionBatches))
      // }
      // logger.silly({thePromises}, "In _collectAllCollectionBatches beginning wait for all collectionBatch queries")
      NetworkUtils.getMostRecentCollectionBatchForIndexList(this.client, curIndexes, curCollectionBatches)
        .then(values => {
          logger.silly({ curCollectionBatches, curIndexes }, 'Success in _collectAllCollectionBatches');
          resolve(curCollectionBatches);
        })
        .catch(error => {
          logger.silly({ error: error.message }, 'Failed waiting for all promises in _collectAllCollectionBatches');
          reject(error);
        });
    });
  }

  // ----------------------------------------
  _retrieveCountOfUuidsNotCoveredByAnySecurityPolicyForOneContainer(esClient, indexes, collectionBatches, container) {
    logger.silly({ secgroups, indexes, collectionBatches }, 'Enter _retrieveSecurityPoliciesForGroups');
    return new Promise((resolve, reject) => {
      if (this._arrayIsEmpty(secgroups)) {
        const retval = {};
        retval.ids = [];
        retval.info = [];
        resolve(retval);
      } else {
        esClient
          .search({
            size: 5000,
            index: indexes,
            ignoreUnavailable: true,
            _source: [
              'parent.name',
              'parent.description',
              'parent.objectId',
              'name',
              'description',
              'objectId',
              'dfwSectionName',
              'precedence',
              'securityGroupBindings.objectId',
              'securityGroupBindings.name'
            ],
            body: {
              query: {
                bool: {
                  filter: {
                    bool: {
                      must: [
                        { terms: { collectionBatch: collectionBatches } },
                        {
                          nested: {
                            path: 'securityGroupBindings',
                            query: { terms: { 'securityGroupBindings.objectId': secgroups } }
                          }
                        }
                      ]
                    }
                  }
                }
              }
            }
          })
          .then(body => {
            logger.silly({ body, indexes }, 'Success retrieving in _retrieveSecurityPoliciesForGroups');
            const retval = {};
            const secPolicySet = new Set();
            const secPolicyInfo = [];
            let prevSecPolicyIdSize = 0;
            for (let i = 0; i < body.hits.hits.length; i++) {
              const oneHit = body.hits.hits[i];
              secPolicySet.add(oneHit._source.objectId);
              if (secPolicySet.size > prevSecPolicyIdSize) {
                prevSecPolicyIdSize = secPolicySet.size;
                secPolicyInfo.push(oneHit._source);
              }
            }
            retval.ids = Array.from(secPolicySet);
            retval.info = secPolicyInfo;
            resolve(retval);
          })
          .catch(error => {
            logger.silly({ error: error.message }, 'Error in _retrieveSecurityPoliciesForGroups');
            reject(error);
          });
      }
    });
  }

  // -----------------------
  _sortSecurityGroupsByAssets(esClient, indexes, collectionBatches, uuids, timeInterval) {
    logger.silly({ timeInterval, uuids, indexes, collectionBatches }, 'Enter _sortSecurityGroupsByAssets');
    return new Promise((resolve, reject) => {
      esClient
        .search({
          index: indexes,
          size: 0,
          ignoreUnavailable: true,
          body: {
            query: {
              bool: {
                filter: {
                  bool: {
                    must: [
                      { terms: { collectionBatch: collectionBatches } },
                      {
                        nested: {
                          path: 'membersAsVms',
                          query: {
                            terms: { 'membersAsVms.instanceUuid': uuids }
                          }
                        }
                      }
                    ]
                  }
                }
              }
            },
            aggs: {
              security_groups: {
                terms: { field: 'name', size: 5000 },
                aggs: {
                  assets: {
                    nested: {
                      path: 'membersAsVms'
                    },
                    aggs: {
                      assetCount: { value_count: { field: 'membersAsVms.instanceUuid' } }
                    }
                  }
                }
              }
            }
          }
        })
        .then(body => {
          logger.silly({ body, indexes }, 'Success retrieving in _sortSecurityGroupsByAssets');
          const result = body;
          resolve(result);
        })
        .catch(error => {
          logger.silly({ error: error.message }, 'Error in _sortFlowBytesBy');
          reject(error);
        });
    });
  }

  // ---------------------------------------
  _countDfwRulesThatAllowAndDeny(esClient, indexes, collectionBatches) {
    logger.silly({ indexes, collectionBatches }, 'Enter _countDfwRulesThatAllowAndDeny');
    return new Promise((resolve, reject) => {
      esClient
        .search({
          index: indexes,
          ignoreUnavailable: true,
          size: 0,
          body: {
            query: {
              bool: {
                filter: {
                  bool: {
                    must: [{ terms: { collectionBatch: collectionBatches } }]
                  }
                }
              }
            },
            aggs: {
              uniqueActions: { terms: { field: 'action', size: 3 },
                aggs: { distinctIds: { cardinality: { field: 'id' } } }
              }
            }
          }
        })
        .then(body => {
          logger.silly({ body, indexes }, 'Success retrieving in _countDfwRulesThatAllowAndDeny');
          const retval = {
            allowCount: 0,
            denyCount: 0
          };
          if ('aggregations' in body) {
            if ('uniqueActions' in body.aggregations) {
              for (let i = 0; i < body.aggregations.uniqueActions.buckets.length; i++) {
                const bucket = body.aggregations.uniqueActions.buckets[i];
                let theCount = 0;
                if ('distinctIds' in bucket) {
                  theCount = bucket.distinctIds.value;
                }
                if (bucket.key.toLowerCase() === 'allow') retval.allowCount = theCount;
                else if (bucket.key.toLowerCase() === 'deny') retval.denyCount = theCount;
              }
            }
          }
          resolve(retval);
        })
        .catch(error => {
          logger.error({ error: error.message, stack: error.stack }, 'Error in _countDfwRulesThatAllowAndDeny');
          reject(error);
        });
    });
  }

  // ---------------------------------------
  // Returns [policyName, ...]
  _retrieveUniquePolicyNames(esClient, indexes, collectionBatches) {
    logger.silly({ indexes, collectionBatches }, 'Enter _retrieveUniquePolicyNames');
    return new Promise((resolve, reject) => {
      esClient
        .search({
          index: indexes,
          ignoreUnavailable: true,
          size: 0,
          body: {
            query: {
              bool: {
                filter: {
                  bool: {
                    must: [{ terms: { collectionBatch: collectionBatches } }]
                  }
                }
              }
            },
            aggs: {
              distinctIds: { terms: { field: 'objectId', size: 900 },
                aggs: { name: { top_hits: { _source: { includes: ['name'] }, size: 1 } } }
              }
            }
          }
        }).then(body => {
          logger.silly({ body, indexes }, 'Success retrieving in _retrieveUniquePolicyNames');
          const retval = [];
          if ('aggregations' in body) {
            if ('distinctIds' in body.aggregations) {
              logger.silly({ numOfBuckets: body.aggregations.distinctIds.buckets.length }, 'In _retrieveUniquePolicyNames');
              for (let i = 0; i < body.aggregations.distinctIds.buckets.length; i++) {
                logger.silly({ i, value: body.aggregations.distinctIds.buckets[i] }, '_retrieveUniquePolicyNames');
                const bucket = body.aggregations.distinctIds.buckets[i];
                if ('name' in bucket) {
                  logger.silly('has a name');
                  if ('hits' in bucket.name) {
                    logger.silly('has hits');
                    if ('hits' in bucket.name.hits) {
                      logger.silly('has _source');
                      logger.silly({ name: bucket.name.hits.hits[0]._source.name }, 'In _retrieveUniquePolicyNames, adding name');
                      retval.push(bucket.name.hits.hits[0]._source.name);
                    }
                  }
                }
              }
            }
          }
          logger.silly({ retval }, 'Returning from _retrieveUniquePolicyNames');
          resolve(retval);
        })
        .catch(error => {
          logger.error({ error: error.message, stack: error.stack }, 'Error in _retrieveUniquePolicyNames');
          reject(error);
        });
    });
  }

  // ---------------------------------------
  // Returns [{<firewall rule body from dfwrules index of ElasticSearch>}, ...]
  _retrieveDfwRulesNotManagedByPolicy(esClient, indexes, collectionBatches) {
    logger.silly({ indexes, collectionBatches }, 'Enter _retrieveDfwRulesNotManagedByPolicy');
    return new Promise((resolve, reject) => {
      esClient
        .search({
          index: indexes,
          ignoreUnavailable: true,
          size: 5000,
          body: {
            query: {
              bool: {
                filter: {
                  bool: {
                    must: [{ terms: { collectionBatch: collectionBatches } }],
                    must_not: { exists: { field: 'managedBy' } }
                  }
                }
              }
            }
          }
        }).then(body => {
          logger.silly({ body, indexes }, 'Success retrieving in _retrieveDfwRulesNotManagedByPolicy');
          let retval = [];
          if ('hits' in body) {
            if ('hits' in body.hits) {
              const dfwRulesMap = {};
              // retval = body.hits.hits.map((obj) => {
              //   if ( ! (obj._source.id in dfwRulesMap)) {
              //     dfwRulesMap[obj._source.id] = 1;
              //     return obj._source;
              //   }
              // });

              retval = body.hits.hits.reduce((result, obj) => {
                if ( !(obj._source.id in dfwRulesMap)) {
                  dfwRulesMap[obj._source.id] = 1;
                  result.push(obj._source);
                }
                return result;
              }, []);
            }
          }
          logger.silly({ retval }, 'Returning from _retrieveDfwRulesNotManagedByPolicy');
          resolve(retval);
        })
        .catch(error => {
          logger.error({ error: error.message, stack: error.stack }, 'Error in _retrieveDfwRulesNotManagedByPolicy');
          reject(error);
        });
    });
  }

  //-----------------------------
  // Returns  {<policy, firewallrules>}
  //TODO Jim, use this?
  _retrieveOneSecurityPoliciesWithFirewallRulesFromPolicyName(esClient, secPoliciesIndexes, collectionBatches, policyName) {
    logger.silly({ policyName, secPoliciesIndexes, collectionBatches }, 'Enter _retrieveOneSecurityPoliciesWithFirewallRulesFromPolicyName');
    return new Promise((resolve, reject) => {
      const retvalue = {};
      retvalue.info = [];
      retvalue.ids = [];
      const dfwRulesIndexes = [];
      for (let i = 0; i < secPoliciesIndexes.length; i++) {
        dfwRulesIndexes.push(secPoliciesIndexes[i].replace('secpolicies', 'dfwrules'));
      }
      this._retrievePolicyByName(esClient, secPoliciesIndexes, collectionBatches, policyName)
        .then(result => {
          const thePromises = [];
          logger.silly({ result }, ' Got policy from policy name');
          thePromises[0] = this._getFirewallRulesForOnePolicy(esClient, dfwRulesIndexes, collectionBatches, result);
          Promise.all(thePromises)
            .then(results => {
              logger.silly({ results, result }, '_retrieveOneSecurityPoliciesWithFirewallRulesFromPolicyName success! success returning result');
              resolve(result);
            })
            .catch(error => {
              logger.error({ error: error.message, stack: error.stack }, 'Error in _retrieveOneSecurityPoliciesWithFirewallRulesFromPolicyName while resolving promises');
              reject(error);
            });
        })
        .catch(error => {
          logger.error({ error: error.message, stack: error.stack }, 'Error in _retrieveOneSecurityPoliciesWithFirewallRulesFromPolicyName');
          reject(error);
        });
    });
  }

  // ---------------------------------------
  // Returns [{<firewall rule body from dfwrules index of ElasticSearch>}, ...]
  _retrievePolicyByName(esClient, indexes, collectionBatches, policyName) {
    logger.silly({ indexes, collectionBatches, policyName }, 'Enter _retrievePolicyByName');
    const searchBody = {
      index: indexes,
      ignoreUnavailable: true,
      size: 1,
      body: {
        query: {
          bool: {
            filter: {
              bool: {
                must: [
                  { terms: { collectionBatch: collectionBatches } },
                  { match: { name: { query: policyName, operator: 'and' } } }
                ]
              }
            }
          }
        }
      }
    };
    logger.silly({ searchBody }, 'Search body causing error in _retrievePolicyByName');
    return new Promise((resolve, reject) => {
      esClient
        .search(searchBody).then(body => {
          logger.silly({ body, indexes }, 'Success retrieving in _retrievePolicyByName');
          let retval = {};
          if ('hits' in body) {
            if ('hits' in body.hits) {
              if(body.hits.hits[0]){
                retval = body.hits.hits[0]._source;
              }
            }
          }
          logger.silly({ retval }, 'Returning from _retrievePolicyByName');
          resolve(retval);
        })
        .catch(error => {
          logger.error({ error: error.message, stack: error.stack }, 'Error in _retrievePolicyByName');
          reject(error);
        });
    });
  }

}

module.exports = NetworkPoliciesElasticsearch;
