const elasticsearch = require('./NetworkPoliciesElasticsearch');
module.exports = { elasticsearch };
