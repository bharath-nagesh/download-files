let elasticsearch = require('elasticsearch')
let url = require('url');
let config =  require('../configure').get();
let jp = require('jmespath')
let rp = require('request-promise')
let moment = require('moment')
let _ = require('lodash')
let logger = require('./logger.js').logger.child({

})
const SIZE = 500
module.exports = class NetworkForensics {
  constructor( hostPort,userName,UserPass, cookie, token = null, authToken = null, log = 'warning') {
    logger.silly({ hostPort, log }, 'Enter NetworkPolicies constructor')
    var q = url.parse(hostPort, true);
    this.hostPort = hostPort
    this.es_UserName=userName;
    this.es_UserPassword=UserPass;
    this.token = token
    this.authToken = authToken
    if (config.forensics_enabled == true) {
      this.client = new elasticsearch.Client({
        host:{
          protocol: q.protocol,
          host: q.host.split(':')[0],
          port: q.port,
          headers: {
            Authorization: this.authToken,
            RiskForesight: this.token
          }
        },
        log: log
      })
    }else{
      this.client = new elasticsearch.Client({
        host:{
          protocol:q.protocol,
          host:q.host.split(':')[0],

          // uri:q.protocol+'//'+q.host+'/',
          headers:{
            Authorization:`Bearer ${cookie}`
          }
        },
        log: log
      })
    }

    if (this.client == null) {
      logger.error('Unable to create elasticsearch client.');
      let e = new Error('invalid credentials');
      e.status = 403;
      throw e;
    }
  this.types = ['flow','scan','syslog']
  }
  async waitForScroll(query, size = 20000){
  let body = await query
  let scrollId = body._scroll_id
  let retArray = []
  let processed = 0
  let done = false
    if(!scrollId) return body.hits.hits
  do {
    logger.silly({ scrollId }, '  In waitForScroll, Initial scroll id ')
        //TODO process scroll id and close it when done.
    if (body.hits.hits.length > 0) {
      let flowsListBuffer = body.hits.hits
      flowsListBuffer.map(obj => {
        processed += 1

        retArray.push(obj)
    })
      logger.silly('Done parsing hits into flowsMap')
    }
    if (body.hits.total > processed) {
      done = false
      try {

        body = await this.client.scroll({ scrollId, scroll: '100s' })
        logger.info({processed},'continuing on scroll')
      } catch (e) {
        logger.error({ exception: e.stack }, 'Exception while scrolling through ElasticSearch data results for flows.')
      }
    } else {

      done = true
      try{
        await this.client.clearScroll({scrollId})
      }catch(error){

      }
    }
  } while (!done && processed<=size)
  return retArray
}
async getAggregation(query){
    let body  = await query
    let data = body.aggregations || body.aggs || body.aggregation || {theCount:{buckets:[]}}
  return data
}
async getCount(index, query,body,header){


  try{
    return query.q ?
       rp.post(`${this.hostPort}/${index}/_count`,{qs:{ignore_unavailable:query.ignoreUnavailable,q:query.q},headers:header,rejectUnauthorized:false,json:true})
      // this.client.count()
      :
      rp.post(`${this.hostPort}/${index}/_count`,{qs:{ignore_unavailable:query.ignoreUnavailable},body,headers:header,rejectUnauthorized:false,json:true})
  }catch(e){
logger.error({e, stack:e.stack},'error occurred')
    e.status = 400
    throw e
  }
}
async getMapping(index){
  let mappingProm ={"caveoscan-0-vulnerability-2018-09-02":{"mappings":{"scanResults":{"properties":{"affected_platforms":{"type":"text","fields":{"keyword":{"type":"keyword","ignore_above":256}}},"asset_id":{"type":"text","fields":{"keyword":{"type":"keyword","ignore_above":256}}},"asset_name":{"type":"text","fields":{"keyword":{"type":"keyword","ignore_above":256}}},"class":{"type":"text","fields":{"keyword":{"type":"keyword","ignore_above":256}}},"collectionTime":{"type":"date","format":"yyyy-MM-dd HH-mm-ss || epoch_millis"},"definition_id":{"type":"text","fields":{"keyword":{"type":"keyword","ignore_above":256}}},"deprecated":{"type":"boolean"},"description":{"type":"text","fields":{"keyword":{"type":"keyword","ignore_above":256}}},"organizationId":{"type":"integer"},"references":{"type":"text","fields":{"keyword":{"type":"keyword","ignore_above":256}}},"result":{"type":"text","fields":{"keyword":{"type":"keyword","ignore_above":256}}},"severity":{"type":"text","fields":{"keyword":{"type":"keyword","ignore_above":256}}},"sourceUUID":{"type":"text","fields":{"keyword":{"type":"keyword","ignore_above":256}}},"title":{"type":"text","fields":{"keyword":{"type":"keyword","ignore_above":256}}},"version":{"type":"text","fields":{"keyword":{"type":"keyword","ignore_above":256}}}}}}}}
  //   let mappingProm = await this.client.indices.getMapping( {
  //   index,
  //   ignoreUnavailable:true
  // })
  return  Object.entries(Object.assign({}, ...jp.search(mappingProm,'*.mappings.*.properties[]'))).map((obj)=>{
    return {
      term:obj[0],
      type:obj[1].type,
      path: `_source.${obj[0]}`
    }

  })
}
getDates(data) {
  let startDate, endDate = null
  for (let i = 0; i < data.length; i++) {
    let currentDate = moment(data[i]._index.split('-').slice(-3).join('/'))

    if (i == 0) {
      startDate = endDate = currentDate
    }
    if(moment(startDate).isAfter(currentDate)) startDate =  currentDate
    if(moment(endDate).isBefore(currentDate)) endDate =  currentDate
  }
  return {startDate,endDate}
}
  getHeader(cookie){
    let header
    if(config.forensics_enabled){
      header = {
        Authorization: this.authToken,
        RiskForesight: this.token
      }
    }else{
      header = {
        Authorization: `Bearer ${cookie}`
      };
    }
    return header
  }
async caveoFlowLogs(orgId,searchParams, namedParams,offset=0,cookie){

  let index = `caveonetwork-${orgId}-*-*-flows-*`
  try{
    let header = this.getHeader(cookie)
    logger.info({namedParams, searchParams},' the search and name params')
    let mustParams = Object.keys(namedParams).map(key =>{
      return {term:{[key]: namedParams[key]}}
    })
  let mapping  = await this.getMapping(index)
  let searchBody = {
  headers: header,

  // scroll:"240s",
  // size:SIZE,
  // from:offset,
  index,
  ignoreUnavailable:true,
  body:{
    "query" : {
      "bool" : {
        "must" : mustParams

      }
    },
  }}

  let countSearchBody =  _.cloneDeep(searchBody )
    searchBody.body.sort = {collectionTime:{order:'desc'}}
    searchBody.from = offset
    searchBody.size = SIZE
    if(searchParams){
    searchBody.q = searchParams
  countSearchBody.q = searchParams
    }
  let countBody = await this.getCount(index,countSearchBody,countSearchBody.body,header)
    let count = countBody.count
  let data =  await this.waitForScroll(this.client.search(searchBody))
    let {startDate, endDate }= this.getDates(data)
  return {mapping,data,count,startDate,endDate}
  }catch(e){
    e.status = e.status || 500
    logger.error({e,stack:e.stack},'error occurred caveoFlowLogs')
    return []
  }
}
async caveoScanLogs(orgId,searchParams, namedParams,offset=0,cookie){
  let index = `caveoscan-${orgId}-*`
  let mustParams = Object.keys(namedParams).map(key =>{
    return {term:{[key]: namedParams[key]}}
  })
  try {
    let header = this.getHeader(cookie)
    let searchBody = {
      headers: header,

      // scroll:"240s",
      // size:SIZE,
      // from:offset,
      index,
      ignoreUnavailable:true,
      body:{
        "query" : {
          "bool" : {
            "must" : mustParams

          }
        },
      }}
    let mapping  = await this.getMapping(index)
    let countSearchBody =  _.cloneDeep(searchBody )
    searchBody.body.sort = {collectionTime:{order:'desc'}}
    searchBody.from = offset
    searchBody.size = SIZE
    if(searchParams){
      searchBody.q = searchParams
      countSearchBody.q = searchParams
    }    let countBody = await this.getCount(index,countSearchBody,countSearchBody.body,header)
    let count = countBody.count
    let data = await this.waitForScroll(this.client.search(searchBody))
    let {startDate, endDate }= this.getDates(data)
    return {mapping,data,count,startDate,endDate}
  }catch(e){
    e.status = e.status || 500
    logger.error({e,stack:e.stack},'error occurred')
    return []
  }
}
async caveoLogs(orgId,searchParams, namedParams,offset=0,cookie){

  let index =`caveolog-${orgId}-*`;
  let mustParams = Object.keys(namedParams).map(key =>{
    return {term:{[key]: namedParams[key]}}
  })
  try {
    let header = this.getHeader(cookie)
    let searchBody = {
      headers: header,

      // scroll:"240s",
      // size:SIZE,
      // from:offset,
      index,
      ignoreUnavailable:true,
      body:{
        "query" : {
          "bool" : {
            "must" : mustParams

          }
        },
      }}

    let countSearchBody =  _.cloneDeep(searchBody )
    searchBody.body.sort = {collectionTime:{order:'desc'}}
    searchBody.from = offset
    searchBody.size = SIZE
    if(searchParams){
      searchBody.q = searchParams
      countSearchBody.q = searchParams
    }
    let countBody = await this.getCount(index,countSearchBody,countSearchBody.body,header)
    let count = countBody.count
    let mapping  = await this.getMapping(index)
    let data = await this.waitForScroll(this.client.search(searchBody))
    let {startDate, endDate }= this.getDates(data)
    return {mapping,data,count,startDate,endDate}
  }catch(e){
    e.status = e.status || 500
    logger.error({e,stack:e.stack},'error occurred')
    return []
  }
}
async caveoFlowsEventTrend(orgId,cookie){

  let index = `caveonetwork-${orgId}-*-*-flows-*`;
  try{
    let header = this.getHeader(cookie)
  let data =  await this.getAggregation(this.client.search({
    headers: header,
    index,
    size:SIZE,

    body:{
      "aggs": {

        "theCount" : {"terms" : {"field": "collectionTime"}}
      },
      sort:{collectionTime:{order:'desc'}}
    }
  }))
  return data
}catch(e){
    e.status = e.status || 500
    logger.error({e,stack:e.stack},'error occurred')
    return []
  }
  }
async caveoScanEventTrend(orgId,cookie){

  let index = `caveoscan-${orgId}-*`;

  try{
    let header = this.getHeader(cookie)
  let data =  await this.getAggregation(this.client.search({
    headers: header,
    index,
    size:SIZE,

    body:{
      "aggs": {

        "theCount" : {"terms" : {"field": "collectionTime"}}
      },
      sort:{collectionTime:{order:'desc'}}
    }
  }))
  return data
  }catch(e){
    e.status = e.status || 500
    logger.error({e,stack:e.stack},'error occurred')
    return []
  }
}
async caveoEventTrend(orgId,cookie){

  let index =  `caveolog-${orgId}-*`;
  try{
    let header = this.getHeader(cookie)
  let data =  await this.getAggregation(this.client.search({
    headers: header,
    index,

    size:SIZE,

    body:{
      "aggs": {
        "theCount" : {"terms" : {"field": "collectionTime","order": {"_key": "asc"}},
          "aggs": {
            "theAssetNames": {"terms" :
                {"field": "asset_name.keyword"}}
          }}

      },
      sort:{collectionTime:{order:'desc'}}
        }
  }
        ))
  return data
  }catch(e){
    e.status = e.status || 500
    logger.error({e,stack:e.stack},'error occurred')
    return []
  }
}}
