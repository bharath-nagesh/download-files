# Caveonix Riskforesight API - Enterprise Collector
This is the Riskforesight API for Enterprise Collector. All things come through here and then get dispersed appropriate.

## Code Standards
In  order to keep the code clean and maintainable, everyone that contributes to this repo should follow the coding standards below:
* JavaScript: https://github.com/airbnb/javascript

## Getting Started
Install of the the important packages and dependencies using `npm install`.  Once everything is installed Use `npm run dev` in order to get the project up and running. See deployment for notes on how to deploy the project on a live system.

### Prerequisites
Running `npm install` will install all of the relevant packages.  All of the important  

### Installing
Make sure the correct information is placed in the `config.json` file.  It is what is used to configure database connections and all other important configurations for the API to run.  After everything has been configured, run the command `npm run dev` in order to get the API started.

## Running the tests
Use `npm run test` in order to test the code.

### Break down into end to end tests
Mocha is used to test all of the code. The test files are located within the test folder.

## Deployment
Using the CI/CD the project gets deployed based off the the branch

## Built With
* [ExpressJS](https://expressjs.com/) - The web framework used
* [SwaggerUI](https://swagger.io/) - API documentation engine
* [Mocha](https://mochajs.org/) - Test Framework
