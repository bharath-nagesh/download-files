const where = require('../definitions/common');
const whereCondition = require('../../utils/whereParser.js');
const conditionFilter = require('../../utils/conditionFilter');
const complianceScore = require('../definitions/scoringModules/complianceScore.view');
const complianceSelector = require('../definitions/common/complianceSelector');
const _ = require('lodash');

class ComplianceFactory {
  constructor() {

  }

  static getRegulationList() {
    const regulationMap = require('./regulations');
    return Object.keys(regulationMap);
  }

  /**
   * Checks the available compliance files for the specified regulation, if its exists then returning it otherwise a 404
   * @param regulationName
   * @returns {*}
   */
  static getRegulationByName(regulationName) {
    const regulationMap = require('./regulations');
    if (!regulationName) {
      const error = new Error('No Regulation Selected');
      error.status = 404;
      throw error;
    }
    const regulation = regulationMap[regulationName] || regulationMap[regulationName.toLowerCase()] || regulationMap[regulationName.toUpperCase()];

    // if the regulation is missing from the regulation map then informing the user of their error
    if (!regulation) {
      const error = new Error(`Not a Supported Regulation ${regulationName}`);
      error.regulation = regulation;
      error.status = 404;
      throw error;
    }
    return regulation;
  }

  riskImprovement(condition) {
    return `select *, (case when cum_vul<=20 then '20%' when cum_vul <=40 and cum_vul>20 then '40%' when cum_vul <=60 and cum_vul>40 then '60%' when cum_vul>60 then '80%' end) as cum_vul_group 
       from (select rownum, cci,nist_index, definition,organization_name,location,application_grp_name, application_name,(compliance_score::numeric/total_count) as compliance_score,
       round((rownum*100)/ (max(rownum) over()) :: float) as cum_vul, round(sum(compliance_score*100/total_score:: float) over(order by rownum )) as cummulative_reduction,asset_type
        from (select row_number() over () as rownum,cci,nist_index,total_count,compliance_score,location,organization_name,application_grp_name, application_name,definition,sum(compliance_score) over() as total_score,asset_type
         from (select cci_id as cci, nist_index,definition, location, organization_name, application_grp_name, application_name, dc.id, count(dc.id) as total_count,
          sum(case when lower(severity) ='low' then 2 when lower(severity) ='medium' then 5 when lower(severity) ='high' then 8 when lower(severity) ='critical' then 10 else 1 end) as compliance_score,
           impact_level, bai_value,  initcap(severity) as severity, asset_type from ${where.compliance.viewWithNist} dc , xccdf_rules x ${whereCondition(
      ...conditionFilter(['application_grp_name', 'location_name', 'organization_name', 'application_name', 'source', 'asset_type', 'dc.result'], condition),
      'dc.rule_id=x.rule_id',
      where.compliance.resultFailFilter
    )}  group by cci_id,nist_index, definition, location, organization_name, application_grp_name, application_name,asset_type, dc.id,impact_level,bai_value ,severity order by compliance_score desc ) t 
       group by cci,nist_index, total_count, location,application_grp_name, application_name, asset_type,organization_name,definition, t.compliance_score ) r ORDER BY cum_vul) j 
       join regulation_nist_mappings  npm on nist_index = npm.nist_id join regulation_controls rc on rc.mapping_id = npm.mapping_id
        ${whereCondition(...conditionFilter(['rc.family_name', 'rc.mapping_id', 'rc.sub_control_id'], condition))}`;
  }

  riskReductionView(condition) {
    const applicationName = condition.application_name ? `ags.application_name = '${condition.application_name}' and` : '';
    const serviceApplicationName = condition.application_name ? `agsv.application_name = '${condition.application_name}' and` : '';

    const applicationJoin = applicationName ? `join application_tag_certificate_members atc on ags.application_id = atc.application_tag_id and rc.certificate_id = atc.certificate_id
    join application_regulation_control_list_function_common(atc.application_tag_id, '${this.regulationName}') arcl on arcl.regulation_control_id = rc.mapping_id` : '';

    const applicationServicesJoin = serviceApplicationName ? `join application_tag_certificate_members atc on agsv.application_grp_id = atc.application_tag_id
    join application_tag_controls_members atcm on atcm.certificate_id = rc.certificate_id and atcm.control_id = rc.mapping_id and atcm.application_id = agsv.application_grp_id` : '';

    return ` select *,round((rownum*100)/ (max(rownum) over()) :: float) as cum_vul,
    round(sum(score*100/risk_score:: float) over(order by rownum )) as cummulative_reduction from (
    select row_number() over () as rownum,organization_id, organization_name, top_org, 
           application_name , severity_count, round(score,2) as score, round(sum(score) over(),2) as risk_score
    from (
    select organization_id, organization_name, top_org, application_name , severity_count,
    sum(failed_controls) failed_controls, sum(passed_controls) passed_controls,  
    sum(case when lower(name)='low' then (score*1.1) when lower(name)='medium' then (score*1.2)
            when lower(name)='high' then (score*1.3) 
            when lower(name)='critical' then (score*1.5)  end)::numeric/sum(case when failed_controls = 0 then 1 else failed_controls end)  as score 
    from (
    select isc.organization_id, o.name as organization_name, o.id = :orgId as top_org, ags.application_name,
    sum(case when result = 'FAIL' then 1 else 0 end) as failed_controls, 
    sum(case when result = 'PASS' then 1 else 0 end) as passed_controls, 
    count(isc.cis_control_id) as total_controls, 
    cis.severity as name,
    count(cis.severity) as severity_count,
    sum(case when result = 'FAIL' then case when lower(cis.severity)='low' then 3 when lower(cis.severity)='medium' then 5
             when lower(cis.severity)='high' then 7
             when lower(cis.severity)='critical' then 9  end end) as score
       from infrastructure_services_compliance isc
        join cis_webservices_controls cis on cis.control_id = isc.cis_control_id and cis.cloud_type = isc.cloud_type
        join nist_cis_mappings ncm on ncm.mapping_id = cis.control_id and ncm.cloud_type = isc.cloud_type
        join regulation_nist_mappings rnm on ncm.nist_id = rnm.nist_id 
        join regulation_controls rc on rc.mapping_id = rnm.mapping_id and rc.certificate_id = rnm.certificate_id and rc.compliance = 'Auto'
        join application_group_service_view ags on isc.entity_arn = ags.entity_arn and ags.organization_id in (select org_chain_list(:orgId)) 
        join organizations o on o.id = isc.organization_id
        join (select max(batch_id) as max_batch_id,entity_arn from infrastructure_services_compliance where organization_id in (select org_chain_list(:orgId) ) group by entity_arn ) as max_batch_infra on max_batch_infra.max_batch_id = isc.batch_id and max_batch_infra.entity_arn = isc.entity_arn
        ${applicationJoin}
        join certificates c on c.id = rc.certificate_id and c.id = (select id from certificates where UPPER(name) = UPPER('${this.regulationName}'))
        where 
        ${applicationName}
        isc.organization_id in (select org_chain_list(:orgId)) and
        (isc.entity_arn, cis_control_id) NOT IN (select entity_arn,control_id from exemptions where is_active != 'false' and exemption_valid_till >= NOW() or exemption_valid_till is null and organization_id in (select org_chain_list(:orgId)) )
          group by isc.organization_id, o.name, top_org, ags.application_name, cis.severity
        ) outer_sql
        group by 
        (organization_id, organization_name, application_name, top_org, severity_count, failed_controls,passed_controls)
        union all
        select organization_id, organization_name, top_org, application_name, sum(failed_controls),sum(passed_controls), round(avg(score),2)  as risk_score, severity_count
        from (
        select organization_id, organization_name, top_org, application_name, sum(failed_controls) failed_controls, sum(passed_controls) passed_controls,  
        round(sum(case when lower(name)='low' then (score*1.1) when lower(name)='medium' then (score*1.2)
                when lower(name)='high' then (score*1.3) 
                when lower(name)='critical' then (score*1.5)  end)::numeric/sum(case when failed_controls = 0 then 1 else failed_controls end),2) as score , severity_count
        from (
        select scan.organization_id, o.name as organization_name, o.id = :orgId as top_org, application_grp_name as application_name, 
        sum(case when UPPER(scan_result) = 'FAIL' then 1 else 0 end) as failed_controls, 
        sum(case when UPPER(scan_result) = 'PASS' then 1 else 0 end) as passed_controls, 
        count(scan.rule_id) as total_count, 
        severity as name,
        count(severity) as severity_count,
        sum(case when lower(severity)='low' then 3 when lower(severity)='medium' then 5
                 when lower(severity)='high' then 7
                 when lower(severity)='critical' then 9  end) as score
        from daily_scan_xccdf_results scan 
        join assets a on scan.asset_id = a.id and (is_active='enabled' or is_active='true' or is_active='disabled')
        join xccdf_rules xr ON scan.rule_id = xr.rule_id
        join control_correlation_identifier cci on scan.reference  = cci.cci_id
        join regulation_nist_mappings rnm on cci.nist_index = rnm.nist_id
        join regulation_controls rc on rnm.certificate_id = rc.certificate_id and rnm.mapping_id = rc.mapping_id and compliance = 'Auto'
        join application_group_asset_view agsv on agsv.id = scan.asset_id and agsv.organization_id in (select org_chain_list(:orgId))
        ${applicationServicesJoin}
        join (select asset_id, max(batch_id) as max_batch_id from daily_scan_xccdf_results where asset_id in (select id from assets
        where (is_active='enabled' or is_active='true' or is_active='disabled') and
        organization_id in (select org_chain_list(:orgId)) )
        group by asset_id) as max_scanresult on scan.asset_id = max_scanresult.asset_id and scan.batch_id = max_scanresult.max_batch_id
        join certificates c on c.id = rc.certificate_id and c.id = (select id from certificates where UPPER(name) = UPPER('${this.regulationName}'))
        join organizations o on o.id = a.organization_id
        where 
        ${serviceApplicationName}
        scan.organization_id in (select org_chain_list(:orgId)) and
        (scan.asset_id::varchar, scan.rule_id) NOT IN (select entity_arn,control_id from exemptions where is_active != 'false' and exemption_valid_till >= NOW() or exemption_valid_till is null and organization_id in (select org_chain_list(:orgId)) )
        group by scan.organization_id, o.name, top_org, application_grp_name,severity
    ) outer_sql
    group by organization_id, organization_name, top_org, application_name, severity_count
    ) compute_score
   group by organization_id, organization_name, top_org, application_name, severity_count
   ) outer_sql
   ) cumm_cacl`;
  }

  xriskReductionView(condition) {
    return `select *, (case when cum_vul<=20 then '20%' when cum_vul <=40 and cum_vul>20 then '40%' when cum_vul <=60 and cum_vul>40 then '60%' when cum_vul>60 then '80%' end) as cum_vul_group  from (
        select rownum,reference,nist_index,location,asset_type, organization_name, application_grp_name, application_name,severity, asset_name, (compliance_score::numeric/total_count) as compliance_score,
        round((rownum*100)/ (max(rownum) over()) :: float) as cum_vul, round(sum(compliance_score*100/total_score:: float) over(order by rownum )) as cummulative_reduction from (
        select row_number() over () as rownum,reference,nist_index,location,asset_type, organization_name, application_grp_name, application_name,severity, asset_name,total_count,compliance_score,sum(compliance_score) over() as total_score from (
        select reference,nist_index,location,asset_type, organization_name, application_grp_name, application_name,severity, asset_name, count(dc.asset_id) as total_count, sum(case when lower(severity) ='low' then 2 when lower(severity) ='medium' then 5 when lower(severity) ='high' then 8 when lower(severity) ='critical' then 10 else 1 end) as compliance_score from
         ${complianceSelector(['source', 'asset_type', 'location', 'organization_name', 'application_grp_name', 'application_name', 'asset_id', 'asset_name', 'result', 'nist_index', 'rule_id', 'reference'])} dc ,
          xccdf_rules x ${whereCondition(
      ...conditionFilter(['application_grp_name', 'location_name', 'organization_name', 'application_name', 'source', 'asset_type'], condition),
      'dc.rule_id=x.rule_id',
      where.compliance.resultFailFilter
    )}  group by reference,nist_index,location,asset_type, organization_name, application_grp_name, application_name,severity, asset_name  ) t 
         group by reference,nist_index,location,asset_type, organization_name, application_grp_name, application_name,severity, asset_name, total_count,compliance_score order by compliance_score desc ) r ) j
          join regulation_nist_mappings npm on nist_index = npm.nist_id
          join regulation_controls rc on rc.mapping_id = npm.mapping_id
             ${whereCondition(...conditionFilter(['rc.family_name', 'rc.mapping_id', 'rc.sub_control_id'], condition))}`;

  }

  regulationControlView(condition) {
    const mappingId = condition.mapping_id ? ` rc.mapping_id = '${condition.mapping_id}' and` : '';
    const controlId = condition.control_id ? ` rc.control_id = '${condition.control_id}' and` : '';
    const domainId = condition.domain_id ? ` rc.domain_id = '${condition.domain_id}' and` : '';
    const controlName = condition.control_name ? ` rc.control_name = '${condition.control_name}' and` : '';
    const subControlName = condition.sub_control_name ? ` rc.sub_control_name = '${condition.sub_control_name}' and` : '';
    const applicationName = condition.application_name ? `and  ag.application_name = '${condition.application_name}' ` : '';
    const serviceApplicationName = condition.application_name ? `ags.application_name = '${condition.application_name}' and` : '';

    const applicationJoin = applicationName ? `join application_tag_certificate_members atc on dc.application_grp_id = atc.application_tag_id 
    join application_regulation_control_list_function_common(dc.application_grp_id, '${this.regulationName}') arcl on arcl.regulation_control_id = rc.mapping_id` : '';

    const applicationServicesJoin = applicationName ? `join application_tag_certificate_members atc on ags.application_id = atc.application_tag_id and rc.certificate_id = atc.certificate_id` : '';

    return `select DISTINCT '${this.regulationName}' as regulation,scan_type, asset_type as product,asset_id , asset_id::varchar as entity_arn, asset_name as entity_name, application_grp_name as application_name, 
    rc.family_id, 
    rc.domain_id, 
    rc.domain_name,
    rc.family_name, 
    dc.definition as title, 
    rc.control_id,
    rc.control_name,
    rc.sub_control_id,
    rc.sub_control_name, 
    rc.mapping_id,
    rnm.nist_id,dc.result, cci_id as cci, dc.rule_id, source
    from  (select bb.*, ag.application_grp_name, ag.type as asset_type, ag.application_grp_id,ag.asset_name,ag.source,ag.operating_system,
    cci.definition , cci.title,cci.index ,cci.nist_index, cci.cci_id  from
    (select  distinct batch_id, scan.asset_id,scan.rule_id,
    (CASE WHEN (select type from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) and (entity_arn = scan.asset_id::varchar or entity_arn is null) and control_id = scan.rule_id limit 1) is not null THEN
    (select type from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) and (entity_arn = scan.asset_id::varchar or entity_arn is null) and control_id = scan.rule_id limit 1) ELSE scan_result END) as result,
    scan_type,xr.rule_title,
    scan.reference from daily_scan_xccdf_results scan  INNER JOIN xccdf_rules xr ON scan.rule_id = xr.rule_id and scan.reference = xr.rule_identifiers
    join (select asset_id, max(batch_id) as max_batch_id from daily_scan_xccdf_results where asset_id in (select id from assets 
    where (is_active='enabled' or is_active='true' or is_active='disabled') and organization_id in (select org_chain_list(:orgId)) ) 
    and organization_id in (select org_chain_list(:orgId))
    group by asset_id ) as max_scanresult on scan.asset_id = max_scanresult.asset_id and scan.batch_id = max_scanresult.max_batch_id 
    ) bb ,control_correlation_identifier cci, application_group_asset_view ag
    where cci.cci_id = reference and ag.id = asset_id ${applicationName} ) dc 
    join regulation_nist_mappings rnm on dc.nist_index = rnm.nist_id 
    join regulation_controls rc on rc.mapping_id = rnm.mapping_id and rc.certificate_id = rnm.certificate_id and rc.compliance = 'Auto'
    ${applicationJoin}
    where rc.certificate_id = (select id from certificates where UPPER(name) = UPPER('${this.regulationName}')) and
    ${mappingId}
    ${controlId}
    ${domainId}
    ${controlName}
    ${subControlName}
    1=1 
    GROUP BY regulation,scan_type, asset_type,asset_id, asset_name,application_grp_name,
    rc.domain_id,rc.family_id,rc.domain_name,rc.family_name,dc.definition,rc.control_id,rc.control_name,rc.sub_control_id,rc.mapping_id, rc.sub_control_name,rnm.nist_id,result,cci_id,rule_id,source
    union all
    select DISTINCT '${this.regulationName}' as regulation,'services' as scan_type, product ,service_id as asset_id , entity_arn, entity_name, application_name, 
    domain_name,
    family_name,
    domain_id,
    family_id, 
    title,
    control_id,
    control_name,
    sub_control_id,
    sub_control_name, 
    mapping_id,
    nist_id,result, cis_control_id as cci, '' as rule_id,cloud_type 
    from (
    select infra.organization_id, o.name as organization_name, o.id = '0' as top_org, ags.application_name,
    sum(case when result = 'FAIL' then 1 else 0 end) as failed_controls, 
    sum(case when result = 'PASS' then 1 else 0 end) as passed_controls, 
    count(infra.cis_control_id) as total_controls,
    (CASE WHEN (select type from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) and (entity_arn = infra.entity_arn or entity_arn is null) and control_id = infra.cis_control_id limit 1) is not null THEN
    (select type from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) and (entity_arn = infra.entity_arn or entity_arn is null) and control_id = infra.cis_control_id limit 1) ELSE infra.result END) as result,
    infra.cis_control_id,infra.cloud_type,
    cis.severity as name,cis.title, 
    count(cis.severity) as severity_count,
    infra.product, ags.service_id, infra.entity_arn, infra.entity_name, rc.domain_id, rc.family_id, rc.domain_name, rc.family_name, rc.control_id, rc.control_name, rc.sub_control_id, rc.sub_control_name,rc.mapping_id, rnm.nist_id
    from infrastructure_services_compliance infra 
    join (select batch_id, entity_arn, cloud_type from (select batch_id, entity_arn,cloud_type, row_number() OVER (PARTITION BY cloud_type,entity_arn ORDER BY batch_id DESC) as rank from infrastructure_services_compliance where organization_id in (select org_chain_list(:orgId) ) group by batch_id,cloud_type,entity_arn) isc where rank <= 1 ) as max_batch_infra on max_batch_infra.batch_id = infra.batch_id and max_batch_infra.entity_arn = infra.entity_arn and max_batch_infra.cloud_type = infra.cloud_type 
    join cis_webservices_controls cis on cis.control_id = infra.cis_control_id and cis.cloud_type = infra.cloud_type
    join nist_cis_mappings ncm on ncm.mapping_id = cis.control_id and ncm.cloud_type = infra.cloud_type
    join regulation_nist_mappings rnm on ncm.nist_id = rnm.nist_id 
    join regulation_controls rc on rc.mapping_id = rnm.mapping_id and rc.certificate_id = rnm.certificate_id and rc.compliance = 'Auto'
    join application_group_service_view ags on infra.entity_arn = ags.entity_arn and ags.organization_id in (select org_chain_list(:orgId)) 
    join organizations o on o.id = infra.organization_id
    ${applicationServicesJoin}
    join certificates c on c.id = rc.certificate_id and c.id = (select id from certificates where UPPER(name) = UPPER('${this.regulationName}'))
    where infra.organization_id in (select org_chain_list(:orgId)) and
    ${mappingId}
    ${controlId}
    ${domainId}
    ${controlName}
    ${subControlName}
    ${serviceApplicationName}
    1=1
    group by cis.title,infra.organization_id, o.name, top_org, ags.application_name, result, infra.cis_control_id, infra.cloud_type,cis.severity, infra.product, ags.service_id, 
    infra.entity_arn, infra.entity_name, rc.domain_id, rc.family_id, rc.domain_name, rc.family_name, rc.control_id, rc.control_name, rc.sub_control_id, rc.sub_control_name, rc.mapping_id,rnm.nist_id) outer_sql`;
  }

  regulationControlViewDownload(condition) {
    return `select distinct '${this.regulationName}' as regulation,dc.id,r.rule_id,lower(r.severity) as severity, r.rule_fix, r.rule_desc,application_grp_name as application,scan_type,
    ${this.getReverseMapping(this.regulationName, ['control_id', 'control_desc', 'family_name', 'sub_control_name'])}, npm.nist_id, dc.definition as title,
     initcap(result) as result, cci_id as cci, asset_name, dc.operating_system, dc.test_result,dc.rule_title  from ${where.compliance.viewWithNist} dc 
     join regulation_nist_mappings npm on dc.nist_index = npm.nist_id 
     join regulation_controls rc on rc.mapping_id = npm.mapping_id
     join application_tag_certificate_members atc on dc.application_grp_id = atc.application_tag_id join xccdf_rules r on r.rule_id = dc.rule_id 
     ${whereCondition(...conditionFilter(['application_grp_name', 'location_name', 'organization_name', 'application_name', 'source', 'asset_type'], condition),
      `atc.certificate_id = (select id from certificates where UPPER(name) = UPPER('${this.certificate}'))`
    )}`;
  }

  regulationControlViewSubControl(condition, subControl) {
    return ` select npm.nist_id,${this.getReverseMapping(this.regulationName, ['sub_control_name'])},result,asset_name, dc.vmid,cci_id as cci from ${where.compliance.viewWithNist} dc 
    join regulation_nist_mappings npm on dc.nist_index = npm.nist_id 
    join regulation_controls rc on rc.mapping_id = npm.mapping_id
     where c.mapping_id = :subControl and dc.id in (select id from assets where ${where.common.orgChainFilter} group by npm.nist_id, c.name,result,asset_name, dc.vmid,cci_id`;
  }

  topFailedControlFamily(condition) {
    const applicationName = condition.application_name ? `ags.application_name = '${condition.application_name}' and` : '';
    const serviceApplicationName = condition.application_name ? `agsv.application_name = '${condition.application_name}' and` : '';

    const applicationJoin = applicationName ? `join application_tag_certificate_members atc on ags.application_id = atc.application_tag_id and rc.certificate_id = atc.certificate_id
    join application_regulation_control_list_function_common(atc.application_tag_id, '${this.regulationName}') arcl on arcl.regulation_control_id = rc.mapping_id` : '';

    const applicationServicesJoin = serviceApplicationName ? `join application_tag_certificate_members atc on agsv.application_grp_id = atc.application_tag_id
    join application_tag_controls_members atcm on atcm.certificate_id = rc.certificate_id and atcm.control_id = rc.mapping_id and atcm.application_id = agsv.application_grp_id` : '';

    return `select control_name,control_count,severity,UPPER('${this.certificate}') as regulation from (
        select control_name,control_count::integer,initcap(severity) as severity, row_number() OVER (PARTITION BY severity ORDER BY severity DESC) AS outerrownum from (
        select * from (select rc.control_name, count(distinct isc.entity_arn) as control_count, LOWER(cis.severity) as severity,
        row_number() OVER (PARTITION BY LOWER(cis.severity) ORDER BY cis.severity DESC) AS rownum
        from infrastructure_services_compliance isc
        join cis_webservices_controls cis on cis.control_id = isc.cis_control_id and cis.cloud_type = isc.cloud_type
        join nist_cis_mappings ncm on ncm.mapping_id = cis.control_id and ncm.cloud_type = isc.cloud_type
        join regulation_nist_mappings rnm on ncm.nist_id = rnm.nist_id 
        join regulation_controls rc on rc.mapping_id = rnm.mapping_id and rc.certificate_id = rnm.certificate_id and rc.compliance = 'Auto'
        join application_group_service_view ags on isc.entity_arn = ags.entity_arn and ags.organization_id in (select org_chain_list(:orgId)) 
        join organizations o on o.id = isc.organization_id
        join (select max(batch_id) as max_batch_id,entity_arn from infrastructure_services_compliance where organization_id in (select org_chain_list(:orgId) ) group by entity_arn ) as max_batch_infra on max_batch_infra.max_batch_id = isc.batch_id and max_batch_infra.entity_arn = isc.entity_arn
        ${applicationJoin}
        join certificates c on c.id = rc.certificate_id and c.id = (select id from certificates where UPPER(name) = UPPER('${this.certificate}'))
        where 
        ${applicationName}
        isc.organization_id in (select org_chain_list(:orgId))
        and lower(isc.result) = 'fail'
        group by rc.control_name, cis.severity
        order by cis.severity,control_count desc
        ) a where rownum <= 10
        UNION ALL
        select * from (select rc.control_name , count(distinct scan.asset_id) as control_count, LOWER(xr.severity) as severity,
        row_number() OVER (PARTITION BY LOWER(xr.severity) ORDER BY xr.severity  DESC) AS rownum
        from daily_scan_xccdf_results scan
        join xccdf_rules xr ON scan.rule_id = xr.rule_id
        join control_correlation_identifier cci on scan.reference  = cci.cci_id
        join regulation_nist_mappings rnm on cci.nist_index = rnm.nist_id
        join regulation_controls rc on rnm.certificate_id = rc.certificate_id and rnm.mapping_id = rc.mapping_id and compliance = 'Auto'
        join application_group_asset_view agsv on agsv.id = scan.asset_id and agsv.organization_id in (select org_chain_list(:orgId))
        ${applicationServicesJoin}
        join (select asset_id, max(batch_id) as max_batch_id from daily_scan_xccdf_results where asset_id in (select id from assets
        where (is_active='enabled' or is_active='true' or is_active='disabled') and
        organization_id in (select org_chain_list(:orgId)) )
        group by asset_id) as max_scanresult on scan.asset_id = max_scanresult.asset_id and scan.batch_id = max_scanresult.max_batch_id
        join certificates c on c.id = rc.certificate_id and c.id = (select id from certificates where UPPER(name) = UPPER('${this.certificate}'))
        where
        ${serviceApplicationName}
        scan.organization_id in (select org_chain_list(:orgId)) and rc.certificate_id in (select distinct certificate_id From org_certificate_members where organization_id in (select org_chain_list(:orgId)) order by certificate_id)
        and (scan.asset_id::varchar, scan.rule_id) NOT IN (select entity_arn,control_id from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) )
        and scan.organization_id in (select org_chain_list(:orgId))
        and lower(scan.scan_result)  = 'fail'
        group by rc.control_name, xr.severity  
        order by control_count desc 
        ) c where rownum <= 10
      ) d
    ) outer_sql where outerrownum <= 10 and severity in ('Critical','High','Medium','Low')
    order by severity, control_count desc`;
  }

  xtopFailedControlFamily(condition) {
    return `select ${this.getReverseMapping(this.regulationName, ['family_name'])},round(avg(n.raw_weighted_risk),2) as compliance_count from 
      (${complianceScore('nist_index', condition)}) as n join regulation_nist_mappings npm on n.label = npm.nist_id 
    join regulation_controls rc on rc.mapping_id = npm.mapping_id 
    ${whereCondition(...conditionFilter(['rc.family_name', 'rc.mapping_id', 'rc.sub_control_id'], condition))}
    group by rc.family_name order by compliance_count desc limit 4`;
  }

  topControlFailure(condition) {
    const applicationName = condition.application_name ? `ags.application_name = '${condition.application_name}' and` : '';
    const serviceApplicationName = condition.application_name ? `agsv.application_name = '${condition.application_name}' and` : '';

    const applicationJoin = applicationName ? `join application_tag_certificate_members atc on ags.application_id = atc.application_tag_id and rc.certificate_id = atc.certificate_id
    join application_regulation_control_list_function_common(atc.application_tag_id, '${this.regulationName}') arcl on arcl.regulation_control_id = rc.mapping_id` : '';

    const applicationServicesJoin = serviceApplicationName ? `join application_tag_certificate_members atc on agsv.application_grp_id = atc.application_tag_id
    join application_tag_controls_members atcm on atcm.certificate_id = rc.certificate_id and atcm.control_id = rc.mapping_id and atcm.application_id = agsv.application_grp_id` : '';

    return `select mapping_id,control_count,severity,UPPER('${this.certificate}') as regulation from (
      select mapping_id,control_count::integer,initcap(severity) as severity, row_number() OVER (PARTITION BY severity ORDER BY severity DESC) AS outerrownum from (	   
        select * from (select rc.mapping_id, count(distinct isc.entity_arn) as control_count, LOWER(cis.severity) as severity,
        row_number() OVER (PARTITION BY LOWER(cis.severity) ORDER BY cis.severity DESC) AS rownum
        from infrastructure_services_compliance isc
        join cis_webservices_controls cis on cis.control_id = isc.cis_control_id and cis.cloud_type = isc.cloud_type
        join nist_cis_mappings ncm on ncm.mapping_id = cis.control_id and ncm.cloud_type = isc.cloud_type
        join regulation_nist_mappings rnm on ncm.nist_id = rnm.nist_id 
        join regulation_controls rc on rc.mapping_id = rnm.mapping_id and rc.certificate_id = rnm.certificate_id and rc.compliance = 'Auto'
        join application_group_service_view ags on isc.entity_arn = ags.entity_arn and ags.organization_id in (select org_chain_list(:orgId)) 
        join organizations o on o.id = isc.organization_id
        join (select max(batch_id) as max_batch_id,entity_arn from infrastructure_services_compliance where organization_id in (select org_chain_list(:orgId) ) group by entity_arn ) as max_batch_infra on max_batch_infra.max_batch_id = isc.batch_id and max_batch_infra.entity_arn = isc.entity_arn
        ${applicationJoin}
        join certificates c on c.id = rc.certificate_id and c.id = (select id from certificates where UPPER(name) = UPPER('${this.certificate}'))
        where 
        ${applicationName}
        isc.organization_id in (select org_chain_list(:orgId))
        and lower(isc.result) = 'fail'
        group by rc.mapping_id, cis.severity
        order by cis.severity,control_count desc
        ) a where rownum <= 10
        UNION ALL
        select * from (select rc.mapping_id , count(distinct scan.asset_id) as control_count, LOWER(xr.severity) as severity,
        row_number() OVER (PARTITION BY LOWER(xr.severity) ORDER BY xr.severity  DESC) AS rownum
        from daily_scan_xccdf_results scan
        join xccdf_rules xr ON scan.rule_id = xr.rule_id
        join control_correlation_identifier cci on scan.reference  = cci.cci_id
        join regulation_nist_mappings rnm on cci.nist_index = rnm.nist_id
        join regulation_controls rc on rnm.certificate_id = rc.certificate_id and rnm.mapping_id = rc.mapping_id and compliance = 'Auto'
        join application_group_asset_view agsv on agsv.id = scan.asset_id and agsv.organization_id in (select org_chain_list(:orgId))
        ${applicationServicesJoin}
        join (select asset_id, max(batch_id) as max_batch_id from daily_scan_xccdf_results where asset_id in (select id from assets
        where (is_active='enabled' or is_active='true' or is_active='disabled') and
        organization_id in (select org_chain_list(:orgId)) )
        group by asset_id) as max_scanresult on scan.asset_id = max_scanresult.asset_id and scan.batch_id = max_scanresult.max_batch_id
        join certificates c on c.id = rc.certificate_id and c.id = (select id from certificates where UPPER(name) = UPPER('${this.certificate}'))
        where
        ${serviceApplicationName}
        scan.organization_id in (select org_chain_list(:orgId)) and rc.certificate_id in (select distinct certificate_id From org_certificate_members where organization_id in (select org_chain_list(:orgId)) order by certificate_id)
        and (scan.asset_id::varchar, scan.rule_id) NOT IN (select entity_arn,control_id from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) )
        and scan.organization_id in (select org_chain_list(:orgId))
        and lower(scan.scan_result)  = 'fail'
        group by rc.mapping_id, xr.severity  
        order by control_count desc 
        ) c where rownum <= 10
      ) d
    ) outer_sql where outerrownum <= 10 and severity in ('Critical','High','Medium','Low')
    order by severity, control_count desc`;
  }

  xtopControlFailure(condition) {
    return `select '${this.regulationName}' as regulation, ${this.getReverseMapping(this.regulationName, ['sub_control_name', 'family_name', 'control_desc'])},count(distinct dc.id) as asset_count, mapping.mapping_id
    from ${where.compliance.viewWithNist} dc, regulation_nist_mappings mapping, application_tag_certificate_members atc, regulation_controls rc
  ${whereCondition(...conditionFilter(['application_grp_name', 'location_name', 'organization_name', 'application_name', 'source', 'asset_type', 'dc.result', 'family_name', 'sub_control_name', 'control_desc'], condition),
      `nist_index = nist_id`,
      where.compliance.resultFailFilter,
      `rc.mapping_id = mapping.mapping_id`,
      `atc.certificate_id = (select id from certificates where UPPER(name) = UPPER('${this.certificate}')) and dc.application_grp_id = atc.application_tag_id`)}
     group by sub_control_name,family_name,control_desc,mapping.mapping_id order by asset_count desc limit 10`;

  }

  topControlFailureTabular(condition) {
    return `select '${this.regulationName}' as regulation,x.rule_id as "Rule Id", organization_name,location,
  application_grp_name as "Application",application_name as "Sub-Application", dc.asset_name as "Asset",dc.asset_name||'^^'||dc.id as asset_hash, dc.id as "AssetId",
  mapping_id as mapping_id,cci_id as "CCI",x.severity, result from ${where.compliance.viewWithNist} dc ,application_tag_certificate_members atc, xccdf_rules x,regulation_nist_mappings npm
  ${whereCondition(...conditionFilter(['application_grp_name', 'location_name', 'organization_name', 'application_name', 'source', 'asset_type'], condition),
      'dc.rule_id = x.rule_id', `nist_index = nist_id`, where.compliance.resultFailFilter,
      `atc.certificate_id = (select id from certificates where UPPER(name) = UPPER('${this.certificate}')) and dc.application_grp_id = atc.application_tag_id`)}`;

  }

  regulationDistributionCounts(condition) {
    return `select distinct dc.asset_name, dc.network_ip, application_grp_name as application_name from ${where.compliance.viewWithNist} dc join regulation_nist_mappings npm on dc.nist_index = npm.nist_id
          join regulation_controls rc on rc.mapping_id = npm.mapping_id ${whereCondition(...conditionFilter(['application_grp_name', 'location_name', 'organization_name', 'application_name', 'source', 'asset_type'], condition)
    )}`;
  }

  regulationDistributionFamilyCounts(condition) {
    return `select distinct dc.asset_name, dc.network_ip,${this.getReverseMapping(this.regulationName, ['family_name'])},mapping_id as mapping_id, application_grp_name as application_name from ${where.compliance.viewWithNist} dc join regulation_nist_mappings npm on dc.nist_index = npm.nist_id
          join regulation_controls rc on rc.mapping_id = npm.mapping_id ${whereCondition(...conditionFilter(['application_grp_name', 'location_name', 'organization_name', 'application_name', 'source', 'asset_type'], condition)
    )}`;
  }

  regulationDistribution(condition) {
    return `select controls as total_controls,
        controls_count as total_controls_count,
        automatable_controls,
        automatable_controls_count,
        failed_cci as failed_ccis,
        failed_cci_count as failed_ccis_count,
        passed_controls,
        passed_controls_count,
        assets,
        assets_count,
        failed_controls,
        failed_controls_count,
        failed_assets,
        failed_assets_count from (
        select array_agg (distinct dc.asset_id) as assets,count(distinct dc.asset_id) as assets_count,
        array_agg(distinct (CASE WHEN result = 'FAIL' THEN nim.mapping_id END)) as failed_controls,
        count(distinct (CASE WHEN result = 'FAIL' THEN nim.mapping_id END)) as failed_controls_count,
        array_agg(distinct (CASE WHEN result = 'FAIL' THEN dc.asset_id END)) as failed_assets,
        count(distinct (CASE WHEN result = 'FAIL' THEN dc.asset_id END)) as failed_assets_count,
        array_agg(distinct (CASE WHEN result = 'FAIL' THEN cci_id END)) as failed_cci,
        count(distinct (CASE WHEN result = 'FAIL' THEN cci_id END)) as failed_cci_count from
        (select nist_id,organization_id, entity_arn as asset_id,result,null as cci_id
        from   (select distinct ncm.nist_id, infra.entity_arn ,infra.organization_id ,infra.result 
        from infrastructure_services_compliance infra, cis_webservices_controls cis,application_group_service_view ags, nist_cis_mappings ncm
        where ncm.mapping_id = cis.control_id and cis.control_id = infra.cis_control_id and infra.entity_arn = ags.entity_arn and ags.organization_id in (select org_chain_list(:orgId))
        and batch_id::text || '__' || infra.entity_arn  in (select max(batch_id) || '__' || entity_arn from infrastructure_services_compliance where organization_id in (select org_chain_list(:orgId)) group by entity_arn)) ds
        -- above is services
        union all 
        -- below is workloads
        select nist_index,organization_id,asset_id::text,result,cci_id
        from (select bb.asset_id, bb.rule_id,cci.nist_index, cci.cci_id,ag.organization_id,bb.result  from
        (select distinct asset_id,scan.rule_id,scan_result as result,scan.reference from daily_scan_xccdf_results scan  
        INNER JOIN xccdf_rules xr ON scan.rule_id = xr.rule_id and scan.reference = xr.rule_identifiers
        where organization_id in (select org_chain_list(:orgId)) and scan.id in (select id from daily_scan_xccdf_results scan where
        date_trunc('hour', scan.created_at) || asset_id::text in (select
        max(date_trunc('hour', created_at)) || asset_id::text from
        daily_scan_xccdf_results where organization_id in (select org_chain_list(:orgId)) and asset_id in (select id from assets where
        (is_active='enabled' or is_active='true' or is_active='disabled') and
        organization_id in (select org_chain_list(:orgId)) ) group by
        asset_id)) ) bb , control_correlation_identifier cci, application_group_asset_view ag
        where cci.cci_id = reference and ag.id = asset_id ) dr  join xccdf_rules x on dr.rule_id=x.rule_id) dc
        join regulation_nist_mappings nim on dc.nist_id = nim.nist_id
        join regulation_controls rc  on rc.mapping_id = nim.mapping_id and rc.certificate_id = nim.certificate_id
        ${whereCondition(...conditionFilter(['application_grp_name', 'location_name', 'organization_name', 'application_name', 'source', 'asset_type', 'dc.result', 'rc.sub_control_name', 'rc.family_name', 'rc.mapping_id'], condition), `dc.organization_id in (select org_chain_list(:orgId))`,
      `rc.certificate_id = (select id from certificates where UPPER(name) = UPPER('${this.certificate}'))`)}) a,
        (select array_agg (distinct mapping_id) as passed_controls,
        count(distinct mapping_id) as passed_controls_count
        from
        (select nim.mapping_id
        from
        (select nist_id,organization_id, entity_arn as asset_id,result,null as cci_id
        from   (select distinct ncm.nist_id, infra.entity_arn ,infra.organization_id ,infra.result 
        from infrastructure_services_compliance infra, cis_webservices_controls cis,application_group_service_view ags, nist_cis_mappings ncm
        where ncm.mapping_id = cis.control_id and cis.control_id = infra.cis_control_id and infra.entity_arn = ags.entity_arn and ags.organization_id in (select org_chain_list(:orgId))
        and batch_id::text || '__' || infra.entity_arn  in (select max(batch_id) || '__' || entity_arn from infrastructure_services_compliance where organization_id in (select org_chain_list(:orgId)) group by entity_arn)) ds
        -- above is services
        union all 
        -- below is workloads
        select nist_index,organization_id,asset_id::text,result,cci_id
        from (select bb.asset_id, bb.rule_id,cci.nist_index, cci.cci_id,ag.organization_id,bb.result  from
        (select distinct asset_id,scan.rule_id,scan_result as result,scan.reference from daily_scan_xccdf_results scan  
        INNER JOIN xccdf_rules xr ON scan.rule_id = xr.rule_id and scan.reference = xr.rule_identifiers
        where organization_id in (select org_chain_list(:orgId)) and scan.id in (select id from daily_scan_xccdf_results scan where
        date_trunc('hour', scan.created_at) || asset_id::text in (select
        max(date_trunc('hour', created_at)) || asset_id::text from
        daily_scan_xccdf_results where organization_id in (select org_chain_list(:orgId)) and asset_id in (select id from assets where
        (is_active='enabled' or is_active='true' or is_active='disabled') and
        organization_id in (select org_chain_list(:orgId)) ) group by
        asset_id)) ) bb , control_correlation_identifier cci, application_group_asset_view ag
        where cci.cci_id = reference and ag.id = asset_id ) dr  join xccdf_rules x on dr.rule_id=x.rule_id) dc
        join regulation_nist_mappings nim on dc.nist_id = nim.nist_id
        join regulation_controls rc  on rc.mapping_id = nim.mapping_id and rc.certificate_id = nim.certificate_id
        ${whereCondition(...conditionFilter(['application_grp_name', 'location_name', 'organization_name', 'application_name', 'source', 'asset_type', 'dc.result', 'rc.sub_control_name', 'rc.family_name', 'rc.mapping_id'], condition),
      `dc.organization_id in (select org_chain_list(:orgId))`,
      `rc.certificate_id = (select id from certificates where UPPER(name) = UPPER('${this.certificate}'))`
    )} group by nim.mapping_id having every(result = 'PASS') is TRUE) x ) b,
        (select array_agg(distinct mapping_id) as controls, count(distinct mapping_id) as controls_count from regulation_controls rc ${whereCondition(...conditionFilter(['rc.control_name', 'rc.family_name', 'rc.mapping_id'], condition), `certificate_id = (select id from certificates where UPPER(name) = UPPER('${this.certificate}')`)} )) c,
        (select array_agg(distinct mapping_id) as automatable_controls, count(distinct mapping_id) as automatable_controls_count from regulation_controls rc ${whereCondition(...conditionFilter(['rc.control_name', 'rc.family_name', 'rc.mapping_id'], condition), `certificate_id = (select id from certificates where UPPER(name) = UPPER('${this.certificate}')`, `compliance = 'Auto'`)} )) d`;
  }

  regulationDistributionTotals(condition) {
    return `select * from regulation_controls rc ${whereCondition(...conditionFilter(['rc.mapping_id', 'rc.sub_control_name', 'rc.family_name'], condition))}`;
  }

  regulationDistributionTabular(condition) {
    return `select f.*,a.implementation_status,a.notes from (
  select distinct npm.nist_id as "NIST Id", 
  ${this.getReverseMapping(this.regulationName, ['rc.mapping_id', 'sub_control_name', 'control_name', 'family_name'])},initcap(result) as "Result",asset_name as "Asset", dc.asset_id as asset_id,dc.organization_name as "Organization",
  dc.application_name as "Sub-Application",dc.application_grp_name as "Application", dc.vmid,cci_id as "CCI",
  initcap(severity) as "Severity", dc.realm AS "registeredName" ,
  dc.network_ip as ipAddress from ${where.compliance.viewWithNist} dc
  join regulation_nist_mappings npm on dc.nist_index = npm.nist_id 
  join regulation_controls rc on rc.mapping_id = npm.mapping_id
  join xccdf_rules x on x.rule_id = dc.rule_id ${
      whereCondition(
        ...conditionFilter(condition),
        where.compliance.createdAtComplianceFilter
      )}) f left join application_tag_controls_members a on a.control_id=f.mapping_id`;
  }

  topApplicationByRegulationTabular(condition) {
    return `select upper('${this.certificate}') as regulation, reference_id, result,asset_id, asset_name as "Asset", vmid, application_name as "Sub-Application", 
  application_grp_name as "Application", organization as "Organization", location as "Location", o.final_count as "${this.regulationName}_percent", 
  p.name as severity from ( select reference_id, result,asset_id, asset_name , vmid, application_name , application_grp_name , organization , location, compliance_count::float/total_count as final_count from 
  (select cci_id as reference_id, result,dc.id as asset_id, asset_name , vmid, application_name , application_grp_name , organization_name as organization , location, count(dc.id) as total_count, sum(case
        when lower(severity) ='low' then 2  when lower(severity) ='medium' then 5 when
        lower(severity) ='high' then 8 when lower(severity) ='critical' then 10 else 1 end) as
        compliance_count from 
  ${where.compliance.viewWithNist} dc,xccdf_rules x, regulation_nist_mappings npm ${whereCondition(...conditionFilter(['organization_name', 'location', 'application_grp_name', 'application_name', 'asset_type'], condition), `nist_index = nist_id`, 'x.rule_id = dc.rule_id')} group by dc.id, cci_id, result,asset_id, asset_name , vmid, application_name , application_grp_name , organization_name , location order by compliance_count ) as t) as o join priorities p on o.final_count <=p.max_value::float and o.final_count >= p.min_value::float  ${whereCondition(...conditionFilter(['p.name'], condition))}`;

  }

  applicationRegulationCounts(condition) {
    return `select ac.name,'${this.certificate}' as regulation, coalesce(every(result = 'pass'), true) as passed from application_certifications ac  
 left join ${where.compliance.viewWithNist} dc on ac.application_id = dc.application_grp_id
left join regulation_nist_mappings npm on dc.nist_index = npm.nist_id
    left join regulation_controls rc on rc.mapping_id = npm.mapping_id 
        ${whereCondition(...conditionFilter(condition))} group by ac.name`;
  }

  assetRegulationCounts(condition) {
    return `select asset_name, '${this.certificate}' as regulation,every(result = 'pass') as passed from ${where.compliance.viewWithNist} dc
join regulation_nist_mappings npm on dc.nist_index = npm.nist_id
    join regulation_controls rc on rc.mapping_id = npm.mapping_id
        join xccdf_rules x on x.rule_id = dc.rule_id ${
      whereCondition(
        ...conditionFilter(condition)
      )} group by asset_name`;
  }

  applicationReportsBase(condition, selector, date) {
    return `select  initcap(result) as result, ${this.getReverseMapping(this.regulationName, ['sub_control_name'])},
        dc.asset_name, dc.application_grp_name as application from ${where.compliance.viewWithNist} dc join regulation_nist_mappings npm on dc.nist_index = npm.nist_id
    join regulation_controls rc on rc.mapping_id = npm.mapping_id ${whereCondition(
      `npm.mapping_id in (select control_id from application_tag_controls_members atcm where atcm.certificate_id = (select id from certificates where UPPER(name) = UPPER('${this.regulationName}')))`,
      `dc.application_grp_id in (select application_id from application_tag_controls_members atcm where atcm.certificate_id = (select id from certificates where UPPER(name) = UPPER('${this.regulationName}')))`,
      ...conditionFilter(condition),
      'dc.application_id = :applicationId'
    )}`;
  }

  applicationReportsControls(condition, selector, date) {
    return `select (select name from application_tags where id = :applicationId) as application,${this.getReverseMapping(this.regulationName, ['sub_control_name'])},* from regulation_controls rc`;
  }

  applicationReportsStatus(condition, selector, date) {
    return `select implementation_status,notes,control_id as sub_control, true as found from application_tag_controls_members atcm ${whereCondition(`atcm.certificate_id = (select id from certificates where UPPER(name) = UPPER('${this.regulationName}'))`, 'atcm.application_id = :applicationId')}`;
  }

  getWhereMapping(selector) {
    return this.mapping;
  }

  getReverseMapping(selector, columns) {
    //const inverseMapping = _.invert(this.getWhereMapping(selector).mapping);
    return columns.join(', ');
  }

}

module.exports = ComplianceFactory;
