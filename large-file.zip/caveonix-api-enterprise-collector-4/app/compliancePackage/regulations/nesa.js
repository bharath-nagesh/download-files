const BaseCompliance = require('../complianceFactory');
const whereCondition = require('../../../utils/whereParser.js');
const conditionFilter = require('../../../utils/conditionFilter');

class NESA extends BaseCompliance {
  constructor() {
    super();
    this.regulationName = 'NESA';
    this.selector = this.regulationName.toLowerCase();
    this.certificate = this.selector;
    this.controlDescription = 'nesa.title';
    this.familyName = 'nesa.family';
    this.testId;
    this.subControl = 'nesa.name';
    this.nistMappingTable = 'nist_nesa_mappings';
    this.controlTableMappingId = 'nesa.mapping_id';
    this.controlTable = 'nesa_controls nesa';
    this.nistRegulationMappingId = 'nesa_id';
    this.mapping = {
      apply: true,
      mapping: {
        mapping_id: this.nistRegulationMappingId,
        sub_control: 'nesa.name',
        name: 'nesa.name',
        'nesa.name': 'nesa.name',
        source: 'source',
        asset_type: 'asset_type',
        application: 'application_grp_name',
        result: 'dc.result',
        family_control: 'nesa.family',
        domain_id: 'domain_id',
        domain_name: 'domain_name',
        domain_description: 'domain_desc',
        family_id: 'family_id',
        family_name: 'family_name',
        family_description: 'family_desc',
        control_id: 'rc.mapping_id',
        control_name: 'control_name',
        control_desc: 'control_desc',
        control_guidance: 'control_guidance',
        control_additional_information: 'control_additional_information',
        control_test_id: 'control_test_id',
        control_test: 'control_test',
        control_baseline: 'control_baseline',
        control_priority: 'control_priority',
        sub_control_id: 'sub_control_id',
        sub_control_name: 'sub_control_name',
        sub_control_description: 'sub_control_desc',
        sub_control_guidance: 'sub_control_guidance',
        sub_control_additional_information: 'sub_control_additional_information',
        sub_control_test_id: 'sub_control_test_id',
        sub_control_test: 'sub_control_test',
        sub_control_baseline: 'sub_control_baseline',
        sub_control_priority: 'sub_control_priority'
      }
    };
  }

  regulationDistributionTotals(condition) {
    return `select family as "Family",control_type as "ControlType",name as "Name",type as "Type",title as "Title",priority as "Priority",version as "Version",standards as "Description",directive as "Directive",preventive as "Preventive",detective as "Detective",corrective as "Corrective",low,medium,high,version_history as "Version_History",dependencies as "Dependencies",control_ref as "ControlRef",compliance as "Compliance" from nesa_controls nesa ${whereCondition(...conditionFilter([this.mapping.mapping.control_id, this.mapping.mapping.sub_control, this.mapping.mapping.family_control, this.mapping.mapping.family], condition))}`;

  }
}

module.exports = NESA;
