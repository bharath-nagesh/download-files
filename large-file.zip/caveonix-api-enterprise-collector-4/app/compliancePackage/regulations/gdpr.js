const BaseCompliance = require('../complianceFactory');
const whereCondition = require('../../../utils/whereParser.js');
const conditionFilter = require('../../../utils/conditionFilter');

class GDPR extends BaseCompliance {
  constructor() {
    super();
    this.regulationName = 'GDPR';
    this.selector = this.regulationName.toLowerCase();
    this.certificate = this.selector;
    this.controlDescription = 'gdpr.artical_title';
    this.familyName = 'gdpr.chapter_title';
    this.testId;
    this.subControl = 'gdpr.artical_id';
    this.nistMappingTable = '(gdpr_iso_mappings g join nist_iso_mappings n on n.iso_27001 = g.iso_id)';
    this.controlTable = 'gdpr_controls gdpr';
    this.controlTableMappingId = 'gdpr.artical_id';
    this.nistRegulationMappingId = 'gdpr_id';
    this.mapping = {
      apply: true,
      mapping: {
        mapping_id: this.nistRegulationMappingId,
        sub_control: 'gdpr.artical_id',
        artical_id: 'gdpr.artical_id',
        name: 'gdpr.chapter_title',
        'gdpr.chapter_title': 'gdpr.chapter_title',
        source: 'source',
        asset_type: 'asset_type',
        application: 'application_grp_name',
        result: 'dc.result',
        family_control: 'gdpr.chapter_title',
        control_id: 'rc.mapping_id',
        domain_id: 'domain_id',
        domain_name: 'domain_name',
        domain_description: 'domain_desc',
        section_id: 'family_id',
        family_name: 'family_name',
        family_description: 'family_desc',
        article: 'control_id',
        article_name: 'control_name',
        article_description: 'control_desc',
        control_guidance: 'control_guidance',
        control_additional_information: 'control_additional_information',
        control_test_id: 'control_test_id',
        control_test: 'control_test',
        control_baseline: 'control_baseline',
        control_priority: 'control_priority',
        sub_control_id: 'sub_control_id',
        sub_control_name: 'sub_control_name',
        sub_control_description: 'sub_control_desc',
        sub_control_guidance: 'sub_control_guidance',
        sub_control_additional_information: 'sub_control_additional_information',
        sub_control_test_id: 'sub_control_test_id',
        sub_control_test: 'sub_control_test',
        sub_control_baseline: 'sub_control_baseline',
        sub_control_priority: 'sub_control_priority'
      }
    };
  }

  regulationDistributionTotals(condition) {
    return `select chapter as "Chapter",chapter_title as "ChapterTitle",session as "Session",title as "Title",artical_id as "ArticalId",artical as "Name",artical_title as "ArticalTitle",description as "Description",compliance as "Compliance" from gdpr_controls gdpr ${whereCondition(...conditionFilter([this.mapping.mapping.control_id,this.mapping.mapping.sub_control,this.mapping.mapping.family_control,this.mapping.mapping.family],condition))}`;

  }
}

module.exports = GDPR;
