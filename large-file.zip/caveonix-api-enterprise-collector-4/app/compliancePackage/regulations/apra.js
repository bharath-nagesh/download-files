const BaseCompliance = require('../complianceFactory');
const whereCondition = require('../../../utils/whereParser.js');
const conditionFilter = require('../../../utils/conditionFilter');

class APRA extends BaseCompliance {
  constructor() {
    super();
    this.regulationName = 'APRA-CPS';
    this.selector = 'apra-cps';
    this.certificate = this.selector;
    this.controlDescription = 'apra.control_desc';
    this.familyName = 'apra.family_name';
    this.testId;
    this.subControl = 'apra.control_id';
    this.nistMappingTable = 'nist_apra_cps_mappings';
    this.controlTableMappingId = 'apra.mapping_id';
    this.controlTable = 'apra_cps_controls apra';
    this.nistRegulationMappingId = 'apra_cps_id';
    this.mapping = {
      apply: true,
      mapping: {
        mapping_id: this.nistRegulationMappingId,
        sub_control: 'apra.control_id',
        control_id: 'rc.mapping_id',
        name: 'apra.family_name',
        'apra.name': 'apra.family_name',
        source: 'source',
        asset_type: 'asset_type',
        application: 'application_grp_name',
        result: 'dc.result',
        family_control: 'apra.family_name',
        domain_id: 'domain_id',
        domain_name: 'domain_name',
        domain_description: 'domain_desc',
        section_id: 'family_id',
        section: 'family_name',
        family_description: 'family_desc',
        paragraph: 'control_id',
        control_name: 'control_name',
        control_desc: 'control_desc',
        control_guidance: 'control_guidance',
        control_additional_information: 'control_additional_information',
        control_test_id: 'control_test_id',
        control_test: 'control_test',
        control_baseline: 'control_baseline',
        control_priority: 'control_priority',
        sub_control_id: 'sub_control_id',
        sub_control_name: 'sub_control_name',
        sub_control_description: 'sub_control_desc',
        sub_control_guidance: 'sub_control_guidance',
        sub_control_additional_information: 'sub_control_additional_information',
        sub_control_test_id: 'sub_control_test_id',
        sub_control_test: 'sub_control_test',
        sub_control_baseline: 'sub_control_baseline',
        sub_control_priority: 'sub_control_priority'
      }
    };
  }

  regulationDistributionTotals(condition) {
    return `select family_name as "Family", control_name as "Name",control_desc as "Description",compliance as "Compliance" from apra_cps_controls apra ${whereCondition(...conditionFilter([this.mapping.mapping.control_id, this.mapping.mapping.sub_control, this.mapping.mapping.family_control, this.mapping.mapping.family], condition))}`;

  }

}

module.exports = APRA;
