const BaseCompliance = require('../complianceFactory');
const whereCondition = require('../../../utils/whereParser.js');
const conditionFilter = require('../../../utils/conditionFilter');

class PCI extends BaseCompliance {
  constructor() {
    super();
    this.regulationName = 'PCI';
    this.selector = this.regulationName.toLowerCase();
    this.certificate = this.selector;
    this.controlDescription = 'pci.requirements';
    this.familyName = 'pci.family';
    this.testId;
    this.subControl = 'pci.req_id';
    this.nistMappingTable = 'nist_pci_mappings';
    this.controlTable = 'pci_controls pci';
    this.controlTableMappingId = 'pci.mapping_id';
    this.nistRegulationMappingId = 'pci_id';
    this.mapping = {
      apply: true,
      mapping: {
        mapping_id: this.nistRegulationMappingId,
        sub_control: 'pci.req_id',
        name: 'pci.family',
        'pci.name': 'pci.family',
        source: 'source',
        asset_type: 'asset_type',
        application: 'application_grp_name',
        result: 'dc.result',
        family_control: 'pci.family',
        control_id: 'rc.mapping_id',
        domain_id: 'domain_id',
        goals: 'domain_name',
        domain_description: 'domain_desc',
        requirement: 'family_id',
        requirement_name: 'family_name',
        family_description: 'family_desc',
        control: 'control_id',
        control_name: 'control_name',
        requirement_description: 'control_desc',
        guidance: 'control_guidance',
        control_additional_information: 'control_additional_information',
        control_test_id: 'control_test_id',
        testing_procedures: 'control_test',
        control_baseline: 'control_baseline',
        control_priority: 'control_priority',
        sub_control_id: 'sub_control_id',
        sub_control_name: 'sub_control_name',
        sub_control_description: 'sub_control_desc',
        sub_control_guidance: 'sub_control_guidance',
        sub_control_additional_information: 'sub_control_additional_information',
        sub_control_test_id: 'sub_control_test_id',
        sub_control_test: 'sub_control_test',
        sub_control_baseline: 'sub_control_baseline',
        sub_control_priority: 'sub_control_priority'
      }
    };
  }

  regulationDistributionTotals(condition) {
    return `select family as "Family", req_id as "Name",requirements as "Title", test_id as "TestId",testing as "Testing",guidance as "Description",compliance as "Compliance" from pci_controls pci ${whereCondition(...conditionFilter([this.mapping.mapping.control_id,this.mapping.mapping.sub_control,this.mapping.mapping.family_control,this.mapping.mapping.family],condition))}`;

  }
}

module.exports = PCI;
