const path = require('path');
const fs = require('fs');
const basename = path.basename(module.filename);

const map = {};

fs
  .readdirSync(__dirname)
  .filter(function (file) {
    return file.indexOf('.') !== 0 && file !== basename;
  })
  .forEach(function (file) {
    const Regulation = require('./' + file);
    const r = new Regulation();
    const name = r.selector;
    map[name] = Regulation;

  });

module.exports = map;
