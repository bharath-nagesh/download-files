const BaseCompliance = require('../complianceFactory');
const whereCondition = require('../../../utils/whereParser.js');
const conditionFilter = require('../../../utils/conditionFilter');

class NIST_800_171 extends BaseCompliance {
  constructor() {
    super();
    this.regulationName = 'NIST-800-171';
    this.selector = 'nist-800-171';
    this.certificate = this.selector;
    this.controlDescription = 'nist.control_desc';
    this.familyName = 'nist.family_name';
    this.testId;
    this.subControl = 'nist.control_id';
    this.nistMappingTable = '(SELECT nist_id,mapping_id from nist_nist_800_171_mappings)';
    this.controlTable = 'nist_800_171_controls nist';
    this.controlTableMappingId = 'nist.mapping_id';
    this.nistRegulationMappingId = 'mapping_id';
    this.mapping = {
      apply: true,
      mapping: {
        mapping_id: this.nistRegulationMappingId,
        control_id: 'rc.mapping_id',
        sub_control: 'nist.control_id',
        name: 'nist.family_name',
        'nist.name': 'nist.family_name',
        source: 'source',
        asset_type: 'asset_type',
        application: 'application_grp_name',
        result: 'dc.result',
        family_control: 'nist.family_name',
        domain_id: 'domain_id',
        domain_name: 'domain_name',
        domain_description: 'domain_desc',
        family_id: 'family_id',
        family_name: 'family_name',
        family_description: 'family_desc',
        requirement: 'control_id',
        control_name: 'control_name',
        requirement_description: 'control_desc',
        requirement_guidance: 'control_guidance',
        control_additional_information: 'control_additional_information',
        control_test_id: 'control_test_id',
        control_test: 'control_test',
        control_baseline: 'control_baseline',
        priority: 'control_priority',
        sub_control_id: 'sub_control_id',
        sub_control_name: 'sub_control_name',
        sub_control_description: 'sub_control_desc',
        sub_control_guidance: 'sub_control_guidance',
        sub_control_additional_information: 'sub_control_additional_information',
        sub_control_test_id: 'sub_control_test_id',
        sub_control_test: 'sub_control_test',
        sub_control_baseline: 'sub_control_baseline',
        sub_control_priority: 'sub_control_priority'
      }
    };
  }

  regulationDistributionTotals(condition) {
    return `select id, family_name as "FamilyName",control_id as "Control Id",  family_name as "Name",family_name as "Title", control_desc as "Description",compliance as "Compliance" from nist_800_171_controls nist ${whereCondition(...conditionFilter([this.mapping.mapping.control_id, this.mapping.mapping.sub_control, this.mapping.mapping.family_control, this.mapping.mapping.family], condition))}`;

  }
}

module.exports = NIST_800_171;
