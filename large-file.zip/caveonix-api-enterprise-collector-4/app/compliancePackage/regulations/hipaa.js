const BaseCompliance = require('../complianceFactory');
const whereCondition = require('../../../utils/whereParser.js');
const conditionFilter = require('../../../utils/conditionFilter');

class HIPAA extends BaseCompliance {
  constructor() {
    super();
    this.regulationName = 'HIPAA';
    this.selector = this.regulationName.toLowerCase();
    this.certificate = this.selector;
    this.controlDescription = 'hipaa.title';
    this.familyName = 'hipaa.family';
    this.testId;
    this.subControl = 'hipaa.control_type';
    this.nistMappingTable = 'nist_hipaa_mappings';
    this.controlTable = 'hipaa_controls hipaa';
    this.controlTableMappingId = 'hipaa.mapping_id';
    this.nistRegulationMappingId = 'hipaa_id';
    this.mapping = {
      apply: true,
      mapping: {
        mapping_id: this.nistRegulationMappingId,
        sub_control: 'hipaa.control_type',
        name: 'hipaa.family',
        'hipaa.family': 'hipaa.family',
        source: 'source',
        asset_type: 'asset_type',
        application: 'application_grp_name',
        result: 'dc.result',
        family_control: 'hipaa.family',
        control_id: 'rc.mapping_id',
        domain_id: 'domain_id',
        domain_name: 'domain_name',
        domain_description: 'domain_desc',
        family_id: 'family_id',
        section_objective: 'family_name',
        family_description: 'family_desc',
        section: 'control_id',
        key_activity: 'control_name',
        established_performance_criteria: 'control_desc',
        control_guidance: 'control_guidance',
        control_additional_information: 'control_additional_information',
        control_test_id: 'control_test_id',
        audit_inquiry: 'control_test',
        control_baseline: 'control_baseline',
        control_priority: 'control_priority',
        sub_control_id: 'sub_control_id',
        sub_control_name: 'sub_control_name',
        sub_control_description: 'sub_control_desc',
        sub_control_guidance: 'sub_control_guidance',
        sub_control_additional_information: 'sub_control_additional_information',
        sub_control_test_id: 'sub_control_test_id',
        sub_control_test: 'sub_control_test',
        sub_control_baseline: 'sub_control_baseline',
        sub_control_priority: 'sub_control_priority'
      }
    };
  }

  regulationDistributionTotals(condition) {
    return `select family as "Family",control_type as "Name",title as "Title",implementation as "Implementation",guidance as "Description",compliance as "Compliance" from hipaa_controls hipaa ${whereCondition(...conditionFilter([this.mapping.mapping.control_id, this.mapping.mapping.sub_control, this.mapping.mapping.family_control, this.mapping.mapping.family], condition))}`;

  }
}

module.exports = HIPAA;
