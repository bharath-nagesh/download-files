const BaseCompliance = require('../complianceFactory');
const whereCondition = require('../../../utils/whereParser.js');
const conditionFilter = require('../../../utils/conditionFilter');

class KORISMS extends BaseCompliance {
  constructor() {
    super();
    this.regulationName = 'KOR-ISMS';
    this.selector = 'kor-isms';
    this.certificate = this.selector;
    this.controlDescription = 'korisms.control_desc';
    this.familyName = 'korisms.family';
    this.testId;
    this.subControl = 'korisms.control_id';
    this.nistMappingTable = 'nist_kor_isms_mappings';
    this.controlTable = 'kor_isms_controls korisms';
    this.controlTableMappingId = 'korisms.mapping_id';
    this.nistRegulationMappingId = 'mapping_id';
    this.mapping = {
      apply: true,
      mapping: {
        mapping_id: this.nistRegulationMappingId,
        sub_control: 'korisms.control_id',
        control_id:'rc.mapping_id',
        name: 'korisms.family',
        'korisms.family': 'korisms.family',
        source: 'source',
        asset_type: 'asset_type',
        application: 'application_grp_name',
        result: 'dc.result',
        family_control: 'korisms.family',
        domain_id: 'domain_id',
        domain_name: 'domain_name',
        domain_description: 'domain_desc',
        family_id: 'family_id',
        family_name: 'family_name',
        family_description: 'family_desc',
        control: 'control_id',
        control_name: 'control_name',
        control_description: 'control_desc',
        control_guidance: 'control_guidance',
        control_additional_information: 'control_additional_information',
        control_test_id: 'control_test_id',
        control_test: 'control_test',
        control_baseline: 'control_baseline',
        control_priority: 'control_priority',
        sub_control_id: 'sub_control_id',
        sub_control_name:'sub_control_name',
        sub_control_description: 'sub_control_desc',
        sub_control_guidance: 'sub_control_guidance',
        sub_control_additional_information: 'sub_control_additional_information',
        sub_control_test_id: 'sub_control_test_id',
        sub_control_test: 'sub_control_test',
        sub_control_baseline: 'sub_control_baseline',
        sub_control_priority: 'sub_control_priority'
      }
    };

  }

  regulationDistributionTotals(condition) {
    return `select family as "Family", control_id as "Name",control_name as "Control Name", control_desc as "Description",compliance as "Compliance" from ${this.controlTable} ${whereCondition(...conditionFilter([this.mapping.mapping.control_id,this.mapping.mapping.sub_control,this.mapping.mapping.family_control,this.mapping.mapping.family],condition))}`;

  }
}

module.exports = KORISMS;
