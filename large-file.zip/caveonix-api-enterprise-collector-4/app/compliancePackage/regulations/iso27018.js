const BaseCompliance = require('../complianceFactory');
const whereCondition = require('../../../utils/whereParser.js');
const conditionFilter = require('../../../utils/conditionFilter');

class ISO_27018 extends BaseCompliance {
  constructor() {
    super();
    this.regulationName = 'ISO-27018';
    this.selector = 'iso-27018';
    this.certificate = this.selector;
    this.controlDescription = 'iso.clause_name';
    this.familyName = 'iso.category_name';
    this.testId;
    this.subControl = 'iso.control_id';
    this.nistMappingTable = 'nist_iso_27018_mappings';
    this.controlTable = 'iso_27018_controls iso';
    this.controlTableMappingId = 'iso.mapping_id';
    this.nistRegulationMappingId = 'mapping_id';
    this.mapping = {
      apply: true,
      mapping: {
        mapping_id: this.nistRegulationMappingId,
        sub_control: 'iso.control_id',
        control_id: 'rc.mapping_id',
        name: 'iso.category_name',
        family_control: 'iso.category_name',
        'iso.name': 'iso.category_name',
        source: 'source',
        asset_type: 'asset_type',
        application: 'application_grp_name',
        result: 'dc.result',
        domain_id: 'domain_id',
        domain_name: 'domain_name',
        domain_description: 'domain_desc',
        clause_id: 'family_id',
        clause_name: 'family_name',
        family_description: 'family_desc',
        category: 'control_id',
        category_name: 'control_name',
        category_description: 'control_desc',
        Supplementary_information: 'control_guidance',
        control_additional_information: 'control_additional_information',
        control_test_id: 'control_test_id',
        control_test: 'control_test',
        control_baseline: 'control_baseline',
        control_priority: 'control_priority',
        control: 'sub_control_id',
        control_name:'sub_control_name',
        control_description:'sub_control_desc',
        control_guidance:'sub_control_guidance',
        other_information:'sub_control_additional_information',
        sub_control_test_id: 'sub_control_test_id',
        sub_control_test: 'sub_control_test',
        sub_control_baseline: 'sub_control_baseline',
        sub_control_priority: 'sub_control_priority'
      }
    };
  }

  regulationDistributionTotals(condition) {
    return `select category_name as "Family",control_name as "Name",control_id as "SubControl",clause_name as "Title",control_guide as "Objective",control_desc as "Description" from iso_27018_controls iso ${whereCondition(...conditionFilter([this.mapping.mapping.control_id,this.mapping.mapping.sub_control,this.mapping.mapping.family_control,this.mapping.mapping.family],condition))}`;

  }
}

module.exports = ISO_27018;
