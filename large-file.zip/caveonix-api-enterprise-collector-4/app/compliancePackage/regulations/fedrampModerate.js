const BaseCompliance = require('../complianceFactory');
const whereCondition = require('../../../utils/whereParser.js');
const conditionFilter = require('../../../utils/conditionFilter');

class FEDRAMP_MODERATE extends BaseCompliance {
  constructor() {
    super();
    this.regulationName = 'FEDRAMP MODERATE';
    this.selector = 'fedramp moderate';
    this.certificate = this.selector;
    this.controlDescription = 'fedramp_moderate.control_desc';
    this.familyName = 'fedramp_moderate.family';
    this.testId;
    this.subControl = 'fedramp_moderate.control_id';
    this.nistMappingTable = '(select control_id,control_id as nist_id from fedramp_moderate_controls)';
    this.controlTable = 'fedramp_moderate_controls fedramp_moderate';
    this.controlTableMappingId = 'fedramp_moderate.control_id';
    this.nistRegulationMappingId = 'nist_id';
    this.mapping = {
      apply: true,
      mapping: {
        mapping_id: this.nistRegulationMappingId,
        sub_control: 'fedramp_moderate.control_id',
        control_id: 'rc.mapping_id',
        source: 'source',
        asset_type: 'asset_type',
        application: 'application_grp_name',
        result: 'dc.result',
        family_control: 'family',
        family: 'fedramp_moderate.family',
        domain_id: 'domain_id',
        domain_name: 'domain_name',
        domain_description: 'domain_desc',
        family_id: 'family_id',
        family_name: 'family_name',
        family_description: 'family_desc',
        control: 'control_id',
        control_name: 'control_name',
        control_description: 'control_desc',
        supplemental_guidance: 'control_guidance',
        control_additional_information: 'control_additional_information',
        control_test_id: 'control_test_id',
        control_test: 'control_test',
        control_baseline: 'control_baseline',
        control_priority: 'control_priority',
        enhancement: 'sub_control_id',
        enhancement_name: 'sub_control_name',
        enhancement_description: 'sub_control_desc',
        enhancement_guidance: 'sub_control_guidance',
        sub_control_additional_information: 'sub_control_additional_information',
        sub_control_test_id: 'sub_control_test_id',
        enhancement_test: 'sub_control_test',
        enhancement_baseline: 'sub_control_baseline',
        enhancement_priority: 'sub_control_priority'
      }
    };
  }

  regulationDistributionTotals(condition) {
    return `select id, family as "FamilyName",control_name as "Control Name", control_id as "Name",select_params as "Select Params", guidance as "Guidance",control_desc as "Description",compliance as "Compliance" from fedramp_moderate_controls fedramp_moderate ${whereCondition(...conditionFilter([this.mapping.mapping.control_id,this.mapping.mapping.sub_control,this.mapping.mapping.family_control,this.mapping.mapping.family],condition))}`;

  }
}

module.exports = FEDRAMP_MODERATE;
