const BaseCompliance = require('../complianceFactory');
const whereCondition = require('../../../utils/whereParser.js');
const conditionFilter = require('../../../utils/conditionFilter');

class CSF extends BaseCompliance {
  constructor() {
    super();
    this.regulationName = 'CSF';
    this.selector = this.regulationName.toLowerCase();
    this.certificate = this.selector;
    this.controlDescription = 'csf.control_desc';
    this.familyName = 'csf.function';
    this.testId;
    this.subControl = 'csf.sub_control_id';
    this.nistMappingTable = 'nist_csf_mappings';
    this.controlTable = 'csf_controls csf';
    this.controlTableMappingId = 'csf.mapping_id';
    this.nistRegulationMappingId = 'mapping_id';
    this.mapping = {
      apply: true,
      mapping: {
        mapping_id: this.nistRegulationMappingId,
        sub_control: 'csf.sub_control_id',
        name: 'csf.function',
        'csf.name': 'csf.function',
        source: 'source',
        asset_type: 'asset_type',
        application: 'application_grp_name',
        result: 'dc.result',
        family_control: 'csf.function',
        control_id: 'rc.mapping_id',
        function_id: 'domain_id',
        function: 'domain_name',
        domain_description: 'domain_desc',
        category_id: 'family_id',
        category: 'family_name',
        category_description: 'family_desc',
        sub_category: 'control_id',
        control_name: 'control_name',
        subcategory_description: 'control_desc',
        control_guidance: 'control_guidance',
        control_additional_information: 'control_additional_information',
        control_test_id: 'control_test_id',
        control_test: 'control_test',
        control_baseline: 'control_baseline',
        priority: 'Control_priority',
        sub_control_id: 'sub_control_id',
        sub_control_name: 'sub_control_name',
        sub_control_description: 'sub_control_desc',
        sub_control_guidance: 'sub_control_guidance',
        sub_control_additional_information: 'sub_control_additional_information',
        sub_control_test_id: 'sub_control_test_id',
        sub_control_test: 'sub_control_test',
        sub_control_baseline: 'sub_control_baseline',
        sub_control_priority: 'sub_control_priority'
      }
    };
  }

  regulationDistributionTotals(condition) {
    return `select function as "Family", sub_control_id as "Name",control_name as "Control Name", control_desc as "Description",compliance as "Compliance" from csf_controls csf ${whereCondition(...conditionFilter([this.mapping.mapping.control_id, this.mapping.mapping.sub_control, this.mapping.mapping.family_control, this.mapping.mapping.family], condition))}`;

  }
}

module.exports = CSF;
