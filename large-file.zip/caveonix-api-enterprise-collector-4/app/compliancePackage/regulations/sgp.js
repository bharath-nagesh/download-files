const BaseCompliance = require('../complianceFactory');
const whereCondition = require('../../../utils/whereParser.js');
const conditionFilter = require('../../../utils/conditionFilter');

class SGP extends BaseCompliance {
  constructor() {
    super();
    this.regulationName = 'SGP-MTCS';
    this.selector = 'sgp-mtcs';
    this.certificate = this.selector;
    this.controlDescription = 'sgp.control_desc';
    this.familyName = 'sgp.family';
    this.testId = '';
    this.subControl = 'sgp.control_id';
    this.nistMappingTable = 'nist_sgp_mappings';
    this.controlTable = 'sgp_controls sgp';
    this.controlTableMappingId = 'sgp.mapping_id';
    this.nistRegulationMappingId = 'sgp_id';
    this.mapping = {
      apply: true,
      mapping: {
        mapping_id: this.nistRegulationMappingId,
        sub_control: 'sgp.control_id',
        control_id: 'rc.mapping_id',
        name: 'sgp.family',
        'sgp.name': 'sgp.family',
        source: 'source',
        asset_type: 'asset_type',
        application: 'application_grp_name',
        result: 'dc.result',
        family_control: 'sgp.family',
        domain_id: 'domain_id',
        domain_name: 'domain_name',
        domain_description: 'domain_desc',
        family_id: 'family_id',
        family: 'family_name',
        family_description: 'family_desc',
        control: 'control_id',
        control_name: 'control_name',
        control_description: 'control_desc',
        level_requirements: 'control_guidance',
        control_additional_information: 'control_additional_information',
        control_test_id: 'control_test_id',
        testing_procedures: 'control_test',
        control_baseline: 'control_baseline',
        control_priority: 'control_priority',
        sub_control_id: 'sub_control_id',
        sub_control_name: 'sub_control_name',
        sub_control_description: 'sub_control_desc',
        sub_control_guidance: 'sub_control_guidance',
        sub_control_additional_information: 'sub_control_additional_information',
        sub_control_test_id: 'sub_control_test_id',
        sub_control_test: 'sub_control_test',
        sub_control_baseline: 'sub_control_baseline',
        sub_control_priority: 'sub_control_priority'
      }
    };
  }

  regulationDistributionTotals(condition) {
    return `select family as "Family",family_desc as "Family Description", control_id as "Name",control_name as "Control Name", level1 as "Level 1", level2 as "Level 2", control_desc as "Description",compliance as "Compliance" from sgp_controls sgp ${whereCondition(...conditionFilter([this.mapping.mapping.control_id, this.mapping.mapping.sub_control, this.mapping.mapping.family_control, this.mapping.mapping.family], condition))}`;

  }
}

module.exports = SGP;
