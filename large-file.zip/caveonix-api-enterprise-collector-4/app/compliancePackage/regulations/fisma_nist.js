const BaseCompliance = require('../complianceFactory');
const whereCondition = require('../../../utils/whereParser.js');
const conditionFilter = require('../../../utils/conditionFilter');

class NIST extends BaseCompliance {
  constructor() {
    super();
    this.regulationName = 'FISMA (NIST-800-53-R4)';
    this.selector = 'fisma (nist-800-53-r4)';
    this.certificate = 'fisma (nist-800-53-r4)';
    this.controlDescription = 'nist.title';
    this.familyName = 'nist.family_name';
    this.subControl = 'nist.name';
    this.nistMappingTable = '(select name as nist_id, name as control_id from controls_800_53)';
    this.controlTable = 'controls_800_53 nist';
    this.controlTableMappingId = 'nist.name';
    this.nistRegulationMappingId = 'control_id';
    this.controlFilter = `name SIMILAR TO '__-[0-9][0-9]' or name SIMILAR TO '__-[0-9]'`;
    this.mapping = {
      apply: true,
      mapping: {
        mapping_id: this.nistRegulationMappingId,
        sub_control: 'nist.name',
        control_id: 'rc.mapping_id',
        name: 'nist.family_name',
        'nist.name': 'nist.family_name',
        source: 'source',
        asset_type: 'asset_type',
        application: 'application_grp_name',
        result: 'dc.result',
        family_control: 'nist.family_name',
        family_id: 'family_id',
        family_name: 'family_name',
        family_description: 'family_desc',
        control: 'control_id',
        control_name: 'control_name',
        control_description: 'control_desc',
        supplemental_guidance: 'control_guidance',
        control_additional_information: 'control_additional_information',
        control_test_id: 'control_test_id',
        control_test: 'control_test',
        control_baseline: 'control_baseline',
        control_priority: 'control_priority',
        enhancement: 'sub_control_id',
        enhancement_name: 'sub_control_name',
        enhancement_description: 'sub_control_desc',
        enhancement_guidance: 'sub_control_guidance',
        sub_control_additional_information: 'sub_control_additional_information',
        sub_control_test_id: 'sub_control_test_id',
        enhancement_test: 'sub_control_test',
        enhancement_baseline: 'sub_control_baseline',
        enhancement_priority: 'sub_control_priority'
      }
    };
  }

  regulationDistributionTotals(condition) {
    return `select nist.id, nist.family_name as "FamilyName", nist.name as "Name",title as "Title", priority as "Priority",baseline as "Baseline",description as "Description",supplemental as "Supplemental",related as "Related",nist.compliance as "Compliance" from controls_800_53 nist join regulation_controls rc on rc.mapping_id = nist.name ${whereCondition(...conditionFilter([this.mapping.mapping.control_id, this.mapping.mapping.sub_control, this.mapping.mapping.family_control, this.mapping.mapping.family], condition), ` (name SIMILAR TO '__-[0-9][0-9]' or name SIMILAR TO '__-[0-9]')`)}`;
  }
}

module.exports = NIST;
