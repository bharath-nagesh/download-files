const BaseCompliance = require('../complianceFactory');
const whereCondition = require('../../../utils/whereParser.js');
const conditionFilter = require('../../../utils/conditionFilter');

class ISO extends BaseCompliance {
  constructor() {
    super();
    this.regulationName = 'ISO';
    this.selector = this.regulationName.toLowerCase();
    this.certificate = this.selector;
    this.controlDescription = 'iso.control_desc';
    this.familyName = 'iso.family';
    this.testId;
    this.subControl = 'iso.sub_control';
    this.nistMappingTable = 'nist_iso_mappings';
    this.controlTable = 'iso_controls iso';
    this.controlTableMappingId = 'iso.sub_control';
    this.nistRegulationMappingId = 'iso_27002';
    this.mapping = {
      apply: true,
      mapping: {
        mapping_id: this.nistRegulationMappingId,
        sub_control: 'iso.sub_control',
        xcontrol: 'iso.sub_control',
        name: 'iso.family',
        family_control: 'iso.family',
        'iso.name': 'iso.family',
        source: 'source',
        asset_type: 'asset_type',
        application: 'application_grp_name',
        result: 'dc.result',
        control_id: 'rc.mapping_id',
        domain_id: 'domain_id',
        domain_name: 'domain_name',
        domain_description: 'domain_desc',
        clause_id: 'family_id',
        clause_name: 'family_name',
        family_description: 'family_desc',
        category: 'control_id',
        category_name: 'control_name',
        category_description: 'control_desc',
        supplementary_information: 'control_guidance',
        control_additional_information: 'control_additional_information',
        control_test_id: 'control_test_id',
        control_test: 'control_test',
        control_baseline: 'control_baseline',
        control_priority: 'control_priority',
        control: 'sub_control_id',
        control_name:'sub_control_name',
        control_description:'sub_control_desc',
        implementation:'sub_control_guidance',
        other_information:'sub_control_additional_information',
        sub_control_test_id: 'sub_control_test_id',
        sub_control_test: 'sub_control_test',
        sub_control_baseline: 'sub_control_baseline',
        sub_control_priority: 'sub_control_priority'
      }
    };
  }

  regulationDistributionTotals(condition) {
    return `select family as "Family",sub_control as "Name",title as "Title",objective as "Objective",control_desc as "Description",imp_guidance as "ImpGuidance",other_info as "OtherInfo",compliance as "Compliance" from iso_controls iso ${whereCondition(...conditionFilter([this.mapping.mapping.control_id,this.mapping.mapping.sub_control,this.mapping.mapping.family_control,this.mapping.mapping.family],condition))}`;
  }
}

module.exports = ISO;
