const BaseCompliance = require('../complianceFactory');
const whereCondition = require('../../../utils/whereParser.js');
const conditionFilter = require('../../../utils/conditionFilter');

class FFIEC extends BaseCompliance {
  constructor() {
    super();
    this.regulationName = 'FFIEC';
    this.selector = this.regulationName.toLowerCase();
    this.certificate = this.selector;
    this.controlDescription = 'ffiec.control_desc';
    this.familyName = 'ffiec.family';
    this.subControl = 'ffiec.control';
    this.nistMappingTable = '(ffiec_nist_mappings g join ffiec_cyber_mappings n on n.cyber_id = g.cyber_id)';
    this.controlTable = 'ffiec_controls ffiec';
    this.controlTableMappingId = 'ffiec.mapping_id';
    this.nistRegulationMappingId = 'ffiec_id';
    this.mapping = {
      apply: true,
      mapping: {
        mapping_id: this.nistRegulationMappingId,
        sub_control: 'ffiec.control',
        name: 'ffiec.family',
        'ffiec.family': 'ffiec.family',
        source: 'source',
        asset_type: 'asset_type',
        application: 'application_grp_name',
        result: 'dc.result',
        family_control: 'ffiec.family',
        part: 'domain_id',
        section_name: 'domain_name',
        domain_description: 'domain_desc',
        family_id: 'family_id',
        family_name: 'family_name',
        family_description: 'family_desc',
        control_id: 'rc.mapping_id',
        control_name: 'control_name',
        control_desc: 'control_desc',
        control_guidance: 'control_guidance',
        control_additional_information: 'control_additional_information',
        control_test_id: 'control_test_id',
        control_test: 'control_test',
        control_baseline: 'control_baseline',
        control_priority: 'control_priority',
        sub_control_id: 'sub_control_id',
        sub_control_name: 'sub_control_name',
        sub_control_description: 'sub_control_desc',
        sub_control_guidance: 'sub_control_guidance',
        sub_control_additional_information: 'sub_control_additional_information',
        sub_control_test_id: 'sub_control_test_id',
        sub_control_test: 'sub_control_test',
        sub_control_baseline: 'sub_control_baseline',
        sub_control_priority: 'sub_control_priority'
      }
    };
  }

  regulationDistributionTotals(condition) {
    return `select control as "Control",family as "Name",control_desc as "Description",compliance as "Compliance" from ffiec_controls ffiec ${whereCondition(...conditionFilter([this.mapping.mapping.control_id, this.mapping.mapping.sub_control, this.mapping.mapping.family_control, this.mapping.mapping.family], condition))}`;

  }
}

module.exports = FFIEC;
