const BaseCompliance = require('../complianceFactory');
const whereCondition = require('../../../utils/whereParser.js');
const conditionFilter = require('../../../utils/conditionFilter');

class FISCAM extends BaseCompliance {
  constructor() {
    super();
    this.regulationName = 'FISCAM';
    this.selector = 'fiscam';
    this.certificate = this.selector;
    this.controlDescription = 'fiscam.control_desc';
    this.familyName = 'fiscam.family_name';
    this.subControl = 'fiscam.control_id';
    this.nistMappingTable = 'nist_fiscam_c5_mappings';
    this.controlTable = 'controls_800_53 nist fiscam';
    this.controlTableMappingId = 'fiscam.mapping_id';
    this.nistRegulationMappingId = 'mapping_id';
    this.mapping = {
      apply: true,
      mapping: {
        mapping_id: this.nistRegulationMappingId,
        domain_id: 'domain_id',
        domain_name: 'domain_name',
        domain_description: 'domain_desc',
        family_id: 'family_id',
        family_name: 'family_name',
        family_description: 'family_desc',
        control_reference: 'control_reference',
        control_id: 'rc.mapping_id',
        control_title: 'control_title',
        article_description: 'article_description',
        supplementary_information: 'control_guidance',
        control_additional_information: 'control_additional_information',
        control_test_id: 'control_test_id',
        control_test: 'control_test',
        control_baseline: 'control_baseline',
        control_priority: 'control_priority',
        sub_control_id: 'sub_control_id',
        sub_control_name: 'sub_control_name',
        sub_control_description: 'sub_control_desc',
        sub_control_guidance: 'sub_control_guidance',
        sub_control_additional_information: 'sub_control_additional_information',
        sub_control_test_id: 'sub_control_test_id',
        sub_control_test: 'sub_control_test',
        sub_control_baseline: 'sub_control_baseline',
        sub_control_priority: 'sub_control_priority'
      }
    };
  }

  regulationDistributionTotals(condition) {
    return `select family_name as "Family", control_id as "Name",control_name as "Control Name", control_desc as "Description" from ${this.controlTable} ${whereCondition(...conditionFilter([this.mapping.mapping.control_id, this.mapping.mapping.sub_control, this.mapping.mapping.family_control, this.mapping.mapping.family], condition))}`;
  }
}

module.exports = FISCAM;
