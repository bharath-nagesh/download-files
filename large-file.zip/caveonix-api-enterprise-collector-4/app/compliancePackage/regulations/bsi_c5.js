const BaseCompliance = require('../complianceFactory');
const whereCondition = require('../../../utils/whereParser.js');
const conditionFilter = require('../../../utils/conditionFilter');

class BSI_C5 extends BaseCompliance {
  constructor() {
    super();
    this.regulationName = 'BSI-C5';
    this.selector = 'bsi-c5';
    this.certificate = this.selector;
    this.controlDescription = 'bsi.control_desc';
    this.familyName = 'bsi.family_name';
    this.testId;
    this.subControl = 'bsi.control_id';
    this.nistMappingTable = 'nist_bsi_c5_mappings';
    this.controlTable = 'bsi_c5_controls bsi';
    this.controlTableMappingId = 'bsi.mapping_id';
    this.nistRegulationMappingId = 'mapping_id';
    this.mapping = {
      apply: true,
      mapping: {
        mapping_id: this.nistRegulationMappingId,
        sub_control: 'bsi.control_id',
        control_id: 'rc.mapping_id',
        name: 'bsi.name',
        'bsi.name': 'bsi.name',
        source: 'source',
        asset_type: 'asset_type',
        application: 'application_grp_name',
        result: 'dc.result',
        family_control: 'bsi.family_name',
        domain_id: 'domain_id',
        domain_name: 'domain_name',
        domain_description: 'domain_desc',
        family_id: 'family_id',
        family_name: 'family_name',
        family_description: 'family_desc',
        control_reference: 'control_id',
        control_title: 'control_name',
        article_description: 'control_desc',
        supplementary_information: 'control_guidance',
        control_additional_information: 'control_additional_information',
        control_test_id: 'control_test_id',
        control_test: 'control_test',
        control_baseline: 'control_baseline',
        control_priority: 'control_priority',
        sub_control_id: 'sub_control_id',
        sub_control_name: 'sub_control_name',
        sub_control_description: 'sub_control_desc',
        sub_control_guidance: 'sub_control_guidance',
        sub_control_additional_information: 'sub_control_additional_information',
        sub_control_test_id: 'sub_control_test_id',
        sub_control_test: 'sub_control_test',
        sub_control_baseline: 'sub_control_baseline',
        sub_control_priority: 'sub_control_priority'
      }
    };
  }

  regulationDistributionTotals(condition) {
    return `select family_name as "Family", control_id as "Name",control_name as "Control Name", control_desc as "Description" from ${this.controlTable} ${whereCondition(...conditionFilter([this.mapping.mapping.control_id, this.mapping.mapping.sub_control, this.mapping.mapping.family_control, this.mapping.mapping.family], condition))}`;
  }
}

module.exports = BSI_C5;
