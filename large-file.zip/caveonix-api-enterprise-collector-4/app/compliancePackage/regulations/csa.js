const BaseCompliance = require('../complianceFactory');
const whereCondition = require('../../../utils/whereParser.js');
const conditionFilter = require('../../../utils/conditionFilter');

class CSA extends BaseCompliance {
  constructor() {
    super();
    this.regulationName = 'CSA';
    this.selector = this.regulationName.toLowerCase();
    this.certificate = this.selector;
    this.controlDescription = 'csa.control_desc';
    this.familyName = 'csa.domain_name';
    this.testId;
    this.subControl = 'csa.control_id';
    this.nistMappingTable = 'nist_csa_mappings';
    this.controlTable = 'csa_controls csa';
    this.controlTableMappingId = 'csa.mapping_id';
    this.nistRegulationMappingId = 'mapping_id';
    this.mapping = {
      apply:true,
      mapping: {
        mapping_id:this.nistRegulationMappingId,
        sub_control:'csa.control_id',
        control_id:'rc.mapping_id',
        name:'csa.domain_name',
        'csa.name':'csa.domain_name',
        source:'source',
        asset_type:'asset_type',
        application:'application_grp_name',
        result:'dc.result',
        family_control:'csa.domain_name',
        xdomain_id: 'domain_id',
        domain_name: 'domain_name',
        domain_description: 'domain_desc',
        domain_id: 'family_id',
        family_name: 'family_name',
        family_description: 'family_desc',
        control: 'control_id',
        control_title: 'control_name',
        control_description: 'control_desc',
        supplementary_information: 'control_guidance',
        control_additional_information: 'control_additional_information',
        control_test_id: 'control_test_id',
        control_test: 'control_test',
        control_baseline: 'control_baseline',
        control_priority: 'control_priority',
        sub_control_id: 'sub_control_id',
        sub_control_name: 'sub_control_name',
        sub_control_description: 'sub_control_desc',
        sub_control_guidance: 'sub_control_guidance',
        sub_control_additional_information: 'sub_control_additional_information',
        sub_control_test_id: 'sub_control_test_id',
        sub_control_test: 'sub_control_test',
        sub_control_baseline: 'sub_control_baseline',
        sub_control_priority: 'sub_control_priority'
      }
    };
  }

  regulationDistributionTotals(condition) {
    return `select *,control_id as "Name", domain_name as "Family", control_desc as "Description", compliance as "Compliance"   from ${this.controlTable} ${whereCondition(...conditionFilter([this.mapping.mapping.control_id,this.mapping.mapping.sub_control,this.mapping.mapping.family_control,this.mapping.mapping.family],condition))}`;
  }
}

module.exports = CSA;
