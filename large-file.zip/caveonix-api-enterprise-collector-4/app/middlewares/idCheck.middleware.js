const errorHandler = require('../../utils/errorHandler');
const logger = require('./../../utils/logger').logger.child({
  sub_name: 'IdentityService-permission.middleware'
});
const Validator = require('../../utils/validator');
module.exports = function (module, parameterToTest) {
  return async (req, res, next, value) => {

    const validatorParams = 'required|integer';
    try {
      const resourceJSON = { resourceId: value };
      const errorMessage = `Error with ${module} Id`;

      await Validator.validateParams({
        resourceId: validatorParams
      }, resourceJSON, { resourceId: errorMessage });

    } catch (error) {
      logger.error('error occurred', { error });
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }

    return next();
  };
};
