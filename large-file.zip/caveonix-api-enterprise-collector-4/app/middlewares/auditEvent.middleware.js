const JobManager = require('../../config/bull.conf');

module.exports = function (name, message, namedParams = [], excludedParams = []) {

  return async function (req, res, next) {
    const params = Object.assign({}, req.query, req.body, req.params);

    next();
    for (const variable of namedParams) {
      if (params[variable]) {
        this[variable] = params[variable];
        delete params[variable];
      }
    }
    for (const excludedVar of excludedParams) {
      delete params[excludedVar];
    }
    const jobDetails = {
      name,
      message: typeof message === 'function' ? message() : message,
      params,
      timestamp: new Date()
    };
    await JobManager.produceJob('audit', jobDetails);
  };
};
