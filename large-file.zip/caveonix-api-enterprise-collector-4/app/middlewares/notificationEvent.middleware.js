const JobManager = require('../../config/bull.conf');

module.exports = function (type, message) {

  return async function (req, res, next) {
    const params = Object.assign({}, req.query, req.body, req.params);

    next();
    const notificationDetails = {
      type,
      message,
      data: {
        ...params,
        userId: req.user.id,
        orgId: req.user.organization_id,
      },
      timestamp: new Date()
    };
    await JobManager.produceJob('notifications', notificationDetails);

  };
};
