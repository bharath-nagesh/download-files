const { get } = require('lodash');
const jwt = require('jsonwebtoken');

const appService = require('./../services/app.service').getInstance();
const logger = require('../../utils/logger').logger;

const loggerLabel = 'Help';

/**
 * Checks if the the user has access to help
 */
module.exports = () => {
  return async (req, res, next) => {
    try {
      const jwtInfo = appService.getJwtInfo();
      const jwtCert = jwtInfo.jwtCert;
      const algorithm = jwtInfo.jwtAlgorithm;
      const token = get(req, 'cookies.Authorization');
      jwt.verify(token, jwtCert, { algorithm });
    } catch (error) {
      logger.error(`unable to verify token and redirecting to login`, { loggerLabel, error });
      return res.redirect('/login');
    }

    res.setHeader(
      'Content-Security-Policy',
      "default-src * 'unsafe-inline' 'self'; script-src * 'unsafe-inline' 'unsafe-eval' 'self'; img-src * 'unsafe-inline' 'unsafe-eval' 'self'; worker-src * 'unsafe-inline' 'unsafe-eval' 'self' "
    );
    next();
  };
};
