const _ = require('lodash');

const config = require('./../../configure').get();
const isAppliance = require('../../utils/isAppliance');
const logger = require('./../../utils/logger').logger.child({
  sub_name: 'IdentityService-permission.middleware'
});
const PermissionService = require('../services/permission.service');
const permissionService = new PermissionService();

const middleware = {
  async checkPermission(req, res, next) {
    const userId = req.user.id;
    const user = req.user;
    const orgIds = req.user.Organizations.map(o => o.id);
    const verb = req.method;
    const urlParts = req.originalUrl.split('/');
    let resourceId;
    let mod;
    if (_.get(config, 'forensics_enabled') === true) {
      const authInfo = req.authInfo.split('^^');
      req.authInfo = authInfo[0];
      req.headers.es_token = 'Basic ' + authInfo[1];
      req.body.userToken = authInfo[0];
    }

    if (urlParts[1] === 'api') {
      mod = '/' + urlParts[2];
      resourceId = urlParts[3];
    } else {
      mod = '/' + urlParts[1];
      resourceId = urlParts[2];
    }

    try {
      const checks = await Promise.all(orgIds.map((orgId) => permissionService.checkPermission(user.id, orgId, mod, resourceId, verb)));
      const allowed = _.some(checks, Boolean);

      if (allowed) {
        return next();
      } else {
        logger.error('unauthorized user');
        return res.sendStatus(401);
      }
    } catch (error) {
      if (error.status === 404) {
        logger.error('unauthorized user', { error });
        return res.sendStatus(401);
      } else if (error.status === 440) {
        logger.error('Session Expired', { error });
        res.statusCode = 440;
        return res.send('Session Expired');
      }
      logger.error('error occurred', { error });
      return res.sendStatus(500);
    }
  },
  async isInOrgChain(req, res, next) {
    const urlParts = req.originalUrl.split('/');
    const orgId = urlParts[3] || req.user.Organizations[0].id;
    let allowedOrgIds = [];
    let allowed;
    const userRole = _.get(req.user, 'OrgMemberships[0].Role.name');
    if (!isAppliance()) {
      if (userRole === 'mssp_owner' || userRole === 'msp_owner') {
        allowedOrgIds = req.user.Organizations.map(o => o.id);
        allowed = allowedOrgIds.includes(parseInt(orgId));
      } else {
        allowed = await permissionService.checkInOrgChain(req.user, orgId);
      }
    } else {
      allowed = true;
    }

    return allowed ? next() : res.sendStatus(401);
  }
};

module.exports = middleware;
