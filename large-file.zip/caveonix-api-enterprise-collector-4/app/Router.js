const paginate = require('./middlewares/paginate.middleware');
const { organization, user, auth } = require('./modules');

/**
 * Main Router for the app
 */
class CavRouter {
  static getRoutes() {
    return [
      {
        path: '/organization',
        middleware: [organization.isProvider, paginate.middleware()],
        permissionCheck: { func: organization.checkPermission, param: 'orgId' },
        handler: organization.router,
        protected: true
      },
      {
        path: '/auth',
        middleware: [],
        handler: auth.router,
        protected: false
      },
      {
        path: '/api/auth',
        middleware: [],
        handler: auth.router,
        protected: false
      },
      {
        path: '/common',
        middleware: [],
        handler: require('./apis/common/common.routes'),
        protected: false
      }
    ];
  }
}

module.exports = CavRouter.getRoutes();
