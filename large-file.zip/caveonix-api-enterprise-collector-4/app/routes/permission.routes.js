

let express = require('express');
let Controller = require('../apis/permission.controller');
let router = express.Router({mergeParams:true});

router.post('/', Controller.checkPermission);

module.exports = router;
