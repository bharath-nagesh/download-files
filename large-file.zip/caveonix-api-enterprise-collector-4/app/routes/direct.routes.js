const AuthController = require('../apis/auth/auth.controller');
const authController = new AuthController();
const express = require('express');
const router = express.Router({ mergeParams: true });

/* Public Registartion Endpoints */
router.post('/preregister', authController.preRegisterDirect);
router.get('/register/verify', authController.directRegisterVerify);
router.post('/register', authController.register);

module.exports = router;
