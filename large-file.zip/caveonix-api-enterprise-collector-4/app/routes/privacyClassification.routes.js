let express = require('express');
let Controller = require('../apis/privacyClassification.controller');
let router = express.Router({mergeParams:true});

router.get('/', Controller.getAllPrivacyClassification);
router.post('/', Controller.createPrivacyClassification);
router.get('/:privacyClassificationId', Controller.getPrivacyClassificationById);
router.put('/:privacyClassificationId', Controller.updatePrivacyClassificationById);
// router.delete('/:vendorId', Controller.deletePrivacyClassification);

module.exports = router;
