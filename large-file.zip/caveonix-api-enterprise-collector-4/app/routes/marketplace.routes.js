const AuthController = require('../apis/auth/auth.controller');
const authController = new AuthController();
const express = require('express');
const router = express.Router({ mergeParams: true });
const multer = require('multer');
const formData = multer();

/* Public Registartion Endpoints */
router.get('/preregister', authController.preRegisterAWS);
router.post('/preregister', formData.none(), authController.preRegisterAWS);
router.post('/register', authController.register);

module.exports = router;
