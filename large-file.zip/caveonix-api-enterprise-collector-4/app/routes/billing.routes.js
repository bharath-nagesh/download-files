

/*
 * App Routes
 * path: /app
 */

let express = require('express');
let ServiceProviderController = require('../apis/serviceProvider/serviceProvider.controller');
let router = express.Router({mergeParams:true});
const controller = new ServiceProviderController()
router.get('/getBillingInfo', controller.getBillingInfo);

module.exports = router;
