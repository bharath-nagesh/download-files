const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();


class customControls extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
      family: {
        type: Sequelize.STRING,
        field: 'family'
      },
      control_type: {
        type: Sequelize.STRING,
        field: 'control_type'
      },
      name: {
        type: Sequelize.STRING,
        field: 'name',
        unique: true
      },
      type: {
        type: Sequelize.STRING,
        field: 'type'
      },
      title: {
        type: Sequelize.STRING,
        field: 'title'
      },
      priority: {
        type: Sequelize.STRING,
        field: 'priority'
      },
      version: {
        type: Sequelize.STRING,
        field: 'version'
      },
      standards: {
        type: Sequelize.STRING,
        field: 'standards'
      },
      directive: {
        type: Sequelize.STRING,
        field: 'directive'
      },
      preventive: {
        type: Sequelize.STRING,
        field: 'preventive'
      },
      detective: {
        type: Sequelize.STRING,
        field: 'detective'
      },
      corrective: {
        type: Sequelize.STRING,
        field: 'corrective'
      },
      low: {
        type: Sequelize.STRING,
        field: 'low'
      },
      medium: {
        type: Sequelize.STRING,
        field: 'medium'
      },
      high: {
        type: Sequelize.STRING,
        field: 'high'
      },
      version_history: {
        type: Sequelize.STRING,
        field: 'version_history'
      },
      dependencies: {
        type: Sequelize.STRING,
        field: 'dependencies'
      },
      control_ref: {
        type: Sequelize.STRING,
        field: 'control_ref'
      },
      compliance: {
        type: Sequelize.STRING,
        field: 'compliance'
      },
      organization_id: {
        type: Sequelize.STRING,
        field: 'organization_id'
      }
    },
    { sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'custom_controls',
      underscored: true
    });
  }

  static upsert (name, data) {
    const find = { name };
    const create = data;
    return customControls.findOrCreate({ where: find, attributes: ['family'], defaults: create });
  };
}
// customControls.removeAttribute('id');
module.exports = customControls;
