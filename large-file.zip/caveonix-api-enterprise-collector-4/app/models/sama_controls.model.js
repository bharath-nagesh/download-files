const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();

class Sama_controls extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
      control_id: {
        type: Sequelize.STRING,
        field: 'control_id'
      },
      sub_control_id: {
        type: Sequelize.STRING,
        field: 'sub_control_id'
      },
      domain: {
        type: Sequelize.STRING,
        field: 'domain'
      },
      domain_desc: {
        type: Sequelize.STRING,
        field: 'domain_desc'
      },
      sub_domain: {
        type: Sequelize.STRING,
        field: 'sub_domain'
      },
      sub_domain_principal: {
        type: Sequelize.STRING,
        field: 'sub_domain_principal'
      },
      sub_domain_objective: {
        type: Sequelize.STRING,
        field: 'sub_domain_objective'
      },
      supplement_control_id: {
        type: Sequelize.STRING,
        field: 'supplement_control_id'
      },
      control_desc: {
        type: Sequelize.STRING,
        field: 'control_desc'
      },
      compliance: {
        type: Sequelize.STRING,
        field: 'compliance'
      }
    },
    { sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'sama_controls',
      underscored: true
    });
  }
}

module.exports = Sama_controls;
