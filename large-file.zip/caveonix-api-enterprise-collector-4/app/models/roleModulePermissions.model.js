const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();

let RoleModulePermission = sequelize.define(
  'RoleModulePermission',
  {
    permission: {type: Sequelize.STRING}
  },
  {
    timestamps: false,
    freezeTableName: true,
    tableName: 'role_module_permissions',
    underscored: true
  }
);

let classMethods = {
  associate: function (models) {
    RoleModulePermission.belongsTo(models.Role);
    RoleModulePermission.belongsTo(models.Module);
  }
};
for (let key in classMethods) {
  RoleModulePermission[key] = classMethods[key];
}

module.exports = RoleModulePermission;
