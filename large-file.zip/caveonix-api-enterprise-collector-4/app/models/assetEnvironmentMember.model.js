const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();

class AssetEnvironmentMember extends Sequelize.Model {
  static init(sequelize) {
    return super.init({
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      asset_id: { type: Sequelize.INTEGER, field: 'asset_id' },
      environment_id: { type: Sequelize.INTEGER, field: 'environment_id' }
    },
    { sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'asset_environment_members',
      underscored: true
    });
  }

  static associate(models) {
    AssetEnvironmentMember.belongsTo(models.Asset);
    AssetEnvironmentMember.belongsTo(models.Environment);
  };
}
module.exports = AssetEnvironmentMember;
