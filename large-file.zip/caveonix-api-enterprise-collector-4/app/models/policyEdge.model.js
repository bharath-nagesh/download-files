const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();

const PolicyEdge = sequelize.define(
  'PolicyEdge',
  {
    action: { type: Sequelize.STRING, allowNull: false },
    incoming: { type: Sequelize.BOOLEAN, field: 'incoming', allowNull: false },
    stateful: { type: Sequelize.BOOLEAN, field: 'stateful', allowNull: false },
    ethertype: { type: Sequelize.INTEGER, field: 'ethertype' },
    ipProtocol: { type: Sequelize.INTEGER, field: 'ip_protocol' },
    startPort: { type: Sequelize.INTEGER, field: 'start_port' },
    endPort: { type: Sequelize.INTEGER, field: 'end_port' }
  },
  { timestamps: false, freezeTableName: true, tableName: 'policy_edge', underscored: true }
);

PolicyEdge.associate = (models) => {
  PolicyEdge.belongsTo(models.PolicyGroup, {
    required: true,
    field: 'subject_policy_group_id',
    as: 'SubjectPolicyGroup'
  });
  PolicyEdge.belongsTo(models.PolicyGroup, { field: 'object_policy_group_id', as: 'ObjectPolicyGroup' });
};

module.exports = PolicyEdge;
