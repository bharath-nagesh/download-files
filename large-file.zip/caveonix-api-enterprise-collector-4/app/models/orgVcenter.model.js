const Sequelize = require('sequelize');

/**
 * @swagger
 * components:
 *   schemas:
 *     Job:
 *       type: object
 *       required:
 *         - name
 *         - isActive
 *       properties:
 *         name:
 *           type: string
 *         description:
 *           type: string
 *         org_type:
 *           type: string
 *         organization_id:
 *           type: string
 * @param sequelize
 */
class OrgVCenter extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
        // id: {
        //   type: Sequelize.INTEGER,
        //   primaryKey: true,
        //   autoIncrement: true
        // },
        type: { type: Sequelize.ENUM('ResourcePool', 'Folder', 'Datacenter'), allowNull: false },
        values: { type: Sequelize.STRING, field: 'value', allowNull: false },

      },
      {
        sequelize,
        timestamps: false,
        freezeTableName: true,
        tableName: 'organization_vcenter_mappings',
        underscored: true
      });
  }

// model associations
  static associate(models) {
    OrgVCenter.belongsTo(models.AssetRepoEndpoint);
    OrgVCenter.belongsTo(models.Organization);
  };
}

module.exports = OrgVCenter;
