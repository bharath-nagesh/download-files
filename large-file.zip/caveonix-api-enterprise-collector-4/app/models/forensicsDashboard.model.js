const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();

class ForensicsDashboard extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      index_pattern: { type: Sequelize.STRING, field: 'index_pattern', allowNull: false },
      organization_id: { type: Sequelize.INTEGER, field: 'organization_id', allowNull: false },
      type: { type: Sequelize.STRING, field: 'type', allowNull: false },
      dashboard_url: { type: Sequelize.STRING, field: 'dashboard_url', allowNull: false },
      widget: { type: Sequelize.STRING, field: 'widget', allowNull: false }
    },
    { sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'forensics_dashboard',
      underscored: true
    });
  }

  static associate(models) {
    ForensicsDashboard.belongsTo(models.Organization, { foreignKey: 'organization_id' });
  };
}
module.exports = ForensicsDashboard;
