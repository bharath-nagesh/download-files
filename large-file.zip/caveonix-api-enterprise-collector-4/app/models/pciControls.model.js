const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();

class PciControls extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
      name: {
        type: Sequelize.STRING,
        field: 'req_id'
      },
      description: {
        type: Sequelize.STRING,
        field: 'requirements'
      },
      compliance: {
        type: Sequelize.STRING,
        field: 'compliance'
      }
    },
    { sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'pci_controls',
      underscored: true
    });
  }
}

module.exports = PciControls;
