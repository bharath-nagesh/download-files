const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();

class AssetVMNetwork extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
      networkMac: { type: Sequelize.STRING, field: 'network_mac' },
      networkIp: { type: Sequelize.STRING, field: 'network_ip' },
      network: { type: Sequelize.STRING, field: 'network', allowNull: false }
    },
    { sequelize , timestamps: true, freezeTableName: true, tableName: 'asset_vm_network_details', underscored: true });
  }

  static associate(models) {
    AssetVMNetwork.belongsTo(models.Asset,{ foreignKey:'asset_id' });
  }
}
module.exports = AssetVMNetwork;
