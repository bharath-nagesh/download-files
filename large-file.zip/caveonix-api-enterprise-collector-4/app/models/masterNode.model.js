const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();
const MasterNode = sequelize.define(
  'MasterNode',
  {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    masterNode_host_name: { type: Sequelize.STRING, field: 'host_name' },
    masterNode_username: { type: Sequelize.STRING, field: 'username' },
    masterNode_password: { type: Sequelize.STRING, field: 'password' },
    asset_repo_type_id: { type: Sequelize.INTEGER },
    asset_repo_endpoint_id: { type: Sequelize.INTEGER }
  },
  { timestamps: true, freezeTableName: true, tableName: 'master_nodes', underscored: true }
);

MasterNode.associate = (models) => {
  MasterNode.belongsTo(models.AssetRepoEndpoint, { foreignKey: 'asset_repo_endpoint_id' });
};

module.exports = MasterNode;
