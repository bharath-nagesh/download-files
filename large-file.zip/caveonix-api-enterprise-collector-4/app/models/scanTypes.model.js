const {DataTypes} = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();
const ScanTypes = sequelize.define(
  'scanTypes',
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    name: { type: DataTypes.STRING, allowNull: false },
    isActive: { type: DataTypes.STRING, field: 'is_active' },
    is_active: { type: DataTypes.STRING, field: 'is_active' },
    type: { type: DataTypes.STRING, allowNull: false },
    comments: { type: DataTypes.STRING, allowNull: false },
    jobId: { type: DataTypes.INTEGER, allowNull: true, field: 'job_id' }

  },
  {
    timestamps: false,
    freezeTableName: true,
    tableName: 'scan_types',
    underscored: true
  }
);

module.exports = ScanTypes;
