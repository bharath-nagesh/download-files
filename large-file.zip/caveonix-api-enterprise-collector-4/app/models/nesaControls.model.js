const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();

class NesaControls extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
      name: {
        type: Sequelize.STRING,
        field: 'name'
      },
      description: {
        type: Sequelize.STRING,
        field: 'standards'
      },
      compliance: {
        type: Sequelize.STRING,
        field: 'compliance'
      }
    },
    { sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'nesa_controls',
      underscored: true
    });
  }
}

module.exports = NesaControls;
