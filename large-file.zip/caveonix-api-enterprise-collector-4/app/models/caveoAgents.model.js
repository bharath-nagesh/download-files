const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();

class CaveoAgents extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      name: { type: Sequelize.STRING, allowNull: false, field: 'agent_name' },
      ipAddress: { type: Sequelize.STRING, allowNull: false, field: 'ip_address' },
      hostName: { type: Sequelize.STRING, allowNull: false, field: 'host_name' },
      remote_address: { type: Sequelize.STRING, allowNull: false, field: 'remote_address' },
      remote_ip_address: { type: Sequelize.STRING, allowNull: false, field: 'remote_ip_address' },
      isActive: { type: Sequelize.STRING, field: 'is_active', defaultValue: true },
      is_active: { type: Sequelize.STRING, field: 'is_active', }
    },
    { sequelize,
      timestamps: true,
      freezeTableName: true,
      tableName: 'caveo_agents',
      underscored: true
    });
  }
}
module.exports = CaveoAgents;
