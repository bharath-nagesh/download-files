const { DataTypes, Model } = require('sequelize');

class ApraCpsControls extends Model {
  static init(sequelize) {
    return super.init({
      family_name: {
        type: DataTypes.STRING,
        field: 'family_name'
      },
      control_id: {
        type: DataTypes.STRING,
        field: 'control_id'
      },
      control_name: {
        type: DataTypes.STRING,
        field: 'control_name'
      },
      control_desc: {
        type: DataTypes.STRING,
        field: 'control_desc'
      },
      compliance: {
        type: DataTypes.STRING,
        field: 'compliance'
      }
    },
    {
      sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'apra_cps_controls',
      underscored: true
    });
  }
}

module.exports = ApraCpsControls;
