const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();

class VcenterResourceMappings extends Sequelize.Model {
  static init(sequelize) {
    return super.init({
        asset_repo_endpoint_id: { type: Sequelize.INTEGER, field: 'asset_repo_endpoint_id' },
        folder: { type: Sequelize.STRING, allowNull: true, field: 'folder' },
        clusterName: { type: Sequelize.STRING, allowNull: true, field: 'cluster_name' },
        dataCenter: { type: Sequelize.STRING, allowNull: true, field: 'datacenter' },
        resourcePool: { type: Sequelize.STRING, allowNull: true, field: 'resource_pool' }
      },
      { sequelize, timestamps: false, freezeTableName: true, tableName: 'vcenter_resource_mappings', underscored: true }
    );
  }

  static associate(models) {
    /* // AssetRepoEndpointMembers.hasMany(models.AssetRepoEndpoint,{foreignKey: 'id'});
    AssetRepoEndpointMembers.belongsTo(models.AssetRepoEndpoint,{foreignKey: 'id'}); */
    VcenterResourceMappings.belongsTo(models.AssetRepoEndpoint,
      { foreignKey: 'asset_repo_endpoint_id', targetKey: 'id' });
  }

}

module.exports = VcenterResourceMappings;
