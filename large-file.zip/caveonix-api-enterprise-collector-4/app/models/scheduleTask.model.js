const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();

class ScheduleTask extends Sequelize.Model {
  static init(sequelize) {
    return super.init({
        name: { type: Sequelize.STRING, allowNull: false, field: 'name' },
        job_id: { type: Sequelize.INTEGER, allowNull: false, field: 'job_id' },
        user_id: { type: Sequelize.INTEGER, allowNull: false, field: 'user_id' },
        org_id: { type: Sequelize.INTEGER, allowNull: false, field: 'org_id' },
        asset_repo_id: { type: Sequelize.INTEGER, allowNull: true, field: 'asset_repo_id' },
        org_name: { type: Sequelize.STRING, field: 'org_name' },
        cron_expression: { type: Sequelize.STRING, allowNull: false, field: 'cron_expression' },
        scan_type: { type: Sequelize.STRING, allowNull: true, field: 'scan_types' },
        isActive: { type: Sequelize.BOOLEAN, field: 'is_active', defaultValue: true },
        is_active: { type: Sequelize.BOOLEAN, field: 'is_active' },
        flowsPeriod: { type: Sequelize.INTEGER, field: 'flows_time_window' },
        parameters: { type: Sequelize.STRING, field: 'parameters' },
        report_type_id: { type: Sequelize.INTEGER, allowNull: true, field: 'report_type_id' },
        type: { type: Sequelize.STRING, allowNull: true, field: 'type' },
        typeValues: { type: Sequelize.STRING, allowNull: true, field: 'type_values' },
        ecHostName: { type: Sequelize.STRING, allowNull: true, field: 'ec_host_name' },
        includeSubResources: { type: Sequelize.BOOLEAN, field: 'include_sub_resources', defaultValue: false },
        timezoneName: { type: Sequelize.STRING, allowNull: true, field: 'timezone_name' },
        timezoneOffset: { type: Sequelize.STRING, allowNull: true, field: 'timezone_offset' },
        remoteAccessDetailId: { type: Sequelize.INTEGER, allowNull: true, field: 'remote_access_detail_id' }
      },
      {
        sequelize,
        timestamps: true,
        freezeTableName: true,
        tableName: 'schedules',
        underscored: true
      });
  }

  static associate(models) {
    ScheduleTask.belongsTo(models.Organization, { foreignKey: 'org_id' });
    ScheduleTask.belongsTo(models.AssetRepoEndpoint, { foreignKey: 'asset_repo_id' });
    ScheduleTask.belongsTo(models.Job);
    ScheduleTask.belongsTo(models.RemoteAccessDetail, { foreignKey: 'remote_access_detail_id' });

  }
}

module.exports = ScheduleTask;
