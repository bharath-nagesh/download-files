const { DataTypes, Model } = require('sequelize');

class CsaControls extends Model {
  static init(sequelize) {
    return super.init({
      domain_name: {
        type: DataTypes.STRING,
        field: 'domain_name'
      },
      domain_id: {
        type: DataTypes.STRING,
        field: 'domain_id'
      },
      control_id: {
        type: DataTypes.STRING,
        field: 'control_id'
      },
      control_desc: {
        type: DataTypes.STRING,
        field: 'control_desc'
      },
      mapping_id: {
        type: DataTypes.STRING,
        field: 'mapping_id'
      },
      compliance: {
        type: DataTypes.STRING,
        field: 'compliance'
      }
    },
    {
      sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'csa_controls',
      underscored: true
    });
  }
}

module.exports = CsaControls;
