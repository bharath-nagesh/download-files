const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();

const NetworkLogicalSwitch = sequelize.define(
  'NetworkLogicalSwitch',
  {
    hostId: { type: Sequelize.STRING, field: 'host_id' },
    elementId: { type: Sequelize.STRING, field: 'element_id' },
    name: { type: Sequelize.STRING }
  },
  { timestamps: true, freezeTableName: true, tableName: 'network_logical_switches', underscored: true }
);

NetworkLogicalSwitch.associate = (models) => {
  NetworkLogicalSwitch.belongsTo(models.AssetRepoEndpoint);
  NetworkLogicalSwitch.belongsTo(models.NetworkVirtualSwitch, { foreignKey: 'backing_vswitch_id' });
  NetworkLogicalSwitch.belongsTo(models.NetworkPortGroup, { foreignKey: 'backing_portgroup_id' });
};

module.exports = NetworkLogicalSwitch;
