const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();

class GdprControls extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
      name: {
        type: Sequelize.STRING,
        field: 'artical'
      },
      description: {
        type: Sequelize.STRING,
        field: 'description'
      },
      compliance: {
        type: Sequelize.STRING,
        field: 'compliance'
      }
    },
    { sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'gdpr_controls',
      underscored: true
    });
  }
}

module.exports = GdprControls;
