const Sequelize = require('sequelize');
const connection = require('../../config/db.conf').getConnection();

const AssetOrgMember = connection.define('AssetOrgMember',
  {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    }
  },
  {
    timestamps: false,
    freezeTableName: true,
    tableName: 'asset_org_members',
    underscored: true
  }
);

// const classMethods = {
//   associate: (models) => {
//     AssetOrgMember.belongsTo(models.OrgType);
//   }
// };

module.exports = AssetOrgMember;
