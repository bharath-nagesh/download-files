const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();

class ApplicationPocMember extends Sequelize.Model {
  static init(sequelize) {
    return super.init({
        id: {
          type: Sequelize.INTEGER,
          primaryKey: true,
          autoIncrement: true
        },
        systemOwner: { field: 'system_owner', type: Sequelize.STRING },
        managementPoc: { field: 'management_poc', type: Sequelize.STRING },
        technicalPoc: { field: 'techinical_poc', type: Sequelize.STRING }
      },
      {
        sequelize,
        timestamps: false,
        freezeTableName: true,
        tableName: 'application_poc_members',
        underscored: true
      });
  }
}

module.exports = ApplicationPocMember;
