const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();

/**
 * @swagger
 * components:
 *   schemas:
 *     Vendor:
 *       type: object
 *       required:
 *         - name
 *         - isActive
 *       properties:
 *         name:
 *           type: string
 *         isActive:
 *           type: string
 * @param sequelize
 */

const Vendor = sequelize.define('Vendor',
  {
    name: {type: Sequelize.STRING},
    isActive: {type: Sequelize.BOOLEAN, field: 'is_active'},
    is_active: {type: Sequelize.BOOLEAN, field: 'is_active'}
  },
  {timestamps: false, freezeTableName: true, tableName: 'vendor', underscored: true}
);
module.exports = Vendor;

