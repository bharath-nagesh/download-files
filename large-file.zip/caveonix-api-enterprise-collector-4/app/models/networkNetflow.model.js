const { DataTypes, Model } = require('sequelize');

class NetworkNetflow extends Model {
  static init(sequelize) {
    return super.init({
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      observationDomainId: { type: DataTypes.INTEGER,field: 'observation_domain_id' },
      asset_repo_endpoint_id: { type: DataTypes.INTEGER,field: 'asset_repo_endpoint_id' },
      isActive: { type: DataTypes.STRING,field: 'is_active', defaultValue:'enabled' },
      is_active: { type: DataTypes.STRING,field: 'is_active' },
      vcd_vcenter_details_id: { type: DataTypes.INTEGER, field: 'vcd_vcenter_details_id' }
    },
    {
      sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'network_netflow',
      underscored: true
    });
  }

  static associate(models) {
    NetworkNetflow.belongsTo(models.AssetRepoEndpoint ,{ foreignKey: 'asset_repo_endpoint_id' });
    NetworkNetflow.belongsTo(models.vcdVcenterDetails ,{ foreignKey: 'vcd_vcenter_details_id' });
  };
}

module.exports = NetworkNetflow;
