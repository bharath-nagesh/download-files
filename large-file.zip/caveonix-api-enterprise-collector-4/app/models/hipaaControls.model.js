const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();

class HipaaControls extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
      name: {
        type: Sequelize.STRING,
        field: 'control_type'
      },
      description: {
        type: Sequelize.STRING,
        field: 'guidance'
      },
      compliance: {
        type: Sequelize.STRING,
        field: 'compliance'
      }
    },
    { sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'hipaa_controls',
      underscored: true
    });
  }
}

module.exports = HipaaControls;
