const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();

const NetworkVirtualSwitch = sequelize.define(
  'NetworkVirtualSwitch',
  {
    hostId: { type: Sequelize.STRING, field: 'host_id' },
    elementId: { type: Sequelize.STRING, field: 'element_id' },
    elementIdAlternate: { type: Sequelize.STRING, field: 'element_id_alternate' },
    name: { type: Sequelize.STRING },
    type: { type: Sequelize.STRING, field: 'type' }
  },
  { timestamps: true, freezeTableName: true, tableName: 'network_virtual_switch', underscored: true }
);

NetworkVirtualSwitch.associate = (models) => {
  NetworkVirtualSwitch.belongsTo(models.AssetRepoEndpoint);
};

module.exports = NetworkVirtualSwitch;
