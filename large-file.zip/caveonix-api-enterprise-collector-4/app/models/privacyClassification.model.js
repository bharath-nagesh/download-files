const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();

const PrivacyClassification = sequelize.define('PrivacyClassification',
  {
    name: { type: Sequelize.STRING }
  },
  { timestamps: false, freezeTableName: true, tableName: 'privacy_classifications', underscored: true }
);

module.exports = PrivacyClassification;
