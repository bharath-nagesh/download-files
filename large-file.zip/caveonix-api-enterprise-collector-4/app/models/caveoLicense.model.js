const Sequelize = require('sequelize');
const isAppliance = require('../../utils/isAppliance');
const logger = require('../../utils/logger').logger.child({
  sub_name: 'IdentityService-user.model'
});

module.exports = class CaveoLicense extends Sequelize.Model {
  static init(sequelize) {
    return super.init({
        licenseKey: { type: Sequelize.STRING, field: 'license_key' },
        licenseName: { type: Sequelize.STRING, field: 'license_name' },
        publicKey: { type: isAppliance() ? Sequelize.VIRTUAL : Sequelize.STRING, field: 'public_key' },
        createdAt: {
          type: Sequelize.DATE,
          field: 'created_at',
          allowNull: false,
          defaultValue: sequelize.literal('now()')
        },
        isActive: { type: Sequelize.STRING, field: 'is_active', defaultValue: true, allowNull: false }
      },
      {
        sequelize,
        timestamps: false,

        freezeTableName: true,
        tableName: 'caveo_license',
        underscored: true,
        updatedAt: 'updated_at',
        createdAt: 'created_at'
      }
    );
  }

  static associate(models) {
    // CaveoLicense.belongsTo(models.Organization);
  }

};
