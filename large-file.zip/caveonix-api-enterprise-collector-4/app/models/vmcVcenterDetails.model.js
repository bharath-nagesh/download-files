const { DataTypes, Model } = require('sequelize');

class VMCVcenterDetails extends Model {
  static init(sequelize) {
    return super.init({
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      asset_repo_endpoint_vmc_id: { type: DataTypes.INTEGER, field: 'asset_repo_endpoint_vmc_id' },
      vcenter_url: { type: DataTypes.STRING, field: 'vcenter_url' },
      organization_id: { type: DataTypes.INTEGER, field: 'organization_id' },
      location_id: { type: DataTypes.INTEGER, field: 'location_id' },
      hosting_provider_id: { type: DataTypes.INTEGER, field: 'hosting_provider_id' },
      nsx_url: { type: DataTypes.STRING, field: 'nsx_url' },
      nsx_reverse_proxy_url: { type: DataTypes.STRING, field: 'nsx_reverse_proxy_url' },
      username: { type: DataTypes.STRING, field: 'username' },
      password: { type: DataTypes.STRING, field: 'password' }
    },
    {
      sequelize,
      timestamps: true,
      createdAt: 'created_at',
      updatedAt: false,
      freezeTableName: true,
      tableName: 'vmc_vcenter_details',
      underscored: true
    });
  }

  static associate(models) {
    VMCVcenterDetails.belongsTo(models.Organization, { foreignKey: 'organization_id' });
  }
}

module.exports = VMCVcenterDetails;

