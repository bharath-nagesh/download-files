const { DataTypes, Model } = require('sequelize');

class Iso270108Controls extends Model {
  static init(sequelize) {
    return super.init({
      clause_id: {
        type: DataTypes.STRING,
        field: 'clause_id'
      },
      clause_name: {
        type: DataTypes.STRING,
        field: 'clause_name'
      },
      category_id: {
        type: DataTypes.STRING,
        field: 'category_id'
      },
      category_name: {
        type: DataTypes.STRING,
        field: 'category_name'
      },
      category_desc: {
        type: DataTypes.STRING,
        field: 'category_desc'
      },
      control_id: {
        type: DataTypes.STRING,
        field: 'control_id'
      },
      control_name: {
        type: DataTypes.STRING,
        field: 'control_name'
      },
      control_desc: {
        type: DataTypes.STRING,
        field: 'control_desc'
      },
      control_guide: {
        type: DataTypes.STRING,
        field: 'control_guide'
      },
      custom_guide: {
        type: DataTypes.STRING,
        field: 'custom_guide'
      },
      custom_guide1: {
        type: DataTypes.STRING,
        field: 'custom_guide1'
      },
      mapping_id: {
        type: DataTypes.STRING,
        field: 'mapping_id'
      },
      compliance: {
        type: DataTypes.STRING,
        field: 'compliance'
      }
    },
    {
      sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'iso_27018_controls',
      underscored: true
    });
  }
}

module.exports = Iso270108Controls;
