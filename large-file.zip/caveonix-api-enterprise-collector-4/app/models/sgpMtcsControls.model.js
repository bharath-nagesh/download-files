const { Model, DataTypes } = require('sequelize');

class SgpMtcsControls extends Model {
  static init(sequelize) {
    return super.init({
      family_id: {
        type: DataTypes.STRING,
        field: 'family_id'
      },
      family: {
        type: DataTypes.STRING,
        field: 'family'
      },
      family_desc: {
        type: DataTypes.STRING,
        field: 'family_desc'
      },
      control_id: {
        type: DataTypes.STRING,
        field: 'control_id'
      },
      control_name: {
        type: DataTypes.STRING,
        field: 'control_name'
      },
      control_desc: {
        type: DataTypes.STRING,
        field: 'control_desc'
      },
      level1: {
        type: DataTypes.STRING,
        field: 'level1'
      },
      level2: {
        type: DataTypes.STRING,
        field: 'level2'
      },
      level3: {
        type: DataTypes.STRING,
        field: 'level3'
      },
      compliance: {
        type: DataTypes.STRING,
        field: 'compliance'
      }
    },
    {
      sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'sgp_controls',
      underscored: true
    });
  }
}

module.exports = SgpMtcsControls;
