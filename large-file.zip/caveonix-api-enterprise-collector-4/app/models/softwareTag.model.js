const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();
/**
 * @swagger
 * components:
 *   schemas:
 *     Software:
 *       type: object
 *       required:
 *         - name
 *         - description
 *       properties:
 *         name:
 *           type: string
 *         description:
 *           type: string
 *         part:
 *           type: string
 *         vendor:
 *           type: string
 *         version:
 *           type: string
 *         language:
 *           type: string
 *         softwareEdition:
 *           type: string
 *         softwareTarget:
 *           type: string
 *         hardwareTarget:
 *           type: string
 *         other:
 *           type: string
 * @param sequelize
 */
const SoftwareTag = sequelize.define(
  'SoftwareTag',
  {
    name: { type: Sequelize.STRING, allowNull: false },
    description: { type: Sequelize.STRING, allowNull: false },
    part: { type: Sequelize.STRING },
    vendor: { type: Sequelize.STRING },
    version: { type: Sequelize.STRING },
    update: { type: Sequelize.STRING },
    edition: { type: Sequelize.STRING },
    language: { type: Sequelize.STRING, field: 'lang' },
    softwareEdition: { type: Sequelize.STRING, field: 'sw_edition' },
    softwareTarget: { type: Sequelize.STRING, field: 'target_sw' },
    hardwareTarget: { type: Sequelize.STRING, field: 'target_hw' },
    other: { type: Sequelize.STRING }
  },
  {
    timestamps: true,
    freezeTableName: true,
    tableName: 'software_tags',
    underscored: true
  }
);

SoftwareTag.associate = (models) => {
  // SoftwareTag.belongsTo(models.Organization, { required: true });
  SoftwareTag.belongsToMany(models.Asset, {
    through: 'asset_software_tags_members',
    foreignKey: 'software_tags_id',
    otherKey: 'asset_id',
    timestamps: true
  });
};

module.exports = SoftwareTag;
