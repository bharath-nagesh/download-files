const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();
const NetworkPortGroup = sequelize.define(
  'NetworkPortGroup',
  {
    hostId: { type: Sequelize.STRING, field: 'host_id' },
    elementId: { type: Sequelize.STRING, field: 'element_id' },
    name: { type: Sequelize.STRING },
    defaultVlanNumber: { type: Sequelize.INTEGER, field: 'default_vlan_number' },
    type: { type: Sequelize.STRING }
  },
  { timestamps: true, freezeTableName: true, tableName: 'network_portgroups', underscored: true }
);

NetworkPortGroup.associate = (models) => {
  NetworkPortGroup.belongsTo(models.AssetRepoEndpoint);

  NetworkPortGroup.belongsToMany(models.NetworkVirtualSwitch, {
    through: 'network_portgroup_vswitch_map',
    foreignKey: 'portgroup_id',
    otherKey: 'vswitch_id'
  });
  NetworkPortGroup.belongsToMany(models.NetworkEdgeAppliance, {
    through: 'network_edge_appliance_portgroup_map',
    foreignKey: 'portgroup_id',
    otherKey: 'edge_appliance_id'
  });
};

module.exports = NetworkPortGroup;
