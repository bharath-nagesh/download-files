const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();

/**
 * @swagger
 * components:
 *   schemas:
 *     WorkflowTasks:
 *       type: object
 *       required:
 *         - createdUserId
 *         - organizationId
 *         - cveIds
 *       properties:
 *         createdUserId:
 *           type: string
 *         organizationId:
 *           type: string
 *         cveIds:
 *           type: string
 *         cceIds:
 *           type: string
 *         assetIds:
 *           type: string
 *         assignedUserId:
 *           type: string
 *         ticketId:
 *           type: string
 *         summary:
 *           type: string
 *         notes:
 *           type: string
 *         isActive:
 *           type: string
 * @param sequelize
 */
class workflowTasks extends Sequelize.Model {
  static init(sequelize) {
    return super.init(
      {
        createdUserId: { type: Sequelize.INTEGER, field: 'created_user_id' },
        organizationId: { type: Sequelize.INTEGER, field: 'organization_id' },
        ticketSystemConfigurationId: { type: Sequelize.INTEGER, field: 'ticket_system_configuration_id' },
        cveIds: { type: Sequelize.STRING, field: 'cve_ids' },
        cceIds: { type: Sequelize.STRING, field: 'cce_ids' },
        assetIds: { type: Sequelize.STRING, field: 'asset_ids' },
        assignedUserId: { type: Sequelize.INTEGER, field: 'assigned_user_id' },
        ticketId: { type: Sequelize.STRING, field: 'ticket_id' },
        summary: { type: Sequelize.STRING, field: 'summary' },
        notes: { type: Sequelize.STRING, field: 'notes' },
        ticketType: { type: Sequelize.STRING, field: 'type' },
        isActive: { type: Sequelize.STRING, field: 'is_active' },
        is_active: { type: Sequelize.STRING, field: 'is_active' }
      },
      {
        sequelize,
        timestamps: true,
        freezeTableName: true,
        tableName: 'workflow_tasks',
        underscored: true
      }
    );
  }

  static associate(models) {
    workflowTasks.belongsTo(models.Organization, { foreignKey: 'organization_id' });
    workflowTasks.belongsTo(models.TicketSystemConfiguration, { foreignKey: 'ticket_system_configuration_id' });
    workflowTasks.belongsTo(models.User, { foreignKey: 'assigned_user_id' });
  };
}

module.exports = workflowTasks;
