const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();

class AssetPhysicalNetwork extends Sequelize.Model {
  static init(sequelize) {
    return super.init({
      physicalNic: { type: Sequelize.STRING, field: 'physical_nic' },
      physicalKey: { type: Sequelize.STRING, field: 'physical_key' },
      physicalHostIp: { type: Sequelize.STRING, field: 'physical_host_ip' },
      physicalMac: { type: Sequelize.STRING, field: 'physical_mac', allowNull: false },
      port: { type: Sequelize.INTEGER, field: 'port' },
      portGroupKey: { type: Sequelize.INTEGER, field: 'port_group_key' },
      portSwitchId: { type: Sequelize.STRING, field: 'port_switch_uuid' }
    },
    { sequelize, timestamps: true, freezeTableName: true, tableName: 'asset_physical_network_details', underscored: true });
  }

  static associate(models) {
    AssetPhysicalNetwork.belongsTo(models.Asset);
  };
}
module.exports = AssetPhysicalNetwork;
