const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();

class fedramp_low_controls extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
      name: {
        type: Sequelize.STRING,
        field: 'control_id'
      },
      description: {
        type: Sequelize.STRING,
        field: 'control_desc'
      },
      compliance: {
        type: Sequelize.STRING,
        field: 'compliance'
      }
    },
    { sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'fedramp_low_controls',
      underscored: true
    });
  }
}

module.exports = fedramp_low_controls;
