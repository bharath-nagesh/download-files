const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();

const NetworkEdgeAppliance = sequelize.define(
  'NetworkEdgeAppliance',
  {
    nat: { type: Sequelize.BOOLEAN, defaultValue: false },
    l2vpn: { type: Sequelize.BOOLEAN, defaultValue: false },
    dns: { type: Sequelize.BOOLEAN, defaultValue: false },
    sslvpn: { type: Sequelize.BOOLEAN, defaultValue: false },
    firewall: { type: Sequelize.BOOLEAN, defaultValue: false },
    routing: { type: Sequelize.BOOLEAN, defaultValue: false },
    ipsec: { type: Sequelize.BOOLEAN, defaultValue: false },
    dhcp: { type: Sequelize.BOOLEAN, defaultValue: false },
    loadbalancer: { type: Sequelize.BOOLEAN, defaultValue: false },
    elementId: { type: Sequelize.STRING, field: 'element_id' }
  },
  { timestamps: true, freezeTableName: true, tableName: 'network_portgroups', underscored: true }
);

NetworkEdgeAppliance.associate = (models) => {
  NetworkEdgeAppliance.belongsTo(models.AssetRepoEndpoint);
  NetworkEdgeAppliance.belongsToMany(models.NetworkPortGroup, {
    through: 'network_edge_appliance_portgroup_map',
    otherKey: 'portgroup_id',
    foreignKey: 'edge_appliance_id'
  });
};

module.exports = NetworkEdgeAppliance;
