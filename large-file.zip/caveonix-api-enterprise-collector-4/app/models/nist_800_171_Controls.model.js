const { DataTypes, Model } = require('sequelize');

class Nist800171Controls extends Model {
  static init(sequelize) {
    return super.init({
      family_id: {
        type: DataTypes.STRING,
        field: 'family_id'
      },
      family_name: {
        type: DataTypes.STRING,
        field: 'family_name'
      },
      control_name: {
        type: DataTypes.STRING,
        field: 'control_name'
      },
      control_id: {
        type: DataTypes.STRING,
        field: 'control_id'
      },
      control_desc: {
        type: DataTypes.STRING,
        field: 'control_desc'
      },
      control_guide: {
        type: DataTypes.STRING,
        field: 'control_guide'
      },
      mapping_id: {
        type: DataTypes.STRING,
        field: 'mapping_id'
      },
      compliance: {
        type: DataTypes.STRING,
        field: 'compliance'
      }
    },
    {
      sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'nist_800_171_controls',
      underscored: true
    });
  }
}

module.exports = Nist800171Controls;
