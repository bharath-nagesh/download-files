const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();

class UserSessionInfo extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      user_id: {
        type: Sequelize.INTEGER,
        field: 'user_id'
      },
      session_id: {
        type: Sequelize.STRING,
        field: 'session_id'
      },
      organization_id: {
        type: Sequelize.INTEGER,
        field: 'organization_id'
      },
      isActive: {
        type: Sequelize.BOOLEAN,
        field: 'is_active',
        defaultValue: true
      },
      is_active: {
        type: Sequelize.BOOLEAN,
        field: 'is_active',
      }
    },
    { sequelize,
      timestamps: true,
      freezeTableName: true,
      tableName: 'user_session_info',
      underscored: true
    });
  }
}

module.exports = UserSessionInfo;
