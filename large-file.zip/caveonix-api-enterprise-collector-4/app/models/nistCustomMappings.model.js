const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();
const NistCustomMappings = sequelize.define(
  'nistCustomMappings',
  {
    nistId: {
      type: Sequelize.STRING,
      field: 'nist_id'
    },
    customId: {
      type: Sequelize.STRING,
      field: 'custom_id'
    }
  },
  {
    timestamps: false,
    freezeTableName: true,
    tableName: 'nist_custom_mappings',
    underscored: true
  }
);

NistCustomMappings.upsert = (nistId, customId, data) => {
  const find = { nistId, customId };
  const create = data;
  return NistCustomMappings.findOrCreate({ where: find, defaults: create });
};

// nistCustomMappings.removeAttribute('id');
module.exports = NistCustomMappings;
