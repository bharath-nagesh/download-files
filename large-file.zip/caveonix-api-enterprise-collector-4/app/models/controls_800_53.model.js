const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();

class controls_800_53 extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
      name: {
        type: Sequelize.STRING,
        field: 'name'
      },
      description: {
        type: Sequelize.STRING,
        field: 'description'
      },
      compliance: {
        type: Sequelize.STRING,
        field: 'compliance'
      },
      baseline: {
        type: Sequelize.STRING,
        field: 'baseline'
      }
    },
    { sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'controls_800_53',
      underscored: true
    });
  }
}
module.exports = controls_800_53;
