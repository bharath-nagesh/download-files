const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();

let Module = sequelize.define(
  'Module',
  {
    name: {type: Sequelize.STRING},
    description: {type: Sequelize.STRING}
  },
  {
    timestamps: false,
    freezeTableName: true,
    tableName: 'modules',
    underscored: true
  }
);

let classMethods = {
  associate: function (models) {
    Module.belongsToMany(models.Role, {as: 'Modules', through: models.RoleModulePermission});
  }
};
for (let key in classMethods) {
  Module[key] = classMethods[key];
}

module.exports = Module;

