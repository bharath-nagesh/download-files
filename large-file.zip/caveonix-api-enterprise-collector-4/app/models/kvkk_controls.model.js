const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();

class KvkkControls extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
      control_id: {
        type: Sequelize.STRING,
        field: 'control_id'
      },
      chapter: {
        type: Sequelize.STRING,
        field: 'chapter'
      },
      chapter_name: {
        type: Sequelize.STRING,
        field: 'chapter_name'
      },
      artical: {
        type: Sequelize.STRING,
        field: 'artical'
      },
      artical_name: {
        type: Sequelize.STRING,
        field: 'artical_name'
      },
      control_desc: {
        type: Sequelize.STRING,
        field: 'control_desc'
      },
      compliance: {
        type: Sequelize.STRING,
        field: 'compliance'
      }
    },
    { sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'kvkk_controls',
      underscored: true
    });
  }
}

module.exports = KvkkControls;
