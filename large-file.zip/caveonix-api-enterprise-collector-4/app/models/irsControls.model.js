const { DataTypes, Model } = require('sequelize');

class IrsControls extends Model {
  static init(sequelize) {
    return super.init({
      family_name: {
        type: DataTypes.STRING,
        field: 'family_name'
      },
      session_id: {
        type: DataTypes.STRING,
        field: 'session_id'
      },
      control_id: {
        type: DataTypes.STRING,
        field: 'control_id'
      },
      control_name: {
        type: DataTypes.STRING,
        field: 'control_name'
      },
      control_desc: {
        type: DataTypes.STRING,
        field: 'control_desc'
      },
      mapping_id: {
        type: DataTypes.STRING,
        field: 'mapping_id'
      },
      compliance: {
        type: DataTypes.STRING,
        field: 'compliance'
      }
    },
    {
      sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'irs_controls',
      underscored: true
    });
  }
}

module.exports = IrsControls;
