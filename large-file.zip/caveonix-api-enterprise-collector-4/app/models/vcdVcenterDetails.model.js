const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();

/**
 * @swagger
 * components:
 *   schemas:
 *     VcdVcenterDetails:
 *       type: object
 *       required:
 *         - asset_repo_endpoint_vcd_id
 *         - vcenter_url
 *         - organization_id
 *         - location_id
 *         - hosting_provider_id
 *       properties:
 *         asset_repo_endpoint_vcd_id:
 *           type: string
 *         vcenter_url:
 *           type: string
 *         organization_id:
 *           type: string
 *         location_id:
 *           type: string
 *         hosting_provider_id:
 *           type: string
 *         domain_id:
 *           type: string
 *         vcd_vms_only:
 *           type: string
 * @param sequelize
*/
const vcdVcenterDetails = sequelize.define(
  'vcdVcenterDetails',
  {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    asset_repo_endpoint_vcd_id: { type: Sequelize.STRING, field: 'asset_repo_endpoint_vcd_id' },
    vcenter_url: { type: Sequelize.STRING, field: 'vcenter_url' },
    organization_id: { type: Sequelize.STRING, field: 'organization_id' },
    location_id: { type: Sequelize.INTEGER, field: 'location_id' },
    hosting_provider_id: { type: Sequelize.STRING, field: 'hosting_provider_id' },
    vcd_vms_only: { type: Sequelize.STRING, field: 'vcd_vms_only' },
    domain_id: { type: Sequelize.STRING, field: 'domain_id' }
  },
  {
    timestamps: true,
    freezeTableName: true,
    tableName: 'vcd_vcenter_details',
    underscored: true,
    updatedAt: false,
    createdAt: 'created_at'
  }
);

vcdVcenterDetails.associate = (models) => {
  vcdVcenterDetails.belongsTo(models.Organization);
};

module.exports = vcdVcenterDetails;
