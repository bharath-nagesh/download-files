const { Model, DataTypes } = require('sequelize');

/**
 * @swagger
 * components:
 *   schemas:
 *     KorIsms:
 *       type: object
 *       properties:
 *         domain_id:
 *           type: string
 *         domain:
 *           type: string
 *         family_id:
 *           type: string
 *         family:
 *           type: string
 *         control_id:
 *           type: string
 *         control_name:
 *           type: string
 *         control_desc:
 *           type: string
 *         control_test:
 *           type: string
 *         mapping_id:
 *           type: string
 * @param sequelize
 */

class KorIsmsControls extends Model {
  static init(sequelize) {
    return super.init({
      domain_id: {
        type: DataTypes.STRING
      },
      domain: {
        type: DataTypes.STRING
      },
      family_id: {
        type: DataTypes.STRING
      },
      family: {
        type: DataTypes.STRING
      },
      control_id: {
        type: DataTypes.STRING
      },
      control_name: {
        type: DataTypes.STRING
      },
      control_desc: {
        type: DataTypes.STRING
      },
      control_test: {
        type: DataTypes.STRING
      },
      mapping_id: {
        type: DataTypes.STRING
      }
    },
    {
      sequelize,
      timestamps: true,
      freezeTableName: true,
      tableName: 'kor_isms_controls',
      underscored: true
    }
    );
  }
}

module.exports = KorIsmsControls;
