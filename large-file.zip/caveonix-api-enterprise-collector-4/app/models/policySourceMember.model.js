const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();

class PolicySourceMembers extends Sequelize.Model {
  static init(sequelize) {
    return super.init({
        policyGroupId: { type: Sequelize.INTEGER, field: 'policy_group_id' },
        subApplicationId: { type: Sequelize.INTEGER, field: 'policy_group_id' },
        sourceId: { type: Sequelize.INTEGER, field: 'source_id' },
        sourceType: { type: Sequelize.STRING, field: 'source_type' }
      },
      {
        sequelize,
        timestamps: false,
        freezeTableName: true,
        tableName: 'sub_application_members',
        underscored: true
      });
  }

  static associate(models) {
    PolicySourceMembers.belongsTo(models.PolicyGroup, { foreignKey: 'policyGroupId' });
    PolicySourceMembers.belongsTo(models.ApplicationTag, { foreignKey: 'sourceId' });
  };
}

module.exports = PolicySourceMembers;
