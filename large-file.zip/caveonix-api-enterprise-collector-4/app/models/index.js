/*
let logger = require('./../../utils/logger').logger.child({

  sub_name: 'IdentityService.model'

});

function isClass(func) {
  return typeof func === 'function'
    && /^class\s/.test(Function.prototype.toString.call(func));
}

var fs = require('fs');
var path = require('path');
var Sequelize = require('sequelize');
var basename = path.basename(module.filename);
var db = {};
let config = require('./../../configure').get();
const NodeCache = require('node-cache');
let KeyGenerator = require('./../../utils/generateKeys');
let keyGenerator = new KeyGenerator();
let sequelize = require('../../config/db.conf');

fs
  .readdirSync(__dirname)
  .filter(function (file) {
    return file.indexOf('.') !== 0 && file !== basename && file.slice(-3) === '.js';
  })
  .forEach(function (file) {
    logger.info({file});
    // let model;
    let model = require(path.join(__dirname, file));
    // if (!isClass(mod)) {
    // sequelize['import'](path.join(__dirname, file));
    // var model = sequelize['import'](path.join(__dirname, file));
    //   logger.info({mod}, ' un oh');
    // } else {
    //   model = mod;
    // }
    db[model.name] = model;
  });
let models = [];
Object.keys(db).forEach(function (modelName) {
  models.push(modelName);

  if (db[modelName].associate) {
    db[modelName].associate(db);
  }
});
db.sequelize = sequelize;
db.Sequelize = Sequelize;
db.modelNames = models;
// });
module.exports = db;
*/
