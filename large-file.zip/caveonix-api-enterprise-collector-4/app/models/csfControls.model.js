const { DataTypes, Model } = require('sequelize');

class CsfControls extends Model {
  static init(sequelize) {
    return super.init({
      function: {
        type: DataTypes.STRING,
        field: 'function'
      },
      control_name: {
        type: DataTypes.STRING,
        field: 'control_name'
      },
      control_id: {
        type: DataTypes.STRING,
        field: 'control_id'
      },
      control_desc: {
        type: DataTypes.STRING,
        field: 'control_desc'
      },
      mapping_id: {
        type: DataTypes.STRING,
        field: 'mapping_id'
      },
      sub_control_id: {
        type: DataTypes.STRING,
        field: 'sub_control_id'
      },
      sub_control_desc: {
        type: DataTypes.STRING,
        field: 'sub_control_desc'
      },
      compliance: {
        type: DataTypes.STRING,
        field: 'compliance'
      }
    },
    {
      sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'csf_controls',
      underscored: true
    });
  }
}

module.exports = CsfControls;
