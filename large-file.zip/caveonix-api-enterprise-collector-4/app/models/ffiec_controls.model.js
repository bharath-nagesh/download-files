const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();

class ffiec_controls extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
      name: {
        type: Sequelize.STRING,
        field: 'control'
      },
      description: {
        type: Sequelize.STRING,
        field: 'control_desc'
      },
      compliance: {
        type: Sequelize.STRING,
        field: 'compliance'
      }
    },
    { sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'ffiec_controls',
      underscored: true
    });
  }
}

module.exports = ffiec_controls;
