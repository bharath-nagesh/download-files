const Sequelize = require('sequelize');

class Notifications extends Sequelize.Model {
  static init(sequelize) {
    return super.init(
      {
        detail: { type: Sequelize.STRING, field: 'notification_detail' },
        action: { type: Sequelize.STRING, field: 'notification_action' },
        isActive: { type: Sequelize.STRING, field: 'is_active' },
      },
      {
        sequelize,
        timestamps: true,
        freezeTableName: true,
        tableName: 'caveo_notifications',
        underscored: true,
        createdAt: 'created_at',
        updatedAt: false
      }
    );
  }

  static associate(models) {
    Notifications.belongsTo(models.Organization, { foreignKey: 'organization_id' });
    Notifications.belongsTo(models.User, { foreignKey: 'user_id' });
  }
};
module.exports = Notifications;
