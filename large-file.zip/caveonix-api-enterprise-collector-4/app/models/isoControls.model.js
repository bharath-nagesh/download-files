const Sequelize = require('sequelize');
const sequelize = require('../../config/db.conf').getConnection();

class IsoControls extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
      name: {
        type: Sequelize.STRING,
        field: 'control'
      },
      description: {
        type: Sequelize.STRING,
        field: 'control_desc'
      },
      compliance: {
        type: Sequelize.STRING,
        field: 'compliance'
      }
    },
    { sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'iso_controls',
      underscored: true
    });
  }
}

module.exports = IsoControls;
