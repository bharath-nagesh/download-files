const express = require('express');
const { makeCertificateRouter, makeApplicationCertificationRouter } = require('../../apis/certificates/certificates.routes');
const router = express.Router({ mergeParams: true });

makeCertificateRouter('/:appId/certificate', router);
makeApplicationCertificationRouter('/certification', router);
module.exports = router;
