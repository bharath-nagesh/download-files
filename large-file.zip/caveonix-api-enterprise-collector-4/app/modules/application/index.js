const checkPermission = require('./application.permissions');
const router = require('./application.routes');
module.exports = { router, checkPermission };
