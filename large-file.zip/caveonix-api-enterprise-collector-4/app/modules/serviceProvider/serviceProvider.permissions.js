const errorHandler = require('../../../utils/errorHandler');
const Organization = require('../../apis/organization/organization.model');
const _ = require('lodash');
module.exports = async (req, res, next,serviceProviderId) => {
  const { user } = req;
  const orgIds = user.Organizations.map(o => o.id);
  const verb = req.method;

  const checks = await Promise.all(orgIds.map(async (orgId) => {
    const serviceProvider = await Organization.findByPk(serviceProviderId, { where: { type: 'Provider' } });
    if (!serviceProvider) return false;
    const chain = await Organization.getOrgChain(orgId);
    return chain.includes(parseInt(serviceProviderId));
  }));
  const allowed = _.some(checks, Boolean);

  if (allowed) {
    return next();
  }
  const error = new Error('Unauthorized');
  error.status = 401;
  return errorHandler(req, res, error);

};


