module.exports = require('../../apis/serviceProvider/serviceProvider.routes');
