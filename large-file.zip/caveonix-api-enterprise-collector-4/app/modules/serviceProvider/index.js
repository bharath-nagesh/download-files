const checkPermission = require('./serviceProvider.permissions');
const router = require('./serviceProvider.routes');
module.exports = { router, checkPermission  };
