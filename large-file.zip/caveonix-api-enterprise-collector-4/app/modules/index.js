const internal = require('./internal');
const organization = require('./organization');
const application = require('./application');
const serviceProvider = require('./serviceProvider');
const user = require('./user');
const auth = require('./auth');
module.exports = { internal, organization, application, serviceProvider, user, auth };
