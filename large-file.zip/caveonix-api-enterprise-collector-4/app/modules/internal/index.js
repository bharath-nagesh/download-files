const checkPermission = require('./internal.permissions');
const router = require('./internal.routes');
module.exports = { router, checkPermission };
