const express = require('express');
const ReportController = require('../../apis/reports/reports.controller');
const reportController = new ReportController();
const OrgController = require('../../apis/organization/org.controller');

const definitions = require('../../definitions/org.js');
const complianceDefinitions = require('../../definitions/compliance');
const cyberDefinitions = require('../../definitions/cyber');
const assetDefinitions = require('../../definitions/asset');
const router = express.Router({mergeParams:true});
const ReferenceService = require('../../services/reference.service');
const referenceService = new ReferenceService();

// todo look into this
router.post('/organization/:orgId/reports/createReport', reportController.createReport);
router.post('/organization/:orgId/reports/createScheduledReport', reportController.createScheduledReport);
router.get('/organization/:orgId', OrgController.getOrganization);

referenceService.addEndpoints(null, router, definitions, '/organization/:orgId');
referenceService.addEndpoints(null, router, complianceDefinitions, '/organization/:orgId/compliance');
referenceService.addEndpoints(null, router, cyberDefinitions, '/organization/:orgId/cyber');
referenceService.addEndpoints(null, router, assetDefinitions, '/organization/:orgId/asset');
module.exports = router;
