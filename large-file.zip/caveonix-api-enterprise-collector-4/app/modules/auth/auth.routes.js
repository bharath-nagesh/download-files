module.exports = require('../../apis/auth/auth.routes');
