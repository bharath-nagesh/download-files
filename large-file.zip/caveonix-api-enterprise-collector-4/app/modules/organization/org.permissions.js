const _ = require('lodash');

const errorHandler = require('../../../utils/errorHandler');
const isAppliance = require('../../../utils/isAppliance');
const Organization = require('../../apis/organization/organization.model');

module.exports = async (req, res, next, requestOrgId) => {
  const { user } = req;
  const orgIds = user.Organizations.map(o => o.id);

  const checks = await Promise.all(orgIds.map(async (orgId) => {
    const org = await Organization.findByPk(requestOrgId);
    if (!org) {
      return false;
    }
    const chain = await Organization.getOrgChain(orgId);
    return isAppliance() ? true : chain.includes(parseInt(requestOrgId));
  }));
  const allowed = _.some(checks, Boolean);

  if (allowed) {
    return next();
  }
  const error = new Error('Unauthorized');
  error.status = 401;
  return errorHandler(req, res, error);
};