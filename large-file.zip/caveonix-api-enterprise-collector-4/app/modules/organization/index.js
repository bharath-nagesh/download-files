const checkPermission = require('./org.permissions');
const router = require('./org.routes');
const isProvider = require('./isProvider.middleware');
module.exports = { router, checkPermission, isProvider };
