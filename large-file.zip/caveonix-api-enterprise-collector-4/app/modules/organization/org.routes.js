const AssetController = require('../../apis/asset/asset.controller');
const AssetRepoEndpointRouter = require('../../apis/assetRepoEndpoint/assetRepoEndpoint.routes');
const AssetRouter = require('../../apis/asset/asset.routes');
const AssetRemoteAccessDetailMembersController = require('../../apis/assetRemoteAccessDetailMembers/assetRemoteAccessDetailMembers.controller');
const AssetRemoteAccessDetailMembersRouter = require('../../apis/assetRemoteAccessDetailMembers/assetRemoteAccessDetailMembers.routes');
const AuthorizationInfoRouter = require('../../apis/authorizationInfo/authorizationInfo.routes');
const express = require('express');
const JobRouter = require('../../apis/job/job.routes');
const OrgController = require('../../apis/organization/org.controller');
const OrgOnboardingStatusRouter = require('../../apis/orgOnboardingStatus/orgOnboardingStatus.routes');
const RemoteAccessDetailRouter = require('../../apis/remoteAccessDetail/remoteAccessDetail.routes');
const ScanAuditRouter = require('../../apis/scanAudit/scanAudit.routes');
const UserController = require('../../apis/user/user.controller');
const CaveoAgentRouter = require('../../apis/caveoAgent/caveoAgent.routes');
const idCheckMiddlewareFactory = require('../../middlewares/idCheck.middleware');

const router = express.Router({ mergeParams: true });
router.param('orgId', idCheckMiddlewareFactory('organization'));

/**
 * @swagger
 * tags:
 *  - name: Organization
 *    description: Organization endpoints
 *  - name: User
 *    description: User endpoints
 */
function setupOrganizationRoutes() {
  // router.get(`/:orgId/related-laws`, OrgController.getRelatedLaws);
  // router.post(`/:orgId/related-laws`, OrgController.createRelatedLaws);
  // router.put(`/:orgId/related-laws/:relatedLawId`, OrgController.updateRelatedLaws);
  /**
   * @swagger
   *
   * /api/organization/{orgId}:
   *   get:
   *     tags:
   *       - Organization
   *     summary: Gets an organization by its id
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: orgId
   *         description: The organization's id.
   *         in: path
   *         required: true
   *         type: number
   *     responses:
   *       200:
   *         description: get the license
   *       401:
   *         description: unauthorized
   */
  router.get('/:orgId/', OrgController.getOrganization); //done

  /**
   * @swagger
   *
   * /api/organization:
   *   post:
   *     tags:
   *       - Organization
   *     summary: Creates an organization
   *     produces:
   *       - application/json
   *     requestBody:
   *       content:
   *         application/json:
   *           schema:
   *             $ref: '#/components/schemas/Organization'
   *     responses:
   *       200:
   *         description: get the license
   *       401:
   *         description: unauthorized
   */
  // router.post('/', pngUpload.single('orgLogo'), OrgController.createChildOrganization); //done

  /**
   * @swagger
   *
   * /api/organization/{orgId}:
   *   put:
   *     tags:
   *       - Organization
   *     summary: Updates the specified organization
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: orgId
   *         description: The organization's id.
   *         in: path
   *         required: true
   *         type: number
   *     requestBody:
   *       content:
   *         application/json:
   *           schema:
   *             $ref: '#/components/schemas/Organization'
   *     responses:
   *       200:
   *         description: get the license
   *       401:
   *         description: unauthorized
   */
  // router.put('/:orgId', pngUpload.single('orgLogo'), OrgController.updateOrganization); //done

  /**
   * @swagger
   *
   * /api/organization/{orgId}/subOrganizations:
   *   get:
   *     tags:
   *       - Organization
   *     summary: Gets sub organizations
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: orgId
   *         description: The organization's id.
   *         in: path
   *         required: true
   *         type: number
   *     responses:
   *       200:
   *         description: get the license
   *       401:
   *         description: unauthorized
   */
  router.get('/:orgId/subOrganizations', OrgController.getOrgChain); //done

  /**
   * @swagger
   *
   * /api/organization/{orgId}/subOrganizations:
   *   delete:
   *     tags:
   *       - Organization
   *     summary: Deletes multiple organizations by their ids
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: orgId
   *         description: The organization's id.
   *         in: path
   *         required: true
   *         type: number
   *       - name: id
   *         description: A comma delimited list of ids
   *         in: query
   *         required: true
   *         type: string
   *     responses:
   *       200:
   *         description: get the license
   *       401:
   *         description: unauthorized
   */
  // router.delete('/:orgId/subOrganizations', OrgController.deleteMultipleOrg); //done
  // router.get('/:orgId/key/generate', OrgController.generateKey);
  // router.get('/:orgId/key', OrgController.getKey);
  // router.get('/:orgId/cloudFormation', OrgController.getCloudFormation);
  // // license
  // router.put('/:orgId/updateLicense', upload.fields([{ name: 'licenseKey', maxCount: 1 }, {
  //   name: 'publicKey',
  //   maxCount: 1
  // }]), OrgController.updateCaveoLicense); //done
  // // license key
  // router.put('/:orgId/license-key', OrgController.updateLicenseKey); //done

  /**
   * @swagger
   *
   * /api/organization/{orgId}/getOrgListForOrgUpdate:
   *   get:
   *     tags:
   *       - Organization
   *     summary: Gets an organization by its id
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: orgId
   *         description: The organization's id.
   *         in: path
   *         required: true
   *         type: number
   *     responses:
   *       200:
   *         description: get the license
   *       401:
   *         description: unauthorized
   */
  // router.get('/:orgId/getOrgListForOrgUpdate', OrgController.getAllOrgListForOrgUpdate); //done/

  /**
   * @swagger
   *
   * /api/organization/{orgId}/getManifestInfo:
   *   get:
   *     tags:
   *       - RF
   *     summary: Gets the app's build manifest information
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: orgId
   *         description: The organization's id.
   *         in: path
   *         required: true
   *         type: number
   *     responses:
   *       200:
   *         description: get the manifest info
   *       401:
   *         description: unauthorized
   */
  // router.get('/:orgId/getManifestInfo', OrgController.getBuildInfo); //done

  /**
   * @swagger
   *
   * /api/organization/{orgId}/logo:
   *   get:
   *     tags:
   *       - Organization
   *     summary: Gets an organization's logo
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: orgId
   *         description: The organization's id.
   *         in: path
   *         required: true
   *         type: number
   *     responses:
   *       200:
   *         description: get the license
   *       401:
   *         description: unauthorized
   */
  // router.get('/:orgId/logo', OrgController.getLogo);

  /**
   * @swagger
   *
   * /api/organization/{orgId}/logo:
   *   post:
   *     tags:
   *       - Organization
   *     summary: Sets an organization's logo
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: orgId
   *         description: The organization's id.
   *         in: path
   *         required: true
   *         type: number
   *     responses:
   *       200:
   *         description: get the logo
   *       401:
   *         description: unauthorized
   */
  // router.post('/:orgId/logo', pngUpload.single('file'), OrgController.addLogo);

  // search routes
  // router.get('/:orgId/advancedSearch', SearchController.getSearch);
}

function setupUserRoutes() {
  const userController = new UserController();
  // todo look into the user of OrgController vs UserController
  // new UserRouter('/:orgId/user', router, 'Organization');
  /**
   * @swagger
   *
   * /api/organization/{orgId}/user:
   *   get:
   *     tags:
   *       - User
   *     summary: Gets a list of all users
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: orgId
   *         description: The organization's id.
   *         in: path
   *         required: true
   *         type: number
   *     responses:
   *       200:
   *         description: get all users
   *       401:
   *         description: unauthorized
   */
  router.get('/:orgId/user', OrgController.getOrganizationUsers); //done

  /**
   * @swagger
   *
   * /api/organization/{orgId}/user/{userId}:
   *   get:
   *     tags:
   *       - User
   *     summary: Gets a user by their id
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: orgId
   *         description: The organization's id.
   *         in: path
   *         required: true
   *         type: number
   *       - name: userId
   *         description: The organization's id.
   *         in: path
   *         required: true
   *         type: number
   *     responses:
   *       200:
   *         description: get all users
   *       401:
   *         description: unauthorized
   */
  router.get('/:orgId/user/:userId', userController.getUser); //done

  /**
   * @swagger
   *
   * /api/organization/{orgId}/user:
   *   post:
   *     tags:
   *       - User
   *     summary: Gets a list of all users
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: orgId
   *         description: The organization's id.
   *         in: path
   *         required: true
   *         type: number
   *     requestBody:
   *       content:
   *         application/json:
   *           schema:
   *             $ref: '#/components/schemas/User'
   *     responses:
   *       200:
   *         description: get all users
   *       401:
   *         description: unauthorized
   */
  router.post('/:orgId/user', OrgController.createOrganizationUser); //done

  /**
   * @swagger
   *
   * /api/organization/{orgId}/changeOrgUser:
   *   put:
   *     tags:
   *       - User
   *     summary: Updates the specified organization user
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: orgId
   *         description: The organization's id.
   *         in: path
   *         required: true
   *         type: number
   *       - name: userId
   *         description: The user's id.
   *         in: path
   *         required: true
   *         type: number
   *     responses:
   *       200:
   *         description: user is updated
   *       401:
   *         description: unauthorized
   */
  router.put('/:orgId/user/:userId/changeOrgUser', OrgController.changeOrganizationUser); //done

  /**
   * @swagger
   *
   * /api/organization/{orgId}/user:
   *   delete:
   *     tags:
   *       - User
   *     summary: Deletes an organization user
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: orgId
   *         description: The organization's id.
   *         in: path
   *         required: true
   *         type: number
   *       - name: userId
   *         description: The user's id.
   *         in: path
   *         required: true
   *         type: number
   *     responses:
   *       200:
   *         description: the organization user is deleted
   *       401:
   *         description: unauthorized
   */
  router.delete('/:orgId/user/:userId/deleteOrgUser', OrgController.deleteOrganizationUser); //done

  // todo make these more RESTful
  /**
   * @swagger
   *
   * /api/organization/{orgId}/multiUser:
   *   delete:
   *     tags:
   *       - User
   *     summary: Deletes a list of multiple users
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: orgId
   *         description: The organization's id.
   *         in: path
   *         required: true
   *         type: number
   *       - name: userId
   *         description: A comma delimited list of user ids.
   *         in: query
   *         required: true
   *         type: string
   *     responses:
   *       200:
   *         description: users have been deleted
   *       401:
   *         description: unauthorized
   */
  router.delete('/:orgId/user', userController.deleteMultipleUser);
}

function setupAssetRoutes() {
  new AssetRouter('/:orgId/asset', router, 'org');

  // todo makes this more RESTful
  const assetController = new AssetController();

  /**
   * @swagger
   *
   * /api/organization/{orgId}/assets:
   *   get:
   *     tags:
   *       - Asset
   *     summary: Gets a list of assets for an organization
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: orgId
   *         description: The organization's id.
   *         in: path
   *         required: true
   *         type: number
   *     responses:
   *       200:
   *          description: List of assets
   *       400:
   *          description: Bad Request
   */
  router.get('/:orgId/assets', assetController.getAssetListForOrg);

  /**
   * @swagger
   *
   * /api/organization/{orgId}/assetsList:
   *   get:
   *     tags:
   *       - Asset
   *     summary: Gets a list of assets for an organization
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: orgId
   *         description: The organization's id.
   *         in: path
   *         required: true
   *         type: number
   *     responses:
   *       200:
   *          description: List of assets
   *       400:
   *          description: Bad Request
   */
  // router.get('/:orgId/assetsList', assetController.getAssetList);
  //
  // router.get('/:orgId/assetCount', assetController.getAssetCount);
  // router.get('/:orgId/getAssetForApplication/:policyGroupId', assetController.getAssetForApplication);
  // router.post('/:orgId/bulkCreateAssets', assetController.bulkCreateAssets);
  // router.post('/:orgId/uploadAssets', upload.single('file'), assetController.uploadAssets);
  // router.put('/:orgId/AssignAssetToSubApp', assetController.AssignAssetToSubApp);
  router.get('/:orgId/assetById/:assetId', assetController.getAssetById);
  // router.post('/:orgId/startAssetDiscovery', assetController.AssetDiscovery);
  router.delete('/:orgId/deleteAsset/', assetController.deleteMultipleAssets);
  // router.put('/:orgId/ChangeAssetState', assetController.ChangeAssetState);
  // router.put('/:orgId/ChangeNetworkIp/:asset_id', assetController.ChangeNetworkIp);
  // router.get('/:orgId/billing', OrgController.getBillingInfoForOrg);
  // router.get('/:orgId/billingDetails', OrgController.getBillingDetailsForOrg);

}

function setupAuthorizationInfoRoutes() {
  new AuthorizationInfoRouter('/:orgId/authorizationInfo', router);
}

function setupAssetRepoEndpointRoutes() {
  new AssetRepoEndpointRouter('/:orgId/assetRepoEndpoint', router);
}

function setupRemoteAccessDetailRoutes() {
  new RemoteAccessDetailRouter('/:orgId/remoteAccessDetail', router);
}

function setupAssetRemoteAccessDetailMembersRoutes() {
  router.use('/:orgId/assetRemoteAccessMembers', (req, res, next) => {
    new AssetRemoteAccessDetailMembersRouter('/:orgId/assetRemoteAccessMembers', router);
  });

  const assetRemoteAccessDetailMembersController = new AssetRemoteAccessDetailMembersController();
  router.get('/:orgId/getAssetRemoteAccessDetailMembersWithAssetDetails/:remoteAccessDetailId', assetRemoteAccessDetailMembersController.getAssetRemoteAccessDetailMembersWithAssetDetails);
}

function setupCaveoAgentRoutes() {
  new CaveoAgentRouter('/:orgId/agent', router);
}

function setupJobRoutes() {
  new JobRouter('/:orgId/job', router);
}

function setupOrgOnboardingRoutes() {
  new OrgOnboardingStatusRouter('/:orgId/onboarding', router, 'org');
}

/**
 * @swagger
 * tags:
 *   - name: AuditScan
 *     description: Audit Scan endpoints
 */
function setupAuditScanRoutes() {
  // todo sync up the naming with the endpoint
  new ScanAuditRouter('/:orgId/auditScanHistory', router);
}

/**
 * Setting up all of the organization related routes
 */
function setupOrgRoutes() {
  setupUserRoutes();
  setupOrganizationRoutes();
  setupAssetRoutes();
  setupAuthorizationInfoRoutes();
  setupAssetRepoEndpointRoutes();
  setupRemoteAccessDetailRoutes();
  setupAssetRemoteAccessDetailMembersRoutes();
  setupJobRoutes();
  setupOrgOnboardingRoutes();
  setupAuditScanRoutes();
  setupCaveoAgentRoutes();
}

// setting up organization endpoints
setupOrgRoutes();
module.exports = router;
