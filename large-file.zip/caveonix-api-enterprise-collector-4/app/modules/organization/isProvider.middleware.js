const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-isProvider.middleware'
});
module.exports = async function (req, res, next) {
  const { type } = req.user.Organizations[0];
  req.isProvider = type == 'Provider';
  next();
};
