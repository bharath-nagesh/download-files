const checkPermission = require('./user.permissions');
const router = require('./user.routes');
module.exports = { router, checkPermission };
