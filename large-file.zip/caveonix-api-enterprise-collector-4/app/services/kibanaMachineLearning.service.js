var rp = require('request-promise');
const fs = require('fs');
let kibanaMachineLearningPayload = fs.readFileSync('./utils/machineLearning.json');
let KeyGenerator = require('./../../utils/generateKeys');
//let config = require('../../config.json');
let config = require('./../../configure').get();
const sequelize = require('../../config/db.conf').getConnection();
const _ = require('lodash');
var auth = "";
let jobArr = [];
let dataFeedArr = [];
const ForensicsDashboard = require('../models/forensicsDashboard.model');
let logger = require('./../../utils/logger').logger.child({
    sub_name: 'IdentityService-kibanaMachineLearning.service',
});
module.exports = class Service {
    constructor(services) {
        this.services = services;
        this.keyGenerator = new KeyGenerator();
        logger.debug('called constructor');
    }
    async createAnomalyExp(orgId, data) {
        let service = this;
        let newPassword = await service.keyGenerator.decryptKeys(config.es_password);
        auth = "Basic " + new Buffer(config.es_username + ":" + newPassword).toString("base64");
        return service.createJob(orgId, data);
    }
    async createJob(orgId, data) {
        var machineLearningPayload = JSON.parse(kibanaMachineLearningPayload);
        let service = this;
        let titleLinuxLog = "caveolinuxlog-" + orgId;
        let titleWinLog = "caveowinlog-" + orgId;
        let titleScan = "caveoscan-" + orgId;
        let titleFlow = "caveonetwork-" + orgId;

        let logIframe = "";
        let scanIframe = "";
        let flowIframe = "";

        data.forEach(object =>{
            if(object.type == 'logs'){
                logIframe = object.dashboard_url;
            }
            if(object.type == 'scan'){
                scanIframe = object.dashboard_url;
            }
            if(object.type == 'flows'){
                flowIframe = object.dashboard_url;
            }
        })

        let urlLinuxLog = config.kibana_url + '/api/ml/anomaly_detectors/' + titleLinuxLog;
        let urlWinLog = config.kibana_url + '/api/ml/anomaly_detectors/' + titleWinLog;
        let urlScan = config.kibana_url + '/api/ml/anomaly_detectors/' + titleScan;
        let urlFlow = config.kibana_url + '/api/ml/anomaly_detectors/' + titleFlow;

        let urlArr = new Array();
        urlArr.push(urlLinuxLog, urlWinLog, urlScan, urlFlow);

        for(let u=0; u<urlArr.length; u++){
            let object = urlArr[u];
            let payload = "";
            if (object === urlLinuxLog) {
                //machineLearningPayload.machineLearning.Jobs[1].custom_settings.custom_urls[0].url_name = titleLog;
                machineLearningPayload.machineLearning.Jobs[1].custom_settings.custom_urls[0].url_value = service.splitDashboard(logIframe, 'hostName.keyword');
                machineLearningPayload.machineLearning.Jobs[1].results_index_name = titleLinuxLog;
                payload = machineLearningPayload.machineLearning.Jobs[1];
            }
            else if (object === urlWinLog) {
                //machineLearningPayload.machineLearning.Jobs[1].custom_settings.custom_urls[0].url_name = titleLog;
                machineLearningPayload.machineLearning.Jobs[2].custom_settings.custom_urls[0].url_value = service.splitDashboard(logIframe, 'MachineName.keyword');
                machineLearningPayload.machineLearning.Jobs[2].results_index_name = titleWinLog;
                payload = machineLearningPayload.machineLearning.Jobs[2];
            }
            else if (object === urlScan) {
                //machineLearningPayload.machineLearning.Jobs[0].custom_settings.custom_urls[0].url_name = titleScan;
                machineLearningPayload.machineLearning.Jobs[0].custom_settings.custom_urls[0].url_value = service.splitDashboard(scanIframe, 'asset_name.keyword');
                machineLearningPayload.machineLearning.Jobs[0].results_index_name = titleScan;
                payload = machineLearningPayload.machineLearning.Jobs[0];
            }
            else {
                //machineLearningPayload.machineLearning.Jobs[2].custom_settings.custom_urls[0].url_name = titleFlow;
                machineLearningPayload.machineLearning.Jobs[3].custom_settings.custom_urls[0].url_value = service.splitDashboard(flowIframe, 'source');
                machineLearningPayload.machineLearning.Jobs[3].results_index_name = titleFlow;
                payload = machineLearningPayload.machineLearning.Jobs[3];
            }
            let reponse = await service.makeRequest('PUT',object, payload, null, auth);
            if(service.checkStatus(response)){
                if (reponse.body.job_id == titleLinuxLog) {
                    jobArr.push({ "LinuxLogs": reponse.body.job_id });
                }
                else if (reponse.body.job_id == titleWinLog) {
                    jobArr.push({ "WinLogs": reponse.body.job_id });
                }
                else if (reponse.body.job_id == titleScan) {
                    jobArr.push({ "Scan": reponse.body.job_id });
                }
                else {
                    jobArr.push({ "Flows": reponse.body.job_id });
                }
            }else{
                return service.errorHandler("Error in creating job");
            }
        }

        if(jobArr.length == 4){
           return service.createDataFeed(orgId);
        }else{
            return service.errorHandler("Error in creating job");
        }
    }
    async createDataFeed(orgId){
        var machineLearningPayload = JSON.parse(kibanaMachineLearningPayload);
        let service = this;
        let titleLinuxLog = "datafeed-caveolinuxlog-" + orgId;
        let titleWinLog = "datafeed-caveowinlog-" + orgId;
        let titleScan = "datafeed-caveoscan-" + orgId;
        let titleFlow = "datafeed-caveonetwork-" + orgId;

        let logIndex = "caveolog-" + orgId + "*";
        let scanIndex = "caveoscan-" + orgId + "*";
        let networkIndex = "caveonetwork-" + orgId + "*-flows*";

        let urlLinuxLogDataFeed = config.kibana_url + '/api/ml/datafeeds/' + titleLinuxLog;
        let urlWinLogDataFeed = config.kibana_url + '/api/ml/datafeeds/' + titleWinLog;
        let urlScanDataFeed = config.kibana_url + '/api/ml/datafeeds/' + titleScan;
        let urlFlowDataFeed = config.kibana_url + '/api/ml/datafeeds/' + titleFlow;

        let LinuxLogJob = "";
        let WinLogJob = "";
        let ScanJob = "";
        let FlowJob = "";
        jobArr.filter(function (object) {
            if (object.LinuxLogs) {
                LinuxLogJob = object.LinuxLogs;
            }
            else if (object.WinLogs) {
                WinLogJob = object.WinLogs;
            }
            else if (object.Scan) {
                ScanJob = object.Scan;
            }
            else {
                FlowJob = object.Flows;
            }
        });

        let urlArr = new Array();
        urlArr.push(urlLinuxLogDataFeed, urlWinLogDataFeed, urlScanDataFeed, urlFlowDataFeed);

        for(let u=0; u<urlArr.length; u++){
            let object = urlArr[u];
            let payload = "";
            if (object === urlLinuxLogDataFeed) {
                machineLearningPayload.machineLearning.Datafeed[0].job_id = LinuxLogJob;
                machineLearningPayload.machineLearning.Datafeed[0].indices[0] = logIndex;
                payload = machineLearningPayload.machineLearning.Datafeed[0];
            }
            else if (object === urlWinLogDataFeed) {
                machineLearningPayload.machineLearning.Datafeed[0].job_id = WinLogJob;
                machineLearningPayload.machineLearning.Datafeed[0].indices[0] = logIndex;
                payload = machineLearningPayload.machineLearning.Datafeed[0];
            }
            else if (object === urlScanDataFeed) {
                machineLearningPayload.machineLearning.Datafeed[0].job_id = ScanJob;
                machineLearningPayload.machineLearning.Datafeed[0].indices[0] = scanIndex;
                payload = machineLearningPayload.machineLearning.Datafeed[0];
            }
            else {
                machineLearningPayload.machineLearning.Datafeed[0].job_id = FlowJob;
                machineLearningPayload.machineLearning.Datafeed[0].indices[0] = networkIndex;
                payload = machineLearningPayload.machineLearning.Datafeed[0];
            }
            let reponse = await service.makeRequest('PUT',object, payload, null, auth);
            if(service.checkStatus(response)){
                if (reponse.body.datafeed_id == titleLinuxLog) {
                    dataFeedArr.push({ "LinuxLogDataFeed": reponse.body.datafeed_id });
                }
                else if (reponse.body.datafeed_id == titleWinLog) {
                    dataFeedArr.push({ "WinLogDataFeed": reponse.body.datafeed_id });
                }
                else if (reponse.body.datafeed_id == titleScan) {
                    dataFeedArr.push({ "ScanDataFeed": reponse.body.datafeed_id });
                }
                else {
                    dataFeedArr.push({ "FlowDataFeed": reponse.body.datafeed_id });
                }
            }else{
                return service.errorHandler("Error in creating datafeed");
            }
        }

        if(jobArr.length == 4){
            return service.openLogJobAndStartDataFeed(orgId);
        }else{
            return service.errorHandler("Error in creating datafeed");
        }
    }
    async openLinuxLogJobAndStartDataFeed(orgId){
        var machineLearningPayload = JSON.parse(kibanaMachineLearningPayload);
        let service = this;

        let LinuxLogJob = "";
        jobArr.filter(function (object) {
            if (object.LinuxLogs) {
                LinuxLogJob = object.LinuxLogs;
            }
        });

        let urlLinuxLogOpen = config.kibana_url + '/api/ml/anomaly_detectors/' + LinuxLogJob + '/_open';
        try{
            await rp.post({url:urlLinuxLogOpen, headers: { 'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Authorization': auth }, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true });
            let LinuxLogDataFeed = "";
            dataFeedArr.filter(function (object) {
                if (object.LinuxLogDataFeed) {
                    LinuxLogDataFeed = object.LinuxLogDataFeed;
                }
            });
            let urlLinuxLogStartDataFeed = config.kibana_url + '/api/ml/datafeeds/' + LinuxLogDataFeed + '/_start';
            let payload = machineLearningPayload.machineLearning.StartDataFeed[0];
            try{
                await rp.post({url:urlLinuxLogStartDataFeed, body: payload, headers: { 'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Authorization': auth }, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true });
                return service.openWinLogJobAndStartDataFeed(orgId);
            }catch(error){
                return service.errorHandler("Error in starting log datafeed");
            }
        }catch(error){
            return service.errorHandler("Error in opening log job");
        }
    }
    async openWinLogJobAndStartDataFeed(orgId){
        var machineLearningPayload = JSON.parse(kibanaMachineLearningPayload);
        let service = this;

        let WinLogJob = "";
        jobArr.filter(function (object) {
            if (object.WinLogJob) {
                WinLogJob = object.WinLogJob;
            }
        });

        let urlWinLogOpen = config.kibana_url + '/api/ml/anomaly_detectors/' + WinLogJob + '/_open';
        try{
            await rp.post({url:urlWinLogOpen, headers: { 'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Authorization': auth }, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true });
            let WinLogDataFeed = "";
            dataFeedArr.filter(function (object) {
                if (object.WinLogDataFeed) {
                    WinLogDataFeed = object.WinLogDataFeed;
                }
            });
            let urlWinLogStartDataFeed = config.kibana_url + '/api/ml/datafeeds/' + WinLogDataFeed + '/_start';
            let payload = machineLearningPayload.machineLearning.StartDataFeed[0];
            try{
                await rp.post({url:urlWinLogStartDataFeed, body: payload, headers: { 'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Authorization': auth }, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true });
                return service.openScanJobAndStartDataFeed(orgId);
            }catch(error){
                return service.errorHandler("Error in starting log datafeed");
            }
        }catch(error){
            return service.errorHandler("Error in opening log job");
        }
    }
    async openScanJobAndStartDataFeed(orgId){
        var machineLearningPayload = JSON.parse(kibanaMachineLearningPayload);
        let service = this;

        let ScanJob = "";
        jobArr.filter(function (object) {
            if (object.Scan) {
                ScanJob = object.Scan;
            }
        });

        let urlScanOpen = config.kibana_url + '/api/ml/anomaly_detectors/' + ScanJob + '/_open';
        try{
            await rp.post({url:urlScanOpen, headers: { 'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Authorization': auth }, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true });
            let ScanDataFeed = "";
            dataFeedArr.filter(function (object) {
                if (object.ScanDataFeed) {
                    ScanDataFeed = object.ScanDataFeed;
                }
            });

            let urlScanStartDataFeed = config.kibana_url + '/api/ml/datafeeds/' + ScanDataFeed + '/_start';

            let payload = machineLearningPayload.machineLearning.StartDataFeed[0];
            try{
                await rp.post({url:urlScanStartDataFeed, body: payload, headers: { 'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Authorization': auth }, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true });
                return service.openFlowJobAndStartDataFeed(orgId);
            }catch(error){
                return service.errorHandler("Error in starting scan datafeed");
            }
        }catch(error){
            return service.errorHandler("Error in opening scan job");
        }
    }
    async openFlowJobAndStartDataFeed(orgId){
        var machineLearningPayload = JSON.parse(kibanaMachineLearningPayload);
        let service = this;

        let FlowJob = "";
        jobArr.filter(function (object) {
            if (object.Flows) {
                FlowJob = object.Flows;
            }
        });

        let urlFlowOpen = config.kibana_url + '/api/ml/anomaly_detectors/' + FlowJob + '/_open';
        try{
            await rp.post({url:urlFlowOpen, headers: { 'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Authorization': auth }, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true });
            let FlowDataFeed = "";
            dataFeedArr.filter(function (object) {
                if (object.FlowDataFeed) {
                    FlowDataFeed = object.FlowDataFeed;
                }
            });

            let urlFlowStartDataFeed = config.kibana_url + '/api/ml/datafeeds/' + FlowDataFeed + '/_start';

            let payload = machineLearningPayload.machineLearning.StartDataFeed[0];
            try{
                await rp.post({url:urlFlowStartDataFeed, body: payload, headers: { 'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Authorization': auth }, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true });
                return service.createAnomalyExplorer(orgId, jobArr);
            }catch(error){
                return service.errorHandler("Error in starting network datafeed");
            }
        }catch(error){
            return service.errorHandler("Error in opening network job");
        }
    }
    async createAnomalyExplorer(orgId, jobArray){
        let LinuxLogJob = "";
        let WinLogJob = "";
        let ScanJob = "";
        let FlowJob = "";
        let index_pattern = 'machine_learning-' + orgId;
        let type = 'machine_learning'
        jobArray.filter(function (object) {
            if (object.LinuxLogs) {
                LinuxLogJob = object.LinuxLogs;
            }
            else if (object.WinLogs) {
                WinLogJob = object.WinLogs;
            }
            else if (object.Scan) {
                ScanJob = object.Scan;
            }
            else {
                FlowJob = object.Flows;
            }
        });

        let timeframe = "";
        if (config.Forensics_Timeframe) {
            timeframe = config.Forensics_Timeframe;
        } else {
            timeframe = '30d';
        }
        let anomalyUrl = '<iframe src="kibanaUrl/app/ml#/explorer?embed=true&_g=(ml:(jobIds:!(' + LinuxLogJob + ',' + WinLogJob + ',' + FlowJob + ',' + ScanJob + ')),refreshInterval:(' + "'$$hashKey'" + ':' + "'object:2595'" + ',display:Off,pause:!f,section:0,value:0),time:(from:now-' + timeframe + ',mode:quick,to:now))&_a=(filters:!(),mlCheckboxShowCharts:(showCharts:!t),mlExplorerSwimlane:(viewBy:' + "'job%20ID'" + '),mlSelectInterval:(interval:(display:Auto,val:auto)),mlSelectLimit:(limit:(display:' + "'10'" + ',val:10)),mlSelectSeverity:(threshold:(display:warning,val:0)))" height="600" width="800"></iframe>';

        await ForensicsDashboard.destroy({ where: { organization_id: orgId, type: 'machine_learning' } });
        await sequelize.query('insert into forensics_dashboard(index_pattern, organization_id, type, dashboard_url, widget, is_active, created_at) values ($1,$2,$3,$4,$5,$6, now())', {
                bind: [index_pattern, orgId, type, anomalyUrl, type, 'true']})
        jobArr.length = 0;
        dataFeedArr.length = 0;
        let result = await ForensicsDashboard.findAll({ where: { organization_id: orgId, type: 'machine_learning' }, include: [{ all: true }] });
        result.filter(object => {
            object.dashboard_url = object.dashboard_url.split('kibanaUrl').join(config.kibana_url);
        });
        return result;
    }
    async getLinuxLogJob(orgId, sid, data) {
        if(config.forensics_enabled  == true && config.ml_enabled == false){
            sid = '';
        }
        let service = this;
        let todayDate = new Date();
        let linuxLogJob = "caveolinuxlog-" + orgId;
        let dataFeedLinuxLog = "datafeed-caveolinuxlog-" + orgId;
        let getJobIdArr = new Array();

        let urlToGetLinuxLogJob = config.kibana_url + '/api/ml/anomaly_detectors/' + linuxLogJob;
        let urlToGetStateOfDataFeed = config.kibana_url + '/api/ml/datafeeds/' + dataFeedLinuxLog + '/_stats';

        let newPassword = await service.keyGenerator.decryptKeys(config.es_password);
        auth = "Basic " + new Buffer(config.es_username + ":" + newPassword).toString("base64");
        if(service.checkPreviledges(auth)) {
            let linuxLogData = await service.makeRequest('GET', urlToGetLinuxLogJob, null, sid, null);
            if(service.checkStatus(linuxLogData)){
                let dataFeedStatus = await service.makeRequest('GET', urlToGetStateOfDataFeed, null, sid, null);
                if(dataFeedStatus.body){
                    if (dataFeedStatus.body.datafeeds[0].state == 'started') {
                        let iframeUrlData = await ForensicsDashboard.findOne({ where: { organization_id: orgId, type: 'machine_learning' }, include: [{ all: true }] });
                        if (iframeUrlData) {
                            let createdDate = iframeUrlData.created_at;
                            if (todayDate > createdDate) {
                                return service.deleteAndCreateLinuxLogJob(orgId, linuxLogJob, auth, sid, data);
                            } else {
                                getJobIdArr.push({ "LinuxLogs": linuxLogJob });
                                return service.getWindowsLogJob(orgId, getJobIdArr, sid, data);
                            }
                        } else {
                            return service.deleteAndCreateLinuxLogJob(orgId, linuxLogJob, auth, sid, data);
                        }
                    }else{
                        return service.deleteAndCreateLinuxLogJob(orgId, linuxLogJob, auth, sid, data);
                    }
                }else{
                    return service.deleteAndCreateLinuxLogJob(orgId, linuxLogJob, auth, sid, data);
                }
            }else{
                await service.createSingleJob(orgId, linuxLogJob, data);
                getJobIdArr.push({ "LinuxLogs": linuxLogJob });
                return service.getWindowsLogJob(orgId, getJobIdArr, sid, data)
            }
        } else{
            return service.errorHandler("Error in changing index previledges.");
        }
    }
    async getWindowsLogJob(orgId, getJobIdArr, sid, data) {
        if(config.plugin.toLowerCase() == 'riskforesight'){
            sid = '';
        }
        let service = this;
        let todayDate = new Date();
        let winLogJob = "caveowinlog-" + orgId;
        let dataFeedWinLog = "datafeed-caveowinlog-" + orgId;

        let urlToGetWinLogJob = config.kibana_url + '/api/ml/anomaly_detectors/' + winLogJob;
        let urlToGetStateOfDataFeed = config.kibana_url + '/api/ml/datafeeds/' + dataFeedWinLog + '/_stats';

        let newPassword = await service.keyGenerator.decryptKeys(config.es_password);
        auth = "Basic " + new Buffer(config.es_username + ":" + newPassword).toString("base64");
        let winLogData = await service.makeRequest('GET', urlToGetWinLogJob, null, sid, null);
        if(service.checkStatus(winLogData)){
            let dataFeedStatus = await service.makeRequest('GET', urlToGetStateOfDataFeed, null, sid, null);
            if(dataFeedStatus.body){
                if (dataFeedStatus.body.datafeeds[0].state == 'started') {
                    let iframeUrlData = await ForensicsDashboard.findOne({ where: { organization_id: orgId, type: 'machine_learning' }, include: [{ all: true }] });
                    if (iframeUrlData) {
                        let createdDate = iframeUrlData.created_at;
                        if (todayDate > createdDate) {
                            return service.deleteAndCreateWinLogJob(orgId, winLogJob, auth, sid, data, getJobIdArr);
                        } else {
                            getJobIdArr.push({ "WinLogs": winLogJob });
                            return service.getScanJob(orgId, getJobIdArr, sid, data);
                        }
                    } else {
                        return service.deleteAndCreateWinLogJob(orgId, winLogJob, auth, sid, data, getJobIdArr);
                    }
                }else{
                    return service.deleteAndCreateWinLogJob(orgId, winLogJob, auth, sid, data, getJobIdArr);
                }
            }else{
                return service.deleteAndCreateWinLogJob(orgId, winLogJob, auth, sid, data, getJobIdArr);
            }
        }else{
            await service.createSingleJob(orgId, winLogJob, data);
            getJobIdArr.push({ "WinLogs": winLogJob });
            return service.getScanJob(orgId, getJobIdArr, sid, data)
        }
    }
    async getScanJob(orgId, arr, sid, data) {
        let service = this;
        let todayDate = new Date();
        let scanJob = "caveoscan-" + orgId;
        let dataFeedScan = "datafeed-caveoscan-" + orgId;

        let urlToGetScanJob = config.kibana_url + '/api/ml/anomaly_detectors/' + scanJob;
        let urlToGetStateOfDataFeed = config.kibana_url + '/api/ml/datafeeds/' + dataFeedScan + '/_stats';

        let scanData = await service.makeRequest('GET', urlToGetScanJob, null, sid, null);
        if(service.checkStatus(scanData)){
            let dataFeedStatus = await service.makeRequest('GET', urlToGetStateOfDataFeed, null, sid, null);
            if(service.checkStatus(dataFeedStatus)){
                if (dataFeedStatus.body.datafeeds[0].state == 'started') {
                    let iframeUrlData = await ForensicsDashboard.findOne({ where: { organization_id: orgId, type: 'machine_learning' }, include: [{ all: true }] });
                    if (iframeUrlData) {
                        let createdDate = iframeUrlData.created_at;
                        if (todayDate > createdDate) {
                            return service.deleteAndCreateCombinedScanJob(orgId, scanJob, auth, sid, data, arr);
                        } else {
                            arr.push({ "Scan": scanJob });
                            return service.getFlowJob(orgId, arr, sid, data);
                        }
                    } else {
                        return service.deleteAndCreateCombinedScanJob(orgId, scanJob, auth, sid, data, arr);
                    }
                }else{
                    return service.deleteAndCreateCombinedScanJob(orgId, scanJob, auth, sid, data, arr);
                }
            }else{
                return service.deleteAndCreateCombinedScanJob(orgId, scanJob, auth, sid, data, arr);
            }
        }else{
            await service.createSingleJob(orgId, scanJob, data);
            arr.push({ "Scan": scanJob });
            return service.getFlowJob(orgId, arr, sid, data);
        }
    }
    async getFlowJob(orgId, newArr, sid, data) {
        let service = this;
        let todayDate = new Date();
        let flowJob = "caveonetwork-" + orgId;
        let dataFeedFlow = "datafeed-caveonetwork-" + orgId;

        let urlToGetFlowJob = config.kibana_url + '/api/ml/anomaly_detectors/' + flowJob;
        let urlToGetStateOfDataFeed = config.kibana_url + '/api/ml/datafeeds/' + dataFeedFlow + '/_stats';

        let flowData = await service.makeRequest('GET', urlToGetFlowJob, null, sid, null);
        if(service.checkStatus(flowData)){
            let dataFeedStatus = await service.makeRequest('GET', urlToGetStateOfDataFeed, null, sid, null);
            if(service.checkStatus(dataFeedStatus)){
                if (dataFeedStatus.body.datafeeds[0].state == 'started') {
                    let iframeUrlData = await ForensicsDashboard.findOne({ where: { organization_id: orgId, type: 'machine_learning' }, include: [{ all: true }] });
                    if (iframeUrlData) {
                        let createdDate = iframeUrlData.created_at;
                        if (todayDate > createdDate) {
                            return service.deleteAndCreateCombinedFlowJob(orgId, flowJob, auth, data, newArr);
                        } else {
                            newArr.push({ "Flows": flowJob });
                            if (newArr.length == 4) {
                                newArr.length = 0;
                                let result = await ForensicsDashboard.findAll({ where: { organization_id: orgId, type: 'machine_learning' }, include: [{ all: true }] });
                                if (result.length != 0) {
                                    result.filter(object => {
                                        object.dashboard_url = object.dashboard_url.split('kibanaUrl').join(config.kibana_url);
                                    });
                                    return result;
                                } else {
                                    let titleLinuxLog = "caveolinuxlog-" + orgId;
                                    let titleWinLog = "caveowinlog-" + orgId;
                                    let titleScan = "caveoscan-" + orgId;
                                    let titleFlow = "caveonetwork-" + orgId;

                                    let jobArray = [{ "LinuxLogs": titleLinuxLog }, { "WinLogs": titleWinLog }, { "Scan": titleScan }, { "Flows": titleFlow }];

                                    return service.createAnomalyExplorer(orgId, jobArray);
                                }
                            }
                        }
                    }else{
                        return service.deleteAndCreateCombinedFlowJob(orgId, flowJob, auth, data, newArr);
                    }
                }else{
                    return service.deleteAndCreateCombinedFlowJob(orgId, flowJob, auth, data, newArr);
                }
            }else{
                return service.deleteAndCreateCombinedFlowJob(orgId, flowJob, auth, data, newArr);
            }
        }else{
            await service.createSingleJob(orgId, flowJob, data);
            newArr.push({ "Flows": flowJob });
            if (newArr.length == 4) {
                newArr.length = 0;
                let titleLinuxLog = "caveolinuxlog-" + orgId;
                let titleWinLog = "caveowinlog-" + orgId;
                let titleScan = "caveoscan-" + orgId;
                let titleFlow = "caveonetwork-" + orgId;

                let jobArray = [{ "LinuxLogs": titleLinuxLog }, { "WinLogs": titleWinLog }, { "Scan": titleScan }, { "Flows": titleFlow }];

                return service.createAnomalyExplorer(orgId, jobArray);
            }
        }
    }
    async makeRequest(method, url, payload, sid, auth) {
        let headers;
        if (sid) {
            headers = { 'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Cookie': sid};
        } else {
            headers = { 'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Authorization': auth};
        }
        try{
            let response = await rp({ method: method, url: url, body: payload, headers: headers, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true });
            return response;
        }catch(error){
            return error;
        }
    }
    async createSingleJob(orgId, job_id, data) {
        let service = this;
        let machineLearningPayload = JSON.parse(kibanaMachineLearningPayload);
        let titleLinuxLog = "caveolinuxlog-" + orgId;
        let titleWinLog = "caveowinlog-" + orgId;
        let titleScan = "caveoscan-" + orgId;
        let titleFlow = "caveonetwork-" + orgId;

        let dataFeedFlowIndex = "caveonetwork-" + orgId + "*-flows*";
        let dataFeedLogIndex = "caveolog-" + orgId + "*";

        let logIframe = "";
        let scanIframe = "";
        let flowIframe = "";

        data.forEach(object => {
            if (object.type == 'logs') {
                logIframe = object.dashboard_url;
            }
            if (object.type == 'scan') {
                scanIframe = object.dashboard_url;
            }
            if (object.type == 'flows') {
                flowIframe = object.dashboard_url;
            }
        })

        //let jobs = [];
        //jobs.push({ 'LinuxLogs': titleLinuxLog }, { 'WinLogs': titleWinLog }, { 'Scan': titleScan }, { 'Flows': titleFlow });

        var jobPayload = '';
        let dataFeedPayload = machineLearningPayload.machineLearning.Datafeed[0];
        let startDataFeedPayload = machineLearningPayload.machineLearning.StartDataFeed[0];

        let urlToCreateJob = config.kibana_url + '/api/ml/anomaly_detectors/' + job_id;
        let urlToCreateDataFeed = config.kibana_url + '/api/ml/datafeeds/datafeed-' + job_id;
        let urlToOpenJob = config.kibana_url + '/api/ml/anomaly_detectors/' + job_id + '/_open';
        let urlToStartDataFeed = config.kibana_url + '/api/ml/datafeeds/datafeed-' + job_id + '/_start';

        if (job_id == titleLinuxLog) {
            //machineLearningPayload.machineLearning.Jobs[1].custom_settings.custom_urls[0].url_name = titleLog;
            machineLearningPayload.machineLearning.Jobs[1].custom_settings.custom_urls[0].url_value = service.splitDashboard(logIframe, 'hostName.keyword');
            machineLearningPayload.machineLearning.Jobs[1].results_index_name = titleLinuxLog;
            jobPayload = machineLearningPayload.machineLearning.Jobs[1];

            dataFeedPayload.job_id = job_id;
            dataFeedPayload.indices[0] = dataFeedLogIndex;
        }
        if (job_id == titleWinLog) {
            //machineLearningPayload.machineLearning.Jobs[1].custom_settings.custom_urls[0].url_name = titleLog;
            machineLearningPayload.machineLearning.Jobs[2].custom_settings.custom_urls[0].url_value = service.splitDashboard(logIframe, 'MachineName.keyword');
            machineLearningPayload.machineLearning.Jobs[2].results_index_name = titleWinLog;
            jobPayload = machineLearningPayload.machineLearning.Jobs[2];

            dataFeedPayload.job_id = job_id;
            dataFeedPayload.indices[0] = dataFeedLogIndex;
        }
        if (job_id == titleScan) {
            //machineLearningPayload.machineLearning.Jobs[0].custom_settings.custom_urls[0].url_name = titleScan;
            machineLearningPayload.machineLearning.Jobs[0].custom_settings.custom_urls[0].url_value = service.splitDashboard(scanIframe, 'asset_name.keyword');
            machineLearningPayload.machineLearning.Jobs[0].results_index_name = titleScan;
            jobPayload = machineLearningPayload.machineLearning.Jobs[0];

            dataFeedPayload.job_id = job_id;
            dataFeedPayload.indices[0] = job_id + "*";
        }
        if (job_id == titleFlow) {
            //machineLearningPayload.machineLearning.Jobs[3].custom_settings.custom_urls[0].url_name = titleFlow;
            machineLearningPayload.machineLearning.Jobs[3].custom_settings.custom_urls[0].url_value = service.splitDashboard(flowIframe, 'source');
            machineLearningPayload.machineLearning.Jobs[3].results_index_name = titleFlow;
            jobPayload = machineLearningPayload.machineLearning.Jobs[3];

            dataFeedPayload.job_id = job_id;
            dataFeedPayload.indices[0] = dataFeedFlowIndex;
        }

        let newPassword = await service.keyGenerator.decryptKeys(config.es_password);
        let auth = "Basic " + new Buffer(config.es_username + ":" + newPassword).toString("base64");
        let jobData = await service.makeRequest('PUT', urlToCreateJob, jobPayload, null, auth);
        if(service.checkStatus(jobData)){
            let dataFeedData = await service.makeRequest('PUT', urlToCreateDataFeed, dataFeedPayload, null, auth);
            if(service.checkStatus(dataFeedData)){
                let openData = await service.makeRequest('POST', urlToOpenJob, "", null, auth);
                if(service.checkStatus(openData)){
                    let startData = await service.makeRequest('POST', urlToStartDataFeed, startDataFeedPayload, null, auth);
                    if(service.checkStatus(startData)){
                        return jobData;
                    }else{
                        if (startData.message.includes('cannot retrieve field') && startData.message.indexOf('cannot retrieve field [collectionTime]') == -1) {
                            let message = startData.message.split('cannot retrieve field');
                            let field = message[1].match(/\[([^)]+)\]/)[1];
                            let deletedJob = await service.deleteSingleJob(job_id, auth);
                            if(service.checkStatus(deletedJob)){
                                let newJobCreated = await service.createJobByRemovingField(orgId, job_id, jobPayload, dataFeedPayload, startDataFeedPayload, field);
                                if(service.checkStatus(newJobCreated)){
                                    return newJobCreated;
                                }else{
                                    return service.errorHandler("Error in recreation of job");
                                }
                            }else{
                                return service.errorHandler("Error in deletion of job");
                            }
                        } else {
                            return service.errorHandler("Error in starting datafeed");
                        }
                    }
                }else{
                    return service.errorHandler("Error in opening job");
                }
            }else{
                return service.errorHandler("Error in creation of datafeed");
            }
        }else{
            return service.errorHandler("Error in creation of job");
        }
    }
    splitDashboard(iframeUrl, keyword) {
        if (keyword == 'hostName.keyword') {
            iframeUrl = iframeUrl.split('app/');
            iframeUrl = iframeUrl[1].split('"');
            iframeUrl = iframeUrl[0].split("language:lucene,query:''").join("language:lucene,query:'hostName.keyword:\"$hostName.keyword$\"'");
            return iframeUrl;
        }
        if (keyword == 'MachineName.keyword') {
            iframeUrl = iframeUrl.split('app/');
            iframeUrl = iframeUrl[1].split('"');
            iframeUrl = iframeUrl[0].split("language:lucene,query:''").join("language:lucene,query:'MachineName.keyword:\"$MachineName.keyword$\"'");
            return iframeUrl;
        }
        if (keyword == 'asset_name.keyword') {
            iframeUrl = iframeUrl.split('app/');
            iframeUrl = iframeUrl[1].split('"');
            iframeUrl = iframeUrl[0].split("language:lucene,query:''").join("language:lucene,query:'asset_name.keyword:\"$asset_name.keyword$\"'");
            return iframeUrl;
        }
        if (keyword == 'source') {
            iframeUrl = iframeUrl.split('app/');
            iframeUrl = iframeUrl[1].split('"');
            iframeUrl = iframeUrl[0].split("language:lucene,query:''").join("language:lucene,query:'source:\"$source$\"'");
            return iframeUrl;
        }
    }
    async updateJob(orgId, auth, data) {
        var machineLearningPayload = JSON.parse(kibanaMachineLearningPayload);
        let jobArr1 = [];
        let service = this;
        let titleLinuxLog = "caveolinuxlog-" + orgId;
        let titleWinLog = "caveowinlog-" + orgId;
        let titleScan = "caveoscan-" + orgId;
        let titleFlow = "caveonetwork-" + orgId;

        let logIframe = "";
        let scanIframe = "";
        let flowIframe = "";

        data.forEach(object => {
            if (object.type == 'logs') {
                logIframe = object.dashboard_url;
            }
            else if (object.type == 'scan') {
                scanIframe = object.dashboard_url;
            }
            else if (object.type == 'flows') {
                flowIframe = object.dashboard_url;
            }
        })

        let urlLinuxLog = config.kibana_url + '/api/ml/anomaly_detectors/' + titleLinuxLog + '/_update';
        let urlWinLog = config.kibana_url + '/api/ml/anomaly_detectors/' + titleWinLog + '/_update';
        let urlScan = config.kibana_url + '/api/ml/anomaly_detectors/' + titleScan + '/_update';
        let urlFlow = config.kibana_url + '/api/ml/anomaly_detectors/' + titleFlow + '/_update';

        let urlArr = new Array();
        urlArr.push(urlLinuxLog, urlWinLog, urlScan, urlFlow);

        for(let u=0; u<urlArr.length; u++){
            let object = urlArr[u];
            let payload = "";
            if (object === urlLinuxLog) {
                //machineLearningPayload.machineLearning.UpdateJob[0].custom_settings.custom_urls[0].url_name = titleLog;
                machineLearningPayload.machineLearning.UpdateJob[0].custom_settings.custom_urls[0].url_value = service.splitDashboard(logIframe, 'hostName.keyword');
                payload = machineLearningPayload.machineLearning.UpdateJob[0];
            }
            else if (object === urlWinLog) {
                //machineLearningPayload.machineLearning.UpdateJob[0].custom_settings.custom_urls[0].url_name = titleLog;
                machineLearningPayload.machineLearning.UpdateJob[0].custom_settings.custom_urls[0].url_value = service.splitDashboard(logIframe, 'MachineName.keyword');
                payload = machineLearningPayload.machineLearning.UpdateJob[0];
            }
            else if (object === urlScan) {
                //machineLearningPayload.machineLearning.UpdateJob[0].custom_settings.custom_urls[0].url_name = titleScan;
                machineLearningPayload.machineLearning.UpdateJob[0].custom_settings.custom_urls[0].url_value = service.splitDashboard(scanIframe, 'asset_name.keyword');
                payload = machineLearningPayload.machineLearning.UpdateJob[0];
            }
            else {
                //machineLearningPayload.machineLearning.UpdateJob[0].custom_settings.custom_urls[0].url_name = titleFlow;
                machineLearningPayload.machineLearning.UpdateJob[0].custom_settings.custom_urls[0].url_value = service.splitDashboard(flowIframe, 'source');
                payload = machineLearningPayload.machineLearning.UpdateJob[0];
            }

            let response = await service.makeRequest('POST',object, payload, null, auth);
            if(service.checkStatus(response)){
                if (response.body.job_id == titleLinuxLog) {
                    jobArr1.push({ "LinuxLogs": response.body.job_id });
                }
                else if (response.body.job_id == titleWinLog) {
                    jobArr1.push({ "WinLogs": response.body.job_id });
                }
                else if (response.body.job_id == titleScan) {
                    jobArr1.push({ "Scan": response.body.job_id });
                }
                else {
                    jobArr1.push({ "Flows": response.body.job_id });
                }
            }else{
                return service.errorHandler("Error in updating job");
            }
        }
        if(jobArr1.length == 4){
            return "Successfully updated!!!";
        }else{
            return service.errorHandler("Error in updating job");
        }
    }
    async deleteDataFeed(orgId, sid, auth, data) {
        let service = this;
        let titleLinuxLog = "datafeed-caveolinuxlog-" + orgId;
        let titleWinLog = "datafeed-caveowinlog-" + orgId;
        let titleScan = "datafeed-caveoscan-" + orgId;
        let titleFlow = "datafeed-caveonetwork-" + orgId;

        let urlLinuxLogDataFeedDelete = config.kibana_url + '/api/ml/datafeeds/' + titleLinuxLog + '?force=true';
        let urlWinLogDataFeedDelete = config.kibana_url + '/api/ml/datafeeds/' + titleWinLog + '?force=true';
        let urlScanDataFeedDelete = config.kibana_url + '/api/ml/datafeeds/' + titleScan + '?force=true';
        let urlFlowDataFeedDelete = config.kibana_url + '/api/ml/datafeeds/' + titleFlow + '?force=true';

        let urlArr = new Array();
        urlArr.push(urlLinuxLogDataFeedDelete, urlWinLogDataFeedDelete, urlScanDataFeedDelete, urlFlowDataFeedDelete);

        for(let u=0; u<urlArr.length; u++){
            let object = urlArr[u];
            try{
                await rp.delete({url:object, headers: { 'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Authorization': auth }, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true });
            }catch(err){
                return service.errorHandler("Error in deleting datafeed");
            }
        }
        return service.deleteJob(orgId, sid, auth, data);
    }
    async deleteJob(orgId, sid, auth, data) {
        let service = this;
        let titleLinuxLog = "caveolinuxlog-" + orgId;
        let titleWinLog = "caveowinlog-" + orgId;
        let titleScan = "caveoscan-" + orgId;
        let titleFlow = "caveonetwork-" + orgId;

        let urlLinuxLogDelete = config.kibana_url + '/api/ml/anomaly_detectors/' + titleLinuxLog + '?force=true';
        let urlWinLogDelete = config.kibana_url + '/api/ml/anomaly_detectors/' + titleWinLog + '?force=true';
        let urlScanDelete = config.kibana_url + '/api/ml/anomaly_detectors/' + titleScan + '?force=true';
        let urlFlowDelete = config.kibana_url + '/api/ml/anomaly_detectors/' + titleFlow + '?force=true';

        let urlArr = new Array();
        urlArr.push(urlLinuxLogDelete, urlWinLogDelete, urlScanDelete, urlFlowDelete);

        for(let u=0; u<urlArr.length; u++){
            let object = urlArr[u];
            try{
                await rp.delete({url:object, headers: { 'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Authorization': auth }, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true });
            }catch(err){
                return service.errorHandler("Error in deleting job");
            }
        }
        return service.getLinuxLogJob(orgId, sid, data);
    }

    async createJobByRemovingField(orgId, jobName, jobPayload, dataFeedPayload, startDataFeedPayload, fieldToRemove) {
        let service = this;

        let urlToCreateJob = config.kibana_url + '/api/ml/anomaly_detectors/' + jobName;
        let urlToCreateDataFeed = config.kibana_url + '/api/ml/datafeeds/datafeed-' + jobName;
        let urlToOpenJob = config.kibana_url + '/api/ml/anomaly_detectors/' + jobName + '/_open';
        let urlToStartDataFeed = config.kibana_url + '/api/ml/datafeeds/datafeed-' + jobName + '/_start';

        let ctr = 0;
        let incre = 0;
        let newDetectorArr = new Array();
        let newInfluencerArr = new Array();
        let detectors = jobPayload.analysis_config.detectors;
        detectors.filter(object => {
            if (object.partition_field_name != fieldToRemove && object.by_field_name != fieldToRemove) {
                if (object.field_name != fieldToRemove) {
                    newDetectorArr.push(object);
                }
            }
            ctr++;
            if (ctr == jobPayload.analysis_config.detectors.length) {
                let influencers = jobPayload.analysis_config.influencers;
                influencers.filter(object => {
                    if (object != fieldToRemove) {
                        newInfluencerArr.push(object);
                    }
                    incre++;
                    if (incre == jobPayload.analysis_config.influencers.length) {
                        jobPayload.analysis_config.detectors = newDetectorArr;
                        jobPayload.analysis_config.influencers = newInfluencerArr;
                    }
                });
            }
        });
        let newJobPayload = jobPayload;
        let newPassword = await service.keyGenerator.decryptKeys(config.es_password);
        auth = "Basic " + new Buffer(config.es_username + ":" + newPassword).toString("base64");
        let jobData = await service.makeRequest('PUT', urlToCreateJob, newJobPayload, null, auth);
        if(service.checkStatus(jobData)){
            let dataFeedData = await service.makeRequest('PUT', urlToCreateDataFeed, dataFeedPayload, null, auth);
            if(service.checkStatus(dataFeedData)){
                let openData = await service.makeRequest('POST', urlToOpenJob, "", null, auth);
                if(service.checkStatus(openData)){
                    let startData = await service.makeRequest('POST', urlToStartDataFeed, startDataFeedPayload, null, auth);
                    if(service.checkStatus(startData)){
                        return jobData;
                    }else{
                        if (startData.message.includes('cannot retrieve field') && startData.message.indexOf('cannot retrieve field [collectionTime]') == -1) {
                            let message = startData.message.split('cannot retrieve field');
                            let field = message[1].match(/\[([^)]+)\]/)[1];
                            let deletedJob = await service.deleteSingleJob(jobName, auth);
                            if(service.checkStatus(deletedJob)){
                                let newJobCreated = await service.createJobByRemovingField(orgId, jobName, newJobPayload, dataFeedPayload, startDataFeedPayload, field);
                                if(service.checkStatus(newJobCreated)){
                                    return newJobCreated;
                                }else{
                                    return service.errorHandler("Error in recreation of job");
                                }
                            }else{
                                return service.errorHandler("Error in deletion of job");
                            }
                        }else{
                            return service.errorHandler("Error in starting datafeed");
                        }
                    }
                }else{
                    return service.errorHandler("Error in opening job");
                }
            }else{
                return service.errorHandler("Error in creation of datafeed");
            }
        }else{
            return service.errorHandler("Error in creation of job");
        }
    }

    async deleteSingleJob(jobName, auth) {
        let service = this;
        let dataFeedName = "datafeed-" + jobName;

        let urlDataFeedDelete = config.kibana_url + '/api/ml/datafeeds/' + dataFeedName + '?force=true';
        let urlToDeleteJob = config.kibana_url + '/api/ml/anomaly_detectors/' + jobName + '?force=true';

        let datafeed = await service.makeRequest('DELETE', urlDataFeedDelete, null, null, auth);
        if (service.checkStatus(datafeed)) {
            let job = await service.makeRequest('DELETE', urlToDeleteJob, null, null, auth);
            if (service.checkStatus(job)) {
                return job;
            } else {
                return service.errorHandler("Error in deletion of job");
            }
        } else {
            if(datafeed.message.includes('[FORBIDDEN/12/index read-only / allow delete (api)]')){
                return service.changeIndicesPreviledges(jobName, auth);
            }
            if(datafeed.statusCode == 404){
                let job = await service.makeRequest('DELETE', urlToDeleteJob, null, null, auth);
                if (service.checkStatus(job)) {
                    return job;
                } else {
                    return service.errorHandler("Error in deletion of job");
                }
            }
            return service.errorHandler("Error in deletion of datafeed");
        }
    }

    async deleteAndCreateLinuxLogJob(orgId, linuxLogJob, auth, sid, data){
        let service = this;
        let getJobIdArr = new Array();
        let deletedJob = await service.deleteSingleJob(linuxLogJob, auth);
        if(service.checkStatus(deletedJob)){
            await service.createSingleJob(orgId, linuxLogJob, data)
            getJobIdArr.push({ "LinuxLogs": linuxLogJob });
            return service.getWindowsLogJob(orgId, getJobIdArr, sid, data);
        }else{
            getJobIdArr.push({ "LinuxLogs": linuxLogJob });
            return service.getWindowsLogJob(orgId, getJobIdArr, sid, data);
        }
    }

    async deleteAndCreateWinLogJob(orgId, winLogJob, auth, sid, data, getJobIdArr){
        let service = this;
        let deletedJob = await service.deleteSingleJob(winLogJob, auth);
        if(service.checkStatus(deletedJob)){
            await service.createSingleJob(orgId, winLogJob, data)
            getJobIdArr.push({ "WinLogs": winLogJob });
            return service.getScanJob(orgId, getJobIdArr, sid, data);
        }else{
            getJobIdArr.push({ "WinLogs": winLogJob });
            return service.getScanJob(orgId, getJobIdArr, sid, data);
        }
    }

    async deleteAndCreateCombinedScanJob(orgId, scanJob, auth, sid, data, getJobIdArr){
        let service = this;
        let deletedJob = await service.deleteSingleJob(scanJob, auth);
        if(service.checkStatus(deletedJob)){
            await service.createSingleJob(orgId, scanJob, data);
            getJobIdArr.push({ "Scan": scanJob });
            return service.getFlowJob(orgId, getJobIdArr, sid, data);
        }else{
            getJobIdArr.push({ "Scan": scanJob });
            return service.getFlowJob(orgId, getJobIdArr, sid, data);
        }
    }

    async deleteAndCreateCombinedFlowJob(orgId, flowJob, auth, data, getJobIdArr){
        let service = this;
        let deletedJob = await service.deleteSingleJob(flowJob, auth);
        if(service.checkStatus(deletedJob)){
            await service.createSingleJob(orgId, flowJob, data);
            getJobIdArr.push({ "Flows": flowJob });
            if (getJobIdArr.length == 4) {
                getJobIdArr.length = 0;
                let titleLinuxLog = "caveolinuxlog-" + orgId;
                let titleWinLog = "caveowinlog-" + orgId;
                let titleScan = "caveoscan-" + orgId;
                let titleFlow = "caveonetwork-" + orgId;

                let jobArray = [{ "LinuxLogs": titleLinuxLog }, { "WinLogs": titleWinLog }, { "Scan": titleScan }, { "Flows": titleFlow }];

                return service.createAnomalyExplorer(orgId, jobArray);
            }
        }else{
            getJobIdArr.push({ "Flows": flowJob });
            if (getJobIdArr.length == 4) {
                getJobIdArr.length = 0;
                let titleLinuxLog = "caveolinuxlog-" + orgId;
                let titleWinLog = "caveowinlog-" + orgId;
                let titleScan = "caveoscan-" + orgId;
                let titleFlow = "caveonetwork-" + orgId;

                let jobArray = [{ "LinuxLogs": titleLinuxLog }, { "WinLogs": titleWinLog }, { "Scan": titleScan }, { "Flows": titleFlow }];

                return service.createAnomalyExplorer(orgId, jobArray);
            }
        }
    }

    checkStatus(response){
        if(response && (response.statusCode == 200 || response.statusCode == 202 || response.statusCode == 204)){
            return true;
        }else{
            return false;
        }
    }

    async checkPreviledges(auth){
        let urlToGetIndexSettings =  config.es_url + '/_all/_settings/index.blocks*';   
        let allowDelete;     
        try{
            let getResponse = await rp.get(urlToGetIndexSettings, {headers: {'Authorization': auth}, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true, json: true});
            for(let key in getResponse.body){
                let singleObject = getResponse.body[key];
                allowDelete = singleObject.settings.index.blocks.read_only_allow_delete;
                break;
            }
            if(allowDelete == "true" || allowDelete == true){
                let url = config.es_url + '/*/_settings';
                let body = { "index": { "blocks": { "read_only_allow_delete": "false" } } };
                let response = await rp.put(url, {body: body, headers: {'Authorization': auth}, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true, json: true});
                return true;
            } else{
                return true;
            }
        } catch(error){
            return false;
        }
    }

    errorHandler(message){
        let err = new Error(message);
        err.status = 400;
        return err;
    }

    async changeIndicesPreviledges(jobName, auth) {
        let service = this;
        let url = config.es_url + '/*/_settings';
        let body = { "index": { "blocks": { "read_only_allow_delete": "false" } } };
        try{
            await rp.put(url, {body: body, headers: {'Authorization': auth}, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true, json: true});
            return service.deleteSingleJob(jobName, auth);
        } catch(error){
            return service.errorHandler("Error in changing ml index previledges.");
        }
    }
};
