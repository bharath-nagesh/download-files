const db = require('../models');
const Location = require('../apis/location/location.model');
const PrivacyClassification = require('../models/privacyClassification.model');
const sequelize = require('../../../config/db.conf').getConnection();
const logger = require('./../../utils/logger').logger.child({
  sub_name: 'IdentityService-privacyClassification.service'

});
module.exports = class Service {
  constructor(services) {
    this.services = services;
    logger.debug('called constructor');
  }

  getPrivacyClassification(privacyClassificationId, opts) {
    return PrivacyClassification.findByPk(privacyClassificationId);
  }

  getAllPrivacyClassifications(limit, offset) {
    return PrivacyClassification.findAll({ order: [['id', 'ASC']], limit: limit, offset: offset });
  }

  getAllPrivacyClassificationsCount() {
    return PrivacyClassification.count();
  }

  async createPrivacyClassification(params) {
    const name = params.name;
    const exists = await this.checkName(name);
    if (exists) {
      const err = new Error('Duplicate PrivacyClassification name.');
      err.status = 400;
      throw err;
    }
    return PrivacyClassification.create(params);
  }

  async updatePrivacyClassification(privacyClassificationId, params) {
    const name = params.name;
    const exists = await this.checkNameForUpdate(privacyClassificationId, name);
    if (exists) {
      const err = new Error('Duplicate PrivacyClassification name.');
      err.status = 400;
      throw err;
    }
    const privacyClassification = await this.getPrivacyClassification(privacyClassificationId);
    return privacyClassification.update(params);
  }

  checkName(name) {
    return PrivacyClassification.findOne({
      where: {
        name: sequelize.where(sequelize.fn('LOWER', sequelize.col('name')), sequelize.fn('lower', name)),
        $or: [{ isActive: { $ne: 'false' } }]
      }
    });
  }

  checkNameForUpdate(privacyClassificationId, name) {
    return Location.findOne({
      where: {
        name: sequelize.where(sequelize.fn('LOWER', sequelize.col('name')), sequelize.fn('lower', name)),
        $or: [{ isActive: { $ne: 'false' } }],
        id: { $ne: privacyClassificationId }
      }
    });
  }

  deleteById(privacyClassificationId) {
    return PrivacyClassification.update({ isActive: false }, { where: { id: privacyClassificationId } });
  }
};
