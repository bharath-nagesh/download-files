const rp = require('request-promise');
const sequelize = require('../../config/db.conf').getConnection();
const CentralCollectorClient = require('../../utils/centralCollector.client');
const { QueryTypes } = require('sequelize');
const config = require('../../configure').get();
const where = require('../definitions/common');
const organizationBillingDetails = require('../apis/organization/organizationBillingDetails.model');
const saasorganizationBillingDetails = require('../apis/organization/saasOrganizationBillingDetails.model');
const Organization = require('../apis/organization/organization.model');
const whereCondition = require('../../utils/whereParser.js');
const logger = require('./../../utils/logger').logger.child({
  sub_name: 'IdentityService-reference.service'
});
const _ = require('lodash-joins');

module.exports = class BillingService {
  constructor() {
    logger.debug('called BillingService constructor');
  }

  async getBillingForMonth(orgId) {
    try {
      if (config.saas) {
        const billingInfo = await sequelize.query(
          `select organization_id as organizationId, name, alias_name as aliasName, certificate_name as certificateName, tier_minimum as tierMinimum, consumption_count as consumptionCount, 
          CASE WHEN consumption_count > tier_minimum THEN (consumption_count - tier_minimum) ELSE tier_minimum END as reportedCount,
          billing_date as billingDate, license_type as licenseType, start_date as startDate, end_date as endDate, product_name as productName
          from (select ol.organization_id, o.name, o.alias_name, string_agg(c.name, ',') as certificate_name,
          (sp.asset_count_included*ol.license_count) as tier_minimum, sum(sobd.asset_cnt) as consumption_count, sobd.created_at::date as billing_date,
          ol.license_type, ol.license_count, ol.start_date, ol.end_date, sp.product_name
          from org_license ol 
          join organizations o on o.id = ol.organization_id 
          join org_certificate_members ocm on ocm.organization_id = o.id
          join certificates c on c.id = ocm.certificate_id
          join saas_organization_billing_details sobd on sobd.organization_id = o.id
          join saas_products sp on sp.product_code = ol.license_code
          where ol.organization_id in ( select reporting_org_chain_list(:orgId))
          group by ol.organization_id, ol.license_type, ol.license_count, ol.start_date, ol.end_date,
          o.name, o.alias_name, sobd.created_at, sp.asset_count_included, sp.product_name) billing`,
          { replacements: { orgId }, type: QueryTypes.SELECT });
        return { billingInfo };
      } else {
        const [licenseInfo, assetConsumption, topTenants] = await Promise.all([CentralCollectorClient.getLicenseInfo(), this.getAssetConsumption(), this.getTopTenantsByAssetCount()]);

        const billingInfo = assetConsumption.map((d) => {
          const topTenantForMonth = topTenants.filter((tenant) => {
            return tenant.month === d.month;
          });
          const consumptionCount = topTenantForMonth.reduce((total, obj) => {
            return total + parseInt(obj.avg_asset_count);
          }, 0);
          const min = consumptionCount > parseInt(licenseInfo.minimum) ? consumptionCount : licenseInfo.minimum;
          return {
            billingCount: min,
            consumptionCount,
            tierMinimum: licenseInfo.minimum,
            tierType: licenseInfo['tier-type'],
            licenseType: licenseInfo.type,
            date: d.month,
            topTenants: topTenantForMonth,
            tenantCount: topTenantForMonth.length

          };
        }).sort((a, b) => {
          return new Date(a.month) > new Date(b.month);
        });

        return { licenseInfo, billingInfo };
      }
    } catch (e) {
      logger.error({ e, stack: e.stack }, 'error occurred getting Billing info');
      throw e;
    }
  }

  async getBillingForOrg(orgId, startDate, endDate, hourly = false) {
    if (hourly == 'false') hourly = false;
    try {
      const [licenseInfo, assetConsumption] = await Promise.all([CentralCollectorClient.getLicenseInfo(), this.getAssetComsumptionByOrgId(orgId, startDate, endDate, hourly)]);
      const billingInfo = assetConsumption.map((d) => {
        const min = d.avg_asset_count > parseInt(licenseInfo.minimum) ? d.avg_asset_count : licenseInfo.minimum;
        const string_asset_list = d.asset_list || '';
        const assetList = Array.from(new Set(string_asset_list.split(',')));
        return {
          billingCount: min,
          tierMinimum: licenseInfo['tier-type'],
          date: d.day || d.hour,
          average: d.avg_asset_count,
          assetList
        };
      });
      return billingInfo;
    } catch (error) {
      throw error;
    }

  }

  async getAssetConsumption() {
    try {
      return sequelize.query(
        `select type,month, sum(asset_count)/count(asset_count) as avg_asset_count
from ( select to_char(dai.created_at, 'YYYY-MM') as month, type,asset_count from daily_asset_summary dai
where  (is_active ='true' or is_active = 'enabled')) foo
 group by month,type order by month`, { type: QueryTypes.SELECT });
    } catch (e) {
      logger.error({ e, stack: e.stack });
      throw e;
    }
  }

  async getAssetComsumptionByOrgId(orgId, startDate, endDate, hourly = false) {
    logger.info({ startDate, endDate });
    try {
      if (!hourly) {
        return sequelize.query(
          `select day, round(avg(asset_count),0) as avg_asset_count, string_agg(asset_list, ',' ) as asset_list
from ( select date_trunc('day',dai.created_at) as day,  asset_count, asset_list from daily_asset_summary dai
${whereCondition(
            // `(is_active ='true' or is_active = 'enabled')`,
            where.common.orgChainFilter,
            `date_trunc('day',dai.created_at::DATE) >= date_trunc('day',:startDate::DATE)`,
            `date_trunc('day',dai.created_at::DATE) <= date_trunc('day',:endDate::DATE)`
          )}) foo
 group by day order by day desc`, { type: QueryTypes.SELECT, replacements: { orgId, startDate, endDate } });
      } else {
        return sequelize.query(`select hour, round(avg(asset_count),0) as avg_asset_count, string_agg(asset_list, ',' ) as asset_list
from ( select date_trunc('hour',dai.created_at) as hour,  asset_count, asset_list from hourly_asset_summary dai
${whereCondition(
          // `(is_active ='true' or is_active = 'enabled')`,
          where.common.orgChainFilter,
          `date_trunc('hour',dai.created_at) > date_trunc('hour',:startDate::DATE)`,
          `date_trunc('hour',dai.created_at) < date_trunc('hour',:endDate::DATE)`)}) foo
 group by hour order by hour desc`, { type: QueryTypes.SELECT, replacements: { orgId, startDate, endDate } });

      }
    } catch (e) {
      logger.error({ e, stack: e.stack });
      throw e;
    }
  }

  async getTopTenantsByAssetCount() {
    try {
      return sequelize.query(
        `select month,foo.type,parent_org_id,o.name,sum(asset_count)/count(asset_count) as avg_asset_count,
        string_agg(DISTINCT cert.name::character varying,',')::character varying as certificates
           from (select to_char(dai.created_at, 'YYYY-MM') as month,type,
            case when parent_organization_id = -1 then organization_id else parent_organization_id end as parent_org_id,
         asset_count from daily_asset_summary dai where (is_active ='true' or is_active = 'enabled')) as foo 
         join organizations o on parent_org_id = o.id join org_certificate_members ocm on ocm.organization_id = o.id
         join certificates cert on cert.id = ocm.certificate_id
         where (o.is_active ='true' or o.is_active = 'enabled') group by month,foo.type,parent_org_id,o.name
           order by month`,
        { type: QueryTypes.SELECT });
    } catch (e) {
      logger.error({ e, stack: e.stack });
      throw e;
    }

  }

  async getBillingDetailsForOrg(orgId) {
    const orgChain = await Organization.getOrgChain(orgId);
    if (config.saas) {
      return saasorganizationBillingDetails.findAll({ where: { organization_id: orgChain } });
    }
    return organizationBillingDetails.findAll({ where: { organization_id: orgChain } });
  }

};
