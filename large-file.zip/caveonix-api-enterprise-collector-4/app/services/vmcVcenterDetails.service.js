let services = require('./.././services');
let models = require('../models');
let sequelize = require('sequelize');
const _ = require('lodash');
let KeyGenerator = require('./../../utils/generateKeys');
let logger = require('./../../utils/logger').logger.child({
  sub_name: 'IdentityService-vcdVcenterDetails.service',
});
module.exports = class Service {
  constructor(services) {
    this.services = services;
    this.keyGenerator = new KeyGenerator();
    logger.debug('called constructor');
  }
  async getAllVMCVcenterDetails(orgId, limit, offset) {
    let result = await models.VMCVcenterDetails.findAll({ include: [{ model: models.Organization, attributes: ['id', 'name'] }], order: [['id', 'ASC']], limit: limit, offset: offset });
    return result;
  }
  getVMCVcenterDetailsCount(orgId) {
    return models.VMCVcenterDetails.count({ where: { organization_id: orgId } });
  }
  getVMCVcenterDetailsId(VMCVcenterDetailId, orgId) {
    return models.VMCVcenterDetails.findOne({ where: { id: VMCVcenterDetailId, organization_id: orgId }, include: [{ model: models.Organization, attributes: ['id', 'name'] }] });
  }
  getVMCVcenterDetailsByVMCId(VMCId, orgId) {
    return models.VMCVcenterDetails.findOne({ where: { asset_repo_endpoint_vmc_id: VMCId, organization_id: orgId }, include: [{ model: models.Organization, attributes: ['id', 'name'] }] });
  }
  async updateVMCVcenterDetailsById(vmcVcenterDetailId, update) {
    if (update.password) {
      let newPassword = await this.keyGenerator.generateKeys(update.password, null);
      update.password = newPassword;
    }
    return models.VMCVcenterDetails.update(update, {
      where: { id: vmcVcenterDetailId }
    });
  }
  async createVMCVcenterDetails(params) {
    const createdRecords = [];
    for (let i = 0; i < params.length; i++) {
      let data = params[i];
      if (data.password) {
        let newPassword = await this.keyGenerator.generateKeys(data.password, null);
        data.password = newPassword;
      } else {
        data.password = "";
      }
      let url = data.vcenter_url;
      let existingRecord = await models.VMCVcenterDetails.findOne({ where: { vcenter_url: sequelize.where(sequelize.fn('LOWER', sequelize.col('vcenter_url')), sequelize.fn('lower', url)) } });
      if (!existingRecord) {
        let createdResult = await models.VMCVcenterDetails.create(data)
        createdRecords.push(createdResult);
      } else {
        await models.VMCVcenterDetails.update(data, { where: { vcenter_url: url } });
        let result = await models.VMCVcenterDetails.findAll({ where: { vcenter_url: url }, order: [['id', 'ASC']] });
        createdRecords.push(result);
      }
    }
    return createdRecords;
  }
  async updateMultipleVMCVcenterDetails(update) {
    const updatedRecords = [];
    if (update.length > 0) {
      for (let i = 0; i < update.length; i++) {
        let singlePayload = update[i];
        if (singlePayload.password) {
          let newPassword = await this.keyGenerator.generateKeys(singlePayload.password, null);
          singlePayload.password = newPassword;
        }
        let url = singlePayload.vcenter_url;
        let existingRecord = await models.VMCVcenterDetails.findOne({ where: { vcenter_url: sequelize.where(sequelize.fn('LOWER', sequelize.col('vcenter_url')), sequelize.fn('lower', url)) } });
        if (!existingRecord) {
          let createdResult = await models.VMCVcenterDetails.create(singlePayload);
          let result = await models.VMCVcenterDetails.findAll({ where: { vcenter_url: createdResult.vcenter_url }, order: [['id', 'ASC']] });
          updatedRecords.push(result);
        } else {
          await models.VMCVcenterDetails.update(singlePayload, { where: { vcenter_url: url } });
          let result = await models.VMCVcenterDetails.findAll({ where: { vcenter_url: url }, order: [['id', 'ASC']] });
          updatedRecords.push(result);
        }
      }
    }
    return updatedRecords;
  }
};
