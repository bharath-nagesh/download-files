let models = require('./../models');
let sequelize = require('sequelize');
let logger = require('./../../utils/logger').logger.child({
  sub_name: 'IdentityService-productOfferingsService.service',
});
module.exports = class Service {
  constructor(services) {
    this.services = services;
    logger.debug('called constructor')
  }
  getById(Id) {
    return models.ProductOfferings.findOne({ where: { id: Id, $and: [{ is_active: { $ne: "disabled" } }, { is_active: { $ne: "false" } }] } });
  }
  getAllProductOfferings(limit, offset) {
    return models.ProductOfferings.findAll({
      where: { $and: [{ is_active: { $ne: "disabled" } }, { is_active: { $ne: "false" } }] }, order: [['id', 'ASC']], limit: limit,
      offset: offset
    });
  }
  getAllProductOfferingsCount() {
    return models.ProductOfferings.count({
      where: { $and: [{ is_active: { $ne: "disabled" } }, { is_active: { $ne: "false" } }] }
    });
  }
  async getProductOfferingsByOrgId(orgId) {
    try {
      let org = await models.Organization.findByPk(orgId, { include: [{ all: true }] })
      if (org.type == 'Provider') {
        return models.ProductOfferings.findAll({ where: { $and: [{ is_active: { $ne: "disabled" } }, { is_active: { $ne: "false" } }] } });
      }
      else {
        let result = await models.OrgProductOffering.findAll({ where: { organization_id: orgId } })
        let newArr = result.map(object => {
          return object.dataValues.product_offering_id;
        });
        return models.ProductOfferings.findAll({ where: { id: { $in: newArr }, $and: [{ is_active: { $ne: "disabled" } }, { is_active: { $ne: "false" } }] } });
      }
    }
    catch (error) {
      logger.error({ error, stack: error.stack }, 'error getting product offering')
      error.status = 400
      throw error
    }
  }
};
