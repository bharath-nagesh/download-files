var rp = require('request-promise');
let dashboard = require('./../../utils/forensicDashboard.json');
let KeyGenerator = require('./../../utils/generateKeys');
//let config = require('../../config.json');
const KibanaUserRolesService = require('../apis/kibanaUserRoles/kibanaUserRoles.service');
const kibanaUserRolesService = new KibanaUserRolesService();
let config = require('./../../configure').get();
const _ = require('lodash');
const uuidv4 = require('uuid/v4');
var request = require('request');
let indexPatternArr = [];
let visualizationArr = [];
let searchArr = [];
let dashBoardArr = [];
var auth = '';
let cookie = '';
const ForensicsDashboard = require('../models/forensicsDashboard.model');
let logger = require('./../../utils/logger').logger.child({

  sub_name: 'IdentityService-kibanaDashBoard.service',
});
module.exports = class KibanaDashboardService {
  constructor() {
    this.keyGenerator = new KeyGenerator();
    logger.debug('called constructor');
  }

  createDashboard(orgId, callback = null) {
    this.createIndexPattern(orgId, callback);
  }

  createIndexPattern(orgId, callback = null) {
    let service = this;
    let ctr = 0;
    let titleLog = 'caveolog-' + orgId + '*';
    let titleScan = 'caveoscan-' + orgId + '*';
    let titleFlow = 'caveonetwork-' + orgId + '*-flows*';

    let urlLog = config.kibana_url + '/api/saved_objects/index-pattern/' + uuidv4();
    let urlScan = config.kibana_url + '/api/saved_objects/index-pattern/' + uuidv4();
    let urlFlow = config.kibana_url + '/api/saved_objects/index-pattern/' + uuidv4();

    let urlArr = [];
    urlArr.push(urlLog, urlScan, urlFlow);

    urlArr.forEach(function (object) {
      let payload = '';
      if (object === urlLog) {
        dashboard.forensicDashboard.Indexes[2].attributes.title = titleLog;
        payload = dashboard.forensicDashboard.Indexes[2];
      } else if (object === urlScan) {
        dashboard.forensicDashboard.Indexes[0].attributes.title = titleScan;
        payload = dashboard.forensicDashboard.Indexes[0];
      } else {
        dashboard.forensicDashboard.Indexes[1].attributes.title = titleFlow;
        payload = dashboard.forensicDashboard.Indexes[1];
      }
      var options = {
        method: 'POST',
        uri: object,
        body: payload,
        headers: {
          'kbn-xsrf': 'anything',
          'Content-Type': 'application/json',
          'Authorization': auth
        },
        json: true,
        rejectUnauthorized: config.checkKibanaCertificate
      };
      rp(options)
        .then(parsedBody => {
          if (parsedBody.attributes.title == titleLog) {
            indexPatternArr.push({ 'Logs': parsedBody.id });
            ctr++;
          } else if (parsedBody.attributes.title == titleScan) {
            indexPatternArr.push({ 'Scan': parsedBody.id });
            ctr++;
          } else {
            indexPatternArr.push({ 'Flows': parsedBody.id });
            ctr++;
          }

          if (ctr == 3) {
            service.createDefaultIndexPattern(orgId, callback);
          }
        })
        .catch(function (err) {
          if (err.statusCode == 404) {
            service.createIndexPatternForNewKibanaVersion(orgId, callback);
          } else {
            callback('Error in index pattern creation', false);
          }
        });
    });
  }

  createDefaultIndexPattern(orgId, callback = null) {
    let service = this;

    let url = config.kibana_url + '/api/kibana/settings/defaultIndex';

    let Logs = '';
    indexPatternArr.filter(function (object) {
      if (object.Logs) {
        Logs = object.Logs;
      }
    });

    var options = {
      method: 'POST',
      uri: url,
      body: {
        'value': Logs
      },
      headers: {
        'kbn-xsrf': 'anything',
        'Content-Type': 'application/json',
        'Authorization': auth
      },
      json: true,
      rejectUnauthorized: config.checkKibanaCertificate
    };
    rp(options)
      .then(parsedBody => {
        if (parsedBody) {
          service.createVisualization(orgId, callback);
        }
      })
      .catch(function (err) {
        if (err) {
          return err;
        }
      });
  }

  createVisualization(orgId, callback = null) {
    let service = this;
    let ctr = 0;
    let dis = 'Tenant-' + orgId;
    let url = config.kibana_url + '/api/saved_objects/visualization';

    let Logs = '';
    let Scan = '';
    let Flows = '';
    indexPatternArr.filter(function (object) {
      if (object.Logs) {
        Logs = object.Logs;
      } else if (object.Scan) {
        Scan = object.Scan;
      } else {
        Flows = object.Flows;
      }
    });

    let typeArr = [];
    typeArr.push('log', 'scan', 'flow');

    let payloadVisualization = [];
    typeArr.forEach(function (object) {
      var payload_Configuration_Check = '';
      var payload_Network_Flow = '';
      var payload_Events = '';
      if (object === 'scan') {
        payload_Configuration_Check = dashboard.forensicDashboard.visualization[0];
        let obj = JSON.parse(payload_Configuration_Check.attributes.kibanaSavedObjectMeta.searchSourceJSON);
        obj.index = Scan;
        let jsonString = JSON.stringify(obj);
        payload_Configuration_Check.attributes.kibanaSavedObjectMeta.searchSourceJSON = jsonString;
        payload_Configuration_Check.attributes.description = dis;

        payloadVisualization.push(payload_Configuration_Check);
      } else if (object === 'flow') {
        payload_Network_Flow = dashboard.forensicDashboard.visualization[2];
        let obj = JSON.parse(payload_Network_Flow.attributes.kibanaSavedObjectMeta.searchSourceJSON);
        obj.index = Flows;
        let jsonString = JSON.stringify(obj);
        payload_Network_Flow.attributes.kibanaSavedObjectMeta.searchSourceJSON = jsonString;
        payload_Network_Flow.attributes.description = dis;

        payloadVisualization.push(payload_Network_Flow);
      } else {
        payload_Events = dashboard.forensicDashboard.visualization[4];
        let obj = JSON.parse(payload_Events.attributes.kibanaSavedObjectMeta.searchSourceJSON);
        obj.index = Logs;
        let jsonString = JSON.stringify(obj);
        payload_Events.attributes.kibanaSavedObjectMeta.searchSourceJSON = jsonString;
        payload_Events.attributes.description = dis;

        payloadVisualization.push(payload_Events);
      }
    });
    payloadVisualization.forEach(function (payload) {
      var options = {
        method: 'POST',
        uri: url,
        body: payload,
        headers: {
          'kbn-xsrf': 'anything',
          'Content-Type': 'application/json',
          'Authorization': auth
        },
        json: true,
        rejectUnauthorized: config.checkKibanaCertificate
      };
      rp(options)
        .then(parsedBody => {
          if (parsedBody.attributes.title == 'Configuration Check') {
            visualizationArr.push({ 'Configuration_Check': parsedBody.id });
            ctr++;
          } else if (parsedBody.attributes.title == 'Network Flow') {
            visualizationArr.push({ 'Network_Flow': parsedBody.id });
            ctr++;
          } else {
            visualizationArr.push({ 'Events': parsedBody.id });
            ctr++;
          }
          if (ctr == 3) {

            service.createSearch(orgId, callback);
          }
        })
        .catch(function (err) {
          if (err) {
            return err;
          }
        });
    });
  }

  createSearch(orgId, callback = null) {
    let service = this;
    let ctr = 0;
    let dis = 'Tenant-' + orgId;

    let url = config.kibana_url + '/api/saved_objects/search';

    let Logs = '';
    let Scan = '';
    let Flows = '';
    indexPatternArr.filter(function (object) {
      if (object.Logs) {
        Logs = object.Logs;
      } else if (object.Scan) {
        Scan = object.Scan;
      } else {
        Flows = object.Flows;
      }
    });

    let typeArr = [];
    typeArr.push('log', 'scan', 'flow');

    let payloadSearch = [];
    typeArr.forEach(function (object) {
      var payload_Scan_search = '';
      var payload_Flows_Search = '';
      var payload_Log_Search = '';
      if (object === 'scan') {
        payload_Scan_search = dashboard.forensicDashboard.visualization[1];
        let obj = JSON.parse(payload_Scan_search.attributes.kibanaSavedObjectMeta.searchSourceJSON);
        obj.index = Scan;
        let jsonString = JSON.stringify(obj);
        payload_Scan_search.attributes.kibanaSavedObjectMeta.searchSourceJSON = jsonString;
        payload_Scan_search.attributes.description = dis;

        payloadSearch.push(payload_Scan_search);
      } else if (object === 'flow') {
        payload_Flows_Search = dashboard.forensicDashboard.visualization[3];
        let obj = JSON.parse(payload_Flows_Search.attributes.kibanaSavedObjectMeta.searchSourceJSON);
        obj.index = Flows;
        let jsonString = JSON.stringify(obj);
        payload_Flows_Search.attributes.kibanaSavedObjectMeta.searchSourceJSON = jsonString;
        payload_Flows_Search.attributes.description = dis;

        payloadSearch.push(payload_Flows_Search);
      } else {
        payload_Log_Search = dashboard.forensicDashboard.visualization[5];
        let obj = JSON.parse(payload_Log_Search.attributes.kibanaSavedObjectMeta.searchSourceJSON);
        obj.index = Logs;
        let jsonString = JSON.stringify(obj);
        payload_Log_Search.attributes.kibanaSavedObjectMeta.searchSourceJSON = jsonString;
        payload_Log_Search.attributes.description = dis;

        payloadSearch.push(payload_Log_Search);
      }
    });
    payloadSearch.forEach(function (payload) {
      var options = {
        method: 'POST',
        uri: url,
        body: payload,
        headers: {
          'kbn-xsrf': 'anything',
          'Content-Type': 'application/json',
          'Authorization': auth
        },
        json: true,
        rejectUnauthorized: config.checkKibanaCertificate
      };
      rp(options)
        .then(parsedBody => {
          if (parsedBody.attributes.title == 'Log Search') {
            searchArr.push({ 'Log_Search': parsedBody.id });
            ctr++;
          } else if (parsedBody.attributes.title == 'Flows Search') {
            searchArr.push({ 'Flows_Search': parsedBody.id });
            ctr++;
          } else {
            searchArr.push({ 'Scan_search': parsedBody.id });
            ctr++;
          }
          if (ctr == 3) {
            service.createDashBoard(orgId, callback);
          }
        })
        .catch(function (err) {
          if (err) {
            return err;
          }
        });
    });
  }

  createDashBoard(orgId, callback = null) {
    let ctr = 0;
    let service = this;
    let titleLog = 'CaveoLogs-Dashboard-' + orgId;
    let titleScan = 'CaveoScan-Dashboard-' + orgId;
    let titleFlow = 'CaveoNetwork-Dashboard-' + orgId;

    let dis = 'Tenant-' + orgId;

    let Configuration_Check = '';
    let Network_Flow = '';
    let Events = '';
    let Log_Search = '';
    let Flows_Search = '';
    let Scan_search = '';
    visualizationArr.filter(function (object) {
      if (object.Configuration_Check) {
        Configuration_Check = object.Configuration_Check;
      } else if (object.Network_Flow) {
        Network_Flow = object.Network_Flow;
      } else {
        Events = object.Events;
      }
    });
    searchArr.filter(function (object) {
      if (object.Log_Search) {
        Log_Search = object.Log_Search;
      } else if (object.Flows_Search) {
        Flows_Search = object.Flows_Search;
      } else {
        Scan_search = object.Scan_search;
      }
    });
    let url = config.kibana_url + '/api/saved_objects/dashboard';

    let typeArr = [];
    typeArr.push('log', 'scan', 'flow');

    let payloadArr = [];
    typeArr.forEach(function (object) {
      var payloadLog = '';
      var payloadScan = '';
      var payloadFlow = '';
      if (object === 'scan') {
        payloadScan = dashboard.forensicDashboard.Dashboard[0];
        let obj = JSON.parse(payloadScan.attributes.panelsJSON);
        obj[0].id = Configuration_Check;
        obj[1].id = Scan_search;
        let jsonString = JSON.stringify(obj);
        payloadScan.attributes.panelsJSON = jsonString;
        payloadScan.attributes.description = dis;
        payloadScan.attributes.title = titleScan;

        payloadArr.push(payloadScan);
      } else if (object === 'flow') {
        payloadFlow = dashboard.forensicDashboard.Dashboard[1];
        let obj = JSON.parse(payloadFlow.attributes.panelsJSON);
        obj[0].id = Network_Flow;
        obj[1].id = Flows_Search;
        let jsonString = JSON.stringify(obj);
        payloadFlow.attributes.panelsJSON = jsonString;
        payloadFlow.attributes.description = dis;
        payloadFlow.attributes.title = titleFlow;

        payloadArr.push(payloadFlow);
      } else {
        payloadLog = dashboard.forensicDashboard.Dashboard[2];
        let obj = JSON.parse(payloadLog.attributes.panelsJSON);
        obj[0].id = Log_Search;
        obj[1].id = Events;
        let jsonString = JSON.stringify(obj);
        payloadLog.attributes.panelsJSON = jsonString;
        payloadLog.attributes.description = dis;
        payloadLog.attributes.title = titleLog;

        payloadArr.push(payloadLog);
      }
    });
    payloadArr.forEach(function (payload) {
      var options = {
        method: 'POST',
        uri: url,
        body: payload,
        headers: {
          'kbn-xsrf': 'anything',
          'Content-Type': 'application/json',
          'Authorization': auth
        },
        json: true,
        rejectUnauthorized: config.checkKibanaCertificate
      };
      rp(options)
        .then(parsedBody => {
          if (parsedBody.attributes.title == titleLog) {
            dashBoardArr.push({ 'Log_Dashboard': parsedBody.id });
            ctr++;
          } else if (parsedBody.attributes.title == titleScan) {
            dashBoardArr.push({ 'Scan_Dashboard': parsedBody.id });
            ctr++;
          } else {
            dashBoardArr.push({ 'Flows_Dashboard': parsedBody.id });
            ctr++;
          }

          if (ctr == 3) {
            service.createIframeUrl(orgId, callback);
          }
        })
        .catch(function (err) {
          if (err) {
            return err;
          }
        });
    });
  }

  createIframeUrl(orgId, callback = null) {
    let dis = 'Tenant-' + orgId;
    let service = this;
    let titleLog = 'CaveoLogs-Dashboard-' + orgId;
    let titleScan = 'CaveoScan-Dashboard-' + orgId;
    let titleFlow = 'CaveoNetwork-Dashboard-' + orgId;

    let indexPatternLog = 'caveolog-' + orgId + '*';
    let indexPatternScan = 'caveoscan-' + orgId + '*';
    let indexPatternFlow = 'caveonetwork-' + orgId + '*';

    let typeArr = [];
    typeArr.push('logs', 'scan', 'flows');

    let Configuration_Check = '';
    let Network_Flow = '';
    let Events = '';
    let Log_Search = '';
    let Flows_Search = '';
    let Scan_search = '';
    let Log_Dashboard = '';
    let Scan_Dashboard = '';
    let Flows_Dashboard = '';
    visualizationArr.filter(function (object) {
      if (object.Configuration_Check) {
        Configuration_Check = object.Configuration_Check;
      } else if (object.Network_Flow) {
        Network_Flow = object.Network_Flow;
      } else {
        Events = object.Events;
      }
    });
    searchArr.filter(function (object) {
      if (object.Log_Search) {
        Log_Search = object.Log_Search;
      } else if (object.Flows_Search) {
        Flows_Search = object.Flows_Search;
      } else {
        Scan_search = object.Scan_search;
      }
    });
    dashBoardArr.filter(function (object) {
      if (object.Log_Dashboard) {
        Log_Dashboard = object.Log_Dashboard;
      } else if (object.Scan_Dashboard) {
        Scan_Dashboard = object.Scan_Dashboard;
      } else {
        Flows_Dashboard = object.Flows_Dashboard;
      }
    });

    let timeframe = '';
    if (config.Forensics_Timeframe) {
      timeframe = config.Forensics_Timeframe;
    } else {
      timeframe = '30d';
    }
    let iframeLog = '<iframe src="kibanaUrl/app/kibana#/dashboard/' + Log_Dashboard + '?embed=true&_g=(refreshInterval:(display:Off,pause:!f,value:0),time:(from:now-' + timeframe + ',mode:quick,to:now))&_a=(description:' + dis + ',filters:!(),fullScreenMode:!f,options:(darkTheme:!f,hidePanelTitles:!f,useMargins:!t),panels:!((gridData:(h:3,i:' + '\'1\'' + ',w:12,x:0,y:0),id:' + '\'' + Events + '\'' + ',panelIndex:' + '\'1\'' + ',type:visualization,version:' + '\'6.1.3\'' + '),(gridData:(h:5,i:' + '\'2\'' + ',w:12,x:0,y:3),id:' + '\'' + Log_Search + '\'' + ',panelIndex:' + '\'2\'' + ',type:search,version:' + '\'6.1.3\'' + ')),query:(language:lucene,query:\'\'),timeRestore:!t,title:' + titleLog + ',viewMode:view)" height="600" width="800"></iframe>';
    let iframeScan = '<iframe src="kibanaUrl/app/kibana#/dashboard/' + Scan_Dashboard + '?embed=true&_g=(refreshInterval:(display:Off,pause:!f,value:0),time:(from:now-' + timeframe + ',mode:quick,to:now))&_a=(description:' + dis + ',filters:!(),fullScreenMode:!f,options:(darkTheme:!f,hidePanelTitles:!f,useMargins:!t),panels:!((gridData:(h:3,i:' + '\'1\'' + ',w:12,x:0,y:0),id:' + '\'' + Configuration_Check + '\'' + ',panelIndex:' + '\'1\'' + ',type:visualization,version:' + '\'6.1.3\'' + '),(gridData:(h:5,i:' + '\'2\'' + ',w:12,x:0,y:3),id:' + '\'' + Scan_search + '\'' + ',panelIndex:' + '\'2\'' + ',type:search,version:' + '\'6.1.3\'' + ')),query:(language:lucene,query:\'\'),timeRestore:!t,title:' + titleScan + ',viewMode:view)" height="600" width="800"></iframe>';
    let iframeFlow = '<iframe src="kibanaUrl/app/kibana#/dashboard/' + Flows_Dashboard + '?embed=true&_g=(refreshInterval:(display:Off,pause:!f,value:0),time:(from:now-' + timeframe + ',mode:quick,to:now))&_a=(description:' + dis + ',filters:!(),fullScreenMode:!f,options:(darkTheme:!f,hidePanelTitles:!f,useMargins:!t),panels:!((gridData:(h:3,i:' + '\'1\'' + ',w:12,x:0,y:0),id:' + '\'' + Network_Flow + '\'' + ',panelIndex:' + '\'1\'' + ',type:visualization,version:' + '\'6.1.3\'' + '),(gridData:(h:5,i:' + '\'2\'' + ',w:12,x:0,y:3),id:' + '\'' + Flows_Search + '\'' + ',panelIndex:' + '\'2\'' + ',type:search,version:' + '\'6.1.3\'' + ')),query:(language:lucene,query:\'\'),timeRestore:!t,title:' + titleFlow + ',viewMode:view)" height="600" width="800"></iframe>';

    return ForensicsDashboard.sequelize.query('insert into forensics_dashboard(index_pattern, organization_id, type, dashboard_url, widget, is_active, created_at) values ($1,$2,$3,$4,$5,$6, now())', {
      bind: [indexPatternLog, orgId, typeArr[0], iframeLog, Log_Dashboard, 'true']
    }).then(() => {
      return ForensicsDashboard.sequelize.query('insert into forensics_dashboard(index_pattern, organization_id, type, dashboard_url, widget, is_active, created_at) values ($1,$2,$3,$4,$5,$6, now())', {
        bind: [indexPatternScan, orgId, typeArr[1], iframeScan, Scan_Dashboard, 'true']
      });
    }).then(() => {
      return ForensicsDashboard.sequelize.query('insert into forensics_dashboard(index_pattern, organization_id, type, dashboard_url, widget, is_active, created_at) values ($1,$2,$3,$4,$5,$6, now())', {
        bind: [indexPatternFlow, orgId, typeArr[2], iframeFlow, Flows_Dashboard, 'true']
      });
    }).then(() => {
      if (callback != null) {
        return service.getFields(orgId, cookie, function (err, result) {
          return service.updateIndexPatternFields(orgId, null, indexPatternArr, result, auth, function (err, finalData) {
            indexPatternArr.length = 0;
            visualizationArr.length = 0;
            searchArr.length = 0;
            dashBoardArr.length = 0;

            return service.services.kibanaMachineLearningService.getLogJob(orgId, cookie, finalData, function (err, data) {
              if (err) {
                callback(false, finalData);
              } else {
                return service.services.kibanaMachineLearningService.updateJob(orgId, auth, finalData, function (err, data) {
                  if (err) {
                    return service.services.kibanaMachineLearningService.deleteDataFeed(orgId, cookie, auth, finalData, function (err, data) {
                      if (err) {
                        callback(false, finalData);
                      } else {
                        callback(false, finalData);
                      }
                    });
                  } else {
                    callback(false, finalData);
                  }
                });
              }
            });
          });
        });
      }
    });
  }

  async getDashBoard(orgId, sid, callback = null) {
    let ctr = 0;
    let service = this;

    if (config.forensics_enabled == true && config.ml_enabled == false) {
      sid = '';
    }
    cookie = sid;

    let LogDashBoard = 'null';
    let ScanDashboard = 'null';
    let NetworkDashboard = 'null';
    let dashBoardResponse = [];
    let checkStatus = true;

    logger.info('Kafka Url' + config.kibana_url);
    let data = await ForensicsDashboard.findAll({
      where: {
        organization_id: orgId,
        type: { $ne: 'machine_learning' }
      }
    });
    let newPassword = await service.keyGenerator.decryptKeys(config.es_password);
    auth = 'Basic ' + new Buffer(config.es_username + ':' + newPassword).toString('base64');
    data.filter(object => {
      if (object.type == 'logs') {
        LogDashBoard = object.widget;
      } else if (object.type == 'scan') {
        ScanDashboard = object.widget;
      } else {
        NetworkDashboard = object.widget;
      }
    });
    let urls = [
      config.kibana_url + '/api/saved_objects/dashboard/' + LogDashBoard,
      config.kibana_url + '/api/saved_objects/dashboard/' + ScanDashboard,
      config.kibana_url + '/api/saved_objects/dashboard/' + NetworkDashboard
    ];
    logger.info('LogDashboard Url' + urls[0]);
    logger.info('ScanDashboard Url' + urls[1]);
    logger.info('NetworkDashboard Url' + urls[2]);
    urls.forEach(function (url) {
      var options = {
        method: 'GET',
        uri: url,
        headers: {
          'kbn-xsrf': 'anything',
          'Cookie': sid
        },
        json: true,
        rejectUnauthorized: config.checkKibanaCertificate
      };
      request(options, function (err, response, body) {
        if (response && (response.statusCode == 200 || response.statusCode == 202)) {
          dashBoardResponse.push(body);
          ctr++;

          if (ctr == 3) {
            service.getVisualization(orgId, dashBoardResponse, sid, callback);
          }
        } else {
          if (checkStatus == true) {
            checkStatus = false;
            return service.deleteDashboard(orgId, sid, callback);
          }
        }
      });
    });
  }

  getVisualization(orgId, responseArray, sid, callback = null) {
    let service = this;
    let ctr = 0;

    let LogVisualization = 'null';
    let ScanVisualization = 'null';
    let NetworkVisualization = 'null';
    let visualizationResponse = [];
    let checkStatus = true;

    responseArray.filter(function (object) {
      let jsonObject = JSON.parse(object.attributes.panelsJSON);
      if (object.attributes.title == 'CaveoLogs-Dashboard-' + orgId) {
        LogVisualization = jsonObject[1].id;
      } else if (object.attributes.title == 'CaveoScan-Dashboard-' + orgId) {
        ScanVisualization = jsonObject[0].id;
      } else {
        NetworkVisualization = jsonObject[0].id;
      }
    });
    let visualizationUrlArray = [
      config.kibana_url + '/api/saved_objects/visualization/' + LogVisualization,
      config.kibana_url + '/api/saved_objects/visualization/' + ScanVisualization,
      config.kibana_url + '/api/saved_objects/visualization/' + NetworkVisualization
    ];
    visualizationUrlArray.forEach(function (url) {
      var options = {
        method: 'GET',
        uri: url,
        headers: {
          'kbn-xsrf': 'anything',
          'Cookie': sid
        },
        json: true,
        rejectUnauthorized: config.checkKibanaCertificate
      };
      request(options, function (err, response, body) {
        if (response && (response.statusCode == 200 || response.statusCode == 202)) {
          visualizationResponse.push(body);
          ctr++;

          if (ctr == 3) {
            service.getIndexPattern(orgId, visualizationResponse, sid, callback);
          }
        } else {
          if (checkStatus == true) {
            checkStatus = false;
            return service.deleteDashboard(orgId, sid, callback);
          }
        }
      });
    });
  }

  getIndexPattern(orgId, responseArray, sid, callback = null) {
    let service = this;
    let ctr = 0;

    let LogIndex = 'null';
    let ScanIndex = 'null';
    let NetworkIndex = 'null';
    let checkStatus = true;

    responseArray.filter(function (object) {
      let jsonObject = JSON.parse(object.attributes.kibanaSavedObjectMeta.searchSourceJSON);
      if (object.attributes.title == 'Events') {
        LogIndex = jsonObject.index;
      } else if (object.attributes.title == 'Configuration Check') {
        ScanIndex = jsonObject.index;
      } else {
        NetworkIndex = jsonObject.index;
      }
    });
    let indexPatternUrlArray = [
      config.kibana_url + '/api/saved_objects/index-pattern/' + LogIndex,
      config.kibana_url + '/api/saved_objects/index-pattern/' + ScanIndex,
      config.kibana_url + '/api/saved_objects/index-pattern/' + NetworkIndex
    ];
    indexPatternUrlArray.forEach(function (url) {
      var options = {
        method: 'GET',
        uri: url,
        headers: {
          'kbn-xsrf': 'anything',
          'Cookie': sid
        },
        json: true,
        rejectUnauthorized: config.checkKibanaCertificate
      };
      request(options, function (err, response, body) {
        if (response && (response.statusCode == 200 || response.statusCode == 202)) {
          ctr++;

          if (ctr == 3) {
            return service.getFields(orgId, sid, function (err, result) {
              return service.updateIndexPatternFields(orgId, responseArray, null, result, auth, callback);
            });
          }
        } else {
          if (checkStatus == true) {
            checkStatus = false;
            return service.deleteDashboard(orgId, sid, callback);
          }
        }
      });
    });
  }

  deleteDashboard(orgId, sid, callback = null) {
    let idToDelete = [];
    let ctr = 0;
    let service = this;
    let increament = 0;
    let i = 0;
    let checkStatus = true;

    let urls = [
      config.kibana_url + '/api/saved_objects/dashboard/',
      config.kibana_url + '/api/saved_objects/visualization/',
      config.kibana_url + '/api/saved_objects/search/'
    ];

    let typeArray = ['dashboard', 'visualization', 'search'];

    typeArray.forEach(function (type) {
      let getUrlold = config.kibana_url + '/api/saved_objects/?type=' + type + '&search=' + orgId + '&search_fields=title%5E3&search_fields=description';
      let getUrlnew = config.kibana_url + '/api/saved_objects/_find?type=' + type + '&search=' + orgId + '&search_fields=title%5E3&search_fields=description';

      var options = {
        method: 'GET',
        url: getUrlold,
        headers: {
          'kbn-xsrf': 'anything',
          'Content-Type': 'application/json',
          'Cookie': sid
        },
        json: true,
        rejectUnauthorized: config.checkKibanaCertificate
      };
      var option1 = {
        method: 'GET',
        url: getUrlnew,
        headers: {
          'kbn-xsrf': 'anything',
          'Content-Type': 'application/json',
          'Cookie': sid
        },
        json: true,
        rejectUnauthorized: config.checkKibanaCertificate
      };
      request(options, function (err, response, body) {
        if (response && (response.statusCode == 200 || response.statusCode == 202)) {
          body.saved_objects.forEach(function (object) {
            if (type == 'dashboard') {
              idToDelete.push({ 'dashboard': object.id });
              ctr++;
            } else if (type == 'visualization') {
              idToDelete.push({ 'visualization': object.id });
              ctr++;
            } else {
              idToDelete.push({ 'search': object.id });
              ctr++;
            }
          });
          increament++;
          if (increament == typeArray.length) {
            if (idToDelete.length != 0) {
              idToDelete.forEach(function (object) {
                let url = '';
                if (object.dashboard) {
                  url = urls[0] + object.dashboard;
                } else if (object.visualization) {
                  url = urls[1] + object.visualization;
                } else {
                  url = urls[2] + object.search;
                }
                var options1 = {
                  method: 'DELETE',
                  uri: url,
                  headers: {
                    'kbn-xsrf': 'anything',
                    'Authorization': auth
                  },
                  json: true,
                  rejectUnauthorized: config.checkKibanaCertificate
                };
                rp(options1)
                  .then(body => {
                    if (body) {
                      i++;

                      if (i == idToDelete.length) {
                        service.deleteIndexPattern(orgId, sid, callback);
                      }
                    }
                  });
              });
            } else {
              service.deleteIndexPattern(orgId, sid, callback);
            }
          }
        } else {
          request(option1, function (err, response, bodyNew) {
            if (checkStatus == true) {
              if (response && (response.statusCode == 200 || response.statusCode == 202)) {
                bodyNew.saved_objects.forEach(function (object) {
                  if (type == 'dashboard') {
                    idToDelete.push({ 'dashboard': object.id });
                    ctr++;
                  } else if (type == 'visualization') {
                    idToDelete.push({ 'visualization': object.id });
                    ctr++;
                  } else {
                    idToDelete.push({ 'search': object.id });
                    ctr++;
                  }
                });
                increament++;
                if (increament == typeArray.length) {
                  if (idToDelete.length != 0) {
                    idToDelete.forEach(function (object) {
                      let url = '';
                      if (object.dashboard) {
                        url = urls[0] + object.dashboard;
                      } else if (object.visualization) {
                        url = urls[1] + object.visualization;
                      } else {
                        url = urls[2] + object.search;
                      }
                      var options1 = {
                        method: 'DELETE',
                        uri: url,
                        headers: {
                          'kbn-xsrf': 'anything',
                          'Authorization': auth
                        },
                        json: true,
                        rejectUnauthorized: config.checkKibanaCertificate
                      };
                      rp(options1)
                        .then(body => {
                          if (body) {
                            i++;

                            if (i == idToDelete.length) {
                              service.deleteIndexPattern(orgId, sid, callback);
                            }
                          }
                        });
                    });
                  } else {
                    service.deleteIndexPattern(orgId, sid, callback);
                  }
                }
              } else {
                checkStatus = false;
                callback('Error in deletion', false);
              }
            }
          });
        }
      });
    });
  }

  deleteIndexPattern(orgId, sid, callback = null) {
    let service = this;
    let ctr = 0;
    let i = 0;
    let titleLog = 'caveolog-' + orgId + '*';
    let titleScan = 'caveoscan-' + orgId + '*';
    let titleFlow = 'caveonetwork-' + orgId + '*-flows*';
    let idToDelete = [];
    let checkStatus = true;

    let deleteUrl = config.kibana_url + '/api/saved_objects/index-pattern/';
    let getUrlOld = config.kibana_url + '/api/saved_objects/?type=index-pattern&fields=title&per_page=10000';
    let getUrlNew = config.kibana_url + '/api/saved_objects/_find?type=index-pattern&fields=title&per_page=10000';

    var options = {
      method: 'GET',
      url: getUrlOld,
      headers: {
        'kbn-xsrf': 'anything',
        'Content-Type': 'application/json',
        'Cookie': sid
      },
      json: true,
      rejectUnauthorized: config.checkKibanaCertificate
    };
    var option1 = {
      method: 'GET',
      url: getUrlNew,
      headers: {
        'kbn-xsrf': 'anything',
        'Content-Type': 'application/json',
        'Cookie': sid
      },
      json: true,
      rejectUnauthorized: config.checkKibanaCertificate
    };
    request(options, function (err, response, body) {
      if (response && (response.statusCode == 200 || response.statusCode == 202)) {
        body.saved_objects.forEach(function (object) {
          if (object.attributes.title == titleLog || object.attributes.title == titleScan || object.attributes.title == titleFlow) {
            idToDelete.push(object.id);
            ctr++;
          }
        });
        if (idToDelete.length != 0) {
          idToDelete.forEach(function (object) {
            let url = deleteUrl + object;
            var options1 = {
              method: 'DELETE',
              uri: url,
              headers: {
                'kbn-xsrf': 'anything',
                'Authorization': auth
              },
              json: true,
              rejectUnauthorized: config.checkKibanaCertificate
            };
            rp(options1)
              .then(body => {
                if (body) {
                  i++;

                  if (i == idToDelete.length) {
                    return ForensicsDashboard.destroy({
                      where: {
                        organization_id: orgId,
                        type: { $ne: 'machine_learning' }
                      }
                    }).then(() => {
                      return service.createDashboard(orgId, callback);
                    });
                  }
                }
              });
          });
        } else {
          return ForensicsDashboard.destroy({
            where: {
              organization_id: orgId,
              type: { $ne: 'machine_learning' }
            }
          }).then(() => {
            return service.createDashboard(orgId, callback);
          });
        }
      } else {
        request(option1, function (err, response, bodyNew) {
          if (checkStatus == true) {
            if (response && (response.statusCode == 200 || response.statusCode == 202)) {
              bodyNew.saved_objects.forEach(function (object) {
                if (object.attributes.title == titleLog || object.attributes.title == titleScan || object.attributes.title == titleFlow) {
                  idToDelete.push(object.id);
                  ctr++;
                }
              });
              if (idToDelete.length != 0) {
                idToDelete.forEach(function (object) {
                  let url = deleteUrl + object;
                  var options1 = {
                    method: 'DELETE',
                    uri: url,
                    headers: {
                      'kbn-xsrf': 'anything',
                      'Authorization': auth
                    },
                    json: true,
                    rejectUnauthorized: config.checkKibanaCertificate
                  };
                  rp(options1)
                    .then(body => {
                      if (body) {
                        i++;

                        if (i == idToDelete.length) {
                          return ForensicsDashboard.destroy({
                            where: {
                              organization_id: orgId,
                              type: { $ne: 'machine_learning' }
                            }
                          }).then(() => {
                            return service.createDashboard(orgId, callback);
                          });
                        }
                      }
                    });
                });
              } else {
                return ForensicsDashboard.destroy({
                  where: {
                    organization_id: orgId,
                    type: { $ne: 'machine_learning' }
                  }
                }).then(() => {
                  return service.createDashboard(orgId, callback);
                });
              }
            } else {
              checkStatus = false;
              callback('Error in deletion of index_pattern', false);
            }
          }
        });
      }
    });
  }

  async kibanaUserLogin(username, password, user = null) {
    const url = config.kibana_url + '/api/security/v1/login';
    const body = Object.assign({});
    body.username = username;
    body.password = password;

    try {
      const response = await rp.post(url, { body: body, headers: { 'kbn-xsrf': 'anything', 'Content-Type': 'application/json' }, json: true, rejectUnauthorized: false, resolveWithFullResponse: true });
      return response.headers['set-cookie'][0].split(';');
    } catch(error){
      if(user) {
        const orgId = _.has(user, 'Organization.organization_id') ? _.get(user, 'Organization.organization_id') : _.get(user, 'organization.id');
        const params = {
          username: user.username,
          fullname: `${user.firstName} ${user.lastName}`,
          email: user.username,
          password: password
        };
        try{
          if(user.role.name.toLowerCase() === ('msp_owner') || user.role.name.toLowerCase() === ('mssp_owner')){
            const assignedOrgIds = user.OrgMemberships.map( o => o.id || o.organization_id);
            await kibanaUserRolesService.createRolesForMspAndMsspUsers(assignedOrgIds, params);
          } else{
            await kibanaUserRolesService.createUserRoles(orgId, params, 'all');
          }
          const response = await rp.post(url, { body: body, headers: { 'kbn-xsrf': 'anything', 'Content-Type': 'application/json' }, json: true, rejectUnauthorized: false, resolveWithFullResponse: true });
          return response.headers['set-cookie'][0].split(';');
        } catch(e) {
          logger.error(e);
          const err = new Error('Error in kibana user login');
          err.status = 400;
          return Promise.reject(err);
        }
      }
      logger.error(error);
      const err = new Error('Error in kibana user login');
      err.status = 400;
      return Promise.reject(err);
    }
  }

  createIndexPatternForNewKibanaVersion(orgId, callback = null) {
    let service = this;
    let ctr = 0;
    let titleLog = 'caveolog-' + orgId + '*';
    let titleScan = 'caveoscan-' + orgId + '*';
    let titleFlow = 'caveonetwork-' + orgId + '*-flows*';

    let urlToCreateIndex = config.kibana_url + '/api/saved_objects/index-pattern';

    let titleArr = [];
    titleArr.push(titleLog, titleScan, titleFlow);

    titleArr.forEach(function (object) {
      let payload = '';
      if (object === titleLog) {
        dashboard.forensicDashboard.Indexes[4].attributes.title = titleLog;
        payload = dashboard.forensicDashboard.Indexes[4];
      } else if (object === titleScan) {
        dashboard.forensicDashboard.Indexes[4].attributes.title = titleScan;
        payload = dashboard.forensicDashboard.Indexes[4];
      } else {
        dashboard.forensicDashboard.Indexes[4].attributes.title = titleFlow;
        payload = dashboard.forensicDashboard.Indexes[4];
      }
      var options = {
        method: 'POST',
        uri: urlToCreateIndex,
        body: payload,
        headers: {
          'kbn-xsrf': 'anything',
          'Content-Type': 'application/json',
          'Authorization': auth
        },
        json: true,
        rejectUnauthorized: config.checkKibanaCertificate
      };
      rp(options)
        .then(parsedBody => {
          if (parsedBody.attributes.title == titleLog) {
            indexPatternArr.push({ 'Logs': parsedBody.id });
            ctr++;
          } else if (parsedBody.attributes.title == titleScan) {
            indexPatternArr.push({ 'Scan': parsedBody.id });
            ctr++;
          } else {
            indexPatternArr.push({ 'Flows': parsedBody.id });
            ctr++;
          }

          if (ctr == 3) {
            service.createDefaultIndexPattern(orgId, callback);
          }
        })
        .catch(function (err) {
          if (err) {
            callback('Error in index pattern creation', false);
          }
        });
    });
  }

  getFields(orgId, sid, callback) {
    let ctr = 0;
    let titleLog = 'caveolog-' + orgId + '*';
    let titleScan = 'caveoscan-' + orgId + '*';
    let titleFlow = 'caveonetwork-' + orgId + '*-flows*';

    let fieldArr = [];

    let indexPatternArr = [];
    indexPatternArr.push(titleLog, titleScan, titleFlow);

    indexPatternArr.forEach(function (object) {
      let urlToGetFields = config.kibana_url + '/api/index_patterns/_fields_for_wildcard?pattern=' + object + '&meta_fields=%5B%22_source%22%2C%22_id%22%2C%22_type%22%2C%22_index%22%2C%22_score%22%5D';
      var option = {
        method: 'GET',
        url: urlToGetFields,
        headers: {
          'kbn-xsrf': 'anything',
          'Content-Type': 'application/json',
          'Cookie': sid
        },
        json: true,
        rejectUnauthorized: config.checkKibanaCertificate
      };

      request(option, function (err, response, body) {
        if (response && (response.statusCode == 200 || response.statusCode == 202)) {
          if (response.request.path.includes(titleLog)) {
            fieldArr.push({ 'logFields': body });
            ctr++;
          }
          if (response.request.path.includes(titleScan)) {
            fieldArr.push({ 'scanFields': body });
            ctr++;
          }
          if (response.request.path.includes(titleFlow)) {
            fieldArr.push({ 'networkFields': body });
            ctr++;
          }

          if (ctr == 3) {
            callback(false, fieldArr);
          }
        } else {
          if (response.request.path.includes(titleLog)) {
            fieldArr.push({ 'logFields': body });
            ctr++;
          }
          if (response.request.path.includes(titleScan)) {
            fieldArr.push({ 'scanFields': body });
            ctr++;
          }
          if (response.request.path.includes(titleFlow)) {
            fieldArr.push({ 'networkFields': body });
            ctr++;
          }

          if (ctr == 3) {
            callback(false, fieldArr);
          }
        }
      });
    });
  }

  updateIndexPatternFields(orgId, arrToGetIndexPatternId, indexPatternIdArr, fieldArr, auth, callback) {
    let LogUrl = 'null';
    let ScanUrl = 'null';
    let NetworkUrl = 'null';
    let ctr = 0;
    let increment = 0;
    let dashboardUrl = [];

    let titleLog = 'caveolog-' + orgId + '*';
    let titleScan = 'caveoscan-' + orgId + '*';
    let titleFlow = 'caveonetwork-' + orgId + '*-flows*';

    let payloadLog = null;
    let payloadScan = null;
    let payloadFlows = null;

    if (arrToGetIndexPatternId) {
      arrToGetIndexPatternId.filter(function (object) {
        let jsonObject = JSON.parse(object.attributes.kibanaSavedObjectMeta.searchSourceJSON);
        if (object.attributes.title == 'Events') {
          LogUrl = config.kibana_url + '/api/saved_objects/index-pattern/' + jsonObject.index;
        } else if (object.attributes.title == 'Configuration Check') {
          ScanUrl = config.kibana_url + '/api/saved_objects/index-pattern/' + jsonObject.index;
        } else {
          NetworkUrl = config.kibana_url + '/api/saved_objects/index-pattern/' + jsonObject.index;
        }
      });
    }
    if (indexPatternIdArr) {
      indexPatternIdArr.filter(function (object) {
        if (object.Logs) {
          LogUrl = config.kibana_url + '/api/saved_objects/index-pattern/' + object.Logs;
        } else if (object.Scan) {
          ScanUrl = config.kibana_url + '/api/saved_objects/index-pattern/' + object.Scan;
        } else {
          NetworkUrl = config.kibana_url + '/api/saved_objects/index-pattern/' + object.Flows;
        }
      });
    }

    fieldArr.filter(function (object) {
      if (object.logFields) {
        if (object.logFields != '') {
          dashboard.forensicDashboard.Indexes[2].attributes.fields = JSON.stringify(object.logFields.fields);
        }
        dashboard.forensicDashboard.Indexes[2].attributes.title = titleLog;
        payloadLog = dashboard.forensicDashboard.Indexes[2];
      }
      if (object.scanFields) {
        if (object.scanFields != '') {
          dashboard.forensicDashboard.Indexes[0].attributes.fields = JSON.stringify(object.scanFields.fields);
        }
        dashboard.forensicDashboard.Indexes[0].attributes.title = titleScan;
        payloadScan = dashboard.forensicDashboard.Indexes[0];
      }
      if (object.networkFields) {
        if (object.networkFields != '') {
          dashboard.forensicDashboard.Indexes[1].attributes.fields = JSON.stringify(object.networkFields.fields);
        }
        dashboard.forensicDashboard.Indexes[1].attributes.title = titleFlow;
        payloadFlows = dashboard.forensicDashboard.Indexes[1];
      }
    });

    let urlArray = [];
    urlArray.push({ 'log': LogUrl }, { 'scan': ScanUrl }, { 'network': NetworkUrl });

    urlArray.forEach(function (object) {
      let payload = '';
      let url = '';
      if (object.log) {
        url = LogUrl;
        payload = payloadLog;
      }
      if (object.scan) {
        url = ScanUrl;
        payload = payloadScan;
      }
      if (object.network) {
        url = NetworkUrl;
        payload = payloadFlows;
      }
      var options = {
        method: 'PUT',
        uri: url,
        body: payload,
        headers: {
          'kbn-xsrf': 'anything',
          'Content-Type': 'application/json',
          'Authorization': auth
        },
        json: true,
        rejectUnauthorized: config.checkKibanaCertificate
      };

      rp(options)
        .then(parsedBody => {
          ctr++;

          if (ctr == 3) {
            return ForensicsDashboard.findAll({
              where: { organization_id: orgId, type: { $ne: 'machine_learning' } },
              include: [{ all: true }]
            }).then(result => {
              result.filter(object => {
                object.dashboard_url = object.dashboard_url.split('kibanaUrl').join(config.kibana_url);
                dashboardUrl.push(object);
                increment++;
              });
            }).then(() => {
              callback(false, dashboardUrl);
            });
          }
        })
        .catch(function (err) {
          ctr++;

          if (ctr == 3) {
            return ForensicsDashboard.findAll({
              where: { organization_id: orgId, type: { $ne: 'machine_learning' } },
              include: [{ all: true }]
            }).then(result => {
              result.filter(object => {
                object.dashboard_url = object.dashboard_url.split('kibanaUrl').join(config.kibana_url);
                dashboardUrl.push(object);
                increment++;
              });
            }).then(() => {
              callback(false, dashboardUrl);
            });
          }
        });
    });
  }

};
