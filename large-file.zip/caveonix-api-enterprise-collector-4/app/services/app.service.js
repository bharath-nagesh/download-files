const fs = require('fs');
const { get } = require('lodash');
const config = require('../../configure').get();
const logger = require('./../../utils/logger').logger;
const SECRET = require('./../../utils/secret');

let instance = null;
const loggerLabel = 'AppService';

module.exports = class AppService {
  constructor() {
    logger.debug('initialized', { loggerLabel });
  }

  /**
   * Returns the instance of the App Service
   * @returns {AppService}
   */
  static getInstance() {
    if (!instance) {
      instance = new AppService();
    }

    return instance;
  }
  /**
   * Returns jwt info based off of config file properties
   * @returns {{jwtCert: string, jwtKey: string, jwtAlgorithm: (string)}}
   */
  getJwtInfo() {
    logger.debug('checking if jwtCertfile is present', { loggerLabel });

    try {
      const jwtAlgorithm = get(config, 'jwtKeyPath') && get(config, 'jwtCertPath') ? 'RS256' : 'HS256';
      const jwtCert = jwtAlgorithm === 'RS256' ? fs.readFileSync(config.jwtCertPath) + '\n' : SECRET;
      const jwtKey = jwtAlgorithm === 'RS256' ? fs.readFileSync(config.jwtKeyPath) + '\n' : SECRET;

      return { jwtAlgorithm, jwtCert, jwtKey };
    } catch (err) {
      const message = 'The jwtKeyPath and/or jwtCertPath file paths are incorrectly configured';
      const error = get(err, 'code') === 'ENOENT' ? new Error(message) : err;
      logger.warn(message, { loggerLabel });
      throw error;
    }
  }

};
