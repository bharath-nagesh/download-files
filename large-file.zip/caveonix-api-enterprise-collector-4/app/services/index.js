/*
let path = require('path');
let fs = require('fs');
let basename = path.basename(module.filename);

let services = {};

fs
  .readdirSync(__dirname)
  .filter(function(file) {
    return file.indexOf('.') !== 0 && file !== basename && file.slice(-3) === '.js';
  })
  .forEach(function(file) {
    let serviceClass = require('./' + file);
    let service = new serviceClass(services);
    let name = file.split('.')[0];
    services[name + 'Service'] = service;
    if (service.initService) {
      service.initService();
    }
  });

module.exports = services;
*/
