let models = require('../models');
const csv = require('async-csv')
let logger = require('./../../utils/logger').logger.child({

    sub_name: 'IdentityService-customControls.service',

});
module.exports = class Service {
    constructor(services) {
        this.services = services;
        logger.debug('called constructor');
    }

    async uploadCustomControls(orgId, fileType, csvFile) {
        if(fileType.toLowerCase() == 'control'){
            const parse = csv.parse
            logger.silly({ csvFile }, 'csv file')
            try {
                let output = await parse(csvFile, { columns: true, delimiter: '\t', rtrim: true, ltrim: true})
                logger.info({ output }, 'file upload output');
                for(let op=0; op<output.length; op++){
                    await models.customControls.upsert(output[op].name, output[op]);
                }
            } catch (error) {
                error.message = 'Error in adding csv data in custom controls.';
                error.status = 400
                logger.error({ error, stack: error.stack }, 'error occurred')
                throw error
            }
            return 'Successfully added custom controls data.';
        }
        if(fileType.toLowerCase() == 'mapping'){
            const parse = csv.parse
            logger.silly({ csvFile }, 'csv file')
            try {
                let colnames=['nistId', 'customId']
                let output = await parse(csvFile, { columns: colnames, delimiter: ',', rtrim: true, ltrim: true })
                logger.info({ output }, 'file upload output');
                for(let op=0; op<output.length; op++){
                    await models.nistCustomMappings.upsert(output[op].nistId, output[op].customId, output[op]);
                }
            } catch (error) {
                error.message = 'Error in adding csv data in custom mapping.'
                error.status = 400
                logger.error({ error, stack: error.stack }, 'error occurred')
                throw error;
            }
            return 'Successfully added mapping data.';
        }
    }
};
