const { get, has } = require('lodash');
const logger = require('./../../utils/logger').logger;
const LoginService = require('../apis/auth/login.service');
const loginService = new LoginService();
const Module = require('../models/module.model');
const OrgService = require('../apis/organization/org.service');
const orgService = new OrgService();
const RoleModulePermission = require('../models/roleModulePermissions.model');
const User = require('../apis/user/user.model');
const isAppliance = require('../../utils/isAppliance');

module.exports = class PermissionService {
  constructor() {
    logger.debug('called PermissionService constructor');
  }

  async checkPermission(userId, orgId, moduleName, resourceId, verb) {
    try {
      const userSessionInfo = await loginService.getUserSessionInfo(userId);

      if (!userSessionInfo) {
        const err = new Error(`Session Expired`);
        err.status = 440;
        throw err;
      }
      if (isAppliance()) return true;
      const { user } = userSessionInfo;
      const org = has(user, 'Organizations') ? user.Organizations.find(o => get(o, 'id') === orgId)
        : get(user, 'organization');
      const roleId = has(user, 'role.id') ? user.role.id : get(org, 'OrgMembers.role_id');

      // checking for the billing role
      logger.silly({ orgId: org.organization_id, userId: user.id, moduleName }, ' Checking User Role in Org');
      if (moduleName === '/billing') resourceId = user.id;
      const allowed = await this.checkResource(org, moduleName, resourceId);
      if (!allowed) {
        return false;
      }

      // getting the modules
      const mod = await Module.findOne({ where: { name: moduleName } });
      if (!mod) {
        const err = new Error(`Module named ${moduleName} not found`);
        err.status = 404;
        throw err;
      }

      // determining the permissions
      const role = await RoleModulePermission.findOne({ where: { module_id: mod.id, role_id: roleId } });
      if (!role) {
        logger.info('No Permissions Found');
        return false;
      }
      const permission = get(role, 'RoleModulePermission.permission') || get(role, 'permission');
      verb = verb.toLowerCase();
      switch (verb) {
        case 'get':
          return permission.indexOf('R') !== -1;

        case 'post':
          return permission.indexOf('C') !== -1;

        case 'put':
          return permission.indexOf('U') !== -1;

        case 'delete':
          return permission.indexOf('D') !== -1;

        default:
          return false;
      }
    } catch (error) {
      logger.error('error occurred', { error });
      if (error.status === 440) throw error;
      return false;
    }
  }

  async checkResource(userOrg, modName, resourceId) {
    if (!resourceId && modName !== '/billing') {
      return true;
    }
    const ApplicationTag = require('../apis/application/applicationTag.model');
    const Organization = require('../apis/organization/organization.model');
    const userOrgId = !isNaN(userOrg.id) ? userOrg.id : get(userOrg, 'organization_id');
    let org, chain;
    switch (modName) {
      case '/organization':
        org = await Organization.findByPk(resourceId);
        chain = await orgService.getOrgChain(userOrgId);
        const orgId = get(org, 'id');
        return (orgId === userOrgId) || (org && chain.includes(orgId));

      case '/serviceProvider':
        org = await Organization.findByPk(resourceId);
        if (!org) {
          const err = new Error('Org Not Found');
          err.status = 404;
          throw err;
        }

        const allowed = org.type === 'Provider' && org.id === userOrgId;
        return allowed;

      case '/asset':
        const Asset = require('../apis/asset/asset.model');
        const asset = await Asset.findByPk(resourceId);
        if (!asset) {
          const err = new Error('Asset Not Found');
          err.status = 404;
          throw err;
        }
        const chain1 = await orgService.getOrgChain(userOrgId);
        if (chain1.includes(asset.organization_id)) {
          return true;
        }
        return false;

      case '/application':
        const app = await ApplicationTag.findByPk(resourceId);
        const chain2 = await orgService.getOrgChain(userOrgId);
        if (chain2.includes(app.organization_id)) {
          return true;
        }
        return false;

      case '/users':
        const user1 = await User.findByPk(resourceId, { include: [{ all: true }] });
        chain = await orgService.getOrgChain(userOrgId);
        if (chain.includes(user1.Organizations[0].id) || user1.Organizations[0].type === 'Provider') {
          return true;
        }
        return false;

      case '/billing':
        const user = await User.findByPk(resourceId, { include: [{ all: true }] });
        return user.Organizations[0].type === 'Provider';

      default:
        const err = new Error('Unknown Module Type');
        err.status = 400;
        throw err;
    }
  }

  async checkInOrgChain(user, orgId) {
    const userOrgId = get(user, 'Organizations[0].id');
    if (isNaN(userOrgId)) {
      logger.error('userOrgId does not exist');
      return false;
    }
    const chain = await orgService.getOrgChain(userOrgId);
    return chain.includes(parseInt(orgId));
  }
};
