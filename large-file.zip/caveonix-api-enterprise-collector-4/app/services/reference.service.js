const { QueryTypes } = require('sequelize');
const _ = require('lodash');

const logger = require('./../../utils/logger').logger;
const config = require('../../configure').get();
const NetworkUtilsFactory = require('./../../utils/network/networkUtils/NetworkUtilsFactory');
const Utils = NetworkUtilsFactory.createNetworkUtils();
const errorHandler = require('./../../utils/errorHandler');
const PostProcessor = require('./../../utils/postProcessor');
const sequelize = require('../../config/db.conf').getConnection();

const loggerLabel = 'ReferenceService';

module.exports = class ReferenceService {
  constructor(services) {
    this.services = services;
    this.searchTermsMap = {};
    this.PostProcessor = new PostProcessor(this);
    this.nameQueryMap = {};
    logger.debug('called ReferenceService constructor', { loggerLabel });
  }

  async runNamedQuery(name, selector, params, refresh = false) {
    const fn = this.nameQueryMap[name];
    if (!fn) {
      let e = new Error('method not found');
      e.func_name = name;
      e.status = 404;
      throw e;
    }
    return fn(selector, params, refresh);
  }

  createHandler(sqlObj, postStages, expectedParams, whereTransform) {
    return async (req, res) => {
      const authToken = req.headers.es_token;
      const token = req.authInfo;
      const headers = { authToken, token };
      const queryParams = Object.assign({}, req.query, req.body);
      if (queryParams.cache) delete queryParams.cache;
      if (req.headers.source && req.headers.source === 'reportgenerator') queryParams.cache = 'false';
      const whereConditionTemp = Object.assign({}, queryParams.where, queryParams.w);
      const urlParams = req.params;
      const params = Object.assign({}, queryParams, urlParams, headers);
      const filter = params.filter || {};
      if (!params.date) params.date = Utils.getYYYY_MM_DD(new Date(Date.now()), false);
      const cacheKey = req.path;
      const mode = params.mode || 'default';
      await this.validateParams(expectedParams, params);
      if (!Array.isArray((params.selector))) params.selector = [params.selector];
      try {
        const whereCondition = await this.whereTransformMethod(sqlObj, whereTransform, whereConditionTemp, params.selector);
        let data = [];
        if (mode === 'delta') {
          data = await this.deltaMode(cacheKey, sqlObj, params, whereCondition);

          return res.json(data);
        } else if (mode === 'query' && config.development) {
          data = await this.queryMode(sqlObj, params, whereCondition);

          return res.json(data);

        } else if (mode === 'percentChange') {
          data = await this.percentChangeMode(cacheKey, sqlObj, params, whereCondition);

          return res.json(data);
        } else if (mode === 'uniqueLists') {
          data = await this.defaultMode(cacheKey, sqlObj, mode, postStages, filter, params, whereCondition);
          return res.json(data.uniqueLists);
        } else {
          data = await this.defaultMode(cacheKey, sqlObj, mode, postStages, filter, params, whereCondition);
          return res.json(data);
        }
      } catch (error) {
        return errorHandler(req, res, error);
      }
    };
  }

  createMethod(sqlObj, postStages, expectedParams) {
    return async (selector, params, refresh = false) => {

      const whereCondition = Object.assign({}, params.where, params.w);
      const filter = params.filter || {};
      if (!params.date) params.date = Utils.getYYYY_MM_DD(new Date(Date.now()), false);
      const mode = params.mode || 'default';

      await this.validateParams(expectedParams, params);
      if (!Array.isArray(selector)) {
        params.selector = [selector];
      }
      try {
        let data = [];

        data = await Promise.all(params.selector.map(async (selector) => {
          return this.validateAndExecute(`${params.name}^${params.orgId}`, sqlObj, selector, params, whereCondition);
        }));

        if (data.length === 1) data = data[0];

        if (postStages < 1 || mode == 'raw') {
          logger.debug('returning data');
          return data;
        } else {
          if (Object.keys(filter).length > 0) data = PostProcessor._postFilter(params, data);
          const transformatedData = await this.PostProcessor.process(params, postStages, data);
          return mode === 'uniqueLists' ? transformatedData.uniqueLists : transformatedData;
        }
      } catch (error) {
        logger.error({ error }, 'error');
        throw error;
      }
    };
  }

  addEndpoints(baseRoute, router, definitions, prefix = null) {
    if (Array.isArray(definitions)) {
      definitions.forEach(d => {
        const name = d.name;
        const sqlObj = d.sql;
        let route = d.route;
        const searchTerms = d.search_terms;
        const postStages = d.postStages || [];
        const expectedParams = d.expected_params || [];
        if (baseRoute) this.addSearchTerms(baseRoute, route, searchTerms);
        const nameHandler = this.createMethod(sqlObj, postStages, expectedParams);
        this.nameQueryMap[name] = nameHandler;

        if (router) {
          const handler = this.createHandler(sqlObj, postStages, expectedParams, d.whereTransform);
          if (Array.isArray(route)) {
            route.forEach((r) => {
              r = prefix ? prefix + r : r;
              router.get(r, handler);
              router.post(r, handler);
            });
          } else if (route) {
            route = prefix ? prefix + route : route;
            router.get(route, handler);
            router.post(route, handler);
          }
        }
      });

    }
  }

  async validateSql(sqlObj, selector, date = new Date(), condition = {}, params = {}) {
    if (typeof sqlObj === 'string') return sqlObj;

    const sql = sqlObj[selector] || sqlObj.default;
    if (!sql) {
      const err = new Error('No Filter Selected');
      err.status = 404;
      throw err;
    }
    date = Utils.getYYYY_MM_DD(date);
    logger.info({ condition }, 'mapped condition');
    return sql(condition, selector, date, params);
  }

  async validateParams(expectedParams, params) {
    logger.info(params, 'the params');
    for (let i = 0; i < expectedParams.length; i++) {
      const p = expectedParams[i];
      logger.info(p, 'the expected param');
      if (params[p] == null) {
        const err = new Error('Missing an expected param: ' + expectedParams);
        err.status = 400;
        throw err;
      }
    }
  }

  async validateAndExecute(baseUrl, sqlObj, selector, params, whereCondition = {}) {
    const date = params.date || new Date();
    //TODO create actual return results class that classifies sql vs result. if sql runs sequelize.query
    let sql = await this.validateSql(sqlObj, selector, date, whereCondition, params);
    const arr = Object.entries(whereCondition) || [];
    const value = (arr.sort().map((entry) => {
      return `${entry[0]}#${entry[1]}`;
    }).join('^'));
    let data = [];
    let d;

    if (!params.refresh || params.refresh === 'false') {
      d = await this.cache.get(`${baseUrl}#${selector}#date#${params.date}#${value}`);
      logger.silly({ d }, 'cache returned data');
    }

    if (d && (params.refresh !== true && params.refresh !== 'true')) {
      logger.silly({ params, d }, 'returning cached data');
      return d;
    }
    const initialOffset = parseInt(params.offset) || 0;
    const initialLimit = params.limit || 10000;
    try {
      if (!_.isString(sql)) {
        data = await sql;
      } else if (_.isString(sql) && sql.toLowerCase().slice(-100).includes('limit')) {
        data = await sequelize.query(sql, {
          replacements: params,
          type: QueryTypes.SELECT
        });
      } else {
        let q = 0;
        if (_.isString(sql) && sql.trim().slice(-1) === ';') sql = sql.trim().slice(0, -1);
        while (q >= 0 && data.length <= initialLimit) {
          const tempdata = await sequelize.query(sql + ` LIMIT 1000 OFFSET ${q * 1000 + initialOffset}`, {
            replacements: params,
            type: QueryTypes.SELECT
          });
          q++;
          data.push(...tempdata);
          // end case
          if (tempdata.length < 1000) q = -1;
        }
      }
    } catch (error) {
      await this.cache.set(`${baseUrl}#${selector}#date#${params.date}#${value}`, null);

      if (Object.keys(whereCondition).length > 0 && error.message.startsWith('column')) {
        logger.error({ error, stack: error.stack }, 'the error');
        return [];
      }
      logger.error({ error, stack: error.stack }, 'the error');
      throw error;
    }

    await this.cache.set(`${baseUrl}#${selector}#date#${params.date}#${value}`, data);

    return data;
  }

  /*
  MODES
   */
  async defaultMode(cacheKey, sqlObj, mode, postStages, filter, params, whereCondition) {

    let data = await Promise.all(params.selector.map(async (selector) => {
      return this.validateAndExecute(cacheKey, sqlObj, selector, params, whereCondition, params);
    }));

    if (data.length === 1) data = data[0];
    if (Object.keys(filter).length > 0) data = PostProcessor._postFilter(params, data);

    if (postStages < 1 || mode === 'raw') {
      logger.debug('returning data');
      return data;
    }
    const transformedData = await this.PostProcessor.process(params, postStages, data);
    return transformedData;

  }

  async percentChangeMode(cacheKey, sqlObj, params, whereCondition) {
    const property = params.property;
    const secondParams = Object.assign({}, params);
    secondParams.date = secondParams.startDate;
    params.date = params.endDate;
    if (!params.date || !secondParams.date) {
      const e = new Error('missing date params for percentChange mode');
      e.status = 400;
      throw e;
    }
    if (params.selector.length > 1) {
      const e = new Error('too many selectors given for percentChangeMode mode');
      e.status = 400;
      throw e;
    }
    const selector = params.selector[0];
    const data = await Promise.all([
      this.validateAndExecute(cacheKey, sqlObj, selector, secondParams, whereCondition),
      this.validateAndExecute(cacheKey, sqlObj, selector, params, whereCondition)
    ]);

    const deltaStages = [{ type: 'percentChange', transformer: property }];
    return this.PostProcessor.process(params, deltaStages, data);
  }

  async queryMode(sqlObj, params, whereCondition) {
    return Promise.all(params.selector.map(async (selector) => {
      const date = params.date || new Date();
      return this.validateSql(sqlObj, selector, date, whereCondition);
    }));
  }

  async deltaMode(cacheKey, sqlObj, params, whereCondition) {
    const property = params.property || 'id';
    const secondParams = Object.assign({}, params);
    secondParams.date = secondParams.startDate;
    params.date = params.endDate;
    if (!params.date || !secondParams.date) {
      const e = new Error('missing date params for delta mode');
      e.status = 400;
      throw e;
    }
    if (params.selector.length > 1) {
      const e = new Error('too many selectors given for delta mode');
      e.status = 400;
      throw e;
    }
    const selector = params.selector[0];
    const data = await Promise.all([
      this.validateAndExecute(cacheKey, sqlObj, selector, secondParams, whereCondition),
      this.validateAndExecute(cacheKey, sqlObj, selector, params, whereCondition)
    ]);

    const deltaStages = [{ type: 'delta', transformer: property }];

    return this.PostProcessor.process(params, deltaStages, data);
  }

  /* */
  addSearchTerms(baseRoute, routes, searchTerms) {
    if (!Array.isArray(searchTerms)) {
      searchTerms = [searchTerms];
    }
    if (!Array.isArray(routes)) {
      routes = [routes];
    }
    for (let i = 0; i < searchTerms.length; i++) {
      const term = searchTerms[i];
      const route = routes[0];
      const fullRoute = route[0] === '/' && baseRoute[baseRoute.length - 1] === '/' ? baseRoute.slice(0, -1) + route : baseRoute + route;
      if (term) this.searchTermsMap[term] = fullRoute;
    }
  }

  async getCache() {
    return JSON.parse(this.cache.cache.exportJson());
  }

  getSearchTerms() {
    return Promise.resolve(this.searchTermsMap);
  }

  async whereTransformMethod(sqlObj, whereTransformObj = {}, whereConditionTemp, selector) {
    let whereTransformInfo = {};
    const currentSelector = selector[0] ? selector[0] : 'default';
    if (whereTransformObj && _.isFunction(whereTransformObj.default)) {
      try {
        whereTransformInfo = whereTransformObj.default(currentSelector);
      } catch (e) {
        logger.error(e);
        whereTransformInfo = whereTransformObj[currentSelector];
      }
    } else if (whereTransformObj) {
      whereTransformInfo = whereTransformObj[currentSelector] || whereTransformObj.default;
    } else {
      whereTransformInfo = {};
    }
    const whereTransformMap = whereTransformInfo ? whereTransformInfo.mapping : null;
    const whereCondition = whereTransformMap ? _.chain(whereConditionTemp).entries().reduce((result, [whereConditionName, filterValue]) => {
      const label = whereTransformMap[whereConditionName] || whereConditionName;
      result[label] = filterValue;
      return result;
    }, {}).value() : whereConditionTemp;
    return whereCondition;
  }
};
