const Sequelize = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();

/**
 * @swagger
 * components:
 *   schemas:
 *     AwsRegions:
 *       type: object
 *       properties:
 *         name:
 *           type: string
 *         fullName:
 *           type: string
 * @param sequelize
 */
const AwsRegions = sequelize.define(
  'awsRegions',
  {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    name: { type: Sequelize.STRING, field: 'name' },
    fullName: { type: Sequelize.STRING, field: 'full_name' }
  },
  { timestamps: false, freezeTableName: true, tableName: 'aws_regions', underscored: true }
);

module.exports = AwsRegions;
