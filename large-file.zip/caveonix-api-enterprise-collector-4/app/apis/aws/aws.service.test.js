const expect = require('chai').expect;
const proxyquire = require('proxyquire').noCallThru();

describe('AWSService', function () {
  beforeEach(() => {

  });

  describe('getAWSVpcRegionsById', () => {
    it('getAWSVpcRegionsById', async () => {

      const Id = 1;
      const response = {
        data: 1
      };

      class AwsVpcRegionsStubb {
        constructor() { }

        static findOne() {
          return Promise.resolve(response);
        }
      };

      class AwsRegionsStub{
        constructor() { }
      }

      class AwsVpcAdminHosts{
        constructor() { }
      }

      class Organization{
        constructor() { }
      }
      const AWSService = proxyquire('./aws.service', {
        './awsVpcRegions.model': AwsVpcRegionsStubb,
        './awsRegions.model':AwsRegionsStub,
        './awsVpcAdminHosts.model':AwsVpcAdminHosts,
        '../organization/organization.model':Organization
      });
      const awsService = new AWSService();
      const data = await awsService.getAWSVpcRegionsById(Id);
      expect(data).to.be.equal(response);
    });
  });

  describe('getAllAWSVpcRegions', () => {
    it('getAllAWSVpcRegions', async () => {

      const limit = 10;
      const offset = 0;
      const response = [{
        data: 1
      }];

      class AwsVpcRegionsStubb {
        constructor() { }

        static findAll() {
          return Promise.resolve(response);
        }
      };

      class AwsRegionsStub{
        constructor() { }
      }

      class AwsVpcAdminHosts{
        constructor() { }
      }

      class Organization{
        constructor() { }
      }

      const sequelizeStub = {
        getConnection() {
          return {
            Op: { eq: 'eq' },
            query() {
              return response;
            },
            where() {
              return 'where x=1';
            },
            col() {
              return 'small';
            },
            fn() {
              return true;
            }
          };
        }
      };

      const AWSService = proxyquire('./aws.service', {
        './awsVpcRegions.model': AwsVpcRegionsStubb,
        './awsRegions.model':AwsRegionsStub,
        './awsVpcAdminHosts.model':AwsVpcAdminHosts,
        '../organization/organization.model':Organization,
        '../../../config/db.conf': sequelizeStub
      });
      const awsService = new AWSService();
      let filter = 'region';
      const region = 'region';
      const availZone = 'region';
      const vpcName = 'region';
      let data = await awsService.getAllAWSVpcRegions(filter, region, availZone, vpcName, limit, offset);
      expect(data).to.be.equal(response);
      filter = 'avail_zone';
      data = await awsService.getAllAWSVpcRegions(filter, region, availZone, vpcName, limit, offset);
      expect(data).to.be.equal(response);
      filter = 'vpc_name';
      data = await awsService.getAllAWSVpcRegions(filter, region, availZone, vpcName, limit, offset);
      expect(data).to.be.equal(response);
    });
  });

  describe('getAllAWSVpcRegionsCount', () => {
    it('getAllAWSVpcRegionsCount', async () => {

      const count = 1;
      const response = {
        data: 1
      };

      class AwsVpcRegionsStubb {
        constructor() { }

        static count() {
          return Promise.resolve(count);
        }
      };

      class AwsRegionsStub{
        constructor() { }
      }

      class AwsVpcAdminHosts{
        constructor() { }
      }

      class Organization{
        constructor() { }
      }
      const AWSService = proxyquire('./aws.service', {
        './awsVpcRegions.model': AwsVpcRegionsStubb,
        './awsRegions.model':AwsRegionsStub,
        './awsVpcAdminHosts.model':AwsVpcAdminHosts,
        '../organization/organization.model':Organization
      });
      const awsService = new AWSService();
      const data = await awsService.getAllAWSVpcRegionsCount();
      expect(data).to.be.equal(count);
    });
  });

  describe('getAllAWSRegions', () => {
    it('getAllAWSRegions', async () => {

      const limit = 10;
      const offset = 0;
      const response = {
        data: 1
      };

      class AwsRegionsStub {
        constructor() { }

        static findAll() {
          return Promise.resolve(response);
        }
      };

      class AwsVpcRegionsStubb{
        constructor() { }
      }

      class AwsVpcAdminHosts{
        constructor() { }
      }

      class Organization{
        constructor() { }
      }
      const AWSService = proxyquire('./aws.service', {
        './awsVpcRegions.model': AwsVpcRegionsStubb,
        './awsRegions.model':AwsRegionsStub,
        './awsVpcAdminHosts.model':AwsVpcAdminHosts,
        '../organization/organization.model':Organization
      });
      const awsService = new AWSService();
      const data = await awsService.getAllAWSRegions(limit, offset);
      expect(data).to.be.equal(response);
    });
  });

  describe('getAWSVpcAdminHostById', () => {
    it('getAWSVpcAdminHostById', async () => {

      const Id = 10;
      const response = {
        data: 1
      };

      class AwsRegionsStub {
        constructor() { }
      };

      class AwsVpcRegionsStubb{
        constructor() { }
      }

      class AwsVpcAdminHosts{
        constructor() { }
      }

      class Organization{
        constructor() { }
      }

      const sequelizeStub = {
        getConnection() {
          return {
            Op: { eq: 'eq' },
            query() {
              return response;
            },
            where() {
              return 'where x=1';
            },
            col() {
              return 'small';
            },
            fn() {
              return 'small';
            },
            QueryTypes:{
              SELECT:'SELECT'
            }
          };
        }
      };

      const AWSService = proxyquire('./aws.service', {
        './awsVpcRegions.model': AwsVpcRegionsStubb,
        './awsRegions.model':AwsRegionsStub,
        './awsVpcAdminHosts.model':AwsVpcAdminHosts,
        '../organization/organization.model':Organization,
        '../../../config/db.conf': sequelizeStub
      });
      const awsService = new AWSService();
      const data = await awsService.getAWSVpcAdminHostById(Id);
      expect(data).to.be.equal(response);
    });
  });

  describe('getAllAWSVpcAdminHosts', () => {
    it('getAllAWSVpcAdminHosts', async () => {

      const Id = 10;
      const orgchain = [1,2,3];
      const response = {
        data: 1
      };

      class AwsRegionsStub {
        constructor() { }
      };

      class AwsVpcRegionsStubb{
        constructor() { }
      }

      class AwsVpcAdminHosts{
        constructor() { }
      }

      class Organization{
        constructor() { }

        static getOrgChain(){
          return Promise.resolve(orgchain);
        }
      }

      const sequelizeStub = {
        getConnection() {
          return {
            Op: { eq: 'eq' },
            query() {
              return response;
            },
            where() {
              return 'where x=1';
            },
            col() {
              return 'small';
            },
            fn() {
              return 'small';
            },
            QueryTypes:{
              SELECT:'SELECT'
            }
          };
        }
      };

      const AWSService = proxyquire('./aws.service', {
        './awsVpcRegions.model': AwsVpcRegionsStubb,
        './awsRegions.model':AwsRegionsStub,
        './awsVpcAdminHosts.model':AwsVpcAdminHosts,
        '../organization/organization.model':Organization,
        '../../../config/db.conf': sequelizeStub
      });
      const awsService = new AWSService();
      const data = await awsService.getAllAWSVpcAdminHosts(Id);
      expect(data).to.be.equal(response);
    });
  });

  describe('getAllAWSVpcAdminHostsCount', () => {
    it('getAllAWSVpcAdminHostsCount', async () => {

      const count = 1;
      const response = {
        data: 1
      };

      class AwsVpcRegionsStubb {
        constructor() { }
      };

      class AwsRegionsStub{
        constructor() { }
      }

      class AwsVpcAdminHosts{
        constructor() { }

        static count() {
          return Promise.resolve(count);
        }
      }

      class Organization{
        constructor() { }
      }
      const AWSService = proxyquire('./aws.service', {
        './awsVpcRegions.model': AwsVpcRegionsStubb,
        './awsRegions.model':AwsRegionsStub,
        './awsVpcAdminHosts.model':AwsVpcAdminHosts,
        '../organization/organization.model':Organization
      });
      const awsService = new AWSService();
      const data = await awsService.getAllAWSVpcAdminHostsCount();
      expect(data).to.be.equal(count);
    });
  });

  describe('createAWSVpcAdminHost', () => {
    it('createAWSVpcAdminHost', async () => {

      const orgId = 1;
      const params = {
        vpc_name : 'vpc-0001a'
      };
      const findoneData = false;
      const response = {
        data: 1
      };

      class AwsVpcRegionsStubb {
        constructor() { }
      };

      class AwsRegionsStub{
        constructor() { }
      }

      class AwsVpcAdminHosts{
        constructor() { }

        static create() {
          return Promise.resolve(params);
        }

        static findOne() {
          return Promise.resolve(findoneData);
        }

      }

      class Organization{
        constructor() { }
      }

      const sequelizeStub = {
        getConnection() {
          return {
            Op: { eq: 'eq' },
            query() {
              return response;
            },
            where() {
              return 'where x=1';
            },
            col() {
              return 'small';
            },
            fn() {
              return 'small';
            },
            QueryTypes:{
              SELECT:'SELECT'
            }
          };
        }
      };
      const AWSService = proxyquire('./aws.service', {
        './awsVpcRegions.model': AwsVpcRegionsStubb,
        './awsRegions.model':AwsRegionsStub,
        './awsVpcAdminHosts.model':AwsVpcAdminHosts,
        '../organization/organization.model':Organization,
        '../../../config/db.conf': sequelizeStub
      });
      const awsService = new AWSService();
      const data = await awsService.createAWSVpcAdminHost(params, orgId);
      expect(data).to.be.equal(params);
    });
  });

  describe('updateAWSVpcAdminHostById', () => {
    it('updateAWSVpcAdminHostById', async () => {

      const orgId = 1;
      const params = {
        vpc_name : 'vpc-0001a'
      };
      const response = {
        data: 1
      };

      class AwsVpcRegionsStubb {
        constructor() { }
      };

      class AwsRegionsStub{
        constructor() { }
      }

      class AwsVpcAdminHosts{
        constructor() { }

        static update() {
          return Promise.resolve(params);
        }

        static findByPk() {
          return Promise.resolve(params);
        }
        
        static findOne() {
          return Promise.resolve(false);
        }
        
      }

      class Organization{
        constructor() { }
      }

      const sequelizeStub = {
        getConnection() {
          return {
            Op: { eq: 'eq' },
            query() {
              return response;
            },
            where() {
              return 'where x=1';
            },
            col() {
              return 'small';
            },
            fn() {
              return 'small';
            },
            QueryTypes:{
              SELECT:'SELECT'
            }
          };
        }
      };
      const AWSService = proxyquire('./aws.service', {
        './awsVpcRegions.model': AwsVpcRegionsStubb,
        './awsRegions.model':AwsRegionsStub,
        './awsVpcAdminHosts.model':AwsVpcAdminHosts,
        '../organization/organization.model':Organization,
        '../../../config/db.conf': sequelizeStub
      });
      const awsService = new AWSService();
      const data = await awsService.updateAWSVpcAdminHostById(params, orgId);
      expect(data).to.be.equal(params);
    });
  });

  
  describe('deleteAWSVpcAdminHostById', () => {
    it('deleteAWSVpcAdminHostById', async () => {

      const Id = 1;
      const params = {
        vpc_name : 'vpc-0001a'
      };
      const response = {
        data: 1
      };

      class AwsVpcRegionsStubb {
        constructor() { }
      };

      class AwsRegionsStub{
        constructor() { }
      }

      class AwsVpcAdminHosts{
        constructor() { }

        static update() {
          return Promise.resolve(params);
        }

        static findOne() {
          return Promise.resolve(params);
        }

      }

      class Organization{
        constructor() { }
      }

      const sequelizeStub = {
        getConnection() {
          return {
            Op: { eq: 'eq' },
            query() {
              return response;
            },
            where() {
              return 'where x=1';
            },
            col() {
              return 'small';
            },
            fn() {
              return 'small';
            },
            QueryTypes:{
              SELECT:'SELECT'
            }
          };
        }
      };
      const AWSService = proxyquire('./aws.service', {
        './awsVpcRegions.model': AwsVpcRegionsStubb,
        './awsRegions.model':AwsRegionsStub,
        './awsVpcAdminHosts.model':AwsVpcAdminHosts,
        '../organization/organization.model':Organization,
        '../../../config/db.conf': sequelizeStub
      });
      const awsService = new AWSService();
      const data = await awsService.deleteAWSVpcAdminHostById(Id);
      expect(data).to.be.equal(params);
    });
  });

  describe('deleteAWSVpcAdminHostById', () => {
    it('deleteAWSVpcAdminHostById', async () => {

      const Id = 1;
      const params = {
        vpc_name : 'vpc-0001a'
      };
      const response = {
        data: 1
      };

      class AwsVpcRegionsStubb {
        constructor() { }
      };

      class AwsRegionsStub{
        constructor() { }
      }

      class AwsVpcAdminHosts{
        constructor() { }

        static update() {
          return Promise.resolve(params);
        }

        static findOne() {
          return Promise.resolve(params);
        }

      }

      class Organization{
        constructor() { }
      }

      const sequelizeStub = {
        getConnection() {
          return {
            Op: { eq: 'eq' },
            query() {
              return response;
            },
            where() {
              return 'where x=1';
            },
            col() {
              return 'small';
            },
            fn() {
              return 'small';
            },
            QueryTypes:{
              SELECT:'SELECT'
            }
          };
        }
      };
      const AWSService = proxyquire('./aws.service', {
        './awsVpcRegions.model': AwsVpcRegionsStubb,
        './awsRegions.model':AwsRegionsStub,
        './awsVpcAdminHosts.model':AwsVpcAdminHosts,
        '../organization/organization.model':Organization,
        '../../../config/db.conf': sequelizeStub
      });
      const awsService = new AWSService();
      const data = await awsService.deleteAWSVpcAdminHostById(Id);
      expect(data).to.be.equal(params);
    });
  });

  describe('deleteMultipleAWSVpcAdminHosts', () => {
    it('deleteMultipleAWSVpcAdminHosts', async () => {

      const Id = 1;
      const params = {
        vpc_name : 'vpc-0001a'
      };
      const response = {
        data: 1
      };

      class AwsVpcRegionsStubb {
        constructor() { }
      };

      class AwsRegionsStub{
        constructor() { }
      }

      class AwsVpcAdminHosts{
        constructor() { }

        static update() {
          return Promise.resolve(params);
        }

        static findAll() {
          return Promise.resolve(params);
        }

      }

      class Organization{
        constructor() { }
      }

      const sequelizeStub = {
        getConnection() {
          return {
            Op: { eq: 'eq' },
            query() {
              return response;
            },
            where() {
              return 'where x=1';
            },
            col() {
              return 'small';
            },
            fn() {
              return 'small';
            },
            QueryTypes:{
              SELECT:'SELECT'
            }
          };
        }
      };
      const AWSService = proxyquire('./aws.service', {
        './awsVpcRegions.model': AwsVpcRegionsStubb,
        './awsRegions.model':AwsRegionsStub,
        './awsVpcAdminHosts.model':AwsVpcAdminHosts,
        '../organization/organization.model':Organization,
        '../../../config/db.conf': sequelizeStub
      });
      const awsService = new AWSService();
      const data = await awsService.deleteMultipleAWSVpcAdminHosts(Id);
      expect(data).to.be.equal(params);
    });
  });


});
