const AWSService = require('./aws.service');
const checkId = require('../../../utils/checkId');
const errorHandler = require('../../../utils/errorHandler');
const Validator = require('../../../utils/validator');
const CheckIp = require('../../../utils/checkIp');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-aws.controller'
});
const paginate = require('../../middlewares/paginate.middleware');
const awsService = new AWSService();

module.exports = class AWSController {
  //DO NOT COPY, NOT CLEAN IMPLEMENTATION
  async getOVAFromS3(req, res) {

    try {
      awsService.getOVA(res, errorHandler);

    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  //DO NOT COPY NOT CLEAN IMPLEMENTATION
  async getPostScriptFromS3(req, res) {

    try {
      awsService.getPostInstallScript(res, errorHandler);

    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getAllAWSVpcRegions(req, res) {
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    const filter = req.query.filter || null;
    const region = req.query.region || null;
    const availZone = req.query.avail_zone || null;
    const vpcName = req.query.vpc_name || null;
    try {
      const results = await awsService.getAllAWSVpcRegions(filter, region, availZone, vpcName, limit, offset);
      const itemCount = await awsService.getAllAWSVpcRegionsCount();
      const pageCount = Math.ceil(itemCount / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        AWSVpcRegions: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getAWSVpcRegionsById(req, res) {
    const awsVpcRegionsId = req.params.awsVpcRegionsId;
    if (checkId(awsVpcRegionsId)) {
      logger.error({ awsVpcRegionsId }, 'Bad awsVpcRegionsId');
      const error = new Error('Bad awsVpcRegionsId');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const awsVpcRegions = await awsService.getAWSVpcRegionsById(awsVpcRegionsId);
      return res.json(awsVpcRegions);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getAWSVpcNameByOrgId(req, res) {
    const orgId = req.params.orgId || req.params.serviceProviderId;
    try {
      const awsVpcNames = await awsService.getAWSVpcNameByOrgId(orgId);
      return res.json(awsVpcNames);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getAllAWSVpcAdminHosts(req, res) {
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    const orgId = req.params.orgId || req.params.serviceProviderId;
    try {
      const results = await awsService.getAllAWSVpcAdminHosts(orgId,limit, offset);
      const itemCount = await awsService.getAllAWSVpcAdminHostsCount();
      const pageCount = Math.ceil(itemCount / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        AWSVpcAdminHosts: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getAWSVpcAdminHostById(req, res) {
    const awsVpcAdminHostId = req.params.awsVpcAdminHostId;
    if (checkId(awsVpcAdminHostId)) {
      logger.error({ awsVpcAdminHostId }, 'Error with awsVpcAdminHostId');
      const error = new Error('Error with Org Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const awsVpcAdminHost = await awsService.getAWSVpcAdminHostById(awsVpcAdminHostId);
      return res.json(awsVpcAdminHost);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async createAWSVpcAdminHost(req, res) {
    const params = req.body;
    const orgId = req.params.orgId;
    params.checkIp = CheckIp.checkIp(params.admin_range);
    try {
      params.checkPorts = params.ports.split(',').map(a => { return a.trim(); });
      params.ports=params.checkPorts.join();
      await Validator.validateParams({
        vpc_name: 'required|string',
        region: 'required|string',
        avail_zone: 'required|string',
        admin_range: 'required|string',
        isActive: 'required|in:enabled,disabled,true',
        ports: 'required|string',
        checkIp: 'required|notIn:false',
        checkPorts: 'required|array',
        'checkPorts.*': 'required|integer|in:22,3389'
      }, params, { checkIp: 'Invalid Admin Range Provided', 'checkPorts.*': 'Invalid Ports Provided' });

    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    try {

      const AWSVpcAdminHost = await awsService.createAWSVpcAdminHost(params, orgId);
      return res.json(AWSVpcAdminHost);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async updateAWSVpcAdminHostById(req, res) {
    const update = req.body;
    const orgId = req.params.orgId;
    const params = req.body;
    const awsVpcAdminHostId = req.params.awsVpcAdminHostId;
    params.checkIp = CheckIp.checkIp(params.admin_range);
    try {
      params.checkPorts = params.ports.split(',').map(a => { return a.trim(); });
      params.ports=params.checkPorts.join();
      await Validator.validateParams({
        vpc_name: 'required|string',
        region: 'required|string',
        avail_zone: 'required|string',
        admin_range: 'required|string',
        isActive: 'required|in:enabled,disabled,true',
        ports: 'required|string',
        checkIp: 'required|notIn:false',
        checkPorts: 'required|array',
        'checkPorts.*': 'required|integer|in:22,3389'
      }, params, { checkIp: 'Invalid Admin Range Provided', 'checkPorts.*': 'Invalid Ports Provided' });

    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    try {
      const AWSVpcAdminHost = await awsService.updateAWSVpcAdminHostById(update, awsVpcAdminHostId, orgId);
      return res.json(AWSVpcAdminHost);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async deleteAWSVpcAdminHostById(req, res) {
    const awsVpcAdminHostId = req.params.awsVpcAdminHostId;
    if (checkId(awsVpcAdminHostId)) {
      logger.error('Invalid parameters for AWSVpcAdminHost creation');
      const error = new Error('Bad awsVpcRegionsId');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const AWSVpcAdminHost = await awsService.deleteAWSVpcAdminHostById(awsVpcAdminHostId);
      logger.info({ AWSVpcAdminHost, awsVpcAdminHostId }, 'deleted');
      return res.json(AWSVpcAdminHost);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async deleteMultipleAWSVpcAdminHosts(req, res) {
    const awsVpcAdminHostId = req.query.id || '-1';

    try {

      const awsVpcAdminHostIdArr = awsVpcAdminHostId.split(',');
      const AWSVpcAdminHosts = await awsService.deleteMultipleAWSVpcAdminHosts(awsVpcAdminHostIdArr);
      return res.json(AWSVpcAdminHosts);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }

  }

  async getAllAWSRegions(req, res) {
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    try {

      const results = await awsService.getAllAWSRegions(limit, offset);
      const itemCount = await awsService.getAllAWSRegionsCount();
      const pageCount = Math.ceil(itemCount / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        AWSRegions: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }
};
