const AWSController = require('./aws.controller');

/**
 * @swagger
 * tags:
 *  - name: AWS VPC
 *    description: AWS VPC endpoints
 */
module.exports = class AWSRoutes {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.awsController = new AWSController();
      this.initOrganization();

    }
  }

  initOrganization() {
    this.router.get(`${this.path}/OVA`, this.awsController.getOVAFromS3);
    this.router.get(`${this.path}/postscript`, this.awsController.getPostScriptFromS3);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/aws/vpcRegion:
     *   get:
     *     tags:
     *       - AWS VPC
     *     summary: Gets a list of all AWS VPC Regions
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of regions
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/vpcRegion`, this.awsController.getAllAWSVpcRegions);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/aws/region:
     *   get:
     *     tags:
     *       - AWS VPC
     *     summary: Gets a list of all AWS Regions
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of regions
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/region`, this.awsController.getAllAWSRegions);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/aws/vpcRegion/{awsVpcRegionsId}:
     *   get:
     *     tags:
     *       - AWS VPC
     *     summary: Gets a AWS VPC Region by its id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: awsVpcRegionsId
     *         description: The id of the specified AWS VPC Region.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: vpc region
     */
    this.router.get(`${this.path}/vpcRegion/:awsVpcRegionsId`, this.awsController.getAWSVpcRegionsById);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/aws/vpcName:
     *   get:
     *     tags:
     *       - AWS VPC
     *     summary: Gets a AWS VPC Name by OrgID
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: vpc names
     */
    this.router.get(`${this.path}/vpcName`, this.awsController.getAWSVpcNameByOrgId);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/aws/vpcAdminHost:
     *   get:
     *     tags:
     *       - AWS VPC
     *     summary: Gets a list of AWS VPC Admin Hosts
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: AWS VPC
     *
     */
    this.router.get(`${this.path}/vpcAdminHost`, this.awsController.getAllAWSVpcAdminHosts);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/aws/vpcAdminHost/{awsVpcAdminHostId}:
     *   get:
     *     tags:
     *       - AWS VPC
     *     summary: Gets a AWS VPC Admin Host by it's id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: awsVpcAdminHostId
     *         description: The id of the AWS VPC Admin Host.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: AWS VPC updated
     */
    this.router.get(`${this.path}/vpcAdminHost/:awsVpcAdminHostId`, this.awsController.getAWSVpcAdminHostById);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/aws/vpcAdminHost:
     *   post:
     *     tags:
     *       - AWS VPC
     *     summary: Creates a VPC Admin host
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/AWS VPC'
     *     responses:
     *       200:
     *         description: AWS VPS AdminHost
     */
    this.router.post(`${this.path}/vpcAdminHost`, this.awsController.createAWSVpcAdminHost);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/aws/vpcAdminHost/{awsVpcAdminHostId}:
     *   put:
     *     tags:
     *       - AWS VPC
     *     summary: Updates a AWS VPC Admin Host
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: awsVpcAdminHostId
     *         description: The AWS VPC Admin Host's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/AWS VPC'
     *     responses:
     *       200:
     *         description: An AWS VPC Admin Host
     */
    this.router.put(`${this.path}/vpcAdminHost/:awsVpcAdminHostId`, this.awsController.updateAWSVpcAdminHostById);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/aws/vpcAdminHost/{awsVpcAdminHostId}:
     *   delete:
     *     tags:
     *       - AWS VPC
     *     summary: Deletes a AWS VPC Admin Host
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: awsVpcAdminHostId
     *         description: A AWS Vpc Admin Host's id.
     *         in: query
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: AWS VPC Admin Host is successfully deleted
     */
    this.router.delete(`${this.path}/vpcAdminHost/:awsVpcAdminHostId`, this.awsController.deleteAWSVpcAdminHostById);

    /**
     *
     *
     * /api/organization/{orgId}/AWSVpcAdminHost/{awsVpcAdminHostId}:
     *   delete:
     *     tags:
     *       - AWS VPC
     *     summary: Deletes a AWS VPC Admin Host
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: awsVpcAdminHostId
     *         description: A AWS Vpc Admin Host's id.
     *         in: query
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: AWS VPC Admin Host is successfully deleted
     */
    this.router.delete(`${this.path}/vpcAdminHost`, this.awsController.deleteMultipleAWSVpcAdminHosts);
  }
};
