const AwsRegions = require('./awsRegions.model');
const AwsVpcAdminHosts = require('./awsVpcAdminHosts.model');
const AwsVpcRegions = require('./awsVpcRegions.model');
const removeSpace = require('../../../utils/checkSpaces');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-awsService.service'
});
const Organization = require('../organization/organization.model')
const config = require('../../../configure').get();
const _ = require('lodash');
const AWS = require('aws-sdk');
const sequelize = require('../../../config/db.conf').getConnection();
AWS.Request.prototype.forwardToExpress = function forwardToExpress(res, next) {
  this
    .on('httpHeaders', function (code, headers) {
      if (code < 300) {
        res.set(_.pick(headers, 'content-type', 'content-length', 'last-modified'));
      }
    })
    .createReadStream()
    .on('error', next)
    .pipe(res);
};

const AwsS3 = require('aws-sdk/clients/s3');

const s3 = new AwsS3({

  accessKeyId: config.awsKey,
  secretAccessKey: config.awsSecret
});

/**
 * AWS Service that handles all of the queries to the database
 * @type {AWSService}
 */
module.exports = class AWSService {
  constructor() {
    logger.debug('called AWS Service constructor');
  }

  getAWSVpcRegionsById(Id) {
    return AwsVpcRegions.findOne({ where: { id: Id } });
  }

  async getAWSVpcNameByOrgId(orgId){
    const data = await sequelize.query('SELECT distinct vpc_name from aws_vpc_regions where asset_id in (select asset_id from assets where organization_id = :orgId);', {
      replacements: { orgId },type: sequelize.QueryTypes.SELECT
    });
    return data;
  }

  getAllAWSVpcRegions(filter, region, availZone, vpcName, limit, offset) {
    if (filter && filter === 'region') {
      return AwsVpcRegions.findAll(
        {
          limit: limit, offset: offset, attributes: [[sequelize.fn('DISTINCT', sequelize.col('region')), 'region']]
        });
    } else if (filter && filter === 'avail_zone') {
      const regionJson = region ? { region } : null;
      return AwsVpcRegions.findAll(
        {
          where: regionJson,
          limit: limit,
          offset: offset,
          attributes: [[sequelize.fn('DISTINCT', sequelize.col('avail_zone')), 'avail_zone']]
        });
    } else if (filter && filter === 'vpc_name') {
      const jsonVPC = {};
      region ? jsonVPC.region = region : null;
      availZone ? jsonVPC.avail_zone = availZone : null;
      return AwsVpcRegions.findAll(
        {
          where: jsonVPC,
          limit: limit,
          offset: offset,
          attributes: [[sequelize.fn('DISTINCT', sequelize.col('vpc_name')), 'vpc_name']]
        });
    }
    return AwsVpcRegions.findAll(
      { order: [['vpc_name', 'ASC']], limit: limit, offset: offset });
  }

  getAllAWSVpcRegionsCount() {
    return AwsVpcRegions.count({});
  }

  getAllAWSRegions(limit, offset) {
    return AwsRegions.findAll(
      { order: [['name', 'ASC']], limit: limit, offset: offset });
  }

  getAllAWSRegionsCount() {
    return AwsRegions.count({});
  }

  async getAWSVpcAdminHostById(Id) {
    const data = await sequelize.query('SELECT reg.vpc_name,reg.avail_zone,reg.region,ahost.* from aws_vpc_admin_hosts ahost INNER JOIN  (SELECT * from aws_vpc_regions WHERE id IN (SELECT max(id) from aws_vpc_regions GROUP BY vpc_name)) reg on ahost.vpc_name = reg.vpc_name  WHERE ahost.id = :Id', {
      replacements: { Id },type: sequelize.QueryTypes.SELECT
    });
    return data;
  }

  async getAllAWSVpcAdminHosts(orgId, limit, offset) {
    const orgChain = await Organization.getOrgChain(orgId);
    const data = await sequelize.query(`SELECT reg.vpc_name,reg.avail_zone,reg.region,ahost.* from aws_vpc_admin_hosts ahost INNER JOIN  (SELECT * from aws_vpc_regions WHERE id IN (SELECT max(id) from aws_vpc_regions GROUP BY vpc_name)) reg on ahost.vpc_name = reg.vpc_name  WHERE ahost.organization_id IN (:orgChain) and ahost.is_active != 'false' `, {
      replacements: { orgChain },type: sequelize.QueryTypes.SELECT
    });
    return data;
  }

  getAllAWSVpcAdminHostsCount() {
    return AwsVpcAdminHosts.count({
      where: {
        $and: [
          { is_active: { $ne: 'false' } }]
      }
    });
  }

  async createAWSVpcAdminHost(params, orgId) {
    const vpcName = params.vpc_name;
    params.organization_id = orgId;
    const newName = removeSpace.checkMultiSpace(vpcName);
    const exists = await this.checkVpcName(newName);
    if (exists) {
      const error = new Error('Duplicate vpc_name.');
      error.status = 400;
      throw error;
    }
    params.vpc_name = newName;
    return AwsVpcAdminHosts.create(params);
  }

  checkVpcName(vpcName) {
    return AwsVpcAdminHosts.findOne({
      where: {
        vpc_name: sequelize.where(
          sequelize.fn('LOWER', sequelize.col('vpc_name')),
          sequelize.fn('lower', vpcName)),
        $or: [{ is_active: { $ne: 'false' } }]
      }
    });
  }

  async updateAWSVpcAdminHostById(update, awsVpcAdminHostId, orgId) {
    const vpcName = update.vpc_name;
    update.organization_id = orgId;
    const newName = removeSpace.checkMultiSpace(vpcName);
    const exists = await this.checkVpcNameForUpdate(newName, awsVpcAdminHostId);
    if (exists) {
      const error = new Error('Duplicate vpc_name.');
      error.status = 400;
      throw error;
    }
    update.vpc_name = newName;
    await AwsVpcAdminHosts.update(update, { where: { id: awsVpcAdminHostId } });
    return AwsVpcAdminHosts.findByPk(awsVpcAdminHostId);
  }

  checkVpcNameForUpdate(vpcName, Id) {
    return AwsVpcAdminHosts.findOne({
      where: {
        vpc_name: sequelize.where(
          sequelize.fn('LOWER', sequelize.col('vpc_name')),
          sequelize.fn('lower', vpcName)),
        $or: [{ is_active: { $ne: 'false' } }],
        id: { $ne: Id }
      }
    });
  }

  async deleteAWSVpcAdminHostById(Id) {
    await AwsVpcAdminHosts.update({ is_active: false }, { where: { id: Id } });
    return AwsVpcAdminHosts.findOne({ where: { id: Id } });
  }

  async deleteMultipleAWSVpcAdminHosts(awsVpcAdminHostIdArr) {
    await AwsVpcAdminHosts.update({ is_active: false }, { where: { id: { $in: awsVpcAdminHostIdArr } } });
    return AwsVpcAdminHosts.findAll({ where: { id: { $in: awsVpcAdminHostIdArr } } });
  }

/*
@deprecated
TODO: may be used later
  async getOVA(res, errorHandler) {
    const params = {
      Bucket: 'riskforesight-ova',
      Key: 'Support-export-2.iso'
    };
    s3.getObject(params).forwardToExpress(res, (error) => {
      return errorHandler({}, res, error);
    });

  }

  async getPostInstallScript(res, errorHandler) {
    const params = {
      Bucket: 'riskforesight-ova',
      Key: 'Support-export.ovf'
    };
    s3.getObject(params).forwardToExpress(res, (error) => {
      return errorHandler({}, res, error);
    });
  }*/
};
