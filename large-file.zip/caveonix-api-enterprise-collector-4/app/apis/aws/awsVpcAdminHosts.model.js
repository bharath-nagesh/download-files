const Sequelize = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();

/**
 * @swagger
 * components:
 *   schemas:
 *     AWS VPC:
 *       type: object
 *       required:
 *         - name
 *         - isActive
 *       properties:
 *         vpc_name:
 *           type: string
 *         admin_range:
 *           type: string
 *         organization_id:
 *           type: string
 *         isActive:
 *           type: string
 *         ports:
 *           type: string
 * @param sequelize
 */
class awsVpcAdminHosts extends Sequelize.Model {
  static init(sequelize) {
    return super.init(
      {
        id: {
          type: Sequelize.INTEGER,
          primaryKey: true,
          autoIncrement: true
        },
        vpc_name: { type: Sequelize.STRING, field: 'vpc_name' },
        admin_range: { type: Sequelize.STRING, field: 'admin_range' },
        organization_id: { type: Sequelize.INTEGER, field: 'organization_id' },
        isActive: { type: Sequelize.STRING, field: 'is_active' },
        is_active: { type: Sequelize.STRING, field: 'is_active' },
        ports: { type: Sequelize.STRING, field: 'ports' }
      },
      {
        sequelize,
        timestamps: false,
        freezeTableName: true,
        tableName: 'aws_vpc_admin_hosts',
        underscored: true
      }
    );

  }

  static associate(models) {
    awsVpcAdminHosts.belongsTo(models.awsVpcRegions,
      { foreignKey: 'vpc_name', targetKey: 'vpc_name' });
    awsVpcAdminHosts.belongsTo(models.Organization);
  };
}

module.exports = awsVpcAdminHosts;
