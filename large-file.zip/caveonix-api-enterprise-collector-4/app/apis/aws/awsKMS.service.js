const MarketplaceConnections = require('../auth/marketplaceConnections.model');
const CentralCollectorClient = require('../../../utils/centralCollector.client');
const AWS = require('aws-sdk');
const utils = require('util');
const rp = require('request-promise');
const sequelize = require('../../../config/db.conf').getConnection();
const KeyGenerator = require('../../../utils/generateKeys');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-awsKMS.service'
});

/**
 * AWS Service that handles all of the queries to the database
 * @type {AWSKMSService}
 */
module.exports = class AWSKMSService {
  constructor() {
    logger.debug('called AWS KMS Service constructor');
    this.keyGenerator = new KeyGenerator();
  }

  async createKMS(AliasName, TagKey, TagValue, Description = null) {
    let Keydata;
    const marketplaceConnections = await MarketplaceConnections.findOne({ where: { isActive: 'enabled' } });
    marketplaceConnections.authCode = await this.keyGenerator.decryptKeys(marketplaceConnections.authCode);
    const kmsClient = new AWS.KMS({
      accessKeyId: marketplaceConnections.authKey,
      secretAccessKey: marketplaceConnections.authCode,
      region: 'us-east-1'
    });

    try {
      const KeyParams = { Tags: [{ TagKey, TagValue }] };
      if (Description) KeyParams.Description = Description;
      kmsClient.createKey = utils.promisify(kmsClient.createKey);
      Keydata = await kmsClient.createKey(KeyParams);
    } catch (err) {
      const error = new Error(err.message || 'Error Creating KMS Key');
      error.status = 400;
      throw error;
    }

    try {
      var AliasParams = { AliasName: `alias/${AliasName}`, TargetKeyId: Keydata.KeyMetadata.KeyId };
      kmsClient.createAlias = utils.promisify(kmsClient.createAlias);
      Keydata.AliasData = await kmsClient.createAlias(AliasParams);
    } catch (err) {
      const error = new Error(err.message || 'Error Creating KMS Key Alias Name');
      error.status = 400;
      throw error;
    }

    return Keydata;
  }

  async getSSMParameter(Names) {
    const marketplaceConnections = await MarketplaceConnections.findOne({ where: { isActive: 'enabled' } });
    marketplaceConnections.authCode = await this.keyGenerator.decryptKeys(marketplaceConnections.authCode);
    const ssm = new AWS.SSM({
      accessKeyId: marketplaceConnections.authKey,
      secretAccessKey: marketplaceConnections.authCode,
      region: 'us-east-1'
    });

    try {
      Names = Array.isArray(Names) ? Names : [Names];
      const SSMParams = { Names, WithDecryption: true };
      ssm.getParameters = utils.promisify(ssm.getParameters);
      const SSMdata = await ssm.getParameters(SSMParams);
      return SSMdata.Parameters;
    } catch (err) {
      const error = new Error(err.message || 'Error Getting SSM Paramter');
      error.status = 400;
      throw error;
    }
  }

  async createSSMParameter(Name, Value, KeyId, Description = null) {
    const marketplaceConnections = await MarketplaceConnections.findOne({ where: { isActive: 'enabled' } });
    marketplaceConnections.authCode = await this.keyGenerator.decryptKeys(marketplaceConnections.authCode);
    const ssm = new AWS.SSM({
      accessKeyId: marketplaceConnections.authKey,
      secretAccessKey: marketplaceConnections.authCode,
      region: 'us-east-1'
    });

    try {
      const SSMParams = { Name, Value, KeyId, Type: 'SecureString', Overwrite: true };
      if (Description) SSMParams.Description = Description;
      ssm.putParameter = utils.promisify(ssm.putParameter);
      const SSMdata = await ssm.putParameter(SSMParams);
      return SSMdata;
    } catch (err) {
      const error = new Error(err.message || 'Error Creating SSM Paramter');
      error.status = 400;
      throw error;
    }
  }

  async deleteSSMParameter(Name) {
    const marketplaceConnections = await MarketplaceConnections.findOne({ where: { isActive: 'enabled' } });
    marketplaceConnections.authCode = await this.keyGenerator.decryptKeys(marketplaceConnections.authCode);
    const ssm = new AWS.SSM({
      accessKeyId: marketplaceConnections.authKey,
      secretAccessKey: marketplaceConnections.authCode,
      region: 'us-east-1'
    });

    try {
      const SSMParams = { Name };
      ssm.deleteParameters = utils.promisify(ssm.deleteParameters);
      const SSMdata = await ssm.deleteParameter(SSMParams);
      return SSMdata;
    } catch (err) {
      const error = new Error(err.message || 'Error Deleteing SSM Paramter');
      error.status = 400;
      throw error;
    }
  }

  async CentralCollectorServiceUpdate(configType, configId, orgId, userId, userToken) {
    if (!['assetRepo', 'schedule', 'remoteAccessDetails', 'assetRemoteAccessDetails','authInfo'].includes(configType)) {
      logger.error('Invalid Config Type Passed');
      const error = new Error('Invalid Config Type Passed');
      error.status = 400;
      throw error;
    }
    const caveoAgent = await sequelize.query(`select split_part(authorization_info_clear,'-',1) as organization_id from session_info where caveo_agent_id in (select id from caveo_agents where agent_name = 'EC' order by created_at desc limit 1) and  split_part(authorization_info_clear,'-',1)::integer = :orgId  order by created_at desc limit 1;`,
      {
        type: sequelize.QueryTypes.SELECT, replacements: { orgId }
      });
    if (!caveoAgent || caveoAgent.length < 1) { return true; }
    const ccUrl = await CentralCollectorClient.getCentralCollectorAddress();
    if (!ccUrl) {
      const err = new Error('No Central Collector Available. Please Contact your Caveonix Administrator');
      err.status = 404;
      throw err;
    }
    const url = `${ccUrl}/centralcollector/api/V1/ec/config?userToken=${userToken}&userId=${userId}&orgId=${orgId}&configType=${configType}&configId=${configId}`;
    try {
      const response = await rp.post({ url: url, json: true, rejectUnauthorized: false });
      return response;
    } catch (err) {
      logger.error(err);
      const error = new Error(err.message);
      error.status = 400;
      throw error;
    }
  };

};
