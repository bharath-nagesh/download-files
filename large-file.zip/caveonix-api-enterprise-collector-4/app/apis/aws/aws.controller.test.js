const expect = require('chai').expect;
const proxyquire = require('proxyquire').noCallThru();
const httpMocks = require('node-mocks-http');

describe('AWSController', function () {
  beforeEach(() => {

  });

  describe('AWSController', () => {

    describe('getOVAFromS3', () => {
      it('getOVAFromS3', async () => {
        const resData = { data : 1 };
        const ovaData = 1;

        const AWSService = class AWSService {
          getOVA(res, errorHandler){
            return Promise.resolve(ovaData);
          };
        };
        const AWSController = proxyquire('./aws.controller', {
          './aws.service': AWSService
        });

        const awsController = new AWSController();
        const req = httpMocks.createRequest();
        const res = httpMocks.createResponse();
        const details = await awsController.getOVAFromS3(req, res);
        expect(details).to.deep.equal(ovaData);
      });
    });

    describe('getPostScriptFromS3', () => {
      it('getPostScriptFromS3', async () => {
        const resData = { data : 1 };
        const ovaData = 1;

        const AWSService = class AWSService {
          getPostInstallScript(res, errorHandler){
            return Promise.resolve(ovaData);
          };
        };
        const AWSController = proxyquire('./aws.controller', {
          './aws.service': AWSService
        });

        const awsController = new AWSController();
        const req = httpMocks.createRequest();
        const res = httpMocks.createResponse();
        const details = await awsController.getPostScriptFromS3(req, res);
        expect(details).to.deep.equal(ovaData);
      });
    });

    describe('getAllAWSVpcRegions', () => {
      it('getAllAWSVpcRegions', async () => {
        const resData = { data : 1 };

        const orgId = 1;
        const page = 1;
        const limit = 10;
        const offset = 0;
        const total_record_count = 10;
        const AwsResponse = {
          total_page_count: 1,
          pageLimit: limit,
          total_record_count: total_record_count,
          page_number: page,
          AWSVpcRegions: resData,
          pages: [{
            number: 1,
            url: 'null?page=' + page
          }]
        };

        const AWSService = class AWSService {
          getAllAWSVpcRegions(filter, region, availZone, vpcName, limit, offset){
            return Promise.resolve(resData);
          };

          getAllAWSVpcRegionsCount(){
            return Promise.resolve(total_record_count);
          };
        };
        const AWSController = proxyquire('./aws.controller', {
          './aws.service': AWSService
        });

        const awsController = new AWSController();
        const req = httpMocks.createRequest({ params: { orgId }, query: { page } });
        const res = httpMocks.createResponse({ locals: { paginate: { limit, offset, page } } });
        const details = await awsController.getAllAWSVpcRegions(req, res);
        const awsData = details._getData();
        expect(JSON.parse(awsData)).to.deep.equal(AwsResponse);
      });
    });

    describe('getAWSVpcRegionsById', () => {
      it('getAWSVpcRegionsById', async () => {
        const resData = { data : 1 };
        const awsVpcRegionsId = 1;

        const AWSService = class AWSService {
          getAWSVpcRegionsById(res, errorHandler){
            return Promise.resolve(resData);
          };
        };
        const AWSController = proxyquire('./aws.controller', {
          './aws.service': AWSService
        });

        const awsController = new AWSController();
        const req = httpMocks.createRequest({ params: { awsVpcRegionsId } });
        const res = httpMocks.createResponse();
        const details = await awsController.getAWSVpcRegionsById(req, res);
        const awsData = details._getData();
        expect(JSON.parse(awsData)).to.deep.equal(resData);
      });
    });

    describe('getAllAWSVpcAdminHosts', () => {
      it('getAllAWSVpcAdminHosts', async () => {
        const resData = { data : 1 };
        const serviceProviderId = 1;
        const orgId = 1;
        const page = 1;
        const limit = 10;
        const offset = 0;
        const total_record_count = 10;
        const AwsResponse = {
          total_page_count: 1,
          pageLimit: limit,
          total_record_count: total_record_count,
          page_number: page,
          AWSVpcAdminHosts: resData,
          pages: [{
            number: 1,
            url: 'null?page=' + page
          }]
        };

        const AWSService = class AWSService {
          getAllAWSVpcAdminHosts(filter, region, availZone, vpcName, limit, offset){
            return Promise.resolve(resData);
          };

          getAllAWSVpcAdminHostsCount(){
            return Promise.resolve(total_record_count);
          };
        };
        const AWSController = proxyquire('./aws.controller', {
          './aws.service': AWSService
        });

        const awsController = new AWSController();
        const req = httpMocks.createRequest({ params: { orgId,serviceProviderId }, query: { page } });
        const res = httpMocks.createResponse({ locals: { paginate: { limit, offset, page } } });
        const details = await awsController.getAllAWSVpcAdminHosts(req, res);
        const awsData = details._getData();
        expect(JSON.parse(awsData)).to.deep.equal(AwsResponse);
      });
    });

    describe('getAWSVpcAdminHostById', () => {
      it('getAWSVpcAdminHostById', async () => {
        const resData = { data : 1 };
        const awsVpcAdminHostId = 1;

        const AWSService = class AWSService {
          getAWSVpcAdminHostById(res, errorHandler){
            return Promise.resolve(resData);
          };
        };
        const AWSController = proxyquire('./aws.controller', {
          './aws.service': AWSService
        });

        const awsController = new AWSController();
        const req = httpMocks.createRequest({ params: { awsVpcAdminHostId } });
        const res = httpMocks.createResponse();
        const details = await awsController.getAWSVpcAdminHostById(req, res);
        const awsData = details._getData();
        expect(JSON.parse(awsData)).to.deep.equal(resData);
      });
    });

    describe('createAWSVpcAdminHost', () => {
      it('createAWSVpcAdminHost', async () => {
        const paramsData = {
          vpc_name: 'vpc-0001',
          region: 'us-east',
          avail_zone: '1a',
          admin_range: '10.1.1.1-10.1.1.2',
          isActive: 'enabled',
          checkIp: 'true',
          ports: '1,2,3'
        };
        const orgId = 1;

        const AWSService = class AWSService {
          createAWSVpcAdminHost(res, errorHandler){
            return Promise.resolve(paramsData);
          };
        };
        const CheckIpStub = class CheckIpStub {
          static checkIp(ip){
            return Promise.resolve(true);
          };
        };
        const AWSController = proxyquire('./aws.controller', {
          './aws.service': AWSService,
          '../../../utils/checkIp':CheckIpStub
        });

        const awsController = new AWSController();
        const req = httpMocks.createRequest({ params: { orgId } , body:  paramsData });
        const res = httpMocks.createResponse();
        const details = await awsController.createAWSVpcAdminHost(req, res);
        const awsData = details._getData();
        expect(JSON.parse(awsData)).to.deep.equal(paramsData);
      });
    });

    describe('updateAWSVpcAdminHostById', () => {
      it('updateAWSVpcAdminHostById', async () => {
        const awsVpcAdminHostId = 1;
        const paramsData = {
          vpc_name: 'vpc-0001',
          region: 'us-east',
          avail_zone: '1a',
          admin_range: '10.1.1.1-10.1.1.2',
          isActive: 'enabled',
          checkIp: 'true',
          ports: '1,2,3'
        };
        const orgId = 1;

        const AWSService = class AWSService {
          updateAWSVpcAdminHostById(update, awsVpcAdminHostId, orgId){
            return Promise.resolve(paramsData);
          };
        };
        const CheckIpStub = class CheckIpStub {
          static checkIp(ip){
            return Promise.resolve(true);
          };
        };
        const AWSController = proxyquire('./aws.controller', {
          './aws.service': AWSService,
          '../../../utils/checkIp':CheckIpStub
        });

        const awsController = new AWSController();
        const req = httpMocks.createRequest({ params: { orgId,awsVpcAdminHostId } , body:  paramsData });
        const res = httpMocks.createResponse();
        const details = await awsController.updateAWSVpcAdminHostById(req, res);
        const awsData = details._getData();
        expect(JSON.parse(awsData)).to.deep.equal(paramsData);
      });
    });

    describe('deleteAWSVpcAdminHostById', () => {
      it('deleteAWSVpcAdminHostById', async () => {
        const resData = { data : 1 };
        const awsVpcAdminHostId = 1;

        const AWSService = class AWSService {
          deleteAWSVpcAdminHostById(res, errorHandler){
            return Promise.resolve(resData);
          };
        };
        const AWSController = proxyquire('./aws.controller', {
          './aws.service': AWSService
        });

        const awsController = new AWSController();
        const req = httpMocks.createRequest({ params: { awsVpcAdminHostId } });
        const res = httpMocks.createResponse();
        const details = await awsController.deleteAWSVpcAdminHostById(req, res);
        const awsData = details._getData();
        expect(JSON.parse(awsData)).to.deep.equal(resData);
      });
    });

    describe('deleteMultipleAWSVpcAdminHosts', () => {
      it('deleteMultipleAWSVpcAdminHosts', async () => {
        const resData = [{ data : 1 }];
        const id = '1,2,3';

        const AWSService = class AWSService {
          deleteMultipleAWSVpcAdminHosts(res, errorHandler){
            return Promise.resolve(resData);
          };
        };
        const AWSController = proxyquire('./aws.controller', {
          './aws.service': AWSService
        });

        const awsController = new AWSController();
        const req = httpMocks.createRequest({ query: id });
        const res = httpMocks.createResponse();
        const details = await awsController.deleteMultipleAWSVpcAdminHosts(req, res);
        const awsData = details._getData();
        expect(JSON.parse(awsData)).to.deep.equal(resData);
      });
    });

    describe('getAllAWSRegions', () => {
      it('getAllAWSRegions', async () => {
        const resData = { data : 1 };
        const serviceProviderId = 1;
        const orgId = 1;
        const page = 1;
        const limit = 10;
        const offset = 0;
        const total_record_count = 10;
        const AwsResponse = {
          total_page_count: 1,
          pageLimit: limit,
          total_record_count: total_record_count,
          page_number: page,
          AWSRegions: resData,
          pages: [{
            number: 1,
            url: 'null?page=' + page
          }]
        };

        const AWSService = class AWSService {
          getAllAWSRegions(filter, region, availZone, vpcName, limit, offset){
            return Promise.resolve(resData);
          };

          getAllAWSRegionsCount(){
            return Promise.resolve(total_record_count);
          };
        };
        const AWSController = proxyquire('./aws.controller', {
          './aws.service': AWSService
        });

        const awsController = new AWSController();
        const req = httpMocks.createRequest({ params: { orgId,serviceProviderId }, query: { page } });
        const res = httpMocks.createResponse({ locals: { paginate: { limit, offset, page } } });
        const details = await awsController.getAllAWSRegions(req, res);
        const awsData = details._getData();
        expect(JSON.parse(awsData)).to.deep.equal(AwsResponse);
      });
    });

  });
});
