const Sequelize = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();

const AwsVpcRegions = sequelize.define(
  'awsVpcRegions',
  {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    region: { type: Sequelize.STRING, field: 'region' },
    avail_zone: { type: Sequelize.STRING, field: 'avail_zone' },
    vpc_name: { type: Sequelize.STRING, field: 'vpc_name' },
    asset_id: { type: Sequelize.INTEGER, field: 'asset_id' }
  },
  { timestamps: false, freezeTableName: true, tableName: 'aws_vpc_regions', underscored: true }
);

module.exports = AwsVpcRegions;
