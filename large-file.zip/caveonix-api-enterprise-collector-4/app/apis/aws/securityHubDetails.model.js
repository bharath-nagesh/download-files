const Sequelize = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();

/**
 * @swagger
 * components:
 *   schemas:
 *     Job:
 *       type: object
 *       required:
 *         - name
 *         - isActive
 *       properties:
 *         name:
 *           type: string
 *         description:
 *           type: string
 *         org_type:
 *           type: string
 *         organization_id:
 *           type: string
 * @param sequelize
 */
class SecurityHubDetail extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      consume: { type: Sequelize.STRING, field: 'consume_from_sechub' },
      publish: { type: Sequelize.STRING, field: 'send_to_sechub' },
      queueName: { type: Sequelize.STRING, field: 'queue_name' },
      accountNumber: { type: Sequelize.STRING, field: 'account_number' }
    },
    {
      sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'aws_security_hub_details',
      underscored: true
    });
  }

  // model associations
  static associate(models) {
    SecurityHubDetail.belongsTo(models.AssetRepoEndpoint, { foreignKey: 'asset_repo_endpoints_id', allowNull: false });

  };
}

module.exports = SecurityHubDetail;
