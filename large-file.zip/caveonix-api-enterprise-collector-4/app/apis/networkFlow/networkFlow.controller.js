const cache = {};
const config = require('../../../config.json');
const errorHandler = require('../../../utils/errorHandler');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-asset.controller'
});
const NetworkFlowService = require('./networkFlow.service');
const networkFlowService = new NetworkFlowService();
const NetworkUtilsFactory = require('../../../utils/network/networkUtils/NetworkUtilsFactory');
const Utils = NetworkUtilsFactory.createNetworkUtils();

const DEFAULT_FLOWS_OFFSET = 0; // when retrieving raw flows this is the default starting index returned
const DEFAULT_FLOWS_LIMIT = 10000; // when retrieving raw flows this is the default number of flow records returned

module.exports = class NetworkFlowController {
  async getDashboardInfo(req, res) {
    const authToken = req.headers.es_token;
    const bearerToken = req.authInfo;
    const d = config.demo ? new Date(config.demo_es_date) : new Date(Date.now());
    d.setDate(d.getDate());
    const date = req.query.date ? Utils.getYYYY_MM_DD(req.query.date) : Utils.getYYYY_MM_DD(d);

    const orgId = req.params.orgId || req.params.serviceProviderId;

    let url = req.originalUrl;
    const where = req.query.w || req.query.where || {};
    const refresh = req.query.refresh || false;
    const arr = Object.entries(where) || [];
    const value = arr.sort().map((entry) => {
      return `${entry[0]}#${entry[1]}`;
    }).join('^');
    url = url.split('?')[0];
    const key = `${url}#${orgId}#date#${date}#${value}`;
    let data = await cache.get(key);
    if (refresh !== 'true' && data) return res.json(data);
    try {
      data = await networkFlowService
        .getDashboardInfo(orgId, date, where, bearerToken, authToken);
      await cache.set(key, data);
      return res.json(data);
    } catch (error) {
      return errorHandler(req, res, error);
    }

  }

  async getNetworkFlowsPage(req, res) {
    const authToken = req.headers.es_token;
    const bearerToken = req.authInfo;
    const d = config.demo ? new Date(config.demo_es_date) : new Date(Date.now());
    d.setDate(d.getDate());
    const date = req.query.date ? Utils.getYYYY_MM_DD(req.query.date) : Utils.getYYYY_MM_DD(d);
    const orgId = req.params.orgId;
    const control = req.query.control;
    let url = req.originalUrl;
    const where = req.query.w || req.query.where || {};
    const mode = req.query.mode || 'normal';
    const refresh = req.query.refresh || false;
    const offset = req.query.offset || DEFAULT_FLOWS_OFFSET;
    const limit = req.query.limit || DEFAULT_FLOWS_LIMIT;
    const arr = Object.entries(where) || [];
    const value = arr.sort().map((entry) => {
      return `${entry[0]}#${entry[1]}`;
    }).join('^');
    url = url.split('?')[0];
    const key = `${url}#${orgId}#date#${date}#${value}#${offset}#${limit}`;
    const data = await cache.get(key);
    logger.info({ key, url, date, orgId }, 'cache things');
    if (refresh !== 'true' && data) return res.json(data);
    try {
      const data = await networkFlowService
        .getNetworkFlowsPage(orgId, date, control, where, (refresh==='true'), mode, bearerToken, authToken, offset, limit);
      logger.silly({ data }, 'networkFlowData');
      await cache.set(key, data);
      return res.json(data);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getNetworkPoliciesRiskPage(req, res) {
    const d = config.demo ? new Date(config.demo_es_date) : new Date(Date.now());
    const authToken = req.headers.es_token;
    const bearerToken = req.authInfo;
    // d.setDate(d.getDate())
    const date = req.query.date ? Utils.getYYYY_MM_DD(req.query.date) : Utils.getYYYY_MM_DD(d);
    const orgId = req.params.orgId;
    let url = req.originalUrl;
    const control = req.query.control;
    const where = req.query.w || req.query.where || {};
    const mode = req.query.mode || 'normal';
    const refresh = req.query.refresh || false;
    const arr = Object.entries(where) || [];
    const value = arr.sort().map((entry) => {
      return `${entry[0]}#${entry[1]}`;
    }).join('^');
    url = url.split('?')[0];
    const key = `${url}#${orgId}#date#${date}#${value}`;
    const data = await cache.get(key);
    if (refresh !== 'true' && data) return res.json(data);
    try {
      const data = await networkFlowService
        .getPolicyRiskPage(orgId, date, control, where, mode, bearerToken, authToken);
      await cache.set(key, data);
      return res.json(data);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getNetworkPoliciesCompliancePage(req, res) {
    const d = config.demo ? new Date(config.demo_es_date) : new Date(Date.now());
    const authToken = req.headers.es_token;
    const bearerToken = req.authInfo;
    // d.setDate(d.getDate())
    const date = req.query.date ? Utils.getYYYY_MM_DD(req.query.date) : Utils.getYYYY_MM_DD(d);
    const orgId = req.params.orgId;
    let url = req.originalUrl;
    url = url.split('?')[0];
    const control = req.query.control;
    const where = req.query.w || req.query.where || {};
    const refresh = req.query.refresh || false;
    const source = req.query.source || null;
    const destination = req.query.destination || null;
    const mode = req.query.mode || 'normal';
    const port = req.query.port || null;
    const arr = Object.entries(where) || [];
    const value = arr.sort().map((entry) => {
      return `${entry[0]}#${entry[1]}`;
    }).join('^');
    const key = `${url}#${orgId}#date#${date}#${value}`;
    const data = await cache.get(key);
    if (refresh !== 'true' && data) return res.json(data);
    try {
      const data = await networkFlowService
        .getPolicyCompliancePage(orgId, date, control, where, (refresh==='true'), mode,  source, destination, port, bearerToken, authToken);
      await cache.set(key, data);
      return res.json(data);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }


  async getNetworkDataForAsset(req, res) {
    const authToken = req.headers.es_token;
    const bearerToken = req.authInfo;
    const { assetId, orgId } = req.params;
    try {
      const data = await networkFlowService.getNetworkDataForAsset(orgId, assetId, bearerToken, authToken);
      return res.json(data);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }
};
