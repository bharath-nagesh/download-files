const ApplicationTag = require('../application/applicationTag.model');
const Asset = require('../asset/asset.model');
const AssetService = require('../asset/asset.service');
const assetService = new AssetService();
const AssetRepoService = require('../assetRepoEndpoint/assetRepoEndpoint.service');
const assetRepoService = new AssetRepoService();
const config = require('../../../configure').get();
const conditionFilter = require('../../../utils/conditionFilter');
const NetworkDashboardFactory = require('../../../utils/network/networkDashboard/NetworkDashboardFactory');
const NetworkFlowsFactory = require('../../../utils/network/networkFlows/NetworkFlowsFactory');
const NetworkPoliciesFactory = require('../../../utils/network/networkPolicies/NetworkPoliciesFactory');
const ReferenceService = require('../../services/reference.service');
const referenceService = new ReferenceService();

const networkDefinitions = require('../../definitions/network');
referenceService.addEndpoints(null, null, networkDefinitions, '');
const NetworkForensics = require('../../../utils/NetworkForensics');
const OrgService = require('../organization/org.service');
const orgService = new OrgService();
const SubApplication = require('../subApplication/subApplication.model');
const pp = require('../../../utils/postProcessor');
const sequelize = require('../../../config/db.conf').getConnection();
const KeyGenerator = require('../../../utils/generateKeys');
const logger = require('../../../utils/logger').logger;
const rp = require('request-promise');
const whereCondition = require('../../../utils/whereParser.js');
const _ = require('lodash');
const DEFAULT_FLOWS_OFFSET = 0;
const DEFAULT_FLOWS_LIMIT = 10000;

module.exports = class NetworkFlowService {
  constructor(services) {
    this.cache = {};
    this.keyGenerator = new KeyGenerator();
    this.serviceUri = config.es_url;
    if (!this.serviceUri) {
      this.available = false;
    } else {
      this.available = true;
    }
    this.serviceUserName = config.es_username;
    this.servicePass = config.es_password;
  }

  async getAssets(orgId, condition = {}, ...terms) {
    const orgChain = await orgService.getOrgChain(orgId);
    const termClause = terms.join(', ');
    return sequelize.query(`select ${termClause} from application_group_asset_view ${whereCondition(...conditionFilter(condition), ` application_grp_org_id in (:orgChain)`)} group by ${termClause}`, {
      replacements: { orgChain },
      type: sequelize.QueryTypes.SELECT
    });
  }

  // called from controller
  async getDashboardInfo(orgId, date, where, token = null, authToken = null) {

    const assets = await this.getAssets(orgId, where, 'vmid');

    const vmIds = assets.map(asset => {
      return asset.vmid;
    });
    const assetGroups = [
      {
        containerName: 'dashboardInfo',
        members: {
          options: {
            location: '*',
            serviceProvider: '*',
            organization: orgId
          },
          objects: vmIds
        }
      }
    ];
    const pass = await this.keyGenerator.decryptKeys(this.servicePass);
    const nd = NetworkDashboardFactory.createNetworkDashboard(assetGroups, this.serviceUri, this.serviceUserName, pass, token, authToken);
    const mostRecentDates = await Promise.all([nd.getMostRecentDateWithData('flows', orgId), nd.getMostRecentDateWithData('policies', orgId)]);
    const userDate = new Date(date);
    const mostRecentFlowDateFirst = mostRecentDates[0][0];
    const mostRecentFlowDateSecond = mostRecentDates[0][1];
    const mostRecentPolicyDateFirst = mostRecentDates[1][0];
    const mostRecentPolicyDateSecond = mostRecentDates[1][1];
    logger.info({ mostRecentFlowDateFirst, mostRecentFlowDateSecond, userDate }, 'the dates');
    const retData = await Promise.all([nd.calculateTotalTrafficFlow(mostRecentFlowDateFirst, mostRecentFlowDateSecond), nd.calculateTotalPolicies(mostRecentPolicyDateFirst, mostRecentPolicyDateSecond), nd.calculateTotalFirewallRules(mostRecentPolicyDateFirst, mostRecentPolicyDateSecond)]);

    // TODO: Change key name from totalSecurityGroups to totalFirewallRules, didn't do it yet so UI is not broken
    return Promise.resolve({
      totalTrafficFlow: retData[0],
      totalPolicies: retData[1],
      totalSecurityGroups: retData[2],
      dateUsed: mostRecentFlowDateFirst
    });

  }

  async getPolicyRiskPage(orgId, date, control, where, mode = 'normal', token = null, authToken = null) {
    if (mode === 'uniqueLists') {
      const dataArray = await Promise.all([
        this.getPolicyRiskCircle(orgId, date, control, where, mode, token, authToken)
      ]);
      return { uniqueLists: dataArray[0].uniqueLists };
    }
    const dataArray = await Promise.all([
      this.getPolicyRiskCircle(orgId, date, control, where, token, authToken),
      this.getPolicyWidgets(orgId, date, control, where, true, token, authToken)
    ]);

    return {
      caveoCircle: dataArray[0],
      topFlowsByPort: dataArray[1][0],
      distributionTable: dataArray[1][1],
      topSecurityPoliciesByAsset: dataArray[1][2],
      securityPoliciesByAppGroup: dataArray[1][3],
      policyTabularData: dataArray[1][4],
      dateUsed: dataArray[1][5],
      appGroupBySecurityPolicies: dataArray[1][6],
      appGroupByFirewalls: dataArray[1][7]
    };
  }

  async getPolicyCompliancePage(orgId, date, control, where, refresh,  mode, source, destination, port, token = null, authToken = null) {
    if (mode === 'uniqueLists') {
      const dataArray = await Promise.all([
        this.getPolicyComplianceCircle(orgId, date, control, where, refresh, mode, source, destination, port, token, authToken)
      ]);
      return { uniqueLists: dataArray[0].uniqueLists };
    }
    const dataArray = await Promise.all([
      this.getPolicyComplianceCircle(orgId, date, control, where, refresh, mode, source, destination, port, token, authToken),
      this.getPolicyWidgets(orgId, date, control, where, false, token, authToken)
    ]);

    return {
      caveoCircle: dataArray[0],
      topFlowsByPort: dataArray[1][0],
      distributionTable: dataArray[1][1],
      topSecurityPoliciesByAsset: dataArray[1][2],
      securityPoliciesByAppGroup: dataArray[1][3],
      policyTabularData: dataArray[1][4],
      dateUsed: dataArray[1][5],
      appGroupBySecurityPolicies: dataArray[1][6],
      appGroupByFirewalls: dataArray[1][7]
    };
  }


  async _getFlowsTabular(nf, date, control,  offset = DEFAULT_FLOWS_OFFSET, limit = DEFAULT_FLOWS_LIMIT) {
    let indexkey = 'container';
    if (control) indexkey = control;
    const orgId = nf.assetGroups[0] ? nf.assetGroups[0].members.options.organization : -1;
    let data = await nf.getRawFlows(date, offset, limit);
    if (!data) data = [];
    // logger.silly({ data }, ' FLOWS RAW DATA');
    const vmIds = [].concat.apply(
      [],
      data.map(container => {
        return [container.destinationUuid, container.sourceUuid];
      })
    );
    vmIds.push(null);
    const vmAssetMap = await this.getAssetDataByVmIds(vmIds);
    // map with assetRepoId as key and value is object that includes asset repo type
    const assetRepoList = await this.getAssetRepos(orgId);
    const assetRepoMap = assetRepoList.reduce((accumulator, assetRepo) => {
      accumulator[assetRepo.id] = assetRepo;
      return accumulator;
    }, {});
    const myRegexp = /([a-zA-Z0-9/(]{9}-[a-zA-Z0-9]{4}-[a-zA-Z0-9]{4}-[a-zA-Z0-9]{4}-[a-zA-Z0-9/)]{13})/g;
    data.map(flowData => {
      const destinationData = vmAssetMap[flowData.destinationUuid] || {
        asset_name: null,
        application_grp_name: null,
        application_name: null,
        organization_name: null
      };
      flowData.destination_asset_id = destinationData.id;
      flowData.destination_asset_name = destinationData.asset_name;
      if (flowData.destination_asset_name) {
        var destinationNamematch = flowData.destination_asset_name.match(myRegexp);
      }
      if (destinationNamematch) {
        flowData.destination_asset_name = flowData.destination_asset_name.replace(destinationNamematch[0], '');
      }
      flowData.destination_sub_application_name = destinationData.application_name;
      flowData.destination_application_name = destinationData.application_grp_name;

      const sourceData = vmAssetMap[flowData.sourceUuid] || {
        asset_name: null,
        application_grp_name: null,
        application_name: null,
        organization_name: null
      };
      flowData.source_asset_id = sourceData.id;
      flowData.source_asset_name = sourceData.asset_name;
      if (flowData.source_asset_name) {
        var sourceAssetName = flowData.source_asset_name.match(myRegexp);
      }
      if (sourceAssetName) {
        flowData.source_asset_name = flowData.source_asset_name.replace(sourceAssetName[0], '');
      }
      flowData.source_sub_application_name = sourceData.application_name;
      flowData.source_application_name = sourceData.application_grp_name;
      // --- determine the organization name of the target of flow
      if (sourceData.organization_name && destinationData.organization_name) {
        // if both source and destination both have an organization name then if
        //  direction is egress then use source, otherwise use destination
        // direction, 0=ingress, 1=egress
        if (flowData.direction && flowData.direction === 1) {
          flowData['Organization Name'] = sourceData.organization_name;
        } else {
          flowData['Organization Name'] = destinationData.organization_name;
        }
      } else if (sourceData.organization_name) {
        // if only source has organization name use it
        flowData['Organization Name'] = sourceData.organization_name;
      } else {
        // otherwise use destination organization name
        flowData['Organization Name'] = destinationData.organization_name;
      }
      flowData['Rule Name'] = flowData.ruleName || 'unknown';
      flowData['Protocol'] = flowData.protocol || 'unknown';
      flowData['Flows'] = flowData.flowClass || 'unknown';
      if (flowData.blocked === 0) {
        flowData['Action'] = 'allow';
      } else {
        flowData['Action'] = 'block';
      }
      flowData['Destination Asset'] = flowData.destination_asset_name || 'unknown';
      if (flowData['Destination Asset']) {
        var DestinationAsset = flowData['Destination Asset'].match(myRegexp);
      }
      if (DestinationAsset) {
        flowData['Destination Asset'] = flowData['Destination Asset'].replace(DestinationAsset[0], '');
      }
      flowData['Destination Application'] = flowData.destination_application_name || 'unknown';
      flowData['Destination Sub-Application'] = flowData.destination_sub_application_name || 'unknown';
      flowData['Source Asset'] = flowData.source_asset_name || 'unknown';
      if (flowData['Source Asset']) {
        var SourceAsset = flowData['Source Asset'].match(myRegexp);
      }
      if (SourceAsset) {
        flowData['Source Asset'] = flowData['Source Asset'].replace(SourceAsset[0], '');
      }
      flowData['Source Application'] = flowData.source_application_name || 'unknown';
      flowData['Source Sub-Application'] = flowData.source_sub_application_name || 'unknown';

      // --- if destination asset name is unknown or empty, but destination has value, set asset name to destination
      if ((!flowData.destination_asset_name) && (flowData.destination)) {
        flowData.destination_asset_name = flowData.destination;
      }
      if ((flowData['Destination Asset'] === 'unknown') && (flowData.destination)) {
        flowData['Destination Asset'] = flowData.destination;
      }
      // --- if source asset name is unknown or empty, but source has value, set asset name to source
      if ((!flowData.source_asset_name) && (flowData.source)) {
        flowData.source_asset_name = flowData.source;
      }
      if ((flowData['Source Asset'] === 'unknown') && (flowData.source)) {
        flowData['Source Asset'] = flowData.source;
      }
      //-- get the asset repo type where the flow came from and add to the flow
      const assetRepoType = assetRepoMap[flowData.assetRepoId] || { AssetRepoType: { dataValues: { name: 'unknown' } } };
      flowData['assetRepoType'] = assetRepoType.AssetRepoType.dataValues.name || 'unknown';
      return true;
    });

    const retData = [].concat.apply([], data);
    const uniqueLists = pp._uniquer({}, retData, null, [
      { label: 'Protocol', path: 'protocol' },
      { label: 'Rule Name', path: 'Rule Name' },
      { label: 'Flows', path: 'Flows' },
      { label: 'Destination Asset', path: 'Destination Asset' },
      { label: 'Destination Sub-Application', path: 'Destination Sub-Application' },
      { label: 'Destination Application', path: 'Destination Application' },
      { label: 'Source Asset', path: 'Source Asset' },
      { label: 'Source Sub-Application', path: 'Source Sub-Application' },
      { label: 'Source Application', path: 'Source Application' },
      { label: 'Action', path: 'Action' },
      { label: 'Organization Name', path: 'Organization Name' },
      { label: 'Repository Type', path: 'assetRepoType' },
      { label: 'Destination Port', path: 'destinationPort' }
    ]);
    return Promise.resolve({ index: indexkey, data: retData, uniqueLists });
  }



  async getPolicyComplianceCircle(orgId, date, control, where, refresh = false, mode,  source = null, destination = null, port = null, token = null, authToken = null) {
    const uniqueLists = {
      'Sub-Application': { label: 'Sub-Application', path: 'application_name', items: [] },
      Application: { label: 'Application', path: 'application_grp_name', items: [] },
      Organization: { label: 'Organization', path: 'organization_name', items: [] }
    };

    const orgChain = await orgService.getOrgChain(orgId);

    const assets = await this.getAssets(orgId, where, 'vmid', 'application_grp_name', 'application_name', 'application_grp_org_id', 'organization_name');
    const appGroupApplicationMap = {};
    const appGroupApplicationOrgIdMap = {};
    logger.silly({ assets }, 'returned assets ');
    assets.map(assetInfo => {
      if (assetInfo.vmid) {
        if (!appGroupApplicationMap[assetInfo.application_grp_name + '^^' + assetInfo.application_name]) {
          appGroupApplicationMap[assetInfo.application_grp_name + '^^' + assetInfo.application_name] = [];
        }
        if (!appGroupApplicationOrgIdMap[assetInfo.application_grp_name + '^^' + assetInfo.application_name]) {
          appGroupApplicationOrgIdMap[assetInfo.application_grp_name + '^^' + assetInfo.application_name] = assetInfo.application_grp_org_id;
          uniqueLists['Organization'].items.push(assetInfo.organization_name);
        }

        appGroupApplicationMap[assetInfo.application_grp_name + '^^' + assetInfo.application_name].push(assetInfo.vmid);
        uniqueLists['Application'].items.push(assetInfo.application_grp_name);
        uniqueLists['Sub-Application'].items.push(assetInfo.application_name);
      }
    });
    uniqueLists['Sub-Application'].items = Array.from(new Set(uniqueLists['Sub-Application'].items));
    uniqueLists['Application'].items = Array.from(new Set(uniqueLists['Application'].items));
    uniqueLists['Organization'].items = Array.from(new Set(uniqueLists['Organization'].items));
    if (mode === 'uniqueLists') {
      return { uniqueLists: Object.values(uniqueLists) };
    }
    // uniqueLists['Application'].push('EXTERNAL')
    // uniqueLists['Application'].push('INTERNET')
    const assetGroups = [];
    logger.info({ appGroupApplicationMap }, 'appGroupApplicationMap');

    Object.keys(appGroupApplicationMap).forEach(key => {
      // --- for AWS (where we push flows to index with sub org id in index name)
      assetGroups.push({
        containerName: key,
        members: {
          options: {
            location: '*',
            serviceProvider: '*',
            organization: appGroupApplicationOrgIdMap[key]
          },
          objects: appGroupApplicationMap[key]
        }
      });
      // --- for vmware (where we push flows to top org's index)
      if (appGroupApplicationOrgIdMap[key] != orgId) {
        assetGroups.push({
          containerName: key,
          members: {
            options: {
              location: '*',
              serviceProvider: '*',
              organization: orgId
            },
            objects: appGroupApplicationMap[key]
          }
        });
      }
    });
    const pass = await this.keyGenerator.decryptKeys(this.servicePass);
    const nf = NetworkFlowsFactory.createNetworkFlows(assetGroups, this.serviceUri, this.serviceUserName, pass, this.cache, refresh, token, authToken);
    logger.debug({ assetGroups }, 'the assetGroups');
    const mostRecentDate = await nf.getMostRecentDateWithData(orgId);
    const userDate = new Date(date);
    let d = userDate > mostRecentDate ? mostRecentDate : userDate;
    if (d == null) d = new Date();
    // let data = await np.calculateRuleComplianceLinks(d, token, authToken)
    const data = await nf.calculateRibbons(d);
    const policyData = await sequelize.query(`select organization_id,source_type,source_id,source_name,
            destination_type,destination_id,destination_name,port,network_security_policy_name from network_flows_policies where organization_id in (:orgChain) and is_active<>'false'`,
      { replacements: { orgChain }, type: sequelize.QueryTypes.SELECT });

    await Promise.all(policyData.map((policyD) => {
      logger.silly({ policyD });
      return this.HACKTHEPOLICY(data, policyD.source_name, policyD.source_type, policyD.destination_name,
        policyD.destination_type, policyD.port, policyD.network_security_policy_name);
    }));

    data.containers.forEach((d) => {
      const source = d.containerName;
      d.ribbons.forEach((ribbon) => {
        ribbon.source = source;
      });
    });
    data.containers = _.sortBy(data.containers, [(elem) => -1 * (elem.totalBytes)]);
    return { data, uniqueLists: Object.values(uniqueLists) };

  }

  /**
   * @todo Unhack the policy
   */
  async HACKTHEPOLICY(data, source, sourceType, destination, destinationType, port, ruleName) {
    const containers = data.containers;
    if (sourceType === 'application') {
      const app = await ApplicationTag.findOne({ where: { security_tag_name: source } });
      if (app) {
        source = app.security_tag_name;
      }
    }
    if (sourceType === 'sub-application') {
      const subApp = await SubApplication.findOne({ where: { security_tag_name: source } });
      if (subApp) {
        source = subApp.security_tag_name;
      }
    }
    if (destinationType === 'application') {
      const app = await ApplicationTag.findOne({ where: { security_tag_name: destination } });
      if (app) {
        destination = app.security_tag_name;
      }
    }
    if (destinationType === 'sub-application') {
      const subApp = await SubApplication.findOne({ where: { security_tag_name: destination } });
      if (subApp) {
        destination = subApp.security_tag_name;
      }
    }
    let container = containers.find((container) => {
      if (sourceType.toUpperCase() === 'INTERNET' || sourceType.toUpperCase() === 'EXTERNAL') {
        return container.containerName.includes(sourceType.toUpperCase());
      }
      return container.containerName.includes(source);
    });
    container = container || {};
    let ribbon = {};
    if (Object.keys(container).length !== 0) {
      ribbon = container.ribbons.find((obj) => {
        if (destinationType.toUpperCase() === 'INTERNET' || destinationType.toUpperCase() === 'EXTERNAL') {
          return obj.destination.includes(destinationType.toUpperCase());
        }
        return obj.destination.includes(destination);
      });
    }
    ribbon = ribbon || {};
    let portObj = {};
    if (Object.keys(ribbon).length !== 0) {
      portObj = ribbon.details.ports.find((portByteObj) => {
        return portByteObj.port === port;
      });
    }
    portObj = portObj || {};
    logger.info({ portObj }, 'the port obj before mutation');
    if (Object.keys(portObj).length !== 0) {

      portObj.allowed.bytes = 1;
      portObj.allowed.policy = {
        type: 'POLICY-ALLOW', name: ruleName
      };
    }
    logger.info({ portObj }, 'the port obj after mutation');
  }

  async getPolicyRiskCircle(orgId, date, control, condition, mode, token = null, authToken = null) {
    let vmIds = [];
    const uniqueLists = {
      'Sub-Application': { label: 'Sub-Application', path: 'application_name', items: [] },
      Application: { label: 'Application', path: 'application_grp_name', items: [] }
    };
    const orgChain = await orgService.getOrgChain(orgId);
    const assets = await sequelize.query(
        `select ag.name,ag.repo_type,vmid,application_grp_name,application_name,application_quarantine,application_grp_quarantine, application_id ,application_grp_id ,location,nsta.is_quarantined as quarantine from application_group_asset_view ag left join network_security_tag_assets nsta on  nsta.asset_instance_uuid = ag.vmid and nsta.is_active != 'false'
         ${whereCondition(`ag.is_active != 'false'`,
            'application_grp_org_id in (:orgChain)',
            ...conditionFilter(condition)
        )}  group by vmid, repo_type,application_name,application_grp_name,application_grp_id,application_id,application_quarantine,application_grp_quarantine, location, ag.name,nsta.is_quarantined`,
        {
          replacements: { orgChain },
          type: sequelize.QueryTypes.SELECT
        });
    if (assets) {
      const myRegexp = /([a-zA-Z0-9/(]{9}-[a-zA-Z0-9]{4}-[a-zA-Z0-9]{4}-[a-zA-Z0-9]{4}-[a-zA-Z0-9/)]{13})/g;
      assets.map(d => {
        const name = d.name;
        if (name) {
          var namematch = name.match(myRegexp);
        }
        if (namematch) {
          d.name = name.replace(namematch[0], '');
        }
      });
    }
    const appGroupMap = {};
    const assetMap = {};
    const appGroupApplicationMap = {};
    const applicationIdMap = {};
    const applicationQuarantineMap = {};
    logger.silly({ assets }, 'returned assets ');
    assets.map(assetInfo => {
      if (assetInfo.vmid) {
        if (!appGroupMap[assetInfo.application_grp_name]) appGroupMap[assetInfo.application_grp_name] = [];

        if (!appGroupApplicationMap[assetInfo.application_grp_name]) appGroupApplicationMap[assetInfo.application_grp_name] = [];
        appGroupMap[assetInfo.application_grp_name].push(assetInfo.vmid);
        appGroupApplicationMap[assetInfo.application_grp_name].push(assetInfo.application_name);
        applicationIdMap[assetInfo.application_name] = assetInfo.application_id;
        applicationIdMap[assetInfo.application_grp_name] = assetInfo.application_grp_id;
        applicationQuarantineMap[assetInfo.application_name] = assetInfo.application_quarantine;
        applicationQuarantineMap[assetInfo.application_grp_name] = assetInfo.application_grp_quarantine;
        applicationIdMap[assetInfo.application_name] = assetInfo.application_id;
        uniqueLists['Application'].items.push(assetInfo.application_grp_name);
        uniqueLists['Sub-Application'].items.push(assetInfo.application_name);
        vmIds.push(assetInfo.vmid);
        assetMap[assetInfo.vmid] = assetInfo;
      }
    });
    vmIds = Array.from(new Set(vmIds));
    uniqueLists['Sub-Application'].items = Array.from(new Set(uniqueLists['Sub-Application'].items));
    uniqueLists['Application'].items = Array.from(new Set(uniqueLists['Application'].items));
    if (mode === 'uniqueLists') {
      return Promise.resolve({ uniqueLists: Object.values(uniqueLists) });
    }
    const assetGroups = [];
    logger.info({ appGroupMap }, 'appGroupMap');

    Object.keys(appGroupMap).forEach(key => {
      assetGroups.push({
        containerName: key,
        members: {
          options: {
            location: '*',
            serviceProvider: '*',
            organization: orgId
          },
          objects: appGroupMap[key]
        }
      });
    });
    const pass = await this.keyGenerator.decryptKeys(this.servicePass);
    const np = NetworkPoliciesFactory.createNetworkPolicies(assetGroups, this.serviceUri, this.serviceUserName, pass, token, authToken);
    const mostRecentDate = await np.getMostRecentDateWithData(orgId);
    const userDate = new Date(date);
    let d = userDate > mostRecentDate ? mostRecentDate : userDate;
    if (d == null) d = new Date();

    const containerSet = await np.calculatePolicy(d);
    logger.info({ vmIds }, 'the vmIds');
    const vmIdMap = await Asset.getRiskScoreByVmIds(vmIds);
    logger.info({ assetMap, vmIdMap, containerSet }, 'was assetMap created');
    const appGroupArrayWithChildren = this.attachRiskScore(containerSet.policies, vmIdMap, assetMap);
    const applicationArray = _.reduce(appGroupApplicationMap, (res, val, key) => {
      val = Array.from(new Set(val));
      const children = val.map((subAppVal) => {
        return {
          type: 'sub-application',
          name: subAppVal,
          id: applicationIdMap[subAppVal],
          quarantine: applicationQuarantineMap[subAppVal] || 'false',
          children: []
        };
      });
      res.push({
        type: 'application',
        name: key,
        id: applicationIdMap[key],
        quarantine: applicationQuarantineMap[key] || 'false',
        children
      });
      return res;
    }, []);
    for (let k = 0; k < appGroupArrayWithChildren.length; k++) {
      this.recurse(applicationArray, appGroupArrayWithChildren[k], [{
        type: appGroupArrayWithChildren[k].type,
        id: applicationIdMap[appGroupArrayWithChildren[k].name],
        quarantine: applicationQuarantineMap[appGroupArrayWithChildren[k].name] || 'false',
        name: appGroupArrayWithChildren[k].name,
        totalAssets: appGroupArrayWithChildren[k].totalAssets,
        firewallRuleCount: appGroupArrayWithChildren[k].firewallRuleCount,
        totalAssetsNotCoveredByPolicy: appGroupArrayWithChildren[k].totalAssetsNotCoveredByPolicy,
        percentNotCoveredByPolicy: appGroupArrayWithChildren[k].percentNotCoveredByPolicy,
        allAssetCount: appGroupArrayWithChildren[k].allAssetCount

      }, {}]);
    }
    return { data: applicationArray, uniqueLists: Object.values(uniqueLists) };

  }




  async getPolicyWidgets(orgId, date, control, where, forRisk = true, token = null, authToken = null) {
    const assets = await this.getAssets(orgId, where, 'vmid', 'application_grp_name');
    const appGroupMap = {};
    logger.silly({ assets }, 'returned assets ');
    assets.map(assetInfo => {
      if (assetInfo.vmid) {
        if (!appGroupMap[assetInfo.application_grp_name]) appGroupMap[assetInfo.application_grp_name] = [];
        appGroupMap[assetInfo.application_grp_name].push(assetInfo.vmid);
      }
    });
    const assetGroups = [];
    logger.info({ appGroupMap }, 'appGroupMap');

    Object.keys(appGroupMap).forEach(key => {
      assetGroups.push({
        containerName: key,
        members: {
          options: {
            location: '*',
            serviceProvider: '*',
            organization: orgId
          },
          objects: appGroupMap[key]
        }
      });
    });
    const pass = await this.keyGenerator.decryptKeys(this.servicePass);
    const np = NetworkPoliciesFactory.createNetworkPolicies(assetGroups, this.serviceUri, this.serviceUserName, pass, token, authToken);
    logger.info({ assetGroups }, 'the assetGroups');
    const mostRecentDate = await np.getMostRecentDateWithData(orgId);
    const userDate = new Date(date);
    let d = userDate > mostRecentDate ? mostRecentDate : userDate;
    if (d == null) d = new Date();

    // -- get date for flows
    const nf = NetworkFlowsFactory.createNetworkFlows(assetGroups, this.serviceUri, this.serviceUserName, pass, this.cache, false, token, authToken);
    const nfmostRecentDate = await nf.getMostRecentDateWithData(orgId);
    const nfuserDate = new Date(date);
    let nfd = userDate > nfmostRecentDate ? nfmostRecentDate : nfuserDate;
    if (nfd == null) nfd = new Date();

    return Promise.all([
      np.sortFlowsByPort(nfd, token, authToken),
      this.getDistributionTable(orgId, np, d, forRisk, token, authToken),
      Promise.resolve([]),
      Promise.resolve([]),
      Promise.resolve({data:[], uniqueLists:[]}),
      Promise.resolve(d),
      Promise.resolve([]),
      Promise.resolve([])
    ]);
  }


  async getDistributionTable(orgId, np, date, getRiskTable = true, token = null, authToken = null) {
    if (getRiskTable) {
      try {
        const data = await Promise.all([
          np.statisticsForPolicyRisk(date, token, authToken),
          Asset.getComplianceAssetCount(orgId),
          Asset.getCyberAssetCount(orgId),
          assetService.getAssetCountForOrg(orgId, false)
        ]);
        const retData = data[0];
        const complianceArray = data[1];
        const riskArray = data[2];
        const complianceCountObj =
            complianceArray.find(obj => {
              obj.priority = 'Critical';
            }) || {};
        const complianceCount = complianceCountObj.count || 0;
        const riskCountObj =
            riskArray.find(obj => {
              obj.priority = 'Critical';
            }) || {};
        const riskCount = riskCountObj.count || 0;
        const assetCount = data[3];
        retData.cyberRiskAssetCount = riskCount;
        retData.complianceAssetCount = complianceCount;
        retData.assetCount = assetCount;
        return Promise.resolve(retData);
      } catch (error) {
        console.log({error, stack: error.stack}, 'error occurred');
        error.status = 500;
        throw error;
      }
    } else {
      return np.statisticsForPolicyCompliance(date, token, authToken);
    }
  }

  attachRiskScore(containerPolicyArray, vmIdMap, assetMap) {
    logger.info({ containerPolicyArray, length: containerPolicyArray.length }, 'container array');
    let tempArray = [];

    for (let j = 0; j < containerPolicyArray.length; j++) {
      try {
        if (containerPolicyArray[j].type === 'securityGroup') {
          tempArray = tempArray.concat(containerPolicyArray[j].children);
          const a = containerPolicyArray.splice(j, j + 1);
          logger.silly({ removedElement: a, tempArray }, 'removed element ');
        }
      } catch (e) {
        logger.error({ e, stack: e.stack }, 'containerPolicyArray error');
      }
    }
    containerPolicyArray.push(...tempArray);
    let children = [];
    logger.info({ assetMap, vmIdMap }, 'the maps');
    logger.silly({ length: containerPolicyArray.length }, 'containerPolicyArray length');
    for (let i = 0; i < containerPolicyArray.length; i++) {
      logger.silly({ obj: containerPolicyArray[i] }, 'policyObject iterating on');
      if (containerPolicyArray[i].type === 'asset') {
        logger.silly('in asset');
        children.push(this.findRisk(containerPolicyArray[i], vmIdMap, assetMap));
      } else {
        children = children.concat(this.attachRiskScore(containerPolicyArray[i].children, vmIdMap, assetMap));
      }
    }
    return containerPolicyArray;
  }

  findRisk(asset, vmIdMap, assetMap) {
    const scoreObj = vmIdMap[asset.name] || { priority: 'None' };
    const assetObj = assetMap[asset.name] || { AssetDetails: [], PolicyGroups: [], quarantine: false };
    logger.info({ asset }, ' the asset');
    asset.locations = [];
    asset.applications = [];
    asset.id = asset.name;

    asset.quarantine = assetObj.quarantine || 'false';
    if (assetObj.name) {
      asset.asset_name = assetObj.name;
      logger.info('changed asset name');
    }
    if (assetObj.location) {
      asset.locations.push(assetObj.location);
      logger.info('changed asset location');
    }
    if (assetObj.application_name) {
      asset.applications.push(assetObj.application_name);
      logger.info('changed asset application');
    }
    if (assetObj.repo_type) {
      asset.repo_type = assetObj.repo_type;
      logger.info('changed asset repo_type');
    }
    if (scoreObj.priority) {
      asset.riskScore = scoreObj.priority;
      asset.score = scoreObj.score;
      logger.info('changed asset score');
    }
    return asset;
  }

  recurse(resultData, dataSet, currentPath = []) {
    currentPath = Array.from(currentPath);
    const pointer = dataSet;
    for (let i = 0; i < pointer.children.length; i++) {
      if (pointer.children[i].type !== 'asset') {

        this.recurse(resultData, pointer.children[i], currentPath.concat([pointer.children[i]]));
      } else if (pointer.children[i].type === 'asset') {
        if (pointer.children[i].applications[0]) {
          currentPath = currentPath.slice();
          currentPath[1] = { name: pointer.children[i].applications[0], type: 'sub-application' };
        }
        logger.info({ currentPath, current: pointer.children[i] }, 'found an asset');
        let currentPointer = { children: resultData };
        for (let j = 0; j < currentPath.length; j++) {
          // logger.info({currentElem:pointer.children[i],currentPath,length:currentPath.length},'current pointer')
          let cur = currentPointer.children.find((elem) => {
            return currentPath[j].name === elem.name;
          });
          if (!cur) {
            cur = {
              name: currentPath[j].name,
              id: currentPath[j].id,
              quarantine: currentPath[j].quarantine || 'false',
              type: currentPath[j].type,
              totalAssets: currentPath[j].totalAssets,
              allAssetCount: currentPath[j].allAssetCount,
              percentNotCoveredByPolicy: currentPath[j].percentNotCoveredByPolicy,
              firewallRuleCount: (currentPath[j].firewallRuleCount || 0),
              allowCount: (currentPath[j].allowCount || 0),
              denyCount: (currentPath[j].denyCount || 0),
              children: []
            };
            currentPointer.children.push(cur);
          } else {
            cur.totalAssets = currentPath[j].totalAssets;
            cur.totalAssetsNotCoveredByPolicy = currentPath[j].totalAssetsNotCoveredByPolicy;
            cur.firewallRuleCount = currentPath[j].firewallRuleCount || 0;
            cur.allowCount = currentPath[j].allowCount || 0;
            cur.denyCount = currentPath[j].denyCount || 0;
            cur.percentNotCoveredByPolicy = currentPath[j].percentNotCoveredByPolicy;
            cur.allAssetCount = currentPath[j].allAssetCount;
          }
          currentPointer = cur;
        }
        currentPointer.children.push(pointer.children[i]);
      }
    }
  }

  getAssetDataByVmIds(orgId,vmIds) {
    return Asset.getAssetDataByVmIds(orgId,vmIds);
  }

  async getAssetRepos(organizationId) {
    return assetRepoService.getAllAssetRepoEndpoints(organizationId, null, null, 'All');
  }

  async caveoLogs(orgId, username, password, searchParams = null, namedParams = {}, offset = 0, cookie, refresh_token, token = null, authToken = null) {
    const np = new NetworkForensics(this.serviceUri, username, password, cookie, token, authToken);
    let d = await np.caveoLogs(orgId, searchParams, namedParams, offset, cookie);
    if (d.data && d.data.length === 0 && config.forensics_enabled === false) {
      const obj = await this.elasticReLogin(refresh_token);
      cookie = obj.access_token;
      refresh_token = obj.refresh_token;
      d = await np.caveoLogs(orgId, searchParams, namedParams, offset, cookie);
    }
    const { data, mapping, count, startDate, endDate } = d;
    return { data, mapping, count, startDate, endDate, offset, cookie, refresh_token };
  }

  async caveoFlowLogs(orgId, username, password, searchParams = null, namedParams = {}, offset = 0, cookie, refresh_token, token = null, authToken = null) {
    const np = new NetworkForensics(this.serviceUri, username, password, cookie, token, authToken);
    let d = await np.caveoFlowLogs(orgId, searchParams, namedParams, offset, cookie);
    if (((d.data && d.data.length === 0) || d.length === 0) && config.forensics_enabled === false) {
      const obj = await this.elasticReLogin(refresh_token);
      cookie = obj.access_token;
      refresh_token = obj.refresh_token;
      d = await np.caveoFlowLogs(orgId, searchParams, namedParams, offset, cookie);
    }
    const { data, mapping, count, startDate, endDate } = d;
    return { data, mapping, count, startDate, endDate, offset, cookie, refresh_token };
  }

  async caveoScanLogs(orgId, username, password, searchParams = null, namedParams = {}, offset = 0, cookie, refresh_token, token = null, authToken = null) {
    const np = new NetworkForensics(this.serviceUri, username, password, cookie, token, authToken);
    let d = await np.caveoScanLogs(orgId, searchParams, namedParams, offset, cookie);
    if (((d.data && d.data.length === 0) || d.length === 0) && config.forensics_enabled === false) {
      const obj = await this.elasticReLogin(refresh_token);
      cookie = obj.access_token;
      refresh_token = obj.refresh_token;
      d = await np.caveoScanLogs(orgId, searchParams, namedParams, offset, cookie);
    }
    const { data, mapping, count, startDate, endDate } = d;

    return { data, mapping, count, startDate, endDate, offset, cookie, refresh_token };
  }

  async caveoEventTrend(orgId, username, password, cookie, refresh_token, token = null, authToken = null) {
    const np = new NetworkForensics(this.serviceUri, username, password, cookie, token, authToken);
    let d = await np.caveoEventTrend(orgId, cookie);
    if (((d.data && d.data.length === 0) || d.length === 0) && config.forensics_enabled === false) {
      const obj = await this.elasticReLogin(refresh_token);
      cookie = obj.access_token;
      refresh_token = obj.refresh_token;
      d = await np.caveoEventTrend(orgId, cookie);
    }
    return { data: d, cookie, refresh_token };
  }

  async caveoFlowEventTrend(orgId, username, password, cookie, refresh_token, token = null, authToken = null) {
    const np = new NetworkForensics(this.serviceUri, username, password, cookie, token, authToken);
    let d = await np.caveoFlowsEventTrend(orgId, cookie);
    if (((d.data && d.data.length === 0) || d.length === 0) && config.forensics_enabled === false) {
      const obj = await this.elasticReLogin(refresh_token);
      cookie = obj.access_token;
      refresh_token = obj.refresh_token;
      d = await np.caveoFlowsEventTrend(orgId, cookie);
    }
    return { data: d, cookie, refresh_token };
  }

  async caveoScanEventTrend(orgId, username, password, cookie, refresh_token, token = null, authToken = null) {
    const np = new NetworkForensics(this.serviceUri, username, password, cookie, token, authToken);
    let d = await np.caveoScanEventTrend(orgId, cookie);
    if (((d.data && d.data.length === 0) || d.length === 0) && config.forensics_enabled === false) {
      const obj = await this.elasticReLogin(refresh_token);
      cookie = obj.access_token;
      refresh_token = obj.refresh_token;
      d = await np.caveoScanEventTrend(orgId, cookie);
    }
    return { data: d, cookie, refresh_token };
  }

  async elasticLogin(username, password, token) {
    if (config.forensics_enabled === true) {
      const url = `${this.serviceUri}`;
      const auth = 'Basic ' + new Buffer(username + ':' + password).toString('base64');
      try {
        await rp.get(url, {
          json: true,
          rejectUnauthorized: false,
          headers: { Authorization: auth, RiskForeSight: token }
        });
        return { access_token: new Buffer(username + ':' + password).toString('base64'), refresh_token: '' };
      } catch (e) {
        logger.error({ e, stack: e.stack }, 'error occurred logging into elastic search');
        return {};
      }
    } else {
      const url = `${this.serviceUri}/_security/oauth2/token`;
      const body = {
        grant_type: 'password',
        username,
        password
      };
      const super_pass = await this.keyGenerator.decryptKeys(this.servicePass);
      const auth = 'Basic ' + new Buffer(this.serviceUserName + ':' + super_pass).toString('base64');
      try {
        const data = await rp.post(url, {
          json: true,
          rejectUnauthorized: false,
          body,
          headers: { Authorization: auth }
        });
        return { access_token: data.access_token, refresh_token: data.refresh_token };
      } catch (e) {
        logger.error({ e, stack: e.stack }, 'error occurred logging into elastic search');
        return {};
      }

    }
  }

  async elasticReLogin(refresh_token) {
    const url = `${this.serviceUri}/_security/oauth2/token`;
    const body = {
      grant_type: 'refresh_token',
      refresh_token
    };
    const superPass = await this.keyGenerator.decryptKeys(this.servicePass);
    const auth = 'Basic ' + new Buffer(this.serviceUserName + ':' + superPass).toString('base64');
    try {
      const data = await rp.post(url, {
        json: true,
        rejectUnauthorized: false,
        body,
        headers: { Authorization: auth }
      });
      return { access_token: data.access_token, refresh_token: data.refresh_token };
    } catch (e) {
      logger.error({ e, stack: e.stack }, 'error occurred logging into elastic search');
      return {};
    }
  }

  async getNetworkDataForAsset(orgId, assetId, token, authToken) {
    const decryptedPassword = await this.keyGenerator.decryptKeys(this.servicePass);
    const nf = NetworkFlowsFactory.createNetworkFlows({}, this.serviceUri, this.serviceUserName, decryptedPassword, this.cache, true, token, authToken);
    const asset = await Asset.findByPk(assetId);
    if (!asset) {
      const error = new Error('Asset not Found');
      error.status = 404;
      throw error;
    }
    try {
      return nf.getNetworkDataForAsset(orgId, [asset.vmId]);
    } catch (error) {
      error.status = 400;
      throw error;
    }
  }


  async getNetworkFlowsPage(orgId, date, control, where,  refresh = false, mode = 'normal', token = null, authToken = null,  offset = DEFAULT_FLOWS_OFFSET, limit = DEFAULT_FLOWS_LIMIT) {
    const data = await this.getNetworkFlowsPageByAppGroup(orgId, date, control, where, refresh, mode, token, authToken, offset, limit);
    if (mode === 'uniqueLists') {
      return { uniqueLists: data.ribbonGraph.uniqueLists };
    }

    return data;
  }
  async getNetworkFlowsPageByAppGroup(orgId, date, control, condition, refresh = false, mode,  token = null, authToken = null, offset = DEFAULT_FLOWS_OFFSET, limit = DEFAULT_FLOWS_LIMIT) {

    const assetGroupsByAppGroupData = await this.getAssetGroupsByAppGroup(orgId, condition);
    const uniqueLists = assetGroupsByAppGroupData.uniqueLists;
    const assetGroups = assetGroupsByAppGroupData.assetGroups;
    const assetGroupsByLocationData = await this.getAssetGroupsByLocation(orgId, condition);
    const assetGroupsByLocation = assetGroupsByLocationData.assetGroups;
    const assetGroupsBySubApplicationData = await this.getAssetGroupsBySubApplication(orgId, condition);

    // --- create combined uniqueList
    uniqueLists['Sub-Application'] = assetGroupsBySubApplicationData.uniqueLists['Sub-Application'];
    uniqueLists['Location'] = assetGroupsByLocationData.uniqueLists['Location'];

    if (mode === 'uniqueLists') {
      return Promise.resolve({ ribbonGraph: { uniqueLists: Object.values(uniqueLists) } });
    }

    const pass = await this.keyGenerator.decryptKeys(this.servicePass);
    const nf = NetworkFlowsFactory.createNetworkFlows(assetGroups, this.serviceUri, this.serviceUserName, pass, this.cache, refresh, token, authToken);
    const nfForLocation = NetworkFlowsFactory.createNetworkFlows(assetGroupsByLocation, this.serviceUri, this.serviceUserName, pass, this.cache, refresh, token, authToken);
    logger.info({ assetGroups }, 'the assetGroups');
    const mostRecentDate = await nf.getMostRecentDateWithData(orgId);
    const userDate = new Date(date);
    let d = userDate > mostRecentDate ? mostRecentDate : userDate;
    if (d == null) d = new Date();
    const datePrev = new Date(d.valueOf() - 1000 * 3600 * 24); // work around bug in Date, subtracting 1 day does not work in some corner cases, using 24 hours does work
    const dayData = await Promise.all([nf.calculateRibbons(d), nf.calculateRibbons(datePrev)]);
    const ribbonData = dayData[0];
    delete ribbonData.portMap;

    const data = await Promise.all([
      Promise.resolve(ribbonData),
      nf.calculateTrafficOverTime(d),
      nf.statistics(d),
      nf.sortFlowsByPort(d),
      nfForLocation.sortFlowsByContainer(d),
      this._getFlowsTabular(nf, d, control, offset, limit)
    ]);

    return Promise.resolve({
      ribbonGraph: { data: data[0], uniqueLists: Object.values(uniqueLists) },
      totalFlow: data[1],
      distributionTable: data[2],
      topFlowsByPort: data[3],
      topFlowsBy: data[4].slice(0, 5),
      flowTabularData: data[5],
      dateUsed: d
    });
  }

  async getAssetGroupsByAppGroup(orgId, condition) {
    const uniqueLists = {
      'Sub-Application': { label: 'Sub-Application', path: 'application_name', items: [] },
      Application: { label: 'Application', path: 'application_grp_name', items: [] },
      Organization: { label: 'Organization', path: 'organization_name', items: [] }
    };
    const orgChain = await orgService.getOrgChain(orgId);
    // return db.Asset.findAll({
    //   where: { organization_id: orgId },
    //   attributes: ['vmId'],
    //   include: [{ model: db.ApplicationTag, attributes: ['id', 'name'] }]
    //   //
    // });
    const assets = await sequelize.query(
        `select vmid,application_grp_name,application_name,organization_id,organization_name from application_group_asset_view ${whereCondition(...conditionFilter(condition), ` application_grp_org_id in (:orgChain)`)} group by vmid, application_grp_name,application_name,organization_id,organization_name`,
        {
          replacements: { orgChain },
          type: sequelize.QueryTypes.SELECT
        }
    );
    const appGroupMap = {};
    const appGroupApplicationOrgIdMap = {};
    logger.silly({ assets }, 'returned assets ');
    assets.map(assetInfo => {
      if (assetInfo.vmid) {
        if (!appGroupMap[assetInfo.application_grp_name]) appGroupMap[assetInfo.application_grp_name] = [];
        appGroupMap[assetInfo.application_grp_name].push(assetInfo.vmid);
        uniqueLists['Application'].items.push(assetInfo.application_grp_name);
      }
      if (!appGroupApplicationOrgIdMap[assetInfo.application_grp_name]) appGroupApplicationOrgIdMap[assetInfo.application_grp_name] = [];
      appGroupApplicationOrgIdMap[assetInfo.application_grp_name].push(assetInfo.organization_id);
      uniqueLists['Organization'].items.push(assetInfo.organization_name);

    });
    // uniqueLists['Application'].push('EXTERNAL')
    // uniqueLists['Application'].push('INTERNET')
    uniqueLists['Application'].items = Array.from(new Set(uniqueLists['Application'].items));
    uniqueLists['Organization'].items = Array.from(new Set(uniqueLists['Organization'].items));

    const assetGroups = [];
    logger.info({ appGroupMap }, 'appGroupMap');

    Object.keys(appGroupMap).forEach(key => {
      const orgIds = Array.from(new Set(appGroupApplicationOrgIdMap[key]));
      if (!orgIds.includes(orgId)) {
        orgIds.push(orgId);  // we push orgId into list for vmware where flows are all under top org
      }
      assetGroups.push({
        containerName: key,
        members: {
          options: {
            location: '*',
            serviceProvider: '*',
            organization: orgIds
          },
          objects: appGroupMap[key]
        }
      });
    });
    return Promise.resolve ({
      uniqueLists: uniqueLists,
      assetGroups: assetGroups
    });
  }

  async getAssetGroupsByLocation(orgId, condition) {
    const uniqueLists = { Location: { label: 'Location', path: 'location', items: [] },
      Organization: { label: 'Organization', path: 'organization_name', items: [] }};
    //parent_org_id = data[0][0].parent_org_id
    const orgChain = await orgService.getOrgChain(orgId);

    const assets = await sequelize.query(
        `select vmid,location, location_id, organization_id, organization_name from application_group_asset_view ${whereCondition(...conditionFilter(condition), ` application_grp_org_id in (:orgChain)`)} group by vmid, location, location_id, organization_id, organization_name`,
        {
          replacements: { orgChain },
          type: sequelize.QueryTypes.SELECT
        }
    );
    const locationMap = {};
    const locationOrgMap = {};
    assets.map(assetInfo => {

      if (assetInfo.vmid) {
        if (!locationMap[assetInfo.location]) locationMap[assetInfo.location] = [assetInfo.location_id];
        locationMap[assetInfo.location].push(assetInfo.vmid);
        uniqueLists['Location'].items.push(assetInfo.location);

        if (!locationOrgMap[assetInfo.location]) locationOrgMap[assetInfo.location] = [];
        locationOrgMap[assetInfo.location].push(assetInfo.organization_id);
        uniqueLists['Organization'].items.push(assetInfo.organization_name);
      }
    });
    uniqueLists['Location'].items = Array.from(new Set(uniqueLists['Location'].items));
    uniqueLists['Organization'].items = Array.from(new Set(uniqueLists['Organization'].items));
    const assetGroups = [];
    logger.info({ locationMap }, 'locationMap');

    Object.keys(locationMap).forEach(key => {
      const orgIds = Array.from(new Set(locationOrgMap[key]));
      assetGroups.push({
        containerName: key,
        members: {
          options: {
            location: '*',
            serviceProvider: '*',
            organization: orgIds
          },
          objects: locationMap[key]
        }
      });
    });
    return Promise.resolve ({
      uniqueLists: uniqueLists,
      assetGroups: assetGroups
    });
  }

  async getAssetGroupsBySubApplication(orgId, condition) {
    const uniqueLists = { 'Sub-Application': { label: 'Sub-Application', path: 'application_name', items: [] },
      Organization: { label: 'Organization', path: 'organization_name', items: [] } };
    const orgChain = await orgService.getOrgChain(orgId);

    const assets = await sequelize.query(
        `select vmid,application_name,application_grp_name,organization_id,organization_name from application_group_asset_view ${whereCondition(...conditionFilter(condition), ` application_grp_org_id in (:orgChain)`)} group by vmid,application_grp_name, application_name,organization_id,organization_name`,
        {
          replacements: { orgChain },
          type: sequelize.QueryTypes.SELECT
        }
    );
    const applicationMap = {};
    const applicationOrgIdMap = {};
    logger.silly({ assets }, 'returned assets ');
    assets.map(assetInfo => {

      if (assetInfo.vmid) {
        if (!applicationMap[assetInfo.application_name]) applicationMap[assetInfo.application_name] = [];
        applicationMap[assetInfo.application_name].push(assetInfo.vmid);
        uniqueLists['Sub-Application'].items.push(assetInfo.application_name);
      }
      if (!applicationOrgIdMap[assetInfo.application_name]) applicationOrgIdMap[assetInfo.application_name] = [];
      applicationOrgIdMap[assetInfo.application_name].push(assetInfo.organization_id); // this assumes that all the app group for application are the same org
      uniqueLists['Organization'].items.push(assetInfo.organization_name);

    });

    uniqueLists['Sub-Application'].items = Array.from(new Set(uniqueLists['Sub-Application'].items));
    uniqueLists['Organization'].items = Array.from(new Set(uniqueLists['Organization'].items));
    const assetGroups = [];
    logger.info({ applicationMap }, 'applicationMap');

    Object.keys(applicationMap).forEach(key => {
      const orgIds = Array.from(new Set(applicationOrgIdMap[key]));
      if (!orgIds.includes(orgId)) {
        orgIds.push(orgId);  // we push orgId into list for vmware where flows are all under top org
      }
      assetGroups.push({
        containerName: key,
        members: {
          options: {
            location: '*',
            serviceProvider: '*',
            organization: orgIds
          },
          objects: applicationMap[key]
        }
      });
    });
    return Promise.resolve ({
      uniqueLists: uniqueLists,
      assetGroups: assetGroups
    });
  }
};
