const NetworkFlowController = require('./networkFlow.controller');

/**
 * @swagger
 * tags:
 *  - name: NetworkFlow
 *    description: Network flow endpoints
 */
module.exports = class NetworkFlowRoutes {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.networkFlowController = new NetworkFlowController();

      // initializing route
      this.initOrganization(router);
    }
  }

  initOrganization(router) {

    /**
     * @swagger
     *
     * /api/organization/{orgId}/networkFlow/dashboardInfo:
     *   get:
     *     tags:
     *       - NetworkFlow
     *     summary: Gets the network dashboard info
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of network flows
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/dashboardInfo`, this.networkFlowController.getDashboardInfo);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/networkFlow/flows:
     *   get:
     *     tags:
     *       - NetworkFlow
     *     summary: Gets the Network Flows page data
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of network flows
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/flows`, this.networkFlowController.getNetworkFlowsPage);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/networkFlow/policiesRisk:
     *   get:
     *     tags:
     *       - NetworkFlow
     *     summary: Gets the Network Policies Risk page data
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of network flows
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/policiesRisk`, this.networkFlowController.getNetworkPoliciesRiskPage);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/networkFlow/policiesCompliance:
     *   get:
     *     tags:
     *       - NetworkFlow
     *     summary: Gets the Network Policies Compliance page data
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of network flows
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/policiesCompliance`, this.networkFlowController.getNetworkPoliciesCompliancePage);
    this.router.get(`${this.path}/asset/:assetId`, this.networkFlowController.getNetworkDataForAsset);

    module.exports = router;
  }
};
