const JobManager = require('../../../config/bull.conf');
const logger = require('../../../utils/logger').logger;
const _ = require('lodash');
const CaveoNotification = require('../../models/notifications.model');

class NotificationJobListener {
  constructor() {
    this.QUEUE_NAME = 'notifications';
    this.handlers = { default: this.defaultHandler.bind(this) };
    JobManager.registerConsumer(this.QUEUE_NAME, this.jobQueueListener.bind(this));
  }

  addHandler(messageType, handler) {
    this.handlers[messageType] = handler;
  }

  async defaultHandler(params) {
    params.message = params.error ? params.error.message : 'No Handler Registered';
    params.failed = true;
    CaveoNotification.build({ detail: params, action: 'Failed', user_id: params.userId });

  }

  async jobQueueListener(params) {
    logger.debug({ params }, 'params');
    const handler = _.get(this.handlers, params.type, this.defaultHandler.bind(this));

    try {
      await handler(params);
      // return;
    } catch (error) {
      params.error = error;
      await this.defaultHandler(params);

    }
  }
}

module.exports = new NotificationJobListener();
