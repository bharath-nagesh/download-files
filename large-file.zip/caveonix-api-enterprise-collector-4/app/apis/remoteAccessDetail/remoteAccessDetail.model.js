const Sequelize = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();

/**
 * @swagger
 * components:
 *   schemas:
 *     RemoteAccessDetail:
 *       type: object
 *       required:
 *         - linuxSPUsername
 *         - linuxSPPassword
 *         - windowsSPUsername
 *         - windowsSPPassword
 *         - type
 *         - salt
 *         - connectionName
 *         - ssh_key
 *         - isActive
 *       properties:
 *         linuxSPUsername:
 *           type: string
 *         linuxSPPassword:
 *           type: string
 *         windowsSPUsername:
 *           type: string
 *         windowsSPPassword:
 *           type: string
 *         type:
 *           type: string
 *         salt:
 *           type: string
 *         connectionName:
 *           type: string
 *         ssh_key:
 *           type: string
 *         isActive:
 *           type: string
 * @param sequelize
 */
class RemoteAccessDetail extends Sequelize.Model {
  static init(sequelize) {
    return super.init({
      linuxSPUsername: { type: Sequelize.STRING, field: 'linux_sp_username' },
      linuxSPPassword: { type: Sequelize.STRING, field: 'linux_sp_password' },
      windowsSPUsername: { type: Sequelize.STRING, field: 'windows_sp_username' },
      windowsSPPassword: { type: Sequelize.STRING, field: 'windows_sp_password' },
      type: { type: Sequelize.STRING, field: 'type' },
      salt: { type: Sequelize.STRING, field: 'salt' },
      connectionName: { type: Sequelize.STRING, field: 'connection_name' },
      ssh_key: { type: Sequelize.STRING, field: 'ssh_key_file' },
      ssh_keyPassPhrase: { type: Sequelize.STRING, field: 'ssh_key_passphrase', allowNull: true },
      sshParameters: {type: Sequelize.JSON, field: 'ssh_parameters'},
      isActive: { type: Sequelize.BOOLEAN, field: 'is_active', defaultValue: true, allowNull: false },
      is_active: { type: Sequelize.BOOLEAN, field: 'is_active' },
      ecHostName: { type: Sequelize.STRING, field: 'ec_host_name', allowNull: true },
      locationId: { type: Sequelize.INTEGER, field: 'location_id', defaultValue: 0 },
      hostingProviderId: { type: Sequelize.INTEGER, field: 'hosting_provider_id', defaultValue: 0 }
    },
    { sequelize, timestamps: true, freezeTableName: true, tableName: 'remote_access_details', underscored: true }
    );
  }

  static associate(models) {
    RemoteAccessDetail.belongsTo(models.Organization, { allowNull: false, foreignKey: 'organization_id' });
    RemoteAccessDetail.hasMany(models.AssetRemoteAccessDetailMembers);
    RemoteAccessDetail.belongsToMany(models.Asset, {
      through: 'asset_remote_access_detail_members',
      otherKey: 'asset_id',
      foreignKey: 'remote_access_detail_id'
    });
  };
}

module.exports = RemoteAccessDetail;
