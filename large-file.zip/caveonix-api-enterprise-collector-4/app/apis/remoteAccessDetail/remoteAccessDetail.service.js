const { get, map, isNil } = require('lodash');
const sequelize = require('../../../config/db.conf').getConnection();
const AssetRemoteAccessDetailMembers = require('../assetRemoteAccessDetailMembers/assetRemoteAccessDetailMembers.model');
const KeyGenerator = require('../../../utils/generateKeys');
const logger = require('../../../utils/logger').logger;
const Organization = require('../organization/organization.model');
const RemoteAccessDetail = require('./remoteAccessDetail.model');
const ScheduleTask = require('../../models/scheduleTask.model');
const removeSpace = require('../../../utils/checkSpaces');
const validator = require('validator');

const loggerLabel = 'RemoteAccessDetailService';

module.exports = class RemoteAccessDetailService {
  constructor() {
    this.keyGenerator = new KeyGenerator();
    logger.debug('called constructor');
  }

  async getRemoteAccessDetail(remoteAccessDetailId, orgId = -88, showPassword = false) {
    logger.debug('Retrieving remote access detail', { loggerLabel });
    logger.silly(`for remoteAccessDetailId ${remoteAccessDetailId}`, { loggerLabel });

    const where = { id: remoteAccessDetailId, isActive: { $ne: 'false' } };
    const exclude = ['ssh_keyPassPhrase'];

    if (!showPassword) {
      exclude.push(...['linuxSPPassword', 'windowsSPPassword', 'salt'])
    }

    if (orgId !== -88) {
      where.organization_id = await Organization.getReportingOrgChain(orgId)
    }

    const include = this.getRemoteAccessDetailsInclude();
    const remoteAccessDetail = await RemoteAccessDetail.findOne({
      attributes: { exclude },
      where,
      include
    });
    if (get(remoteAccessDetail,'sshParameters')) {
      try {
        const sshParameters = JSON.parse(get(remoteAccessDetail,'sshParameters'));
        delete sshParameters.password;
        remoteAccessDetail.setDataValue('sshParameters',sshParameters);

      } catch (error) {
         logger.warn('Unable to parse parameters', { error, loggerLabel });

      }
    }

    return remoteAccessDetail;
  }

  async getAllRemoteAccessDetails(orgId, limit, offset) {
    logger.debug('Retrieving remote access details', { loggerLabel });
    logger.silly(`for orgId ${orgId}`, { loggerLabel });

    const orgArr = await Organization.getReportingOrgChain(orgId);
    const include = this.getRemoteAccessDetailsInclude();

    return RemoteAccessDetail.findAll({
      where: { organization_id: orgArr, isActive: { $ne: 'false' } },
      attributes: ['id', 'connectionName', 'linuxSPUsername', 'windowsSPUsername', 'type','ssh_key', 'ssh_keyPassPhrase','isActive'],
      order: [['id', 'ASC']],
      include,
      limit: limit,
      offset: offset
    });
  }

  async getRemoteAccessDetailsCount(orgId) {

    logger.debug('Retrieving remote access details count', { loggerLabel });
    logger.silly(`for orgId ${orgId}`, { loggerLabel });

    return RemoteAccessDetail.count({
      where: { isActive: { $ne: 'false' }
      },
      order: [['id', 'ASC']]
    });
  }

  async updateRemoteAccessDetail(remoteAccessDetailId, orgId, params, loggedInUserId, userToken) {

    logger.debug('Updating remote access detail', { loggerLabel });
    logger.silly(`for remoteAccessDetailId ${remoteAccessDetailId} for orgId ${orgId}`, { loggerLabel });

    if (get(params,'isActive') === 'disabled') {
      const scheduleJobwithScanCredential = await ScheduleTask.count({where: { id: remoteAccessDetailId }});
      if ( scheduleJobwithScanCredential > 0 ) {
        logger.error(`Cannot disable a scan credential that is associated to a scheduled job with id ${remoteAccessDetailId}.`, { loggerLabel });
        const error = new Error('Cannot disable a scan credential that is associated to a scheduled job');
        error.status = 400;
        throw error;
      }
    }

    const remoteAccessDetail = await this.getRemoteAccessDetail(remoteAccessDetailId, orgId);
    const name = params.connectionName;
    const newName = removeSpace.checkMultiSpace(name);
    let type = params.type;
    type = type.toLowerCase();
    await this.checkRemoteAccessDetailForUpdate(remoteAccessDetailId, params.organization_id, type);
    const exists = await this.checkNameForUpdate(newName, remoteAccessDetailId, orgId);
    if (exists) {
      const err = new Error('Duplicate Remote Access Connection name.');
      err.status = 400;
      throw err;
    }
    params.connectionName = newName;
    //check for type SU password is new or empty
    let sshParams = get(remoteAccessDetail,'sshParameters');
    if(get(params,'sshParameters.type') === 'SU') {
        params.sshParameters.user = !isNil(get(params,'sshParameters.user')) ? params.sshParameters.user : sshParams.user;
        params.sshParameters.password = !isNil(get(params,'sshParameters.password')) ? await this.keyGenerator.generateKeys(get(params,'sshParameters.password')) : sshParams.password;
      }
    await this.update(remoteAccessDetail, remoteAccessDetailId, orgId, params, loggedInUserId, userToken);
    return this.getRemoteAccessDetail(remoteAccessDetail.id);
  }

  async create(orgId, params, loggedInUserId, userToken) {
    logger.debug('Creating remote access detail', { loggerLabel });
    logger.silly(`for orgId ${orgId}`, { loggerLabel });

    const service = this;
    if (!params.type) params.type = 'default';
    let type = params.type;
    params.salt = params.key || params.salt;
    const newSalt = removeSpace.checkMultiSpace(params.salt);
    type = type.toLowerCase();
    await this.checkRemoteAccessDetail(params.organization_id, type);
    const exists = await Promise.all([
      this.keyGenerator.generateKeys(params.linuxSPPassword, params.salt),
      this.keyGenerator.generateKeys(params.windowsSPPassword, params.salt),
      this.checkLinuxSPUsername(orgId, params.linuxSPUsername, null),
      this.checkWindowsSPUsername(orgId, params.windowsSPUsername, null)
    ]);
    params.linuxSPPassword = exists[0];
    params.windowsSPPassword = exists[1];
    const name = params.connectionName;
    const newName = removeSpace.checkMultiSpace(name);
    const checkNameExists = await this.checkName(newName, orgId);
    if (checkNameExists) {
      const err = new Error('Duplicate Remote Access Connection name.');
      err.status = 400;
      throw err;
    }
    params.salt = newSalt;
    params.connectionName = newName;
    if (newSalt.length <= 0) params.salt = null;
    if (validator.contains(params.linuxSPUsername, '\\')) {
      const hostName = params.linuxSPUsername;
      const a = hostName.replace('\\', '\\\\');
      params.linuxSPUsername = a;
    }
    if (validator.contains(params.windowsSPUsername, '\\')) {
      const windowsSPUsername = params.windowsSPUsername;
      const b = windowsSPUsername.replace('\\', '\\\\');
      params.windowsSPUsername = b;
    }
    const linuxSPPassword = params.linuxSPPassword;
    const windowsSPPassword = params.windowsSPPassword;
    params.ssh_keyPassPhrase = params.ssh_keyPassPhrase ? await this.keyGenerator.generateKeys(params.ssh_keyPassPhrase) : null;
    if(get(params,'sshParameters.type') === 'SU') {
      params.sshParameters.password = !isNil(get(params,'sshParameters.password')) ? await this.keyGenerator.generateKeys(get(params,'sshParameters.password')) : null;
    }
    params.hosting_provider_id = get(params,'hosting_provider_id',0);
    params.location_id = get(params,'location_id',0);
    const remoteAccDtl = await RemoteAccessDetail.create(params);
    const remoteAccDtlId = remoteAccDtl.id;
    params.id = remoteAccDtlId;
    params.linuxSPPassword = linuxSPPassword;
    params.windowsSPPassword = windowsSPPassword;
    params.remoteAccessDetailId = remoteAccDtl.id;
    const assetArray = params.assets;
    if (assetArray && assetArray.length > 0) {
      params.remote_access_detail_id = remoteAccDtlId;
      await service.createAssetRemoteAccessDetailMembers(params, assetArray);
    }
    return RemoteAccessDetail.findByPk(remoteAccDtlId, { include: [{ model: AssetRemoteAccessDetailMembers }] });
  }

  async createVCD(orgId, params, loggedInUserId, userToken) {
    if (!params.type) params.type = 'default';
    let type = params.type;
    params.salt = params.key || params.salt;
    const newSalt = removeSpace.checkMultiSpace(params.salt);
    type = type.toLowerCase();
    await this.checkRemoteAccessDetail(params.organization_id, type);
    const exists = await Promise.all([
      this.keyGenerator.generateKeys(params.linuxSPPassword, params.salt),
      this.keyGenerator.generateKeys(params.windowsSPPassword, params.salt),
      this.checkLinuxSPUsername(orgId, params.linuxSPUsername, null),
      this.checkWindowsSPUsername(orgId, params.windowsSPUsername, null)
    ]);
    params.linuxSPPassword = exists[0];
    params.windowsSPPassword = exists[1];
    const linuxSPPassword = params.linuxSPPassword;
    const windowsSPPassword = params.windowsSPPassword;
    const name = params.connectionName;
    const newName = removeSpace.checkMultiSpace(name);
    const checkNameExists = await this.checkName(newName, orgId);
    if (checkNameExists) {
      const err = new Error('Duplicate Remote Access Connection name.');
      err.status = 400;
      throw err;
    }
    params.salt = newSalt;
    params.connectionName = newName;
    if (newSalt.length <= 0) params.salt = null;
    if (params.linuxSPUsername && validator.contains(params.linuxSPUsername, '\\')) {
      const hostName = params.linuxSPUsername;
      const a = hostName.replace('\\', '\\\\');
      params.linuxSPUsername = a;
    }
    if (params.windowsSPUsername && validator.contains(params.windowsSPUsername, '\\')) {
      const windowsSPUsername = params.windowsSPUsername;
      const b = windowsSPUsername.replace('\\', '\\\\');
      params.windowsSPUsername = b;
    }
    const remoteAccDtl = await RemoteAccessDetail.create(params);
    const remoteAccDtlId = remoteAccDtl.id;
    params.id = remoteAccDtlId;
    params.linuxSPPassword = linuxSPPassword;
    params.windowsSPPassword = windowsSPPassword;
    return RemoteAccessDetail.findByPk(remoteAccDtlId, { include: [{ model: AssetRemoteAccessDetailMembers }] });
  }

  async updateVCDAccessDetail(remoteAccessDetailId, orgId, params, loggedInUserId, userToken) {
    const remoteAccessDetail = await this.getRemoteAccessDetail(remoteAccessDetailId);
    const name = params.connectionName;
    const newName = removeSpace.checkMultiSpace(name);
    let type = params.type;
    type = type.toLowerCase();
    await this.checkRemoteAccessDetailForUpdate(remoteAccessDetailId, params.organization_id, type);
    const exists = await this.checkNameForUpdate(newName, remoteAccessDetailId, orgId);
    if (exists) {
      const err = new Error('Duplicate Remote Access Connection name.');
      err.status = 400;
      throw err;
    }
    params.connectionName = newName;
    await this.updateVCD(remoteAccessDetail, remoteAccessDetailId, orgId, params, loggedInUserId, userToken);
    return this.getRemoteAccessDetail(remoteAccessDetail.id);
  }

  async deleteById(remoteAccessDetailId) {
    await RemoteAccessDetail.update({ isActive: false }, { where: { id: remoteAccessDetailId } });
    await AssetRemoteAccessDetailMembers.destroy({ where: { remote_access_detail_id: { $in: remoteAccessDetailId } } });
    return RemoteAccessDetail.findByPk(remoteAccessDetailId);
  }

  async deleteMultipleRemoteAccessDetail(remoteAccessDetailIdArr, orgId, loggedInUserId, userToken) {
    const scheduleJobwithScanCredential = await ScheduleTask.findAll({where: { id: remoteAccessDetailIdArr }});
    if ( scheduleJobwithScanCredential.length > 0 ) {
      logger.error(`Cannot delete a scan credential that is associated to a scheduled job with id ${map(scheduleJobwithScanCredential, item => `${item.id}`)}`, { loggerLabel });
      const error = new Error('Cannot delete a scan credential that is associated to a scheduled job');
      error.status = 400;
      throw error;
    }
    await RemoteAccessDetail.update({ isActive: false }, { where: { id: { $in: remoteAccessDetailIdArr } } });
    await AssetRemoteAccessDetailMembers.destroy({ where: { remote_access_detail_id: { $in: remoteAccessDetailIdArr } } });
    return RemoteAccessDetail.findAll({ where: { id: { $in: remoteAccessDetailIdArr } } });
  }

  async checkRemoteAccessDetail(orgId, type) {
    if (type === 'default' || type === 'vcd') {
      let errorMessage;
      const exists = await RemoteAccessDetail.findOne({
        where: {
          $and: [{ organization_id: orgId }, { type: type }],
          $or: [{ isActive: { $ne: 'false' } }]
        }
      });
      if (exists) {
        if (type === 'default') {
          errorMessage = 'Remote Access Details with default type already exists.';
        } else if (type === 'vcd') {
          errorMessage = 'Remote Access with VCD type already exists.';
        }
        const err = new Error(errorMessage);
        err.status = 400;
        throw err;
      }
    }
  }

  async checkRemoteAccessDetailForUpdate(remoteAccessDetailId, orgId, type) {
    if (type === 'default' || type === 'vcd') {
      let errorMessage;
      const exists = await RemoteAccessDetail.findOne({
        where: {
          $and: [{ id: { $ne: remoteAccessDetailId } }, { organization_id: orgId }, { type: type }],
          $or: [{ isActive: { $ne: 'false' } }]
        }
      });
      if (exists) {
        if (type === 'default') {
          errorMessage = 'Remote Access Details with default type already exists.';
        }
        if (type === 'vcd') {
          errorMessage = 'Remote Access with VCD type already exists.';
        }
        const err = new Error(errorMessage);
        err.status = 400;
        throw err;
      }
    }
  }

  async update(remoteAccessDetail, remoteAccessDetailId, orgId, params, loggedInUserId, userToken) {

    const service = this;
    if (params.salt == null) params.salt = '';
    params.salt = params.key || params.salt;
    const newSalt = removeSpace.checkMultiSpace(params.salt);
    const type = remoteAccessDetail.type;
    logger.info(type, ' the type');

    if (params.linuxSPUsername) {
      const linuxPassHash = await this.keyGenerator.generateKeys(params.linuxSPPassword, params.salt);
      if (params.linuxSPPassword) {
        params.linuxSPPassword = linuxPassHash;
      }
    }
    if (params.windowsSPUsername) {
      const windowsPassHash = await this.keyGenerator.generateKeys(params.windowsSPPassword, params.salt);
      if (params.windowsSPPassword) {
        params.windowsSPPassword = windowsPassHash;
      }
    }

    if (type === 'asset') {
      if (params.linuxSPUsername) {
        await this.checkLinuxSPUsername(orgId, params.linuxSPUsername, remoteAccessDetailId);
        if (params.linuxSPUsername && validator.contains(params.linuxSPUsername, '\\')) {
          const hostName = params.linuxSPUsername;
          const a = hostName.replace('\\', '\\\\').replace('\\\\', '\\');
          params.linuxSPUsername = a;
        }
      }
      if (params.windowsSPUsername) {
        await this.checkWindowsSPUsername(orgId, params.windowsSPUsername, remoteAccessDetailId);
        if (params.windowsSPUsername && validator.contains(params.windowsSPUsername, '\\')) {
          const windowsSPUsername = params.windowsSPUsername;
          const b = windowsSPUsername.replace('\\', '\\\\').replace('\\\\', '\\');
          params.windowsSPUsername = b;
        }
      }
      params.salt = newSalt;
      if (newSalt.length <= 0) params.salt = null;
      await remoteAccessDetail.update(params);
      return service.updateAssetRemoteAccessAsset(remoteAccessDetail, params);

    } else {
      await remoteAccessDetail.update(params);
      return true;
    }
  }

  async updateVCD(remoteAccessDetail, remoteAccessDetailId, orgId, params, loggedInUserId, userToken) {
    if (params.salt == null) params.salt = '';
    params.salt = params.key || params.salt;
    const newSalt = removeSpace.checkMultiSpace(params.salt);
    const [linuxPassHash, windowsPassHash] = await Promise.all([
      this.keyGenerator.generateKeys(params.linuxSPPassword, params.salt),
      this.keyGenerator.generateKeys(params.windowsSPPassword, params.salt)
    ]);
    if (params.linuxSPPassword) {
      params.linuxSPPassword = linuxPassHash;
    }
    if (params.windowsSPPassword) {
      params.windowsSPPassword = windowsPassHash;
    }
    const exists = await Promise.all([
      this.checkLinuxSPUsername(orgId, params.linuxSPUsername, remoteAccessDetailId),
      this.checkWindowsSPUsername(orgId, params.windowsSPUsername, remoteAccessDetailId)
    ]);
    logger.info(exists, 'the exists array');
    const linuxUsernameExists = exists[0];
    if (linuxUsernameExists) {
      const err = new Error('VCD User Name for Asset is already exist.');
      err.status = 400;
      logger.error(err, 'Error occurred');
      throw err;
    }
    params.salt = newSalt;
    if (newSalt.length <= 0) params.salt = null;
    if (params.linuxSPUsername && validator.contains(params.linuxSPUsername, '\\')) {
      const hostName = params.linuxSPUsername;
      const a = hostName.replace('\\', '\\\\').replace('\\\\', '\\');
      params.linuxSPUsername = a;
    }
    if (params.windowsSPUsername && validator.contains(params.windowsSPUsername, '\\')) {
      const windowsSPUsername = params.windowsSPUsername;
      const b = windowsSPUsername.replace('\\', '\\\\').replace('\\\\', '\\');
      params.windowsSPUsername = b;
    }
    await remoteAccessDetail.update(params);
    return true;
  }

  async updateAssetRemoteAccessAsset(remoteAccessDetail, params) {
    const remoteAccDtlId = remoteAccessDetail.id;
    params.remoteAccessDetailId = remoteAccessDetail.id;
    const assetArray = params.assets;

    await AssetRemoteAccessDetailMembers.destroy({ where: { remote_access_detail_id: remoteAccDtlId } });
    if (assetArray && assetArray.length > 0) {
      assetArray.map(function (asset) {
        const updateAsset = {
          remoteAccessDetailId: remoteAccDtlId,
          assetId: asset.assetId,
          vmId: asset.vmId
        };
        return AssetRemoteAccessDetailMembers.create(updateAsset);
      });
    }
  }

  checkLinuxSPUsername(orgId, linuxSPUsername, remoteAccessDetailId, type) {
    if (linuxSPUsername && linuxSPUsername.length > 0) {
      if (remoteAccessDetailId) {
        return RemoteAccessDetail.findOne({
          where: {
            linux_sp_username: sequelize.where(sequelize.fn('LOWER', sequelize.col('linux_sp_username')), sequelize.fn('lower', linuxSPUsername)),
            organization_id: orgId,
            $or: [{ isActive: { $ne: 'false' } }],
            id: { $ne: remoteAccessDetailId }
          }
        });
      } else {
        return RemoteAccessDetail.findOne({
          where: {
            linux_sp_username: sequelize.where(sequelize.fn('LOWER', sequelize.col('linux_sp_username')), sequelize.fn('lower', linuxSPUsername)),
            organization_id: orgId,
            $or: [{ isActive: { $ne: 'false' } }]
          }
        });
      }
    }
  }

  checkWindowsSPUsername(orgId, windowsSPUsername, remoteAccessDetailId) {
    if (windowsSPUsername && windowsSPUsername.length > 0) {
      if (remoteAccessDetailId) {
        return RemoteAccessDetail.findOne({
          where: {
            windows_sp_username: sequelize.where(sequelize.fn('LOWER', sequelize.col('windows_sp_username')), sequelize.fn('lower', windowsSPUsername)),
            organization_id: orgId,
            $or: [{ isActive: { $ne: 'false' } }],
            id: { $ne: remoteAccessDetailId }
          }
        });
      } else {
        return RemoteAccessDetail.findOne({
          where: {
            windows_sp_username: sequelize.where(sequelize.fn('LOWER', sequelize.col('windows_sp_username')), sequelize.fn('lower', windowsSPUsername)),
            organization_id: orgId,
            $or: [{ isActive: { $ne: 'false' } }]
          }
        });
      }
    }
  }

  checkName(name, orgId) {
    return RemoteAccessDetail.findOne({
      where: {
        connection_name: sequelize.where(sequelize.fn('LOWER', sequelize.col('connection_name')), sequelize.fn('lower', name)),
        organization_id: orgId,
        $or: [{ isActive: { $ne: 'false' } }]
      }
    });
  }

  checkNameForUpdate(name, remoteAccessDetailId, orgId) {
    return RemoteAccessDetail.findOne({
      where: {
        connection_name: sequelize.where(sequelize.fn('LOWER', sequelize.col('connection_name')), sequelize.fn('lower', name)),
        organization_id: orgId,
        $or: [{ isActive: { $ne: 'false' } }],
        id: { $ne: remoteAccessDetailId }
      }
    });
  }

  async createAssetRemoteAccessDetailMembers(params, assetArray) {
    return assetArray.map( async function (asset) {
      const newParams = {
        remoteAccessDetailId: params.remoteAccessDetailId,
        assetId: asset.assetId,
        vmId: asset.vmId
      };
      return await AssetRemoteAccessDetailMembers.create(newParams);
    });
  }

  /**
   * Generates Includes for RemoteAccessDetails
   */
     getRemoteAccessDetailsInclude() {
      return [
        { model: AssetRemoteAccessDetailMembers },
        { model: Organization, attributes: ['id', 'name', 'aliasName', 'fullName', 'type'] }
      ];
    }

};
