const RemoteAccessDetailController = require('./remoteAccessDetail.controller');

/**
 * @swagger
 * tags:
 *  - name: RemoteAccessDetail
 *    description: Remote Access Detail endpoints
 */
module.exports = class RemoteAccessDetailRoutes {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.remoteAccessDetailController = new RemoteAccessDetailController();

      // initializing route
      if (type === 'Service Provider') {
        this.initServiceProvider();
      } else {
        this.initOrganization();
      }
    }
  }

  initOrganization() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/remoteAccessDetail:
     *   get:
     *     tags:
     *       - RemoteAccessDetail
     *     summary: Gets a list of Remote Access Details
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of Remote Access Details
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/`, this.remoteAccessDetailController.getAllRemoteAccessDetail);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/remoteAccessDetail/{remoteAccessDetailId}:
     *   get:
     *     tags:
     *       - RemoteAccessDetail
     *     summary: Gets a Remote Access Detail by it's id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: remoteAccessDetailId
     *         description: The id of the specified Remote Access Detail.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: remoteAccessDetail
     */
    this.router.get(`${this.path}/:remoteAccessDetailId`, this.remoteAccessDetailController.getRemoteAccessDetailById);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/remoteAccessDetail:
     *   post:
     *     tags:
     *       - RemoteAccessDetail
     *     summary: Creates a Remote Access Detail
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/RemoteAccessDetail'
     *     responses:
     *       200:
     *         description: remoteAccessDetail
     */
    this.router.post(`${this.path}/`, this.remoteAccessDetailController.createRemoteAccessDetail);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/remoteAccessDetail/{remoteAccessDetailId}:
     *   put:
     *     tags:
     *       - RemoteAccessDetail
     *     summary: Updates a Remote Access Detail
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: remoteAccessDetailId
     *         description: The id of the specified Remote Access Detail.
     *         in: path
     *         required: true
     *         type: string
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/RemoteAccessDetail'
     *     responses:
     *       200:
     *         description: remoteAccessDetail
     */
    this.router.put(`${this.path}/:remoteAccessDetailId`, this.remoteAccessDetailController.updateRemoteAccessDetail);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/remoteAccessDetail/{remoteAccessDetailId}:
     *   delete:
     *     tags:
     *       - RemoteAccessDetail
     *     summary: Deletes a Remote Access Detail
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: remoteAccessDetailId
     *         description: The id of the specified Remote Access Detail.
     *         in: path
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: remoteAccessDetail
     */
    this.router.delete(`${this.path}/`, this.remoteAccessDetailController.deleteMultipleRemoteAccessDetail);

     /**
     * @swagger
     *
     * /api/organization/{orgId}/remoteAccessDetail/vcd:
     *   post:
     *     tags:
     *       - RemoteAccessDetail
     *     summary: Creates a Remote Access Detail for VCD organization
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/RemoteAccessDetail'
     *     responses:
     *       200:
     *         description: remoteAccessDetail
     */
    this.router.post(`${this.path}/vcd`, this.remoteAccessDetailController.createVCDAccessDetail);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/remoteAccessDetail/vcd/{remoteAccessDetailId}:
     *   put:
     *     tags:
     *       - RemoteAccessDetail
     *     summary: Updates a Remote Access Detail for VCD organization
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: remoteAccessDetailId
     *         description: The id of the specified Remote Access Detail.
     *         in: path
     *         required: true
     *         type: string
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/RemoteAccessDetail'
     *     responses:
     *       200:
     *         description: remoteAccessDetail
     */
    this.router.put(`${this.path}/vcd/:remoteAccessDetailId`, this.remoteAccessDetailController.updateVCDAccessDetail);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/remoteAccessDetail/vcd:
     *   delete:
     *     tags:
     *       - RemoteAccessDetail
     *     summary: Deletes a Remote Access Detail
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: remoteAccessDetailId
     *         description: The id of the specified Remote Access Detail.
     *         in: path
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: remoteAccessDetail
     */
    this.router.delete(`${this.path}/vcd`, this.remoteAccessDetailController.deleteMultipleRemoteAccessDetail);

  }

  initServiceProvider() {
  }
};
