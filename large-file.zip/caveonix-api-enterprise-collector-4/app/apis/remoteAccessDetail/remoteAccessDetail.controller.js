const { get, includes, toLower } = require('lodash');
const checkId = require('../../../utils/checkId');
const checkName = require('../../../utils/checkName');
const errorHandler = require('../../../utils/errorHandler');
const isAppliance = require('../../../utils/isAppliance');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-remoteAccessDetail.controller'
});
const paginate = require('../../middlewares/paginate.middleware');
const RemoteAccessDetailService = require('./remoteAccessDetail.service');
const remoteAccessDetailService = new RemoteAccessDetailService();
const Validator = require('../../../utils/validator');
const loggerLabel = 'RemoteAccessDetailController';
let instance = null;

module.exports = class RemoteAccessDetailController {

  constructor() {
    logger.debug('initialized', { loggerLabel });
  }

  /**
  * Returns the instance of the RemoteAccess Detail Controller
  * @returns {RemoteAccessDetailController}
  */
  static getInstance() {
    if (!instance) {
      instance = new RemoteAccessDetailController();
    }

    return instance;
  }

  async getAllRemoteAccessDetail(req, res) {
    const orgId = +get(req, 'params.orgId');
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    try {
      const results = await remoteAccessDetailService.getAllRemoteAccessDetails(orgId, limit, offset);
      const itemCount = await remoteAccessDetailService.getRemoteAccessDetailsCount(orgId);
      const pageCount = Math.ceil(itemCount / limit);
      res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        remoteAccessDetails: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getRemoteAccessDetailById(req, res) {
    const remoteAccessDetailId = +get(req, 'params.remoteAccessDetailId');
    const orgId = +get(req, 'params.orgId');
    try {
      const remoteAccessDetail = await remoteAccessDetailService.getRemoteAccessDetail(remoteAccessDetailId, orgId);
      return res.json(remoteAccessDetail);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async createRemoteAccessDetail(req, res) {
    const params = req.body;
    const action = 'create';
    const user = get(req, 'user.username', '');

    try {
      params.isActive = toLower(get(params, 'isActive', 'enabled'));
      await Validator.validateParams({
          connectionName: 'required|maxLength:50|alphaDashSpace',
          salt: 'isXSSFree|maxLength:100',
          type: 'required|in:default,asset,service account',
          organization_id: 'required|integer',
          linuxSPUsername: 'username',
          linuxSPPassword: 'string|maxLength:100',
          ssh_key: 'string|maxLength:100|isXSSFree',
          ssh_keyPassPhrase: 'string|maxLength:100',
          sshParameters : 'object',
          windowsSPUsername: 'username',
          windowsSPPassword: 'string|maxLength:100',
          assets: 'nullable',
          'assets.*.assetId': 'integer',
          'assets.*.vmId': 'alphaDash',
          isActive: 'required|in:enabled,disabled,true'
      }, params);

    } catch (error) {
      if (includes(error.validationErrors, 'The salt value is malformed.')) {
        error.validationErrors[error.validationErrors.indexOf('The salt value is malformed.')] = 'Encryption Passphrase is malformed.';
      }
      if (includes(error.validationErrors, 'The ssh key value is malformed.')) {
        error.validationErrors[error.validationErrors.indexOf('The ssh key value is malformed.')] = 'SSH Key Name is malformed.';
      }
      logger.error('Error occurred while attempting to validate parameters to create remote access detail', { error, loggerLabel, action, user });
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const orgId = params.organization_id;
    const name = params.connectionName;
    const userToken = req.authInfo;
    const loggedInUserId = req.user.id;
    const exists = await remoteAccessDetailService.checkName(name, orgId);
    if (exists) {
      logger.info({ name }, 'Duplicate Remote Access Connection name.');
      const error = new Error('Duplicate Remote Access Connection name.');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const remoteAccessDetail = await remoteAccessDetailService.create(orgId, params, loggedInUserId, userToken);
      if (remoteAccessDetail) {
        const result = await remoteAccessDetailService.getRemoteAccessDetail(remoteAccessDetail.id, orgId);
        return res.json(result);
      }
      return res.json(remoteAccessDetail);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async createVCDAccessDetail(req, res) {
    const params = req.body;
    const action = 'create';
    const user = get(req, 'user.username', '');

    try {
      params.isActive = toLower(get(params, 'isActive', 'enabled'));
      await Validator.validateParams({
        connectionName: 'required|string',
        salt: 'nullable',
        type: 'required|in:default,asset,service account,vcd',
        organization_id: 'required|integer',
        linuxSPUsername: 'nullable',
        linuxSPPassword: 'nullable',
        ssh_key: 'string',
        ssh_keyPassPhrase: 'string',
        windowsSPUsername: 'nullable',
        windowsSPPassword: 'nullable',
        VCDUsername: 'required|string',
        VCDPassword: 'required|string',
        assets: 'nullable',
        'assets.*.assetId': 'integer',
        'assets.*.vmId': 'alphaDash',
        isActive: 'required|in:enabled,disabled,true'
      }, params);
    } catch (error) {
      logger.error('Error occurred while attempting to create remote access detail', { error, loggerLabel, action, user });
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const orgId = params.organization_id;
    const userToken = req.authInfo;
    const loggedInUserId = req.user.id;
    params.linuxSPUsername = params.VCDUsername;
    params.windowsSPUsername = params.VCDUsername;
    params.linuxSPPassword = params.VCDPassword;
    params.windowsSPPassword = params.VCDPassword;
    const connName = params.connectionName;
    if (checkName(connName)) {
      const err = new Error('Invalid value for connection name');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    try {
      const exists = await remoteAccessDetailService.checkName(connName, orgId);
      if (exists) {
        logger.info({ connName }, 'Duplicate Remote Access Connection name.');
        const error = new Error('Duplicate Remote Access Connection name.');
        error.status = 400;
        return errorHandler(req, res, error);
      }
      const remoteAccessDetail = await remoteAccessDetailService.createVCD(orgId, params, loggedInUserId, userToken);
      if (remoteAccessDetail) {
        const result = await remoteAccessDetailService.getRemoteAccessDetail(remoteAccessDetail.id, orgId);
        return res.json(result);
      }
      return res.json(remoteAccessDetail);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async deleteRemoteAccessDetail(req, res) {
    const remoteAccessDetailId = req.params.remoteAccessDetailId;
    if (checkId(remoteAccessDetailId)) {
      logger.error('Error with Org Id');
      const error = new Error('Error with Org Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const update = await remoteAccessDetailService.deleteById(remoteAccessDetailId);
      logger.info({ update, remoteAccessDetailId }, 'Update');
      return res.json(update);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async deleteMultipleRemoteAccessDetail(req, res) {
    const remoteAccessDetail = req.query.id;
    const orgId = req.params.orgId;
    const userToken = req.authInfo;
    const loggedInUserId = req.user.id;
    const remoteAccessDetailIdArr = remoteAccessDetail.split(',');
    try {
      const update = await remoteAccessDetailService.deleteMultipleRemoteAccessDetail(remoteAccessDetailIdArr, orgId, loggedInUserId, userToken);
      return res.json(update);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async updateRemoteAccessDetail(req, res) {
    const params = req.body;
    const action = 'update';
    const user = get(req, 'user.username', '');
    try {
      params.isActive = toLower(get(params, 'isActive', 'enabled'));
      await Validator.validateParams({
        connectionName: 'required|string',
        salt: 'nullable',
        type: 'required|in:default,asset,service account',
        organization_id: 'required|integer',
        linuxSPUsername: 'nullable',
        linuxSPPassword: 'nullable',
        ssh_key: 'string',
        ssh_keyPassPhrase: 'string',
        sshParameters : 'object',
        windowsSPUsername: 'nullable',
        windowsSPPassword: 'nullable',
        assets: 'nullable',
        'assets.*.assetId': 'integer',
        'assets.*.vmId': 'alphaDash',
        isActive: 'required|in:enabled,disabled,true'
      }, params);
    } catch (error) {
      logger.error('Error occurred while validating parameters to update remote access detail', { error, loggerLabel, action, user });
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const remoteAccessDetailId = req.params.remoteAccessDetailId;
    const orgId = req.params.orgId;
    if (checkId(remoteAccessDetailId)) {
      logger.error('Error with RemoteAccessDetail Id');
      const error = new Error('Error with RemoteAccessDetail Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    const linux = params.linuxSPUsername;
    const windows = params.windowsSPUsername;
    const connName = params.connectionName;
    const userToken = req.authInfo;
    const loggedInUserId = req.user.id;
    if (linux && checkName(linux)) {
      const err = new Error('Invalid value for linux username');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    if (windows && checkName(windows)) {
      const err = new Error('Invalid value for windows username');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    if (checkName(connName)) {
      const err = new Error('Invalid value for connection name');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    try {
      const remoteAccessData = await remoteAccessDetailService.getRemoteAccessDetail(remoteAccessDetailId, -88, true);
      if (params.salt && remoteAccessData.dataValues.salt !== params.salt) {

        if (linux && (!params.linuxSPPassword || params.linuxSPPassword === '')) {
          const err = new Error('Linux Password is Mandatory if Passphrase is changed');
          err.status = 400;
          return errorHandler(req, res, err);
        }

        if (windows && (!params.windowsSPPassword || params.windowsSPPassword === '')) {
          const err = new Error('Windows Password is Mandatory if Passphrase is changed');
          err.status = 400;
          return errorHandler(req, res, err);
        }
      }

      const update = await remoteAccessDetailService.updateRemoteAccessDetail(remoteAccessDetailId, orgId, params, loggedInUserId, userToken);
      logger.debug(`Successfully updated remoteAccessDetail ${update.connectionName}(${update.id})`, { loggerLabel, action, user });
      if (update) {
        const result = await remoteAccessDetailService.getRemoteAccessDetail(remoteAccessDetailId);
        return res.json(result);
      }
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async updateVCDAccessDetail(req, res) {
    const params = req.body;
    const orgId = req.params.orgId;
    const userToken = req.authInfo;
    const loggedInUserId = req.user.id;
    const action = 'update';
    const user = get(req, 'user.username', '');
    try {
      params.isActive = toLower(get(params, 'isActive', 'enabled'));
      await Validator.validateParams({
        connectionName: 'required|string',
        remoteAccessDetailId: 'required|integer',
        isActive: 'required|in:enabled,disabled,true'
      }, params);
    } catch (error) {
      logger.error('Error occurred while validating parameters to update VCD access detail', { error, loggerLabel, action, user });
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const remoteAccessDetailId = req.params.remoteAccessDetailId;
    params.linuxSPUsername = params.VCDUsername;
    params.windowsSPUsername = params.VCDUsername;
    params.linuxSPPassword = params.VCDPassword;
    params.windowsSPPassword = params.VCDPassword;
    try {
      const update = await remoteAccessDetailService.updateVCDAccessDetail(remoteAccessDetailId, orgId, params, loggedInUserId, userToken);
      logger.debug(`Successfully updated VCD remoteAccessDetail ${update.connectionName}(${update.id})`, { loggerLabel, action, user });
      if (update) {
        const result = await remoteAccessDetailService.getRemoteAccessDetail(remoteAccessDetailId);
        logger.info({ update, remoteAccessDetailId }, 'Updated');
        return res.json(result);
      }
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }
};
