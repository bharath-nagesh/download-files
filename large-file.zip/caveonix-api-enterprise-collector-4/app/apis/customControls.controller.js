
const services = require('../services');
const customControlsService = services.customControlsService;
const errorHandler = require('./../../utils/errorHandler');
const logger = require('./../../utils/logger').logger.child({

  sub_name: 'IdentityService-customControls.controller',

});
const controller = {
  async uploadCustomControls(req, res) {
    const orgId = req.params.orgId;
    const fileType = req.query.type;
    const csvFile = req.file ? req.file.buffer.toString() : req.body.file;
    try {
      const controls = await customControlsService.uploadCustomControls(orgId, fileType, csvFile);
      return res.json(controls);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred')
      return errorHandler(req, res, error);
    }
  }
};
module.exports = controller;
