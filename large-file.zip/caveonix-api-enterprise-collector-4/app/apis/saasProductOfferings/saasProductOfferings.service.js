const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-saasProductOfferingsService.service'
});
const SaaSProducts = require('../auth/saasProducts.model');

module.exports = class ProductOfferingsService {
  constructor() {
    logger.debug('called ProductOfferingsService constructor');
  }

  getById(Id) {
    return SaaSProducts.findOne({ where: { id: Id, $and: [{ is_active: { $ne: 'disabled' } }, { is_active: { $ne: 'false' } }] } });
  }

  getAllSaasProductOfferings(limit, offset) {
    return SaaSProducts.findAll({
      where: { $and: [{ is_active: { $ne: 'disabled' } }, { is_active: { $ne: 'false' } }] },
      order: [['id', 'ASC']],
      limit: limit,
      offset: offset
    });
  }

  getAllSaasProductOfferingsCount() {
    return SaaSProducts.count({
      where: { $and: [{ is_active: { $ne: 'disabled' } }, { is_active: { $ne: 'false' } }] }
    });
  }

};
