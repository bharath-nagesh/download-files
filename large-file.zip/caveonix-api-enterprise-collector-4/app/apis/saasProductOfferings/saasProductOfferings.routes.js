const SaasProductOfferingsController = require('./saasProductOfferings.controller');

/**
 * @swagger
 * tags:
 *  - name: ProductOfferings
 *    description: Product Offerings endpoints
 */
module.exports = class SaasProductOfferingsRoutes {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.saasProductOfferingsController = new SaasProductOfferingsController();

      // initializing route
      if (type === 'Service Provider') {
        this.initServiceProvider();
      } else {
        this.initOrganization();
      }
    }
  }

  initOrganization() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/SaasProductOfferings:
     *   get:
     *     tags:
     *       - ProductOfferings
     *     summary: Gets a list of Product Offerings from a specified Organization
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of saas product offerings
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/`, this.saasProductOfferingsController.getAllSaasProductOfferings);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/SaasProductOfferings/{ProductOfferingsId}:
     *   get:
     *     tags:
     *       - ProductOfferings
     *     summary: Gets a productOfferings by it's id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: ProductOfferingsId
     *         description: The id of the specified Product Offering.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: productOfferings
     */
    this.router.get(`${this.path}/:SaasProductOfferingsId`, this.saasProductOfferingsController.getSaasProductOfferingsById);


  }

  initServiceProvider() {
    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/SaasProductOfferings:
     *   get:
     *     tags:
     *       - ProductOfferings
     *     summary: Gets a list of all product offerings from a specified organization
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: ProductOfferings
     */
    this.router.get(`${this.path}/`, this.saasProductOfferingsController.getAllSaasProductOfferings);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/SaasProductOfferings/{SaasProductOfferingsId}:
     *   get:
     *     tags:
     *       - SaasProductOfferings
     *     summary: Gets a SaasProduct Offering by it's id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: SaasProductOfferingsId
     *         description: The id of the specified Product Offering.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: SaaS Product Offering
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/:SaasProductOfferingsId`, this.saasProductOfferingsController.getSaasProductOfferingsById);


  }
};
