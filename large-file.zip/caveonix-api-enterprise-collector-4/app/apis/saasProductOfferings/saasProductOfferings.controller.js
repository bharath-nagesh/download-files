const checkId = require('../../../utils/checkId');
const errorHandler = require('../../../utils/errorHandler');
const paginate = require('../../middlewares/paginate.middleware');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-saasProductOfferings.controller'
});
const SaasProductOfferingsService = require('./saasProductOfferings.service');
const saasProductOfferingsService = new SaasProductOfferingsService();

module.exports = class ProductOfferingsController {
  async getAllSaasProductOfferings(req, res) {
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    try {
      const results = await saasProductOfferingsService.getAllSaasProductOfferings(limit, offset);
      const itemCount = await saasProductOfferingsService.getAllSaasProductOfferingsCount();
      const pageCount = Math.ceil(itemCount / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        saasProductOffering: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getSaasProductOfferingsById(req, res) {
    const SaasProductOfferingsId = req.params.SaasProductOfferingsId;
    if (checkId(SaasProductOfferingsId)) {
      logger.error({ SaasProductOfferingsId }, 'Error with SaasProductOfferingsId');
      const err = new Error('Error with SaasProductOfferingsId');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    try {
      const saasProductOffering = await saasProductOfferingsService.getById(SaasProductOfferingsId);
      return res.json(saasProductOffering);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

};
