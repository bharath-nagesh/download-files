const services = require('../services');
var paginate = require('../middlewares/paginate.middleware');
const checkId = require('./../../utils/checkId');
const privacyClassificationService = services.privacyClassificationService;
const errorHandler = require('./../../utils/errorHandler');
const logger = require('./../../utils/logger').logger.child({
  sub_name: 'IdentityService-privacyClassification.controller'
});
const Validator = require('../../../utils/validator');
const controller = {
  async getAllPrivacyClassification(req, res) {
    var limit = res.locals.paginate.limit;
    var offset = res.locals.paginate.offset;
    var pageNumber = res.locals.paginate.page;
    try {
      const results = await privacyClassificationService.getAllPrivacyClassifications(limit, offset);
      const itemCount = await privacyClassificationService.getAllPrivacyClassificationsCount();
      const pageCount = Math.ceil(itemCount / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        privacyClassifications: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      return errorHandler(req, res, error);
    }
  },
  async getPrivacyClassificationById(req, res) {
    const privacyClassificationId = req.params.privacyClassificationId;
    if (checkId(privacyClassificationId)) {
      logger.error({ privacyClassificationId }, 'Error with PrivacyClassification Id');
      const err = new Error('Error with PrivacyClassification Id');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    try {
      const privacyClassification = await privacyClassificationService.getPrivacyClassification(privacyClassificationId);
      return res.json(privacyClassification);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  },
  async createPrivacyClassification(req, res) {
    const params = req.body;
    try {
      params.isActive = params.isActive ? params.isActive.toString().toLowerCase() : 'enabled';
      await Validator.validateParams({
        isActive: 'required|in:enabled,disabled,true'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }

    try {
      const privacyClassification = await privacyClassificationService.createPrivacyClassification(params);
      return res.json(privacyClassification);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  },
  async updatePrivacyClassificationById(req, res) {
    const privacyClassificationId = req.params.privacyClassificationId;
    const params = req.body;
    try {
      params.isActive = params.isActive ? params.isActive.toString().toLowerCase() : null;
      await Validator.validateParams({
        isActive: 'required|in:enabled,disabled,true'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    try {
      const privacyClassification = await privacyClassificationService.updatePrivacyClassification(privacyClassificationId, params);
      return res.json(privacyClassification);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  },
  async deconstePrivacyClassification(req, res) {
    const privacyClassificationId = req.params.privacyClassificationId;
    if (checkId(privacyClassificationId)) {
      logger.error({ privacyClassificationId }, 'Error with PrivacyClassification Id');
      const err = new Error('Error with PrivacyClassification Id');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    try {
      const update = await privacyClassificationService.deconsteById(privacyClassificationId);
      logger.info({ update, privacyClassificationId }, 'update');
      return res.sendStatus(204);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }
};
module.exports = controller;
