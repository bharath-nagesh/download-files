const Sequelize = require('sequelize');
const connection = require('../../../config/db.conf').getConnection();

class OrgProductOffering extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      organization_id: { type: Sequelize.INTEGER, field: 'organization_id' },
      product_offering_id: { type: Sequelize.INTEGER, field: 'product_offering_id' }
    },
    { sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'org_product_offering',
      underscored: true
    });
  }
}

module.exports = OrgProductOffering;
