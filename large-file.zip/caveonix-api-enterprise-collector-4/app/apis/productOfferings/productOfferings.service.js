const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-productOfferingsService.service'
});
const Organization = require('../organization/organization.model');
const OrgProductOffering = require('./orgProductOffering.model');
const ProductOfferings = require('./product_offerings.model');

module.exports = class ProductOfferingsService {
  constructor() {
    logger.debug('called ProductOfferingsService constructor');
  }

  getById(Id) {
    return ProductOfferings.findOne({ where: { id: Id, $and: [{ is_active: { $ne: 'disabled' } }, { is_active: { $ne: 'false' } }] } });
  }

  getAllProductOfferings(limit, offset) {
    return ProductOfferings.findAll({
      where: { $and: [{ is_active: { $ne: 'disabled' } }, { is_active: { $ne: 'false' } }] },
      order: [['id', 'ASC']],
      limit: limit,
      offset: offset
    });
  }

  getAllProductOfferingsCount() {
    return ProductOfferings.count({
      where: { $and: [{ is_active: { $ne: 'disabled' } }, { is_active: { $ne: 'false' } }] }
    });
  }

  async getProductOfferingsByOrgId(orgId) {
    // todo look into this.  it doesn't seem to work
    let ctr = 0;
    const newArr = [];
    const org = await Organization.findByPk(orgId, { include: [{ all: true }] });
    if (org.type === 'Provider' || org.type === 'SaaSProvider') {
      return ProductOfferings.findAll({ where: { $and: [{ is_active: { $ne: 'disabled' } }, { is_active: { $ne: 'false' } }] } });
    } else {
      // todo look into organization_id spelling
      const result = await OrgProductOffering.findAll({ where: { organization_id: orgId } });
      result.filter(object => {
        newArr[ctr] = object.dataValues.product_offering_id;
        ctr++;
      });
      return ProductOfferings.findAll({ where: { id: { $in: newArr }, $and: [{ is_active: { $ne: 'disabled' } }, { is_active: { $ne: 'false' } }] } });
    }
  }
};
