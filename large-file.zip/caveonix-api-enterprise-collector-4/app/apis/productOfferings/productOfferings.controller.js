const checkId = require('../../../utils/checkId');
const errorHandler = require('../../../utils/errorHandler');
const paginate = require('../../middlewares/paginate.middleware');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-productOfferings.controller'
});
const ProductOfferingsService = require('./productOfferings.service');
const productOfferingsService = new ProductOfferingsService();

module.exports = class ProductOfferingsController {
  async getAllProductOfferings(req, res) {
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    try {
      const results = await productOfferingsService.getAllProductOfferings(limit, offset);
      const itemCount = await productOfferingsService.getAllProductOfferingsCount();
      const pageCount = Math.ceil(itemCount / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        poc: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getProductOfferingsById(req, res) {
    const ProductOfferingsId = req.params.ProductOfferingsId;
    if (checkId(ProductOfferingsId)) {
      logger.error({ ProductOfferingsId }, 'Error with ProductOfferingsId');
      const err = new Error('Error with ProductOfferingsId');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    try {
      const productOffering = await productOfferingsService.getById(ProductOfferingsId);
      return res.json(productOffering);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getProductOfferingsByOrgId(req, res) {
    const orgId = req.params.orgId;
    try {
      const result = await productOfferingsService.getProductOfferingsByOrgId(orgId);
      return res.json(result);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }
};
