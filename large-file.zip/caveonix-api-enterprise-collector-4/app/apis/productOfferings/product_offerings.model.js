const Sequelize = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();
/**
 * @swagger
 * components:
 *   schemas:
 *     ProductOfferings:
 *       type: object
 *       required:
 *         - name
 *         - email
 *         - isActive
 *       properties:
 *         name:
 *           type: string
 *         description:
 *           type: string
 *         isActive:
 *           type: string
 * @param sequelize
 */

class ProductOfferings extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      name: { type: Sequelize.STRING, field: 'name' },
      description: { type: Sequelize.STRING, field: 'description' },
      isActive: { type: Sequelize.STRING, field: 'is_active' },
      is_active: { type: Sequelize.STRING, field: 'is_active' }
    },
    { sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'product_offerings',
      underscored: true
    });
  }

  static associate(models) {
    ProductOfferings.belongsToMany(models.Organization, {
      through: models.OrgProductOffering,
      foreignKey: 'organization_id',
      otherKey: 'product_offering_id',
      timestamps: false
    });
  }
}
module.exports = ProductOfferings;
