const ProductOfferingsController = require('./productOfferings.controller');

/**
 * @swagger
 * tags:
 *  - name: ProductOfferings
 *    description: Product Offerings endpoints
 */
module.exports = class ProductOfferingsRoutes {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.productOfferingsController = new ProductOfferingsController();

      // initializing route
      if (type === 'Service Provider') {
        this.initServiceProvider();
      } else {
        this.initOrganization();
      }
    }
  }

  initOrganization() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/ProductOfferings:
     *   get:
     *     tags:
     *       - ProductOfferings
     *     summary: Gets a list of Product Offerings from a specified Organization
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of product offerings
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/`, this.productOfferingsController.getProductOfferingsByOrgId);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/ProductOfferings/{ProductOfferingsId}:
     *   get:
     *     tags:
     *       - ProductOfferings
     *     summary: Gets a productOfferings by it's id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: ProductOfferingsId
     *         description: The id of the specified Product Offering.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: productOfferings
     */
    this.router.get(`${this.path}/:ProductOfferingsId`, this.productOfferingsController.getProductOfferingsById);


  }

  initServiceProvider() {
    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/ProductOfferings:
     *   get:
     *     tags:
     *       - ProductOfferings
     *     summary: Gets a list of all product offerings from a specified organization
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: ProductOfferings
     */
    this.router.get(`${this.path}/`, this.productOfferingsController.getProductOfferingsByOrgId);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/ProductOfferings/{ProductOfferingsId}:
     *   get:
     *     tags:
     *       - ProductOfferings
     *     summary: Gets a Product Offering by it's id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: ProductOfferingsId
     *         description: The id of the specified Product Offering.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: Product Offering
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/:ProductOfferingsId`, this.productOfferingsController.getProductOfferingsById);


  }
};
