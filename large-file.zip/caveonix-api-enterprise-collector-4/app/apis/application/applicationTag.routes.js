const ApplicationController = require('./applicationTag.controller');

/**
 * @swagger
 * tags:
 *  - name: Application
 *    description: Application endpoints
 */
module.exports = class ApplicationRoutes {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.applicationController = new ApplicationController();

      this.initOrganization();
    }
  }

  initOrganization() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/application:
     *   get:
     *     tags:
     *       - Application
     *     summary: Gets a list of organization applications
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of applications
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/`, this.applicationController.getApplicationTagsByOrgId);
    this.router.get(`${this.path}/systems`, this.applicationController.getSystems);
    this.router.get(`${this.path}/systems/counts`, this.applicationController.getSystemCounts);
    this.router.get(`${this.path}/:appId/assets`, this.applicationController.getApplicationAssets);
    this.router.get(`${this.path}/dropDown`, this.applicationController.getApplicationTagsDropDownByOrgId);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/application/{applicationTagId}:
     *   get:
     *     tags:
     *       - Application
     *     summary: Gets a application by it's id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: applicationTagId
     *         description: The id of the specified application.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: application
     */
    this.router.get(`${this.path}/:applicationTagId`, this.applicationController.getApplicationTagById);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/application/{applicationTagId}:
     *   put:
     *     tags:
     *       - Application
     *     summary: Updates a application
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: applicationTagId
     *         description: The id of the specified application.
     *         in: path
     *         required: true
     *         type: string
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/Application'
     *     responses:
     *       200:
     *         description: application
     */
    this.router.put(`${this.path}/:applicationTagId`, this.applicationController.updateApplicationTag);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/application/{applicationTagId}:
     *   post:
     *     tags:
     *       - Application
     *     summary: Creates a application
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: applicationTagId
     *         description: The id of the specified application.
     *         in: path
     *         required: true
     *         type: string
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/Application'
     *     responses:
     *       200:
     *         description: application
     */
    this.router.post(`${this.path}/`, this.applicationController.createApplicationTag);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/application/{applicationTagId}:
     *   delete:
     *     tags:
     *       - Application
     *     summary: Deletes a application
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: applicationTagId
     *         description: The id of the specified application.
     *         in: path
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: application
     */
    this.router.delete(`${this.path}/`, this.applicationController.deleteMultipleApplicationTag);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/application/{applicationTagId}/certificate/{certificateId}/control/{controlId}:
     *   put:
     *     tags:
     *       - Application
     *     summary: Updates a application certificate's control member
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: applicationTagId
     *         description: The id of the specified application.
     *         in: path
     *         required: true
     *         type: string
     *       - name: certificateId
     *         description: The id of the specified certificate.
     *         in: path
     *         required: true
     *         type: string
     *       - name: controlId
     *         description: The id of the specified control.
     *         in: path
     *         required: true
     *         type: string
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/Application'
     *     responses:
     *       200:
     *         description: application
     */
    this.router.put(`${this.path}/:applicationTagId/certificate/:certificateId/control/:controlId`, this.applicationController.updateAppCertificateControlMember);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/application/{applicationTagId}/certificate/{certificateId}/control/{controlId}/getApplicationTagControlsAttachment:
     *   get:
     *     tags:
     *       - Application
     *     summary: Gets the specified application's control attachment
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: applicationTagId
     *         description: The id of the specified application.
     *         in: path
     *         required: true
     *         type: string
     *       - name: certificateId
     *         description: The id of the specified certificate.
     *         in: path
     *         required: true
     *         type: string
     *       - name: controlId
     *         description: The id of the specified control.
     *         in: path
     *         required: true
     *         type: string
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/Application'
     *     responses:
     *       200:
     *         description: application
     */
    this.router.get(`${this.path}/:applicationTagId/certificate/:certificateId/control/:controlId/getApplicationTagControlsAttachment`, this.applicationController.getApplicationTagControlsAttachment);

    this.router.get(`${this.path}/:applicationTagId/subApplications`, this.applicationController.getSubApplicationsByAppId);

    this.router.get(`${this.path}/:applicationName/assets`, this.applicationController.getAssetsByAppName);
  }

  initServiceProvider() {
    // router.post('/:serviceProviderId/application', ApplicationController.createApplicationTag);
    // router.get('/:serviceProviderId/application', ApplicationController.getApplicationTagsByOrgId);

  }
};
