const Sequelize = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();

/**
 * @swagger
 * components:
 *   schemas:
 *     Application:
 *       type: object
 *       required:
 *         - name
 *         - isActive
 *       properties:
 *         name:
 *           type: string
 *         description:
 *           type: string
 *         impactLevel:
 *           type: string
 *         managed:
 *           type: string
 *         security_tag_name:
 *           type: string
 *         cia_value:
 *           type: string
 *         isActive:
 *           type: string
 * @param sequelize
 */
class ApplicationAssessment extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
        id: {
          type: Sequelize.INTEGER,
          primaryKey: true,
          autoIncrement: true
        },

        controlId: { type: Sequelize.STRING, field: 'control_id' },
        assessmentControlId: { type: Sequelize.STRING, field: 'assessment_control_id' },
        groupId: { type: Sequelize.STRING, field: 'group_id' },
        interview: { type: Sequelize.STRING, field: 'interview' },
        examine: { type: Sequelize.STRING, field: 'examine' },
        status: { type: Sequelize.STRING, field: 'status' },
        test: { type: Sequelize.STRING, field: 'test' },
        notes: { type: Sequelize.STRING, field: 'notes' },
        workStatus: { type: Sequelize.STRING, field: 'work_status' },
        createdBy: { type: Sequelize.INTEGER, field: 'created_by', defaultValue: -1 },
        updatedBy: { type: Sequelize.INTEGER, field: 'updated_by', defaultValue: -1 },
      },
      {
        sequelize,
        timestamps: true,
        freezeTableName: true,
        tableName: 'application_assessments',
        underscored: true
      });
  }

  static associate(models) {
    ApplicationAssessment.belongsTo(models.ApplicationCertification, { foreignKey: 'application_certification_id' });
    ApplicationAssessment.belongsTo(models.RegulationControl, { foreignKey: 'control_id' });
    // ApplicationAssessment.belongsTo(models.User );

  }
}

module.exports = ApplicationAssessment;

