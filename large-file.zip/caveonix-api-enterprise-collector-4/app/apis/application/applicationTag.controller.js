const ApplicationTagService = require('./applicationTag.service');
const applicationTagService = new ApplicationTagService();
const checkId = require('../../../utils/checkId');
const errorHandler = require('../../../utils/errorHandler');
const Validator = require('../../../utils/validator');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-application.controller'
});
const paginate = require('../../middlewares/paginate.middleware');
const _ = require('lodash');

module.exports = class ApplicationController {
  async createApplicationTag(req, res) {
    const orgId = req.params.orgId;
    const params = req.body;
    try {
      await Validator.validateParams({
        name: 'required|string',
        policyGroup: 'nullable',
        certificates: 'nullable',
        business_owner_poc_id: 'nullable',
        infra_primary_poc_id: 'nullable',
        infra_secondary_poc_id: 'nullable',
        os_primary_poc_id: 'nullable',
        os_secondary_poc_id: 'nullable',
        db_primary_poc_id: 'nullable',
        db_secondary_poc_id: 'nullable',
        software_primary_poc_id: 'nullable',
        software_secondary_poc_id: 'nullable',
        impactLevel: 'required|integer',
        cia_value: 'required|string',
        managed: 'required|boolean',
        isActive: 'required|in:enabled,disabled,true'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const userId = req.user.id;
    const token = req.authInfo;
    const businessOwnerPocId = params.business_owner_poc_id;
    if (!businessOwnerPocId) {
      logger.info({ business_owner_poc_id: businessOwnerPocId }, 'Invalid value for Business Owner');
      const error = new Error('Invalid value for Business Owner');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const applicationTag = await applicationTagService.create(orgId, params, userId, token);
      if (applicationTag) {
        const result = await applicationTagService.getApplicationPolicySourceMembers(applicationTag.id, orgId);
        return res.json(result);
      }
      return res.json(applicationTag);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getApplicationTagById(req, res) {
    const applicationTagId = req.params.applicationTagId;
    const orgId = req.params.orgId;
    if (checkId(applicationTagId)) {
      logger.error({ applicationTagId }, 'Error with ApplicationTag Id');
      const error = new Error('Error with ApplicationTag Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const applicationTag = await applicationTagService.getApplicationTag(applicationTagId, orgId);
      if (!applicationTag) {
        return res.sendStatus(404);
      }
      return res.json(applicationTag);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getApplicationTagsDropDownByOrgId(req, res) {
    const orgId = req.params.orgId;
    try {
      const data = await applicationTagService.getApplicationByOrgDropdown(orgId);
      return res.json(data);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getApplicationTagsByOrgId(req, res) {
    const orgId = req.params.orgId;
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    const dropdown = req.query.dropdown || false;
    const filterOrgId = req.query.orgid || null;
    let list = req.query.list;

    if (!list) list = 'true';
    const listParam = list.toLowerCase();
    try {
      const results = await applicationTagService.getAllApplicationTag(orgId, limit, offset, listParam, dropdown, filterOrgId);
      const itemCount = await applicationTagService.getApplicationTagCount(orgId, listParam, filterOrgId);
      const pageCount = Math.ceil(itemCount[0].count / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount[0].count,
        page_number: pageNumber,
        applicationTags: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getApplicationAssets(req, res) {
    try {
      const { appId } = req.params;
      const results = await applicationTagService.getApplicationAssets(appId);
      return res.json(results);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getSystems(req, res) {
    const orgId = req.params.orgId;
    const appCertId = req.query.id;
    const userId = req.user.id;

    try {
      const results = await applicationTagService.getSystems(orgId, userId, appCertId);
      return res.json(results);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getSystemCounts(req, res) {
    const orgId = req.params.orgId;
    const userId = req.user.id;

    try {
      const results = await applicationTagService.getSystemCounts(orgId, userId);
      return res.json(results);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async updateApplicationTag(req, res) {
    const applicationTagId = req.params.applicationTagId;
    const orgId = req.params.orgId;
    const update = req.body;
    const params = req.body;
    try {
      await Validator.validateParams({
        name: 'required|string',
        policyGroup: 'nullable',
        certificates: 'nullable',
        business_owner_poc_id: 'nullable',
        infra_primary_poc_id: 'nullable',
        infra_secondary_poc_id: 'nullable',
        os_primary_poc_id: 'nullable',
        os_secondary_poc_id: 'nullable',
        db_primary_poc_id: 'nullable',
        db_secondary_poc_id: 'nullable',
        software_primary_poc_id: 'nullable',
        software_secondary_poc_id: 'nullable',
        impactLevel: 'required|integer',
        cia_value: 'required|string',
        managed: 'required|boolean',
        isActive: 'required|in:enabled,disabled'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const userId = req.user.id;
    const token = req.authInfo;
    update.userId = userId;
    update.token = token;
    try {
      const applicationTag = await applicationTagService.updateApplicationTagById(applicationTagId, update, orgId);
      if (applicationTag) {
        const result = await applicationTagService.getApplicationPolicySourceMembers(applicationTagId, orgId);
        return res.json(result);
      }
      return res.json(applicationTag);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async deleteMultipleApplicationTag(req, res) {
    const orgId = req.params.orgId;
    const applicationTagId = req.query.id || '';
    const userId = req.user.id;
    const token = req.authInfo;
    const applicationTagIdArr = applicationTagId.split(',');
    try {
      for (let d = 0; d < applicationTagIdArr.length; d++) {
        const applicationTagId = applicationTagIdArr[d];
        await applicationTagService.deleteApplicationTagById(userId, token, applicationTagId, orgId);
      }
      const result = await applicationTagService.getApplicationTags(applicationTagIdArr, orgId);
      return res.json(result);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getControls(req, res) {
    const orgId = req.params.orgId;
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    let controls = req.query.controls;
    const applicationId = req.query.applicationId;
    let itemCount;
    if (!controls) controls = 'nist';
    controls = controls.toLowerCase();
    try {
      const results = await applicationTagService.getControls(orgId, applicationId, limit, offset, controls);
      if(controls === 'custom') itemCount = results.length;
      else itemCount = await applicationTagService.getControlsCount(orgId, controls);
      const pageCount = Math.ceil(itemCount / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        Controls: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async createAppCertificateControlMember(req, res) {
    const params = req.body;
    const applicationTagId = params.application_tag_id;
    const certificateId = params.certificate_id;
    params.orgId = req.params.orgId;
    try {
      await Validator.validateParams({
        application_tag_id: 'required|integer',
        certificate_id: 'required|integer',
        controls: 'nullable|array',
        'controls.*.control': 'nullable|string',
        'controls.*.sub_control': 'nullable|string',
        'controls.*.baseline': 'nullable|boolean',
        'controls.*.implementation_status': 'nullable',
        'controls.*.notes': 'nullable',
        'controls.*.attachment_name': 'nullable'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    try {
      await applicationTagService.createAppCertificateControlMember(applicationTagId, params);
      const applicationTag = await applicationTagService.getApplicationTagControls(applicationTagId, certificateId);
      return res.json(applicationTag);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async updateAppCertificateControlMember(req, res) {
    const params = req.body;
    const applicationTagId = req.params.applicationTagId;
    const certificateId = req.params.certificateId;
    const controlId = req.params.controlId;
    if (checkId(applicationTagId)) {
      logger.error({ applicationTagId }, 'Error with ApplicationTag Id');
      const error = new Error('Error with ApplicationTag Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    if (checkId(certificateId)) {
      logger.error({ certificateId }, 'Error with certificateId Id');
      const error = new Error('Error with certificateId Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      await applicationTagService.updateAppCertificateControlMember(applicationTagId, certificateId, controlId, params);
      const data = await applicationTagService.getAppCertificateControlMember(applicationTagId, certificateId, controlId);
      return res.json(data);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getApplicationTagControls(req, res) {
    let applicationTagId = req.params.applicationTagId;
    const certificateId = req.params.certificateId;
    const type = req.query.applications;
    if (type === 'all') {
      applicationTagId = type;
    }
    try {
      if (checkId(certificateId)) {
        logger.error({ certificateId }, 'Error with certificateId Id');
        const error = new Error('Error with certificateId Id');
        error.status = 400;
        return errorHandler(req, res, error);
      }

      const controls = await applicationTagService
        .getApplicationTagControls(applicationTagId, certificateId);
      const controlsDetails = [];
      controls.filter(function (object) {
        if (!object.attachment_name || controlsDetails.length === 0) {
          controlsDetails.push(object);
        } else {
          if (object.attachment_name) {
            let ctr = 0;
            controlsDetails.filter(function (a) {

              if (object.control_id === a.control_id) {
                ctr++;
              }
            });
            if (ctr === 0) {
              controlsDetails.push(object);
            }
          }
        }
      });
      let counter = 0;
      let attachmentArr = [];
      controlsDetails.filter(function (data) {
        controls.filter(function (object1) {
          if ((data.control_id === object1.control_id) && (object1.attachment_name != null)) {
            attachmentArr.push([{
              attachment_name: object1.attachment_name,
              attachment_type: object1.attachment_type,
              attachment: object1.attachment
            }]);
          }
        });
        data.attachmentDetails = _.set(attachmentArr);
        controlsDetails[counter] = data;
        attachmentArr = [];
        counter++;
      });
      return res.json(controlsDetails);

    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getApplicationTagControlsAttachment(req, res) {
    const applicationTagId = req.params.applicationTagId;
    const certificateId = req.params.certificateId;
    const controlId = req.params.controlId;
    try {
      const controls = await applicationTagService.getApplicationTagControlsAttachment(applicationTagId, certificateId, controlId);
      const attachmentArr = [];
      controls.filter((object) => {
        if (object.attachment_name) {
          attachmentArr.push([{
            attachment_name: object.attachment_name,
            attachment_type: object.attachment_type,
            attachment: object.attachment
          }]);
        }
      });
      return res.json({ attachmentDetails: attachmentArr });
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getCertificateApplicationTagDetails(req, res) {
    const certificateId = req.params.certificateId;
    const orgId = req.params.orgId;
    if (checkId(certificateId)) {
      logger.error({ certificateId }, 'Error with Certificate Id');
      const error = new Error('Error with Certificate Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const appTag = await applicationTagService.getCertificateApplicationTagDetails(certificateId, orgId);
      return res.json(appTag);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async ChangeApplicationState(req, res) {
    const update = req.body;
    try {
      await Validator.validateParams({
        applicationId: 'required|integer'
      }, req.params, { applicationId: 'Error with application Id' });

      update.managed = update.managed.toString().toLowerCase();
      await Validator.validateParams({
        managed: 'required|in:true,false'
      }, update);

    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const applicationTagId = req.params.applicationId;

    try {
      const applicationTag = await applicationTagService.ChangeApplicationState(applicationTagId, update);
      return res.json(applicationTag);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getRegulationById(req, res) {
    const certificateId = req.params.certificateId;
    if (checkId(certificateId)) {
      logger.error({ certificateId }, 'Error with Certificate Id');
      const error = new Error('Error with Certificate Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const certificates = await applicationTagService.getRegulationById(certificateId);
      if (!certificates) return res.sendStatus(404);
      return res.json(certificates);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getSubApplicationsByAppId(req, res) {
    const { orgId, applicationTagId } = req.params;
    if (checkId(applicationTagId)) {
      const error = new Error('Bad application id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const data = await applicationTagService.getSubApplicationByAppId(orgId, applicationTagId);
      return res.json(data);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getAssetsByAppName(req, res) {
    const { orgId, applicationName } = req.params;
    if (!applicationName) {
      const error = new Error('Bad application name');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const data = await applicationTagService.getAssetsByAppName(orgId, applicationName);
      return res.json(data);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }
};
