const expect = require('chai').expect;
const proxyquire = require('proxyquire').noCallThru();
const httpMocks = require('node-mocks-http');

describe('ApplicationController', function () {
  beforeEach(() => {

  });

  describe('ApplicationController', () => {

    describe('createApplicationTag', () => {
      it('createApplicationTag', async () => {
        let applicationTagBody = {
          name: 'tagname',
          policyGroup: 'sub app',
          certificates: 'hippa',
          business_owner_poc_id: '10',
          infra_primary_poc_id: '1',
          infra_secondary_poc_id: '1',
          os_primary_poc_id: '1',
          os_secondary_poc_id: '1',
          db_primary_poc_id: '1',
          db_secondary_poc_id: '1',
          software_primary_poc_id: '1',
          software_secondary_poc_id: '1',
          impactLevel: '1',
          cia_value: '1',
          managed: 'true',
          isActive: 'enabled'
        };
        const orgId = 0;
        const applicationTagServiceStub = class ApplicationTagService {
          create() { return Promise.resolve(applicationTagBody); }
          getApplicationPolicySourceMembers() { return Promise.resolve(applicationTagBody); }
        };
        const ApplicationTagController = proxyquire('./application.controller', {
          './applicationTag.service': applicationTagServiceStub
        });

        const applicationTagController = new ApplicationTagController();
        const req = httpMocks.createRequest({ params: { orgId: orgId }, body: applicationTagBody, user: { id: 1 }, authInfo: 'authInfo' });
        const res = httpMocks.createResponse();
        const details = await applicationTagController.createApplicationTag(req, res);
        const applicationTag = details._getData();
        expect(JSON.parse(applicationTag)).to.deep.equal(applicationTagBody);
      });
    });

    describe('getApplicationTagById', () => {
      it('getApplicationTagById', async () => {
        const applicationTagId = 1;
        const orgId = 0;
        const applicationTagData = { data: '1' };
        const applicationTagServiceStub = class ApplicationTagService {
          getApplicationTag() { return Promise.resolve(applicationTagData); }
        };
        const ApplicationTagController = proxyquire('./application.controller', {
          './applicationTag.service': applicationTagServiceStub
        });

        const applicationTagController = new ApplicationTagController();
        const req = httpMocks.createRequest({ params: { applicationTagId, orgId } });
        const res = httpMocks.createResponse();
        const details = await applicationTagController.getApplicationTagById(req, res);
        const applicationTag = details._getData();
        expect(JSON.parse(applicationTag)).to.deep.equal(applicationTagData);
      });
    });

    describe('getApplicationTagsDropDownByOrgId', () => {
      it('getApplicationTagsDropDownByOrgId', async () => {
        const orgId = 0;
        const applicationTagData = [{ data: '1' }, { data: '2' }];
        const applicationTagServiceStub = class ApplicationTagService {
          getApplicationByOrgDropdown() { return Promise.resolve(applicationTagData); }
        };
        const ApplicationTagController = proxyquire('./application.controller', {
          './applicationTag.service': applicationTagServiceStub
        });

        const applicationTagController = new ApplicationTagController();
        const req = httpMocks.createRequest({ params: { orgId } });
        const res = httpMocks.createResponse();
        const details = await applicationTagController.getApplicationTagsDropDownByOrgId(req, res);
        const applicationTag = details._getData();
        expect(JSON.parse(applicationTag)).to.deep.equal(applicationTagData);
      });
    });

    describe('getApplicationTagsByOrgId', () => {
      it('getApplicationTagsByOrgId', async () => {
        const orgId = 10;
        const limit = 10;
        const offset = 0;
        const page = 1;

        const ApplicationTagResponse = {
          total_page_count: 1,
          pageLimit: limit,
          total_record_count: 10,
          page_number: page,
          applicationTags: 10,
          pages: [{
            number: 1,
            url: 'null?page=' + page
          }]
        }

        const ApplicationTagResponseCount = [{ count: 10 }];
        const applicationTagServiceStub = class ApplicationTagService {
          getAllApplicationTag() { return Promise.resolve(orgId, limit, offset); }

          getApplicationTagCount() { return Promise.resolve(ApplicationTagResponseCount); }
        };
        const ApplicationTagController = proxyquire('./application.controller', {
          './applicationTag.service': applicationTagServiceStub
        });

        const applicationTagController = new ApplicationTagController();
        const req = httpMocks.createRequest({ params: { orgId }, query: { page } });
        const res = httpMocks.createResponse({ locals: { paginate: { limit, offset, page } } });
        const details = await applicationTagController.getApplicationTagsByOrgId(req, res);
        const applicationTag = details._getData();
        expect(JSON.parse(applicationTag)).to.deep.equal(ApplicationTagResponse);
      });
    });

    describe('updateApplicationTag', () => {
      it('updateApplicationTag', async () => {
        let applicationTagBody = {
          name: 'tagname',
          policyGroup: 'sub app',
          certificates: 'hippa',
          business_owner_poc_id: '10',
          infra_primary_poc_id: '1',
          infra_secondary_poc_id: '1',
          os_primary_poc_id: '1',
          os_secondary_poc_id: '1',
          db_primary_poc_id: '1',
          db_secondary_poc_id: '1',
          software_primary_poc_id: '1',
          software_secondary_poc_id: '1',
          impactLevel: '1',
          cia_value: '1',
          managed: 'true',
          isActive: 'enabled'
        };
        const orgId = 0;
        const applicationTagId = 1;
        const applicationTagServiceStub = class ApplicationTagService {
          updateApplicationTagById() { return Promise.resolve(applicationTagBody); }

          getApplicationPolicySourceMembers() { return Promise.resolve(applicationTagBody); }
        };
        const ApplicationTagController = proxyquire('./application.controller', {
          './applicationTag.service': applicationTagServiceStub
        });

        const applicationTagController = new ApplicationTagController();
        const req = httpMocks.createRequest({ params: { orgId, applicationTagId }, body: applicationTagBody, user: { id: 1 }, authInfo: 'authInfo' });
        const res = httpMocks.createResponse();
        const details = await applicationTagController.updateApplicationTag(req, res);
        const applicationTag = details._getData();
        expect(JSON.parse(applicationTag)).to.deep.equal(applicationTagBody);
      });
    });


    describe('deleteMultipleApplicationTag', () => {
      it('deleteMultipleApplicationTag', async () => {
        let applicationTagBody = {
          name: 'tagname',
          policyGroup: 'sub app',
          certificates: 'hippa',
          business_owner_poc_id: '10',
          infra_primary_poc_id: '1',
          infra_secondary_poc_id: '1',
          os_primary_poc_id: '1',
          os_secondary_poc_id: '1',
          db_primary_poc_id: '1',
          db_secondary_poc_id: '1',
          software_primary_poc_id: '1',
          software_secondary_poc_id: '1',
          impactLevel: '1',
          cia_value: '1',
          managed: 'true',
          isActive: 'enabled'
        };
        const orgId = 0;
        const applicationTagId = 1;
        const applicationTagServiceStub = class ApplicationTagService {
          getApplicationTags() { return Promise.resolve(applicationTagBody); }

          deleteApplicationTagById() { return Promise.resolve(true); }
        };
        const ApplicationTagController = proxyquire('./application.controller', {
          './applicationTag.service': applicationTagServiceStub
        });

        const applicationTagController = new ApplicationTagController();
        const req = httpMocks.createRequest({ query: { id: '1,2,3' }, params: { orgId, applicationTagId }, user: { id: 1 }, authInfo: 'authInfo' });
        const res = httpMocks.createResponse();
        const details = await applicationTagController.deleteMultipleApplicationTag(req, res);
        const applicationTag = details._getData();
        expect(JSON.parse(applicationTag)).to.deep.equal(applicationTagBody);
      });
    });


    describe('getControls', () => {
      it('getControls', async () => {
        const orgId = 10;
        const limit = 10;
        const offset = 0;
        const page = 1;

        const ApplicationTagResponse = {
          total_page_count: 1,
          pageLimit: limit,
          total_record_count: 10,
          page_number: page,
          Controls: 10,
          pages: [{
            number: 1,
            url: 'null?page=' + page
          }]
        }

        const ApplicationTagResponseCount = 10;
        const applicationTagServiceStub = class ApplicationTagService {
          getControls() { return Promise.resolve(orgId, limit, offset); }

          getControlsCount() { return Promise.resolve(ApplicationTagResponseCount); }
        };
        const ApplicationTagController = proxyquire('./application.controller', {
          './applicationTag.service': applicationTagServiceStub
        });

        const applicationTagController = new ApplicationTagController();
        const req = httpMocks.createRequest({ params: { orgId }, query: { page } });
        const res = httpMocks.createResponse({ locals: { paginate: { limit, offset, page } } });
        const details = await applicationTagController.getControls(req, res);
        const applicationTag = details._getData();
        expect(JSON.parse(applicationTag)).to.deep.equal(ApplicationTagResponse);
      });
    });


    describe('createAppCertificateControlMember', () => {
      it('createAppCertificateControlMember', async () => {
        const applicationTagBody = {
          application_tag_id: 1,
          certificate_id: 1,
          controls: [{ control: '1', baseline: 1 }, { control: '1', baseline: 1 }]
        };
        const applicationTagServiceStub = class ApplicationTagService {
          createAppCertificateControlMember() { return Promise.resolve(true); }

          getApplicationTagControls() { return Promise.resolve(applicationTagBody); }
        };
        const ApplicationTagController = proxyquire('./application.controller', {
          './applicationTag.service': applicationTagServiceStub
        });

        const applicationTagController = new ApplicationTagController();
        const req = httpMocks.createRequest({ body: applicationTagBody });
        const res = httpMocks.createResponse();
        const details = await applicationTagController.createAppCertificateControlMember(req, res);
        const applicationTag = details._getData();
        expect(JSON.parse(applicationTag)).to.deep.equal(applicationTagBody);
      });
    });

    describe('updateAppCertificateControlMember', () => {
      it('updateAppCertificateControlMember', async () => {
        const applicationTagBody = {
          application_tag_id: 1,
          certificate_id: 1,
          controls: [{ control: '1', baseline: 1 }, { control: '1', baseline: 1 }]
        };
        const applicationTagServiceStub = class ApplicationTagService {
          updateAppCertificateControlMember() { return Promise.resolve(true); }

          getAppCertificateControlMember() { return Promise.resolve(applicationTagBody); }
        };
        const application_tag_id = 1;
        const certificate_id = 1;
        const control_id = 1;
        const ApplicationTagController = proxyquire('./application.controller', {
          './applicationTag.service': applicationTagServiceStub
        });

        const applicationTagController = new ApplicationTagController();
        const req = httpMocks.createRequest({ params: { applicationTagId: application_tag_id, certificateId: certificate_id, controlId: control_id }, body: applicationTagBody });
        const res = httpMocks.createResponse();
        const details = await applicationTagController.updateAppCertificateControlMember(req, res);
        const applicationTag = details._getData();
        expect(JSON.parse(applicationTag)).to.deep.equal(applicationTagBody);
      });
    });

    describe('getApplicationTagControls', () => {
      it('getApplicationTagControls', async () => {
        const applicationTagBody = [{
          application_tag_id: 1,
          certificate_id: 1,
          controls: [{ control: '1', baseline: 1 }, { control: '1', baseline: 1 }]
        },
        {
          application_tag_id: 2,
          certificate_id: 1,
          controls: [{ control: '1', baseline: 1 }, { control: '1', baseline: 1 }]
        }];
        const application_tag_id = 1;
        const certificate_id = 1;

        const applicationTagServiceStub = class ApplicationTagService {
          getApplicationTagControls(application_tag_id, certificate_id) { return Promise.resolve(applicationTagBody); }
        };

        const ApplicationTagController = proxyquire('./application.controller', {
          './applicationTag.service': applicationTagServiceStub
        });

        const applicationTagController = new ApplicationTagController();
        const req = httpMocks.createRequest({ params: { applicationTagId: application_tag_id, certificateId: certificate_id } });
        const res = httpMocks.createResponse();
        const details = await applicationTagController.getApplicationTagControls(req, res);
        const applicationTag = details._getData();
        expect(applicationTag).to.deep.equal(JSON.stringify(applicationTagBody));
      });
    });

    describe('getApplicationTagControlsAttachment', () => {
      xit('getApplicationTagControlsAttachment', async () => {
        const applicationTagBody = [{
          application_tag_id: 1,
          certificate_id: 1,
          controls: [{ control: '1', baseline: 1 }, { control: '1', baseline: 1 }]
        },
        {
          application_tag_id: 2,
          certificate_id: 1,
          attachment_name: 'test.jpg',
          attachment_type: 'image/jpg',
          attachment: { type: 'buffer', buffer: '00X' },
          controls: [{ control: '1', baseline: 1 }, { control: '1', baseline: 1 }]
        }];

        const finalRes = {
          attachmentDetails: [{
            attachment_name: applicationTagBody[1].attachment_name,
            attachment_type: applicationTagBody[1].attachment_type,
            attachment: applicationTagBody[1].attachment
          }]
        };
        const application_tag_id = 1;
        const certificate_id = 1;
        const control_id = 1;
        const applicationTagServiceStub = class ApplicationTagService {
          getApplicationTagControlsAttachment(application_tag_id, certificate_id, control_id) {
            return {
              applicationTagBody,
              filter() {
                return applicationTagBody[1];
              }
            };
          }
        };

        const ApplicationTagController = proxyquire('./application.controller', {
          './applicationTag.service': applicationTagServiceStub
        });

        const applicationTagController = new ApplicationTagController();
        const req = httpMocks.createRequest({ params: { applicationTagId: application_tag_id, certificateId: certificate_id, controlId: control_id } });
        const res = httpMocks.createResponse();
        const details = await applicationTagController.getApplicationTagControlsAttachment(req, res);
        const applicationTag = details._getData();
        expect(applicationTag).to.deep.equal(JSON.stringify(finalRes));
      });
    });

    describe('getCertificateApplicationTagDetails', () => {
      it('getCertificateApplicationTagDetails', async () => {
        const applicationTagBody = [{
          application_tag_id: 1,
          certificate_id: 1,
          controls: [{ control: '1', baseline: 1 }, { control: '1', baseline: 1 }]
        },
        {
          application_tag_id: 2,
          certificate_id: 1,
          controls: [{ control: '1', baseline: 1 }, { control: '1', baseline: 1 }]
        }];
        const org_id = 1;
        const certificate_id = 1;

        const applicationTagServiceStub = class ApplicationTagService {
          getCertificateApplicationTagDetails(org_id, certificate_id) { return Promise.resolve(applicationTagBody); }
        };

        const ApplicationTagController = proxyquire('./application.controller', {
          './applicationTag.service': applicationTagServiceStub
        });

        const applicationTagController = new ApplicationTagController();
        const req = httpMocks.createRequest({ params: { orgId: org_id, certificateId: certificate_id } });
        const res = httpMocks.createResponse();
        const details = await applicationTagController.getCertificateApplicationTagDetails(req, res);
        const applicationTag = details._getData();
        expect(applicationTag).to.deep.equal(JSON.stringify(applicationTagBody));
      });
    });


    describe('ChangeApplicationState', () => {
      it('ChangeApplicationState', async () => {
        const applicationTagBody = {
          applicationId: 1,
          certificate_id: 1,
          managed: true,
          controls: [{ control: '1', baseline: 1 }, { control: '1', baseline: 1 }]
        };
        const org_id = 1;
        const certificate_id = 1;
        const application_tag_id = 1;
        const applicationTagServiceStub = class ApplicationTagService {
          ChangeApplicationState(org_id, certificate_id) { return applicationTagBody; }
        };

        const ApplicationTagController = proxyquire('./application.controller', {
          './applicationTag.service': applicationTagServiceStub
        });

        const applicationTagController = new ApplicationTagController();
        const req = httpMocks.createRequest({ params: { orgId: org_id, certificateId: certificate_id, applicationId: application_tag_id }, body: applicationTagBody });
        const res = httpMocks.createResponse();
        const details = await applicationTagController.ChangeApplicationState(req, res);
        const applicationTag = details._getData();
        expect(applicationTag).to.deep.equal(JSON.stringify(applicationTagBody));
      });
    });


    describe('getRegulationById', () => {
      it('getRegulationById', async () => {
        const certificatesBody = { id: 1, data: 'data' };
        const certificate_id = 1;
        const applicationTagServiceStub = class ApplicationTagService {
          getRegulationById(certificate_id) { return certificatesBody; }
        };

        const ApplicationTagController = proxyquire('./application.controller', {
          './applicationTag.service': applicationTagServiceStub
        });

        const applicationTagController = new ApplicationTagController();
        const req = httpMocks.createRequest({ params: { certificateId: certificate_id } });
        const res = httpMocks.createResponse();
        const details = await applicationTagController.getRegulationById(req, res);
        const applicationTag = details._getData();
        expect(applicationTag).to.deep.equal(JSON.stringify(certificatesBody));
      });
    });

    describe('getSubApplicationsByAppId', () => {
      it('getSubApplicationsByAppId', async () => {
        const subAppbody = { data: 1 };
        const applicationTagId = 1;
        const orgId = 1;
        const applicationTagServiceStub = class ApplicationTagService {
          getSubApplicationByAppId(orgId, applicationTagId) { return subAppbody; }
        };

        const ApplicationTagController = proxyquire('./application.controller', {
          './applicationTag.service': applicationTagServiceStub
        });

        const applicationTagController = new ApplicationTagController();
        const req = httpMocks.createRequest({ params: { applicationTagId: applicationTagId, orgId: orgId } });
        const res = httpMocks.createResponse();
        const details = await applicationTagController.getSubApplicationsByAppId(req, res);
        const applicationTag = details._getData();
        expect(applicationTag).to.deep.equal(JSON.stringify(subAppbody));
      });
    });


  });
});
