const Sequelize = require('sequelize');
const moment = require('moment');
const sequelize = require('../../../config/db.conf').getConnection();

/**
 * @swagger
 * components:
 *   schemas:
 *     Application:
 *       type: object
 *       required:
 *         - name
 *         - isActive
 *       properties:
 *         name:
 *           type: string
 *         description:
 *           type: string
 *         impactLevel:
 *           type: string
 *         managed:
 *           type: string
 *         security_tag_name:
 *           type: string
 *         cia_value:
 *           type: string
 *         isActive:
 *           type: string
 * @param sequelize
 */
class ApplicationAuthorize extends Sequelize.Model {
  set values(value) {
    this._values = value;
  }

  static init(sequelize) {
    return super.init({
        id: {
          type: Sequelize.INTEGER,
          primaryKey: true,
          autoIncrement: true
        },
        authorizerName: {
          type: Sequelize.STRING, field: 'authorizer_name'
        },
        status: { type: Sequelize.STRING, allowNull: false },
        atoDate: { type: Sequelize.DATE, field: 'ato_date', allowNull: false },
        createdBy: { type: Sequelize.STRING, field: 'created_by', defaultValue: '' },
        updatedBy: { type: Sequelize.STRING, field: 'updated_by', defaultValue: '' },
        comments: { type: Sequelize.STRING, field: 'comments' },
        expirationDate: { type: Sequelize.DATE, field: 'expiration_date', allowNull: false },
        remainingTime: {
          type: Sequelize.VIRTUAL(Sequelize.INTEGER, ['expirationDate']),
          get() {
            return moment(this.expirationDate, 'DD/MM/YYYY').diff(moment(),'days');
          }
        },
        type: { type: Sequelize.ENUM('Initial Authorization', 'Ongoing Authorization', 'Reauthorization') }
      },
      {
        sequelize,
        timestamps: true,
        freezeTableName: true,
        tableName: 'application_authorize',
        underscored: true
      });
  }

  static associate(models) {

    ApplicationAuthorize.belongsTo(models.Certificates, { foreignKey: 'certificate_id' });
    ApplicationAuthorize.belongsTo(models.ApplicationTag, { foreignKey: 'application_id' });
    ApplicationAuthorize.belongsTo(models.ApplicationCertification, { foreignKey: 'application_certification_id' });

  }
}

module.exports = ApplicationAuthorize;

