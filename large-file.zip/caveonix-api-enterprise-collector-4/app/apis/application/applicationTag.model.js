const Sequelize = require('sequelize');

/**
 * @swagger
 * components:
 *   schemas:
 *     Application:
 *       type: object
 *       required:
 *         - name
 *         - isActive
 *       properties:
 *         name:
 *           type: string
 *         description:
 *           type: string
 *         impactLevel:
 *           type: string
 *         managed:
 *           type: string
 *         security_tag_name:
 *           type: string
 *         cia_value:
 *           type: string
 *         isActive:
 *           type: string
 * @param sequelize
 */
class ApplicationTag extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
        name: {
          type: Sequelize.STRING(50),
          allowNull: false,
          validate: { len: { args: [0, 50], msg: 'value too long for name of application' } }
        },
        description: { type: Sequelize.STRING },
        impactLevel: { type: Sequelize.STRING, field: 'impact_level' },
        isActive: { type: Sequelize.STRING, field: 'is_active', defaultValue: true },
        is_active: { type: Sequelize.STRING, field: 'is_active' },
        security_tag_name: { type: Sequelize.STRING, field: 'security_tag_name' },
        cia_value: { type: Sequelize.STRING, field: 'cia_value' },
        ciaValue: { type: Sequelize.STRING, field: 'cia_value' },
        managed: { type: Sequelize.STRING, field: 'managed' },
      },
      {
        sequelize,
        timestamps: true,
        freezeTableName: true,
        tableName: 'application_tags',
        underscored: true
      });
  }

  static associate(models) {
    ApplicationTag.belongsTo(models.Organization, { foreignKey: 'organization_id' });
    ApplicationTag.hasMany(models.PolicySourceMembers, { foreignKey: 'sourceId' });
    //TODO get rid of this and change all throughout the code where broken
    ApplicationTag.hasMany(models.AppCertificateMembers, { foreignKey: 'application_tag_id' });
    ApplicationTag.hasMany(models.AppCertificateControlMembers, { foreignKey: 'application_id' });
    ApplicationTag.belongsToMany(models.Certificates, {
      through: 'application_tag_certificate_members',
      foreignKey: 'application_tag_id',
      otherKey: 'certificate_id',
      timestamps: false
    });
    ApplicationTag.hasMany(models.ApplicationPocMember, { foreignKey: 'application_id' });
    ApplicationTag.hasMany(models.Task, { foreignKey: 'application_id' });
    ApplicationTag.hasMany(models.ApplicationAuthorize, { foreignKey: 'application_id' });

    ApplicationTag.belongsToMany(models.Asset, {
      through: 'asset_application_tags_members',
      foreignKey: 'application_tags_id',
      otherKey: 'asset_id',
      timestamps: true
    });
    ApplicationTag.belongsToMany(models.PolicyGroup, {
      through: 'sub_application_members',
      foreignKey: 'source_id',
      otherKey: 'policy_group_id',
      timestamps: false
    });
    // ApplicationTag.hasOne(models.ApplicationPocMember);
    ApplicationTag.belongsToMany(models.Poc, {
      through: models.ApplicationPocMember,
      as: 'businessOwner',
      otherKey: 'business_owner_poc_id',
      foreignKey: 'application_id'
    });
    ApplicationTag.belongsToMany(models.Poc, {
      through: models.ApplicationPocMember,
      as: 'infraPrimary',
      otherKey: 'infra_primary_poc_id',
      foreignKey: 'application_id'
    });
    ApplicationTag.belongsToMany(models.Poc, {
      through: models.ApplicationPocMember,
      as: 'infraSecondary',
      otherKey: 'infra_secondary_poc_id',
      foreignKey: 'application_id'
    });
    ApplicationTag.belongsToMany(models.Poc, {
      through: models.ApplicationPocMember,
      as: 'osPrimary',
      otherKey: 'os_primary_poc_id',
      foreignKey: 'application_id'
    });
    ApplicationTag.belongsToMany(models.Poc, {
      through: models.ApplicationPocMember,
      as: 'osSecondary',
      otherKey: 'os_secondary_poc_id',
      foreignKey: 'application_id'
    });
    ApplicationTag.belongsToMany(models.Poc, {
      through: models.ApplicationPocMember,
      as: 'dbPrimary',
      otherKey: 'db_primary_poc_id',
      foreignKey: 'application_id'
    });
    ApplicationTag.belongsToMany(models.Poc, {
      through: models.ApplicationPocMember,
      as: 'dbSecondary',
      otherKey: 'db_secondary_poc_id',
      foreignKey: 'application_id'
    });
    ApplicationTag.belongsToMany(models.Poc, {
      through: models.ApplicationPocMember,
      as: 'softwarePrimary',
      otherKey: 'software_primary_poc_id',
      foreignKey: 'application_id'
    });
    ApplicationTag.belongsToMany(models.Poc, {
      through: models.ApplicationPocMember,
      as: 'softwareSecondary',
      otherKey: 'software_secondary_poc_id',
      foreignKey: 'application_id'
    });
  }
}

module.exports = ApplicationTag;
