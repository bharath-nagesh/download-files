const expect = require('chai').expect;
const proxyquire = require('proxyquire').noCallThru();

describe('Application Tag Service', function () {
  beforeEach(() => {

  });

  describe('getApplicationTag', () => {
    it('getApplicationTag', async () => {
      const applicationTagId = 1;
      const orgId = 1;

      const response = {
        data: 1
      };

      class applicationTagDeatilsStub {
        constructor() { }

        static findOne() {
          return Promise.resolve(response);
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        './applicationTag.model': applicationTagDeatilsStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.getApplicationTag(applicationTagId, orgId);
      expect(data).to.be.equal(response);
    });
  });

  describe('getApplicationTags', () => {
    it('getApplicationTags', async () => {
      const applicationTagId = 1;
      const orgId = 1;

      const response = [{
        data: 1
      },
      {
        data: 12
      }];

      class applicationTagDeatilsStub {
        constructor() { }

        static findAll() {
          return Promise.resolve(response);
        }
      };

      class orgStub {
        constructor() { }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        './applicationTag.model': applicationTagDeatilsStub,
        '../organization/organization.model':orgStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.getApplicationTags(applicationTagId, orgId);
      expect(data).to.be.equal(response);
    });
  });

  describe('getApplicationTagsForOrg', () => {
    it('getApplicationTagsForOrg', async () => {
      const orgId = 1;

      const response = [{
        data: 1
      },
      {
        data: 12
      }];

      class applicationTagDeatilsStub {
        constructor() { }

        static findAll() {
          return Promise.resolve(response);
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        './applicationTag.model': applicationTagDeatilsStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.getApplicationTagsForOrg(orgId);
      expect(data).to.be.equal(response);
    });
  });

  describe('getApplicationPolicySourceMembers', () => {
    it('getApplicationPolicySourceMembers', async () => {
      const applicationTagId = 1;

      const response = [{
        data: 1
      },
      {
        data: 12
      }];

      class applicationTagDeatilsStub {
        constructor() { }

        static findAll() {
          return Promise.resolve(response);
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        './applicationTag.model': applicationTagDeatilsStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.getApplicationPolicySourceMembers(applicationTagId);
      expect(data).to.be.equal(response);
    });
  });

  describe('getApplicationTagControlsAttachment', () => {
    it('getApplicationTagControlsAttachment', async () => {
      const applicationTagId = 1;
      const certificate_id = 1;
      const control_id = 1;
      const response = [{
        data: 1
      },
      {
        data: 12
      }];

      class appCertificateControlMemberDeatilsStub {
        constructor() { }

        static findAll() {
          return Promise.resolve(response);
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        '../../models/appCertificateControlMember.model': appCertificateControlMemberDeatilsStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.getApplicationTagControlsAttachment(applicationTagId, certificate_id, control_id);
      expect(data).to.be.equal(response);
    });
  });

  describe('create', () => {
    it('create', async () => {
      const orgId = 1;
      const userToken = 1;
      const userId = 1;
      const params = { policyGroup: '1,2,3', name: { replace() { return 'application^name'; } } };
      let itr = -1;
      const findOnedata = [false, params];
      class ApplicationTagDetailsStub {
        constructor() { }

        static findOne() {
          itr++;
          return findOnedata[itr];
        }

        static create() {
          params.id = 1;
          return params;
        }

        static findByPk(id) {
          return params;
        }
      };

      class ApplicationPocMemberStub {
        constructor() { }

        static create(params) {
          return params;
        }
      }

      class PolicySourceMembersStub {
        constructor() { }

        static create(params) {
          return params;
        }
      }

      class AppCertificateMembersStub {
        constructor() { }

        static destroy() {
          return true;
        }
      }

      class AppCertificateControlMembersStub {
        constructor() { }

        static destroy() {
          return true;
        }
      }

      const checkSpaceStub = {
        checkMultiSpace(name) {
          return name;
        }
      };

      const sequelizeStub = {
        getConnection() {
          return {
            Op: { eq: 'eq' },
            query() {
              return params;
            },
            where() {
              return 'where x=1';
            },
            col() {
              return 'small';
            },
            fn() {
              return 'small';
            }
          };
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        './applicationTag.model': ApplicationTagDetailsStub,
        '../../../utils/checkSpaces': checkSpaceStub,
        '../../../config/db.conf': sequelizeStub,
        '../../models/ApplicationPocMember.model': ApplicationPocMemberStub,
        '../../models/policySourceMember.model': PolicySourceMembersStub,
        '../../models/applicationCertificateMember.model': AppCertificateMembersStub,
        '../../models/appCertificateControlMember.model': AppCertificateControlMembersStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.create(orgId, params, userId, userToken);
      expect(data).to.be.equal(params);
    });
  });

  describe('checkPolicyGroupsMember', () => {
    it('checkPolicyGroupsMember', async () => {
      const policyGroupId = 1;
      const response = {
        data: 1
      };

      class PolicySourceMembersDeatilsStub {
        constructor() { }

        static findOne() {
          return Promise.resolve(response);
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        '../../models/policySourceMember.model': PolicySourceMembersDeatilsStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.checkPolicyGroupsMember(policyGroupId);
      expect(data).to.be.equal(response);
    });
  });

  describe('checkSourceMember', () => {
    it('checkSourceMember', async () => {
      const sourceId = 1;
      const response = {
        data: 1
      };

      class PolicySourceMembersDeatilsStub {
        constructor() { }

        static findOne() {
          return Promise.resolve(response);
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        '../../models/policySourceMember.model': PolicySourceMembersDeatilsStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.checkSourceMember(sourceId);
      expect(data).to.be.equal(response);
    });
  });

  describe('checkSourceMember', () => {
    it('checkSourceMember', async () => {
      const sourceId = 1;
      const response = {
        data: 1
      };

      class PolicySourceMembersDeatilsStub {
        constructor() { }

        static findOne() {
          return Promise.resolve(response);
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        '../../models/policySourceMember.model': PolicySourceMembersDeatilsStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.checkSourceMember(sourceId);
      expect(data).to.be.equal(response);
    });
  });

  describe('updateApplicationTagById', () => {
    it('updateApplicationTagById', async () => {
      const orgId = 1;
      const applicationTagId = 1;
      const params = {
        id: 1,
        policyGroup: '1,2,3',
        userToken: 1,
        userId: 1,
        name: { replace() { return 'application^name'; } }
      };

      let itr = -1;
      const findOnedata = [false, params];
      class ApplicationTagDetailsStub {
        constructor() { }

        static findOne() {
          itr++;
          return findOnedata[itr];
        }

        static create() {
          params.id = 1;
          return params;
        }

        static update() {
          return params;
        }

        static findByPk(id) {
          return { params, update() { return params; } };
        }
      };

      class ApplicationPocMemberStub {
        constructor() { }

        static create(params) {
          return params;
        }

        static update(params) {
          return params;
        }
      }

      class PolicySourceMembersStub {
        constructor() { }

        static create(params) {
          return params;
        }

        static destroy() {
          return true;
        }
      }

      class AppCertificateMembersStub {
        constructor() { }

        static destroy() {
          return true;
        }
      }

      class AppCertificateControlMembersStub {
        constructor() { }

        static destroy() {
          return true;
        }
      }

      class EnforcementServiceStub {
        constructor() { }

        createApplicationSecurityTag() {
          return true;
        }
      }


      const checkSpaceStub = {
        checkMultiSpace(name) {
          return name;
        }
      };

      const sequelizeStub = {
        getConnection() {
          return {
            Op: { eq: 'eq' },
            query() {
              return params;
            },
            where() {
              return 'where x=1';
            },
            col() {
              return 'small';
            },
            fn() {
              return 'small';
            }
          };
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        './applicationTag.model': ApplicationTagDetailsStub,
        '../../../utils/checkSpaces': checkSpaceStub,
        '../../../config/db.conf': sequelizeStub,
        '../../models/ApplicationPocMember.model': ApplicationPocMemberStub,
        '../../models/policySourceMember.model': PolicySourceMembersStub,
        '../../models/applicationCertificateMember.model': AppCertificateMembersStub,
        '../../models/appCertificateControlMember.model': AppCertificateControlMembersStub,
        '../enforcement/enforcement.service': EnforcementServiceStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.updateApplicationTagById(applicationTagId, params, orgId);
      expect(data).to.be.equal(params);
    });
  });

  describe('deleteApplicationTagById', () => {
    it('deleteApplicationTagById', async () => {
      const orgId = 2;
      const applicationTagId = 1;
      const userId = 1;
      const userToken = 1;
      const params = { id: 1, policyGroup: '1,2,3', userToken: 1, userId: 1, name: { replace() { return 'application^name'; } } };

      class ApplicationTagDetailsStub {
        constructor() { }

        static findOne() {
          return params;
        }

        static update() {
          return params;
        }

        static findByPk(id) {
          return params;
        }
      };

      class ApplicationPocMemberStub {
        constructor() { }

        static create(params) {
          return params;
        }

        static destroy(params) {
          return true;
        }
      }

      class PolicySourceMembersStub {
        constructor() { }

        static create(params) {
          return params;
        }

        static update(params) {
          return params;
        }

        static findAll() {
          return { params, map() { return [params]; } };
        }
      }

      class AppCertificateMembersStub {
        constructor() { }

        static destroy() {
          return true;
        }
      }

      class AppCertificateControlMembersStub {
        constructor() { }

        static destroy() {
          return true;
        }
      }

      const checkSpaceStub = {
        checkMultiSpace(name) {
          return name;
        }
      };
      const sequelizeStub = {
        getConnection() {
          return {
            Op: { eq: 'eq' },
            query() {
              return [{ count: 0 }];
            },
            where() {
              return 'where x=1';
            },
            col() {
              return 'small';
            },
            fn() {
              return 'small';
            },
            QueryTypes: {
              SELECT: 'SELECT'
            }
          };
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        './applicationTag.model': ApplicationTagDetailsStub,
        '../../../utils/checkSpaces': checkSpaceStub,
        '../../../config/db.conf': sequelizeStub,
        '../../models/ApplicationPocMember.model': ApplicationPocMemberStub,
        '../../models/policySourceMember.model': PolicySourceMembersStub,
        '../../models/applicationCertificateMember.model': AppCertificateMembersStub,
        '../../models/appCertificateControlMember.model': AppCertificateControlMembersStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.deleteApplicationTagById(userId, userToken, applicationTagId, orgId);
      console.log(data);
      expect(data).to.be.equal(params);
    });
  });

  describe('deleteById', () => {
    it('deleteById', async () => {
      const applicationTagId = 1;
      const response = {
        data: 1
      };

      class ApplicationTagDetailsStub {
        constructor() { }

        static update() {
          return Promise.resolve(response);
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        './applicationTag.model': ApplicationTagDetailsStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.deleteById(applicationTagId);
      expect(data).to.be.equal(response);
    });
  });

  describe('getApplicationByOrgDropdown', () => {
    it('getApplicationByOrgDropdown', async () => {
      const orgId = 1;
      const response = [{
        data: 1
      },
      {
        data: 12
      }];

      class ApplicationTagDetailsStub {
        constructor() { }

        static findAll() {
          return Promise.resolve(response);
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        './applicationTag.model': ApplicationTagDetailsStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.getApplicationByOrgDropdown(orgId);
      expect(data).to.be.equal(response);
    });
  });

  describe('getAllApplicationTag', () => {
    it('getAllApplicationTag', async () => {
      const orgId = 1;
      const limit = 10;
      const offset = 0;
      const response = [{
        data: 1
      },
      {
        data: 12
      }];
      const orgChain = [1, 2, 3];
      class ApplicationTagDetailsStub {
        constructor() { }

        static findAll() {
          return Promise.resolve(response);
        }
      };

      class OrganizationDetailsStub {
        constructor() { }

        static getOrgChain() {
          return Promise.resolve(orgChain);
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        './applicationTag.model': ApplicationTagDetailsStub,
        '../organization/organization.model': OrganizationDetailsStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.getAllApplicationTag(orgId, limit, offset);
      expect(data).to.be.equal(response);
    });
  });

  describe('getApplicationTagCount', () => {
    it('getApplicationTagCount', async () => {
      const orgId = 1;
      const response = [{
        data: 1
      },
      {
        data: 12
      }];
      const Onedata = {
        data: 1
      };
      const orgChain = [1, 2, 3];
      class ApplicationTagDetailsStub {
        constructor() { }

        static findAll() {
          return Promise.resolve(response);
        }

        static count() {
          return Promise.resolve(2);
        }
      };

      class OrganizationDetailsStub {
        constructor() { }

        static getOrgChain() {
          return Promise.resolve(orgChain);
        }

        static findOne() {
          return Promise.resolve(Onedata);
        }
      };

      const sequelizeStub = {
        getConnection() {
          return {
            Op: { eq: 'eq' },
            query() {
              return Promise.resolve(response);
            }
          };
        }
      };
      const ApplicationTagService = proxyquire('./applicationTag.service', {
        './applicationTag.model': ApplicationTagDetailsStub,
        '../organization/organization.model': OrganizationDetailsStub,
        '../../../config/db.conf': sequelizeStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.getApplicationTagCount(orgId);
      expect(data).to.be.equal(response);
    });
  });

  describe('checkName', () => {
    it('checkName', async () => {
      const orgId = 1;
      const name = 'test';
      const response = {
        data: 1
      };

      class ApplicationTagDetailsStub {
        constructor() { }

        static findOne() {
          return Promise.resolve(response);
        }
      };

      const sequelizeStub = {
        getConnection() {
          return {
            Op: { eq: 'eq' },
            query() {
              return Promise.resolve(response);
            },
            where() {
              return 'where x=1';
            },
            col() {
              return 'small';
            },
            fn() {
              return 'small';
            }
          };
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        './applicationTag.model': ApplicationTagDetailsStub,
        '../../../config/db.conf': sequelizeStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.checkName(name, orgId);
      expect(data).to.be.equal(response);
    });
  });

  describe('checkNameForUpdate', () => {
    it('checkNameForUpdate', async () => {
      const orgId = 1;
      const name = 'test';
      const applicationTagId = 1;
      const response = {
        data: 1
      };

      class ApplicationTagDetailsStub {
        constructor() { }

        static findOne() {
          return Promise.resolve(response);
        }
      };

      const sequelizeStub = {
        getConnection() {
          return {
            Op: { eq: 'eq' },
            query() {
              return Promise.resolve(response);
            },
            where() {
              return 'where x=1';
            },
            col() {
              return 'small';
            },
            fn() {
              return 'small';
            }
          };
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        './applicationTag.model': ApplicationTagDetailsStub,
        '../../../config/db.conf': sequelizeStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.checkNameForUpdate(name, applicationTagId, orgId);
      expect(data).to.be.equal(response);
    });
  });

  describe('getControls', () => {
    it('getControls', async () => {
      const applicationId = 1;
      const orgId = 1;
      const limit = 10;
      const offset = 0;
      const controls = 'nesa';

      let itr = -1;
      const AppTagFindOne = [
        { cia_value: 'HIGH' }
      ];
      const finalRes = [{ dataValues: { name: 'a' }, cia_value: 'LOW', baseline: { match() { return true; } } }];
      const sequelizeStub = {
        getConnection() {
          return {
            Op: { eq: 'eq' },
            query() {
              return [{ nesa_id: 1 }, { nesa_id: 2 }];
            },
            where() {
              return 'where x=1';
            },
            col() {
              return 'small';
            },
            fn() {
              return 'small';
            }
          };
        }
      };

      class applicationTagDeatilsStub {
        constructor() { }

        static findOne() {
          itr++;
          return AppTagFindOne[itr];
        }
      };

      class Controls_800_53Stub {
        constructor() { }

        static findAll() {
          return [{ cia_value: 'LOW', baseline: { match() { return true; } } }];
        }
      }

      class NesaControlsStub {
        constructor() { }

        static findAll() {
          return finalRes;
        }
      }

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        './applicationTag.model': applicationTagDeatilsStub,
        '../../models/controls_800_53.model': Controls_800_53Stub,
        '../../models/nesaControls.model': NesaControlsStub,
        '../../../config/db.conf': sequelizeStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.getControls(orgId, applicationId, limit, offset, controls);
      expect(JSON.stringify(data)).to.be.equal(JSON.stringify(finalRes));
    });
  });

  describe('getControlsCount', () => {
    it('getControlsCount', async () => {
      const orgId = 1;
      const controls = ['nesa','pci','hipaa','gdpr','iso','controls_800_53','ffiec','fedramplow','fedramphigh','fedrampmoderate','sama','kvkk'];
      const count = 10;
      let i;

      class NesaControlsStub {
        static count() {
          return count;
        }
      }

      class PciControlsStub {
        static count() {
          return count;
        }
      }

      class HipaaControlsStub {
        static count() {
          return count;
        }
      }

      class GdprControlsStub {
        static count() {
          return count;
        }
      }

      class IsoControlsStub {
        static count() {
          return count;
        }
      }

      class FfiecControlsStub {
        static count() {
          return count;
        }
      }

      class FedrampLowControlsStub {
        static count() {
          return count;
        }
      }

      class FedrampHighControlsStub {
        static count() {
          return count;
        }
      }

      class FedrampModerateControlsStub {
        static count() {
          return count;
        }
      }

      class SamaControlsStub {
        static count() {
          return count;
        }
      }

      class KvkkControlsStub {
        static count() {
          return count;
        }
      }

      class Controls_800_53Stub {
        static count() {
          return count;
        }
      }

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        '../../models/nesaControls.model': NesaControlsStub,
        '../../models/pciControls.model': PciControlsStub,
        '../../models/hipaaControls.model': HipaaControlsStub,
        '../../models/gdprControls.model': GdprControlsStub,
        '../../models/isoControls.model': IsoControlsStub,
        '../../models/ffiec_controls.model': FfiecControlsStub,
        '../../models/fedramp_low_controls.model': FedrampLowControlsStub,
        '../../models/fedramp_high_controls.model': FedrampHighControlsStub,
        '../../models/fedramp_moderate_controls.model': FedrampModerateControlsStub,
        '../../models/sama_controls.model': SamaControlsStub,
        '../../models/kvkk_controls.model': KvkkControlsStub,
        '../../models/controls_800_53.model':Controls_800_53Stub
      });
      for (i = 0; i < 12; i++) {
        const applicationTagService = new ApplicationTagService();
        const data = await applicationTagService.getControlsCount(orgId, controls[i]);
        expect(JSON.stringify(data)).to.be.equal(JSON.stringify(count));
      }
    });
  });

  describe('getApplicationTagControls', () => {
    it('getApplicationTagControls', async () => {
      const applicationTagId = 1;
      const certificateId = 1;
      const certificateData = [
        { certificate_id: 1, id: 1, name: 'iso' },
        { certificate_id: 2, id: 2, name: 'nesa' },
        { certificate_id: 3, id: 3, name: 'hipaa' },
        { certificate_id: 4, id: 4, name: 'pci' },
        { certificate_id: 5, id: 5, name: 'gdpr' },
        { certificate_id: 6, id: 6, name: 'nist' },
        { certificate_id: 7, id: 7, name: 'custom' },
        { certificate_id: 8, id: 8, name: 'ffiec' },
        { certificate_id: 9, id: 9, name: 'fedramp low' },
        { certificate_id: 10, id: 10, name: 'fedramp high' },
        { certificate_id: 11, id: 11, name: 'fedramp moderate' },
        { certificate_id: 12, id: 12, name: 'sama' },
        { certificate_id: 13, id: 13, name: 'kvkk' },
        { certificate_id: 14, id: 14, name: 'apra-cps' },
        { certificate_id: 15, id: 15, name: 'sgp-mtcs' },
        { certificate_id: 16, id: 16, name: 'irs' },
        { certificate_id: 17, id: 17, name: 'kor-isms' },
        { certificate_id: 18, id: 18, name: 'csa' },
        { certificate_id: 19, id: 19, name: 'csf' }
      ];
      let i = 0;
      let itr = -1;
      class certificatesStub {
        constructor() { }

        static findOne() {
          itr++;
          return certificateData[itr];
        }
      }

      let itr1 = -1;
      const sequelizeStub = {
        getConnection() {
          return {
            Op: { eq: 'eq' },
            query() {
              itr1++;
              return certificateData[itr1];
            },
            where() {
              return 'where x=1';
            },
            col() {
              return 'small';
            },
            fn() {
              return 'small';
            }
          };
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        '../certificates/certificates.model': certificatesStub,
        '../../../config/db.conf': sequelizeStub
      });
      for (i = 0; i < 19; i++) {
        const applicationTagService = new ApplicationTagService();
        const data = await applicationTagService.getApplicationTagControls(applicationTagId, certificateId);
        expect(data).to.be.equal(certificateData[i]);
      }
    });
  });

  describe('createApplicationCertificateMember', () => {
    it('createApplicationCertificateMember', async () => {
      const applicationTagId = 1;
      const certificateList = '1,2,3';
      const certificateData = { certificate_id: 1, id: 1, name: 'iso' };
      const certificateRes = [{ certificate_id: 1, id: 1, name: 'iso' }, { certificate_id: 1, id: 1, name: 'iso' }, { certificate_id: 1, id: 1, name: 'iso' }];
      class AppCertificateMembersStub {
        constructor() { }

        static create() {
          return certificateData;
        }

        static destroy() {
          return true;
        }

        static findAll() {
          return { certificateData, map() { return certificateData; } };
        }
      }

      const sequelizeStub = {
        getConnection() {
          return {
            Op: { eq: 'eq' },
            query() {
              return certificateData;
            },
            where() {
              return 'where x=1';
            },
            col() {
              return 'small';
            },
            fn() {
              return 'small';
            }
          };
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        '../../models/applicationCertificateMember.model': AppCertificateMembersStub,
        '../../../config/db.conf': sequelizeStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.createApplicationCertificateMember(applicationTagId, certificateList);
      expect(JSON.stringify(data)).to.be.equal(JSON.stringify(certificateRes));
    });
  });

  describe('createAppCertificateControlMember', () => {
    it('createAppCertificateControlMember', async () => {
      const applicationTagId = 1;
      const params = { certificate_id: 1, controls: [{ implementation_status: 1, notes: 'notes', attachment_name: 'file.img' }] };
      const resData = [{ data: 1 }, { data: 2 }];

      class CertificatesStub {
        static findOne() {
          return { name: 'iso', id: 1 };
        }
      }

      class AppCertificateControlMembersStub {
        static destroy() {
          return true;
        }

        static create() {
          return { data: 1 };
        }

        static findAll() {
          return resData;
        }
      }

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        '../../models/appCertificateControlMember.model': AppCertificateControlMembersStub,
        '../certificates/certificates.model': CertificatesStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.createAppCertificateControlMember(applicationTagId, params);
      expect(JSON.stringify(data)).to.be.equal(JSON.stringify(resData));
    });
  });

  describe('updateAppCertificateControlMember', () => {
    it('updateAppCertificateControlMember', async () => {
      const applicationId = 1;
      const certificateId = 1;
      const controlId = 1;
      const param = {};
      const response = {
        data: 1
      };

      class AppCertificateControlMembersStub {
        constructor() { }

        static update() {
          return response;
        }

        static findOne() {
          return response;
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        '../../models/appCertificateControlMember.model': AppCertificateControlMembersStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.updateAppCertificateControlMember(applicationId, certificateId, controlId, param);
      expect(data).to.be.equal(response);
    });
  });

  describe('getAppCertificateControlMember', () => {
    it('getAppCertificateControlMember', async () => {
      const applicationId = 1;
      const certificateId = 1;
      const controlId = 1;
      const response = {
        data: 1
      };

      class AppCertificateControlMembersStub {
        constructor() { }

        static findOne() {
          return response;
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        '../../models/appCertificateControlMember.model': AppCertificateControlMembersStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.getAppCertificateControlMember(applicationId, certificateId, controlId);
      expect(data).to.be.equal(response);
    });
  });

  describe('getCertificateApplicationTagDetails', () => {
    it('getCertificateApplicationTagDetails', async () => {
      const applicationId = 1;
      const certificateId = 1;
      const controlId = 1;
      const orgArr = [1, 2, 3];
      const response = [{
        data: 1
      }];

      class OrganizationDetailsStub {
        constructor() { }

        static getOrgChain() {
          return orgArr;
        }
      };

      class ApplicationTagDetailsStub {
        constructor() { }

        static findAll() {
          return response;
        }
      };

      class AppCertificateMembers {
        constructor() { }

        static findAll() {
          return response;
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        './applicationTag.model': ApplicationTagDetailsStub,
        '../organization/organization.model': OrganizationDetailsStub,
        '../../models/applicationCertificateMember.model': AppCertificateMembers
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.getCertificateApplicationTagDetails(applicationId, certificateId, controlId);
      expect(JSON.stringify(data)).to.be.equal(JSON.stringify(response));
    });
  });

  describe('getAllNistControls', () => {
    it('getAllNistControls', async () => {
      const applicationId = 1;
      const limit = 1;
      const offset = 0;
      const orgId = 1;
      const response = { cia_value: 'MODERATE' };
      const Controls_800_53Arr = [{ cia_value: 'MODERATE', baseline: { match() { return true; } }, dataValues: {} }];

      class Controls_800_53Stub {
        constructor() { }

        static findAll() {
          return Controls_800_53Arr;
        }
      }

      class ApplicationTagDetailsStub {
        constructor() { }

        static findOne() {
          return response;
        }
      };

      class AppCertificateMembers {
        constructor() { }

        static findAll() {
          return response;
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        './applicationTag.model': ApplicationTagDetailsStub,
        '../../models/controls_800_53.model': Controls_800_53Stub,
        '../../models/applicationCertificateMember.model': AppCertificateMembers
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.getAllNistControls(applicationId, orgId, limit, offset);
      expect(JSON.stringify(data)).to.be.equal(JSON.stringify(Controls_800_53Arr));
    });
  });

  describe('getAllPCIControls', () => {
    it('getAllPCIControls', async () => {
      const applicationId = 1;
      const limit = 1;
      const offset = 0;
      const orgId = 1;
      const response = { cia_value: 'MODERATE' };
      const Controls_800_53Arr = [{ cia_value: 'MODERATE', baseline: { match() { return true; } }, dataValues: {} }];
      const finalRes = [{ dataValues: { test_id: 1, Baseline_Control: 'false' } }];
      class Controls_800_53Stub {
        constructor() { }

        static findAll() {
          return Controls_800_53Arr;
        }
      }

      class ApplicationTagDetailsStub {
        constructor() { }

        static findOne() {
          return response;
        }
      };

      class AppCertificateMembers {
        constructor() { }

        static findAll() {
          return response;
        }
      };

      class PciControlsStub {
        constructor() { }

        static findAll() {
          return [{ dataValues: { test_id: 1 } }];
        }
      };

      const sequelizeStub = {
        getConnection() {
          return {
            Op: { eq: 'eq' },
            query() {
              return [];
            },
            where() {
              return 'where x=1';
            },
            col() {
              return 'small';
            },
            fn() {
              return 'small';
            }
          };
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        './applicationTag.model': ApplicationTagDetailsStub,
        '../../models/controls_800_53.model': Controls_800_53Stub,
        '../../models/applicationCertificateMember.model': AppCertificateMembers,
        '../../../config/db.conf': sequelizeStub,
        '../../models/pciControls.model': PciControlsStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.getAllPCIControls(applicationId, orgId, limit, offset);
      expect(JSON.stringify(data)).to.be.equal(JSON.stringify(finalRes));
    });
  });

  describe('getAllNesaControls', () => {
    it('getAllNesaControls', async () => {
      const applicationId = 1;
      const limit = 1;
      const offset = 0;
      const orgId = 1;
      const response = { cia_value: 'MODERATE' };
      const Controls_800_53Arr = [{ cia_value: 'MODERATE', baseline: { match() { return true; } }, dataValues: {} }];
      const finalRes = [{ dataValues: { name: 'test', test_id: 1, Baseline_Control: 'false' } }];
      class Controls_800_53Stub {
        constructor() { }

        static findAll() {
          return Controls_800_53Arr;
        }
      }

      class ApplicationTagDetailsStub {
        constructor() { }

        static findOne() {
          return response;
        }
      };

      class NesaControlsStub {
        constructor() { }

        static findAll() {
          return [{ dataValues: { name: 'test', test_id: 1 } }];
        }
      };

      const sequelizeStub = {
        getConnection() {
          return {
            Op: { eq: 'eq' },
            query() {
              return [];
            },
            where() {
              return 'where x=1';
            },
            col() {
              return 'small';
            },
            fn() {
              return 'small';
            }
          };
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        './applicationTag.model': ApplicationTagDetailsStub,
        '../../models/controls_800_53.model': Controls_800_53Stub,
        '../../../config/db.conf': sequelizeStub,
        '../../models/nesaControls.model': NesaControlsStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.getAllNesaControls(applicationId, orgId, limit, offset);
      expect(JSON.stringify(data)).to.be.equal(JSON.stringify(finalRes));
    });
  });

  describe('getAllHipaaControls', () => {
    it('getAllHipaaControls', async () => {
      const applicationId = 1;
      const limit = 1;
      const offset = 0;
      const orgId = 1;
      const response = { cia_value: 'MODERATE' };
      const Controls_800_53Arr = [{ cia_value: 'MODERATE', baseline: { match() { return true; } }, dataValues: {} }];
      const finalRes = [{ dataValues: { name: 'test', test_id: 1, Baseline_Control: 'false' } }];
      class Controls_800_53Stub {
        constructor() { }

        static findAll() {
          return Controls_800_53Arr;
        }
      }

      class ApplicationTagDetailsStub {
        constructor() { }

        static findOne() {
          return response;
        }
      };

      class HipaaControlsStub {
        constructor() { }

        static findAll() {
          return [{ dataValues: { name: 'test', test_id: 1 } }];
        }
      };

      const sequelizeStub = {
        getConnection() {
          return {
            Op: { eq: 'eq' },
            query() {
              return [];
            },
            where() {
              return 'where x=1';
            },
            col() {
              return 'small';
            },
            fn() {
              return 'small';
            }
          };
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        './applicationTag.model': ApplicationTagDetailsStub,
        '../../models/controls_800_53.model': Controls_800_53Stub,
        '../../../config/db.conf': sequelizeStub,
        '../../models/hipaaControls.model': HipaaControlsStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.getAllHipaaControls(applicationId, orgId, limit, offset);
      expect(JSON.stringify(data)).to.be.equal(JSON.stringify(finalRes));
    });
  });

  describe('getAllIsoControls', () => {
    it('getAllIsoControls', async () => {
      const applicationId = 1;
      const limit = 1;
      const offset = 0;
      const orgId = 1;
      const response = { cia_value: 'MODERATE' };
      const Controls_800_53Arr = [{ cia_value: 'MODERATE', baseline: { match() { return true; } }, dataValues: {} }];
      const finalRes = [{ dataValues: { name: 'test', test_id: 1, sub_control: '', Baseline_Control: 'false' } }];
      class Controls_800_53Stub {
        constructor() { }

        static findAll() {
          return Controls_800_53Arr;
        }
      }

      class ApplicationTagDetailsStub {
        constructor() { }

        static findOne() {
          return response;
        }
      };

      class IsoControlsStub {
        constructor() { }

        static findAll() {
          return [{ dataValues: { name: 'test', test_id: 1 } }];
        }
      };

      const sequelizeStub = {
        getConnection() {
          return {
            Op: { eq: 'eq' },
            query() {
              return [];
            },
            where() {
              return 'where x=1';
            },
            col() {
              return 'small';
            },
            fn() {
              return 'small';
            }
          };
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        './applicationTag.model': ApplicationTagDetailsStub,
        '../../models/controls_800_53.model': Controls_800_53Stub,
        '../../../config/db.conf': sequelizeStub,
        '../../models/isoControls.model': IsoControlsStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.getAllIsoControls(applicationId, orgId, limit, offset);
      expect(JSON.stringify(data)).to.be.equal(JSON.stringify(finalRes));
    });
  });

  describe('getAllCustomControls', () => {
    it('getAllCustomControls', async () => {
      const applicationId = 1;
      const limit = 1;
      const offset = 0;
      const orgId = 1;
      const response = { cia_value: 'MODERATE' };
      const Controls_800_53Arr = [{ cia_value: 'MODERATE', baseline: { match() { return true; } }, dataValues: {} }];
      const finalRes = [{ dataValues: { name: 'test', test_id: 1, Baseline_Control: 'false' } }];
      class Controls_800_53Stub {
        constructor() { }

        static findAll() {
          return Controls_800_53Arr;
        }
      }

      class ApplicationTagDetailsStub {
        constructor() { }

        static findOne() {
          return response;
        }
      };

      class CustomControlsStub {
        constructor() { }

        static findAll() {
          return [{ dataValues: { name: 'test', test_id: 1 } }];
        }
      };

      const sequelizeStub = {
        getConnection() {
          return {
            Op: { eq: 'eq' },
            query() {
              return [];
            },
            where() {
              return 'where x=1';
            },
            col() {
              return 'small';
            },
            fn() {
              return 'small';
            }
          };
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        './applicationTag.model': ApplicationTagDetailsStub,
        '../../models/controls_800_53.model': Controls_800_53Stub,
        '../../../config/db.conf': sequelizeStub,
        '../../models/customControls.model': CustomControlsStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.getAllCustomControls(applicationId, orgId, limit, offset);
      expect(JSON.stringify(data)).to.be.equal(JSON.stringify(finalRes));
    });
  });

  describe('getAllGDPRControls', () => {
    it('getAllGDPRControls', async () => {
      const applicationId = 1;
      const limit = 1;
      const offset = 0;
      const orgId = 1;
      const response = { cia_value: 'MODERATE' };
      const Controls_800_53Arr = [{ cia_value: 'MODERATE', baseline: { match() { return true; } }, dataValues: {} }];
      const finalRes = [{ dataValues: { name: 'test', test_id: 1, Baseline_Control: 'false' } }];
      class Controls_800_53Stub {
        constructor() { }

        static findAll() {
          return Controls_800_53Arr;
        }
      }

      class ApplicationTagDetailsStub {
        constructor() { }

        static findOne() {
          return response;
        }
      };

      class gdprControlsStub {
        constructor() { }

        static findAll() {
          return [{ dataValues: { name: 'test', test_id: 1 } }];
        }
      };

      const sequelizeStub = {
        getConnection() {
          return {
            Op: { eq: 'eq' },
            query() {
              return [];
            },
            where() {
              return 'where x=1';
            },
            col() {
              return 'small';
            },
            fn() {
              return 'small';
            }
          };
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        './applicationTag.model': ApplicationTagDetailsStub,
        '../../models/controls_800_53.model': Controls_800_53Stub,
        '../../../config/db.conf': sequelizeStub,
        '../../models/gdprControls.model': gdprControlsStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.getAllGDPRControls(applicationId, orgId, limit, offset);
      expect(JSON.stringify(data)).to.be.equal(JSON.stringify(finalRes));
    });
  });

  describe('getAllFFIECControls', () => {
    it('getAllFFIECControls', async () => {
      const applicationId = 1;
      const limit = 1;
      const offset = 0;
      const orgId = 1;
      const response = { cia_value: 'MODERATE' };
      const Controls_800_53Arr = [{ cia_value: 'MODERATE', baseline: { match() { return true; } }, dataValues: {} }];
      const finalRes = [{ dataValues: { name: 'test', test_id: 1, Baseline_Control: 'false' } }];
      class Controls_800_53Stub {
        constructor() { }

        static findAll() {
          return Controls_800_53Arr;
        }
      }

      class ApplicationTagDetailsStub {
        constructor() { }

        static findOne() {
          return response;
        }
      };

      class ffiec_controlsStub {
        constructor() { }

        static findAll() {
          return [{ dataValues: { name: 'test', test_id: 1 } }];
        }
      };

      const sequelizeStub = {
        getConnection() {
          return {
            Op: { eq: 'eq' },
            query() {
              return [];
            },
            where() {
              return 'where x=1';
            },
            col() {
              return 'small';
            },
            fn() {
              return 'small';
            }
          };
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        './applicationTag.model': ApplicationTagDetailsStub,
        '../../models/controls_800_53.model': Controls_800_53Stub,
        '../../../config/db.conf': sequelizeStub,
        '../../models/ffiec_controls.model': ffiec_controlsStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.getAllFFIECControls(applicationId, orgId, limit, offset);
      expect(JSON.stringify(data)).to.be.equal(JSON.stringify(finalRes));
    });
  });

  describe('getAllFedrampLowControls', () => {
    it('getAllFedrampLowControls', async () => {
      const applicationId = 1;
      const limit = 1;
      const offset = 0;
      const orgId = 1;
      const response = { cia_value: 'MODERATE' };
      const Controls_800_53Arr = [{ cia_value: 'MODERATE', baseline: { match() { return true; } }, dataValues: {} }];
      const finalRes = [{ dataValues: { name: 'test', test_id: 1, Baseline_Control: 'false' } }];
      class Controls_800_53Stub {
        constructor() { }

        static findAll() {
          return Controls_800_53Arr;
        }
      }

      class ApplicationTagDetailsStub {
        constructor() { }

        static findOne() {
          return response;
        }
      };

      class fedramp_low_controlsStub {
        constructor() { }

        static findAll() {
          return [{ dataValues: { name: 'test', test_id: 1 } }];
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        './applicationTag.model': ApplicationTagDetailsStub,
        '../../models/controls_800_53.model': Controls_800_53Stub,
        '../../models/fedramp_low_controls.model': fedramp_low_controlsStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.getAllFedrampLowControls(applicationId, orgId, limit, offset);
      expect(JSON.stringify(data)).to.be.equal(JSON.stringify(finalRes));
    });
  });

  describe('getAllFedrampModerateControls', () => {
    it('getAllFedrampModerateControls', async () => {
      const applicationId = 1;
      const limit = 1;
      const offset = 0;
      const orgId = 1;
      const response = { cia_value: 'MODERATE' };
      const Controls_800_53Arr = [{ cia_value: 'MODERATE', baseline: { match() { return true; } }, dataValues: {} }];
      const finalRes = [{ dataValues: { name: 'test', test_id: 1, Baseline_Control: 'true' } }];
      class Controls_800_53Stub {
        constructor() { }

        static findAll() {
          return Controls_800_53Arr;
        }
      }

      class ApplicationTagDetailsStub {
        constructor() { }

        static findOne() {
          return response;
        }
      };

      class fedramp_moderate_controlsStub {
        constructor() { }

        static findAll() {
          return [{ dataValues: { name: 'test', test_id: 1 } }];
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        './applicationTag.model': ApplicationTagDetailsStub,
        '../../models/controls_800_53.model': Controls_800_53Stub,
        '../../models/fedramp_moderate_controls.model': fedramp_moderate_controlsStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.getAllFedrampModerateControls(applicationId, orgId, limit, offset);
      expect(JSON.stringify(data)).to.be.equal(JSON.stringify(finalRes));
    });
  });

  describe('getAllSAMAControls', () => {
    it('getAllSAMAControls', async () => {
      const applicationId = 1;
      const limit = 1;
      const offset = 0;
      const orgId = 1;
      const response = { cia_value: 'MODERATE' };
      const Controls_800_53Arr = [{ cia_value: 'MODERATE', baseline: { match() { return true; } }, dataValues: {} }];
      const finalRes = [{ dataValues: { name: 'test', test_id: 1, Baseline_Control: 'false' } }];
      class Controls_800_53Stub {
        constructor() { }

        static findAll() {
          return Controls_800_53Arr;
        }
      }

      class ApplicationTagDetailsStub {
        constructor() { }

        static findOne() {
          return response;
        }
      };

      class sama_controlsStub {
        constructor() { }

        static findAll() {
          return [{ dataValues: { name: 'test', test_id: 1 } }];
        }
      };

      const sequelizeStub = {
        getConnection() {
          return {
            Op: { eq: 'eq' },
            query() {
              return [];
            },
            where() {
              return 'where x=1';
            },
            col() {
              return 'small';
            },
            fn() {
              return 'small';
            }
          };
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        './applicationTag.model': ApplicationTagDetailsStub,
        '../../models/controls_800_53.model': Controls_800_53Stub,
        '../../../config/db.conf': sequelizeStub,
        '../../models/sama_controls.model': sama_controlsStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.getAllSAMAControls(applicationId, orgId, limit, offset);
      expect(JSON.stringify(data)).to.be.equal(JSON.stringify(finalRes));
    });
  });

  describe('getAllKVKKControls', () => {
    it('getAllKVKKControls', async () => {
      const applicationId = 1;
      const limit = 1;
      const offset = 0;
      const orgId = 1;
      const response = { cia_value: 'MODERATE' };
      const Controls_800_53Arr = [{ cia_value: 'MODERATE', baseline: { match() { return true; } }, dataValues: {} }];
      const finalRes = [{ dataValues: { name: 'test', test_id: 1, Baseline_Control: 'false' } }];
      class Controls_800_53Stub {
        constructor() { }

        static findAll() {
          return Controls_800_53Arr;
        }
      }

      class ApplicationTagDetailsStub {
        constructor() { }

        static findOne() {
          return response;
        }
      };

      class KvkkControlsStub {
        constructor() { }

        static findAll() {
          return [{ dataValues: { name: 'test', test_id: 1 } }];
        }
      };

      const sequelizeStub = {
        getConnection() {
          return {
            Op: { eq: 'eq' },
            query() {
              return [];
            },
            where() {
              return 'where x=1';
            },
            col() {
              return 'small';
            },
            fn() {
              return 'small';
            }
          };
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        './applicationTag.model': ApplicationTagDetailsStub,
        '../../models/controls_800_53.model': Controls_800_53Stub,
        '../../../config/db.conf': sequelizeStub,
        '../../models/kvkk_controls.model': KvkkControlsStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.getAllKVKKControls(applicationId, orgId, limit, offset);
      expect(JSON.stringify(data)).to.be.equal(JSON.stringify(finalRes));
    });
  });

  describe('getKorIsmsControls', () => {
    it('getKorIsmsControls', async () => {
      const applicationId = 1;
      const limit = 1;
      const offset = 0;
      const orgId = 1;
      const response = { cia_value: 'MODERATE' };
      const Controls_800_53Arr = [{ cia_value: 'MODERATE', baseline: { match() { return true; } }, dataValues: {} }];
      const finalRes = [{ dataValues: { name: 'test', test_id: 1, Baseline_Control: 'true' } }];
      class Controls_800_53Stub {
        constructor() { }

        static findAll() {
          return Controls_800_53Arr;
        }
      }

      class ApplicationTagDetailsStub {
        constructor() { }

        static findOne() {
          return response;
        }
      };

      class KorIsmsControlsStub {
        constructor() { }

        static findAll() {
          return [{ dataValues: { name: 'test', test_id: 1 } }];
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        './applicationTag.model': ApplicationTagDetailsStub,
        '../../models/controls_800_53.model': Controls_800_53Stub,
        '../../models/korIsmsControls.model': KorIsmsControlsStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.getKorIsmsControls(applicationId, orgId, limit, offset);
      expect(JSON.stringify(data)).to.be.equal(JSON.stringify(finalRes));
    });
  });

  describe('getSgpMtcsControls', () => {
    it('getSgpMtcsControls', async () => {
      const applicationId = 1;
      const limit = 1;
      const offset = 0;
      const orgId = 1;
      const response = { cia_value: 'MODERATE' };
      const Controls_800_53Arr = [{ cia_value: 'MODERATE', baseline: { match() { return true; } }, dataValues: {} }];
      const finalRes = [{ dataValues: { name: 'test', test_id: 1, Baseline_Control: 'true' } }];
      class Controls_800_53Stub {
        constructor() { }

        static findAll() {
          return Controls_800_53Arr;
        }
      }

      class ApplicationTagDetailsStub {
        constructor() { }

        static findOne() {
          return response;
        }
      };

      class SgpMtcsControlsStub {
        constructor() { }

        static findAll() {
          return [{ dataValues: { name: 'test', test_id: 1 } }];
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        './applicationTag.model': ApplicationTagDetailsStub,
        '../../models/controls_800_53.model': Controls_800_53Stub,
        '../../models/sgpMtcsControls.model': SgpMtcsControlsStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.getSgpMtcsControls(applicationId, orgId, limit, offset);
      expect(JSON.stringify(data)).to.be.equal(JSON.stringify(finalRes));
    });
  });

  describe('getApraCpsControls', () => {
    it('getApraCpsControls', async () => {
      const applicationId = 1;
      const limit = 1;
      const offset = 0;
      const orgId = 1;
      const response = { cia_value: 'MODERATE' };
      const Controls_800_53Arr = [{ cia_value: 'MODERATE', baseline: { match() { return true; } }, dataValues: {} }];
      const finalRes = [{ dataValues: { name: 'test', test_id: 1, Baseline_Control: 'true' } }];
      class Controls_800_53Stub {
        constructor() { }

        static findAll() {
          return Controls_800_53Arr;
        }
      }

      class ApplicationTagDetailsStub {
        constructor() { }

        static findOne() {
          return response;
        }
      };

      class ApraCpsControlsStub {
        constructor() { }

        static findAll() {
          return [{ dataValues: { name: 'test', test_id: 1 } }];
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        './applicationTag.model': ApplicationTagDetailsStub,
        '../../models/controls_800_53.model': Controls_800_53Stub,
        '../../models/apraCpsControls.model': ApraCpsControlsStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.getApraCpsControls(applicationId, orgId, limit, offset);
      expect(JSON.stringify(data)).to.be.equal(JSON.stringify(finalRes));
    });
  });

  describe('ChangeApplicationState', () => {
    it('ChangeApplicationState', async () => {
      const applicationTagId = 1;
      const orgId = 1;
      const update = { manager: true };
      const response = {
        data: 1
      };

      class applicationTagDeatilsStub {
        constructor() { }

        static update() {
          return response;
        }

        static findOne() {
          return response;
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        './applicationTag.model': applicationTagDeatilsStub
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.ChangeApplicationState(applicationTagId, update);
      expect(data).to.be.equal(response);
    });
  });

  describe('getRegulationById', () => {
    it('getRegulationById', async () => {
      const applicationTagId = 1;
      const orgId = 1;
      const update = { manager: true };
      const response = {
        data: 1
      };

      class applicationTagDeatilsStub {
        constructor() { }

        static update() {
          return response;
        }

        static findOne() {
          return response;
        }
      };

      class CertificatesStub {
        constructor() { }

        static findOne() {
          return response;
        }
      };

      const sequelizeStub = {
        getConnection() {
          return {
            Op: { eq: 'eq' },
            query() {
              return response;
            },
            where() {
              return 'where x=1';
            },
            col() {
              return 'small';
            },
            fn() {
              return 'small';
            }
          };
        }
      };

      const lodash = {
        get() {
          return response;
        },
        toLower() {
          return 'name';
        }
      };
      const ApplicationTagService = proxyquire('./applicationTag.service', {
        './applicationTag.model': applicationTagDeatilsStub,
        '../../../config/db.conf': sequelizeStub,
        '../certificates/certificates.model': CertificatesStub,
        lodash: lodash
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.getRegulationById(applicationTagId, update);
      expect(data).to.be.equal(response);
    });
  });

  describe('getSubApplicationByAppId', () => {
    it('getSubApplicationByAppId', async () => {
      const appId = 1;
      const orgId = 1;
      const orgChain = [1, 2, 3];
      const response = [{
        data: 1
      }];

      class SubApplication {
        constructor() { }

        static findAll() {
          return response;
        }
      };

      class OrganizationDetailsStub {
        constructor() { }

        static getOrgChain() {
          return orgChain;
        }
      };

      const ApplicationTagService = proxyquire('./applicationTag.service', {
        '../organization/organization.model': OrganizationDetailsStub,
        '../subApplication/subApplication.model': SubApplication
      });
      const applicationTagService = new ApplicationTagService();
      const data = await applicationTagService.getSubApplicationByAppId(orgId, appId);
      expect(data).to.be.equal(response);
    });
  });



});
