const AppCertificateControlMembers = require('../certificates/applicationCertification/applicationAssignedControls/appCertificateControlMember.model');
const AppCertificateMembers = require('../certificates/applicationCertification/applicationAssignedControls/applicationCertificateMember.model');
const RegulationControl = require('../certificates/regulationControl.model');
const ApplicationPocMember = require('../../models/ApplicationPocMember.model');
const Asset = require('../asset/asset.model');
const ApraCpsControls = require('../../models/apraCpsControls.model');
const CsaControls = require('../../models/csaControls.model');
const CsfControls = require('../../models/csfControls.model');
const IrsControls = require('../../models/irsControls.model');
const BsiC5Controls = require('../../models/bsiC5Controls.model');
const Iso27017Controls = require('../../models/iso27017Controls.model');
const Iso27018Controls = require('../../models/iso27018Controls.model');
const Nist800171Controls = require('../../models/nist_800_171_Controls.model');
const ApplicationTag = require('./applicationTag.model');
const Certificates = require('../certificates/certificates.model');
const Controls_800_53 = require('../../models/controls_800_53.model');
const CustomControls = require('../../models/customControls.model');
const EnforcementService = require('../enforcement/enforcement.service');
const fedramp_moderate_controls = require('../../models/fedramp_moderate_controls.model');
const fedramp_high_controls = require('../../models/fedramp_high_controls.model');
const fedramp_low_controls = require('../../models/fedramp_low_controls.model');
const ffiec_controls = require('../../models/ffiec_controls.model');
const gdprControls = require('../../models/gdprControls.model');
const { uniq, get, toLower, countBy, size, filter, every, map, reduce, chain } = require('lodash');
const sama_controls = require('../../models/sama_controls.model');
const HipaaControls = require('../../models/hipaaControls.model');
const IsoControls = require('../../models/isoControls.model');
const KorIsmsControls = require('../../models/korIsmsControls.model');
const KvkkControls = require('../../models/kvkk_controls.model');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-application.service'
});
const NesaControls = require('../../models/nesaControls.model');
const Organization = require('../organization/organization.model');
const Poc = require('../poc/poc.model');
const Task = require('../tasks/tasks.model');
const ApplicationCertification = require('../certificates/applicationCertification/applicationCertification.model');
const ApplicationAuthorize = require('./applicationAuthorize.model');
const SubApplication = require('../subApplication/subApplication.model');
const PolicySourceMembers = require('../../models/policySourceMember.model');
const PciControls = require('../../models/pciControls.model');
const removeSpace = require('../../../utils/checkSpaces');
const uuid = require('uuid/v4');
const sequelize = require('../../../config/db.conf').getConnection();
const SgpMtcsControls = require('../../models/sgpMtcsControls.model');
const ReferenceService = require('../../services/reference.service');
const referenceService = new ReferenceService();
const complianceDefinitions = require('../../definitions/compliance');
referenceService.addEndpoints(null, null, complianceDefinitions, '');

const { QueryTypes } = require('sequelize');

module.exports = class ApplicationTagService {
  constructor() {
    logger.debug('called ApplicationTagService constructor');
  }

  async getApplicationTag(applicationTagId, orgId) {
    const orgChain = await Organization.getOrgChain(orgId);
    return ApplicationTag.findOne({
      where: { id: applicationTagId, organization_id: { $in: orgChain } },
      include: [
        { model: Organization },
        {
          model: PolicySourceMembers,
          include: [{ model: SubApplication }]
        },
        {
          model: AppCertificateMembers,
          include: [{ model: Certificates }]
        },
        { model: ApplicationPocMember },
        {
          model: Poc,
          as: 'businessOwner'
        },
        { model: Poc, as: 'infraPrimary' },
        { model: Poc, as: 'infraSecondary' },
        { model: Poc, as: 'osPrimary' },
        {
          model: Poc,
          as: 'osSecondary'
        },
        { model: Poc, as: 'dbPrimary' },
        { model: Poc, as: 'dbSecondary' },
        { model: Poc, as: 'softwarePrimary' }, {
          model: Poc,
          as: 'softwareSecondary'
        }]
    });
  }

  getApplicationTags(applicationTagIdArr, orgId) {
    if (!Array.isArray(applicationTagIdArr)) applicationTagIdArr = [applicationTagIdArr];

    return ApplicationTag.findAll({
      where: { id: { $in: applicationTagIdArr }, organization_id: orgId },
      include: [
        { model: Organization },
        {
          model: PolicySourceMembers,
          include: [{ model: SubApplication }]
        },
        {
          model: AppCertificateMembers,
          include: [{ model: Certificates }]
        }]
    });
  }

  getApplicationTagsForOrg(orgId) {
    return ApplicationTag.findAll({
      where: { organization_id: orgId, $or: [{ isActive: { $ne: 'false' } }] },
      order: [['id', 'ASC']]
    });
  }

  getApplicationPolicySourceMembers(applicationTagId) {
    return ApplicationTag.findAll({
      where: { id: applicationTagId },
      include: [
        { model: Organization },
        {
          model: PolicySourceMembers,
          include: [{ model: SubApplication }]
        },
        {
          model: AppCertificateMembers,
          include: [{ model: Certificates }]
        },
        { model: ApplicationPocMember }]
    });
  }

  //TODO: compare to other function `create`
  getApplicationTagControlsAttachment(applicationTagId, certificate_id, control_id) {
    return AppCertificateControlMembers.findAll({
      where: {
        application_id: applicationTagId,
        certificate_id: certificate_id,
        control_id: control_id
      }
    });
  }

  async create(orgId, params) {
    params.organization_id = orgId;
    const policyGroup = params.policyGroup;
    let policyGroupsArray = [];
    if (policyGroup) {
      policyGroupsArray = policyGroup.split(',');
    }
    let applicationTag;
    const name = params.name;
    const newName = removeSpace.checkMultiSpace(name);
    const certificateList = params.certificates;
    const securityTag = `application^${name.replace(new RegExp(':', 'g'), '_').replace(new RegExp(' ', 'g'), '_')}^${uuid()}`;
    params.security_tag_name = securityTag;
    params.name = newName;
    if (!params.impactLevel) {
      params.impactLevel = 1;
    }
    try {

      const exists = await this.checkName(newName, orgId);
      if (exists && exists.isActive !== 'false') {
        const err = new Error('Duplicate Application name.');
        err.status = 400;
        throw err;
      } else if (exists && exists.isActive === 'false') {
        params.id = exists.id;
        applicationTag = await exists.update(params);
        params.id = null; // removing id to avoid insert conflict in upcoming insert queries below
      } else {
        applicationTag = await ApplicationTag.create(params);
      }
      params.application_id = applicationTag.id;
      await ApplicationPocMember.create(params);
      if (policyGroup && policyGroup.charAt(0) !== '') {
        const sourceId = applicationTag.id;
        params.sourceId = sourceId;

        for (let i = 0; i < policyGroupsArray.length; i++) {
          params.policyGroupId = policyGroupsArray[i];
          params.sourceType = 'Application';
          await PolicySourceMembers.create(params);
        }
      }
      await this.createApplicationCertificateMember(applicationTag.id, certificateList);
      return ApplicationTag.findByPk(applicationTag.id);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred creating app tag');
      error.status = 400;
      throw error;
    }
  }

  async checkPolicyGroupsMember(policyGroupId) {
    return PolicySourceMembers.findOne({ where: { policyGroupId: policyGroupId } });
  }

  async checkSourceMember(sourceId) {
    return PolicySourceMembers.findOne({ where: { source_id: sourceId } });
  }

  async updateApplicationTagById(applicationTagId, params, orgId) {
    const name = params.name;
    const newName = removeSpace.checkMultiSpace(name);
    const policyGroups = params.policyGroup;
    const certificateList = params.certificates;
    const userId = params.userId;
    const userToken = params.token;
    const exists = await this.checkNameForUpdate(newName, applicationTagId, orgId);
    if (exists) {
      const err = new Error('Duplicate Application Group name.');
      err.status = 400;
      throw err;
    }
    params.name = newName;
    try {
      const applicationTag = await ApplicationTag.findByPk(applicationTagId);
      await applicationTag.update(params);
      params.application_id = applicationTagId;

      delete params['id'];

      await ApplicationPocMember.update(params, { where: { application_id: applicationTagId } });
      if (policyGroups && policyGroups.charAt(0) !== '') {
        await this.createApplicationCertificateMember(applicationTagId, certificateList);
        const policyGroupsArray = policyGroups.split(',');
        const update = Object.assign({});
        update.sourceId = applicationTagId;
        update.sourceType = 'Application';
        await PolicySourceMembers.destroy({ where: { source_id: applicationTagId } });

        for (let i = 0; i < policyGroupsArray.length; i++) {
          update.policyGroupId = policyGroupsArray[i];
          update.sourceType = 'Application';
          await PolicySourceMembers.create(update);
        }
      } else {
        await this.createApplicationCertificateMember(applicationTagId, certificateList);
        await PolicySourceMembers.destroy({ where: { source_id: applicationTagId } });
      }
      const enforcementService = new EnforcementService();
      await enforcementService.createApplicationSecurityTag(userId, userToken, orgId, applicationTagId, [applicationTag.security_tag_name]);
      return this.getApplicationTag(applicationTagId, applicationTag.organization_id);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred updating app tag');
      error.status = 400;
      throw error;
    }
  }

  async deleteApplicationTagById(userId, userToken, applicationTagId, orgId) {
    const assetsInAppCountArr = await sequelize.query('select count(id) from application_group_asset_view where application_grp_id = :applicationTagId', {
      replacements: { applicationTagId },
      type: sequelize.QueryTypes.SELECT
    });
    const assetsInAppCount = assetsInAppCountArr[0].count;
    if (assetsInAppCount > 0) {
      const e = new Error('Cannot delete application that has assets associated with it.');
      e.status = 400;
      throw e;
    }
    await ApplicationTag.update({ isActive: false }, { where: { id: applicationTagId } });
    await ApplicationPocMember.destroy({ where: { application_id: applicationTagId } });
    await AppCertificateMembers.destroy({ where: { application_tag_id: applicationTagId } });
    await AppCertificateControlMembers.destroy({ where: { application_id: applicationTagId } });
    const defaultApplication = await ApplicationTag.findOne({ where: { $and: [{ name: 'Application' }, { organization_id: orgId }] } });
    const allPolicyGroupsMember = await PolicySourceMembers.findAll({ where: { sourceId: applicationTagId } });
    await Promise.all(allPolicyGroupsMember.map(async (p) => {
      try {
        await PolicySourceMembers.update({ sourceId: defaultApplication.id }, {
          where: {
            sourceId: applicationTagId,
            policy_group_id: p.policyGroupId
          }
        });
      } catch (error) {
        await PolicySourceMembers.destroy({
          where: {
            sourceId: applicationTagId,
            policy_group_id: p.policyGroupId
          }
        });
      }
    }));
    return this.getApplicationTag(applicationTagId, orgId);
  }

  deleteById(applicationTagId) {
    return ApplicationTag.update(
      { isActive: false },
      {
        where: { id: applicationTagId }
      }
    );
  }

  async getApplicationByOrgDropdown(orgId) {
    // const orgChain = await Organization.getOrgChain(orgId);
    return ApplicationTag.findAll({
      where: { isActive: { $in: ['enabled', 'true'] }, managed: { $eq: 'true' } },
      attributes: ['name', 'id'],
      include: [{
        model: Organization,
        attributes: [],
        where: { id: orgId },
        required: true
      }]
    });
  }

  async getAllApplicationTag(orgId, limit, offset, listParam = null, dropdown = null, filterOrgId = null) {

    const orgChain = await Organization.getOrgChain(orgId);
    if (filterOrgId && !orgChain.includes(parseInt(filterOrgId))) {
      const err = new Error('Unauthorized');
      err.status = 401;
      throw err;
    }
    const orgIds = filterOrgId || orgChain;
    let attributes = { exclude: [] };
    let isActive = ['enabled', 'true', 'disabled'];
    let managed = { $or: { $in: ['true', 'false'], $eq: null } };
    let include = [{ model: Organization, where: { id: orgIds }, required: true },
      { model: SubApplication, attributes: ['name', 'isActive'] }, {
        model: AppCertificateMembers,
        include: [{ model: Certificates }]
      }];
    if (dropdown && dropdown === 'true') {
      isActive = ['enabled', 'true'];
      managed = { $or: { $in: ['true'], $eq: null } };
      attributes = ['id', 'name', 'isActive'];
      include = [{
        model: Organization,
        where: { id: orgIds },
        required: true,
        attributes: ['id', 'name', 'aliasName', 'fullName']
      }];
    }
    let data = await ApplicationTag.findAll({
      where: { isActive, managed },
      order: [['id', 'ASC']],
      attributes,
      include,
      limit: limit,
      offset: offset
    });
    if (!dropdown || dropdown === 'false') {
      data = data.map(d => {
        if (!d.managed) d.managed = 'true';
        return d;
      });
    }
    return data;

  }

  async getApplicationAssets(appId) {
    const app = await ApplicationTag.findByPk(appId, {
      include: [{
        model: SubApplication,
        include: [{
          model: Asset,
          include: [
            { association: Asset.associations.AssetDetails, attributes: ['operatingSystem'] },
            { association: Asset.associations.AssetVMNetworks }
          ]
        }]
      }]
    });
    return chain(app.PolicyGroups)
      .map(subApp => subApp.Assets)
      .uniqBy(a => a.id)
      .flatten()
      .value();
  }

  async getSystemCounts(orgId) {
    const runQuery = function (selector) {
      return referenceService.runNamedQuery('applicationPassFailCount', selector, {
        orgId
      }, true);
    };

    const orgChain = await Organization.getOrgChain(orgId);
    const systems = await ApplicationCertification.findAll({
      include: [{
        model: ApplicationTag,
        where: { isActive: { $ne: 'false' } },
        include: [{ model: Organization, where: { id: orgChain }, attributes: [], required: true }
        ]
      }, { model: Certificates, attributes: ['name'] }]
    });
    const regulations = uniq(map(systems, (system) => system.Certificate.name.toLowerCase()));
    const data = await Promise.all(map(regulations, regulation => runQuery(regulation)));
    return reduce(data, (result, elem) => Object.assign({}, result, elem));
  }

  async getSystems(orgId, userId, appCertId = null) {
    const where = appCertId ? { id: appCertId } : {};
    // const orgChain = await Organization.getOrgChain(orgId);
    const systems = await ApplicationCertification.findAll({
      where,
      include: [
        {
          association: ApplicationCertification.associations.systemOwner,
          attributes: ['fullName', 'firstName', 'lastName', 'username', 'id']
        },
        { model: Task, attributes: ['id', 'severity'], where: { type: 'POA&M' }, required: false },
        {
          model: AppCertificateControlMembers,
          attributes: ['implementationStatus', 'complianceStatus'],
          where: { tailored: { $ne: 'minus' } },
          required: false,
        },
        {
          model: ApplicationTag,
          where: { isActive: { $ne: 'false' } },
          required: false,
        },
        { model: ApplicationAuthorize },
        {
          model: Certificates
        },
        { model: Organization, where: { id: orgId }, attributes: [], required: true }
        ]
    });

    return Promise.all(systems.map(async (system) => {
      const runQuery = function (selector) {
        if (!system.ApplicationTag) return {};
        return referenceService.runNamedQuery('assetPassFailCount', selector, {
          orgId,
          where: { application_grp_id: system.ApplicationTag.id.toString() }
        }, true);
      };
      const regulation = system.Certificate.name.toLowerCase();
      const regulationControlTotalCount = await RegulationControl.count({ where: { certificate_id: system.Certificate.id } });
      const data = await runQuery(regulation);

      const objCount = countBy(data, o => o.passed ? 'passedAssets' : 'failedAssets');

      system.setDataValue('assetCounts', objCount);
      const location = system.ApplicationTag ? await sequelize.query(`select distinct location from application_group_asset_view where application_grp_id = :applicationId`, {
        replacements: { applicationId: system.ApplicationTag.id },
        type: sequelize.QueryTypes.SELECT
      }) : [];
      const assignedToMe = size(filter(system.Tasks, t => t.assignee === userId), task => task.type || 'Miscellaneous') || 0;
      const poaAndmCount = countBy(system.Tasks, x => x.severity || 'N/A');
      const implementationStatusCount = countBy(system.AppCertificateControlMembers, x => x.implementationStatus || 'N/A');

      delete system.AppCertificateControlMembers;

      system.setDataValue('POA&MCount', poaAndmCount);
      system.setDataValue('ControlImplementationDetails', implementationStatusCount);
      system.setDataValue('totalControls', regulationControlTotalCount);
      if (system.ApplicationTag) {
        system.ApplicationTag.setDataValue('location', location.map(l => l.location));
      }
      system.setDataValue('assignedToMe', assignedToMe);
      if (!system.ApplicationTag) system.setDataValue('ApplicationTag', { name: 'Common Control Packages' });
      return system;
    }));
  }

  async getApplicationTagCount(orgId, listParam = null, filterOrgId = null) {
    const countArr = [];
    let sqlVar = '';
    const Op = sequelize.Op;
    if (listParam === 'false') {
      sqlVar = 'at.is_active !=' + '\'false\'' + ' and at.is_active !=' + '\'disabled\'' + '';
    } else {
      sqlVar = 'at.is_active !=' + '\'false\'';
    }

    const orgChain = await Organization.getOrgChain(orgId);
    const orgIds = filterOrgId || orgChain;
    const orgDetails = await Organization.findOne({ where: { id: orgId } });
    if (orgDetails.type === 'Provider') {
      if (listParam === 'false') {
        const ApplicationTagCount = await ApplicationTag.count({
          where: {
            organization_id: { $in: orgIds },
            $and: [{ isActive: { $ne: 'disabled' } }, { isActive: { $ne: 'false' } }],
            $or: [{ managed: { $ne: 'false' } }, { managed: { [Op.eq]: null } }]
          }
        });
        countArr.push({ count: ApplicationTagCount });
        return countArr;
      }
      return sequelize
        .query(
          `select count(app_id)
          from ((SELECT at.id as app_id, at.name, at.description,at.cia_value, at.impact_level, at.is_active,at.security_tag_name,at.created_at,at.updated_at,at.organization_id
            FROM application_tags at
          where  at.organization_id in (:orgIds) and (` + sqlVar + `)) app  LEFT OUTER JOIN 
          (select pg.id as policy_grp_id,pg.name as "Policy Name",psm.source_id from sub_applications pg,sub_application_members psm where pg.id = psm.policy_group_id and  
          pg.organization_id in (:orgIds)) subapp on app_id=subapp.source_id) ap
          LEFT OUTER JOIN 
          (select cer.id as "certificate_id",name,atcer.application_tag_id from certificates cer,application_tag_certificate_members atcer where cer.id=atcer.certificate_id) certificate on app_id=certificate.application_tag_id`,
          { replacements: { orgIds }, type: QueryTypes.SELECT }
        );
    }
    if (listParam === 'false') {
      const ApplicationTagCount = await ApplicationTag.count({
        where: {
          organization_id: { $in: orgIds },
          $and: [{ isActive: { $ne: 'disabled' } }, { isActive: { $ne: 'false' } }],
          $or: [{ managed: { $ne: 'false' } }, { managed: { [Op.eq]: null } }]
        }
      });
      countArr.push({ count: ApplicationTagCount });
      return countArr;
    }
    return sequelize
      .query(
        `select count(app_id)
          from ((SELECT at.id as app_id, at.name, at.description, at.impact_level,at.cia_value, at.is_active,at.security_tag_name,at.created_at,at.updated_at,at.organization_id
            FROM application_tags at
          where  at.organization_id in (:orgIds) and (` + sqlVar + `)) app  LEFT OUTER JOIN 
          (select pg.id as policy_grp_id,pg.name as "Policy Name",psm.source_id from sub_applications pg,sub_application_members psm where pg.id = psm.policy_group_id and  
          pg.organization_id in (:orgIds)) subapp on app_id=subapp.source_id) ap
          LEFT OUTER JOIN 
          (select cer.id as "certificate_id",name,atcer.application_tag_id from certificates cer,application_tag_certificate_members atcer where cer.id=atcer.certificate_id) certificate on app_id=certificate.application_tag_id`,
        { replacements: { orgIds }, type: QueryTypes.SELECT }
      );
  }

  checkName(name, orgId) {
    return ApplicationTag.findOne({
      where: {
        name: sequelize.where(sequelize.fn('LOWER', sequelize.col('name')), sequelize.fn('lower', name)),
        organization_id: { $eq: orgId }
      }
    });
  }

  checkNameForUpdate(name, applicationTagId, orgId) {
    return ApplicationTag.findOne({
      where: {
        name: sequelize.where(sequelize.fn('LOWER', sequelize.col('name')), sequelize.fn('lower', name)),
        $or: [{ isActive: { $ne: 'false' } }],
        id: { $ne: applicationTagId },
        organization_id: { $eq: orgId }
      }
    });
  }

  getControls(orgId, applicationId, limit, offset, controls = null) {
    if (controls === 'nesa') {
      return this.getAllNesaControls(applicationId, orgId, limit, offset);
    } else if (controls === 'pci') {
      return this.getAllPCIControls(applicationId, orgId, limit, offset);
    } else if (controls === 'hipaa') {
      return this.getAllHipaaControls(applicationId, orgId, limit, offset);
    } else if (controls === 'gdpr') {
      return this.getAllGDPRControls(applicationId, orgId, limit, offset);
    } else if (controls === 'iso') {
      return this.getAllIsoControls(applicationId, orgId, limit, offset);
    } else if (controls === 'nist' || controls === 'fisma (nist-800-53-r4)') {
      return this.getAllNistControls(applicationId, orgId, limit, offset);
    } else if (controls === 'custom') {
      return this.getAllCustomControls(applicationId, orgId, limit, offset);
    } else if (controls === 'ffiec') {
      return this.getAllFFIECControls(applicationId, orgId, limit, offset);
    } else if (controls === 'fedramp low') {
      return this.getAllFedrampLowControls(applicationId, orgId, limit, offset);
    } else if (controls === 'fedramp high') {
      return this.getAllFedrampHighControls(applicationId, orgId, limit, offset);
    } else if (controls === 'fedramp moderate') {
      return this.getAllFedrampModerateControls(applicationId, orgId, limit, offset);
    } else if (controls === 'sama') {
      return this.getAllSAMAControls(applicationId, orgId, limit, offset);
    } else if (controls === 'kvkk') {
      return this.getAllKVKKControls(applicationId, orgId, limit, offset);
    } else if (controls === 'kor-isms') {
      return this.getKorIsmsControls(applicationId, orgId, limit, offset);
    } else if (controls === 'sgp-mtcs') {
      return this.getSgpMtcsControls(applicationId, orgId, limit, offset);
    } else if (controls === 'apra-cps') {
      return this.getApraCpsControls(applicationId, orgId, limit, offset);
    } else if (controls === 'csa') {
      return this.getCsaControls(applicationId, orgId, limit, offset);
    } else if (controls === 'csf') {
      return this.getCsfControls(applicationId, orgId, limit, offset);
    } else if (controls === 'irs') {
      return this.getIrsControls(applicationId, orgId, limit, offset);
    } else if (controls === 'bsi-c5') {
      return this.getBsiC5Controls(applicationId, orgId, limit, offset);
    } else if (controls === 'iso-27017') {
      return this.getISO27017Controls(applicationId, orgId, limit, offset);
    } else if (controls === 'iso-27018') {
      return this.getISO27018Controls(applicationId, orgId, limit, offset);
    } else if (controls === 'nist-800-171') {
      return this.getNist800171Controls(applicationId, orgId, limit, offset);
    }
  }

  getControlsCount(orgId, controls = null) {
    if (controls === 'nesa') {
      return NesaControls.count({});
    } else if (controls === 'pci') {
      return PciControls.count({});
    } else if (controls === 'hipaa') {
      return HipaaControls.count({});
    } else if (controls === 'gdpr') {
      const GdprControls = require('../../models/gdprControls.model');
      return GdprControls.count({});
    } else if (controls === 'iso') {
      return IsoControls.count({});
    } else if (controls === 'nist' || controls === 'fisma (nist-800-53-r4)') {
      return Controls_800_53.count({});
    } else if (controls === 'ffiec') {
      const FfiecControls = require('../../models/ffiec_controls.model');
      return FfiecControls.count({});
    } else if (controls === 'fedramp low') {
      const FedrampLowControls = require('../../models/fedramp_low_controls.model');
      return FedrampLowControls.count({});
    } else if (controls === 'fedramp high') {
      const FedrampHighControls = require('../../models/fedramp_high_controls.model');
      return FedrampHighControls.count({});
    } else if (controls === 'fedramp moderate') {
      const FedrampModerateControls = require('../../models/fedramp_moderate_controls.model');
      return FedrampModerateControls.count({});
    } else if (controls === 'sama') {
      const SamaControls = require('../../models/sama_controls.model');
      return SamaControls.count({});
    } else if (controls === 'kvkk') {
      const KvkkControls = require('../../models/kvkk_controls.model');
      return KvkkControls.count({});
    } else if (controls === 'kor-isms') {
      return KorIsmsControls.count({});
    } else if (controls === 'sgp-mtcs') {
      return SgpMtcsControls.count({});
    } else if (controls === 'apra-cps') {
      return ApraCpsControls.count({});
    } else if (controls === 'csa') {
      return CsaControls.count({});
    } else if (controls === 'csf') {
      return CsfControls.count({});
    } else if (controls === 'irs') {
      return IrsControls.count({});
    } else if (controls === 'bsi-c5') {
      return BsiC5Controls.count({});
    } else if (controls === 'iso-27017') {
      return Iso27017Controls.count({});
    } else if (controls === 'iso-27018') {
      return Iso27018Controls.count({});
    } else if (controls === 'nist-800-171') {
      return Nist800171Controls.count({});
    }
  }

  async getApplicationTagControls(applicationTagId, certificateId) {
    const Certificate = await Certificates.findOne({ where: { id: certificateId } });
    if (!Certificate) {
      const error = new Error('certificate not found');
      error.status = 404;
      throw error;
    }

    let sqlVar = '';
    let controls = '';
    let alias = '';
    let name = '';
    const certificateName = toLower(get(Certificate, 'name'));
    if (certificateName === 'nesa') {
      controls = 'nesa_controls';
      name = '"nesaControl"';
      alias = '"nesaControl"' + '.' + 'name';
      sqlVar = '"nesaControl"."standards" AS "description", "nesaControl"."compliance" AS "compliance","nesaControl"."title" AS "title", "nesaControl"."family", "nesaControl"."control_type", "nesaControl"."control_ref"';
    } else if (certificateName === 'hipaa') {
      controls = 'hipaa_controls';
      name = '"hipaaControl"';
      alias = '"hipaaControl"' + '.' + 'control_type';
      sqlVar = '"hipaaControl"."guidance" AS "description","hipaaControl"."compliance" AS "compliance", "hipaaControl"."title" AS "title", "hipaaControl"."family", "hipaaControl"."control_type", "hipaaControl"."implementation" ';
    } else if (certificateName === 'pci') {
      controls = 'pci_controls';
      name = '"pciControl"';
      alias = '"pciControl"' + '.' + 'req_id';
      sqlVar = '"pciControl"."guidance" AS "description","pciControl"."compliance" AS "compliance", "pciControl"."requirements" AS "title", "pciControl"."family", "pciControl"."req_id", "pciControl"."testing"  ';
    } else if (certificateName === 'iso') {
      controls = 'iso_controls';
      name = '"isoControl"';
      alias = `"isoControl".sub_control`;
      sqlVar = '"isoControl"."control_desc" AS "description","isoControl"."compliance" AS "compliance", "isoControl"."title" AS "title", "isoControl"."family", "isoControl"."sub_control"  AS "control_id" ,trim("isoControl"."sub_control")as sub_control,"isoControl"."imp_guidance", "isoControl"."objective" ';
      return sequelize
        .query(
          `select distinct * from (SELECT "AppCertificateControlMembers"."id", "AppCertificateControlMembers"."application_id","AppCertificateControlMembers"."baseline" as "Baseline_Control", "AppCertificateControlMembers"."certificate_id", "AppCertificateControlMembers"."control_id" as Key, "AppCertificateControlMembers"."implementation_status", "AppCertificateControlMembers"."notes","AppCertificateControlMembers"."attachment_name", "AppCertificateControlMembers"."attachment_type", "AppCertificateControlMembers"."attachment", "AppCertificateControlMembers"."created_at", "AppCertificateControlMembers"."updated_at", "ApplicationTag"."id" AS "ApplicationTag_id", "ApplicationTag"."name" AS "ApplicationTagName", "ApplicationTag"."impact_level" AS "impactLevel", "Certificate"."id" AS "Certificate_id", "Certificate"."name" AS "Certificate_name", ${sqlVar}
         FROM "application_tag_controls_members" AS "AppCertificateControlMembers" LEFT OUTER JOIN "application_tags" AS "ApplicationTag" ON "AppCertificateControlMembers"."application_id" = "ApplicationTag"."id" LEFT OUTER JOIN "certificates" AS "Certificate" ON "AppCertificateControlMembers"."certificate_id" = "Certificate"."id" LEFT OUTER JOIN ${controls}  AS  ${name}  ON "AppCertificateControlMembers"."control_id" =  ${alias}  WHERE (("AppCertificateControlMembers"."application_id" = :applicationTagId AND "AppCertificateControlMembers"."certificate_id" = :certificateId))) as c;`,
          { replacements: { applicationTagId, certificateId }, type: QueryTypes.SELECT });
    } else if (certificateName === 'gdpr') {
      controls = 'gdpr_controls';
      name = '"gdprControl"';
      alias = '"gdprControl"' + '.' + 'artical_id';
      sqlVar = '"gdprControl"."description" AS "description","gdprControl"."compliance" AS "compliance", "gdprControl"."title" AS "title", "gdprControl"."chapter_title" AS "chapter_title", "gdprControl"."artical_id", "gdprControl"."artical", "gdprControl"."artical_title" ';
    } else if (certificateName === 'fisma (nist-800-53-r4)') {
      controls = 'controls_800_53';
      name = '"nistControl"';
      alias = '"nistControl"' + '.' + 'name';
      sqlVar = '"nistControl"."description" AS "description","nistControl"."compliance" AS "compliance", "nistControl"."title" AS "title",  "nistControl"."family_name", "nistControl"."baseline", "nistControl"."supplemental" ';
    } else if (certificateName === 'custom') {
      controls = 'custom_controls';
      name = '"customControl"';
      alias = '"customControl"' + '.' + 'name';
      sqlVar = '"customControl"."standards" AS "description","customControl"."compliance" AS "compliance", "customControl"."title" AS "title", "customControl"."family", "customControl"."control_ref", "customControl"."organization_id" ';
    } else if (certificateName === 'ffiec') {
      controls = 'ffiec_controls';
      name = '"ffiecControls"';
      alias = '"ffiecControls"' + '.' + 'control';
      sqlVar = '"ffiecControls"."control_desc" AS "description","ffiecControls"."compliance" AS "compliance", "ffiecControls"."family"  ';
    } else if (certificateName === 'fedramp low') {
      controls = 'fedramp_low_controls';
      name = '"fedrampLowControls"';
      alias = '"fedrampLowControls"' + '.' + 'control_id';
      sqlVar = '"fedrampLowControls"."control_desc" AS "description","fedrampLowControls"."compliance" AS "compliance", "fedrampLowControls"."family" , "fedrampLowControls"."control_name" ,"fedrampLowControls"."select_params","fedrampLowControls"."guidance" ';
    } else if (certificateName === 'fedramp high') {
      controls = 'fedramp_high_controls';
      name = '"fedrampHighControls"';
      alias = '"fedrampHighControls"' + '.' + 'control_id';
      sqlVar = '"fedrampHighControls"."control_desc" AS "description","fedrampHighControls"."compliance" AS "compliance", "fedrampHighControls"."family" , "fedrampHighControls"."control_name" ,"fedrampHighControls"."select_params","fedrampHighControls"."guidance" ';
    } else if (certificateName === 'fedramp moderate') {
      controls = 'fedramp_moderate_controls';
      name = '"fedrampModerateControls"';
      alias = '"fedrampModerateControls"' + '.' + 'control_id';
      sqlVar = '"fedrampModerateControls"."control_desc" AS "description","fedrampModerateControls"."compliance" AS "compliance", "fedrampModerateControls"."family" , "fedrampModerateControls"."control_name" ,"fedrampModerateControls"."select_params","fedrampModerateControls"."guidance" ';
    } else if (certificateName === 'sama') {
      controls = 'sama_controls';
      name = '"samaControl"';
      alias = `"samaControl".supplement_control_id`;
      sqlVar = '"samaControl"."id","samaControl"."control_id"  AS "control" ,"samaControl"."sub_control_id","samaControl"."domain","samaControl"."domain_desc","samaControl"."sub_domain","samaControl"."sub_domain_principal","samaControl"."sub_domain_objective" ,"samaControl"."supplement_control_id"  AS "control_id","samaControl"."compliance","samaControl"."control_desc" AS "description" ,"samaControl"."sub_domain"';
    } else if (certificateName === 'kvkk') {
      controls = 'kvkk_controls';
      name = '"kvkkControl"';
      alias = '"kvkkControl"' + '.' + 'control_id';
      sqlVar = '"kvkkControl"."id","kvkkControl"."control_id" ,"kvkkControl"."chapter","kvkkControl"."chapter_name","kvkkControl"."artical","kvkkControl"."artical_name","kvkkControl"."compliance","kvkkControl"."control_desc" AS "description"';
    } else if (certificateName === 'apra-cps') {
      controls = 'apra_cps_controls';
      name = '"apraControl"';
      alias = '"apraControl"' + '.' + 'control_id::text';
      sqlVar = '"apraControl"."id","apraControl"."control_id" ,"apraControl"."family_name","apraControl"."control_name","apraControl"."control_desc","apraControl"."compliance"';
    } else if (certificateName === 'sgp-mtcs') {
      controls = 'sgp_controls';
      name = '"sgpControl"';
      alias = '"sgpControl".control_id::text';
      sqlVar = '"sgpControl"."id","sgpControl"."family_id" ,"sgpControl"."family","sgpControl"."family_desc","sgpControl"."control_id","sgpControl"."control_name","sgpControl"."control_desc","sgpControl"."level1","sgpControl"."level2","sgpControl"."level3","sgpControl"."compliance","sgpControl"."control_desc" AS "description"';
    } else if (certificateName === 'irs') {
      controls = 'irs_controls';
      name = '"irsControl"';
      alias = '"irsControl".control_id::text';
      sqlVar = '"irsControl"."id","irsControl"."family_name","irsControl"."session_id","irsControl"."control_id" ,"irsControl"."control_name","irsControl"."mapping_id","irsControl"."control_desc","irsControl"."compliance","irsControl"."control_desc" AS "description"';
    } else if (certificateName === 'kor-isms') {
      controls = 'kor_isms_controls';
      name = '"korControl"';
      alias = '"korControl".control_id::text';
      sqlVar = '"korControl"."id","korControl"."domain","korControl"."domain_id","korControl"."control_id" ,"korControl"."family_id","korControl"."family","korControl"."control_name","korControl"."control_test","korControl"."control_desc","korControl"."compliance","korControl"."control_desc" AS "description"';
    } else if (certificateName === 'csf') {
      controls = 'csf_controls';
      name = '"csfControl"';
      alias = '"csfControl".sub_control_id::text';
      sqlVar = '"csfControl"."id","csfControl"."function","csfControl"."sub_control_id" as control_id,"csfControl"."control_name" ,"csfControl"."control_desc","csfControl"."sub_control_id","csfControl"."sub_control_desc","csfControl"."compliance","csfControl"."control_desc" AS "description"';
    } else if (certificateName === 'csa') {
      controls = 'csa_controls';
      name = '"csaControl"';
      alias = '"csaControl".control_id::text';
      sqlVar = '"csaControl"."id","csaControl"."domain_name","csaControl"."domain_id","csaControl"."control_id","csaControl"."control_desc","csaControl"."compliance","csaControl"."control_desc" AS "description"';
    } else if (certificateName === 'nist-800-171') {
      controls = 'nist_800_171_controls';
      name = '"nist800171Controls"';
      alias = '"nist800171Controls".control_id::text';
      sqlVar = '"nist800171Controls"."id","nist800171Controls"."family_id","nist800171Controls"."family_name","nist800171Controls"."control_id", "nist800171Controls"."control_name","nist800171Controls"."compliance","nist800171Controls"."control_guide","nist800171Controls"."mapping_id","nist800171Controls"."control_desc" AS "description"';
    } else if (certificateName === 'iso-27017') {
      controls = 'iso_27017_controls';
      name = '"iso27017Controls"';
      alias = '"iso27017Controls".control_id::text';
      sqlVar = '"iso27017Controls"."id","iso27017Controls"."clause_id","iso27017Controls"."clause_name","iso27017Controls"."category_id","iso27017Controls"."category_name","iso27017Controls"."category_desc","iso27017Controls"."clause_name","iso27017Controls"."control_id", "iso27017Controls"."control_name","iso27017Controls"."control_guide","iso27017Controls"."custom_guide","iso27017Controls"."custom_guide1","iso27017Controls"."compliance","iso27017Controls"."mapping_id","iso27017Controls"."control_desc" AS "description"';
    } else if (certificateName === 'bsi-c5') {
      controls = 'bsi_c5_controls';
      name = '"bsiC5Controls"';
      alias = '"bsiC5Controls".control_id::text';
      sqlVar = '"bsiC5Controls"."id","bsiC5Controls"."family_id","bsiC5Controls"."family_name","bsiC5Controls"."control_id", "bsiC5Controls"."control_name","bsiC5Controls"."control_guidance","bsiC5Controls"."mapping_id","bsiC5Controls"."control_desc" AS "description"';
    } else if (certificateName === 'iso-27018') {
      controls = 'iso_27018_controls';
      name = '"iso27018Controls"';
      alias = '"iso27018Controls".control_id::text';
      sqlVar = '"iso27018Controls"."id","iso27018Controls"."clause_id","iso27018Controls"."clause_name","iso27018Controls"."category_id","iso27018Controls"."category_name","iso27018Controls"."category_desc","iso27018Controls"."clause_name","iso27018Controls"."control_id", "iso27018Controls"."control_name","iso27018Controls"."control_guide","iso27018Controls"."custom_guide","iso27018Controls"."custom_guide1","iso27018Controls"."compliance","iso27018Controls"."mapping_id","iso27018Controls"."control_desc" AS "description"';
    } else {
      const error = new Error('certificate not found');
      error.status = 404;
      throw error;
    }
    return sequelize
      .query(
        `select distinct * from (
        SELECT 
        ${sqlVar},
         acm."id",
         acm."application_id",
          acm."certificate_id",
          acm."baseline" as "Baseline_Control", 
          acm."control_id", acm."implementation_status",
         acm."notes",acm."attachment_name", acm."attachment_type",
          acm."attachment", 
         acm."created_at", acm."updated_at", 
         at."id" AS "ApplicationTag_id", at."name" AS "ApplicationTagName", at."impact_level" AS "impactLevel", cert."id" AS "Certificate_id", cert."name" AS "Certificate_name"
         FROM "application_tag_controls_members" AS acm 
         LEFT OUTER JOIN "application_tags" AS at ON acm."application_id" = at."id" 
         LEFT OUTER JOIN "certificates" AS cert ON acm."certificate_id" = cert."id" LEFT OUTER JOIN  ${controls}  AS  ${name}  ON acm."control_id" =  ${alias}  WHERE ((acm."application_id" = :applicationTagId AND acm."certificate_id" = :certificateId))) as c;`,
        { replacements: { applicationTagId, certificateId }, type: QueryTypes.SELECT }
      );
  }

  async createApplicationCertificateMember(applicationId, certificateList) {
    if (!certificateList) {
      await AppCertificateMembers.destroy({ where: { application_tag_id: applicationId } });
      return AppCertificateControlMembers.destroy({ where: { $and: [{ application_id: applicationId }] } });
    } else {
      const certificateArray = certificateList.split(',');
      const appCertificateData = await AppCertificateMembers.findAll({ where: { application_tag_id: applicationId } });
      if (appCertificateData.length !== 0) {
        appCertificateData.map(object => {
          if (!certificateArray.includes('' + object.certificate_id + '')) {
            return AppCertificateControlMembers.destroy({
              where: {
                $and: [{
                  application_id: applicationId,
                  certificate_id: object.certificate_id
                }]
              }
            });
          }
        });
      }
      await AppCertificateMembers.destroy({ where: { application_tag_id: applicationId } });
      return certificateArray.map(function (certificateId) {
        return AppCertificateMembers.create({ application_tag_id: applicationId, certificate_id: certificateId });
      });
    }
  }

  async createAppCertificateControlMember(applicationId, params) {
    const controlDetailsArray = params.controls;
    const Certificate = await Certificates.findOne({ where: { id: params.certificate_id } });
    const CertificateName = Certificate.name;
    if (!params.controls || params.controls === '' || params.controls == null) {
      return AppCertificateControlMembers.destroy({
        where: {
          $and: [{
            application_id: applicationId,
            certificate_id: params.certificate_id
          }]
        }
      });
    } else {
      await AppCertificateControlMembers.destroy({
        where: {
          $and: [{
            application_id: applicationId,
            certificate_id: params.certificate_id
          }]
        }
      });
      let i;
      const controlDetailsArLength = controlDetailsArray.length;
      for (i = 0; i < controlDetailsArLength; i++) {
        controlDetailsArray[i].application_id = applicationId;
        controlDetailsArray[i].certificate_id = params.certificate_id;
        controlDetailsArray[i].organization_id = params.orgId;

        if (!controlDetailsArray[i].implementation_status) controlDetailsArray[i].implementation_status = '';
        if (!controlDetailsArray[i].notes) controlDetailsArray[i].notes = '';
        if (!controlDetailsArray[i].attachment_name) controlDetailsArray[i].attachment_name = '';

        if (CertificateName.toLowerCase() === 'iso') {
          controlDetailsArray[i].control_id = controlDetailsArray[i].sub_control; // ISO sub_control is now control_id
        }
        await AppCertificateControlMembers.create(controlDetailsArray[i]);
      }
    }

    return AppCertificateControlMembers.findAll({
      where: {
        $and: [{
          application_id: applicationId,
          certificate_id: params.certificate_id
        }]
      }
    });
  }

  async updateAppCertificateControlMember(applicationId, certificateId, controlId, params) {
    await AppCertificateControlMembers.update(params, {
      where: {
        application_id: applicationId,
        certificate_id: certificateId,
        control_id: controlId
      }
    });
    return AppCertificateControlMembers.findOne({
      where: {
        application_id: applicationId,
        certificate_id: certificateId,
        control_id: controlId
      }
    });
  }

  async getAppCertificateControlMember(applicationId, certificateId, controlId) {
    const result = await AppCertificateControlMembers.findOne({
      where: {
        $and: [{
          application_id: applicationId,
          certificate_id: certificateId,
          control_id: controlId
        }]
      }
    });
    return result;

  }

  async getCertificateApplicationTagDetails(certificateId, orgId) {

    const orgArr = await Organization.getOrgChain(orgId);

    const appCertificateData = await AppCertificateMembers.findAll({ where: { certificate_id: certificateId } });
    const applicationIdArr = appCertificateData.map(function (object) {
      return object.application_tag_id;
    });
    return ApplicationTag.findAll({ where: { $and: [{ id: { $in: applicationIdArr } }, { organization_id: { $in: orgArr } }] } });
  }

  async getAllNistControls(applicationId, orgId, limit, offset) {
    const results = await ApplicationTag.findOne({ where: { id: applicationId } });
    let ciavalue = results.cia_value;
    if (ciavalue) {
      if (ciavalue.match('HIGH')) {
        ciavalue = 'HIGH';
      } else if (ciavalue.match('MODERATE')) {
        ciavalue = 'MODERATE';
      } else if (ciavalue.match('LOW')) {
        ciavalue = 'LOW';
      }
    }
    const exist = await Controls_800_53.findAll({
      attributes: ['id', 'name', 'description', 'compliance', 'family_name', 'title',
        'priority', 'baseline', 'supplemental', 'related'],
      limit: limit,
      offset: offset
    });
    const allControls = [];
    for (let i = 0; i < exist.length; i++) {
      const object = exist[i];
      const baseline = object.baseline;
      if (baseline.match(ciavalue)) {
        object.dataValues.Baseline_Control = 'true';
        allControls.push(object);
      } else {
        object.dataValues.Baseline_Control = 'false';
        allControls.push(object);
      }
    }
    return allControls;
  }

  async getAllPCIControls(applicationId, orgId, limit, offset) {
    const controlArr = [];
    const NistArr = [];
    const results = await ApplicationTag.findOne({ where: { id: applicationId } });
    let ciavalue = results.cia_value;
    if (ciavalue) {
      if (ciavalue.match('HIGH')) {
        ciavalue = 'HIGH';
      } else if (ciavalue.match('MODERATE')) {
        ciavalue = 'MODERATE';
      } else if (ciavalue.match('LOW')) {
        ciavalue = 'LOW';
      }
    }
    const Controls_800_53 = require('../../models/controls_800_53.model');
    const checkBaselineControls = await Controls_800_53.findAll();
    if (checkBaselineControls.length > 0) {
      for (let i = 0; i < checkBaselineControls.length; i++) {
        const object = checkBaselineControls[i];
        const baseline = object.baseline;
        const checknistcontrolsArr = checkBaselineControls[i];
        if (baseline.match(ciavalue)) {
          const control_name = checknistcontrolsArr.name;
          controlArr.push(control_name);
        }
      }
      if (controlArr.length > 0) {
        const checkNistId = await sequelize
          .query(`select * from nist_pci_mappings where nist_id in (:ControlArr)`,
            { replacements: { ControlArr: controlArr }, type: QueryTypes.SELECT });
        if (checkNistId.length > 0) {
          checkNistId.forEach(element => {
            const pci_id = element.pci_id;
            NistArr.push(pci_id);
          });
        }
      }
    }
    const exist = await PciControls.findAll({
      attributes: [[sequelize.fn('DISTINCT', sequelize.col('req_id')), 'req_id'], 'name', 'requirements', 'description', 'compliance', 'family', 'guidance'],
      limit: limit,
      offset: offset
    });
    const allControls = [];
    for (let i = 0; i < exist.length; i++) {
      const object = exist[i];
      const control_name = object.dataValues.test_id;
      if (NistArr.includes(control_name)) {
        object.dataValues.Baseline_Control = 'true';
        allControls.push(object);
      } else {
        object.dataValues.Baseline_Control = 'false';
        allControls.push(object);
      }
    }
    return allControls;
  }

  async getAllNesaControls(applicationId, orgId, limit, offset) {
    const ControlArr = [];
    const NistArr = [];
    const results = await ApplicationTag.findOne({ where: { id: applicationId } });
    let ciavalue = results.cia_value;
    if (ciavalue) {
      if (ciavalue.match('HIGH')) {
        ciavalue = 'HIGH';
      } else if (ciavalue.match('MODERATE')) {
        ciavalue = 'MODERATE';
      } else if (ciavalue.match('LOW')) {
        ciavalue = 'LOW';
      }
    }
    const Controls_800_53 = require('../../models/controls_800_53.model');
    const checkBaselineControls = await Controls_800_53.findAll();
    if (checkBaselineControls.length > 0) {
      for (let i = 0; i < checkBaselineControls.length; i++) {
        const object = checkBaselineControls[i];
        const baseline = object.baseline;
        const checknistcontrolsArr = checkBaselineControls[i];
        if (baseline.match(ciavalue)) {
          const control_name = checknistcontrolsArr.name;
          ControlArr.push(control_name);
        }
      }
      if (ControlArr.length > 0) {
        const checkNistId = await sequelize
          .query(`select * from nist_nesa_mappings where nist_id in (:ControlArr)`,
            { replacements: { ControlArr }, type: QueryTypes.SELECT });
        if (checkNistId.length > 0) {
          checkNistId.forEach(element => {
            const nesa_id = element.nesa_id;
            NistArr.push(nesa_id);
          });
        }
      }
    }
    const exist = await NesaControls.findAll({
      attributes: ['name', 'description', 'compliance', 'family', 'control_type', 'type', 'title', 'priority', 'version', 'standards', 'directive', 'preventive', 'detective', 'corrective', 'low', 'medium', 'high',
        'version_history', 'dependencies', 'control_ref'],
      limit: limit,
      offset: offset
    });
    const allControls = [];
    for (let i = 0; i < exist.length; i++) {
      const object = exist[i];
      const control_name = object.dataValues.name;
      if (NistArr.includes(control_name)) {
        object.dataValues.Baseline_Control = 'true';
        allControls.push(object);
      } else {
        object.dataValues.Baseline_Control = 'false';
        allControls.push(object);
      }
    }
    return allControls;
  }

  async getAllHipaaControls(applicationId, orgId, limit, offset) {
    const ControlArr = [];
    const NistArr = [];
    const results = await ApplicationTag.findOne({ where: { id: applicationId } });
    let ciavalue = results.cia_value;
    if (ciavalue) {
      if (ciavalue.match('HIGH')) {
        ciavalue = 'HIGH';
      } else if (ciavalue.match('MODERATE')) {
        ciavalue = 'MODERATE';
      } else if (ciavalue.match('LOW')) {
        ciavalue = 'LOW';
      }
    }
    const checkBaselineControls = await Controls_800_53.findAll();
    if (checkBaselineControls.length > 0) {
      for (let i = 0; i < checkBaselineControls.length; i++) {
        const object = checkBaselineControls[i];
        const baseline = object.baseline;
        const checknistcontrolsArr = checkBaselineControls[i];
        if (baseline.match(ciavalue)) {
          const control_name = checknistcontrolsArr.name;
          ControlArr.push(control_name);
        }
      }
      if (ControlArr.length > 0) {
        const checkNistId = await sequelize
          .query(`select * from nist_hipaa_mappings where nist_id in (:ControlArr)`,
            { replacements: { ControlArr }, type: QueryTypes.SELECT });
        if (checkNistId.length > 0) {
          checkNistId.forEach(element => {
            const hipaa_id = element.hipaa_id;
            NistArr.push(hipaa_id);
          });
        }
      }
    }
    const exist = await HipaaControls.findAll({
      attributes: ['name', 'description', 'compliance', 'family', 'title', 'implementation'],
      limit: limit,
      offset: offset
    });
    const allControls = [];
    for (let i = 0; i < exist.length; i++) {
      const object = exist[i];
      const control_name = object.dataValues.name;
      if (NistArr.includes(control_name)) {
        object.dataValues.Baseline_Control = 'true';
        allControls.push(object);
      } else {
        object.dataValues.Baseline_Control = 'false';
        allControls.push(object);
      }
    }
    return allControls;
  }

  async getAllIsoControls(applicationId, orgId, limit, offset) {
    const ControlArr = [];
    const NistArr = [];
    const results = await ApplicationTag.findOne({ where: { id: applicationId } });
    let ciavalue = results.cia_value;
    if (ciavalue) {
      if (ciavalue.match('HIGH')) {
        ciavalue = 'HIGH';
      } else if (ciavalue.match('MODERATE')) {
        ciavalue = 'MODERATE';
      } else if (ciavalue.match('LOW')) {
        ciavalue = 'LOW';
      }
    }
    const checkBaselineControls = await Controls_800_53.findAll();
    if (checkBaselineControls.length > 0) {
      for (let i = 0; i < checkBaselineControls.length; i++) {
        const object = checkBaselineControls[i];
        const baseline = object.baseline;
        const checknistcontrolsArr = checkBaselineControls[i];
        if (baseline.match(ciavalue)) {
          const control_name = checknistcontrolsArr.name;
          ControlArr.push(control_name);
        }
      }
      if (ControlArr.length > 0) {
        const checkNistId = await sequelize
          .query(`select * from nist_iso_mappings where nist_id in (:ControlArr)`,
            { replacements: { ControlArr }, type: QueryTypes.SELECT });
        if (checkNistId.length > 0) {
          checkNistId.forEach(element => {
            const iso_27002_id = element.iso_27002;
            NistArr.push(iso_27002_id);
          });
        }
      }
    }
    const exist = await IsoControls.findAll({
      attributes: [['sub_control', 'control'], 'sub_control', 'description', 'compliance', 'family', 'title', 'objective', 'imp_guidance', 'other_info'],
      limit: limit,
      offset: offset
    });
    const allControls = [];
    for (let i = 0; i < exist.length; i++) {
      const object = exist[i];
      const name = removeSpace.checkMultiSpace(object.dataValues.sub_control);
      object.dataValues.sub_control = name;
      const control_name = object.dataValues.sub_control;
      if (NistArr.includes(control_name)) {
        object.dataValues.Baseline_Control = 'true';
        allControls.push(object);
      } else {
        object.dataValues.Baseline_Control = 'false';
        allControls.push(object);
      }
    }
    return allControls;
  }

  async getAllCustomControls(applicationId, orgId, limit, offset) {
    const ControlArr = [];
    const NistArr = [];
    const results = await ApplicationTag.findOne({ where: { id: applicationId } });
    let ciavalue = results.cia_value;
    if (ciavalue) {
      if (ciavalue.match('HIGH')) {
        ciavalue = 'HIGH';
      } else if (ciavalue.match('MODERATE')) {
        ciavalue = 'MODERATE';
      } else if (ciavalue.match('LOW')) {
        ciavalue = 'LOW';
      }
    }
    const checkBaselineControls = await Controls_800_53.findAll();
    if (checkBaselineControls.length > 0) {
      for (let i = 0; i < checkBaselineControls.length; i++) {
        const object = checkBaselineControls[i];
        const baseline = object.baseline;
        const checknistcontrolsArr = checkBaselineControls[i];
        if (baseline.match(ciavalue)) {
          const control_name = checknistcontrolsArr.name;
          ControlArr.push(control_name);
        }
      }
      if (ControlArr.length > 0) {
        const checkNistId = await sequelize
          .query(`select * from nist_custom_mappings where nist_id in (:ControlArr)`,
            { replacements: { ControlArr }, type: QueryTypes.SELECT });
        if (checkNistId.length > 0) {
          checkNistId.forEach(element => {
            const custom_id = element.custom_id;
            NistArr.push(custom_id);
          });
        }
      }
    }
    const exist = await CustomControls.findAll({
      attributes: ['family', 'control_type', 'name', 'type', 'title', 'priority', 'version', ['standards', 'description'], 'directive', 'preventive', 'detective', 'corrective', 'low', 'medium', 'high',
        'version_history', 'dependencies', 'control_ref', 'compliance', 'organization_id'],
      limit: limit,
      offset: offset
    });
    const allControls = [];
    for (let i = 0; i < exist.length; i++) {
      const object = exist[i];
      const control_name = object.dataValues.name;
      if (NistArr.includes(control_name)) {
        object.dataValues.Baseline_Control = 'true';
        allControls.push(object);
      } else {
        object.dataValues.Baseline_Control = 'false';
        allControls.push(object);
      }
    }
    return allControls;
  }

  async getAllGDPRControls(applicationId, orgId, limit, offset) {
    const ISO_idArr = [];
    const ControlArr = [];
    const NistArr = [];
    const results = await ApplicationTag.findOne({ where: { id: applicationId } });
    let ciavalue = results.cia_value;
    if (ciavalue) {
      if (ciavalue.match('HIGH')) {
        ciavalue = 'HIGH';
      } else if (ciavalue.match('MODERATE')) {
        ciavalue = 'MODERATE';
      } else if (ciavalue.match('LOW')) {
        ciavalue = 'LOW';
      }
    }
    const checkBaselineControls = await Controls_800_53.findAll();
    if (checkBaselineControls.length > 0) {
      for (let i = 0; i < checkBaselineControls.length; i++) {
        const object = checkBaselineControls[i];
        const baseline = object.baseline;
        const checknistcontrolsArr = checkBaselineControls[i];
        if (baseline.match(ciavalue)) {
          const control_name = checknistcontrolsArr.name;
          ControlArr.push(control_name);
        }
      }
      if (ControlArr.length > 0) {
        const checkNistId = await sequelize
          .query(`select * from nist_iso_mappings where nist_id in (:ControlArr)`,
            { replacements: { ControlArr }, type: QueryTypes.SELECT });
        if (checkNistId.length > 0) {
          for (let k = 0; k < checkNistId.length; k++) {
            const element = checkNistId[k];
            const iso_27001 = element.iso_27001;
            ISO_idArr.push(iso_27001);
          }
          const checkISOId = await sequelize
            .query(`select * from gdpr_iso_mappings where iso_id in(:ISO_idArr)`,
              { replacements: { ISO_idArr }, type: QueryTypes.SELECT });
          if (checkISOId.length > 0) {
            for (let l = 0; l < checkISOId.length; l++) {
              const elements = checkISOId[l];
              const artical_id = elements.gdpr_id;
              NistArr.push(artical_id);
            }
          }
        }
      }
    }
    const exist = await gdprControls.findAll({
      attributes: ['name', 'description', 'compliance', 'chapter', 'chapter_title', 'session', 'title', 'artical_id'],
      limit: limit,
      offset: offset
    });
    const allControls = [];
    for (let i = 0; i < exist.length; i++) {
      const object = exist[i];
      const artical_id = object.dataValues.artical_id;
      if (NistArr.includes(artical_id)) {
        object.dataValues.Baseline_Control = 'true';
        allControls.push(object);
      } else {
        object.dataValues.Baseline_Control = 'false';
        allControls.push(object);
      }
    }
    return allControls;
  }

  async getAllFFIECControls(applicationId, orgId, limit, offset) {
    const cyber_idArr = [];
    const ControlArr = [];
    const FfiecArr = [];
    const results = await ApplicationTag.findOne({ where: { id: applicationId } });
    let ciavalue = results.cia_value;
    if (ciavalue) {
      if (ciavalue.match('HIGH')) {
        ciavalue = 'HIGH';
      } else if (ciavalue.match('MODERATE')) {
        ciavalue = 'MODERATE';
      } else if (ciavalue.match('LOW')) {
        ciavalue = 'LOW';
      }
    }
    const checkBaselineControls = await Controls_800_53.findAll();
    if (checkBaselineControls.length > 0) {
      for (let i = 0; i < checkBaselineControls.length; i++) {
        const object = checkBaselineControls[i];
        const baseline = object.baseline;
        const checknistcontrolsArr = checkBaselineControls[i];
        if (baseline.match(ciavalue)) {
          const control_name = checknistcontrolsArr.name;
          ControlArr.push(control_name);
        }
      }
      if (ControlArr.length > 0) {
        const checkNistId = await sequelize
          .query(`select * from ffiec_nist_mappings where nist_id in (:ControlArr)`,
            { replacements: { ControlArr }, type: QueryTypes.SELECT });
        if (checkNistId.length > 0) {
          for (let k = 0; k < checkNistId.length; k++) {
            const element = checkNistId[k];
            const cyber_id = element.cyber_id;
            cyber_idArr.push(cyber_id);
          }
          const checkCyber_id = await sequelize
            .query(`select * from ffiec_cyber_mappings where cyber_id in(:cyber_idArr)`,
              { replacements: { cyber_idArr }, type: QueryTypes.SELECT });
          if (checkCyber_id.length > 0) {
            for (let l = 0; l < checkCyber_id.length; l++) {
              const elements = checkCyber_id[l];
              const ffiec_id = elements.ffiec_id;
              FfiecArr.push(ffiec_id);
            }
          }
        }
      }
    }
    const exist = await ffiec_controls.findAll({
      attributes: ['id', 'family', 'control', 'control_desc', 'compliance'],
      limit: limit,
      offset: offset
    });
    const allControls = [];
    for (let i = 0; i < exist.length; i++) {
      const object = exist[i];
      const control = object.dataValues.control;
      if (FfiecArr.includes(control)) {
        object.dataValues.Baseline_Control = 'true';
        allControls.push(object);
      } else {
        object.dataValues.Baseline_Control = 'false';
        allControls.push(object);
      }
    }
    return allControls;
  }

  async getAllFedrampLowControls(applicationId, orgId, limit, offset) {
    const results = await ApplicationTag.findOne({ where: { id: applicationId } });
    const ciavalue = results.cia_value;
    const exist = await fedramp_low_controls.findAll({
      attributes: ['id', 'family', 'control_id', 'control_name', 'control_desc', 'select_params',
        'compliance', 'guidance'],
      limit: limit,
      offset: offset
    });
    const allControls = [];
    for (let i = 0; i < exist.length; i++) {
      const object = exist[i];
      if (ciavalue && ciavalue.match('LOW')) {
        object.dataValues.Baseline_Control = 'true';
        allControls.push(object);
      } else {
        object.dataValues.Baseline_Control = 'false';
        allControls.push(object);
      }
    }
    return allControls;
  }

  async getAllFedrampHighControls(applicationId, orgId, limit, offset) {
    const results = await ApplicationTag.findOne({ where: { id: applicationId } });
    const ciavalue = results.cia_value;
    const exist = await fedramp_high_controls.findAll({
      attributes: ['id', 'family', 'control_id', 'control_name', 'control_desc', 'select_params',
        'compliance', 'guidance'],
      limit: limit,
      offset: offset
    });
    const allControls = [];
    for (let i = 0; i < exist.length; i++) {
      const object = exist[i];
      if (ciavalue && ciavalue.match('HIGH')) {
        object.dataValues.Baseline_Control = 'true';
        allControls.push(object);
      } else {
        object.dataValues.Baseline_Control = 'false';
        allControls.push(object);
      }

    }
    return allControls;
  }

  async getAllFedrampModerateControls(applicationId, orgId, limit, offset) {
    const results = await ApplicationTag.findOne({ where: { id: applicationId } });
    const ciavalue = results.cia_value;
    const exist = await fedramp_moderate_controls.findAll({
      attributes: ['id', 'family', 'control_id', 'control_name',
        'control_desc', 'select_params', 'compliance', 'guidance'],
      limit: limit,
      offset: offset
    });
    const allControls = [];
    for (let i = 0; i < exist.length; i++) {
      const object = exist[i];
      if (ciavalue && ciavalue.match('MODERATE')) {
        object.dataValues.Baseline_Control = 'true';
        allControls.push(object);
      } else {
        object.dataValues.Baseline_Control = 'false';
        allControls.push(object);
      }
    }
    return allControls;
  }

  async getAllSAMAControls(applicationId, orgId, limit, offset) {
    const ControlArr = [];
    const NistArr = [];
    const results = await ApplicationTag.findOne({ where: { id: applicationId } });
    let ciavalue = results.cia_value;
    if (ciavalue) {
      if (ciavalue.match('HIGH')) {
        ciavalue = 'HIGH';
      } else if (ciavalue.match('MODERATE')) {
        ciavalue = 'MODERATE';
      } else if (ciavalue.match('LOW')) {
        ciavalue = 'LOW';
      }
    }
    const checkBaselineControls = await Controls_800_53.findAll();
    if (checkBaselineControls.length > 0) {
      for (let i = 0; i < checkBaselineControls.length; i++) {
        const object = checkBaselineControls[i];
        const baseline = object.baseline;
        const checknistcontrolsArr = checkBaselineControls[i];
        if (baseline.match(ciavalue)) {
          const control_name = checknistcontrolsArr.name;
          ControlArr.push(control_name);
        }
      }
      if (ControlArr.length > 0) {
        const checkNistId = await sequelize
          .query(`select * from nist_sama_mappings where nist_id in (:ControlArr)`,
            { replacements: { ControlArr }, type: QueryTypes.SELECT });
        if (checkNistId.length > 0) {
          checkNistId.forEach(element => {
            const sama_id = element.sama_id;
            NistArr.push(sama_id);
          });
        }
      }
    }
    const exist = await sama_controls.findAll({
      limit: limit, offset: offset
    });
    const allControls = [];
    for (let i = 0; i < exist.length; i++) {
      const object = exist[i];
      const control_name = object.dataValues.supplement_control_id;
      if (NistArr.includes(control_name)) {
        object.dataValues.Baseline_Control = 'true';
        allControls.push(object);
      } else {
        object.dataValues.Baseline_Control = 'false';
        allControls.push(object);
      }
    }
    return allControls;
  }

  async getAllKVKKControls(applicationId, orgId, limit, offset) {
    const ControlArr = [];
    const NistArr = [];
    const results = await ApplicationTag.findOne({ where: { id: applicationId } });
    let ciavalue = results.cia_value;
    if (ciavalue) {
      if (ciavalue.match('HIGH')) {
        ciavalue = 'HIGH';
      } else if (ciavalue.match('MODERATE')) {
        ciavalue = 'MODERATE';
      } else if (ciavalue.match('LOW')) {
        ciavalue = 'LOW';
      }
    }
    const checkBaselineControls = await Controls_800_53.findAll();
    if (checkBaselineControls.length > 0) {
      for (let i = 0; i < checkBaselineControls.length; i++) {
        const object = checkBaselineControls[i];
        const baseline = object.baseline;
        const checknistcontrolsArr = checkBaselineControls[i];
        if (baseline.match(ciavalue)) {
          const control_name = checknistcontrolsArr.name;
          ControlArr.push(control_name);
        }
      }
      if (ControlArr.length > 0) {
        const checkNistId = await sequelize
          .query(`select * from nist_kvkk_mappings where nist_id in (:ControlArr)`,
            { replacements: { ControlArr }, type: QueryTypes.SELECT });
        if (checkNistId.length > 0) {
          checkNistId.forEach(element => {
            const kvkk_id = element.kvkk_id;
            NistArr.push(kvkk_id);
          });
        }
      }
    }
    const exist = await KvkkControls.findAll({
      limit: limit, offset: offset
    });
    const allControls = [];
    for (let i = 0; i < exist.length; i++) {
      const object = exist[i];
      const control_name = object.dataValues.control_id;
      if (NistArr.includes(control_name)) {
        object.dataValues.Baseline_Control = 'true';
        allControls.push(object);
      } else {
        object.dataValues.Baseline_Control = 'false';
        allControls.push(object);
      }
    }
    return allControls;
  }

  async getKorIsmsControls(applicationId, orgId, limit, offset) {
    const results = await ApplicationTag.findOne({ where: { id: applicationId } });
    const ciavalue = results.cia_value;
    const exist = await KorIsmsControls.findAll({
      attributes: ['id', 'domain_id', 'domain', 'family_id',
        'family', 'control_id', 'control_name', 'control_desc', 'control_test', 'mapping_id', 'compliance'],
      limit,
      offset
    });
    const allControls = [];
    for (let i = 0; i < exist.length; i++) {
      const object = exist[i];
      if (ciavalue && ciavalue.match('MODERATE')) {
        object.dataValues.Baseline_Control = 'true';
        allControls.push(object);
      } else {
        object.dataValues.Baseline_Control = 'false';
        allControls.push(object);
      }
    }
    return allControls;
  }

  async getSgpMtcsControls(applicationId, orgId, limit, offset) {
    const results = await ApplicationTag.findOne({ where: { id: applicationId } });
    const ciavalue = results.cia_value;
    const exist = await SgpMtcsControls.findAll({
      attributes: ['id', 'family_id',
        'family', 'family_desc', 'control_id', 'control_name', 'control_desc', 'level1', 'level2', 'level3', 'mapping_id', 'compliance'],
      limit,
      offset
    });
    const allControls = [];
    for (let i = 0; i < exist.length; i++) {
      const object = exist[i];
      if (ciavalue && ciavalue.match('MODERATE')) {
        object.dataValues.Baseline_Control = 'true';
        allControls.push(object);
      } else {
        object.dataValues.Baseline_Control = 'false';
        allControls.push(object);
      }
    }
    return allControls;
  }

  async getApraCpsControls(applicationId, orgId, limit, offset) {
    const results = await ApplicationTag.findOne({ where: { id: applicationId } });
    const ciavalue = results.cia_value;
    const exist = await ApraCpsControls.findAll({
      attributes: ['id', 'family_name', 'control_id', 'control_name', 'control_desc', 'mapping_id', 'compliance'],
      limit,
      offset
    });
    const allControls = [];
    for (let i = 0; i < exist.length; i++) {
      const object = exist[i];
      if (ciavalue && ciavalue.match('MODERATE')) {
        object.dataValues.Baseline_Control = 'true';
        allControls.push(object);
      } else {
        object.dataValues.Baseline_Control = 'false';
        allControls.push(object);
      }
    }
    return allControls;
  }

  async getCsaControls(applicationId, orgId, limit, offset) {
    const results = await ApplicationTag.findOne({ where: { id: applicationId } });
    const ciavalue = results.cia_value;
    const exist = await CsaControls.findAll({
      attributes: ['id', 'domain_name', 'domain_id', 'control_id', 'control_desc', 'mapping_id', 'compliance'],
      limit,
      offset
    });
    const allControls = [];
    for (let i = 0; i < exist.length; i++) {
      const object = exist[i];
      if (ciavalue && ciavalue.match('MODERATE')) {
        object.dataValues.Baseline_Control = 'true';
        allControls.push(object);
      } else {
        object.dataValues.Baseline_Control = 'false';
        allControls.push(object);
      }
    }
    return allControls;
  }

  async getCsfControls(applicationId, orgId, limit, offset) {
    const results = await ApplicationTag.findOne({ where: { id: applicationId } });
    const ciavalue = results.cia_value;
    const exist = await CsfControls.findAll({
      attributes: ['id', 'function', 'sub_control_id', 'control_name', 'control_id', 'control_desc', 'mapping_id', 'compliance'],
      limit,
      offset
    });
    const allControls = [];
    for (let i = 0; i < exist.length; i++) {
      const object = exist[i];
      if (ciavalue && ciavalue.match('MODERATE')) {
        object.dataValues.Baseline_Control = 'true';
        allControls.push(object);
      } else {
        object.dataValues.Baseline_Control = 'false';
        allControls.push(object);
      }
    }
    return allControls;
  }

  async getIrsControls(applicationId, orgId, limit, offset) {
    const results = await ApplicationTag.findOne({ where: { id: applicationId } });
    const ciavalue = results.cia_value;
    const exist = await IrsControls.findAll({
      attributes: ['id', 'family_name', 'session_id', 'control_id', 'control_name', 'control_desc', 'mapping_id', 'compliance'],
      limit,
      offset
    });
    const allControls = [];
    for (let i = 0; i < exist.length; i++) {
      const object = exist[i];
      if (ciavalue && ciavalue.match('MODERATE')) {
        object.dataValues.Baseline_Control = 'true';
        allControls.push(object);
      } else {
        object.dataValues.Baseline_Control = 'false';
        allControls.push(object);
      }
    }
    return allControls;
  }

  async getBsiC5Controls(applicationId, orgId, limit, offset) {
    const results = await ApplicationTag.findOne({ where: { id: applicationId } });
    const ciavalue = results.cia_value;
    const exist = await BsiC5Controls.findAll({
      attributes: ['id', 'family_id', 'family_name', 'control_name', 'control_id', 'control_desc', 'control_guidance', 'mapping_id', 'compliance'],
      limit,
      offset
    });
    const allControls = [];
    for (let i = 0; i < exist.length; i++) {
      const object = exist[i];
      if (ciavalue && ciavalue.match('MODERATE')) {
        object.dataValues.Baseline_Control = 'true';
        allControls.push(object);
      } else {
        object.dataValues.Baseline_Control = 'false';
        allControls.push(object);
      }
    }
    return allControls;
  }

  async getISO27017Controls(applicationId, orgId, limit, offset) {
    const results = await ApplicationTag.findOne({ where: { id: applicationId } });
    const ciavalue = results.cia_value;
    const exist = await Iso27017Controls.findAll({
      attributes: ['id', 'clause_id', 'clause_name', 'category_id', 'category_name', 'category_desc', 'control_id', 'control_name', 'control_desc', 'control_guide', 'custom_guide', 'custom_guide1', 'mapping_id', 'compliance'],
      limit,
      offset
    });
    const allControls = [];
    for (let i = 0; i < exist.length; i++) {
      const object = exist[i];
      if (ciavalue && ciavalue.match('MODERATE')) {
        object.dataValues.Baseline_Control = 'true';
        allControls.push(object);
      } else {
        object.dataValues.Baseline_Control = 'false';
        allControls.push(object);
      }
    }
    return allControls;
  }

  async getISO27018Controls(applicationId, orgId, limit, offset) {
    const results = await ApplicationTag.findOne({ where: { id: applicationId } });
    const ciavalue = results.cia_value;
    const exist = await Iso27018Controls.findAll({
      attributes: ['id', 'clause_id', 'clause_name', 'category_id', 'category_name', 'category_desc', 'control_id', 'control_name', 'control_desc', 'control_guide', 'custom_guide', 'custom_guide1', 'mapping_id', 'compliance'],
      limit,
      offset
    });
    const allControls = [];
    for (let i = 0; i < exist.length; i++) {
      const object = exist[i];
      if (ciavalue && ciavalue.match('MODERATE')) {
        object.dataValues.Baseline_Control = 'true';
        allControls.push(object);
      } else {
        object.dataValues.Baseline_Control = 'false';
        allControls.push(object);
      }
    }
    return allControls;
  }

  async getNist800171Controls(applicationId, orgId, limit, offset) {
    const results = await ApplicationTag.findOne({ where: { id: applicationId } });
    const ciavalue = results.cia_value;
    const exist = await Nist800171Controls.findAll({
      attributes: ['id', 'family_id', 'family_name', 'control_name', 'control_id', 'control_desc', 'control_guide', 'mapping_id', 'compliance'],
      limit,
      offset
    });
    const allControls = [];
    for (let i = 0; i < exist.length; i++) {
      const object = exist[i];
      if (ciavalue && ciavalue.match('MODERATE')) {
        object.dataValues.Baseline_Control = 'true';
        allControls.push(object);
      } else {
        object.dataValues.Baseline_Control = 'false';
        allControls.push(object);
      }
    }
    return allControls;
  }

  async ChangeApplicationState(applicationTagId, update) {
    const status = update.managed;
    await ApplicationTag.update({ managed: status }, { where: { id: applicationTagId } });
    return ApplicationTag.findOne({ where: { id: applicationTagId } });
  }

  async getRegulationById(certificateId) {
    const certificates = await Certificates.findOne({ where: { id: certificateId } });
    const certificateName = toLower(get(certificates, 'name'));
    let baselineControls = '';
    const certificateQueries = {
      nist: `select * from controls_800_53`,
      'fisma (nist-800-53-r4)': `select * from controls_800_53`,
      nesa: `select * from nesa_controls`,
      pci: `select * from pci_controls`,
      iso: `select * from iso_controls`,
      hipaa: `select * from hipaa_controls`,
      gdpr: `select * from gdpr_controls`,
      custom: `select * from custom_controls`,
      ffiec: `select * from ffiec_controls`,
      'fedramp low': `select * from fedramp_low_controls`,
      'fedramp moderate': `select * from fedramp_moderate_controls`,
      'fedramp high': `select * from fedramp_high_controls`,
      sama: `select * from sama_controls`,
      kvkk: `select * from kvkk_controls`,
      'kor-isms': `select * from kor_isms_controls`,
      'sgp-mtcs': `select * from sgp_controls`,
      irs: `select * from irs_controls`,
      csa: `select * from csa_controls`,
      csf: `select * from csf_controls`,
      'apra-cps': `select * from apra_cps_controls`,
      'bsi-c5': `select * from bsi_c5_controls`
    };

    const query = get(certificateQueries, `[${certificateName}]`);
    if (query) {
      baselineControls = await sequelize.query(query, {
        replacements: {},
        type: QueryTypes.SELECT
      });
    }

    return baselineControls;
  }

  async getSubApplicationByAppId(orgId, appId) {
    const orgChain = await Organization.getOrgChain(orgId);
    const subApps = await SubApplication.findAll({
      isActive: { $ne: 'false' },
      include: [
        { model: Organization, where: { id: orgChain }, required: true },
        { model: ApplicationTag, where: { id: appId }, required: true }
      ]
    });
    return subApps;
  }

  async getAssetsByAppName(orgId, appName) {
    const orgChain = await Organization.getOrgChain(orgId);
    const AssetList = await sequelize.query('select * from application_group_asset_view apv left outer join aws_vpc_regions aws on aws.asset_id = apv.id where apv.application_grp_name = :appName and apv.organization_id in (:orgChain)', {
      replacements: { appName, orgChain },
      type: sequelize.QueryTypes.SELECT
    });
    return AssetList;
  }
};
