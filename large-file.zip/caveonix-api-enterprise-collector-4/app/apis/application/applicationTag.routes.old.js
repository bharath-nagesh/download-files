const express = require('express');
const ApplicationController = require('./applicationTag.controller');
const router = express.Router({mergeParams:true});

const applicationController = new ApplicationController();
router.get('/:applicationTagId', applicationController.getApplicationTagById);
router.put('/:applicationTagId', applicationController.updateApplicationTag);
router.delete('/:applicationTagId', applicationController.deleteApplicationTag);

// router.post('/', applicationController.createApplicationTag);
// router.get('/:applicationTagId/applicationTagDetail', applicationController.getApplicationTagDetail);
// router.post('/:applicationTagId/applicationTagDetail', applicationController.createApplicationTagDetail);

module.exports = router;
