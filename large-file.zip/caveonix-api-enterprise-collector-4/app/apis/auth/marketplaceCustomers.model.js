const Sequelize = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();

class MarketplaceCustomers extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
      customerId: {
        type: Sequelize.STRING,
        field: 'customer_id'
      },
      productId: {
        type: Sequelize.STRING,
        field: 'product_id'
      },
      uuid: {
        type: Sequelize.STRING,
        field: 'uuid'
      },
      createdAt: {
        type: Sequelize.DATE,
        field: 'created_at',
        defaultValue:Sequelize.NOW
      }
    },
    {
      sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'marketplace_customers',
      underscored: true,
      createdAt: 'created_at'
    });
  }

}
module.exports = MarketplaceCustomers;
