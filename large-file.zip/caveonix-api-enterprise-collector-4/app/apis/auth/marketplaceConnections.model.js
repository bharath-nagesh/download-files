const Sequelize = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();

class MarketplaceConnections extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
      authKey: {
        type: Sequelize.STRING,
        field: 'auth_key'
      },
      authCode: {
        type: Sequelize.STRING,
        field: 'auth_code'
      },
      isActive: {
        type: Sequelize.STRING,
        field: 'is_active'
      }
    },
    {
      sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'marketplace_connections',
      underscored: true
    });
  }

}
module.exports = MarketplaceConnections;
