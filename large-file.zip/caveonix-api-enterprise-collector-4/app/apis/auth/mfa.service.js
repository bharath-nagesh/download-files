const authenticator = require('authenticator');
const User = require('../user/user.model');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-login.controller'
});

module.exports = class MFAService {

  async verifyMFA(userId, TOTP = null) {
    const user = await User.findByPk(userId);
    if (!user.twoFactorToken) return true;
    if(!TOTP){
      logger.error({ userId }, 'Unauthorized,  TOTP Failed');
      const err = new Error('Unauthorized,  TOTP Failed');
      err.status = 400;
      throw err;
    }
    const otpVerify = authenticator.verifyToken(user.twoFactorToken, TOTP.toString());
    if (!otpVerify) {
      logger.error('Unauthorized,  TOTP Failed');
      return false;
    }
    return true;
  }

  async generateTOTPUri(userId) {
    const user = await User.findByPk(userId);
    if(user.twoFactorToken){
      logger.error({ userId }, 'MFA is already enabled');
      const err = new Error('MFA is already enabled');
      err.status = 400;
      throw err;
    }
    const twoFactorToken = authenticator.generateKey();
    await user.update({ twoFactorToken });
    const uri = authenticator.generateTotpUri(twoFactorToken, user.username, 'RiskForesight', 'SHA1', 6, 30);
    return { uri, key:twoFactorToken, account:user, issuer:'RiskForesight', mode:'Time Based', userId };
  }

  async removeMFA(userId) {
    return User.update({ twoFactorToken: null }, { where: { id: userId } });
  }

};
