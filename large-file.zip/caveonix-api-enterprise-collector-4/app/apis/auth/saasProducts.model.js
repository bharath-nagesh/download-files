const Sequelize = require('sequelize');

class SaaSProducts extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
      productName: {
        type: Sequelize.STRING,
        field: 'product_name'
      },
      productDesc: {
        type: Sequelize.STRING,
        field: 'product_desc'
      },
      productCode: {
        type: Sequelize.STRING,
        field: 'product_code'
      },
      productSource: {
        type: Sequelize.STRING,
        field: 'product_source'
      },
      contractType: {
        type: Sequelize.STRING,
        field: 'contract_type'
      },
      price: {
        type: Sequelize.STRING,
        field: 'price'
      },
      assetCountIncluded: {
        type: Sequelize.STRING,
        field: 'asset_count_included'
      },
      isActive: {
        type: Sequelize.STRING,
        field: 'is_active'
      }
    },
    {
      sequelize,
      timestamps: true,
      freezeTableName: true,
      tableName: 'saas_products',
      underscored: true
    });
  }

}
module.exports = SaaSProducts;
