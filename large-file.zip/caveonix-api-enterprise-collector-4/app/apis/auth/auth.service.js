const MarketplaceCustomers = require('./marketplaceCustomers.model');
const MarketplaceConnections = require('./marketplaceConnections.model');
const SaaSProducts = require('./saasProducts.model');
const DirectRegistrations = require('./directRegistrations.model');
const OrgService = require('../organization/org.service');
const orgService = new OrgService();
const UserService = require('../user/user.service');
const userService = new UserService();
const LoginService = require('./login.service');
const loginService = new LoginService();
const KibanaUserRolesService = require('../kibanaUserRoles/kibanaUserRoles.service');
const kibanaUserRolesService = new KibanaUserRolesService();
const AuthorizationInfoService = require('../authorizationInfo/authorizationInfo.service');
const authorizationInfoService = new AuthorizationInfoService();
const KeyGenerator = require('../../../utils/generateKeys');
const EmailServerService = require('../emailServer/emailServer.service');
const emailServerService = new EmailServerService();
const AWS = require('aws-sdk');
const chargebee = require('chargebee');
const uuid = require('uuid/v4');
const utils = require('util');
const moment = require('moment');
const rp = require('request-promise');
const config = require('../../../configure').get();
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-auth.service'
});

module.exports = class AuthService {
  constructor() {
    this.keyGenerator = new KeyGenerator();
  }

  async preRegisterAWS(registrationToken) {
    const marketplaceConnections = await MarketplaceConnections.findOne({ where: { isActive: 'enabled' } });
    marketplaceConnections.authCode = await this.keyGenerator.decryptKeys(marketplaceConnections.authCode);
    const marketplaceMetering = new AWS.MarketplaceMetering({
      accessKeyId: marketplaceConnections.authKey,
      secretAccessKey: marketplaceConnections.authCode,
      region: 'us-east-1'
    });
    try {
      marketplaceMetering.resolveCustomer = utils.promisify(marketplaceMetering.resolveCustomer);
      const resolveCustomer = await marketplaceMetering.resolveCustomer({ RegistrationToken: registrationToken });
      logger.info(resolveCustomer);
      const marketplaceCustomersData = {
        customerId: resolveCustomer.CustomerIdentifier,
        productId: resolveCustomer.ProductCode,
        uuid: uuid()
      };
      await MarketplaceCustomers.create(marketplaceCustomersData);
      const token = new Buffer(await this.keyGenerator.generateKeys(marketplaceCustomersData.uuid)).toString('base64');
      return `/registration?token=${token}&source=marketplace`;
    } catch (err) {
      logger.error({ err, stack: err.stack }, 'AWS Resolve Customer Error');
      const error = new Error('AWS Resolve Customer Error');
      error.status = 400;
      throw error;
    }

  }

  async preRegisterDirect(params) {
    await this.captchaVerify(params.g_recaptcha_response);
    const exists = await DirectRegistrations.findOne({ where: { emailAddress: params.emailAddress } });
    if (exists) {
      logger.error('Email Already Registered');
      const error = new Error('Email Already Registered');
      error.status = 400;
      throw error;
    }
    try {
      if (!config.register_url) {
        logger.error('register_url Not Configured');
        const error = new Error('Direct Pre Registration Error');
        error.status = 400;
        throw error;
      }
      const data = await DirectRegistrations.create({ emailAddress: params.emailAddress, token: uuid(), verified: false });
      const token = new Buffer(await this.keyGenerator.generateKeys(data.token)).toString('base64');
      const link = `${config.register_url}/api/direct/register/verify?emailAddress=${params.emailAddress}&token=${token}`;
      try {
        await emailServerService.sendEmail(-1, null, 'RiskForesight Verification', `RiskForesight Verification Link\n ${link}`, null, params.emailAddress);
      } catch (e) {
        logger.error(e);
      }
      return { message: 'Success' };
    } catch (err) {
      logger.error({ err, stack: err.stack }, 'Direct Pre Registration Error');
      const error = new Error('Direct Pre Registration Error');
      error.status = 400;
      throw error;
    }
  }

  async directRegisterVerify(params) {
    let token = Buffer.from(params.token, 'base64').toString('utf-8');
    token = await this.keyGenerator.decryptKeys(token);
    const data = await DirectRegistrations.findOne({ where: { emailAddress: params.emailAddress, token, verified: false } });
    if (!data) {
      logger.error('Registration Link is Invalid or Expired');
      const error = new Error('Registration Link is Invalid or Expired');
      error.status = 400;
      throw error;
    }
    try {
      await data.update({ verified: true });
      return `/registration?token=${params.token}&source=direct`;
    } catch (err) {
      logger.error({ err, stack: err.stack }, 'Direct Pre Registration Error');
      const error = new Error('Direct Pre Registration Error');
      error.status = 400;
      throw error;
    }
  }

  async register(params, token, source) {
    await this.captchaVerify(params.g_recaptcha_response);
    token = Buffer.from(token, 'base64').toString('utf-8');
    token = await this.keyGenerator.decryptKeys(token);
    const orgParams = {
      name: uuid(),
      aliasName: params.company,
      type: 'Organization',
      orgType: 'SaaS',
      email: params.username,
      phone: params.phone || null,
      source: 'Direct',
      product_offering_id: '1,2,3',
      certificate_id: '1',
      bia_value: 'High',
      autoAssignment: 'false',
      isActive: 'enabled',
      externalId: null,
      billingAccountId: null,
      licenseType: 'Trial',
      licenseCode: 'Trial',
      licenseCount: 25,
      unitCount: params.unitCount,
      startDate: moment().toDate(),
      endDate: moment().add(14, 'days').toDate()
    };

    if (source === 'marketplace') {
      const marketplaceConnections = await MarketplaceConnections.findOne({ where: { isActive: 'enabled' } });
      marketplaceConnections.authCode = await this.keyGenerator.decryptKeys(marketplaceConnections.authCode);
      const marketplaceCustomersData = await MarketplaceCustomers.findOne({ where: { uuid: token } });
      if (!marketplaceCustomersData) {
        logger.error('Invalid Token for Registration');
        const error = new Error('Invalid Payload');
        error.status = 400;
        throw error;
      }
      var marketplaceEntitlementService = new AWS.MarketplaceEntitlementService({
        accessKeyId: marketplaceConnections.authKey,
        secretAccessKey: marketplaceConnections.authCode,
        region: 'us-east-1'
      });
      const entitlementsParams = {
        ProductCode: marketplaceCustomersData.productId,
        Filter: {
          CUSTOMER_IDENTIFIER: [marketplaceCustomersData.customerId]
        }
      };
      marketplaceEntitlementService.getEntitlements = utils.promisify(marketplaceEntitlementService.getEntitlements);
      const getEntitlements = await marketplaceEntitlementService.getEntitlements(entitlementsParams);
      logger.info(getEntitlements);
      const saaSProductsDetails = await SaaSProducts.findOne({ where: { productCode: getEntitlements.Entitlements[0].Dimension } });
      if (!saaSProductsDetails) {
        logger.error('Invalid Product Code');
        const error = new Error('Invalid Product Code');
        error.status = 400;
        throw error;
      }
      orgParams.name = marketplaceCustomersData.customerId;
      orgParams.externalId = marketplaceCustomersData.customerId;
      orgParams.billingAccountId = marketplaceCustomersData.customerId;
      orgParams.licenseType = saaSProductsDetails.productName;
      orgParams.licenseCode = getEntitlements.Entitlements[0].Dimension;
      orgParams.licenseCount = saaSProductsDetails.assetCountIncluded;
      orgParams.unitCount = getEntitlements.Entitlements[0].Value.IntegerValue;
      orgParams.startDate = moment().toDate();
      orgParams.source = 'MarketPlace';
      orgParams.endDate = moment().add(3652, 'days').toDate();
    } else {
      const data = await DirectRegistrations.findOne({ where: { emailAddress: params.username, token, verified: true } });
      if (!data) {
        logger.error('Email Not Registered or Expired');
        const error = new Error('Email Not Registered or Expired');
        error.status = 400;
        throw error;
      }
      const chargeBeeData = await this.chargeBeeRegister(params);
      orgParams.name = chargeBeeData.customer.id;
      orgParams.externalId = chargeBeeData.customer.id;
      orgParams.billingAccountId = chargeBeeData.customer.id;
    }

    try {
      const org = await orgService.createOrganization(orgParams, 0, -1);
      const orgId = org.id;
      await orgService.createOrgApiKeys(orgId);
      params.password = 'T' + Math.random().toString(36).substring(2);
      await userService.createUser(params.username, params.password, params.firstName, params.lastName, 3, orgId, params, true);
      const roleParams = {
        username: params.username,
        fullname: params.firstName + ' ' + params.lastName,
        email: params.username,
        password: params.password
      };
      await kibanaUserRolesService.createUserRoles(orgId, roleParams, 'all');
      const authorizationInfoParams = {
        organization_id: orgId,
        location_id: 0,
        hosting_providers_id: 0,
        isActive: 'enabled'
      };
      await authorizationInfoService.create(authorizationInfoParams);
      await loginService.forgetPassword(params.username);
      return org;
    } catch (err) {
      logger.error({ err, stack: err.stack }, err.message || 'Registration Error');
      const error = new Error(err.message || 'Registration Error');
      error.status = 400;
      throw error;
    }
  }

  async chargeBeeRegister(params) {
    try {
      const data = await new Promise(function (resolve, reject) {
        chargebee.configure({
          site: 'caveonixabc-test',
          api_key: 'test_cuFErFilrF3GJslHJPPiBdmhRQEE26a2cu'
        });
        chargebee.subscription.create({
          plan_id: params.productCode,
          auto_collection: 'off',
          billing_address: {
            first_name: params.firstName,
            last_name: params.lastName,
            line1: '',
            city: '',
            state: '',
            zip: '',
            country: ''
          },
          customer: {
            first_name: params.firstName,
            last_name: params.lastName,
            email: params.username
          }
        }).request(function (error, result) {
          if (error) {
            reject(error);
          }
          resolve(result);
        });
      });
      return data;
    } catch (error) {
      logger.error(error);
      error.message = 'Registration Error';
      error.status = 400;
      throw error;
    }
  }

  async captchaVerify(recaptcha) {
    if (!config.reCaptcha_secret) {
      logger.error('reCaptcha_secret not defined in config file');
      const error = new Error('Invalid Captcha');
      error.status = 400;
      throw error;
    }
    const secret = await this.keyGenerator.decryptKeys(config.reCaptcha_secret);
    const response = await rp.post({ url: `https://www.google.com/recaptcha/api/siteverify?secret=${secret}&response=${recaptcha}`, json: true, rejectUnauthorized: false, resolveWithFullResponse: true });
    logger.info(response.body);
    if (response.body && response.body.success) return true;
    else {
      logger.error('Invalid Captcha');
      const error = new Error('Invalid Captcha');
      error.status = 400;
      throw error;
    }
  }
};
