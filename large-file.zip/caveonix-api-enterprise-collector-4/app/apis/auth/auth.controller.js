const { clone, get, has } = require('lodash');
const jwt = require('jsonwebtoken');
const url = require('url');

const AuthService = require('./auth.service');
const CentralCollectorClient = require('../../../utils/centralCollector.client');
const checkId = require('../../../utils/checkId');
const config = require('../../../configure').get();
const errorHandler = require('../../../utils/errorHandler');
const logger = require('../../../utils/logger').logger;
const LoginService = require('./login.service');
const LogoutService = require('./logout.service');
const passport = require('../../../config/passport.conf');
const SECRET = require('../../../utils/secret');
const Validator = require('../../../utils/validator');

const authService = new AuthService();
const loggerLabel = 'AuthController';
const loginService = new LoginService();
const logoutService = new LogoutService();
const VERSION = config.version || 'dev';

module.exports = class AuthController {
  async logoutSession(req, res) {
    const userId = req.params.userId;
    if (checkId(userId)) {
      logger.error({ userId }, 'Error with User Id');
      const error = new Error('Error with User Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const Session = await logoutService.logoutSession(userId);
      return res.json(Session);
    } catch (error) {
      logger.error('error occurred', { loggerLabel, error });
      return errorHandler(req, res, error);
    }
  }

  async login(req, res, next) {
    const action = 'Login';
    const username = get(req, 'body.username');
    const errorMessage = 'Unauthorized';
    // AD User
    logger.profile('login', { loggerLabel, action, user: username });
    let activeDirectoryUser;
    try {
      activeDirectoryUser = await new Promise((resolve, reject) => {
        passport.authenticate('custom', async (error, user, exists) => {
          error ? reject(error) : resolve(user);
        })(req, res);
      });
    } catch (error) {
      logger.error(`unable to authenticate active directory user`, { error, loggerLabel, action, user: username });
    }

    // Local User
    let localUser;
    try {
      localUser = await new Promise((resolve, reject) => {
        passport.authenticate('login', async (error, user, exists) => {
          error ? reject(error) : resolve(user);
        })(req, res);
      });
    } catch (error) {
      logger.error(`unable to authenticate local user`, { error, loggerLabel, action, user: username });
    }

    // setting the user
    const user = localUser || activeDirectoryUser;
    if (!user) {
      logger.error(`unable to authenticate user`, { loggerLabel, action, user: username });
      res.statusCode = 401;
      return res.send(errorMessage);
    }

    // creating the token
    const organizationId = has(user, 'Organization.organization_id') ? get(user, 'Organization.organization_id') : get(user, 'organization.id');
    const roleId = get(user, 'OrgMemberships[0].role_id');
    const token = jwt.sign(
      {
        id: user.id,
        organizationId,
        roleId
      },
      SECRET,
      {
        expiresIn: '12h'
      }
    );

    // Getting the License information
    const licenseInfo = { type: 'Unknown', endDate: 'N/A' };
    const refererFqdn = req.headers.referer ? url.parse(req.headers.referer).hostname.toLowerCase() : '';
    // setting up relevant information
    const userLastLoginSession = await loginService.addLoginData(user, token);
    let checkLicense, checkLicenseMessage;
    try {
      [checkLicense, checkLicenseMessage] = await CentralCollectorClient.checkLicense(token, user.id, organizationId, refererFqdn);
    } catch (error) {
      logger.error('error occurred getting license from CC', { error, loggerLabel });
    }
    // creating the base payload that all configurations are built from
    const basePayload = {
      checkLicense,
      checkLicenseMessage,
      license_expire_date: licenseInfo.endDate,
      license_type: licenseInfo.type,
      token,
      user,
      userLastLoginSession,
      version: VERSION
    };
    // Returning the appropriate information if forensics is enabled
    try {
      const payload = clone(basePayload);
      res.cookie('Authorization', get(payload, 'token'), { path: '/echelp/', httpOnly: true, secure: true });
      res.cookie('Authorization', get(payload, 'token'), { path: '/download-package/', httpOnly: true, secure: true });
      return res.json(payload);
    } catch (error) {
      return res.json(basePayload);
    }
  }

  async esAuthentication(req, res, next) {
    const sessionId = req.headers.authorization;
    if (!sessionId) {
      res.sendStatus(401);
    }
    logger.silly({ sessionId }, 'sesh');
    const exists = await loginService.checkSessionId(sessionId);
    if (!exists) {
      logger.error('cannot find session');
      return res.sendStatus(401);
    }
    logger.info({ exists }, 'does token exists');
    try {
      logger.info('sending 200');
      return res.sendStatus(200);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      logger.error('does not exist');
      return res.sendStatus(401);
    }
  }

  async checkSystem(req, res) {
    try {
      const result = await loginService.checkSystem();
      return res.json(result);
    } catch (error) {
      logger.error('Unable to check system', { error, loggerLabel });
      return errorHandler(req, res, error);
    }
  }

  async createFirstUser(req, res) {

    const { password, username, organization_id, firstName, lastName } = req.body;
    const orgId = organization_id;
    try {
      const result = await loginService.createFirstUser(username, firstName, lastName, password, orgId);
      return res.json(result);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async installLicenseAndOrg(req, res) {
    let params;
    try {
      params = JSON.parse(req.file.buffer.toString());
    } catch (error) {
      const e = new Error('Incorrect license file. Please contact your Caveonix Admin');
      e.status = 400;
      return errorHandler(req, res, e);
    }

    try {
      const result = await loginService.installLicenseAndOrganization(params);
      return res.json(result);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async forgetPassword(req, res) {
    const { username } = req.body;
    try {
      await loginService.forgetPassword(username);
      return res.status(202).json();
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async passwordResetUrl(req, res) {
    const { username } = req.body;
    try {
      const url = await loginService.passwordResetUrl(username);
      return res.json({ url });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async resetPassword(req, res) {
    const { identifier, username, password } = req.body;
    try {
      const data = await loginService.forgetPasswordResetPassword(identifier, username, password);
      return res.status(202).json();
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  /* AWS Pre Registartion */
  async preRegisterAWS(req, res) {
    const RegistrationToken = req.body['registrationToken'] || req.body['x-amzn-marketplace-token'] || req.query['x-amzn-marketplace-token'];
    if (!RegistrationToken) {
      logger.error('x-amzn-marketplace-token is missing in payload');
      const error = new Error(`Invalid Payload`);
      error.status = 400;
      return errorHandler(req, res, error, { error : error.message });
    }
    try {
      const url = await authService.preRegisterAWS(RegistrationToken);
      return res.redirect(url);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error, { error : error.message });
    }
  }

  /* Direct Pre Register Registartion */
  async preRegisterDirect(req, res) {
    const params = req.body;
    try {
      await Validator.validateParams({
        emailAddress: 'required|email',
        g_recaptcha_response: 'required|string'
      }, params);

    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    try {
      const response = await authService.preRegisterDirect(params);
      return res.json(response);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error, { error : error.message });
    }
  }

  /* Direct Pre Register Registartion */
  async directRegisterVerify(req, res) {
    const params = req.query;
    try {
      await Validator.validateParams({
        emailAddress: 'required|email',
        token: 'required|string'
      }, params);

    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    try {
      const url = await authService.directRegisterVerify(params);
      return res.redirect(url);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error, { error : error.message });
    }
  }

  async register(req, res) {
    try {
      const params = req.body;
      params.productCode = params.productCode ? params.productCode : null;
      try {
        await Validator.validateParams({
          token: 'required|string',
          source: 'required|in:direct,marketplace',
          g_recaptcha_response: 'required|string',
          company: 'required|string',
          username: 'required|email',
          phone: 'nullable',
          firstName: 'required|string',
          productCode: 'requiredIf:source,direct',
          unitCount: 'required|integer',
          lastName: 'required|string'
        }, params);

      } catch (error) {
        logger.error({ error }, 'error occurred');
        error.status = 422;
        return errorHandler(req, res, error, { validationErrors: error.validationErrors });
      }
      const data = await authService.register(params, params.token, params.source);
      return res.json(data);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error, { error : error.message });
    }
  }

  async checkMFAUser(req, res) {
    try {
      const { username } = req.body;
      const data = await loginService.checkMFAUser(username);
      return res.json(data);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error, { error : error.message });
    }
  }

};
