const Sequelize = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();

class directRegistrations extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
      emailAddress: {
        type: Sequelize.STRING,
        field: 'email_address'
      },
      token: {
        type: Sequelize.STRING,
        field: 'token'
      },
      verified: {
        type: Sequelize.BOOLEAN,
        field: 'verified'
      }
    },
    {
      sequelize,
      freezeTableName: true,
      tableName: 'direct_registrations',
      underscored: true
    });
  }

}
module.exports = directRegistrations;
