const db = require('../../models');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-logout.service'
});

module.exports = class LogoutService {
  constructor(services) {
    this.services = services;
    logger.debug('called LogoutService constructor');
  }

  async logoutSession(userId) {
    await db.UserSessionInfo.update({ isActive: false }, { where: { user_id: userId } });
    return this.getUserSessionInfo(userId);
  }

  getUserSessionInfo(userId) {
    return db.UserSessionInfo.findOne({ where: { user_id: userId }, order: [['created_at', 'DESC']] });
  }
};
