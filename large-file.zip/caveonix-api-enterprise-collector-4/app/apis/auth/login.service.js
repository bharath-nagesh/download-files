const moment = require('moment');
const Cache = require('../../../utils/cache');
const { get, has } = require('lodash');
const KeyGenerator = require('../../../utils/generateKeys');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-login.service'
});
const UserSessionInfo = require('../../models/UserSessionInfo.model');
const sequelize = require('../../../config/db.conf').getConnection();
const CaveoLicense = require('../../models/caveoLicense.model');
const User = require('../user/user.model');
const Role = require('../roles/role.model');
const Organization = require('../organization/organization.model');
const isAppliance = require('../../../utils/isAppliance');
const OrgMembers = require('../../../app/apis/organization/orgMembers.model');
const Certificates = require('../../../app/apis/certificates/certificates.model');
const ProductOfferings = require('../../../app/apis/productOfferings/product_offerings.model');
const OrgService = require('../organization/org.service');
const EmailServerService = require('../emailServer/emailServer.service');
const orgService = new OrgService();
const config = require('../../../configure').get();
const uuid = require('uuid/v4');
const emailServerService = new EmailServerService();

const loggerLabel = 'LoginService';

module.exports = class LoginService {
  constructor() {
    this.userSessions = {};
    this.keyGenerator = new KeyGenerator();
    logger.debug('called LoginService constructor');
  }

  async addLoginData(user, token) {
    const param = {
      user_id: user.id,
      session_id: token,
      organization_id: has(user, 'Organization.organization_id') ? user.Organization.organization_id : get(user, 'organization.id'),
      is_active: true
    };
    try {
      return await UserSessionInfo.create(param);
    } catch (error) {
      logger.error('unable to create user session', { error, loggerLabel });
      throw error;
    }
  }

  async getUserSessionInfo(userId) {
    return this.getUserSessionInfoLocal(userId);
  }

  async checkSessionId(sessionId) {
    const exists = await UserSessionInfo.findOne({ where: { session_id: sessionId, is_active: { $ne: 'false' } } });
    return exists != null;
  }

  async addManagedOrgs(user) {
    const userId = user.id;
    const role = user.OrgMemberships[0].Role;
    logger.silly({ user }, 'the user');
    const orgObjs = await sequelize.query('select organization_id from user_org_mappings where user_id = :userId', {
      replacements: { userId },
      type: sequelize.QueryTypes.SELECT
    });
    const orgIds = orgObjs.map(o => o.organization_id);
    let organizations = await Organization.findAll({ where: { id: orgIds } });
    organizations = organizations.map((org) => {
      const OrgMembers = {};
      OrgMembers.role_id = role.id;
      OrgMembers.organization_id = org.id;
      OrgMembers.Organization = org;
      OrgMembers.Role = role;
      return org;
    });
    user.Organizations = user.Organizations ? user.Organizations.concat(organizations) : organizations;
    user.OrgMemberships = user.OrgMemberships.concat(organizations);
    return user;
  }

  async checkSystem() {
    logger.info('checking if system is setup properly', { loggerLabel });

    const [license, userExists, org] = await Promise.all([orgService.getLicense(), this.checkUserExists(), this.getTopOrganization()]);
    if (license.length === 0) {
      const e = new Error('Missing License. Please contact Caveonix Administrator or run Post Install Script');
      e.status = 403;
      throw e;
    }
    if (!org) {
      const e = new Error('Missing Organization. Please contact Caveonix Administrator or run Post Install Script');
      e.status = 403;
      throw e;
    }
    if (!userExists) {
      return {
        name: org.name,
        orgId: org.id,
        message: 'Please Create First User',
        userExists
      };
    }
    return {
      name: org.name,
      orgId: org.id,
      message: 'System Installed Properly',
      userExists
    };
  }

  async getTopOrganization() {
    try {
      return Organization.findOne({ attributes: ['id'] });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      throw error;
    }

  }

  async checkUserExists() {
    const user = await User.findOne();
    if (user) {
      return true;
    }
    return false;
  }

  /**
  * Install caveo license from json license file
  * @param {object} params
  */
  async installLicenseAndOrganization(params) {
    const { orgId, licenseKey, licenseName, endDate } = params;

    if (endDate && moment(endDate) < moment()) {
      const e = new Error('License is expired. Please Contact Caveonix Administrator');
      e.status = 400;
      throw e;
    }

    logger.debug('Installing license and organization', { loggerLabel });
    logger.silly(`for orgId ${orgId}`, { loggerLabel });

    /* If Organizations Exists */
    if (await this.getTopOrganization()) {
      if (!await Organization.findByPk(orgId)) {
        const e = new Error('Organization does not exist');
        e.status = 400;
        throw e;
      }

      await orgService.updateOrganizationName(orgId, params);
      await CaveoLicense.update({ licenseKey, licenseName }, { where: {} });

      const licenseData = await CaveoLicense.findOne({ where: { licenseKey } });
      const orgData = await Organization.findByPk(orgId);
      return { org: orgData, license: licenseData };
    }

    /* For New Database With No Organizations */
    const org = await orgService.createFirstOrganization(orgId, params);
    let license = await CaveoLicense.findOne();
    if (license) {
      const e = new Error('License already installed. Please Contact Caveonix Administrator');
      e.status = 400;
      throw e;
    }
    license = await CaveoLicense.create({
      licenseName, licenseKey
    });
    return { org, license };
  }

  async createFirstUser(username, firstName, lastName, password, orgId = 1) {
    if (await this.checkUserExists()) {
      const error = new Error('User already exists');
      error.status = 400;
      throw error;
    }
    const user = await User.create({ username, firstName, lastName, password });
    const role = await Role.findOne();
    orgId = orgId === 0 ? orgId.toString() : orgId;
    //this change is specific to orgId 0 because sequelise does not handle primary key as 0 (INTEGER) and set value as DEFAULT in insert query i.e. 1
    //this addOrganization function does not work if orgId is 0 in the form of an Integer.
    await user.addOrganization(orgId, { through: { role_id: role.id } });
    return user;

  }

  async getAwsUserCount(orgId) {
    const awsUserCount = await sequelize.query(`select count('id') from aws_organization_users where organization_id = :orgId and is_active = 'enabled' `, {
      replacements: { orgId },
      type: sequelize.QueryTypes.SELECT
    });
    if (!awsUserCount || awsUserCount.length <= 0) return 0;
    return parseInt(awsUserCount[0].count);
  }

  async forgetPasswordQueueHandler(jobInfo) {
    logger.info({ jobInfo }, 'the job info');
    const userId = jobInfo.userId;
    const user = await User.findByPk(userId);
    user.avatarUrl = null;
    return user.save();
  }

  async forgetPassword(registeredEmail) {
    const user = await User.findOne({ where: { username: registeredEmail } });
    if (!user) {
      logger.error(`${registeredEmail} user not found`);
      return true;
    }
    const secret = uuid();
    const url = config.register_url;
    const resetPasswordText = `Please click the link to reset your password. This link is only valid for 15 minutes: ${url}/login?identifier=${secret}`;
    user.avatarUrl = secret;
    await user.save();
    const queueRegisterName = 'sendForgetPasswordEmail';
    JobManager.registerConsumer(queueRegisterName, this.forgetPasswordQueueHandler);
    JobManager.produceJob(queueRegisterName, { userId: user.id }, 900); // 15 minutes == 900
    await emailServerService.sendEmail(-1, null, 'RiskForesight Password Reset', resetPasswordText, null, user.username);

  }

  async passwordResetUrl(registeredEmail) {
    const user = await User.findOne({ where: { username: registeredEmail } });
    if (!user) {
      const e = new Error('user not found');
      e.status = 400;
      throw e;
    }
    const secret = uuid();
    const url = config.register_url;
    user.avatarUrl = secret;
    await user.save();
    return `${url}/login?identifier=${secret}`;
  }

  async forgetPasswordResetPassword(identifier, username, password) {
    const user = await User.findOne({ where: { username, avatarUrl: identifier } });
    if (!user) {
      const e = new Error('user not found');
      e.status = 400;
      throw e;
    }
    user.password = password;
    user.avatarUrl = null;
    await user.save();

  }

  async getUserSessionInfoLocal(userId) {

    let organizationInclude = [];
    if (!isAppliance()) {
      organizationInclude = [
        {
          model: Certificates,
          through: { attributes: [] }
        },
        { model: ProductOfferings, through: { attributes: [] } }];
    }

    const userOptions = {
      where: {
        id: userId,
        $or: [
          { isActive: { $eq: 'true' } },
          { isActive: { $eq: 'enabled' } }
        ]
      },
      include: [
        {
          model: OrgMembers,
          as: 'OrgMemberships',
          include: [
            {
              model: Organization,
              include: organizationInclude
            },
            {
              model: Role,
            }
          ]
        }
      ]
    };

    const user = await User.findOne(userOptions);
    let loginInfo = user.toJSON();
    delete loginInfo.password;

    // if the user role is mssp or msp their org needs to be added
    const userRole = get(user, 'OrgMemberships[0].Role.name');
    if (userRole === 'mssp_owner' || userRole === 'msp_owner') {
      loginInfo = await this.addManagedOrgs(loginInfo);
    }

    // setting up the login information for the UI
    const userOrg = get(loginInfo, 'OrgMemberships[0]');
    delete loginInfo.OrgMemberships;
    const orgChain = await Organization.getOrgChain(userOrg.Organization.id);
    loginInfo.organization = userOrg.Organization;
    loginInfo.productOfferings = get(loginInfo.organization, 'ProductOfferings');
    delete loginInfo.organization.ProductOfferings;
    loginInfo.orgChain = orgChain;
    loginInfo.certificates = get(loginInfo.organization, 'Certificates');
    delete loginInfo.organization.Certificates;

    loginInfo.role = userOrg.Role;
    delete loginInfo.role.Users;
    const sessiondata = await UserSessionInfo.findOne({
      where: {
        user_id: userId,
        organization_id: loginInfo.organization.id
      }
    });
    return { session: sessiondata, user: loginInfo };
  }

  async checkMFAUser(username) {
    const user = await User.findOne({ where: { username: username }, attributes: ['twoFactorToken'] });
    if (user && user.twoFactorToken) return { mfa: true };
    return { mfa: false };
  }

};
