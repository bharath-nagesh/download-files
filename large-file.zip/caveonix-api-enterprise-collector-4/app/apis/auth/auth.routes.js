const AuthController = require('./auth.controller');
const authController = new AuthController();
const express = require('express');
const router = express.Router({ mergeParams: true });
const multer = require('multer');
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

/**
 * @swagger
 * tags:
 *  - name: Auth
 *    description: Authorization endpoints
 * components:
 *   schemas:
 *     Auth:
 *       type: object
 *       required:
 *         - username
 *         - password
 *       properties:
 *         username:
 *           type: string
 *         password:
 *           type: string
 */

/**
 * @swagger
 *
 * /auth/login:
 *   post:
 *     tags:
 *       - Auth
 *     summary: Logs a user into the app
 *     produces:
 *       - application/json
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Auth'
 *     responses:
 *       200:
 *         description: User has been logged in
 *       401:
 *         description: unauthorized
 */
router.post('/login', authController.login);

/**
 * @swagger
 *
 * /auth/esLogin:
 *   post:
 *     tags:
 *       - Auth
 *     summary: Elastic Search login
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: header
 *         name: Authorization
 *         schema:
 *           type: string
 *         required: true
 *     responses:
 *       200:
 *         description: Logged into elastic search
 *       401:
 *         description: unauthorized
 */
router.post('/esLogin', authController.esAuthentication);

/**
 * @swagger
 *
 * /auth/logout/{userId}:
 *   post:
 *     tags:
 *       - Auth
 *     summary: Logs a user out of the app
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: userId
 *         description: The user's id.
 *         in: path
 *         required: true
 *         type: number
 *     responses:
 *       200:
 *         description: User has been logged out
 *       401:
 *         description: unauthorized
 */
router.post('/checkmfa', authController.checkMFAUser);
router.post('/forgetPassword', authController.forgetPassword);
router.post('/resetPassword', authController.resetPassword);
router.get('/checkSystem', authController.checkSystem);
router.post('/createFirstUser', authController.createFirstUser);
router.post('/install', upload.single('credentials'), authController.installLicenseAndOrg);

module.exports = router;
