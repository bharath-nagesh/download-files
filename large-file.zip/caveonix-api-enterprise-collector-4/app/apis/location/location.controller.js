const checkId = require('../../../utils/checkId');
const checkName = require('../../../utils/checkName');
const errorHandler = require('../../../utils/errorHandler');
const Validator = require('../../../utils/validator');
const LocationService = require('./location.service');
const locationService = new LocationService();
const paginate = require('../../middlewares/paginate.middleware');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-location.controller'
});
const _ = require('lodash');

module.exports = class LocationController {
  async getAllLocations(req, res) {
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    const dropdown = req.query.dropdown || false;
    try {
      const results = await locationService.getAllLocations(limit, offset, dropdown);
      const itemCount = await locationService.getAllLocationsCount();
      const pageCount = Math.ceil(itemCount / limit);
      res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        locations: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getOrgLocations(req, res) {

    const orgId = req.params.orgId;
    const filterOrgId = req.query.orgid || null;
    try {
      const locations = await locationService.getOrgLocations(orgId,filterOrgId);
      return res.json(locations);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async updateLocation(req, res) {
    const params = req.body;
    try {
      params.isActive = params.isActive ? params.isActive.toString().toLowerCase() : null;
      await Validator.validateParams({
        name: 'required|string',
        addressLine1: 'nullable',
        addressLine2: 'nullable',
        city: 'nullable',
        email: 'required|email',
        state: 'nullable',
        zip: 'nullable',
        country: 'nullable',
        isActive: 'required|in:enabled,disabled'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const locationId = req.params.locationId;
    if (checkId(locationId)) {
      logger.error({ environmentId: locationId }, 'Error with Location Id');
      const error = new Error(`Invalid Location Id: ${locationId}`);
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const location = await locationService.updateLocation(locationId, params);
      logger.info({ location });
      return res.json(location);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getLocationById(req, res) {
    const locationId = req.params.locationId;
    if (checkId(locationId)) {
      logger.error({ locationId }, 'Error with Location Id');
      const error = new Error(`Invalid Location Id: ${locationId}`);
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const location = await locationService.getLocation(locationId);
      return res.json(location);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getLocationByName(req, res) {

    const locationName = req.params.locationName;
    if (checkName(locationName)) {
      logger.error({ locationName }, 'Error with Location Name');
      const error = new Error(`Invalid Location Name: ${locationName}`);
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const location = await locationService.getLocationByName(locationName);
      return res.json(location);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getLocationByOrgId(req, res) {
    const orgId = req.params.orgId;
    try {
      const locations = await locationService.getAllLocationsByOrgId(orgId);
      return res.json(locations);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async createLocation(req, res) {
    const params = req.body;
    try {
      params.isActive = params.isActive ? params.isActive.toString().toLowerCase() : 'enabled';
      await Validator.validateParams({
        name: 'required|string',
        addressLine1: 'nullable',
        addressLine2: 'nullable',
        city: 'nullable',
        email: 'required|email',
        state: 'nullable',
        zip: 'nullable',
        country: 'nullable',
        isActive: 'required|in:enabled,disabled,true'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const orgId = req.params.orgId || req.params.serviceProviderId;
    try {
      params.organization_id = orgId;
      const location = await locationService.create(params);
      return res.json(location);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async deleteLocation(req, res) {

    const locationId = req.params.locationId;
    if (checkId(locationId)) {
      logger.error({ locationId }, 'Error with Location Id');
      const error = new Error(`Invalid Location Id: ${locationId}`);
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const update = await locationService.deleteById(locationId);
      return res.json(update);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async deleteMultipleLocation(req, res) {
    const locationId = req.query.id || '';
    if (locationId === undefined || locationId === '') {
      logger.error('Invalid location Id');
      const error = new Error('Invalid location Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const locationIdArr = locationId.split(',');
      const update = await locationService.deleteMultipleLocation(locationIdArr);
      logger.info('Deleted Multiple Locations');
      return res.json(update);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getLocationReferences(req, res) {
    const orgId = req.params.orgId || req.params.serviceProviderId;
    try {
      let locationIds = req.query.id || '';
      locationIds = locationIds.split(',');
      const locRefAssetRepo = await locationService.getLocationReferenceInAssetRepoEndpoint(locationIds, orgId);
      const locRefAuthInfo = await locationService.getLocationReferenceInAuthorizationInfo(locationIds, orgId);
      const out = _.assign({ 'locRefAssetRepo ': locRefAssetRepo }, { 'locRefAuthInfo ': locRefAuthInfo });
      return res.json(out);
    } catch (error) {
      error.status = 400;
      error.message = `Connection Failed: ${error.code || 'Unknown Failure'}`;
      return errorHandler(req, res, error);
    }
  }
};
