const Sequelize = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();

/**
 * @swagger
 * components:
 *   schemas:
 *     Location:
 *       type: object
 *       required:
 *         - name
 *         - email
 *         - isActive
 *       properties:
 *         name:
 *           type: string
 *         addressLine1:
 *           type: string
 *         addressLine2:
 *           type: string
 *         city:
 *           type: string
 *         email:
 *           type: string
 *         state:
 *           type: string
 *         zip:
 *           type: string
 *         country:
 *           type: string
 *         isActive:
 *           type: string
 * @param sequelize
 */
class Location extends Sequelize.Model {
  static init(sequelize) {
    return super.init({
      name: Sequelize.STRING,
      addressLine1: {
        type: Sequelize.STRING,
        field: 'address_line1'
      },
      addressLine2: {
        type: Sequelize.STRING,
        field: 'address_line2'
      },
      city: {
        type: Sequelize.STRING
      },
      country: {
        type: Sequelize.STRING
      },
      email: {
        type: Sequelize.STRING
      },
      state: {
        type: Sequelize.STRING
      },
      zip: {
        type: Sequelize.STRING
      },
      isActive: {
        type: Sequelize.BOOLEAN,
        field: 'is_active',
        defaultValue: true
      },
      is_active: {
        type: Sequelize.BOOLEAN,
        field: 'is_active'
      }
    },
    {
      sequelize,
      timestamps: true,
      freezeTableName: true,
      tableName: 'locations',
      underscored: true
    }
    );
  }
}

module.exports = Location;
