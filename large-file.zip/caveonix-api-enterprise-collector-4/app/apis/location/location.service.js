const AuthorizationInfo = require('../authorizationInfo/authorizationInfo.model');
const AssetRepoEndpoint = require('../assetRepoEndpoint/assetRepoEndpoint.model');
const Location = require('./location.model');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-location.service'
});
const removeSpace = require('../../../utils/checkSpaces');
const Organization = require('../organization/organization.model');
const OrgService = require('../organization/org.service');
const orgService = new OrgService();
const { QueryTypes } = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();

module.exports = class LocationService {
  constructor() {
    logger.debug('called constructor');
  }

  getLocation(locationId, opts) {
    return Location.findByPk(locationId);
  }

  async getLocationsById(locationIds, opts) {
    if (!Array.isArray(locationIds)) locationIds = [locationIds];
    return Location.findAll({ where: { id: { $in: locationIds } } });
  }

  async getOrgLocations(orgId, filterOrgId = null) {
    const orgChain = await orgService.getOrgChain(orgId);
    if(filterOrgId && !orgChain.includes(parseInt(filterOrgId))){
      const err = new Error('Unauthorized');
      err.status = 401;
      throw err;
    }
    const orgIds = filterOrgId || orgChain;
    const locationObjs = await sequelize.query('select distinct location_id from application_group_asset_view where organization_id in (:orgIds)', {
      replacements: { orgIds },
      type: QueryTypes.SELECT
    });
    const locationIds = locationObjs.map(locationObj => locationObj.location_id);
    return Location.findAll({ where: { id: { $in: locationIds } } });
  }

  getLocationByName(locationName) {
    return Location.findOne({
      where: {
        name: sequelize.where(sequelize.fn('LOWER', sequelize.col('name')), sequelize.fn('lower', locationName)),
        $or: [{ isActive: { $ne: 'false' } }]
      }
    });
  }

  getAllLocations(limit, offset, dropdown = false) {
    let condition = ['false'];
    let attributes = { exclude: [] };
    if(dropdown && dropdown === 'true') {
      condition = ['false','disabled','unmanaged'];
      attributes = ['id','name','isActive'];
    }
    return Location.findAll({
      where: { $or: [{ isActive: { $notIn: condition } }] },
      attributes,
      order: [['name', 'ASC']],
      limit: limit,
      offset: offset
    });
  }

  getAllLocationsCount() {
    return Location.count({ where: { $or: [{ isActive: { $ne: 'false' } }] } });
  }

  async getAllLocationsByOrgId(orgId, opts) {
    const authorizationInfos = await AuthorizationInfo.findAll({ where: { organization_id: orgId }, include: [{ model: Location }] });
    return authorizationInfos.map(ai => {
      return ai.Location;
    }).filter((obj, pos, arr) => {
      return arr.map(mapObj => mapObj.id).indexOf(obj.id) === pos;
    });
  }

  async updateLocation(locationId, update) {
    const name = update.name;
    const newName = removeSpace.checkMultiSpace(name);
    const exists = await this.checkNameForUpdate(newName, locationId);
    if (exists) {
      const err = new Error('Duplicate Location name.');
      err.status = 400;
      throw err;
    }
    update.name = newName;
    const location = await Location.findByPk(locationId);
    return location.update(update);
  }

  async create(params) {
    const name = params.name;
    const newName = removeSpace.checkMultiSpace(name);
    const exists = await this.checkName(newName);
    if (exists) {
      const err = new Error('Duplicate Location name.');
      err.status = 400;
      throw err;
    }
    params.name = newName;
    return Location.create(params);
  }

  checkName(name) {
    return Location.findOne({
      where: {
        name: sequelize.where(sequelize.fn('LOWER', sequelize.col('name')), sequelize.fn('lower', name)),
        $or: [{ isActive: { $ne: 'false' } }]
      }
    });
  }

  checkNameForUpdate(name, locationId) {
    return Location.findOne({
      where: {
        name: sequelize.where(sequelize.fn('LOWER', sequelize.col('name')), sequelize.fn('lower', name)),
        $or: [{ isActive: { $ne: 'false' } }],
        id: { $ne: locationId }
      }
    });
  }

  async deleteById(locationId) {
    await Location.update({ isActive: false }, { where: { id: locationId } });
    return Location.findByPk(locationId);
  }

  async deleteMultipleLocation(locationIdArr) {
    await Location.update({ isActive: false }, { where: { id: { $in: locationIdArr } } });
    return Location.findAll({ where: { id: { $in: locationIdArr } } });
  }

  getLocationReferenceInAssetRepoEndpoint(locationId, orgId) {
    return AssetRepoEndpoint.findAll({
      attributes: ['connection_name'],
      where: { location_id: locationId, organization_id: orgId, isActive: { $ne: 'false' } }
    });
  }

  getLocationReferenceInAuthorizationInfo(locationId, orgId) {
    return AuthorizationInfo.findAll({
      attributes: ['key'],
      where: { location_id: locationId, organization_id: orgId, isActive: { $ne: 'false' } },
      include: [{ model: Organization }]
    });
  }
};
