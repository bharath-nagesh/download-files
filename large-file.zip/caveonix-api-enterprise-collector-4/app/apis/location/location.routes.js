const LocationController = require('./location.controller');

/**
 * @swagger
 * tags:
 *  - name: Location
 *    description: Location endpoints
 */
module.exports = class LocationRoutes {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.locationController = new LocationController();
      this.initOrganization();
    }
  }

  initOrganization() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/location:
     *   get:
     *     tags:
     *       - Location
     *     summary: Gets a list of all organizations
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The Organization id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: location
     */
    this.router.get(`${this.path}/`, this.locationController.getAllLocations);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/location:
     *   post:
     *     tags:
     *       - Location
     *     summary: Creates a location
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The Organization id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/Location'
     *     responses:
     *       200:
     *         description: location
     *       400:
     *          description: Bad Request
     */
    this.router.post(`${this.path}/`, this.locationController.createLocation);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/location/locationReferences:
     *   get:
     *     tags:
     *       - Location
     *     summary: Gets a list of location references
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The Organization id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: locationId
     *         description: A comma delimited list of ids.
     *         in: query
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *          description: List of locations
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/references`, this.locationController.getLocationReferences);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/location/{locationId}:
     *   get:
     *     tags:
     *       - Location
     *     summary: Gets a location by it's id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The Organization id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: locationId
     *         description: The id of the specified location.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: location
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/:locationId`, this.locationController.getLocationById);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/location/Multilocation:
     *   delete:
     *     tags:
     *       - Location
     *     summary: Deletes multiple locations
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The Organization id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: locationId
     *         description: A comma delimited list of location ids.
     *         in: query
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: location
     */
    this.router.delete(`${this.path}/`, this.locationController.deleteMultipleLocation);
    /**
     * @swagger
     *
     * /api/organization/{orgId}/location/locationName/{locationName}:
     *   get:
     *     tags:
     *       - Location
     *     summary: Gets a location by name
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The Organization id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: locationName
     *         description: The name of the specified location.
     *         in: path
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: location
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/locationName/:locationName`, this.locationController.getLocationByName);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/location/{locationId}:
     *   put:
     *     tags:
     *       - Location
     *     summary: Updates a location
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The Organization id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: locationId
     *         description: The id of the specified location.
     *         in: path
     *         required: true
     *         type: string
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/Location'
     *     responses:
     *       200:
     *         description: location
     *       400:
     *          description: Bad Request
     */
    this.router.put(`${this.path}/:locationId`, this.locationController.updateLocation);

  }
};
