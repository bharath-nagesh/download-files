const KibanaUserRolesController = require('./kibanaUserRoles.controller');

/**
 * @swagger
 * tags:
 *  - name: KibanaUserRoles
 *    description: KibanaUserRoles endpoints
 *    @todo look into what this actually does
 */
module.exports = class KibanaUserRolesRouter {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.kibanaUserRolesController = new KibanaUserRolesController();

      // initializing route
      if (type === 'Service Provider') {
        this.initServiceProvider();
      } else {
        this.initOrganization();
      }
    }
  }

  /**
   * Route initialization and setup
   */
  initOrganization() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/KibanaUserRoles/{userName}:
     *   delete:
     *     tags:
     *       - KibanaUserRoles
     *     summary: Deletes a Kibana Role and its User
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: userName
     *         description: The name of the requested kibanaUserRoles.
     *         in: path
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: kibanaUserRoles
     *       401:
     *         description: unauthorized
     */
    this.router.delete(`${this.path}/:userName`, this.kibanaUserRolesController.deleteRoleAndUser);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/KibanaUserRoles/:
     *   post:
     *     tags:
     *       - KibanaUserRoles
     *     summary: Creates a Kibana user and role
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: kibanaUserRoles was created successfully
     *       401:
     *         description: unauthorized
     */
    this.router.post(`${this.path}/`, this.kibanaUserRolesController.createRoleAndUser);


  }

  /**
   * Route initialization and setup
   */
  initServiceProvider() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/KibanaUserRoles/{userName}:
     *   delete:
     *     tags:
     *       - KibanaUserRoles
     *     summary: Deletes a Kibana Role and its User
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: userName
     *         description: The name of the requested kibanaUserRoles.
     *         in: path
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: kibanaUserRoles
     *       401:
     *         description: unauthorized
     */
    this.router.delete(`${this.path}/:userName`, this.kibanaUserRolesController.deleteRoleAndUser);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/KibanaUserRoles/:
     *   post:
     *     tags:
     *       - KibanaUserRoles
     *     summary: Creates a Kibana user and role
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: kibanaUserRoles was created successfully
     *       401:
     *         description: unauthorized
     */
    this.router.post(`${this.path}/`, this.kibanaUserRolesController.createRoleAndUser);


  }
};
