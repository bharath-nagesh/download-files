const config = require('../../../configure').get();
const KeyGenerator = require('../../../utils/generateKeys');
const fs = require('fs');
let kibanaUserRolesPayload = fs.readFileSync('./utils/kibanaUserRoles.json');
kibanaUserRolesPayload = JSON.parse(kibanaUserRolesPayload);
const KibanaDashBoardService = require('../kibanaDashboard/kibanaDashBoard.service');
const KibanaMachineLearning = require('../../../app/services/kibanaMachineLearning.service');
const kibanaDashBoardService = new KibanaDashBoardService();
const kibanaMachineLearning = new KibanaMachineLearning();
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-kibanaUserRoles.service'
});
const rp = require('request-promise');
const _ = require('lodash');

module.exports = class KibanaUserRolesService {
  constructor() {
    this.keyGenerator = new KeyGenerator();
    logger.debug('called KibanaUserRoles constructor');
  }

    async createUserRoles(orgId, params, type) {
        await this.createMLRole(orgId, params, type);
        return "User and it's Roles created successfully";
    }
    async createMLRole(orgId, params, type) {
        let service = this;
        let titleLog = "caveolog-" + orgId + '*';
        let titleScan = "caveoscan-" + orgId + '*';
        let titleFlow = "caveonetwork-" + orgId + '*-flows*';
        let mlLinuxLog = ".ml-anomalies-custom-caveolinuxlog-" + orgId;
        let mlWinLog = ".ml-anomalies-custom-caveowinlog-" + orgId;
        let mlScan = ".ml-anomalies-custom-caveoscan-" + orgId;
        let mlNetwork = ".ml-anomalies-custom-caveonetwork-" + orgId;
        let roleName = 'RoleML-' + orgId;
        var auth = "";

        let newPassword = await service.keyGenerator.decryptKeys(config.es_password);
        auth = "Basic " + new Buffer(config.es_username + ":" + newPassword).toString("base64");
        let url = config.kibana_url + '/api/security/v1/roles/' + roleName;
        let newUrl = config.kibana_url + '/api/security/role/' + roleName;
        let payload = "";
        kibanaUserRolesPayload.kibanaUserRoles.RoleML[0].indices[0].names[0] = titleLog;
        kibanaUserRolesPayload.kibanaUserRoles.RoleML[0].indices[0].names[1] = titleScan;
        kibanaUserRolesPayload.kibanaUserRoles.RoleML[0].indices[0].names[2] = titleFlow;
        kibanaUserRolesPayload.kibanaUserRoles.RoleML[0].indices[0].names[3] = mlLinuxLog;
        kibanaUserRolesPayload.kibanaUserRoles.RoleML[0].indices[0].names[4] = mlWinLog;
        kibanaUserRolesPayload.kibanaUserRoles.RoleML[0].indices[0].names[5] = mlScan;
        kibanaUserRolesPayload.kibanaUserRoles.RoleML[0].indices[0].names[6] = mlNetwork;
        kibanaUserRolesPayload.kibanaUserRoles.RoleML[0].name = roleName;
        payload = kibanaUserRolesPayload.kibanaUserRoles.RoleML[0];

        let newPayload = "";
        kibanaUserRolesPayload.kibanaUserRoles.RoleML[1].elasticsearch.indices[0].names[0] = titleLog;
        kibanaUserRolesPayload.kibanaUserRoles.RoleML[1].elasticsearch.indices[0].names[1] = titleScan;
        kibanaUserRolesPayload.kibanaUserRoles.RoleML[1].elasticsearch.indices[0].names[2] = titleFlow;
        kibanaUserRolesPayload.kibanaUserRoles.RoleML[1].elasticsearch.indices[0].names[3] = mlLinuxLog;
        kibanaUserRolesPayload.kibanaUserRoles.RoleML[1].elasticsearch.indices[0].names[4] = mlWinLog;
        kibanaUserRolesPayload.kibanaUserRoles.RoleML[1].elasticsearch.indices[0].names[5] = mlScan;
        kibanaUserRolesPayload.kibanaUserRoles.RoleML[1].elasticsearch.indices[0].names[6] = mlNetwork;
        newPayload = kibanaUserRolesPayload.kibanaUserRoles.RoleML[1];

        let MLRoleData = await service.makeRequest('POST', url, payload, auth, newPassword);
        if(service.checkStatus(MLRoleData)){
            if(type != 'msp') {
                params.roleML = MLRoleData.body.name;
                service.createDashboardRole(orgId, params);
            } else{
                return roleName;
            }
        }else{
            if (MLRoleData.statusCode == 404) {
                let MLRoleData1 = await service.makeRequest('PUT', newUrl, newPayload, auth, newPassword)
                if(service.checkStatus(MLRoleData1)){
                    if(type != 'msp') {
                        params.roleML = roleName;
                        service.createDashboardRole(orgId, params);
                    } else{
                        return roleName;
                    }
                }else{
                    if(MLRoleData1.message.includes('kibana')){
                        newPayload.kibana = kibanaUserRolesPayload.kibanaUserRoles.RoleML[2].kibana;
                        let MLRoleData2 = await service.makeRequest('PUT', newUrl, newPayload, auth, newPassword);
                        if(service.checkStatus(MLRoleData2)){
                            if(type != 'msp') {
                                params.roleML = roleName;
                                service.createDashboardRole(orgId, params);
                            } else{
                                return roleName;
                            }
                        }else{
                            return service.errorHandler('Error in creating ML Role');
                        }
                    }else{
                        return service.errorHandler('Error in creating ML Role');
                    }
                }
            }else{
                return service.errorHandler('Error in creating ML Role');
            }
        }
    }
    async createDashboardRole(orgId, params, type) {
        let service = this;
        let titleLog = "caveolog-" + orgId + '*';
        let titleScan = "caveoscan-" + orgId + '*';
        let titleFlow = "caveonetwork-" + orgId + '*-flows*';
        let roleName = 'RoleDashboard-' + orgId;
        var auth = "";

        let newPassword = await service.keyGenerator.decryptKeys(config.es_password);
        auth = "Basic " + new Buffer(config.es_username + ":" + newPassword).toString("base64");
        let url = config.kibana_url + '/api/security/v1/roles/' + roleName;
        let newUrl = config.kibana_url + '/api/security/role/' + roleName;
        let payload = "";
        kibanaUserRolesPayload.kibanaUserRoles.RoleDashboard[0].indices[0].names[0] = titleLog;
        kibanaUserRolesPayload.kibanaUserRoles.RoleDashboard[0].indices[0].names[1] = titleScan;
        kibanaUserRolesPayload.kibanaUserRoles.RoleDashboard[0].indices[0].names[2] = titleFlow;
        kibanaUserRolesPayload.kibanaUserRoles.RoleDashboard[0].name = roleName;
        payload = kibanaUserRolesPayload.kibanaUserRoles.RoleDashboard[0];

        let newPayload = "";
        kibanaUserRolesPayload.kibanaUserRoles.RoleDashboard[1].elasticsearch.indices[0].names[0] = titleLog;
        kibanaUserRolesPayload.kibanaUserRoles.RoleDashboard[1].elasticsearch.indices[0].names[1] = titleScan;
        kibanaUserRolesPayload.kibanaUserRoles.RoleDashboard[1].elasticsearch.indices[0].names[2] = titleFlow;
        newPayload = kibanaUserRolesPayload.kibanaUserRoles.RoleDashboard[1];

        let DashboardRoleData = await service.makeRequest('POST', url, payload, auth, newPassword);
        if(service.checkStatus(DashboardRoleData)){
            if(type != 'msp') {
                params.roleDashboard = DashboardRoleData.body.name;
                service.createUser(params, null, type);
            } else{
                return roleName;
            }
        }else{
            if(DashboardRoleData.statusCode == 404){
                let DashboardRoleData1 = await service.makeRequest('PUT', newUrl, newPayload, auth, newPassword)
                if(service.checkStatus(DashboardRoleData1)){
                    if(type != 'msp') {
                        params.roleDashboard = roleName;
                        service.createUser(params, null, type);
                    } else{
                        return roleName;
                    }
                }else{
                    if(DashboardRoleData1.message.includes('kibana')){
                        newPayload.kibana = kibanaUserRolesPayload.kibanaUserRoles.RoleDashboard[2].kibana;
                        let DashboardRoleData2 = await service.makeRequest('PUT', newUrl, newPayload, auth, newPassword)
                        if(service.checkStatus(DashboardRoleData2)){
                            if(type != 'msp') {
                                params.roleDashboard = roleName;
                                service.createUser(params, null, type);
                            } else{
                                return roleName;
                            }
                        }else{
                            return service.errorHandler('Error in creating Dashboard Role');
                        }
                    }else{
                        return service.errorHandler('Error in creating Dashboard Role');
                    }
                }
            }else{
                return service.errorHandler('Error in creating Dashboard Role');
            }
        }
    }
    async createRolesForMspAndMsspUsers(orgIdArray, params){
        let roleArr = [];
        let type = 'msp';
        if(orgIdArray.length > 0){
            for(let o = 0; o < orgIdArray.length; o++){
                let roleML = await this.createMLRole(orgIdArray[o], params, type);
                roleArr.push(roleML);
                let roleDashboard = await this.createDashboardRole(orgIdArray[o], params, type)
                roleArr.push(roleDashboard);
            }
        }
        await this.createUser(params, roleArr, type);
    }
    async createUser(params, roleArr, type) {
        let service = this;
        var auth = "";
        let roleDashboard = params.roleDashboard;
        let roleML = params.roleML;
        let username = params.username;
        let fullname = params.fullname;
        let email = params.email;
        let password = params.password;

        let newPassword = await service.keyGenerator.decryptKeys(config.es_password);
        auth = "Basic " + new Buffer(config.es_username + ":" + newPassword).toString("base64");
        let url = config.kibana_url + '/api/security/v1/users/' + username
        let payload = "";
        kibanaUserRolesPayload.kibanaUserRoles.User[0].username = username;
        if(type != 'msp'){
            kibanaUserRolesPayload.kibanaUserRoles.User[0].roles[0] = roleML;
            kibanaUserRolesPayload.kibanaUserRoles.User[0].roles[1] = roleDashboard;
        } else{
            kibanaUserRolesPayload.kibanaUserRoles.User[0].roles = roleArr;
        }
        kibanaUserRolesPayload.kibanaUserRoles.User[0].full_name = fullname;
        kibanaUserRolesPayload.kibanaUserRoles.User[0].email = email;
        kibanaUserRolesPayload.kibanaUserRoles.User[0].password = password;
        payload = kibanaUserRolesPayload.kibanaUserRoles.User[0];
        try{
            await rp.post(url, { body: payload, headers: { 'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Authorization': auth }, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true }); 
            return 'User created successfully';
        }catch(error){
            return service.errorHandler('Error in creating user');
        }
    }
    async deleteUser(username) {
        let service = this;
        var auth = "";
        let roleML = "";
        let roleDashboard = "";

        let newPassword = await service.keyGenerator.decryptKeys(config.es_password);
        auth = "Basic " + new Buffer(config.es_username + ":" + newPassword).toString("base64");
        let url = config.kibana_url + '/api/security/v1/users/' + username;
        try{
            let getUserResponse = await rp.get(url, { headers: { 'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Authorization': auth }, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true });
            roleML = getUserResponse.body.roles[0];
            roleDashboard = getUserResponse.body.roles[1];
            try{
                await rp.delete(url, { headers: { 'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Authorization': auth }, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true });
                service.deleteRole(roleML, roleDashboard);
            }catch(error){
                return service.errorHandler('Error in deleting user'); 
            }
        }catch(error){
            return service.errorHandler('Error in getting user info to delete user'); 
        }
    }
    async deleteRole(roleML, roleDashboard) {
        var auth = "";
        let service = this;
        let result;
        let roles = new Array();
        roles.push(roleML, roleDashboard);
        let newPassword = await service.keyGenerator.decryptKeys(config.es_password);
        auth = "Basic " + new Buffer(config.es_username + ":" + newPassword).toString("base64");
        let orgId = roleDashboard.split("-")[1];
        let findAnotherUserWithSameOrg = await models.OrgMembers.findAll({where: {organization_id: orgId}});
        if(!(findAnotherUserWithSameOrg && findAnotherUserWithSameOrg.length > 0)){
            for(let ctr = 0; ctr < roles.length; ctr++){
                let oneRoleObject = roles[ctr];
                let url = config.kibana_url + '/api/security/v1/roles/' + oneRoleObject;
                try{
                    await rp.get(url, { headers: { 'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Authorization': auth }, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true });
                    try{
                        await rp.delete(url, { headers: { 'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Authorization': auth }, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true });
                        result = 'Role deleted successfully';
                    }catch(error){
                        return service.errorHandler('Error in deleting Role');
                    }
                }catch(error){
                    if(error.statusCode == 404){
                        let newUrl = config.kibana_url + '/api/security/role/' + oneRoleObject;
                        try{
                            await rp.get(newUrl, { headers: { 'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Authorization': auth }, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true });
                            try{
                                await rp.delete(newUrl, { headers: { 'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Authorization': auth }, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true });
                                result = 'Role deleted successfully';
                            }catch(error){
                                return service.errorHandler('Error in deleting Role');
                            }
                        }catch(error){
                            return service.errorHandler('Error in getting role info to delete Role');
                        }   
                    }else{
                        return service.errorHandler('Error in getting role info to delete Role');
                    }
                }
            }
            return result;
        }
    }
    async makeRequest(method, url, payloadToMakeRequest, auth, newPassword) {
      try{
        let body = await kibanaDashBoardService.kibanaUserLogin(config.es_username, newPassword);
        let sid = body[0];
        try{
          let response = await rp({ method: method, url: url, body: payloadToMakeRequest, headers: { 'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Authorization': auth, 'cookie': sid}, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true });
          return response;
        }catch(error){
          return error;
        }
      }catch(error){
         if(error.message.includes('cluster_block_exception')) {
           await kibanaMachineLearning.checkPreviledges(auth);
           let response = await rp({ method: method, url: url, body: payloadToMakeRequest, headers: { 'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Authorization': auth, 'cookie': sid}, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true });
           return response;
         }
        return error;
      }
    }

    checkStatus(response){
        if(response && (response.statusCode == 200 || response.statusCode == 202 || response.statusCode == 204)){
            return true;
        }
        return false;
    }
    errorHandler(message){
        let err = new Error(message);
        err.status = 400;
        return err;
    }
};
