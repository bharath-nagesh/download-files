const checkId = require('../../../utils/checkId');
const KibanaUserRolesService = require('./kibanaUserRoles.service');
const kibanaUserRolesService = new KibanaUserRolesService();
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-kibanaUserRoles.controller'
});

module.exports = class KibanaUserRolesController {
  async createRoleAndUser(req, res) {
    let orgId = req.params.orgId;
    let params = req.body;
    try{
      let data = await kibanaUserRolesService.createUserRoles(orgId, params);
      return res.send(data);
    }catch(error){
      return res.send(err);
    }
  }
  async deleteRoleAndUser(req, res) {
    let userName = req.params.userName;
    try{
      await kibanaUserRolesService.deleteUser(userName);
      return res.send('User deleted successfully');
    }catch(error){
      return res.send(err);
    }
  }
}
