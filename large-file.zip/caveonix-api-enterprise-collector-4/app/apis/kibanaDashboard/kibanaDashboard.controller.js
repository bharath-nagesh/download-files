const checkId = require('../../../utils/checkId');
const errorHandler = require('../../../utils/errorHandler');
const KibanaDashboardService = require('./kibanaDashBoard.service');
const kibanaDashboardService = new KibanaDashboardService();
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-kibanaDashboard.controller'
});
const NetworkFlowService = require('../networkFlow/networkFlow.service');
const networkFlowService = new NetworkFlowService();

module.exports = class ForensicsDashboardController {
  async createDashboard(req, res) {
    let orgId = req.params.orgId
    try{
      let data = await kibanaDashboardService.createDashboard(orgId);
      return res.send(data);
    }catch(error){
      return res.send(error);
    }
  }
  async getForensicsDashboardUrl(req,res){
    let orgId = req.params.orgId
    let sid = req.query.cookie
    try{
      let data = await kibanaDashboardService.getDashBoard(orgId, sid);
      return res.send(data);
    }catch(error){
      return res.send(error);
    }
  }
  async deleteForensicsDashboard(req,res){
    let orgId = req.params.orgId
    let sid = req.query.cookie
    try{
      let data = await kibanaDashboardService.deleteDashboard(orgId, sid);
      return res.send(data);
    }catch(error){
      return res.send(error);
    }
  }
  async kibanaLogin(req,res){
    let username = req.body.username
    let password = req.body.password
    try{
      let data = await kibanaDashboardService.kibanaUserLogin(username, password);
      return res.send(data);
    }catch(error){
      return res.send(error);
    }
  }

  async caveoScanLogs(req, res) {
    const orgId = req.params.orgId;
    const username = req.user.username;
    const password = req.user.password;
    const cookie = req.body.cookie;
    const refresh_token = req.body.refresh_token;
    const authToken = req.headers.es_token;
    const bearerToken = req.authInfo;
    const searchParams = req.body.q;
    const namedParams = req.body.namedParams;
    const offset = req.body.offset;
    if (namedParams && searchParams) {
      const error = new Error('cannot use both search and filters at same time');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    const data = await networkFlowService.caveoScanLogs(orgId, username, password, searchParams, namedParams, offset, cookie, refresh_token, bearerToken, authToken);
    res.json(data);
  }

  async caveoFlowLogs(req, res) {
    const orgId = req.params.orgId;
    const username = req.user.username;
    const password = req.user.password;
    const cookie = req.body.cookie;
    const refresh_token = req.body.refresh_token;
    const authToken = req.headers.es_token;
    const bearerToken = req.authInfo;
    const searchParams = req.body.q;
    const namedParams = req.body.namedParams;
    const offset = req.body.offset;
    if (namedParams && searchParams) {
      const error = new Error('cannot use both search and filters at same time');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    const data = await networkFlowService.caveoFlowLogs(orgId, username, password, searchParams, namedParams, offset, cookie, refresh_token, bearerToken, authToken);
    res.json(data);
  }

  async caveoLogs(req, res) {
    const orgId = req.params.orgId;
    const username = req.user.username;
    const password = req.user.password;
    const cookie = req.body.cookie;
    const refresh_token = req.body.refresh_token;
    const authToken = req.headers.es_token;
    const bearerToken = req.authInfo;
    const searchParams = req.body.q;
    const namedParams = req.body.namedParams;
    const offset = req.body.offset;
    if (namedParams && searchParams) {
      const error = new Error('cannot use both search and filters at same time');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    const data = await networkFlowService.caveoLogs(orgId, username, password, searchParams, namedParams, offset, cookie, refresh_token, bearerToken, authToken);
    res.json(data);
  }

  async caveoFlowEventTrend(req, res) {
    const orgId = req.params.orgId;
    const username = req.user.username;
    const password = req.user.password;
    const cookie = req.body.cookie;
    const refresh_token = req.body.refresh_token;
    const authToken = req.headers.es_token;
    const bearerToken = req.authInfo;

    const data = await networkFlowService.caveoFlowEventTrend(orgId, username, password, cookie, refresh_token, bearerToken, authToken);
    res.json(data);
  }

  async caveoScanEventTrend(req, res) {
    const orgId = req.params.orgId;
    const username = req.user.username;
    const password = req.user.password;
    const cookie = req.body.cookie;
    const refresh_token = req.body.refresh_token;
    const authToken = req.headers.es_token;
    const bearerToken = req.authInfo;
    const data = await networkFlowService.caveoScanEventTrend(orgId, username, password, cookie, refresh_token, bearerToken, authToken);
    res.json(data);
  }

  async caveoEventTrend(req, res) {
    const orgId = req.params.orgId;
    const username = req.user.username;
    const password = req.user.password;
    const cookie = req.body.cookie;
    const refresh_token = req.body.refresh_token;
    const authToken = req.headers.es_token;
    const bearerToken = req.authInfo;
    const data = await networkFlowService.caveoEventTrend(orgId, username, password, cookie, refresh_token, bearerToken, authToken);
    res.json(data);
  }
};
