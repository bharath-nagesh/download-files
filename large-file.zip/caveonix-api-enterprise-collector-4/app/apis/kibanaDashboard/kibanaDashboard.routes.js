const ForensicsDashboardController = require('./kibanaDashboard.controller');

/**
 * @swagger
 * tags:
 *  - name: ForensicsDashboard
 *    description: Forensics Dashboard endpoints
 * components:
 *   schemas:
 *     ForensicsDashboard:
 *       type: object
 *       required:
 *         - username
 *         - password
 *       properties:
 *         username:
 *           type: string
 *         password:
 *           type: string
 */
module.exports = class ForensicsDashboardRoutes {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.forensicsDashboardController = new ForensicsDashboardController();

      // initializing route
      if (type === 'Service Provider') {
        this.initServiceProvider();
      } else {
        this.initOrganization();
      }
    }
  }

  initOrganization() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/ForensicsDashboard:
     *   post:
     *     tags:
     *       - ForensicsDashboard
     *     summary: Creates a Forensics Dashboard
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/ForensicsDashboard'
     *     responses:
     *       200:
     *         description: forensicsDashboard
     */
    this.router.post(`${this.path}/`, this.forensicsDashboardController.createDashboard);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/ForensicsDashboard:
     *   get:
     *     tags:
     *       - ForensicsDashboard
     *     summary: Gets a list of Forensics Dashboards
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of forensics Dashboards
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/`, this.forensicsDashboardController.getForensicsDashboardUrl);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/ForensicsDashboard:
     *   delete:
     *     tags:
     *       - ForensicsDashboard
     *     summary: Deletes a Forensics Dashboard
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: forensicsDashboardId
     *         description: The id of the specified Forensics Dashboard.
     *         in: path
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: forensicsDashboard
     */
    this.router.delete(`${this.path}/`, this.forensicsDashboardController.deleteForensicsDashboard);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/ForensicsDashboard/caveoLogs:
     *   post:
     *     tags:
     *       - ForensicsDashboard
     *     summary: Gets the Caveo Logs
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/ForensicsDashboard'
     *     responses:
     *       200:
     *         description: forensicsDashboard
     */
    this.router.post(`${this.path}/caveoLogs`, this.forensicsDashboardController.caveoLogs);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/ForensicsDashboard/caveoFlowLogs:
     *   post:
     *     tags:
     *       - ForensicsDashboard
     *     summary: Gets the Caveo Flow Logs
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/ForensicsDashboard'
     *     responses:
     *       200:
     *         description: forensicsDashboard
     */
    this.router.post(`${this.path}/caveoFlowLogs`, this.forensicsDashboardController.caveoFlowLogs);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/ForensicsDashboard/caveoScanLogs:
     *   post:
     *     tags:
     *       - ForensicsDashboard
     *     summary: Gets the Caveo Scan Logs
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/ForensicsDashboard'
     *     responses:
     *       200:
     *         description: forensicsDashboard
     */
    this.router.post(`${this.path}/caveoScanLogs`, this.forensicsDashboardController.caveoScanLogs);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/ForensicsDashboard/caveoEventTrend:
     *   post:
     *     tags:
     *       - ForensicsDashboard
     *     summary: Gets the Caveo Event trend
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/ForensicsDashboard'
     *     responses:
     *       200:
     *         description: forensicsDashboard
     */
    this.router.post(`${this.path}/caveoEventTrend`, this.forensicsDashboardController.caveoEventTrend);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/ForensicsDashboard/caveoFlowEventTrend:
     *   post:
     *     tags:
     *       - ForensicsDashboard
     *     summary: Gets the Caveo Flow Event trend
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/ForensicsDashboard'
     *     responses:
     *       200:
     *         description: forensicsDashboard
     */
    this.router.post(`${this.path}/caveoFlowEventTrend`, this.forensicsDashboardController.caveoFlowEventTrend);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/ForensicsDashboard/caveoScanEventTrend:
     *   post:
     *     tags:
     *       - ForensicsDashboard
     *     summary: Gets the Caveo Scan Event trend
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/ForensicsDashboard'
     *     responses:
     *       200:
     *         description: forensicsDashboard
     */
    this.router.post(`${this.path}/caveoScanEventTrend`, this.forensicsDashboardController.caveoScanEventTrend);


  }

  initServiceProvider() {
    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/ForensicsDashboard:
     *   get:
     *     tags:
     *       - ForensicsDashboard
     *     summary: Gets a list of forensics dashboard urls
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: ForensicsDashboard
     */
    this.router.get(`${this.path}/`, this.forensicsDashboardController.getForensicsDashboardUrl);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/ForensicsDashboard:
     *   post:
     *     tags:
     *       - ForensicsDashboard
     *     summary: Creates a dashboard
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/ForensicsDashboard'
     *     responses:
     *       200:
     *         description: Forensics Dashboard
     *       400:
     *          description: Bad Request
     */
    this.router.post(`${this.path}`, this.forensicsDashboardController.createDashBoard);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/ForensicsDashboard/:
     *   delete:
     *     tags:
     *       - ForensicsDashboard
     *     summary: Deletes a Forensics Dashboard
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: forensicsDashboardId
     *         description: The id of the specified Forensics Dashboard.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: Forensics Dashboard
     *       400:
     *          description: Bad Request
     */
    this.router.delete(`${this.path}/:forensicsDashboardId`, this.forensicsDashboardController.deleteForensicsDashboard);


  }
};
