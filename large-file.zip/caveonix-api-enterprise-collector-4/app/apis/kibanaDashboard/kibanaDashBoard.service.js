let auth = '';
const config = require('../../../configure').get();
let cookie = '';
const fs = require('fs');
let dashboard = fs.readFileSync('./utils/forensicDashboard.json');
dashboard = JSON.parse(dashboard);
let KibanaMachineLearningService = require('../../services/kibanaMachineLearning.service');
let kibanaMachineLearningService = new KibanaMachineLearningService();
const dashBoardArr = [];
const indexPatternArr = [];
const sequelize = require('../../../config/db.conf').getConnection();
const KeyGenerator = require('../../../utils/generateKeys');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-kibanaDashBoard.service'
});
const ForensicsDashboard = require('../../models/forensicsDashboard.model');
const request = require('request');
const rp = require('request-promise');
const searchArr = [];
const uuidv4 = require('uuid/v4');
const visualizationArr = [];
const _ = require('lodash');

module.exports = class KibanaDashboardService {
  constructor() {
    this.keyGenerator = new KeyGenerator();
    logger.debug('called constructor');
  }
  async createDashboard(orgId) {
    let result = await this.createIndexPattern(orgId);
    return result;
  }
  async createIndexPattern(orgId) {
    let service = this;
    let titleLog = "caveolog-" + orgId + "*"
    let titleScan = "caveoscan-" + orgId + "*"
    let titleFlow = "caveonetwork-" + orgId + "*-flows*"

    let urlLog = config.kibana_url + '/api/saved_objects/index-pattern/' + uuidv4()
    let urlScan = config.kibana_url + '/api/saved_objects/index-pattern/' + uuidv4()
    let urlFlow = config.kibana_url + '/api/saved_objects/index-pattern/' + uuidv4()

    let newPassword = await service.keyGenerator.decryptKeys(config.es_password);
    auth = "Basic " + new Buffer(config.es_username + ":" + newPassword).toString("base64");
    let urlArr = new Array()
    urlArr.push(urlLog, urlScan, urlFlow)

    for(let ctr=0; ctr<urlArr.length; ctr++){
      let object = urlArr[ctr];
      let payload = ""
      if (object === urlLog) {
        dashboard.forensicDashboard.Indexes[2].attributes.title = titleLog
        payload = dashboard.forensicDashboard.Indexes[2]
      } else if (object === urlScan) {
        dashboard.forensicDashboard.Indexes[0].attributes.title = titleScan
        payload = dashboard.forensicDashboard.Indexes[0]
      } else {
        dashboard.forensicDashboard.Indexes[1].attributes.title = titleFlow
        payload = dashboard.forensicDashboard.Indexes[1]
      }

      try{
        let response = await rp.post({url: object, body: payload, headers : {'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Authorization': auth}, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true});
        if (response.body.attributes.title == titleLog) {
          indexPatternArr.push({ "Logs": response.body.id })
        } else if (response.body.attributes.title == titleScan) {
          indexPatternArr.push({ "Scan": response.body.id })
        } else {
          indexPatternArr.push({ "Flows": response.body.id })
        }
      }catch(error){
        if (error.statusCode == 404) {
          return service.createIndexPatternForNewKibanaVersion(orgId);
        }else{
          return service.errorHandler('Error in index pattern creation');
        }
      }
    }
    if(indexPatternArr.length == 3) {
      return service.createDefaultIndexPattern(orgId);
    }else{
      return service.errorHandler('Error in index pattern creation');
    }
  }
  async createDefaultIndexPattern(orgId) {
    let service = this

    let url = config.kibana_url + '/api/kibana/settings/defaultIndex'

    let Logs = ""
    indexPatternArr.filter(function (object) {
      if (object.Logs) {
        Logs = object.Logs
      }
    })

    try{
      await rp.post(url, {body: {'value': Logs}, headers : {'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Authorization': auth}, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true});
      return service.createVisualization(orgId);
    }catch(error){
      return service.errorHandler('Error in creating default index pattern');
    }
  }
  async createVisualization(orgId) {
    let service = this;
    let dis = "Tenant-" + orgId
    let url = config.kibana_url + '/api/saved_objects/visualization'

    let Logs = ""
    let Scan = ""
    let Flows = ""
    indexPatternArr.filter(function (object) {
      if (object.Logs) {
        Logs = object.Logs
      } else if (object.Scan) {
        Scan = object.Scan
      } else {
        Flows = object.Flows
      }
    });

    let typeArr = new Array()
    typeArr.push('log', 'scan', 'flow')

    let payloadVisualization = new Array()
    typeArr.forEach(function (object) {
      var payload_Configuration_Check = ''
      var payload_Network_Flow = ''
      var payload_Events = ''
      if (object === 'scan') {
        payload_Configuration_Check = dashboard.forensicDashboard.visualization[0]
        let obj = JSON.parse(payload_Configuration_Check.attributes.kibanaSavedObjectMeta.searchSourceJSON)
        obj.index = Scan
        let jsonString = JSON.stringify(obj)
        payload_Configuration_Check.attributes.kibanaSavedObjectMeta.searchSourceJSON = jsonString
        payload_Configuration_Check.attributes.description = dis

        payloadVisualization.push(payload_Configuration_Check)
      } else if (object === 'flow') {
        payload_Network_Flow = dashboard.forensicDashboard.visualization[2]
        let obj = JSON.parse(payload_Network_Flow.attributes.kibanaSavedObjectMeta.searchSourceJSON)
        obj.index = Flows
        let jsonString = JSON.stringify(obj)
        payload_Network_Flow.attributes.kibanaSavedObjectMeta.searchSourceJSON = jsonString
        payload_Network_Flow.attributes.description = dis

        payloadVisualization.push(payload_Network_Flow)
      } else {
        payload_Events = dashboard.forensicDashboard.visualization[4]
        let obj = JSON.parse(payload_Events.attributes.kibanaSavedObjectMeta.searchSourceJSON)
        obj.index = Logs
        let jsonString = JSON.stringify(obj)
        payload_Events.attributes.kibanaSavedObjectMeta.searchSourceJSON = jsonString
        payload_Events.attributes.description = dis

        payloadVisualization.push(payload_Events)
      }
    })
    for(let p=0; p<payloadVisualization.length; p++){
      let payload = payloadVisualization[p];
      try{
        let response = await rp.post(url, {body: payload, headers : {'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Authorization': auth}, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true});
        if (response.body.attributes.title == 'Configuration Check') {
          visualizationArr.push({ 'Configuration_Check': response.body.id })
        } else if (response.body.attributes.title == 'Network Flow') {
          visualizationArr.push({ 'Network_Flow': response.body.id })
        } else {
          visualizationArr.push({ 'Events': response.body.id })
        }
      }catch(error){
        return service.errorHandler('Error in creating visualization');
      }
    }
    if(visualizationArr.length == 3) {
      return service.createSearch(orgId);
    }else{
      return service.errorHandler('Error in creating visualization');
    }
  }
  async createSearch(orgId) {
    let service = this;
    let dis = "Tenant-" + orgId

    let url = config.kibana_url + '/api/saved_objects/search'

    let Logs = ""
    let Scan = ""
    let Flows = ""
    indexPatternArr.filter(function (object) {
      if (object.Logs) {
        Logs = object.Logs
      } else if (object.Scan) {
        Scan = object.Scan
      } else {
        Flows = object.Flows
      }
    })

    let typeArr = new Array()
    typeArr.push('log', 'scan', 'flow')

    let payloadSearch = new Array()
    typeArr.forEach(function (object) {
      var payload_Scan_search = ""
      var payload_Flows_Search = ""
      var payload_Log_Search = ""
      if (object === 'scan') {
        payload_Scan_search = dashboard.forensicDashboard.visualization[1]
        let obj = JSON.parse(payload_Scan_search.attributes.kibanaSavedObjectMeta.searchSourceJSON)
        obj.index = Scan
        let jsonString = JSON.stringify(obj)
        payload_Scan_search.attributes.kibanaSavedObjectMeta.searchSourceJSON = jsonString
        payload_Scan_search.attributes.description = dis

        payloadSearch.push(payload_Scan_search)
      } else if (object === 'flow') {
        payload_Flows_Search = dashboard.forensicDashboard.visualization[3]
        let obj = JSON.parse(payload_Flows_Search.attributes.kibanaSavedObjectMeta.searchSourceJSON)
        obj.index = Flows
        let jsonString = JSON.stringify(obj)
        payload_Flows_Search.attributes.kibanaSavedObjectMeta.searchSourceJSON = jsonString
        payload_Flows_Search.attributes.description = dis

        payloadSearch.push(payload_Flows_Search)
      } else {
        payload_Log_Search = dashboard.forensicDashboard.visualization[5]
        let obj = JSON.parse(payload_Log_Search.attributes.kibanaSavedObjectMeta.searchSourceJSON)
        obj.index = Logs
        let jsonString = JSON.stringify(obj)
        payload_Log_Search.attributes.kibanaSavedObjectMeta.searchSourceJSON = jsonString
        payload_Log_Search.attributes.description = dis

        payloadSearch.push(payload_Log_Search)
      }
    })
    for(let s=0; s<payloadSearch.length; s++){
      let payload = payloadSearch[s];
      try{
        let response = await rp.post(url, {body: payload, headers : {'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Authorization': auth}, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true});
        if (response.body.attributes.title == 'Log Search') {
          searchArr.push({ 'Log_Search': response.body.id })
        } else if (response.body.attributes.title == 'Flows Search') {
          searchArr.push({ 'Flows_Search': response.body.id })
        } else {
          searchArr.push({ 'Scan_search': response.body.id })
        }
      }catch(error){
        return service.errorHandler('Error in creating search');
      }
    }
    if(searchArr.length == 3) {
      return service.createDashBoard(orgId);
    }else{
      return service.errorHandler('Error in creating search');
    }
  }
  async createDashBoard(orgId) {
    let service = this;
    let titleLog = "CaveoLogs-Dashboard-" + orgId
    let titleScan = "CaveoScan-Dashboard-" + orgId
    let titleFlow = "CaveoNetwork-Dashboard-" + orgId

    let dis = "Tenant-" + orgId

    let Configuration_Check = ""
    let Network_Flow = ""
    let Events = ""
    let Log_Search = ""
    let Flows_Search = ""
    let Scan_search = ""
    visualizationArr.filter(function (object) {
      if (object.Configuration_Check) {
        Configuration_Check = object.Configuration_Check
      } else if (object.Network_Flow) {
        Network_Flow = object.Network_Flow
      } else {
        Events = object.Events
      }
    })
    searchArr.filter(function (object) {
      if (object.Log_Search) {
        Log_Search = object.Log_Search
      } else if (object.Flows_Search) {
        Flows_Search = object.Flows_Search
      } else {
        Scan_search = object.Scan_search
      }
    })
    let url = config.kibana_url + '/api/saved_objects/dashboard'

    let typeArr = new Array()
    typeArr.push('log', 'scan', 'flow')

    let payloadArr = new Array()
    typeArr.forEach(function (object) {
      var payloadLog = ""
      var payloadScan = ""
      var payloadFlow = ""
      if (object === 'scan') {
        payloadScan = dashboard.forensicDashboard.Dashboard[0]
        let obj = JSON.parse(payloadScan.attributes.panelsJSON)
        obj[0].id = Configuration_Check
        obj[1].id = Scan_search
        let jsonString = JSON.stringify(obj)
        payloadScan.attributes.panelsJSON = jsonString
        payloadScan.attributes.description = dis
        payloadScan.attributes.title = titleScan

        payloadArr.push(payloadScan)
      } else if (object === 'flow') {
        payloadFlow = dashboard.forensicDashboard.Dashboard[1]
        let obj = JSON.parse(payloadFlow.attributes.panelsJSON)
        obj[0].id = Network_Flow
        obj[1].id = Flows_Search
        let jsonString = JSON.stringify(obj)
        payloadFlow.attributes.panelsJSON = jsonString
        payloadFlow.attributes.description = dis
        payloadFlow.attributes.title = titleFlow

        payloadArr.push(payloadFlow)
      } else {
        payloadLog = dashboard.forensicDashboard.Dashboard[2]
        let obj = JSON.parse(payloadLog.attributes.panelsJSON)
        obj[0].id = Log_Search
        obj[1].id = Events
        let jsonString = JSON.stringify(obj)
        payloadLog.attributes.panelsJSON = jsonString
        payloadLog.attributes.description = dis
        payloadLog.attributes.title = titleLog

        payloadArr.push(payloadLog)
      }
    })
    for(let d=0; d<payloadArr.length; d++){
      let payload = payloadArr[d];
      try{
        let response = await rp.post(url, {body: payload, headers : {'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Authorization': auth}, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true});
        if (response.body.attributes.title == titleLog) {
          dashBoardArr.push({ "Log_Dashboard": response.body.id })
        } else if (response.body.attributes.title == titleScan) {
          dashBoardArr.push({ "Scan_Dashboard": response.body.id })
        } else {
          dashBoardArr.push({ "Flows_Dashboard": response.body.id })
        }
      }catch(error){
        return service.errorHandler('Error in creating dashboard');
      }
    }
    if(dashBoardArr.length == 3) {
      return service.createIframeUrl(orgId);
    }else{
      return service.errorHandler('Error in creating dashboard');
    }
  }
  async createIframeUrl(orgId) {
    let dis = "Tenant-" + orgId
    let service = this
    let titleLog = "CaveoLogs-Dashboard-" + orgId
    let titleScan = "CaveoScan-Dashboard-" + orgId
    let titleFlow = "CaveoNetwork-Dashboard-" + orgId

    let indexPatternLog = "caveolog-" + orgId + "*"
    let indexPatternScan = "caveoscan-" + orgId + "*"
    let indexPatternFlow = "caveonetwork-" + orgId + "*"

    let typeArr = new Array()
    typeArr.push('logs', 'scan', 'flows')

    let Configuration_Check = ""
    let Network_Flow = ""
    let Events = ""
    let Log_Search = ""
    let Flows_Search = ""
    let Scan_search = ""
    let Log_Dashboard = ""
    let Scan_Dashboard = ""
    let Flows_Dashboard = ""
    visualizationArr.filter(function (object) {
      if (object.Configuration_Check) {
        Configuration_Check = object.Configuration_Check
      } else if (object.Network_Flow) {
        Network_Flow = object.Network_Flow
      } else {
        Events = object.Events
      }
    })
    searchArr.filter(function (object) {
      if (object.Log_Search) {
        Log_Search = object.Log_Search
      } else if (object.Flows_Search) {
        Flows_Search = object.Flows_Search
      } else {
        Scan_search = object.Scan_search
      }
    })
    dashBoardArr.filter(function (object) {
      if (object.Log_Dashboard) {
        Log_Dashboard = object.Log_Dashboard
      } else if (object.Scan_Dashboard) {
        Scan_Dashboard = object.Scan_Dashboard
      } else {
        Flows_Dashboard = object.Flows_Dashboard
      }
    })

    let timeframe = ""
    if (config.Forensics_Timeframe) {
      timeframe = config.Forensics_Timeframe
    } else {
      timeframe = '30d'
    }
    let iframeLog = '<iframe src="kibanaUrl/app/kibana#/dashboard/' + Log_Dashboard + '?embed=true&_g=(refreshInterval:(display:Off,pause:!f,value:0),time:(from:now-' + timeframe + ',mode:quick,to:now))&_a=(description:' + dis + ',filters:!(),fullScreenMode:!f,options:(darkTheme:!f,hidePanelTitles:!f,useMargins:!t),panels:!((gridData:(h:3,i:' + "'1'" + ',w:12,x:0,y:0),id:' + "'" + Events + "'" + ',panelIndex:' + "'1'" + ',type:visualization,version:' + "'6.1.3'" + '),(gridData:(h:5,i:' + "'2'" + ',w:12,x:0,y:3),id:' + "'" + Log_Search + "'" + ',panelIndex:' + "'2'" + ',type:search,version:' + "'6.1.3'" + ')),query:(language:lucene,query:\'\'),timeRestore:!t,title:' + titleLog + ',viewMode:view)" height="600" width="800"></iframe>'
    let iframeScan = '<iframe src="kibanaUrl/app/kibana#/dashboard/' + Scan_Dashboard + '?embed=true&_g=(refreshInterval:(display:Off,pause:!f,value:0),time:(from:now-' + timeframe + ',mode:quick,to:now))&_a=(description:' + dis + ',filters:!(),fullScreenMode:!f,options:(darkTheme:!f,hidePanelTitles:!f,useMargins:!t),panels:!((gridData:(h:3,i:' + "'1'" + ',w:12,x:0,y:0),id:' + "'" + Configuration_Check + "'" + ',panelIndex:' + "'1'" + ',type:visualization,version:' + "'6.1.3'" + '),(gridData:(h:5,i:' + "'2'" + ',w:12,x:0,y:3),id:' + "'" + Scan_search + "'" + ',panelIndex:' + "'2'" + ',type:search,version:' + "'6.1.3'" + ')),query:(language:lucene,query:\'\'),timeRestore:!t,title:' + titleScan + ',viewMode:view)" height="600" width="800"></iframe>'
    let iframeFlow = '<iframe src="kibanaUrl/app/kibana#/dashboard/' + Flows_Dashboard + '?embed=true&_g=(refreshInterval:(display:Off,pause:!f,value:0),time:(from:now-' + timeframe + ',mode:quick,to:now))&_a=(description:' + dis + ',filters:!(),fullScreenMode:!f,options:(darkTheme:!f,hidePanelTitles:!f,useMargins:!t),panels:!((gridData:(h:3,i:' + "'1'" + ',w:12,x:0,y:0),id:' + "'" + Network_Flow + "'" + ',panelIndex:' + "'1'" + ',type:visualization,version:' + "'6.1.3'" + '),(gridData:(h:5,i:' + "'2'" + ',w:12,x:0,y:3),id:' + "'" + Flows_Search + "'" + ',panelIndex:' + "'2'" + ',type:search,version:' + "'6.1.3'" + ')),query:(language:lucene,query:\'\'),timeRestore:!t,title:' + titleFlow + ',viewMode:view)" height="600" width="800"></iframe>'

    await sequelize.query('insert into forensics_dashboard(index_pattern, organization_id, type, dashboard_url, widget, is_active, created_at) values ($1,$2,$3,$4,$5,$6, now())', {
      bind: [indexPatternLog, orgId, typeArr[0], iframeLog, Log_Dashboard, 'true']});
    await sequelize.query('insert into forensics_dashboard(index_pattern, organization_id, type, dashboard_url, widget, is_active, created_at) values ($1,$2,$3,$4,$5,$6, now())', {
        bind: [indexPatternScan, orgId, typeArr[1], iframeScan, Scan_Dashboard, 'true']});
    await sequelize.query('insert into forensics_dashboard(index_pattern, organization_id, type, dashboard_url, widget, is_active, created_at) values ($1,$2,$3,$4,$5,$6, now())', {
        bind: [indexPatternFlow, orgId, typeArr[2], iframeFlow, Flows_Dashboard, 'true']});
    let result = await service.getFields(orgId, cookie)
    let finalData = await service.updateIndexPatternFields(orgId, null, indexPatternArr, result, auth)
    indexPatternArr.length = 0
    visualizationArr.length = 0
    searchArr.length = 0
    dashBoardArr.length = 0
    let response = finalData;
    try{
      let data = await kibanaMachineLearningService.getLinuxLogJob(orgId, cookie, finalData);
      if(data){
        try{
          await kibanaMachineLearningService.updateJob(orgId, auth, finalData);
          return response;
        }catch(error){
          await kibanaMachineLearningService.deleteDataFeed(orgId, cookie, auth, finalData);
          return response;
        }
      }
    }catch(error){
      return response;
    }
  }
  async getDashBoard(orgId, sid) {
    let service = this

    if(config.forensics_enabled  == true && config.ml_enabled == false){
      sid = '';
    }
    cookie = sid

    let LogDashBoard = 'null'
    let ScanDashboard = 'null'
    let NetworkDashboard = 'null'
    let dashBoardResponse = new Array()

    logger.info('Kibana Url' + config.kibana_url)
    let data = await ForensicsDashboard.findAll({ where: { organization_id: orgId, type: { $ne: 'machine_learning' } }});
    let newPassword = await service.keyGenerator.decryptKeys(config.es_password);
    auth = "Basic " + new Buffer(config.es_username + ":" + newPassword).toString("base64")
    data.filter(object => {
      if (object.type == 'logs') {
        LogDashBoard = object.widget
      } else if (object.type == 'scan') {
        ScanDashboard = object.widget
      } else {
        NetworkDashboard = object.widget
      }
    })
    let urls = [
      config.kibana_url + '/api/saved_objects/dashboard/' + LogDashBoard,
      config.kibana_url + '/api/saved_objects/dashboard/' + ScanDashboard,
      config.kibana_url + '/api/saved_objects/dashboard/' + NetworkDashboard
    ]
    logger.info('LogDashboard Url' + urls[0])
    logger.info('ScanDashboard Url' + urls[1])
    logger.info('NetworkDashboard Url' + urls[2])
    let previledgeCheck = await kibanaMachineLearningService.checkPreviledges(auth);
    if(previledgeCheck) {
      for(let ctr = 0; ctr< urls.length; ctr++){
        let url = urls[ctr];
        try{
          let response = await rp.get(url, {headers : {'kbn-xsrf': 'anything', 'Cookie': sid}, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true});
          dashBoardResponse.push(response.body);
        }catch(error){
          ctr = urls.length;
          return service.deleteDashboard(orgId, sid);
        }
      }
      if(dashBoardResponse.length == 3){
        return service.getVisualization(orgId, dashBoardResponse, sid)
      }else{
        return service.deleteDashboard(orgId, sid)
      }
    } else {
      return service.errorHandler("Error in changing index previledges.");
    }
  }
  async getVisualization(orgId, responseArray, sid) {
    let service = this
    let LogVisualization = 'null'
    let ScanVisualization = 'null'
    let NetworkVisualization = 'null'
    let visualizationResponse = new Array()

    responseArray.filter(function (object) {
      let jsonObject = JSON.parse(object.attributes.panelsJSON)
      if (object.attributes.title == 'CaveoLogs-Dashboard-' + orgId) {
        LogVisualization = jsonObject[1].id
      } else if (object.attributes.title == 'CaveoScan-Dashboard-' + orgId) {
        ScanVisualization = jsonObject[0].id
      } else {
        NetworkVisualization = jsonObject[0].id
      }
    })
    let visualizationUrlArray = [
      config.kibana_url + '/api/saved_objects/visualization/' + LogVisualization,
      config.kibana_url + '/api/saved_objects/visualization/' + ScanVisualization,
      config.kibana_url + '/api/saved_objects/visualization/' + NetworkVisualization
    ]
    for(let ctr = 0; ctr< visualizationUrlArray.length; ctr++){
      let url = visualizationUrlArray[ctr];
      try{
        let response = await rp.get(url, {headers : {'kbn-xsrf': 'anything', 'Cookie': sid}, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true});
        visualizationResponse.push(response.body);
      }catch(error){
        ctr = visualizationUrlArray.length;
        return service.deleteDashboard(orgId, sid);
      }
    }
    if(visualizationResponse.length == 3){
      return service.getIndexPattern(orgId, visualizationResponse, sid);
    }else{
      return service.deleteDashboard(orgId, sid)
    }
  }
  async getIndexPattern(orgId, responseArray, sid) {
    let service = this
    let LogIndex = 'null'
    let ScanIndex = 'null'
    let NetworkIndex = 'null'
    let indexPatternResponse = new Array()
    responseArray.filter(function (object) {
      let jsonObject = JSON.parse(object.attributes.kibanaSavedObjectMeta.searchSourceJSON)
      if (object.attributes.title == 'Events') {
        LogIndex = jsonObject.index
      } else if (object.attributes.title == 'Configuration Check') {
        ScanIndex = jsonObject.index
      } else {
        NetworkIndex = jsonObject.index
      }
    })
    
    let indexPatternUrlArray = [
      config.kibana_url + '/api/saved_objects/index-pattern/' + LogIndex,
      config.kibana_url + '/api/saved_objects/index-pattern/' + ScanIndex,
      config.kibana_url + '/api/saved_objects/index-pattern/' + NetworkIndex
    ]
    for(let ctr = 0; ctr< indexPatternUrlArray.length; ctr++){
      let url = indexPatternUrlArray[ctr];
      try{
        let response = await rp.get(url, {headers : {'kbn-xsrf': 'anything', 'Cookie': sid}, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true});
        indexPatternResponse.push(response.body);
      }catch(error){
        ctr = indexPatternUrlArray.length;
        return service.deleteDashboard(orgId, sid);
      }
    }
    if(indexPatternResponse.length == 3){
      let result = await service.getFields(orgId, sid);
      return service.updateIndexPatternFields(orgId, responseArray, null, result, auth)
    }else{
      return service.deleteDashboard(orgId, sid)
    }
  }
  async deleteDashboard(orgId, sid) {
    let idToDelete = new Array();
    let service = this;

    let urls = [
      config.kibana_url + '/api/saved_objects/dashboard/',
      config.kibana_url + '/api/saved_objects/visualization/',
      config.kibana_url + '/api/saved_objects/search/'
    ]

    let typeArray = ['dashboard', 'visualization', 'search']

    for(let t = 0; t < typeArray.length; t++){
      let type = typeArray[t];
      let getUrlold = config.kibana_url + '/api/saved_objects/?type=' + type + '&search=' + orgId + '&search_fields=title%5E3&search_fields=description';
      let getUrlnew = config.kibana_url + '/api/saved_objects/_find?type=' + type + '&search=' + orgId + '&search_fields=title%5E3&search_fields=description';
      try{
        let response = await rp.get({url: getUrlold, headers : {'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Cookie': sid}, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true});
        response.body.saved_objects.forEach(function (object) {
          if (type == 'dashboard') {
            idToDelete.push({ 'dashboard': object.id })
          } else if (type == 'visualization') {
            idToDelete.push({ 'visualization': object.id })
          } else {
            idToDelete.push({ 'search': object.id })
          }
        })
      }catch(error){
        try{
          let response1 = await rp.get({url: getUrlnew, headers : {'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Cookie': sid}, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true});
          response1.body.saved_objects.forEach(function (object) {
            if (type == 'dashboard') {
              idToDelete.push({ 'dashboard': object.id })
            } else if (type == 'visualization') {
              idToDelete.push({ 'visualization': object.id })
            } else {
              idToDelete.push({ 'search': object.id })
            }
          })
        }catch(error){
          return service.errorHandler('Error in deletion');
        }
      }
    }
    if (idToDelete.length != 0) {
      for(let d = 0; d< idToDelete.length; d++){
        let object = idToDelete[d];
        let url = ''
        if (object.dashboard) {
          url = urls[0] + object.dashboard
        } else if (object.visualization) {
          url = urls[1] + object.visualization
        } else {
          url = urls[2] + object.search
        }
        try{
          await rp.delete(url, {headers : {'kbn-xsrf': 'anything', 'Authorization': auth}, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true});
        }catch(error){
          return service.errorHandler('Error in deletion');
        }
      }
      return service.deleteIndexPattern(orgId, sid);
    } else{
      return service.deleteIndexPattern(orgId, sid)
    }
  }
  async deleteIndexPattern(orgId, sid) {
    let service = this
    let titleLog = "caveolog-" + orgId + "*"
    let titleScan = "caveoscan-" + orgId + "*"
    let titleFlow = "caveonetwork-" + orgId + "*-flows*"
    let idToDelete = new Array()

    let deleteUrl = config.kibana_url + '/api/saved_objects/index-pattern/'
    let getUrlOld = config.kibana_url + '/api/saved_objects/?type=index-pattern&fields=title&per_page=10000'
    let getUrlNew = config.kibana_url + '/api/saved_objects/_find?type=index-pattern&fields=title&per_page=10000'

    try{
      let response = await rp.get({url: getUrlOld, headers : {'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Cookie': sid}, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true});
      response.body.saved_objects.forEach(function (object) {
        if (object.attributes.title == titleLog || object.attributes.title == titleScan || object.attributes.title == titleFlow) {
          idToDelete.push(object.id)
        }
      })
    }catch(error){
      let response1 = await rp.get({url: getUrlNew, headers : {'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Cookie': sid}, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true});
      response1.body.saved_objects.forEach(function (object) {
        if (object.attributes.title == titleLog || object.attributes.title == titleScan || object.attributes.title == titleFlow) {
          idToDelete.push(object.id)
        }
      })
    }
    if (idToDelete.length != 0) {
      for(let d = 0; d< idToDelete.length; d++){
        let object = idToDelete[d];
        let url = deleteUrl + object;
        try{
          await rp.delete(url, {headers : {'kbn-xsrf': 'anything', 'Authorization': auth}, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true});
        } catch(error){
          return service.errorHandler('Error in deletion of index_pattern');
        }
      }
      await ForensicsDashboard.destroy({ where: { organization_id: orgId, type: { $ne: 'machine_learning' } } });
      return service.createDashboard(orgId)
    }else{
      await ForensicsDashboard.destroy({ where: { organization_id: orgId, type: { $ne: 'machine_learning' } } });
      return service.createDashboard(orgId)
    }
  }
  async kibanaUserLogin(username, password) {
    let url = config.kibana_url + '/api/security/v1/login'

    let body = Object.assign({})
    body.username = username;
    body.password = password;

    try {
      let response = await rp.post(url, { body: body, headers: { 'kbn-xsrf': 'anything', 'Content-Type': 'application/json' }, json: true, rejectUnauthorized: false, resolveWithFullResponse: true });
      return response.headers['set-cookie'][0].split(';');
    } catch(error){
      return this.errorHandler('Error in kibana user login');
    }
  }
  async createIndexPatternForNewKibanaVersion(orgId){
    let service = this;
    let titleLog = "caveolog-" + orgId + "*"
    let titleScan = "caveoscan-" + orgId + "*"
    let titleFlow = "caveonetwork-" + orgId + "*-flows*"

    let urlToCreateIndex = config.kibana_url + '/api/saved_objects/index-pattern'

    let titleArr = new Array()
    titleArr.push(titleLog, titleScan, titleFlow)

    for(let ctr=0; ctr<titleArr.length; ctr++){
      let object = titleArr[ctr];
      let payload = ""
      if (object === titleLog) {
        dashboard.forensicDashboard.Indexes[4].attributes.title = titleLog
        payload = dashboard.forensicDashboard.Indexes[4]
      } else if (object === titleScan) {
        dashboard.forensicDashboard.Indexes[4].attributes.title = titleScan
        payload = dashboard.forensicDashboard.Indexes[4]
      } else {
        dashboard.forensicDashboard.Indexes[4].attributes.title = titleFlow
        payload = dashboard.forensicDashboard.Indexes[4]
      }

      try{
        let response = await rp.post({url: urlToCreateIndex, body: payload, headers : {'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Authorization': auth}, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true});
        if (response.body.attributes.title == titleLog) {
          indexPatternArr.push({ "Logs": response.body.id })
        } else if (response.body.attributes.title == titleScan) {
          indexPatternArr.push({ "Scan": response.body.id })
        } else {
          indexPatternArr.push({ "Flows": response.body.id })
        }
      }catch(error){
        return service.errorHandler('Error in index pattern creation');
      }
    }
    if(indexPatternArr.length == 3) {
      return service.createDefaultIndexPattern(orgId);
    }else{
      return service.errorHandler('Error in index pattern creation');
    }
  }
  async getFields(orgId, sid){
    let titleLog = "caveolog-" + orgId + "*"
    let titleScan = "caveoscan-" + orgId + "*"
    let titleFlow = "caveonetwork-" + orgId + "*-flows*"

    let fieldArr = new Array()

    let indexPatternArr = new Array()
    indexPatternArr.push(titleLog, titleScan, titleFlow)

    for(let ctr = 0; ctr< indexPatternArr.length;ctr++){
      let indexPattern =  indexPatternArr[ctr];
      let url = config.kibana_url + '/api/index_patterns/_fields_for_wildcard?pattern=' + indexPattern + '&meta_fields=%5B%22_source%22%2C%22_id%22%2C%22_type%22%2C%22_index%22%2C%22_score%22%5D'
      try{
        let response = await rp.get(url, {headers : {'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Cookie': sid}, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true});
        if(response.request.path.includes(titleLog)){
          fieldArr.push({ 'logFields': response.body })
        }
        if(response.request.path.includes(titleScan)){
          fieldArr.push({ 'scanFields': response.body })
        }
        if(response.request.path.includes(titleFlow)){
          fieldArr.push({ 'networkFields': response.body })
        }
      }catch(error){
        ctr = indexPatternArr.length;
        logger.error('Error in getting fiels of indexPattern: ' + indexPattern )
      }
    }
    return fieldArr;
  }
  async updateIndexPatternFields(orgId, arrToGetIndexPatternId, indexPatternIdArr, fieldArr, auth) {
    let LogUrl = 'null'
    let ScanUrl = 'null'
    let NetworkUrl = 'null'
    let dashboardUrl = new Array()

    let titleLog = "caveolog-" + orgId + "*"
    let titleScan = "caveoscan-" + orgId + "*"
    let titleFlow = "caveonetwork-" + orgId + "*-flows*"

    let payloadLog = null
    let payloadScan = null
    let payloadFlows = null

    if (arrToGetIndexPatternId) {
      arrToGetIndexPatternId.filter(function (object) {
        let jsonObject = JSON.parse(object.attributes.kibanaSavedObjectMeta.searchSourceJSON)
        if (object.attributes.title == 'Events') {
          LogUrl = config.kibana_url + '/api/saved_objects/index-pattern/' + jsonObject.index
        } else if (object.attributes.title == 'Configuration Check') {
          ScanUrl = config.kibana_url + '/api/saved_objects/index-pattern/' + jsonObject.index
        } else {
          NetworkUrl = config.kibana_url + '/api/saved_objects/index-pattern/' + jsonObject.index
        }
      })
    }
    if(indexPatternIdArr){
      indexPatternIdArr.filter(function (object) {
        if (object.Logs) {
          LogUrl = config.kibana_url + '/api/saved_objects/index-pattern/' + object.Logs
        } else if (object.Scan) {
          ScanUrl = config.kibana_url + '/api/saved_objects/index-pattern/' + object.Scan
        } else {
          NetworkUrl = config.kibana_url + '/api/saved_objects/index-pattern/' + object.Flows
        }
      })
    }

    fieldArr.filter(function (object) {
      if (object.logFields) {
        if (object.logFields != "") {
          dashboard.forensicDashboard.Indexes[2].attributes.fields = JSON.stringify(object.logFields.fields)
        }
        dashboard.forensicDashboard.Indexes[2].attributes.title = titleLog
        payloadLog = dashboard.forensicDashboard.Indexes[2]
      }
      if (object.scanFields) {
        if (object.scanFields != "") {
          dashboard.forensicDashboard.Indexes[0].attributes.fields = JSON.stringify(object.scanFields.fields)
        }
        dashboard.forensicDashboard.Indexes[0].attributes.title = titleScan
        payloadScan = dashboard.forensicDashboard.Indexes[0]
      }
      if (object.networkFields) {
        if (object.networkFields != "") {
          dashboard.forensicDashboard.Indexes[1].attributes.fields = JSON.stringify(object.networkFields.fields)
        }
        dashboard.forensicDashboard.Indexes[1].attributes.title = titleFlow
        payloadFlows = dashboard.forensicDashboard.Indexes[1]
      }
    })

    let urlArray = new Array()
    urlArray.push({ 'log': LogUrl }, { 'scan': ScanUrl }, { 'network': NetworkUrl })

    for(let ctr=0; ctr<urlArray.length; ctr++){
      let object = urlArray[ctr];
      let payload = ""
      let url = ""
      if (object.log) {
        url = LogUrl
        payload = payloadLog
      }
      if (object.scan) {
        url = ScanUrl
        payload = payloadScan
      }
      if (object.network) {
        url = NetworkUrl
        payload = payloadFlows
      }
      try{
        await rp.put(url, {body: payload, headers : {'kbn-xsrf': 'anything', 'Content-Type': 'application/json', 'Authorization': auth}, json: true, rejectUnauthorized: config.checkKibanaCertificate, resolveWithFullResponse: true});
      }catch(error){
        logger.error('Error in updating fiels of indexPattern')
      }
    }
    let result = await ForensicsDashboard.findAll({ where: { organization_id: orgId, type: { $ne: 'machine_learning' } }, include: [{ all: true }] });
    result.filter(object => {
      object.dashboard_url = object.dashboard_url.split('kibanaUrl').join(config.kibana_url)
      dashboardUrl.push(object)
    })
    return dashboardUrl;
  }

  errorHandler(message){
    let err = new Error(message);
    err.statusCode = 400;
    return Promise.reject(err.message);
  }
}
