const checkId = require('../../../utils/checkId');
const { get } = require('lodash');
const config = require('../../../configure').get();
const errorHandler = require('../../../utils/errorHandler');
const Validator = require('../../../utils/validator');
const KibanaUserRolesService = require('../kibanaUserRoles/kibanaUserRoles.service');
const kibanaUserRolesService = new KibanaUserRolesService();
const RoleService = require('./../roles/role.service');
const roleService = new RoleService();
const MFAService = require('./../auth/mfa.service');
const mfaService = new MFAService();
const GroupService = require('./group.service');
const groupService = new GroupService();
const logger = require('../../../utils/logger').logger;

const UserService = require('./user.service');
const userService = new UserService();

module.exports = class UserController {
  async createUser(req, res) {
    const params = req.body;
    try {
      await Validator.validateParams({
        username: 'required|string',
        firstName: 'required|string',
        lastName: 'nullable',
        role_id: 'required|integer',
        organization_id: 'required|integer',
        password: 'nullable',
        isActive: 'required|in:enabled,disabled,true'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const username = req.body.username;
    const pw = req.body.password;
    const firstname = req.body.firstName;
    const lastname = req.body.lastName;
    const roleId = req.body.role_id;
    const orgId = req.body.organization_id || req.params.orgId;
    params.is_active = params.isActive;
    const update = {};
    try {
      const user = await userService.createUser(username, pw, firstname, lastname, roleId, orgId, params, true);
      if (!user) {
        logger.error('An error occurred creating user');
        const err = new Error('An error occurred creating user');
        err.status = 400;
        return errorHandler(req, res, err);
      }
      update.username = username;
      update.fullname = firstname + lastname;
      update.email = username;
      update.password = params.password;
      if (config.forensics_enabled === false || config.ml_enabled === true) {
        const roleInfo = await roleService.getRole(params.role_id, orgId, '');
        if (roleInfo.name.toLowerCase() === ('msp_owner') || roleInfo.name.toLowerCase() === ('mssp_owner')) {
          kibanaUserRolesService.createRolesForMspAndMsspUsers(params.assigned_org_ids, update);
        } else {
          kibanaUserRolesService.createUserRoles(orgId, update, 'all');
        }
      }
      return res.json(user);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getUser(req, res) {
    const userId = req.params.userId;
    if (checkId(userId)) {
      logger.error({ userId }, 'Error with User Id');
      const err = new Error('Error with User Id');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    const user = await userService.getUserById(userId);
    logger.silly({ user }, 'user');
    if (!user) {
      logger.error({ userId }, 'User not found.');
      return res.sendStatus(404);
    }
    return res.json(user);

  }

  async getUserManagedOrgs(req, res) {
    const userId = req.params.userId;
    const org = req.user.Organizations[0];
    if (checkId(userId)) {
      logger.error({ userId }, 'bad user id');
      const err = new Error('Bad User Id');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    try {
      let orgs = await userService.getUserManagedOrgs(userId);
      orgs = orgs.filter(o => o.id !== org.id);
      orgs.push({ name: org.name, type: org.type, id: org.id });
      return res.json(orgs);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async addManagedOrg(req, res) {
    const userId = req.params.userId;
    let { orgIds } = req.body;
    if (!Array.isArray(orgIds)) orgIds = [orgIds];
    const cspOrgId = req.user.Organizations[0].id;
    if (!orgIds.includes(cspOrgId)) orgIds.push(cspOrgId);
    if (checkId(userId)) {
      logger.error({ userId }, 'bad user id');
      const err = new Error('Bad User Id');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    try {
      const orgs = await userService.addManagedOrg(userId, orgIds);
      return res.json(orgs);
    } catch (error) {
      if (error.name === 'SequelizeUniqueConstraintError') {
        error.status = 400;
        error.message = 'User Already Manages Organizations';
      }
      return errorHandler(req, res, error);
    }
  }

  async removeManagedOrg(req, res) {
    const userId = req.params.userId;
    let { orgId } = req.query;
    if (!Array.isArray(orgId)) orgId = [orgId];
    const orgIds = orgId;
    if (checkId(userId)) {
      logger.error({ userId }, 'bad user id');
      const err = new Error('Bad User Id');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    try {
      const orgs = await userService.removeManagedOrg(userId, orgIds);
      return res.json(orgs);
    } catch (error) {
      if (error.name === 'SequelizeUniqueConstraintError') {
        error.status = 400;
        error.message = 'User Already Manages Organizations';
      }
      return errorHandler(req, res, error);
    }
  }

  async setUserRole(req, res) {
    const userId = req.params.userId;
    const orgId = req.body.orgId;
    const roleId = req.body.roleId;
    if (checkId(userId)) {
      logger.error({ userId }, 'Error with User Id');
      const err = new Error('Error with User Id');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    if (checkId(roleId)) {
      logger.error({ roleId }, 'Error with Role Id');
      const err = new Error('Error with Role Id');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    const success = await userService.addRoleToUser(userId, orgId, roleId);
    if (success) return res.sendStatus(204);
    return res.sendStatus(200);

  }

  async updatePassword(req, res) {
    const userId = req.params.userId;
    const password = req.body.password;
    if (checkId(userId)) {
      logger.error({ userId }, 'Error with User Id');
      const err = new Error('Error with User Id');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    try {
      const data = await userService.updatePassword(userId, password);
      logger.info({ data }, 'Update Password Data');
      return res.sendStatus(204);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async updateUser(req, res) {
    const loggedInUserId = req.user.id;
    const userId = req.params.userId;
    const orgId = req.body.organization_id || req.params.orgId;
    const params = req.body;
    try {
      params.isActive = params.isActive ? params.isActive.toString().toLowerCase() : null;
      await Validator.validateParams({
        username: 'required|string',
        firstName: 'required|string',
        lastName: 'nullable',
        role_id: 'required|integer',
        organization_id: 'required|integer',
        password: 'nullable',
        isActive: 'required|in:enabled,disabled'
      }, params);

      await Validator.validateParams({
        userId: 'required|integer'
      }, req.params, { userId: 'Error with user Id' });
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const update = {};
    const username = params.username;
    try {
      const user = await userService.updateUser(userId, loggedInUserId, orgId, params);
      user.is_active = user.isActive;
      logger.info({ user });
      update.username = username;
      update.fullname = params.firstName + params.lastName;
      update.email = username;
      update.password = params.password;
      if (config.forensics_enabled === false || config.ml_enabled === true) {
        const roleInfo = await roleService.getRole(params.role_id, orgId, '');
        if (roleInfo.name.toLowerCase() === ('msp_owner') || roleInfo.name.toLowerCase() === ('mssp_owner')) {
          kibanaUserRolesService.createRolesForMspAndMsspUsers(params.assigned_org_ids, update);
        } else {
          kibanaUserRolesService.createUserRoles(orgId, update, 'all');
        }
      }
      return res.json(user);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getUserOrganizations(req, res) {
    const userId = req.params.userId;
    const getChildOrgs = req.query.children || false;
    if (checkId(userId)) {
      logger.error({ userId }, 'Error with User Id');
      const err = new Error('Error with User Id');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    try {
      const organizations = await userService.getUserOrganizations(userId, getChildOrgs);
      return res.json(organizations);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async deleteUser(req, res) {
    const userId = req.params.userId;
    const orgId = req.params.orgId;
    let username = '';
    if (checkId(userId)) {
      logger.error({ userId }, 'Error with User Id');
      const err = new Error('Error with User Id');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    try {
      const update = await userService.deleteUser(userId, orgId);
      username = update.username;
      logger.info({ update, userId }, 'Update');
      if (config.forensics_enabled === false || config.ml_enabled === true) {
        kibanaUserRolesService.deleteUser(username);
      }
      return res.json(update);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async deleteMultipleUser(req, res) {
    const userId = req.query.id || '';
    const loggedInUserId = req.user.id;
    const userIdArr = userId.split(',');
    try {
      const update = await userService.deleteMultipleUser(userIdArr, loggedInUserId);
      logger.info('Deleted');
      return res.json(update);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async addMfa(req, res) {
    const userId = req.params.userId;
    try {
      const mfaData = await mfaService.generateTOTPUri(userId);
      return res.json(mfaData);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async removeMfa(req, res) {
    const userId = req.params.userId;
    try {
      const userRole = get(req.user, 'OrgMemberships[0].Role.name');
      if (userRole && !['saas_owner', 'org_owner', 'saas_owner', 'csp_owner'].includes(userRole)) {
        const verify = await mfaService.verifyMFA(userId, req.body.mfaToken || req.query.mfaToken);
        if (!verify) {
          logger.error({ userId }, 'mfaToken is missing');
          const err = new Error('mfaToken is missing');
          err.status = 400;
          return errorHandler(req, res, err);
        }
      }
      await mfaService.removeMFA(userId);
      return res.json({ userId, message: 'Successfully Removed MFA' });
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async verifyMFA(req, res) {
    const userId = req.params.userId;
    try {
      const mfaData = await mfaService.verifyMFA(userId, req.body.mfaToken);
      return res.json(mfaData);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getGroup(req, res) {
    const { groupId, orgId } = req.params;
    try {
      const response = await groupService.getGroup(groupId);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }

  }

  async createGroup(req, res) {
    const params = req.body;
    const { orgId } = req.params;
    try {
      const response = await groupService.createGroup(orgId, params);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async updateGroup(req, res) {
    const params = req.body;
    const { orgId, groupId } = req.params;
    try {
      const response = await groupService.updateGroup(groupId, params);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async addUsers(req, res) {
    const userIds = req.body;
    const { groupId } = req.params;
    try {
      const response = await groupService.addUsers(groupId, userIds);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async setUsers(req, res) {
    const userIds = req.body;
    const { groupId } = req.params;
    try {
      const response = await groupService.setUsers(groupId, userIds);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

};
