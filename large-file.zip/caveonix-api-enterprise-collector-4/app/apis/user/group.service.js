const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-user.service'
});
const Group = require('./group.model');
const User = require('./user.model');
module.exports = class GroupService {
  constructor() {
    logger.debug('called UserService constructor');
  }

  async createGroup(orgId, params, userIds = []) {
    params.organization_id = orgId;
    const group = await Group.create(params);
    if (userIds.length > 0) {
      await group.setUsers(userIds);
    }
    return group;
  }

  async updateGroup(orgId, params, userIds = []) {
    const group = await Group.create(params);
    if (userIds.length > 0) {
      await group.setUsers(userIds);
    }
    return group;
  }

  async getGroup(groupId) {
    return Group.findByPk(groupId);
  }

  async addUsers(groupId, userIds) {
    const group = await this.getGroup(groupId);
    group.addUsers(userIds);
    return group;
  }

  async setUsers(groupId, userIds) {
    const group = await this.getGroup(groupId);
    group.setUsers(userIds);
    return group;
  }
};
