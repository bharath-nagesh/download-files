const config = require('../../../configure');
const cache = {};
const User = require('./user.model');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-user.service'
});
const OrgService = require('../organization/org.service');
const orgService = new OrgService();
const sequelize = require('../../../config/db.conf').getConnection();
const PasswordValidator = require('password-validator');
const removeSpace = require('../../../utils/checkSpaces');
const OrgMembers = require('../organization/orgMembers.model');
const Organization = require('../organization/organization.model');
const Role = require('../roles/role.model');
const UserSessionInfo = require('../../models/UserSessionInfo.model');
module.exports = class UserService {
  constructor() {
    logger.debug('called UserService constructor');
  }

  async getUserManagedOrgs(userId) {
    return sequelize.query(`select o.name,o.type, o.id from user_org_mappings uom 
    join organizations o on o.id = uom.organization_id AND o.is_active!='false' where user_id = :userId`, {
      replacements: { userId },
      type: sequelize.QueryTypes.SELECT
    });
  }

  async addManagedOrg(userId, orgIds) {
    return Promise.all(orgIds.map(async (orgId) => {
      try {
        const a = await sequelize.query(`insert into user_org_mappings(user_id, organization_id) values(:userId, :orgId)`, {
          replacements: {
            userId,
            orgId
          },
          type: sequelize.QueryTypes.INSERT
        });
        return a;
      } catch (e) {
        logger.error({ e, stack: e.stack }, 'error occurred');

      }
    }));

  }

  async removeManagedOrg(userId, orgIds) {
    return Promise.all(orgIds.map(async (orgId) => {
      try {
        const a = await sequelize.query(`delete from user_org_mappings where user_id = :userId and organization_id = :orgId`, {
          replacements: {
            userId,
            orgId
          },
          type: sequelize.QueryTypes.DELETE
        });
        return a;
      } catch (e) {
        logger.error({ e, stack: e.stack }, 'error occurred');
      }
    }));

  }

  getUser(userId, opts) {

    return User.findByPk(userId, {
      include: [
        {
          model: OrgMembers,
          as: 'OrgMemberships',
          attributes: { exclude: ['role_id', 'organization_id'] },
          include: [{ model: Organization }, { model: Role }]
        }
      ]
    });
  }

  async getUserById(userId, opts) {
    const userData = await User.findByPk(userId,
      { attributes:{ exclude:['password'] },include: [{ model: Role, include: [{ all: true }] }, { all: true }] });
    if(userData.activeDirectoryId) userData.dataValues.type = 'Active Directory';
    else userData.dataValues.type = 'Local DB';
    if(userData.twoFactorToken){
      userData.dataValues.twoFactorToken = true;
    } else {
      userData.dataValues.twoFactorToken = false;
    }
    return userData;
  }

  async checkUsernameExists(username) {
    if (!username) return true;
    const user = await User.findOne({ where: { username: sequelize.where(sequelize.fn('LOWER', sequelize.col('username')), sequelize.fn('lower', username)) } });
    if (user) return user;
    return false;
  }

  getUserOrganizations(userId, getChildOrgs = false, isAdminInServiceProvider = true) {
    return this.getUser(userId).then(user => {
      if (!user) {
        logger.error({ userId }, 'User not found.');
        const err = new Error('User not found.');
        err.status = 404;
        throw err;
      }
      logger.info({ user }, 'the user');
      const organization = user.OrgMemberships[0].Organization;
      let p = Promise.resolve([organization]);
      if (getChildOrgs) {
        p = orgService.getOrgChain(organization.id, true).then(orgChain => {
          const actions = orgChain.map(childOrgObj => {
            return orgService.getProvider_Org_SubOrgChain(childOrgObj.getDataValue('organization_id'), null, null, null).then(o => {
              const obj = orgChain.find(data => {
                return data.getDataValue('organization_id') === o.id;
              });
              o.orgChain = obj.getDataValue('path');
              return Promise.resolve(o);
            });
          });
          return Promise.all(actions).then(childOrgs => {
            if (isAdminInServiceProvider) {
              return orgService.getTopLevelOrgs().then(topLevelOrgs => {
                logger.info({ topLevelOrgs, childOrgs }, ' top level orgs and child orgs');

                const filteredOrgs = childOrgs.concat(topLevelOrgs);

                logger.info('it here');
                return Promise.resolve(filteredOrgs);
              });
            } else {
              return Promise.resolve(childOrgs);
            }
          });
        });
      }
      return p;
    });
  }

  async createUser(username, pw, firstName, lastName, roleId, orgId, params, passCheck = true) {
    const schema = new PasswordValidator();
    const complexPassword = config.complex_password;
    if (!username || !pw) {
      const err = new Error('Bad Request');
      err.status = 400;
      throw err;
    }
    if (passCheck) {
      schema
        .is().min(10) // Minimum length 8
        .has().uppercase() // Must have uppercase letters
        .has().lowercase() // Must have lowercase letters
        .has().digits() // Must have digits
        .has().not().spaces() // Should not have spaces
        .has().symbols()
        .is().not().oneOf(['Passw0rd', 'Password123']);

      if (!schema.validate(pw) && complexPassword) {
        const err = new Error('Passwords must contain at least 10-character alpha numeric \n with at least one capital letter, one special character and one numerical value');
        err.status = 400;
        throw err;
      }
    }
    const newName = removeSpace.removeAllSpaces(username);
    const exists = await this.checkUsernameExists(newName);
    if (exists) {
      if (exists.isActive !== false) {
        const err = new Error('Duplicate Username.');
        err.status = 400;
        throw err;
      }
      const userId = exists.id;
      params.username = newName;
      const user = await User.findOne({ where: { id: userId }, include: [{ all: true }] });
      await user.update(params);
      await OrgMembers.create({
        role_id: roleId,
        organization_id: orgId,
        user_id: userId
      });
      const userData = await User.findOne({ where: { id: user.id }, include: [{ all: true }] });
      return userData;
    }
    username = newName;
    const userParams = Object.assign({}, params, { username, password: pw, firstName, lastName, isActive: params.isActive });
    const user = await User.create(userParams);
    user.organization_id = orgId;
    await OrgMembers.create({
      role_id: roleId,
      organization_id: orgId,
      user_id: user.id
    });
    const userData = await User.findOne({ where: { id: user.id }, include: [{ all: true }] });
    return userData;
  }

  checkNameForUpdate(name, userId) {
    return User.findOne({
      where: {
        username: sequelize.where(sequelize.fn('LOWER', sequelize.col('username')), sequelize.fn('lower', name)),
        id: { $ne: userId }
      }
    });
  }

  async updateUser(userId, loggedInUserId, orgId, params) {
    const name = params.username;
    params.password = params.password ? params.password : null;
    const pw = params.password;
    const complexPassword = config.complex_password;
    const schema = new PasswordValidator();
    schema
      .is().min(10) // Minimum length 8
      .has().uppercase() // Must have uppercase letters
      .has().lowercase() // Must have lowercase letters
      .has().digits() // Must have digits
      .has().not().spaces() // Should not have spaces
      .has().symbols()
      .is().not().oneOf(['Passw0rd', 'Password123']);

    if (pw && !schema.validate(pw) && complexPassword) {
      const err = new Error('Password must contain at least 10-character,one capital letter,one special character and one numerical value');
      err.status = 400;
      throw err;
    }
    delete params.twoFactorToken;
    const newName = removeSpace.removeAllSpaces(name);
    const exists = await this.checkNameForUpdate(newName, userId);
    if (exists) {
      const err = new Error('Duplicate Username.');
      err.status = 400;
      throw err;
    }
    params.username = newName;
    const userOrgMembers = await OrgMembers.findOne({ where: { user_id: userId } });
    if((userId === loggedInUserId.toString()) && userOrgMembers.role_id !== params.role_id){
      const err = new Error('Self Role Cannot Be Updated');
      err.status = 400;
      throw err;
    }
    if(userId !== '1') {
      if(userOrgMembers.role_id !== params.role_id || params.isActive === 'disabled' || params.isActive === 'false' ){
        await cache.set(`userSession/user/${userId}`, null);
      }
      await OrgMembers.update(params, { where: { user_id: userId } });
    }
    const updateUser = await User.findOne({ where: { id: userId }, include: [{ all: true }] });
    params.accountVerified = 1;
    return updateUser.update(params);
  }

  async updatePassword(userId, password) {
    //TODO set up with password management table
    const user = await User.findByPk(userId);
    if (!user) {
      logger.error({ userId }, ' User not found.');
      const err = new Error('User not found.');
      err.status = 404;
      throw err;
    }
    logger.silly('updating password');
    const oldPassword = user.password;
    const old_pw = await sequelize.query(`INSERT INTO user_password_mgmt(created_at,updated_at,old_password, user_id) values (now(), now(), $1,$2 );`, { bind: [oldPassword, userId] });
    return user.updatePassword(password);
  }

  async deleteUser(userId, orgId) {
    await User.update({ isActive: false }, { where: { id: userId } });
    await OrgMembers.destroy({ where: { user_id: userId } });
    return User.findOne({ where: { id: userId }, include: [{ all: true }] });
  }

  async deleteMultipleUser(userIdArr, loggedInUserId) {
    loggedInUserId = loggedInUserId.toString();
    // if this gets any bigger, change to switch statement
    const errorMsg = (userIdArr.includes(loggedInUserId)) ? 'Cannot Delete Logged In User' : (userIdArr.includes('1')) ? 'Cannot Delete Default User' : null;
    if (errorMsg) {
      const err = new Error(errorMsg);
      err.status = 400;
      throw err;
    }
    await User.update({ isActive: false, activeDirectoryId: null }, { where: { id: { $in: userIdArr } } });
    await OrgMembers.destroy({ where: { user_id: { $in: userIdArr } } });
    await sequelize.query(`delete from user_org_mappings where user_id in (:userIdArr)`, {
      replacements: { userIdArr }, type: sequelize.QueryTypes.DELETE });
    return User.findAll({ where: { id: { $in: userIdArr } } });
  }

  async addUserSessionForMspUser(params) {
    const userInfo = await User.findOne({ where: { id: params.userId } });
    if(userInfo.isActive === 'enabled' || userInfo.isActive === 'true') userInfo.isActive = true;
    else if(userInfo.isActive === 'disabled' || userInfo.isActive === 'false') userInfo.isActive = false;
    const param = {
      user_id: userInfo.id,
      session_id: params.userToken,
      organization_id: params.orgId,
      is_active: userInfo.isActive
    };
    const session = await UserSessionInfo.create(param);
    return session;
  }

  async checkUserSession(orgId, userId, userToken) {
    const session = await UserSessionInfo.findOne({
      where: {
        user_id: userId,
        session_id: userToken,
        organization_id: orgId
      }
    });
    if (session) return true;
    return false;
  }
};
