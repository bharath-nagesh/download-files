const bcrypt = require('bcrypt-nodejs');
const connection = require('../../../config/db.conf').getConnection();
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-user.model'
});
const { DataTypes, Model } = require('sequelize');

/**
 * @swagger
 * components:
 *   schemas:
 *     User:
 *       type: object
 *       required:
 *         - username
 *         - password
 *         - isActive
 *       properties:
 *         username:
 *           type: string
 *         password:
 *           type: string
 *         firstName:
 *           type: string
 *         lastName:
 *           type: string
 *         companyName:
 *           type: string
 *         companyUrl:
 *           type: string
 *         signUp:
 *           type: string
 *         avatarUrl:
 *           type: string
 *         accountVerified:
 *           type: string
 *         isActive:
 *           type: string
 * @param sequelize
 */
class User extends Model {

  static init(sequelize) {
    return super.init({
        id: {
          type: DataTypes.INTEGER,
          primaryKey: true,
          autoIncrement: true
        },
        username: { type: DataTypes.STRING },
        password: {
          type: DataTypes.STRING,
          set(pw) {
            logger.silly('hashing password');
            if (pw) this.setDataValue('password', User.generateHash(pw));
          }
        },
        firstName: { type: DataTypes.STRING, field: 'first_name', defaultValue: '' },
        lastName: { type: DataTypes.STRING, field: 'last_name', defaultValue: '' },
        fullName: {
          type: DataTypes.VIRTUAL(DataTypes.STRING, ['firstName', 'lastName']),
          get() {
            return `${this.firstName} ${this.lastName}`;
          },
          set(value) {
            throw new Error('Do not try to set the `fullName` value!');
          }
        },
        companyName: { type: DataTypes.STRING, field: 'company_name', defaultValue: '' },
        companyUrl: { type: DataTypes.STRING, field: 'company_url', defaultValue: '' },
        signUp: { type: DataTypes.BOOLEAN, field: 'signup' },
        avatarUrl: { type: DataTypes.STRING, field: 'avatar_url' },
        accountVerified: { type: DataTypes.INTEGER, field: 'account_verified', defaultValue: 0 },
        activeDirectoryId: { type: DataTypes.INTEGER, field: 'active_directory_id' },
        twoFactorToken: { type: DataTypes.STRING, field: 'twofactor_token', allowNull: true },
        isActive: { type: DataTypes.BOOLEAN, field: 'is_active', defaultValue: true, allowNull: false },
        is_active: { type: DataTypes.BOOLEAN, field: 'is_active' }
      },
      {
        sequelize,
        timestamps: true,
        freezeTableName: true,
        tableName: 'users',
        underscored: true,
        updatedAt: 'updated_at',
        createdAt: 'created_at'
      });
  }

  static associate(models) {
    User.belongsToMany(models.Organization, { as: 'Organizations', through: models.OrgMembers });
    User.hasMany(models.OrgMembers, { as: 'OrgMemberships' });
    User.belongsToMany(models.Role, { through: models.OrgMembers });
    User.belongsToMany(models.Group, { through: 'user_group_members', timestamps: false });
    User.hasMany(models.UserWorkflowMember);
  };

  static generateHash(password) {
    return bcrypt.hashSync(password, bcrypt.genSaltSync(8), null);
  };

// class methods
  validPassword(password) {
    return bcrypt.compareSync(password, this.password);
  };

  updatePassword(password) {
    this.password = password;
    return this.save();
  };
}

module.exports = User;
