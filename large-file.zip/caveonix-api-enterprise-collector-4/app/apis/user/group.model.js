const bcrypt = require('bcrypt-nodejs');
const connection = require('../../../config/db.conf').getConnection();
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-user.models'
});
const { DataTypes, Model } = require('sequelize');

/**
 * @swagger
 * components:
 *   schemas:
 *     Group:
 *       type: object
 *       required:
 *         - username
 *         - password
 *         - isActive
 *       properties:
 *         username:
 *           type: string
 *         password:
 *           type: string
 *         firstName:
 *           type: string
 *         lastName:
 *           type: string
 *         companyName:
 *           type: string
 *         companyUrl:
 *           type: string
 *         signUp:
 *           type: string
 *         avatarUrl:
 *           type: string
 *         accountVerified:
 *           type: string
 *         isActive:
 *           type: string
 * @param sequelize
 */
class Group extends Model {

  static init(sequelize) {
    return super.init({
        id: {
          type: DataTypes.INTEGER,
          primaryKey: true,
          autoIncrement: true
        },
        name: { type: DataTypes.STRING, field: 'name' },
        email: { type: DataTypes.STRING, field: 'email' },
        isActive: { type: DataTypes.STRING, field: 'is_active', defaultValue: 'true' }
      },
      {
        sequelize,
        timestamps: false,
        createdAt: 'created_at',
        freezeTableName: true,
        tableName: 'groups',
        underscored: true
      });
  }

  static associate(models) {
    Group.belongsTo(models.Organization, { foreignKey: 'organization_id' });
    Group.belongsToMany(models.User, { through: 'user_group_members', timestamps: false });
  };

}

module.exports = Group;
