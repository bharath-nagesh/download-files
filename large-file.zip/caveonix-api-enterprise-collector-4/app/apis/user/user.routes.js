const UserController = require('./user.controller');

/**
 * @swagger
 * tags:
 *  - name: User
 *    description: User endpoints
 */
module.exports = class UserRouter {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.userController = new UserController();

      this.initRouter();
    }
  }

  /**
   * Route initialization and setup
   */
  initOrganization() {
    this.router.get(`${this.path}/group/:groupId`, this.userController.getGroup);
    this.router.post(`${this.path}/group`, this.userController.createGroup);
    this.router.put(`${this.path}/group/:groupId`, this.userController.updateGroup);
    this.router.put(`${this.path}/group/:groupId/user`, this.userController.addUsers);
    this.router.post(`${this.path}/group/:groupId/user`, this.userController.addUsers);
    /**
     * @swagger
     *
     * /api/organization/{orgId}/user/{userId}:
     *   get:
     *     tags:
     *       - User
     *     summary: Gets an user by its id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: userId
     *         description: The id of the specified user.
     *         in: path
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: User
     *       401:
     *         description: unauthorized
     */
    this.router.get(`${this.path}/:userId`, this.userController.getUser);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/user/:
     *   post:
     *     tags:
     *       - User
     *     summary: Creates an user
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/User'
     *     responses:
     *       200:
     *         description: user was created successfully
     *       401:
     *         description: unauthorized
     */
    this.router.post(`${this.path}/`, this.userController.createUser);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/user:
     *   put:
     *     tags:
     *       - User
     *     summary: Updates the specified user
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/User'
     *     responses:
     *       200:
     *         description: login
     *       401:
     *         description: unauthorized
     */
    this.router.put(`${this.path}/:userId`, this.userController.updateUser);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/user/{userId}:
     *   delete:
     *     tags:
     *       - User
     *     summary: Deletes an user by its id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: userId
     *         description: The id of the specified user.
     *         in: path
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: deleted user
     *       401:
     *         description: unauthorized
     */
    this.router.delete(`${this.path}/:userId`, this.userController.deleteUser);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/user/mfa/{userId}:
     *   post:
     *     tags:
     *       - User
     *     summary: Adds Multi Factory Authetication to User
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: userId
     *         description: The id of the specified user.
     *         in: path
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: created mfa
     *       401:
     *         description: unauthorized
     */
    this.router.post(`${this.path}/mfa/:userId`, this.userController.addMfa);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/user/mfa/{userId}/verifyMFA:
     *   post:
     *     tags:
     *       - User
     *     summary: Adds Multi Factory Authetication to User
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: userId
     *         description: The id of the specified user.
     *         in: path
     *         required: true
     *         type: string
     *       - name: mfaToken
     *         description: token
     *         in: body
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: verified mfa
     *       401:
     *         description: unauthorized
     */
    this.router.post(`${this.path}/mfa/:userId/verifyMFA`, this.userController.verifyMFA);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/user/mfa/{userId}:
     *   delete:
     *     tags:
     *       - User
     *     summary: Adds Multi Factory Authetication to User
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: userId
     *         description: The id of the specified user.
     *         in: path
     *         required: true
     *         type: string
     *       - name: mfaToken
     *         description: mfaToken of user (if not admin)
     *         in: query
     *         required: false
     *         type: string
     *     responses:
     *       200:
     *         description: removed mfa
     *       400:
     *         description: mfaToken is missing
     *       401:
     *         description: unauthorized
     */
    this.router.delete(`${this.path}/mfa/:userId`, this.userController.removeMfa);

  }

  initRouter() {
    this.router.get('/:userId/managed/organizations', this.userController.getUserManagedOrgs);
    this.router.post('/:userId/managed/organizations', this.userController.addManagedOrg);
    this.router.delete('/:userId/managed/organizations', this.userController.removeManagedOrg);
  }
};
