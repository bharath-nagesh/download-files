const Sequelize = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();
/**
 * @swagger
 * components:
 *   schemas:
 *     PolicyManager:
 *       type: object
 *       required:
 *         - name
 *         - condition
 *         - action
 *         - notification
 *         - organization_id
 *       properties:
 *         name:
 *           type: string
 *         condition:
 *           type: string
 *         action:
 *           type: string
 *         notification:
 *           type: string
 *         organization_id:
 *           type: string
 *         policy_past_window:
 *           type: string
 *         isActive:
 *           type: string
 * @param sequelize
 */
const PolicyManager = sequelize.define(
  'policyManager',
  {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    name: { type: Sequelize.STRING, allowNull: false },
    condition: { type: Sequelize.TEXT, allowNull: false },
    action: { type: Sequelize.INTEGER, allowNull: false },
    notification: { type: Sequelize.STRING, allowNull: false },
    organization_id: { type: Sequelize.INTEGER, field: 'organization_id', allowNull: false },
    policy_past_window: { type: Sequelize.STRING, field: 'policy_past_window', allowNull: true },
    isActive: { type: Sequelize.STRING, field: 'is_active',defaultValue:'enabled' },
    is_active: { type: Sequelize.STRING, field: 'is_active'}

  },
  { timestamps: true, freezeTableName: true, tableName: 'policy_manager', underscored: true }
);

PolicyManager.associate = (models) => {
  PolicyManager.belongsTo(models.Organization, { foreignKey: 'organization_id' });
  PolicyManager.belongsTo(models.anamolyActions, { foreignKey: 'action', targetKey: 'id' });
};

module.exports = PolicyManager;
