const checkId = require('../../../utils/checkId');
const errorHandler = require('../../../utils/errorHandler');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-policyManager.controller'
});
const paginate = require('../../middlewares/paginate.middleware');
const PolicyManagerService = require('./policyManager.service');
const policyManagerService = new PolicyManagerService();
const Validator = require('../../../utils/validator');

module.exports = class PolicyManagerController {
  async getAllpolicyManager(req, res) {
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    const orgId = req.params.orgId;
    try{
      const results = await policyManagerService.getAllpolicyManager(orgId, limit, offset);
      const itemCount = await policyManagerService.getAllpolicyManagerCount(orgId);
      results.forEach(function(object) {
        const Arr = object.notification.split(',');
        object.notification = Arr;
      });
      const pageCount = Math.ceil(itemCount / limit);
      res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        poc: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getpolicyManagerById(req, res) {
    const policyManagerId = req.params.policyManagerId;
    if (checkId(policyManagerId)) {
      logger.error({ policyManagerId }, 'Error with policyManagerId');
      const error = new Error('Error with policyManagerId');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try{
      const policyManager = await policyManagerService.getpolicyManagerById(policyManagerId);
      return res.json(policyManager);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async createPolicyManager(req, res) {
    const params = req.body;
    try {
      params.isActive = params.isActive ? params.isActive.toString().toLowerCase() : "enabled";
      await Validator.validateParams({
        name: 'required|string',
        action: 'required|integer',
        condition: 'required|string',
        jobName: 'required|string',
        anamoliScore: 'required|string',
        score: 'required|between:1,100',
        isActive: 'required|in:enabled,disabled,true',
        notification: 'nullable',
        policy_past_window: 'required|string'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const orgId = req.params.orgId;
    try {
      const policyManager = await policyManagerService.create(orgId, params);
      return res.json(policyManager);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async updatePolicyManager(req, res) {
    const params = req.body;
    try {
      params.isActive = params.isActive ? params.isActive.toString().toLowerCase() : null;
      await Validator.validateParams({
        name: 'required|string',
        action: 'required|integer',
        condition: 'required|string',
        jobName: 'required|string',
        anamoliScore: 'required|string',
        score: 'required|between:1,100',
        isActive: 'required|in:enabled,disabled',
        notification: 'nullable',
        policy_past_window: 'required|string'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const orgId = req.params.orgId;
    const policyManagerId = req.params.policyManagerId;
    try{
      const policyManager = await policyManagerService.updatePolicyManager(orgId, policyManagerId, params);
      return res.json(policyManager);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async deletePolicyManagerId(req, res) {
    const policyManagerId = req.params.policyManagerId;
    if (checkId(policyManagerId)) {
      logger.error({ policyManagerId }, 'Error with policyManagerId');
      const error = new Error('Error with policyManagerId');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try{
      const update = await policyManagerService.deletepolicyManagerId(policyManagerId);
      logger.info({ update, policyManagerId }, 'update');
      return res.json(update);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async deleteMultiplePolicyManagerId(req, res) {
    const policyManagerId = req.query.id;
    if (policyManagerId === undefined || policyManagerId === '') {
      logger.error({ policyManagerId }, 'Invalid policyManagerId');
      const error = new Error('Invalid policyManagerId');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try{
      const policyManagerIdArr = policyManagerId.split(',');
      const update = await policyManagerService.deleteMultiplePolicyManagerId(policyManagerIdArr);
      logger.info('Deleted Multiple Policy Managers');
      return res.json(update);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }
};
