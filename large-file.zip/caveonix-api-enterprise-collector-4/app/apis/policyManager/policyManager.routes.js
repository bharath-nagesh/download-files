const PolicyManagerController = require('./policyManager.controller');

/**
 * @swagger
 * tags:
 *  - name: PolicyManager
 *    description: Policy Manager endpoints
 */
module.exports = class PolicyManagerRoutes {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.policyManagerController = new PolicyManagerController();

      this.initOrganization();
    }
  }

  initOrganization() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/policyManager:
     *   get:
     *     tags:
     *       - PolicyManager
     *     summary: Gets a list of Policy Managers
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of policy managers
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/`, this.policyManagerController.getAllpolicyManager);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/policyManager/{policyManagerId}:
     *   get:
     *     tags:
     *       - PolicyManager
     *     summary: Gets a policyManager by it's id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: policyManagerId
     *         description: The id of the specified policyManager.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: policyManager
     */
    this.router.get(`${this.path}/:policyManagerId`, this.policyManagerController.getpolicyManagerById);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/policyManager:
     *   post:
     *     tags:
     *       - PolicyManager
     *     summary: Creates a Policy Manager
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: policyManagerId
     *         description: The id of the specified Policy Manager.
     *         in: path
     *         required: true
     *         type: string
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/PolicyManager'
     *     responses:
     *       200:
     *         description: policyManager
     */
    this.router.post(`${this.path}/`, this.policyManagerController.createPolicyManager);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/policyManager/{policyManagerId}:
     *   put:
     *     tags:
     *       - PolicyManager
     *     summary: Updates a Policy Manager
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: policyManagerId
     *         description: The id of the specified Policy Manager.
     *         in: path
     *         required: true
     *         type: string
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/PolicyManager'
     *     responses:
     *       200:
     *         description: policyManager
     */
    this.router.put(`${this.path}/:policyManagerId`, this.policyManagerController.updatePolicyManager);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/policyManager:
     *   delete:
     *     tags:
     *       - PolicyManager
     *     summary: Deletes a Policy Manager
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: id
     *         description: a comma delimited list of policy manager ids
     *         in: query
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: Deleted Policy Managers
     */
    this.router.delete(`${this.path}/`, this.policyManagerController.deleteMultiplePolicyManagerId);
  }
};
