const AnamolyActions = require('../anamolyActions/anamolyActions.model');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-policyManagerService.service'
});
const Organization = require('../organization/organization.model');
const PolicyManager = require('./policyManager.model');
const sequelize = require('sequelize');

module.exports = class PolicyManagerService {
  constructor() {
    logger.debug('called PolicyManagerService constructor');
  }

  async getpolicyManagerById(policyManagerId, opts) {
    const policyManager = await PolicyManager.findOne({
      where: { id: policyManagerId, $or: [{ is_active: { $ne: 'false' } }] },
      include: [{ model: Organization }, { model: AnamolyActions }]
    });
    try {
      if (policyManager) {
        if (policyManager.parameters) {
          const parameters = JSON.parse(policyManager.parameters);
          const email = parameters.email;
          if (email) {
            policyManager.setDataValue('email', email);
          }
        }
        return policyManager;
      }
    } catch (error) {
      return policyManager;
    }
  }

  async updatePolicyManager(orgId, policyManagerId, update) {
    update.organization_id = orgId;
    const name = update.name;
    const policyActionId = update.action;
    const existstatus = await this.checkPolicyManagerNameForUpdate(name, orgId, policyManagerId);
    if (existstatus) {
      const err = new Error('Duplicate Policy Manager name.');
      err.status = 400;
      throw err;
    }
    const Actionstatus = await this.checkPolicyManagerAction(policyActionId);
    const actionName = Actionstatus.action_name;
    if (actionName === 'Notification') {
      if (!update.notification || update.notification === undefined || update.notification === '') {
        const err = new Error('Please select at least one notification.');
        err.status = 400;
        throw err;
      }
    }
    await PolicyManager.update(update,
      { where: { id: policyManagerId } });
    return this.getpolicyManagerById(policyManagerId);
  }

  async create(orgId, params) {
    const name = params.name;
    params.organization_id = orgId;
    const policyActionId = params.action;
    const existstatus = await this.checkPolicyManagerName(name, orgId);
    if (existstatus) {
      const err = new Error('Duplicate Policy Manager name.');
      err.status = 400;
      throw err;
    }
    const Actionstatus = await this.checkPolicyManagerAction(policyActionId);
    const actionName = Actionstatus.action_name;
    if (actionName === 'Notification') {
      if (!params.notification || params.notification === undefined || params.notification === '') {
        const err = new Error('Please select at least one notification.');
        err.status = 400;
        throw err;
      }
    }
    const result = await PolicyManager.create(params);
    return this.getpolicyManagerById(result.id);
  }

  checkPolicyManagerAction(policyActionId) {
    return AnamolyActions.findOne({ where: { id: policyActionId } });
  }

  checkPolicyManagerName(name, orgId) {
    return PolicyManager.findOne({
      where: {
        name: sequelize.where(sequelize.fn('LOWER', sequelize.col('name')),
          sequelize.fn('lower', name)),
        $or: [{ is_active: { $ne: 'false' } }],
        organization_id: { $eq: orgId }
      }
    });
  }

  checkPolicyManagerNameForUpdate(name, orgId, policyManagerId) {
    return PolicyManager.findOne({
      where: {
        name: sequelize.where(sequelize.fn('LOWER', sequelize.col('name')),
          sequelize.fn('lower', name)),
        $or: [{ is_active: { $ne: 'false' } }],
        organization_id: { $eq: orgId },
        id: { $ne: policyManagerId }
      }
    });
  }

  async deletepolicyManagerId(policyManagerId) {
    await PolicyManager.update({ is_active: false }, { where: { id: policyManagerId } });
    return PolicyManager.findByPk(policyManagerId, { include: [{ model: Organization }] });
  }

  async deleteMultiplePolicyManagerId(policyManagerIdArr) {
    await PolicyManager.update({ is_active: false }, { where: { id: { $in: policyManagerIdArr } } });
    return PolicyManager.findAll({ where: { id: { $in: policyManagerIdArr } }, include: [{ model: Organization }] });
  }

  async getAllpolicyManager(orgId, limit, offset) {
    const policyManager = await PolicyManager.findAll({
      where: { $and: [{ is_active: { $ne: 'false' } }, { organization_id: orgId }] },
      order: [['id', 'ASC']],
      limit: limit,
      offset: offset,
      include: [{ model: Organization }, { model: AnamolyActions }]
    });
    try {
      if (policyManager) {
        for (let i = 0; i < policyManager.length; i++) {
          if (policyManager[i].parameters) {
            const parameters = JSON.parse(policyManager[i].parameters);
            const email = parameters.email;
            if (email) {
              policyManager[i].setDataValue('email', email);
            }
          }
        }
        return policyManager;
      }
    } catch (error) {
      return policyManager;
    }
  }

  getAllpolicyManagerCount(orgId) {
    return PolicyManager.count({ where: { $and: [{ is_active: { $ne: 'false' } }, { organization_id: orgId }] } });
  }
};
