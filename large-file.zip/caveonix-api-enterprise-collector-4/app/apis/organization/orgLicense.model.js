const { DataTypes, Model } = require('sequelize');

class OrgLicense extends Model {
  static init(sequelize) {
    return super.init({
      licenseType: {
        allowNull: false,
        field: 'license_type',
        type: DataTypes.STRING
      },
      licenseCode: {
        allowNull: true,
        field: 'license_code',
        type: DataTypes.STRING
      },
      kmsKeyId: {
        allowNull: true,
        field: 'kms_key_id',
        type: DataTypes.STRING
      },
      licenseCount: {
        field: 'license_count',
        type: DataTypes.INTEGER
      },
      unitCount: {
        field: 'unit_count',
        type: DataTypes.INTEGER
      },
      startDate: {
        allowNull: false,
        field: 'start_date',
        type: DataTypes.DATE
      },
      endDate: {
        allowNull: false,
        field: 'end_date',
        type: DataTypes.DATE
      },
      createdAt: {
        allowNull: false,
        field: 'created_at',
        type: DataTypes.DATE
      },
      isActive: {
        type: DataTypes.STRING,
        field: 'is_active'
      }
    },
    {
      sequelize,
      tableName: 'org_license',
      timestamps: false,
      underscored: true
    });
  }

  static associate(models) {
    OrgLicense.belongsTo(models.Organization, { foreignKey: 'organization_id' });
  };
}

module.exports = OrgLicense;
