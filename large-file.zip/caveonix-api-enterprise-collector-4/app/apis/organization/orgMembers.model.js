const Sequelize = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();

class OrgMembers extends Sequelize.Model {
  static init(sequelize) {
    return super.init({
        role_id: { type: Sequelize.INTEGER, field: 'role_id', primaryKey:'role_id' },
        organization_id: { type: Sequelize.INTEGER, field: 'organization_id', primaryKey:'organization_id' },
        user_id: { type: Sequelize.STRING, field: 'user_id' }
      },
      {
        sequelize,
        tableName: 'org_user_role_members',
        timestamps: true,
        underscored: true
      });
  }

  static associate(models) {
    OrgMembers.belongsTo(models.Role, {});
    OrgMembers.belongsTo(models.Organization, {});
    OrgMembers.belongsTo(models.User, {});
  };
}

module.exports = OrgMembers;
