const Sequelize = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();

class OrgCertificateMembers extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      organization_id: { type: Sequelize.INTEGER, field: 'organization_id' },
      certificate_id: { type: Sequelize.INTEGER, field: 'certificate_id' }
    },
    { sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'org_certificate_members',
      underscored: true
    });
  }
}

module.exports = OrgCertificateMembers;
