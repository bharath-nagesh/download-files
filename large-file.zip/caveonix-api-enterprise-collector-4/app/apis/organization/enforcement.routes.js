const express = require('express');
const EnforcementRouter = require('../enforcement/enforcement.routes');

const router = express.Router();

function setupEnforcementRoutes() {
  new EnforcementRouter('/:orgId/enforcement', router, 'org');
}

setupEnforcementRoutes();
module.exports = router;
