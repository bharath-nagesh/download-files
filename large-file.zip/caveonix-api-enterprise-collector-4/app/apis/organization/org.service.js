const AppCertificateControlMembers = require('../certificates/applicationCertification/applicationAssignedControls/appCertificateControlMember.model');
const AppCertificateMembers = require('../certificates/applicationCertification/applicationAssignedControls/applicationCertificateMember.model');
const ApplicationTagService = require('../application/applicationTag.service');
const applicationTagService = new ApplicationTagService();
const Asset = require('../asset/asset.model');
const ApplicationTag = require('../application/applicationTag.model');
const AuthorizationInfo = require('../authorizationInfo/authorizationInfo.model');
const Certificates = require('../certificates/certificates.model');
const RelatedLaws = require('./relatedLaws.model');
const config = require('../../../configure').get();
const fs = require('fs');
const { get, toLower } = require('lodash');
const HostingProvider = require('../hostingProvider/hostingProvider.model');
const CentralCollectorClient = require('../../../utils/centralCollector.client');
const Location = require('../location/location.model');
const logger = require('../../../utils/logger').logger;
const AssetRepoEndpoint = require('../assetRepoEndpoint/assetRepoEndpoint.model');
const Organization = require('./organization.model');
const OrgCertificateMembers = require('./orgCertificateMembers.model');
const OrgApiKeys = require('./orgApiKeys.model');
const OrgLicense = require('./orgLicense.model');
const caveoLicense = require('../../models/caveoLicense.model');
const OrgProductOffering = require('../productOfferings/orgProductOffering.model');
const PolicyGroup = require('../subApplication/subApplication.model');
const PolicySourceMembers = require('../../models/policySourceMember.model');
const ProductOfferings = require('../productOfferings/product_offerings.model');
const OrgVCenter = require('../../models/orgVcenter.model');
const AssetRepoEndpointService = require('../assetRepoEndpoint/assetRepoEndpoint.service');
const assetRepoEndpointService = new AssetRepoEndpointService();
const AWSKMSService = require('../aws/awsKMS.service');
const awsKMSService = new AWSKMSService();
const KeyGenerator = require('../../../utils/generateKeys');
const removeSpace = require('../../../utils/checkSpaces');
const rp = require('request-promise');
const sequelize = require('../../../config/db.conf').getConnection();
const { QueryTypes } = require('sequelize');
const uuid = require('uuid/v4');
const _ = require('lodash');
const isAppliance = require('../../../utils/isAppliance');
const SERVICE_TYPE = isAppliance() ? 'ec' : 'centralcollector';
const cc_timeout = config.cc_timeout || 15000;

const loggerLabel = 'OrgService';

module.exports = class OrgService {
  constructor() {
    logger.debug('called OrgService constructor');
    this.keyGenerator = new KeyGenerator();
  }

  //To get organization along with its chain.
  /*
  orgId : int - the ID of the org that we want to the org chain for
  all: bool - if all is true, give full output of organization information, if false return the list of IDs

  return: array of Org Objects
   */
  async getOrgChain(orgId, all = false, dropdown = false, type = 'all') {
    const csp = await Organization.findByPk(orgId, { attributes: ['id', 'name', 'type'] });
    let reportingOrgs;
    let data;
    if (csp.type === 'SaaSProvider') {
      reportingOrgs = await sequelize.query(`select oc.organization_id as reporting_org_chain_list from org_chains oc join organizations o on o.id = oc.organization_id where oc.reporting_organization_id = -1 and o.is_active != 'false' ;`, {
        replacements: { orgId },
        type: sequelize.QueryTypes.SELECT
      });
    } else {
      reportingOrgs = await sequelize.query(`SELECT reporting_org_chain_list(:orgId)`, {
        replacements: { orgId },
        type: sequelize.QueryTypes.SELECT
      });
    }
    reportingOrgs = reportingOrgs.map(o => { return o.reporting_org_chain_list; });
    reportingOrgs.push(parseInt(orgId));
    data = reportingOrgs;
    if (all) {
      data = await Organization.findAll({ where: { id: reportingOrgs } });
      const orgIds = data.map(o => {
        return o.id;
      });
      const orgData = await sequelize.query(`SELECT o.*, a.connection_name FROM organizations o  left join asset_repo_endpoints a on a.id = o.asset_repo_endpoint_id  where o.id in (:orgIds)`, {
        replacements: { orgIds },
        type: sequelize.QueryTypes.SELECT
      });
      data = data.map(d => {
        const o = orgData.find(t => t.id === d.id);
        d.aliasName = o.alias_name;
        d.asset_repo_endpoint_id = o.asset_repo_endpoint_id;
        d.connection_name = o.connection_name;
        return d;
      });
    }
    if (type && type.toLowerCase() === 'provider') {
      data = data.filter(q => {
        return ['Provider'].includes(q.type);
      });
    }

    if (dropdown === 'true') {
      if (!_.isNaN(data[0])) return data;
      data = data.map(q => {
        const obj = {
          id: q.id,
          name: q.name,
          aliasName: q.aliasName,
          type: q.type,
          isActive: q.is_active,
          source: q.source,
          organization_id: q.id,
          fullName: `${q.alias_name} (${q.name})`
        };
        if (q.asset_repo_endpoint_id) {
          obj.assetRepoEndpoints = {
            id: q.asset_repo_endpoint_id,
            connectionName: q.connection_name
          };
        }

        return obj;
      });
    }
    return data;
  }

  /**
   * this method used for get default application of given organization Id
   * @param orgId : int-the organization Id for that we want default application
   * @returns default Application of given Org Id
   */
  async getDefaultApplication(orgId) {
    return ApplicationTag.findOne({ where: { $and: [{ name: 'Application' }, { organization_id: orgId }] } });
  }

  /**
   * this method used for get default sub-application of given organization Id
   * @param orgId : int-the organization Id for that we want default sub-application
   * @returns default sub-Application of given Org Id
   */
  async getDefaultSubApplication(orgId) {
    return PolicyGroup.findOne({ where: { $and: [{ name: 'Sub-Application' }, { organization_id: orgId }] } });
  }

  async getTenants(orgId, dropdown = false, type = 'all') {
    if (type && type === 'provider') return [[], 0];
    let condition = ['false'];
    let reportingOrgs;
    let attributes = { exclude: [] };
    let include = !isAppliance() ? [
      { model: Certificates },
      { model: ProductOfferings }
    ] : [];
    if (dropdown && dropdown === 'true') {
      condition = ['false', 'disabled', 'unmanaged'];
      attributes = ['id', 'name', 'aliasName', 'fullName', 'type', 'isActive', 'source', ['id', 'organization_id']];
      include = [];
    }
    const csp = await Organization.findByPk(orgId, { attributes: ['id', 'name', 'type', 'aliasName', 'fullName'] });
    if (csp.type === 'SaaSProvider') {
      reportingOrgs = await sequelize.query(`select oc.organization_id as reporting_org_chain_list from org_chains oc join organizations o on o.id = oc.organization_id where oc.reporting_organization_id = -1 and o.is_active != 'false' ;`, {
        replacements: { orgId },
        type: sequelize.QueryTypes.SELECT
      });
    } else {
      reportingOrgs = await sequelize.query(`SELECT reporting_org_chain_list(:orgId)`, {
        replacements: { orgId },
        type: sequelize.QueryTypes.SELECT
      });
    }
    const reportingOrgIds = reportingOrgs.map((o) => {
      return o.reporting_org_chain_list;
    });
    const tenants = await Organization.findAndCountAll({
      attributes,
      where: {
        type: ['Organization', 'Provider'],
        isActive: { $notIn: condition },
        id: reportingOrgIds
      },
      include
    });
    const orgIds = tenants.rows.map(o => {
      return o.id;
    });
    if (orgIds.length == 0) return [[], 0];
    const orgChainViewData = await sequelize.query(`SELECT organization_id, path FROM org_chain_view where organization_id in (:orgIds)`, {
      replacements: { orgIds },
      type: sequelize.QueryTypes.SELECT
    });
    tenants.rows = tenants.rows.map(o => {
      const pathData = orgChainViewData.filter(d => d.organization_id === o.id);
      o.dataValues.path = pathData.length > 0 ? pathData[0].path : null;
      o.dataValues.fullName = `${o.dataValues.aliasName} (${o.dataValues.name})`;
      return o;
    });
    if (!dropdown || dropdown === 'false') {
      return [tenants.rows.map(tenant => {
        tenant.setDataValue('ParentOrganization', [csp]);
        return tenant;
      }), tenants.count];
    }
    return [tenants.rows, tenants.count];
  }

  async getTenantById(tenantId) {
    const tenant = await Organization.findByPk(tenantId, {
      where: { type: 'Organization' },
      include: [
        { model: Certificates },
        {
          model: ProductOfferings,
          order: [['name', 'DESC']]
        },
        { model: Organization, as: 'ParentOrganization' },
        { model: AssetRepoEndpoint },
        { model: OrgLicense },
        { model: AuthorizationInfo },
        { model: OrgApiKeys }
      ]
    });
    if (!tenant) {
      const e = new Error('Not Found');
      e.status = 404;
      throw e;
    }
    tenant.ProductOfferings.sort((po1, po2) => {
      if (po1.id % 2 === po2.id % 2) {
        if (po1.id > po2.id) return 1;
        if (po1.id < po2.id) return -1;
        return 0;
      }
      return po1.id % 2 - po2.id % 2;
    });

    if (config.saas && tenant.type !== 'SaaSProvider' && tenant.ParentOrganization[0].id == -1) {
      const csp = await Organization.findOne({ where: { type: 'SaaSProvider' } });
      tenant.setDataValue('ParentOrganization', [csp]);
    } else if (!config.saas && tenant.type !== 'Provider' && tenant.ParentOrganization[0].id == -1) {
      const csp = await Organization.findOne({ where: { type: 'Provider' } });
      tenant.setDataValue('ParentOrganization', [csp]);
    }
    tenant.generateOrgApiKey();
    tenant.setDataValue('fullName', `${tenant.aliasName} (${tenant.name})`);
    tenant.setDataValue('isEnterprise', tenant.isEnterprise());
    return tenant;
  }

  // if(?type=Organization)  //list=true
  //   If orgId is 'Provider' then it will display only provider.
  //   If orgId is other than 'Provider' then it will give it's chain.
  // if(?type=Sub-Organization) //list=true
  //   If orgId is 'Provider' then it will display provider along with it's first level sub-organizations and sub-organization chain.
  //   If orgId is other than 'Provider' then it will give it's chain.

  async getProvider_SubOrg_SubOrgChain(orgId, type, limit, offset, listParam = null) {

    const idArr = [];
    let ctr = 0;
    const org = await Organization.findOne({
      where: {
        id: orgId,
        $or: [{ isActive: { $ne: 'false' } }]
      },
      include: [{ model: Certificates }, { model: ProductOfferings }]
    });

    if (org.type === 'Provider') {
      if (!type) {
        const err = new Error('Invalid value for type.');
        err.status = 400;
        throw err;
      } else {
        if (type.toLowerCase() === 'organization') {
          idArr.push(org);
          return idArr;
        }
        if (type.toLowerCase() === 'sub-organization') {
          const org_chain = await Organization.getOrgChain(orgId, true);
          org_chain.filter(object => {
            idArr[ctr] = object.dataValues.organization_id;
            ctr++;
          });
          return this.getCompleteOrgInfo(idArr, listParam, limit, offset);
        }
      }
    }
    const orgChain = await Organization.getOrgChain(orgId, false);

    return this.getCompleteOrgInfo(orgChain, listParam, limit, offset);
  }

  /**
   *
   * @param orgArr:Array of organization Id that we want to get complete organization Info
   * @param listParam: bool - if listParam is true then it returns info of organization which is_active status is true,enabled and disabled
   *  if listParam is false then return the info of organization which is_active status is true,enabled
   * @returns array of complete information of organizations
   */
  getCompleteOrgInfo(orgArr, listParam = null, limit = null, offset = null) {

    if (listParam === 'false') {
      return Organization.findAll({
        where: {
          id: { $in: orgArr },
          $and: [{ isActive: { $ne: 'disabled' } }, { isActive: { $ne: 'false' } }, { isActive: { $ne: 'unmanaged' } }]
        },
        include: [{
          model: Organization,
          as: 'ParentOrganization'
        }, { model: Certificates }, { model: ProductOfferings }],
        order: [['id', 'ASC']],
        limit: limit,
        offset: offset
      });
    }
    return Organization.findAll({
      where: { id: { $in: orgArr }, $and: [{ isActive: { $ne: 'false' } }] },
      include: [{
        model: Organization,
        as: 'ParentOrganization'
      }, { model: Certificates }, { model: ProductOfferings }],
      order: [['id', 'ASC']],
      limit: limit,
      offset: offset
    });
  }

  /**
   * @param orgId:int - the ID of the org that we want to the org chain
   * If orgId is 'Provider' then it will display provider along with it's first level organizations and sub-organizations and sub-organization chain.
   * If orgId is other than 'Provider' then it will give it's chain along with him.
   * @returns  array of Org Chain
   */
  async getProvider_Org_SubOrgChain(orgId, limit, offset, listParam = null) {
    let idArr = [];
    let ctr = 0;
    const org = await Organization.findOne({ where: { id: orgId, $or: [{ isActive: { $ne: 'false' } }] } });
    if (org.type === 'Provider') {
      const org_chain = await Organization.getOrgChain(orgId, true);
      idArr = _.map(org_chain, 'dataValues.organization_id');

      const organizationId = await sequelize.query('select organization_id from org_chains where parent_organization_id in(select parent_organization_id from org_chains where organization_id= ?)', {
        replacements: [orgId],
        model: Organization
      });
      organizationId.filter(object => {
        if (object.dataValues.organization_id !== orgId) {
          idArr = idArr.concat(object.dataValues.organization_id);
        }
      });
      let organizations = await this.getCompleteOrgInfo(idArr, listParam, limit, offset);
      organizations = _.map(organizations, function (a) {
        if (a.type === 'Organization') {
          a = _.set(a, 'dataValues.ParentOrganization[0]', org);
          return a;
        }
        return a;
      });
      return organizations;
    }
    const org_chain = await Organization.getOrgChain(orgId, true);
    org_chain.filter(object => {
      idArr[ctr] = object.dataValues.organization_id;
      ctr++;
    });
    const defaultDetails = await Organization.findOne({ where: { type: 'Provider' } });
    let organizations = await this.getCompleteOrgInfo(idArr, listParam, limit, offset);
    organizations = _.map(organizations, function (a) {
      if (a.type === 'Organization') {
        a = _.set(a, 'dataValues.ParentOrganization[0]', defaultDetails);
        return a;
      }
      return a;
    });
    return organizations;
  }

  /**
   *
   * @param orgId: int- the ID of the organization that we want to the org chain for
   * @returns organization details of given orgId
   */

  async getOrganizationById(orgId, removeDefault = true, filterOrgId = null) {
    logger.debug(`getting organization by id`, { loggerLabel });
    logger.silly(`for org ${orgId}`, { loggerLabel });

    if (filterOrgId) {
      filterOrgId = parseInt(filterOrgId);
      const orgChain = await Organization.getOrgChain(orgId);
      if (!orgChain.includes(filterOrgId)) {
        const err = new Error('Unauthorized');
        err.status = 401;
        throw err;
      }
      orgId = filterOrgId;
    }

    const organization = await Organization.findOne({
      where: { id: orgId, $or: [{ isActive: { $ne: 'false' } }] },
      include: [
        {
          model: Organization,
          as: 'ParentOrganization'
        },
        { model: AuthorizationInfo }]
    });
    if (!organization) {
      const e = new Error('Organization not Found');
      e.status = 404;
      throw e;
    }

    if (removeDefault && get(config, 'saas') && get(organization, 'type') !== 'SaaSProvider' && +get(organization, 'ParentOrganization[0].id') === -1) {
      const csp = await Organization.findOne({ where: { type: 'SaaSProvider' } });
      organization.setDataValue('ParentOrganization', [csp]);
    } else if (removeDefault && !get(config, 'saas') && get(organization, 'type') !== 'Provider' && +get(organization, 'ParentOrganization[0].id') === -1) {
      const csp = await Organization.findOne({ where: { type: 'Provider' } });
      organization.setDataValue('ParentOrganization', [csp]);
    }
    organization.setDataValue('caveoLicense', await caveoLicense.findOne());
    organization.generateOrgApiKey();
    organization.setDataValue('isEnterprise', organization.isEnterprise());
    return organization;
  }

  /**
   *
   * @param orgIdArr -array of orgnization Id used for get details of organization Id given in array
   * @returns array of multiple organization details
   */
  async getMultipleOrg(orgIdArr) {
    let organizations = await Organization.findAll({ where: { id: { $in: orgIdArr } } });
    organizations = organizations.map(o => {
      o.dataValues.fullName = `${o.aliasName} (${o.name})`;
      return o;
    });
    return organizations;
  }

  /**
   * this method used for insert entry into org_chains while  creating orgnization
   * @param parentOrgId: int-parent organization Id of given organization
   * @param  orgId : int-id of organization which we created
   */
  addOrgChain(parentOrgId, orgId, userOrgId = 0) {
    return sequelize.query('insert into org_chains(organization_id, parent_organization_id, created_at, updated_at, reporting_organization_id) values ($1,-1, now(), now(), $2)', {
      bind: [orgId, parentOrgId],
      model: Organization,
      type: QueryTypes.INSERT
    });
  }

  /**
   * this method used for update entry of org_chains while  updating orgnization
   * @param parentOrgId: int-parent organization Id of given organization
   * @param  orgId : int-id of organization which we update
   */
  updateOrgChain(orgId, parentOrgId) {
    return sequelize.query('update org_chains set parent_organization_id=$2 where organization_id=$1', {
      bind: [orgId, parentOrgId],
      model: Organization,
      type: QueryTypes.UPDATE
    });
  }

  /**
   * create Organization
   * @param {integer} orgId
   * @param {object} params
   */
  async createFirstOrganization(orgId, params) {
    const { orgName, aliasName, phone, email, addressLine1, addressLine2, city, state, zip, country, biaValue } = params;
    //this change is specific to orgId 0 because sequelise does not handle primary key as 0 (INTEGER) and set it to default value.
    orgId = orgId === 0 ? orgId.toString() : orgId;
    return Organization.create(
      {
        id: orgId, name: orgName, aliasName, phone, email, addressLine1, addressLine2, city, state, zip, country, bia_value: biaValue, type: 'Organization'
      }
    );
  }

  /**
   * Updates Organization
   * @param {integer} orgId
   * @param {object} params
   */
  async updateOrganizationName(orgId, params) {
    const { orgName, aliasName, phone, email, addressLine1, addressLine2, city, state, zip, country, biaValue } = params;
    return Organization.update(
      { name: orgName, aliasName, phone, email, addressLine1, addressLine2, city, state, zip, country, bia_value: biaValue },
      {
        where: { id: orgId }
      }
    );
  }

  // This method will create new organization under parentOrgId.
  // If we are trying to create organization under 'Provider' then it will create Organization or Sub-Organization according to type parameter.
  // If we are trying to create organization under any other Organization or Sub-Organization then it will only create Sub-Organization.
  // After organization creation it will also put new entry with organization_id and parent_organization_id in org_chains table.

  //if organization type is sub-Organization or not given: then: get chain of parentOrgId to validate organization name and set 'sub-Organization' as organization type,
  //if not then get first level organization and sub-Organization along with provider to validate organization name and set Organization' as organization type,
  //'Default' for parent Organization.
  async createOrganization(params, userOrgId, parentOrgId, userId, token,) {
    params.aliasName = removeSpace.checkMultiSpace(params.aliasName);
    params.name = params.name ? params.name : uuid();
    if (config.saas) {
      params.orgType = 'SaaS';
      params.source = params.source ? params.source : 'Direct';
    }
    logger.info({ params, userOrgId, parentOrgId }, 'Creating New Org ');
    params.autoAssignment = params.autoAssignment ? params.autoAssignment.toLowerCase() : 'false';
    if (params.type && params.type === 'Provider') {
      params.billingCycle = params.billingCycle ? params.billingCycle : 'monthly';
    } else {
      delete params.billingCycle;
    }
    if (params.autoAssignment == 'true') {
      const valueArr = params.values;
      const resourceType = params.resourceType;
      const asset_repo_endpoint_id = params.asset_repo_endpoint_id;

      const mappingList = await sequelize.query(`SELECT count(id)  FROM (SELECT *, unnest(string_to_array(value, ','))::VARCHAR as allvalue FROM "organization_vcenter_mappings") as "OrgVCenter" WHERE "OrgVCenter"."asset_repo_endpoint_id" = :asset_repo_endpoint_id
      AND "OrgVCenter"."type" = :resourceType AND "OrgVCenter"."allvalue" IN (:valueArr)`,
        { replacements: { valueArr, resourceType, asset_repo_endpoint_id }, type: QueryTypes.SELECT });

      if (parseInt(mappingList[0].count) > 0) {
        const err = new Error('Organization with same resource mapping already exists');
        err.status = 400;
        throw err;
      }
    }
    // todo correct this flow. this is confusing and can cause a lot of bugs
    // if creating a sub organization
    if (!params.type || params.type.toLowerCase() === 'sub-organization') {
      params.type = 'Sub-Organization';
      const org = await Organization.create(params);
      const orgId = get(org, 'id');
      await this.addOrgChain(parentOrgId, orgId, userOrgId);
      await this.createOrgProductOfferingMembers(orgId, params);
      await this.createOrgCertificateMembers(orgId, params);
      if (params.autoAssignment == 'true') {
        await assetRepoEndpointService.addOrgVcenterMapping(orgId, params.asset_repo_endpoint_id, params.resourceType, params.values);
      }
      return org;
    }

    params.parentOrgId = parentOrgId;
    params.type = params.type ? params.type : 'Organization';
    if (!params.bia_value) {
      params.bia_value = 'low';
    }
    params.impactLevel = 1;
    const org = await Organization.create(params);
    const orgId = get(org, 'id');
    await this.addOrgChain(parentOrgId, orgId, userOrgId);
    await this.createOrgProductOfferingMembers(orgId, params);
    await this.createOrgCertificateMembers(org.id, params);
    await this.createApplicationAndApplicationTag(orgId, params);
    await this.upsertOrgLicense(orgId, params, 'create');
    await this.createOrgApiKeys(orgId);
    if (params.autoAssignment == 'true') {
      await assetRepoEndpointService.addOrgVcenterMapping(orgId, params.asset_repo_endpoint_id, params.resourceType, params.values);
    }
    return org;
  }

  /**
   *
   * @param orgId:int-the Id of Organization which we want to update
   * @param params:the parameters for update the organization
   * @returns details of organization which we update
   */
  async updateOrg(orgId, params) {
    delete params.name;
    params.aliasName = removeSpace.checkMultiSpace(params.aliasName);
    const existingCertificates = [];
    const locParams = {};
    locParams.addressLine1 = params.addressLine1;
    locParams.addressLine2 = params.addressLine2;
    locParams.city = params.city;
    locParams.country = params.country;
    locParams.email = params.email;
    locParams.state = params.state;
    locParams.zip = params.zip;

    params.autoAssignment = params.autoAssignment ? params.autoAssignment.toLowerCase() : 'false';
    await OrgVCenter.destroy({ where: { organization_id: orgId } });
    if (params.autoAssignment == 'true') {
      const valueArr = params.values;
      const resourceType = params.resourceType;
      const asset_repo_endpoint_id = params.asset_repo_endpoint_id;

      const mappingList = await sequelize.query(`SELECT count(id)  FROM (SELECT *, unnest(string_to_array(value, ','))::VARCHAR as allvalue FROM "organization_vcenter_mappings") as "OrgVCenter" WHERE "OrgVCenter"."asset_repo_endpoint_id" = :asset_repo_endpoint_id
      AND "OrgVCenter"."type" = :resourceType AND "OrgVCenter"."allvalue" IN (:valueArr) AND organization_id != :orgId `,
        { replacements: { valueArr, resourceType, asset_repo_endpoint_id, orgId }, type: QueryTypes.SELECT });

      if (parseInt(mappingList[0].count) > 0) {
        const err = new Error('Organization with same resource mapping already exists');
        err.status = 400;
        throw err;
      }
      await assetRepoEndpointService.addOrgVcenterMapping(orgId, params.asset_repo_endpoint_id, params.resourceType, params.values);
    }
    // getting the current organization's details
    const orgDetails = await Organization.findByPk(orgId, { include: [{ model: Certificates }] });
    orgDetails.Certificates.filter(object => {
      existingCertificates.push(object.id);
    });

    // ending things before they get started
    const orgType = toLower(get(orgDetails, 'type'));
    if (orgType === 'provider' || orgType === 'organization') {
      // const nameExists = await this.checkOrgNameExists(orgId, params.aliasName);
      // if (nameExists) {
      //   const err = new Error('Duplicate Organization name.');
      //   err.status = 400;
      //   throw err;
      // }
    }

    // todo optimize this. there is massive code duplication that can lead to massive bugs
    if (orgDetails.type === 'Provider') {
      params.type = 'Provider';

      // updating the provider and everything associated with it
      await orgDetails.update(params);
      await this.updateOrgProductOfferingMembers(orgId, params);
      await this.removeChildCertificates(orgId, existingCertificates, params.certificate_id);
      await this.updateOrgCertificateMembers(orgId, params);

      // setting up the application associations
      const defaultApplicationDetails = await ApplicationTag.findOne({ where: { $and: [{ name: 'Application' }, { organization_id: orgId }] } });
      const defaultApplicationId = defaultApplicationDetails.id;
      await applicationTagService.createApplicationCertificateMember(defaultApplicationId, params.certificate_id);
      await Location.update(locParams, { where: { name: 'Data Center 1' } });
      await HostingProvider.update({ pocEmail: params.email, pocPhone: params.phone }, { where: { name: 'In-House' } });
      return this.getOrganizationById(orgId);
    } else if (orgDetails.type === 'Organization') {
      params.type = 'Organization';
      const defaultDetails = await Organization.findOne({ where: { type: 'SaaSProvider' } });
      const parentId = defaultDetails.id;
      params.parentOrgId = parentId;
      delete params.billingCycle;

      // updating the current organization and everything associated with it
      const org = await orgDetails.update(params);
      await this.updateOrgChain(org.id, parentId);
      await this.updateOrgProductOfferingMembers(orgId, params);
      await this.removeChildCertificates(orgId, existingCertificates, params.certificate_id);
      await this.updateOrgCertificateMembers(orgId, params);
      await this.upsertOrgLicense(orgId, params, 'update');

      // setting up the application associations
      const defaultApplicationDetails = await ApplicationTag.findOne({ where: { $and: [{ name: 'Application' }, { organization_id: orgId }] } });
      if (defaultApplicationDetails) {
        const defaultApplicationId = defaultApplicationDetails.id;
        await applicationTagService.createApplicationCertificateMember(defaultApplicationId, params.certificate_id);
        return this.getOrganizationById(orgId);
      } else {
        await this.createApplicationAndApplicationTag(orgId, params);
        const defaultApplicationDetails = await ApplicationTag.findOne({ where: { $and: [{ name: 'Application' }, { organization_id: orgId }] } });
        const defaultApplicationId = defaultApplicationDetails.id;
        await applicationTagService.createApplicationCertificateMember(defaultApplicationId, params.certificate_id);
        return this.getOrganizationById(orgId);
      }
    } else {
      params.type = 'Sub-Organization';
      const parentId = params.parentOrgId;
      if (orgId === parentId) {
        const err = new Error('Organization and Parent Organization can not be same.');
        err.status = 400;
        throw err;
      }
      delete params.billingCycle;

      const org = await orgDetails.update(params);
      await this.updateOrgChain(org.id, parentId);
      await this.updateOrgProductOfferingMembers(orgId, params);
      await this.removeChildCertificates(orgId, existingCertificates, params.certificate_id);
      await this.updateOrgCertificateMembers(orgId, params);
      return this.getOrganizationById(orgId);
    }
  }

  /**
   * this method used for insert entry into org_certificate_members
   * @param orgId:int-organization Id for that we assigned certificates
   * @param params: parameters for insert entry into org_certificate_members
   * @returns result of created org certificate members
   */
  async createOrgCertificateMembers(orgId, params) {
    const createCertificate = {};
    const resultArray = [];
    if (params.certificate_id) {
      const certificate_id = params.certificate_id;
      if (certificate_id.charAt(0) !== '') {
        const certificateArray = certificate_id.split(',');
        if (certificateArray.length > 0) {
          createCertificate.organization_id = orgId;
          for (let c = 0; c < certificateArray.length; c++) {
            createCertificate.certificate_id = certificateArray[c];
            const result = await OrgCertificateMembers.create(createCertificate);
            resultArray.push(result);
          }
        }
      }
    }
    return resultArray;
  }

  /**
   * this method used for update entry into org_certificate_members
   * @param orgId:int-organization Id for that we assigned certificates
   * @param params: parameters for update entry into org_certificate_members
   * @returns result of udateed org certificate members
   */
  async updateOrgCertificateMembers(orgId, params) {
    const updateCertificate = {};
    const resultArray = [];
    if (params.certificate_id || (params.certificate_id) !== undefined) {
      await OrgCertificateMembers.destroy({ where: { organization_id: orgId } });
      const certificate_id = params.certificate_id;
      if (certificate_id.charAt(0) !== '') {
        const certificateArray = certificate_id.split(',');
        if (certificateArray.length > 0) {
          updateCertificate.organization_id = orgId;
          for (let c = 0; c < certificateArray.length; c++) {
            const certificate = certificateArray[c];
            updateCertificate.certificate_id = certificate;
            const result = await OrgCertificateMembers.create(updateCertificate);
            resultArray.push(result);
          }
        }
      }
    }
    return resultArray;
  }

  /**
   * this method used for insert entry into org_product_offering
   * @param orgId:int-organization Id for that we assigned product_offering
   * @param params: parameters for insert entry into org_product_offering
   * @return result of created product offering members
   */
  async createOrgProductOfferingMembers(orgId, params) {
    const createProductOfferingMembers = {};
    const resultArray = [];
    if (params.product_offering_id) {
      const product_offering_id = params.product_offering_id;
      if (product_offering_id.charAt(0) !== '') {
        const productOfferingIdArray = product_offering_id.split(',');
        if (productOfferingIdArray.length > 0) {
          createProductOfferingMembers.organization_id = orgId;
          for (let p = 0; p < productOfferingIdArray.length; p++) {
            const product = productOfferingIdArray[p];
            createProductOfferingMembers.product_offering_id = product;
            const result = await OrgProductOffering.create(createProductOfferingMembers);
            resultArray.push(result);
          }
        }
      }
    }
    return resultArray;
  }

  /**
   * this method used for update entry into org_product_offering
   * @param orgId:int-organization Id for that we assigned product_offering
   * @param params: parameters for update entry into org_product_offering
   * @return array of updated product Offering Members
   */
  async updateOrgProductOfferingMembers(orgId, params) {
    const resultArray = [];
    if (!params.product_offering_id) {
      params.product_offering_id = '';
    }
    const updateProductOfferingMembers = {};
    if (params.product_offering_id || (params.product_offering_id) !== undefined) {
      await OrgProductOffering.destroy({ where: { organization_id: orgId } });
      const product_offering_id = params.product_offering_id;
      if (product_offering_id.charAt(0) !== '') {
        const productOfferingIdArray = product_offering_id.split(',');
        if (productOfferingIdArray.length > 0) {
          updateProductOfferingMembers.organization_id = orgId;
          for (let p = 0; p < productOfferingIdArray.length; p++) {
            const product = productOfferingIdArray[p];
            updateProductOfferingMembers.product_offering_id = product;
            const result = await OrgProductOffering.create(updateProductOfferingMembers);
            resultArray.push(result);
          }
        }
      }
    }
    return resultArray;
  }

  /**
   * this method used for remove child certificates
   * @param orgId:int-organization Id for getting org chain
   * @param existingCertificates: existing certificates assigned to org
   * @param newCertificates: new certificates which assigned to org
   */
  async removeChildCertificates(orgId, existingCertificates, newCertificates) {
    const childArr = [];
    const orgchainArray = [];
    let ctr2 = 0;
    const applicationArray = [];
    let ctr1 = 0;
    const orgchain = await Organization.getOrgChain(orgId, true);
    orgchain.filter(object => {
      if (object.dataValues.organization_id !== orgId) {
        childArr.push(object.dataValues.organization_id);
      }
    });
    if (orgchain.length > 0) {
      orgchain.filter(org => {
        orgchainArray[ctr2] = org.dataValues.organization_id;
        ctr2++;
      });
    }
    if (newCertificates && newCertificates.charAt(0) === '') {
      await OrgCertificateMembers.destroy({ where: { organization_id: { $in: childArr } } });
      const applicationTags = await ApplicationTag.findAll({ where: { organization_id: { $in: orgchainArray } } });
      if (applicationTags.length > 0) {
        applicationTags.filter(applicationTag => {
          applicationArray[ctr1] = applicationTag.dataValues.id;
          ctr1++;
        });
        await AppCertificateMembers.destroy({ where: { $and: [{ application_tag_id: { $in: applicationArray } }, { certificate_id: { $in: existingCertificates } }] } });
        await AppCertificateControlMembers.destroy({ where: { $and: [{ application_id: { $in: applicationArray } }, { certificate_id: { $in: existingCertificates } }] } });
      }
    } else {
      if (newCertificates) {
        const certificateArray = newCertificates.split(',');
        const removedCertificates = [];
        if (certificateArray.length > 0 && existingCertificates.length > 0) {
          existingCertificates.filter(cert => {
            if (!certificateArray.includes('' + cert + '')) {
              removedCertificates.push(cert);
            }
          });
          if (removedCertificates.length > 0) {
            await OrgCertificateMembers.destroy({
              where: {
                organization_id: { $in: childArr },
                certificate_id: { $in: removedCertificates }
              }
            });
            const applicationTags = await ApplicationTag.findAll({ where: { organization_id: { $in: orgchainArray } } });
            if (applicationTags.length > 0) {
              applicationTags.filter(applicationTag => {
                applicationArray[ctr1] = applicationTag.dataValues.id;
                ctr1++;
              });
              await AppCertificateMembers.destroy({ where: { $and: [{ application_tag_id: { $in: applicationArray } }, { certificate_id: { $in: removedCertificates } }] } });
              await AppCertificateControlMembers.destroy({ where: { $and: [{ application_id: { $in: applicationArray } }, { certificate_id: { $in: removedCertificates } }] } });
            }
          }
        }
      }
    }
  }

  /**
   * this method used to check organization name is exist or not
   * @param orgId:int-organization Id for getting organization chain
   * @return bool: true if orgName exists
   */
  async checkOrgNameExists(orgId, aliasName) {
    const org = await Organization.findOne({
      where: {
        aliasName: sequelize.where(sequelize.fn('LOWER', sequelize.col('alias_name')), sequelize.fn('lower', aliasName)),
        type: { $in: ['Provider', 'Organization'] },
        id: { $ne: orgId },
        isActive: { $ne: 'false' }
      },
      order: [['id', 'ASC']]
    });
    return org != null;
  }

  checkOrgId(id) {
    if (id < -1 || isNaN(id)) return true;
    return false;
  }

  /**
   * this method used for find top level Organization
   */
  async getTopLevelOrgs() {
    const orgs = await Organization.findAll({ where: { type: 'Organization' }, include: [{ all: true }] });
    logger.info({ orgs }, ' top level orgs');
    return orgs;
  }

  /**
   * this method used for delete organizattion
   * @param orgId: int-the organization Id which we want to delete
   * @param userToken: userToken which required for delete org
   * @param user: int- Id of the user
   * @param userOrgId: int- organization id of the user
   * @returns details of deleted organization
   */
  async deleteOrg(orgId) {
    const orgChain = await Organization.getOrgChain(orgId);
    const assetCountForOrg = await Asset.count({ where: { organizationId: orgChain, is_active: { $ne: 'false' } } });
    if (assetCountForOrg > 0) {
      const e = new Error(`Cannot delete an organization with assets associated with it or it's sub-organizations`);
      e.status = 400;
      throw e;
    }
    await OrgVCenter.destroy({ where: { organization_id: orgId } });
    await OrgProductOffering.destroy({ where: { organization_id: orgId } });
    return Organization.update({ isActive: 'false' }, { where: { id: orgChain } });
  }

  /**
   * this method used for update Caveo License
   * @param params: parameters for update caveo_license
   * @returns details of updated caveo license
   */
  async updateCaveoLicense(params, fqdn) {
    const { orgId, userId, userToken } = params;
    const licenseKeyFile = params.licenseKey;
    const publicKeyFile = params.publicKey;
    const licString = licenseKeyFile.buffer.toString('utf8').replace(/\n|\r/g, '');
    const license_name = 'Caveonix';
    const ipAddress = await CentralCollectorClient.CentralCollectorConnectionCheck();
    const oldKeyId = await sequelize.query(`select id from caveo_license where is_active='true'`, { type: sequelize.QueryTypes.SELECT });
    let keyToAddInDB;
    try {
      keyToAddInDB = decodeURIComponent(licString);
    } catch (err) {
      const error = new Error('Not valid License Key!!!');
      error.status = 400;
      throw error;
    }
    keyToAddInDB = keyToAddInDB.replace(/\r?\n|\r/g, '');
    const result = await this.updateCaveoLicenseInDb(license_name, keyToAddInDB, publicKeyFile.buffer);
    const newLicUrl = `${ipAddress}/${SERVICE_TYPE}/api/v1/validateLicense/?userToken=${userToken}&userId=${userId}&orgId=${orgId}&licString=${licString}&fqdn=${fqdn}`;
    try {
      const newBody = await rp.post({ url: newLicUrl, json: true, rejectUnauthorized: false });
      if (newBody) {
        result[0].public_key = 'PublicKey';
        return result;
      } else {
        if (_.get(oldKeyId, '[0].id')) {
          await this.makeOldLicenseActive(oldKeyId[0].id);
        }
        const error = new Error('Not valid License Key!!!');
        error.status = 400;
        throw error;
      }
    } catch (err) {
      if (_.get(oldKeyId, '[0].id')) {
        await this.makeOldLicenseActive(oldKeyId[0].id);
      }
      logger.error({ err, stack: err.stack }, 'error occur');
      const errorMessage = err.error || 'Failed to get decrypted key.';
      const error = new Error(errorMessage);
      error.status = 400;
      throw error;
    }

  }

  /**
   * this method used for update Caveo License key
   * @param params: parameters for update caveo_license key in db
   * @returns details of updated caveo license
   */
  async updateLicenseKey(params, userToken, userId, orgId) {
    let licString = (params.key.toString('utf8'));
    licString = licString.split(licString.match('\\r?\\n'));
    licString = decodeURIComponent(licString);
    let existingKey;
    try {
      const result = await sequelize.query(`select * from caveo_license where is_active='true'`, { type: sequelize.QueryTypes.SELECT });
      existingKey = result[0].license_key;
      await sequelize.query(`update caveo_license set license_key=$1 where is_active='true'`, {
        type: sequelize.QueryTypes.UPDATE,
        bind: [licString]
      });
    } catch (error) {
      error.message = 'Failed to update license key';
      error.status = 400;
      throw error;
    }
    try {
      await CentralCollectorClient.checkLicense(userToken, userId, orgId, '');
    } catch (error) {
      await sequelize.query(`update caveo_license set license_key=$1 where is_active='true'`, {
        type: sequelize.QueryTypes.UPDATE,
        bind: [existingKey]
      });
      error.message = 'Not a valid license key';
      error.status = 400;
      throw error;
    }
    const result = await sequelize.query(`select * from caveo_license where is_active='true'`, { type: sequelize.QueryTypes.SELECT });
    return result;
  }

  /**
   * this method  called in updateCaveoLicense() method for update CaveoLicense in database
   * @param license_name:string - license_name used for update caveo_license
   * @param licString:string - license key used for update caveo_license
   * @returns return result of updated caveo_license
   */
  async updateCaveoLicenseInDb(license_name, licString, publicKey) {
    await sequelize.query(`update caveo_license set is_active='false'`, {
      replacements: { licString },
      type: sequelize.QueryTypes.UPDATE
    });
    await sequelize.query(`INSERT INTO caveo_license(created_at,license_name, license_key, public_key) values (now(), $1,$2,$3 );`, { bind: [license_name, licString, publicKey], type: sequelize.QueryTypes.INSERT });
    const result = await sequelize.query(`select * from caveo_license where is_active='true'`, { type: sequelize.QueryTypes.SELECT });
    return result;
  }

  async makeOldLicenseActive(id) {
    if (id) {
      await sequelize.query(`update caveo_license set is_active='false'`, { type: sequelize.QueryTypes.UPDATE });
      await sequelize.query(`update caveo_license set is_active='true' where id = :id`, {
        replacements: { id: id },
        type: sequelize.QueryTypes.UPDATE
      });
    }
  }

  /**
   * this method called when we create and update organization for create application and subapplication
   * @param orgId:int- organization Id for which we create application and subapplication
   * @param params: params for create application and subapplication
   *
   */
  async createApplicationAndApplicationTag(orgId, params) {
    const organization_id = orgId;
    const name = 'Application';
    const description = 'Application';
    const isActive = 'enabled';
    const impactLevel = params.impactLevel;
    const security_tag_name = `application^${name}^${uuid()}`;
    const managed = true;
    const applicationTagDetails = await ApplicationTag.create({
      name,
      description,
      impactLevel,
      isActive,
      organization_id,
      security_tag_name,
      managed
    });
    const sourceId = applicationTagDetails.id;
    const nameA = 'Sub-Application';
    const descriptionA = 'Sub-Application';
    const sequence_num = 1;
    const security_tag_nameA = `sub_application^${nameA}^${uuid()}`;
    await applicationTagService.createApplicationCertificateMember(applicationTagDetails.id, params.certificate_id);
    const policyGroupDetails = await PolicyGroup.create({
      name: nameA,
      description: descriptionA,
      sequence_num,
      isActive,
      organization_id,
      security_tag_name: security_tag_nameA
    });
    const policyGroupId = policyGroupDetails.id;
    const sourceType = 'Application';
    return PolicySourceMembers.create({ policyGroupId, sourceId, sourceType });
  }

  /**
   *
   * @param  orgId:int-organization Id
   * @returns caveo license details
   */
  async getLicense(orgId) {
    const license = await sequelize.query('select * from caveo_license where is_active = true', { type: sequelize.QueryTypes.SELECT });
    try {
      if (license) {
        license.map(d => {
          var nameString = d.license_key;
          var l = Math.round((nameString.length) / 3);
          d.license_key = (nameString.substring(0, l));
        });
        return license;
      }
    } catch (e) {
      return license;
    }
  }

  /**
   * this method used for get list of organizations while update
   * @param orgId: int-organization Id which we update
   * @param parentOrgId : int-parent organization of the organization which we update
   * @returns list of organizations
   */
  async getAllOrgListForOrgUpdate(orgId, parentOrgId, limit, offset, all = false) {
    const orgChainArr = await sequelize
      .query(
        `WITH RECURSIVE org_cte(organization_id, name, type, parent_organization_id) AS (
       SELECT tn.organization_id, o.name,o.type, tn.parent_organization_id
       FROM org_chains AS tn join organizations as o on o.id = tn.organization_id WHERE  o.is_active!='false' and tn.organization_id = :parentOrgId
      UNION ALL
       SELECT c.organization_id, o.name, o.type,c.parent_organization_id
        FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id  WHERE c.parent_organization_id = p.organization_id and o.is_active!='false' and o.is_active!='unmanaged' and o.is_active!='disabled'
        and c.organization_id not in(
	        WITH RECURSIVE org_cte(org_id) AS (
	       SELECT tn.organization_id as org_id
	       FROM org_chains AS tn join organizations as o on o.id = tn.organization_id WHERE  o.is_active!='false' and tn.organization_id = :orgId
	      UNION ALL
	       SELECT c.organization_id as org_id
	        FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id  WHERE c.parent_organization_id = p.org_id and o.is_active!='false'
	      )
	      SELECT * FROM org_cte AS n
        )
      )
      SELECT * FROM org_cte AS n limit :limit offset :offset;
      `,
        { replacements: { orgId, parentOrgId, limit, offset }, model: Organization }
      );
    if (!all) {
      const orgChainArrData = [];
      for (let i = 0; i < orgChainArr.length; i++) {
        const tempData = await orgChainArr[i].getDataValue('organization_id');
        orgChainArrData.push(tempData);
      }
      return orgChainArrData;
    } else {
      return orgChainArr;
    }
  }

  /**
   * this method used for get Build Information
   * @returns build Information
   */
  async getBuildInfo() {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    try {
      const ccUrl = await CentralCollectorClient.getCentralCollectorAddress();
      if (!ccUrl) {
        const err = new Error('No Central Collector Available. Please Contact your Caveonix Administrator');
        err.status = 404;
        throw err;
      }
      let buildInfo, reportBuildInfo;
      try {
        buildInfo = await rp.get(`${ccUrl}/${SERVICE_TYPE}/api/v1/getManifestInfo/`, {
          rejectUnauthorized: false,
          timeout: cc_timeout
        });
      } catch (error) {
        buildInfo = JSON.stringify({ 'Central Collector': 'Missing Build Details' });
      }
      try {
        reportBuildInfo = await rp.get(`${config.reports_url}/api/version`, {
          rejectUnauthorized: false,
          timeout: cc_timeout
        });
      } catch (error) {
        reportBuildInfo = JSON.stringify({ buildInfo: 'Missing Build Details' });
      }
      let apiBuildDetails;
      try {
        apiBuildDetails = fs.readFileSync('build.txt').toString();
      } catch (fileErr) {
        apiBuildDetails = 'Missing Build Details';
      }
      buildInfo = JSON.parse(buildInfo);
      buildInfo.api = apiBuildDetails;
      buildInfo.ReportGenerator = JSON.parse(reportBuildInfo).buildInfo || 'Missing Build Details';
      return buildInfo;
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred getting build info');
      error.message = 'Can not get build info. Please contact administrator.';
      throw error;
    }
  }

  async getLogo(orgId) {
    try {
      const org = await Organization.findByPk(orgId);
      return org.orgLogo;
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      error.status = 400;
      throw error;
    }
  }

  async addLogo(orgId, logo) {
    try {
      const org = await Organization.findByPk(orgId);
      org.orgLogo = logo;
      await org.save();
      return org.orgLogo;
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      error.status = 400;
      throw error;
    }
  }

  async getAllServiceProviders(orgId) {
    orgId = parseInt(orgId);
    if (orgId == -1) {
      return Organization.findAll({ where: { id: -1 } });
    }
    const reportingOrgIds = await Organization.getReportingOrg(orgId);
    return Organization.findAll({ where: { id: reportingOrgIds } });
    // const csp = await Organization.findByPk(orgId, { attributes: ['id', 'name', 'type'] });
    // if (csp.type === 'SaaSProvider') {
    //   return Organization.findAll({ where: { id: reportingOrgs } });
    // }
    // return Organization.findAll({ where: { type: ['Provider', 'SaaSProvider'] } });
  }

  /**
   * Updates the Org License for the current organization
   * @returns {Promise<Model>}
   */
  async upsertOrgLicense(orgId, params, mode = null) {
    /*
    if SAAS
    then orgLicense needed in order to create org
    */
    if (!config.saas) return false;
    const licenseParams = {
      id: get(params, 'orgLicenseId'),
      licenseType: get(params, 'licenseType'),
      licenseCount: get(params, 'licenseCount'),
      licenseCode: get(params, 'licenseCode'),
      unitCount: get(params, 'unitCount'),
      organization_id: orgId,
      createdAt: Date.now(),
      startDate: get(params, 'startDate'),
      endDate: get(params, 'endDate'),
      isActive: 'enabled'
    };
    if (mode && mode === 'create') {
      const Keydata = await awsKMSService.createKMS(params.name, 'Customer', params.aliasName);
      const kmsKeyId = await this.keyGenerator.generateKeys(Keydata.KeyMetadata.KeyId);
      licenseParams.kmsKeyId = kmsKeyId;
    }
    return OrgLicense.upsert(licenseParams, {
      where: {
        organization_id: orgId
      }
    });
  }

  async createOrgApiKeys(orgId) {
    const apiKeysParams = {
      organization_id: orgId,
      licenseName: uuid(),
      currentKey: uuid()
    };
    return OrgApiKeys.create(apiKeysParams, {
      where: {
        organization_id: orgId
      }
    });
  }

  async getOrgApiKeys(orgId) {
    return OrgApiKeys.findOne({
      include: [{
        model: Organization,
        where: { id: orgId },
        required: true,
        attributes: []
      }]
    });
  }

  async getCloudFormation(orgId) {
    if (!config.cloudformation_url || !config.ami || !config.saas_url) {
      const e = new Error('CloudFormation url or parameters not configured');
      e.status = 400;
      throw e;
    }
    const url = config.cloudformation_url;
    let cloudformationTemplate = await rp.get(url, { json: true });
    const key = await AuthorizationInfo.findOne({
      where: {
        organization_id: orgId,
        isActive: { $in: ['enabled', 'true'] }
      },
      attributes: ['id', 'key', 'organization_id']
    });
    if (!key) {
      const e = new Error('Central Collector key not configured');
      e.status = 400;
      throw e;
    }
    cloudformationTemplate = JSON.stringify(cloudformationTemplate);
    cloudformationTemplate = cloudformationTemplate.replace('%%AMI%%', config.ami).replace('%%SAASURL%%', config.saas_url).replace('%%COLLECTORKEY%%', key.key).replace('%%PASSWORD%%', key.key);
    return JSON.parse(cloudformationTemplate);
  }

  async getRelatedLaws(orgId) {
    return RelatedLaws.findAll({
      where: {
        $or: [{ organization_id: orgId }, {
          organization_id: {
            $eq: null
          }
        }]
      }
    });
  }

  async createRelatedLaws(orgId, params) {
    params.organization_id = orgId;
    return RelatedLaws.create(params);
  }

  async updateRelatedLaws(orgId, relatedLawId, params) {
    const relatedLaw = await RelatedLaws.findByPk(relatedLawId, {
      where: {
        organization_id: orgId
      }
    });
    if (!relatedLaw) {
      const e = new Error('Related Law Not Found');
      e.status = 404;
      throw e;
    }
    await relatedLaw.update(params);
    return relatedLaw;
  }

  /**
   * all organization list
   * @param {string} orgId
   * @param {string} dropdown
   */
  async getAllOrganizations(orgId, dropdown) {
    logger.debug('Retrieving all organizations', { loggerLabel });
    logger.silly(`for org ${orgId}`, { loggerLabel });
    const where = { isActive: ['enabled', 'true', 'disabled'] };
    let attributes = { exclude: ['orgLogo'] };
    if (dropdown && dropdown === 'true') {
      where.isActive = ['enabled', 'true'];
      attributes = ['id', 'name', 'aliasName', 'fullName'];
    }
    return Organization.findAll({ where, attributes });
  }
};
