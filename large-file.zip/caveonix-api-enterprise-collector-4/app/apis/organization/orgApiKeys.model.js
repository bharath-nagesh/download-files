const { DataTypes, Model } = require('sequelize');

class OrgApiKeys extends Model {
  static init(sequelize) {
    return super.init({
        currentKey: {
          allowNull: false,
          field: 'current_key',
          type: DataTypes.STRING
        },
        licenseName: {
          field: 'license_name',
          type: DataTypes.INTEGER
        }
      },
      {
        sequelize,
        tableName: 'org_api_keys',
        timestamps: true,
        underscored: true
      });
  }

  static associate(models) {
    OrgApiKeys.belongsTo(models.Organization);
  }
}

module.exports = OrgApiKeys;
