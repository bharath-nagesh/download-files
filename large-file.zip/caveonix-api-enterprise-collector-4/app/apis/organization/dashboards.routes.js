const express = require('express');
const definitions = require('../../definitions/org');
const complianceDefinitions = require('../../definitions/compliance');
const dashboardDefinitions = require('../../definitions/dashboard');
const cyberDefinitions = require('../../definitions/cyber');
const assetDefinitions = require('../../definitions/asset');
const alertDefinitions = require('../../definitions/alerts.js');
const softwareDefinitions = require('../../definitions/software');
const networkDefinitions = require('../../definitions/network');
const serviceDefinitions = require('../../definitions/services');
const ReferenceService = require('../../services/reference.service');

const router = express.Router();

function addEndpoints() {
  const referenceService = new ReferenceService();
  referenceService.addEndpoints('/api/organization/', router, definitions, '/:orgId');
  referenceService.addEndpoints(null, router, complianceDefinitions, '/:orgId/compliance');
  referenceService.addEndpoints(null, router, dashboardDefinitions, '/:orgId/dashboard');
  referenceService.addEndpoints(null, router, cyberDefinitions, '/:orgId/cyber');
  referenceService.addEndpoints(null, router, assetDefinitions, '/:orgId/asset');
  referenceService.addEndpoints('/api/organization/', router, alertDefinitions);
  referenceService.addEndpoints(null, router, softwareDefinitions, '/:orgId/software');
  referenceService.addEndpoints(null, router, networkDefinitions, '/:orgId/network');
  referenceService.addEndpoints(null, router, serviceDefinitions, '/:orgId/services');
}
addEndpoints()
module.exports = router;
