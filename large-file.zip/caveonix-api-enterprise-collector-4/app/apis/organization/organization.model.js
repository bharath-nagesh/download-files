const Sequelize = require('sequelize');
const _ = require('lodash');
const sequelize = require('../../../config/db.conf').getConnection();

/**
 * @swagger
 * components:
 *   schemas:
 *     Organization:
 *       type: object
 *       required:
 *         - name
 *         - email
 *         - isActive
 *       properties:
 *         name:
 *           type: string
 *         addressLine1:
 *           type: string
 *         addressLine2:
 *           type: string
 *         city:
 *           type: string
 *         country:
 *           type: string
 *         email:
 *           type: string
 *         state:
 *           type: string
 *         zip:
 *           type: string
 *         phone:
 *           type: string
 *         type:
 *           type: string
 *         bia_value:
 *           type: string
 *         orgLogo:
 *           type: blob
 *         isActive:
 *           type: boolean
 *         orgChain:
 *           type: virtual
 *         source:
 *           type: string
 *         assetRepoEndpointId:
 *           type: integer
 * @param sequelize
 */
class Organization extends Sequelize.Model {
  static init(sequelize) {
    return super.init({
        name: Sequelize.STRING,
        aliasName: {
          type: Sequelize.STRING,
          field: 'alias_name'
        },
        fullName: {
          type: Sequelize.VIRTUAL(Sequelize.STRING, ['alias_name', 'name']),

          get() {
            return `${this.aliasName} (${this.name})`;
          },
          set(value) {
            return value;
          }
        },
        addressLine1: {
          type: Sequelize.STRING,
          field: 'address_line1'
        },
        addressLine2: {
          type: Sequelize.STRING,
          field: 'address_line2'
        },
        city: {
          type: Sequelize.STRING
        },
        country: {
          type: Sequelize.STRING
        },
        email: {
          type: Sequelize.STRING
        },
        state: {
          type: Sequelize.STRING
        },
        zip: {
          type: Sequelize.STRING
        },
        phone: {
          type: Sequelize.STRING
        },
        type: {
          type: Sequelize.STRING,
          allowNull: false
        },
        bia_value: {
          type: Sequelize.STRING,
          field: 'bai_value'
        },
        orgLogo: {
          type: Sequelize.BLOB,
          field: 'org_logo'
        },
        orgType: {
          type: Sequelize.STRING,
          field: 'org_type',
          allowNull: true
        },
        billingAccountId: {
          type: Sequelize.STRING,
          field: 'billing_account_id',
          allowNull: true
        },
        billingCycle: {
          type: Sequelize.STRING,
          field: 'billing_cycle',
          allowNull: true
        },
        externalId: {
          type: Sequelize.STRING,
          field: 'external_id',
          allowNull: true
        },
        isActive: {
          type: Sequelize.BOOLEAN,
          field: 'is_active',
          defaultValue: true,
          allowNull: false
        },
        is_active: {
          type: Sequelize.BOOLEAN,
          field: 'is_active'
        },
        orgChain: {
          type: Sequelize.VIRTUAL
        },
        source: {
          type: Sequelize.STRING,
          allowNull: true
        },
        assetRepoEndpointId: {
          type: Sequelize.INTEGER,
          allowNull: true,
          field: 'asset_repo_endpoint_id'
        }
      },
      {
        tableName: 'organizations',
        sequelize,
        underscored: true
      });

  }

  isEnterprise() {
    if (this.OrgApiKey) return true;
    return false;
  }

  generateOrgApiKey() {
    if (this.OrgApiKey) this.setDataValue('orgApiKey', this.OrgApiKey.currentKey);
    if (this.AuthorizationInfos) this.setDataValue('rcKeys', this.AuthorizationInfos.map(ai => ai.key));
    return true;
  }

  // model associations
  static associate(models) {
    Organization.belongsToMany(models.User, {
      through: models.OrgMembers
    });
    Organization.hasMany(models.Role);
    Organization.hasMany(models.AuthorizationInfo);
    Organization.belongsToMany(Organization, { through: 'org_chains', as: 'ParentOrganization' });
    Organization.belongsToMany(models.Certificates, {
      through: models.OrgCertificateMembers,
      foreignKey: 'organization_id',
      otherKey: 'certificate_id',
      timestamps: false
    });
    Organization.belongsToMany(models.ProductOfferings, {
      through: models.OrgProductOffering,
      foreignKey: 'organization_id',
      otherKey: 'product_offering_id',
      timestamps: false
    });
  };

  static async getOrgChain(orgId, all = false) {
    const orgChainArr = await sequelize.query(
      `WITH RECURSIVE org_cte(id, organization_id, name, type, is_active,parent_organization_id, depth, path, source, asset_repo_endpoint_id) AS (
       SELECT tn.organization_id as id,tn.organization_id, o.name,o.type, o.is_active,tn.parent_organization_id, 1::INT AS depth, o.name::TEXT AS path, o.source, o.asset_repo_endpoint_id
       FROM org_chains AS tn join organizations as o on o.id = tn.organization_id WHERE  o.is_active!='false' and tn.organization_id = :orgId
      UNION ALL
       SELECT c.organization_id as id,c.organization_id, o.name, o.type,o.is_active,c.parent_organization_id,  p.depth + 1 AS depth, (p.path || '->' || o.name::TEXT), o.source, o.asset_repo_endpoint_id
        FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id  WHERE c.parent_organization_id = p.organization_id and o.is_active!='false'
      )
      SELECT * FROM org_cte AS n UNION ALL (SELECT  id, id as organization_id,name,type,is_active, null as parent_organization_id, 0 as depth, name::TEXT as path, source,asset_repo_endpoint_id from organizations where id = :orgId);
      `,
      { replacements: { orgId }, model: Organization }
    );
    if (!all) {
      return _.uniq(orgChainArr.map(row => {
        return row.getDataValue('organization_id');
      }));

    } else {
      return _.uniqBy(orgChainArr, obj => obj.getDataValue('organization_id'));

    }
  };

  static async getReportingOrgChain(orgId, all = false, internalOrg = true) {
    let reportingOrgs;
    if (parseInt(orgId) === -1) {
      reportingOrgs = await sequelize.query(`select oc.organization_id as reporting_org_chain_list from org_chains oc join organizations o on o.id = oc.organization_id where oc.reporting_organization_id = -1 and o.is_active != 'false' ;`, {
        replacements: { orgId },
        type: sequelize.QueryTypes.SELECT
      });
      reportingOrgs.push({ reporting_org_chain_list: -1 });
    } else if (internalOrg) {
      // Get only internal reporting org chain
      reportingOrgs = await sequelize.query(`select organization_id as reporting_org_chain_list from org_chains 
      where organization_id in (SELECT org_chain_list(:orgId)) and (parent_organization_id != -1 or organization_id = :orgId)`, {
        replacements: { orgId },
        type: sequelize.QueryTypes.SELECT
      });

    } else {
      reportingOrgs = await sequelize.query(`(SELECT org_chain_list(:orgId))`, {
        replacements: { orgId },
        type: sequelize.QueryTypes.SELECT
      });
    }
    const orgIds = reportingOrgs.map(o => o.reporting_org_chain_list);
    if (all) {
      return this.findAll({
        where: { id: orgIds },
        attributes: { exclude: ['externalId'] },
        include: [{
          model: Organization,
          as: 'ParentOrganization',
          attributes: ['id', 'name', 'aliasName', 'fullName', 'type', 'isActive', ['id', 'organization_id']]
        }]
      });
    }
    return orgIds;
  }

  static async getParentOrg(orgId) {
    const parentOrgArr = await sequelize.query(
      `(select CASE WHEN parent_organization_id = -1 THEN organization_id ELSE parent_organization_id END as parent_organization_id from
    (WITH RECURSIVE org_cte(organization_id, name, type, parent_organization_id, depth, path) AS (
      SELECT tn.organization_id, o.name,o.type, tn.parent_organization_id, 1::INT AS depth, o.name::TEXT AS path
    FROM org_chains AS tn join organizations as o on o.id = tn.organization_id WHERE tn.organization_id = :orgId
    UNION ALL
    SELECT c.organization_id, o.name, o.type,c.parent_organization_id,  p.depth + 1 AS depth, (p.path || '->' || o.name::TEXT)
    FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id  WHERE c.parent_organization_id = p.organization_id
    and c.parent_organization_id != -1) SELECT * FROM org_cte AS n where organization_id = :orgId) x ) `,
      { replacements: { orgId }, model: Organization }
    );
    const parentOrg = _.get(parentOrgArr, `[0].dataValues.parent_organization_id`);
    return parentOrg;
  }

  static async getReportingOrg(orgId) {
    orgId = parseInt(orgId);
    if (orgId == -1) {
      const orgIds = await sequelize.query(`select organization_id from org_chains where reporting_organization_id = :orgId`, {
        replacements: { orgId },
        type: sequelize.QueryTypes.SELECT
      });
      return orgIds.map(o => o.organization_id);
    }
    const reportingOrgs = await sequelize.query(`SELECT reporting_org_chain_list(:orgId)`, {
      replacements: { orgId },
      type: sequelize.QueryTypes.SELECT
    });
    reportingOrgs.push({ reporting_org_chain_list: orgId });
    return reportingOrgs.map(o => o.reporting_org_chain_list);
  }
}

module.exports = Organization;
