const Sequelize = require('sequelize')

class RelatedLaws extends Sequelize.Model {

  static init(sequelize) {
    return super.init({

      lawNumber: {
        type: Sequelize.STRING,
        field: 'law_number'
      },
      title: {
        type: Sequelize.STRING,
        field: 'title',
      },
      lawDate: {
        type: Sequelize.STRING,
        field: 'law_date',
      },
      source: { type: Sequelize.STRING, field: 'source' },
    }, {
      sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'related_laws',
      underscored: true
    });
  }

  static associate(models) {

    RelatedLaws.belongsTo(models.Organization, { foreignKey: 'organization_id' });
  }
}

module.exports = RelatedLaws;
