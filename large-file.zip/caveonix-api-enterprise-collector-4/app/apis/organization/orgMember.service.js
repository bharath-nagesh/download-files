const logger = require('../../../utils/logger').logger;
const Organization = require('./organization.model');
const OrgMembers = require('./orgMembers.model');
const Role = require('../roles/role.model');
const User = require('../user/user.model');

const loggerLabel = 'OrgMemberService';

module.exports = class OrgMemberService {
  constructor(services) {
    this.services = services;
    logger.debug('called OrgMemberService constructor');
  }

  async addOrgUser(orgId, userId, roleId) {
    logger.info({ userId, orgId, roleId }, 'Attempting to apply role');
    const user = await User.findByPk(userId);
    if (!user) {
      logger.error({ userId }, ' User not found.');
      const err = new Error('User not found.');
      err.status = 404;
      throw err;
    }
    return user.setOrganizations(orgId, { through: { role_id: roleId } });
  }

  async updateOrgUser(orgId, userId, roleId) {
    const orgMember = await OrgMembers.findOne({ where: { organization_id: orgId, user_id: userId } });
    if (!orgMember) {
      const err = new Error('No Organization membership found.');
      err.status = 404;
      throw err;
    }
    orgMember.role_id = roleId;
    await orgMember.save();
    return OrgMembers.findOne({ where: { organization_id: orgId, user_id: userId }, include: [{ all: true }] });
  }

  async deleteOrgUser(orgId, userId) {
    const orgMember = await OrgMembers.findOne({
      where: { organization_id: orgId, user_id: userId },
      include: [{ all: true }]
    });
    if (!orgMember) {
      const err = new Error('No Organization membership found.');
      err.status = 404;
      throw err;
    }
    await orgMember.destroy();
    return orgMember;
  }

  /**
   * Gets list of users
   * @returns {Promise<(*|*)[]>}
   */
  async getOrgUsers() {
    logger.debug(`getting users `, { loggerLabel });

    let orgUsers = await User.findAndCountAll({
      where: { isActive: { $ne: 'false' } },
      attributes: ['id', 'username', 'firstName', 'lastName', 'isActive'],
      include: [
        { model: Organization, as: 'Organizations', required: true, attributes: ['id', 'name', 'aliasName', 'fullName'] },
        { model: Role, attributes: ['name', 'description'] }
      ]
    });
    orgUsers = orgUsers.rows.map(user => {
      if (user.activeDirectoryId) {
        user.dataValues.type = 'Active Directory';
      } else {
        user.dataValues.type = 'Local DB';
      }
      if (user.twoFactorToken){
        user.dataValues.twoFactorToken = true;
      } else {
        user.dataValues.twoFactorToken = false;
      }
      return user;
    });
    return [orgUsers, orgUsers.count];
  }
};
