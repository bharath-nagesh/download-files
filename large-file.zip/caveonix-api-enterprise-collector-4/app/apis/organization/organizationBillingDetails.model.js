const { DataTypes, Model } = require('sequelize');

class OrganizationBillingDetails extends Model {
  static init(sequelize) {
    return super.init({
      name: {
        allowNull: false,
        field: 'name',
        type: DataTypes.STRING
      },
      parentOrganizationId: {
        allowNull: false,
        field: 'parent_organization_id',
        type: DataTypes.STRING
      },
      assetCnt: {
        field: 'asset_cnt',
        type: DataTypes.BIGINT
      },
      type: {
        field: 'type',
        type: DataTypes.STRING
      },
      source: {
        field: 'source',
        type: DataTypes.STRING
      },
      orgCreatedAt: {
        field: 'org_created_at',
        type: DataTypes.STRING
      },
      orgSource: {
        field: 'org_source',
        type: DataTypes.STRING
      },
      orgExternalId: {
        field: 'org_external_id',
        type: DataTypes.STRING
      },
      createdAt: {
        allowNull: false,
        field: 'created_at',
        type: DataTypes.DATE
      },
      isActive: {
        type: DataTypes.STRING,
        field: 'is_active'
      }
    },
    {
      sequelize,
      tableName: 'organization_billing_details',
      timestamps: false,
      underscored: true
    });
  }

  static associate(models) {
    OrganizationBillingDetails.belongsTo(models.Organization, { foreignKey: 'organization_id' });
  };
}

module.exports = OrganizationBillingDetails;
