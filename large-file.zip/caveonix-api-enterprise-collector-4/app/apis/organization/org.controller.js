const paginate = require('../../middlewares/paginate.middleware');
const checkId = require('../../../utils/checkId');
const OrgService = require('./org.service');
const orgService = new OrgService();
const JobService = require('../job/job.service');
const jobService = new JobService();
const UserService = require('../user/user.service');
const userService = new UserService();
const OrgMemberService = require('./orgMember.service');
const orgMemberService = new OrgMemberService();
const BillingService = require('../../services/billing.service');
const billingService = new BillingService();
const config = require('../../../configure').get();
const models = require('../../../config/db.conf').getAllModels();
const errorHandler = require('../../../utils/errorHandler');
const Validator = require('../../../utils/validator');
const logger = require('../../../utils/logger').logger;
const _ = require('lodash');
const url = require('url');

const loggerLabel = 'OrgController';

const controller = {
  /**
   * this method used for get billing information of particular organization
   */
  async getBillingInfoForOrg(req, res) {
    const orgId = req.params.orgId;
    try {
      const d = await billingService.getBillingForMonth(orgId);
      return res.json(d);
    } catch (e) {
      return errorHandler(req, res, e);
    }
  },
  /**
   * this method used for get billing details organization and its chain
   */
  async getBillingDetailsForOrg(req, res) {
    const orgId = req.params.orgId;
    try {
      const d = await billingService.getBillingDetailsForOrg(orgId);
      return res.json(d);
    } catch (e) {
      return errorHandler(req, res, e);
    }
  },
  /**
   *
   *this method used for create child organization under parent organization
   */
  async createChildOrganization(req, res) {
    let orgId = '';
    const params = req.body;
    try {
      params.isActive = params.isActive ? params.isActive.toString().toLowerCase() : 'enabled';
      await Validator.validateParams({
        aliasName: 'required|string',
        bai_value: 'nullable',
        email: 'required|email',
        certificate_id: 'required',
        type: 'nullable',
        parentOrgId: 'required|integer',
        country: 'nullable',
        state: 'nullable',
        zip: 'nullable',
        city: 'nullable',
        addressLine1: 'nullable',
        addressLine2: 'nullable',
        phone: 'string',
        isActive: 'required|in:enabled,disabled,true',
        licenseType: 'nullable',
        licenseCount: 'nullable',
        endDate: 'nullable',
        startDate: 'nullable'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const userId = req.user.id;
    params.orgLogo = req.file ? req.file.buffer : null;
    params.name = null;
    const userOrgId = req.user.Organizations[0].id;
    const token = req.authInfo;
    const parentOrgId = params.parentOrgId;
    if (orgService.checkOrgId(parentOrgId)) {
      logger.error({ parentOrgId }, 'Error with Parent Org Id');
      const error = new Error('Error with Parent Org Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const org = await orgService.createOrganization(params, userOrgId, parentOrgId, userId, token);
      orgId = org.id;
      const result = await orgService.getOrganizationById(orgId);
      if (config.forensics_enabled === false || config.ml_enabled === true) {
        const name = 'watcherRequest' + orgId;
        params.type_name = 'watcherRequest';
        params.cron_expression = '0 0/30 * * * ?';
        params.scan_type = 'watcherRequest';
        params.user_id = userId;
        params.asset_repo_id = 2;
        const job = await jobService.createJob(orgId, name, params.user_id, params);
        const scheduleJob = job;
        const userToken = token;
        const type = 'watcherRequest';
        jobService.createModifyScheduleJob(scheduleJob, userId, userToken, userOrgId, 'watcherSchedule', name, type);
      }
      return res.json(result);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  },
  /**
   *
   * this method used for get organization details of given organization Id
   */
  async getOrganization(req, res) {
    const orgId = req.params.orgId;
    const filterOrgId = req.query.id || null;
    try {
      const organization = await orgService.getOrganizationById(orgId, true, filterOrgId);
      if (!organization) {
        logger.error('Organization Not Found', { loggerLabel });
        return res.sendStatus(404);
      }
      return res.json(organization);
    } catch (error) {
      logger.error('Error occurred while attempting for retrieve organization', { error, loggerLabel });
      return errorHandler(req, res, error);
    }
  },
  /**
   *
   *this method used for update the organization details of given orgId
   */
  async updateOrganization(req, res) {
    const params = req.body;
    try {
      params.isActive = params.isActive ? params.isActive.toString().toLowerCase() : null;
      await Validator.validateParams({
        aliasName: 'required|string',
        bai_value: 'nullable',
        email: 'required|email',
        certificate_id: 'required',
        type: 'nullable',
        parentOrgId: 'required|integer',
        country: 'nullable',
        zip: 'nullable',
        state: 'nullable',
        city: 'nullable',
        addressLine1: 'nullable',
        addressLine2: 'nullable',
        phone: 'string',
        isActive: 'required|in:enabled,disabled'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const orgId = req.query.id || req.params.orgId;
    if(req.file){
      params.orgLogo = req.file.buffer;
    }
    let scheduleJob;
    const userToken = req.authInfo;
    const userId = req.user.id;
    const loginUserOrganizationId = req.user.Organizations[0].id;
    let jobName;
    let type;
    const is_active = params.isActive;
    try {
      const org = await orgService.updateOrg(orgId, params);
      const watcherJob = await models.Job.findOne({ where: { name: 'watcherRequest' } });
      const tasklist = await models.ScheduleTask.findAll({
        where: {
          org_id: orgId,
          isActive: { $ne: 'false' },
          job_id: watcherJob.id
        }
      });
      if (config.forensics_enabled === false || config.ml_enabled === true) {
        if (tasklist.length < 1) {
          const name = 'watcherRequest' + orgId;
          params.type_name = 'watcherRequest';
          params.cron_expression = '0 0/30 * * * ?';
          params.scan_type = 'watcherRequest';
          params.user_id = userId;
          params.asset_repo_id = 2;
          const key = 'id';
          delete params[key];
          const job = await jobService.createJob(orgId, name, params.user_id, params);
          scheduleJob = job;
          const type = 'watcherRequest';
          jobService.createModifyScheduleJob(scheduleJob, userId, userToken, loginUserOrganizationId, 'watcherSchedule', name, type);
        }
      }
      const result = await models.ScheduleTask.findAll({ where: { org_id: orgId, is_active: 'enabled' } });
      if (is_active === 'disabled') {
        await models.ScheduleTask.update({ isActive: 'disabled' }, { where: { org_id: orgId, is_active: 'enabled' } });
        for (let i = 0; i < result.length; i++) {
          scheduleJob = result[i];
          const jobId = scheduleJob.job_id;
          jobName = scheduleJob.name;
          const job = await models.Job.findOne({ where: { id: jobId } });
          type = job.name;
          jobService.createModifyScheduleJob(scheduleJob, userId, userToken, loginUserOrganizationId, 'unSchedule', jobName, type);
        }
      }
      return res.json(org);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  },
  /**
   *
   * this method used for get organization chain
   */
  async getOrgChain(req, res) {
    try {
      const dropdown = req.query.dropdown || false;
      const orgId = req.query.id || req.params.orgId;
      const organizations = await orgService.getAllOrganizations(orgId, dropdown);
      return res.json(organizations);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  },
  /**
   * this method used for get organization chain
   * If orgId is 'Provider' then it will display provider along with it's first level organizations and sub-organizations and sub-organization chain.
   * If orgId is other than 'Provider' then it will give it's chain along with him.
   */

  async createOrganizationUser(req, res) {
    const orgId = req.body.organization_id || req.params.orgId;
    const { username, firstName, lastName, password } = req.body;
    const roleId = req.body.role_id || req.body.roleId;
    try {
      const user = await userService.createUser(username, password, firstName, lastName, roleId, orgId, req.body);

      return res.json(user);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  },
  /**
   *
   * this method used for get organization user details
   */
  async getOrganizationUsers(req, res) {
    const limit = res.locals.paginate.limit;
    const pageNumber = res.locals.paginate.page;
    try {
      const organizationUsers = await orgMemberService.getOrgUsers();
      const results = organizationUsers[0];
      const itemCount = organizationUsers[1];
      const pageCount = Math.ceil(itemCount / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        users: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  },
  /**
   *
   * this method used for change organization user
   */
  async changeOrganizationUser(req, res) {
    const orgId = req.params.orgId;
    const userId = req.params.userId;
    const roleId = req.body.roleId;

    if (checkId(userId)) {
      logger.error({ userId }, 'Error with User Id');
      const error = new Error('Error with User Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    if (checkId(roleId)) {
      logger.error({ roleId }, 'Error with Role Id');
      const error = new Error('Error with Role Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const data = await orgMemberService.updateOrgUser(orgId, userId, roleId);
      logger.info({ data });
      return res.json(data);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  },
  /**
   *
   * this method used fr delete organization user
   */
  async deleteOrganizationUser(req, res) {
    const orgId = req.params.orgId;
    const userId = req.params.userId;

    if (checkId(userId)) {
      logger.error({ userId }, 'Error with User Id');
      const error = new Error('Error with User Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const data = await orgMemberService.deleteOrgUser(orgId, userId);
      return res.json(data);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  },
  /**
   *
   * this method used for delete organization
   */
  async deleteOrg(req, res) {
    const params = req.body;
    const orgId = req.params.orgId;
    const userToken = req.authInfo;
    const createModifyJob = 'Delete';
    let scheduleJob;
    let typeName;
    let jobName;
    const user = req.user.id;
    const userOrgId = req.user.Organizations[0].id;
    const is_active = params.isActive;
    if (is_active === 'true') {
      logger.error({ is_active }, 'Invalid Request with isActive field');
      const error = new Error('Invalid Request with isActive field');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const update = await orgService.deleteOrg(orgId, userToken, user, userOrgId);
      const result = await models.ScheduleTask.findAll({ where: { org_id: orgId, is_active: 'enabled' } });
      await models.ScheduleTask.update({ isActive: false }, { where: { org_id: orgId } });
      for (let i = 0; i < result.length; i++) {
        scheduleJob = result[i];
        const jobId = scheduleJob.job_id;
        jobName = scheduleJob.name;
        const job = await models.Job.findOne({ where: { id: jobId } });
        typeName = job.name;
        jobService.createModifyScheduleJob(scheduleJob, user, userToken, userOrgId, createModifyJob, jobName, typeName);
      }
      logger.info({ update, orgId }, 'update');
      return res.json(update);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  },

  /**
   *
   * this method is used for update License Key
   */
  async updateCaveoLicense(req, res) {
    let params = req.body;
    const userToken = req.authInfo;
    const userId = req.user.id;
    const orgId = req.params.serviceProviderId || req.params.orgId;
    const publicKey = _.get(req, 'files.publicKey[0]');
    const licenseKey = _.get(req, 'files.licenseKey[0]');
    params.licenseKey = licenseKey;
    params.publicKey = publicKey;
    params = Object.assign({}, params, { userToken, orgId, userId });
    // user validation
    if (!userToken || !userId) {
      logger.info('Invalid User Parameters.');
      const error = new Error('Invalid User Parameters.');
      error.status = 400;
      return errorHandler(req, res, error);
    }

    // publicKey validation
    if (!publicKey) {
      logger.info('Missing publicKey.');
      const err = new Error('Missing publicKey.');
      err.status = 400;
      return errorHandler(req, res, err);
    }

    // license key validation
    if (!licenseKey) {
      logger.info('Missing licenseKey.');
      const err = new Error('Missing licenseKey.');
      err.status = 400;
      return errorHandler(req, res, err);
    }

    // key mimetype validation
    if (licenseKey.mimetype != 'application/octet-stream' || publicKey.mimetype != 'application/octet-stream') {
      const err = new Error('Invalid license key. Allowed license file extension - .out');
      err.status = 400;
      return errorHandler(req, res, err);
    }

    // key filetype validation
    if (licenseKey.originalname.slice(-4) != '.out' || publicKey.originalname.slice(-4) != '.out') {
      const err = new Error('Invalid license key. Allowed license file extension - .out');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    try {
      const refererFqdn = req.headers.referer ? url.parse(req.headers.referer).hostname.toLowerCase() : '';
      const data = await orgService.updateCaveoLicense(params, refererFqdn);
      return res.send(data);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  },

  /**
   *
   * this method is used for update License Key
   */
  async updateLicenseKey(req, res) {
    const params = req.body;
    const userToken = req.authInfo;
    const userId = req.user.id;
    const orgId = req.params.orgId;
    if (!params.key) {
      logger.info('Invalid Parameters To Validate License Key.');
      const err = new Error('Invalid Parameters To Validate License Key.');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    try {
      const data = await orgService.updateLicenseKey(params, userToken, userId, orgId);
      return res.send(data);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  },

  /**
   *
   * this method used for delete multiple organizations
   */
  async deleteMultipleOrg(req, res) {
    const orgId = req.query.id || '';
    const user = req.user.id;
    const userOrgId = req.user.Organizations[0].id;
    const userToken = req.authInfo;
    const createModifyJob = 'Delete';
    let scheduleJob;
    let typeName;
    let jobName;
    if (orgId === undefined || orgId === '') {
      logger.error('Invalid Input');
      const error = new Error('Invalid Input');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    const orgIdArr = orgId.split(',');
    try {
      for (let ctr = 0; ctr < orgIdArr.length; ctr++) {
        await orgService.deleteOrg(orgIdArr[ctr], userToken, user, userOrgId);
      }
      const tasklist = await models.ScheduleTask.findAll({
        where: {
          org_id: { $in: orgIdArr },
          is_active: 'enabled'
        }
      });
      await models.ScheduleTask.update({ isActive: false }, { where: { org_id: { $in: orgIdArr } } });
      for (let i = 0; i < tasklist.length; i++) {
        scheduleJob = tasklist[i];
        const jobId = scheduleJob.job_id;
        jobName = scheduleJob.name;
        const job = await models.Job.findOne({ where: { id: jobId } });
        typeName = job.name;
        jobService.createModifyScheduleJob(scheduleJob, user, userToken, userOrgId, createModifyJob, jobName, typeName);
      }
      const result = await orgService.getMultipleOrg(orgIdArr);
      return res.json(result);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  },
  /**
   *
   * this method used for get organization list for update organization
   */
  async getAllOrgListForOrgUpdate(req, res) {
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    const orgId = req.params.orgId;
    const parentOrgId = req.user.Organizations[0].id;

    try {
      const results = await orgService.getAllOrgListForOrgUpdate(orgId, parentOrgId, limit, offset, true);
      const item = await orgService.getAllOrgListForOrgUpdate(orgId, parentOrgId, null, null, true);
      const pageCount = Math.ceil(item.length / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: item.length,
        page_number: pageNumber,
        Organizations: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  },
  /**
   *
   *this method used for get Build Information
   */
  async getBuildInfo(req, res) {
    try {
      const results = await orgService.getBuildInfo();
      return res.json(results);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  },
  async getLogo(req, res) {
    const orgId = req.params.orgId;

    try {
      const logo = await orgService.getLogo(orgId);
      res.setHeader('Content-disposition', `inline;filename=logo.png`);
      res.setHeader('Content-type', 'image/png');
      return res.send(logo);
    } catch (e) {
      logger.error({ e, stack: e.stack }, 'error occurred');
      return errorHandler(req, res, e);
    }
  },
  async addLogo(req, res) {
    const orgId = req.params.orgId;
    const logo = req.file ? req.file.buffer : req.body.file;

    try {
      const data = await orgService.addLogo(orgId, logo);
      res.setHeader('Content-disposition', `inline;filename=logo.png`);
      res.setHeader('Content-type', 'image/png');
      return res.send(data);
    } catch (e) {
      logger.error({ e, stack: e.stack }, 'error occurred');
      return errorHandler(req, res, e);
    }
  },
  async generateKey(req, res) {
    const orgId = req.params.orgId;
    try {
      const data = await orgService.createOrgApiKeys(orgId);

      return res.json(data);
    } catch (e) {
      logger.error({ e, stack: e.stack }, 'error occurred');
      return errorHandler(req, res, e);
    }
  },
  async getKey(req, res) {
    const orgId = req.params.orgId;
    try {
      const data = await orgService.getOrgApiKeys(orgId);

      return res.json(data);
    } catch (e) {
      logger.error({ e, stack: e.stack }, 'error occurred');
      return errorHandler(req, res, e);
    }
  },
  async getCloudFormation(req, res) {
    try {
      const orgId = req.params.orgId;
      const results = await orgService.getCloudFormation(orgId);
      return res.json(results);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  },
  async getRelatedLaws(req, res) {
    const orgId = req.params.orgId;
    try {
      const response = await orgService.getRelatedLaws(orgId);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  },
  async createRelatedLaws(req, res) {
    const orgId = req.params.orgId;
    const params = req.body;
    try {
      const response = await orgService.createRelatedLaws(orgId, params);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  },
  async updateRelatedLaws(req, res) {
    const { orgId, relatedLawId } = req.params;
    const params = req.body;
    try {
      const response = await orgService.updateRelatedLaws(orgId, relatedLawId, params);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }
};

module.exports = controller;
