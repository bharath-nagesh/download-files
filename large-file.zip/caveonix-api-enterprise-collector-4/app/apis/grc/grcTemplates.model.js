const Sequelize = require('sequelize');

/**
 * @swagger
 * components:
 *   schemas:
 *     GRCTemplates:
 *       type: object
 *       properties:
 *         organization_id:
 *           type: string
 *         name:
 *           type: string
 *         version:
 *           type: string
 *         sectionId:
 *           type: string
 *         sectionName:
 *           type: string
 *         sectionNotes:
 *           type: string
 *         isActive:
 *           type: string
 *         createdBy:
 *           type: string
 *         updatedBy:
 *           type: string
 * @param sequelize
 */
class GRCTemplates extends Sequelize.Model {
  static init(sequelize) {
    return super.init({
      name: { type: Sequelize.STRING, field: 'name' },
      organizationId: { type: Sequelize.STRING, field: 'organization_id' },
      version: { type: Sequelize.STRING, field: 'version' },
      sectionId: { type: Sequelize.STRING, field: 'section_id' },
      sectionName: { type: Sequelize.STRING, field: 'section_name' },
      sectionNotes: { type: Sequelize.STRING, field: 'section_notes' },
      isActive: { type: Sequelize.STRING, field: 'is_active' },
      createdBy: { type: Sequelize.STRING, field: 'created_by' },
      updatedBy: { type: Sequelize.STRING, field: 'updated_by' }
    },
    {
      sequelize,
      timestamps: true,
      freezeTableName: true,
      tableName: 'grc_reporting_templates',
      underscored: true
    }
    );
  }
}

GRCTemplates.associate = (models) => {
  GRCTemplates.belongsTo(models.Organization, { foreignKey: 'organization_id' });
};

module.exports = GRCTemplates;
