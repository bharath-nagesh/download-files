const GRCController = require('./grc.controller');

/**
 * @swagger
 * tags:
 *  - name: GRC
 *    description: GRC endpoints
 */
module.exports = class GRCRoutes {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.grcController = new GRCController();
      this.initOrganization();

    }
  }

  initOrganization() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/grc/templates:
     *   get:
     *     tags:
     *       - GRC Reporting Templates
     *     summary: Gets GRC Reporting Templates
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: name
     *         description: The template name.
     *         in: query
     *         required: true
     *         type: string
     *       - name: orgId
     *         description: The organization's id for template.
     *         in: query
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of GRC Templates
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/templates`, this.grcController.getAllGRCTemplates);

  }
};
