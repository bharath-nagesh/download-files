const EnforcementController = require('./enforcement.controller');

/**
 * @swagger
 * tags:
 *  - name: Enforcement
 *    description: Enforcement endpoints
 */
module.exports = class EnforcementRouter {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.enforcementController = new EnforcementController();

      this.initOrganization();
    }
  }

  /**
   * Route initialization and setup
   */
  initOrganization() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/enforcement:
     *   get:
     *     tags:
     *       - Enforcement
     *     summary: Gets the lockdown mode
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: get all enforcements
     *       401:
     *         description: unauthorized
     */
    this.router.get(`${this.path}/`, this.enforcementController.getLockdownMode);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/enforcement:
     *   post:
     *     tags:
     *       - Enforcement
     *     summary: Sets the lockdown mode
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: get all enforcements
     *       401:
     *         description: unauthorized
     */
    this.router.post(`${this.path}/`, this.enforcementController.setLockdownMode);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/enforcement/quarantine:
     *   post:
     *     tags:
     *       - Enforcement
     *     summary: Quarantines a specified asset
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: get all enforcements
     *       401:
     *         description: unauthorized
     */
    this.router.post(`${this.path}/quarantine`, this.enforcementController.quarantine);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/enforcement/unquarantine:
     *   post:
     *     tags:
     *       - Enforcement
     *     summary: Unquarantines a specified asset
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: get all enforcements
     *       401:
     *         description: unauthorized
     */
    this.router.post(`${this.path}/unquarantine`, this.enforcementController.unquarantine);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/enforcement/markQuarantine:
     *   post:
     *     tags:
     *       - Enforcement
     *     summary: Marks a specified asset for quarantine
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: get all enforcements
     *       401:
     *         description: unauthorized
     */
    this.router.post(`${this.path}/markQuarantine`, this.enforcementController.markQuarantine);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/enforcement/unmarkQuarantine:
     *   post:
     *     tags:
     *       - Enforcement
     *     summary: Unmarks a specified asset for quarantine
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: get all enforcements
     *       401:
     *         description: unauthorized
     */
    this.router.post(`${this.path}/unmarkQuarantine`, this.enforcementController.unmarkQuarantine);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/enforcement/addAssetToQuarantineAdmin:
     *   post:
     *     tags:
     *       - Enforcement
     *     summary: Adds an asset to the quarantine admin
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: added asset to quarantine admin
     *       401:
     *         description: unauthorized
     */
    this.router.post(`${this.path}/addAssetToQuarantineAdmin`, this.enforcementController.addAssetToQuarantineAdmin);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/enforcement/suggestAPolicy:
     *   post:
     *     tags:
     *       - Enforcement
     *     summary: Suggests a policy
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: suggests a policy
     *       401:
     *         description: unauthorized
     */
    this.router.post(`${this.path}/suggestAPolicy`, this.enforcementController.suggestAPolicy);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/enforcement/retrieveAPolicy:
     *   post:
     *     tags:
     *       - Enforcement
     *     summary: Suggests a policy
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: retrieves a policy
     *       401:
     *         description: unauthorized
     */
    this.router.post(`${this.path}/retrieveAPolicy`, this.enforcementController.retrieveAPolicy);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/enforcement/createUpdatePolicy:
     *   post:
     *     tags:
     *       - Enforcement
     *     summary: Creates, updates or removes rules from policy.
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: creates, updates and/or removes rules from policy
     *       401:
     *         description: unauthorized
     */
    this.router.post(`${this.path}/createUpdatePolicy`, this.enforcementController.createUpdatePolicy);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/enforcement/addPolicy:
     *   post:
     *     tags:
     *       - Enforcement
     *     summary: Creates a new rule in policy.  Will not remove any existing rules from policy.
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: Creates a new rule in policy.  Will not remove any existing rules from policy.
     *       401:
     *         description: unauthorized
     */
    this.router.post(`${this.path}/addPolicy`, this.enforcementController.addPolicy);
  }
};
