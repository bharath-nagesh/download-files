const EnforcementService = require('./enforcement.service');
const errorHandler = require('../../../utils/errorHandler');
const Validator = require('../../../utils/validator');
const logger = require('../../../utils/logger').logger;
const NetworkUtilsFactory = require('../../../utils/network/networkUtils/NetworkUtilsFactory');
const Utils = NetworkUtilsFactory.createNetworkUtils();
const config = require('../../../config.json');
const enforcementService = new EnforcementService();
const cache = {};

module.exports = class EnforcementController {

  async addAssetToQuarantineAdmin(req, res) {
    const params = req.body;
    try {
      await Validator.validateParams({
        ids: 'required|array'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const userId = req.user.id;
    const token = req.authInfo;
    const orgId = req.params.orgId;
    const ids = req.body.ids;

    try {

      const result = await enforcementService.addAssetToQuarantineAdmin(userId, token, orgId, ids);
      return res.json(result);
    } catch (e) {
      return errorHandler(req, res, e);
    }
  }

  async quarantine(req, res) {
    const userId = req.user.id;
    const token = req.authInfo;
    const orgId = req.params.orgId;
    const type = req.body.type;
    const ids = req.body.ids;
    const tag = req.body.tag;

    logger.silly({ tag, ids, type }, 'quarantine info');
    try {

      const result = await enforcementService.quarantine(userId, token, orgId, type, ids, tag);
      return res.json(result);
    } catch (e) {
      return errorHandler(req, res, e);
    }

  }

  async markQuarantine(req, res) {
    const userId = req.user.id;
    const token = req.authInfo;
    const orgId = req.params.orgId;
    const type = req.body.type;
    const ids = req.body.ids;
    const tag = req.body.tag;

    logger.silly({ tag, ids, type }, 'quarantine info');
    try {

      const result = await enforcementService.markQuarantine(userId, token, orgId, type, ids, tag);
      return res.json(result);
    } catch (e) {
      return errorHandler(req, res, e);
    }

  }

  async unquarantine(req, res) {
    const userId = req.user.id;
    const token = req.authInfo;
    const orgId = req.params.orgId;
    const type = req.body.type;
    const ids = req.body.ids;
    const tag = req.body.tag;

    try {

      const result = await enforcementService.unquarantine(userId, token, orgId, type, ids, tag);
      res.json(result);
    } catch (e) {
      return errorHandler(req, res, e);
    }

  }

  async unmarkQuarantine(req, res) {
    const userId = req.user.id;
    const token = req.authInfo;
    const orgId = req.params.orgId;
    const type = req.body.type;
    const ids = req.body.ids;
    const tag = req.body.tag;

    logger.silly({ tag, ids, type }, 'quarantine info');
    try {

      const result = await enforcementService.unmarkQuarantine(userId, token, orgId, type, ids, tag);
      return res.json(result);
    } catch (e) {
      return errorHandler(req, res, e);
    }

  }

  async suggestAPolicy(req, res) {
    const userId = req.user.id;
    const token = req.authInfo;
    const orgId = req.params.orgId;
    const type = req.body.type;
    const connections = req.body.connections;
    const target = req.body.target;

    logger.silly({ userId, token, orgId, type, target, connections }, 'suggest a policy info');
    try {

      const result = await enforcementService.suggestAPolicy(userId, token, orgId, type, target, connections);
      return res.json(result);
    } catch (e) {
      return errorHandler(req, res, e);
    }
  }

  async retrieveAPolicy(req, res) {
    const userId = req.user.id;
    const token = req.authInfo;
    const orgId = req.params.orgId;
    const type = req.body.type;
    const target = req.body.target;

    try {

      const result = await enforcementService.retrieveAPolicy(userId, token, orgId, type, target);
      return res.json(result);
    } catch (e) {
      return errorHandler(req, res, e);
    }
  }

  async createUpdatePolicy(req, res) {
    const userId = req.user.id;
    const token = req.authInfo;
    const orgId = req.params.orgId;
    const type = req.body.type;
    const rules = req.body.rules;
    const target = req.body.target;
    const zeroTrustMode = req.body.zeroTrustEnabled;

    logger.silly({ userId, token, orgId, type, target, rules }, 'createUpdate policy info');
    try {

      const result = await enforcementService.createUpdatePolicy(userId, token, orgId, type, target, rules, zeroTrustMode);
      return res.json(result);
    } catch (e) {
      return errorHandler(req, res, e);
    }
  }

  async addPolicy(req, res) {
    const userId = req.user.id;
    const token = req.authInfo;
    const orgId = req.params.orgId;
    const type = req.body.type;
    const rules = req.body.rules;
    const target = req.body.target;
    const zeroTrustMode = req.body.zeroTrustEnabled;

    logger.silly({ userId, token, orgId, type, target, rules }, 'create policy info');
    try {

      const result = await enforcementService.addPolicy(userId, token, orgId, type, target, rules, zeroTrustMode);
      return res.json(result);
    } catch (e) {
      return errorHandler(req, res, e);
    }
  }

  async setLockdownMode(req, res) {
    const userId = req.user.id;
    const bearerToken = req.authInfo;
    const zeroTrustMode = req.body.mode;
    const orgId = req.params.orgId;

    const d = config.demo ? new Date(config.demo_es_date) : new Date(Date.now());
    const authToken = req.headers.es_token;
    const date = req.query.date ? Utils.getYYYY_MM_DD(req.query.date) : Utils.getYYYY_MM_DD(d);
    let url = req.originalUrl;
    url = url.split('?')[0];
    const control = req.query.control;
    const where = req.query.w || req.query.where || {};
    const refresh = req.query.refresh || false;
    const source = req.query.source || null;
    const destination = req.query.destination || null;
    const mode = req.query.mode || 'normal';
    const port = req.query.port || null;
    const arr = Object.entries(where) || [];
    const value = arr.sort().map((entry) => {
      return `${entry[0]}#${entry[1]}`;
    }).join('^');
    const key = `${url}#${orgId}#date#${date}#${value}`;
    const data = await cache.get(key);
    if (refresh !== 'true' && data) return res.json(data);

    try {
      const result = await enforcementService.setLockdownMode(userId, orgId, date, control, where, (refresh==='true'), mode, source, destination, port, zeroTrustMode, bearerToken, authToken);
      return res.json(result);
    } catch (e) {
      return errorHandler(req, res, e);
    }
  }

  async getLockdownMode(req, res) {
    const userId = req.user.id;
    const token = req.authInfo;
    const orgId = req.params.orgId;

    logger.silly({ userId, token, orgId }, 'getLockdownMode  info');
    try {

      const result = await enforcementService.getLockdownMode(userId, token, orgId);
      return res.json(result);
    } catch (e) {
      return errorHandler(req, res, e);
    }
  }
};
