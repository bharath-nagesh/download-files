const ApplicationTag = require('../application/applicationTag.model');
const Asset = require('../asset/asset.model');
const AssetDetail = require('../asset/assetDetail.model');
const CaveoAgents = require('../../models/caveoAgents.model');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-enforcement.service'
});
const Organization = require('../organization/organization.model');
const SubApplication = require('../subApplication/subApplication.model');
const PolicySourceMembers = require('../../models/policySourceMember.model');
const SubApplicationAssetMembers = require('../subApplication/subApplicationAssetMembers.model');

const rp = require('request-promise');
const uuid = require('uuid/v4');
const sequelize = require('../../../config/db.conf').getConnection();
const _ = require('lodash');
const isAppliance = require('../../../utils/isAppliance');
const SERVICE_TYPE = isAppliance() ? 'ec' : 'centralcollector';
module.exports = class EnforcementService {
  constructor(services) {
    this.objectTypes = ['application', 'sub-application', 'asset', 'assets', 'internet', 'external'];
    this.rp = rp.defaults({ insecure: true, rejectUnauthorized: false });
    logger.debug('called EnforcementService constructor');
    this.uriPrefix = `/${SERVICE_TYPE}/api/v1`;
  }

  async checkSupportedNetworkExists() {
    const count = await sequelize.query(`select id from asset_repo_endpoints where asset_repo_type_id in (select id from asset_repo_types where name in('VCD','VCENTER','NSX-V','NSX-T','VMC', 'AWS')) 
    and (is_active='enabled' or is_active = 'true')`, { type: sequelize.QueryTypes.SELECT });
    if (count.length > 0) {
      return true;
    }
    return false;
  }

  async checkVCDExists(orgId) {
    const does_vcd_exist = await sequelize.query(`select name, ar.id as source_id from asset_repo_endpoints ar, asset_repo_types art  
      where  (ar.is_active='enabled' or ar.is_active = 'true')  and ar.asset_repo_type_id = art.id and   
    ar.id in (select distinct asset_manager_id from asset_details  
    where organization_id = :orgId and asset_manager_id = 1)  `, {
      replacements: { orgId },
      type: sequelize.QueryTypes.SELECT
    });
    if (!(does_vcd_exist.length > 0)) return false;
    const vcd_credentials = await sequelize.query(`select * from remote_access_details b where b.organization_id =:orgId 
       and b.type= 'vcd' and (b.is_active ='enabled' or  b.is_active ='true' )`, {
      replacements: { orgId },
      type: sequelize.QueryTypes.SELECT
    });
    if (!(vcd_credentials > 0)) return false;

    return true;

  }

  async initQuarantine(userId, userToken, cOrgId, orgId) {
    return this._initQuarantine(userId, userToken, cOrgId, orgId, uuid());
  }

  async markQuarantine(userId, userToken, orgId, type, ids = null, tag = null) {

    if (type === 'application') {
      const apps = await ApplicationTag.findAll({ where: { id: ids } });
      logger.info({ apps }, 'apps');
      ids = apps.map((app) => {
        return app.security_tag_name;
      });

    } else if (type === 'sub-application') {
      const pgs = await SubApplication.findAll({ where: { id: ids } });
      ids = pgs.map((pg) => {
        return pg.security_tag_name;
      });
    }
    return this._markQuarantine(userId, userToken, orgId, type, ids);
  }

  async unmarkQuarantine(userId, userToken, orgId, type, ids = null, tag = null) {

    if (type === 'application') {
      const apps = await ApplicationTag.findAll({ where: { id: ids } });
      logger.info({ apps }, 'apps');
      ids = apps.map((app) => {
        return app.security_tag_name;
      });

    } else if (type === 'sub-application') {
      const pgs = await SubApplication.findAll({ where: { id: ids } });
      ids = pgs.map((pg) => {
        return pg.security_tag_name;
      });
    }
    return this._unmarkQuarantine(userId, userToken, orgId, type, ids);
  }

  async quarantine(userId, userToken, orgId, type, ids = null, tag = null) {

    if (type === 'application') {
      const apps = await ApplicationTag.findAll({ where: { id: ids } });

      ids = apps.map((app) => {
        return app.security_tag_name;
      }).join(',');
      logger.info({ ids }, 'new ids');
    } else if (type === 'sub-application') {
      const pgs = await SubApplication.findAll({ where: { id: ids } });
      ids = pgs.map((pg) => {
        return pg.security_tag_name;
      }).join(',');
    }
    return this._quarantine(userId, userToken, orgId, type, ids, tag);
  }

  async unquarantine(userId, userToken, orgId, type, ids = null) {
    if (type === 'application') {
      const apps = await ApplicationTag.findAll({ where: { id: ids } });
      ids = apps.map((app) => {
        return app.security_tag_name;
      }).join(',');
    } else if (type === 'sub-application') {
      const apps = await SubApplication.findAll({ where: { id: ids } });
      ids = apps.map((app) => {
        return app.security_tag_name;
      }).join(',');
    }
    return this._unquarantine(userId, userToken, orgId, type, ids);
  }

  //
  // The name of this method is misleading, it is called by UI when user asks to set zero trust (lockdown) mode, but this method does NOT set lockdown mode, that is done in createUpdatePolicy.
  //  This method gets
  //        all the suggested policies (and existing policies)
  //        current state of the lockdown (zero trust)
  //  The UI  shows this to user so they may select/edit/add policies/rules and then call createUpdatePolicy (which sets rules and sets lockdown(zero trust))
  //
  async setLockdownMode(userId, orgId, date, control, where, refresh, mode, source, destination, port, zeroTrustMode = 'test', token = null, authToken = null) {
    if (mode !== 'lockdown') {
      mode = 'test';
    }
    try {
      return this._getSuggestedRulesForOrg(userId, orgId, date, control, where, refresh, mode, source, destination, port, token, authToken);
    } catch (e) {
      if (!e.statusCode && !e.status) {
        e.status = 500;
      } else {
        e.status = e.statusCode ? e.statusCode : e.status;
      }

      if (e.error.code === 'ECONNREFUSED') e.message = 'Unable to set lockdown mode, please contact administrator';
      logger.error({ e, stack: e.stack }, 'error occurred setLockdownMode');
      throw e;
    }
  }

  async getLockdownMode(userId, userToken, orgId) {
    try {
      return this._getLockdownMode(userId, userToken, orgId);
    } catch (e) {
      if (!e.statusCode && !e.status) {
        e.status = 500;
      } else {
        e.status = e.statusCode ? e.statusCode : e.status;
      }

      if (e.error && (e.error.code === 'ECONNREFUSED')) e.message = 'Unable to get lockdown mode status, please contact administrator';
      logger.error({ e, stack: e.stack }, 'error occurred getLockdownMode');
      throw e;
    }
  }

  async createApplicationSecurityTag(userId, userToken, orgId, applicationId, tags = []) {
    logger.info({ applicationId }, 'app id');
    const subApplications = await PolicySourceMembers.findAll({
      where: {
        source_id: applicationId,
        source_type: 'Application'
      }
    });
    logger.info({ subApplications }, 'pg groups');
    const pgIds = subApplications.map(pg => pg.subApplicationId);
    logger.info({ pgIds }, 'pgIds');
    const assets = await SubApplicationAssetMembers.findAll({
      where: { policy_group_id: pgIds },
      include: [{ model: Asset, where: { type: { $ne: 'InfraStructure' } }, attributes: { include: ['vmId'] } }]
    });
    logger.info({ assets }, 'assets');
    const vmIds = assets.map(asset => asset.Asset.vmId);
    if (vmIds.length === 0) return;
    return this.createOrUpdateSecurityTag(userId, userToken, orgId, tags, vmIds);
  }

  async createOrUpdateSecurityTag(userId, userToken, orgId, tags = [], assets = null) {
    let data = await Asset.findAll({ where: { vmId: assets } });
    data = data || [];
    const vmIds = data.map(asset => asset.vmId);
    //TODO chris updateSecurityTags error
    try {
      return await this._createOrUpdateSecurityTags(userId, userToken, orgId, tags, vmIds);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'updateSecurityTags error');
    }
  }

  async addAssetsToSubAppSecurityTag(userId, userToken, orgId, subAppId) {
    const assets = await SubApplicationAssetMembers.findAll({
      where: { policy_group_id: subAppId },
      include: [{ model: Asset, where: { type: { $ne: 'InfraStructure' } }, attributes: { include: ['vmId'] } }]
    });
    const subApp = await SubApplication.findByPk(subAppId, { attributes: { include: ['security_tag_name'] } });
    const securityTag = subApp.security_tag_name;
    const assetVmIds = assets.map((asset) => {
      return asset.Asset.vmId;
    });
    //TODO chris updateSecurityTags error
    try {
      return await this._createOrUpdateSecurityTags(userId, userToken, orgId, securityTag, assetVmIds);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'updateSecurityTags error');
    }
  }

  async removeAssetFromSubAppSecurityTag(userId, userToken, orgId, appId, ids) {
    const app = await SubApplication.findByPk(appId, { attributes: { include: ['security_tag_name'] } });
    const assets = await Asset.findAll({ where: { $or: [{ vmId: ids }, { id: ids }] } });
    const securityTag = app.security_tag_name;
    const vmIds = assets.map((asset) => {
      return asset.vmId;
    });
    return this._detatchSecurityTags(userId, userToken, orgId, securityTag, vmIds);
  }

  async deleteSubAppSecurityTag(userId, userToken, orgId, subAppId, defaultSubAppId) {
    const defaultSubApp = await SubApplication.findByPk(defaultSubAppId);
    const subApp = await SubApplication.findByPk(subAppId, { include: [{ model: Asset }] });
    const vmIds = subApp.Assets.map((asset) => {
      return asset.vmId;
    });
    await this._deleteSecurityTags(userId, userToken, orgId, subApp.security_tag_name);
    //TODO chris updateSecurityTags error
    try {
      return await this._createOrUpdateSecurityTags(userId, userToken, orgId, defaultSubApp.security_tag_name, vmIds);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'updateSecurityTags error');
    }
  }

  async addAssetToAppSecurityTag(userId, userToken, orgId, appId) {

    const app = await ApplicationTag.findByPk(appId, {
      attributes: { include: ['security_tag_name'] },
      include: [{ model: Asset, where: { type: { $ne: 'InfraStructure' } }, attributes: { include: ['vmId'] } }]
    });
    const assetVmIds = app.Assets.map((asset) => {
      return asset.vmId;
    });
    const securityTag = app.security_tag_name;
    //TODO chris updateSecurityTags error
    try {
      return await this._createOrUpdateSecurityTags(userId, userToken, orgId, securityTag, assetVmIds);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'updateSecurityTags error');
    }
  }

  async removeAssetFromAppSecurityTag(userId, userToken, orgId, appId, ids) {
    const app = await ApplicationTag.findByPk(appId, { attributes: { include: ['security_tag_name'] } });
    const assets = await Asset.findAll({ where: { $or: [{ vmId: ids }, { id: ids }] } });
    const securityTag = app.security_tag_name;
    const vmIds = assets.map((asset) => {
      return asset.vmId;
    });
    return this._detatchSecurityTags(userId, userToken, orgId, securityTag, vmIds);
  }

  async addSubAppFromAppSecurityTag(userId, userToken, orgId, subAppId, appId) {
    const app = await ApplicationTag.findByPk(appId);
    const assets = await SubApplicationAssetMembers.findAll({
      where: { policy_group_id: subAppId },
      include: [{ model: Asset, where: { type: { $ne: 'InfraStructure' } }, attributes: { include: ['vmId'] } }]
    });
    const vmIds = assets.map((asset) => {
      return asset.Asset.vmId;
    });
    const securityTag = app.security_tag_name;
    //TODO chris updateSecurityTags error
    try {
      return await this._createOrUpdateSecurityTags(userId, userToken, orgId, securityTag, vmIds);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'updateSecurityTags error');
    }
  }

  async removeSubAppFromAppSecurityTag(userId, userToken, orgId, subAppId, appId) {
    const app = await ApplicationTag.findByPk(appId);
    const assets = await SubApplicationAssetMembers.findAll({
      where: { policy_group_id: subAppId },
      include: [{ model: model.Asset, where: { type: { $ne: 'InfraStructure' } }, attributes: { include: ['vmId'] } }]
    });
    const vmIds = assets.map((asset) => {
      return asset.Asset.vmId;
    });
    const securityTag = app.security_tag_name;
    return this._detatchSecurityTags(userId, userToken, orgId, securityTag, vmIds);
  }

  async addAssetToQuarantineAdmin(userId, userToken, orgId, vmIds) {
    const adminSecurityObj = await sequelize.query('select admin_security_tag_name from network_quarantine_tags where organization_id = :orgId', {
      replacements: { orgId },
      type: sequelize.QueryTypes.SELECT
    });
    const adminSecurityTag = adminSecurityObj[0].admin_security_tag_name;
    //TODO chris updateSecurityTags error
    try {
      return await this._createOrUpdateSecurityTags(userId, userToken, orgId, [adminSecurityTag], vmIds);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'updateSecurityTags error');
    }
  }

  async suggestAPolicy(userId, userToken, orgId, type, tag = null, connections = null) {
    try {
      const orgChain = await Organization.getOrgChain(orgId);
      const payload = await this._suggestAPolicy(userId, userToken, orgId, type, tag, connections);
      const policyData = await sequelize.query(`select organization_id,source_type,source_id,source_name,
            destination_type,destination_id,destination_name,port,network_security_policy_name from network_flows_policies where organization_id in (:orgChain) and is_active<>'false'`,
        { replacements: { orgChain }, type: sequelize.QueryTypes.SELECT });
      payload.rules = payload.rules.map((rule) => {
        if ((policyData.map(pd => pd.network_security_policy_name)).includes(rule.name)) {
          rule.status = 'existing';
          return rule;
        }
        return rule;
      });
      return payload;

    } catch (e) {
      if (!e.statusCode && !e.status) {
        e.status = 500;
      } else {
        e.status = e.statusCode ? e.statusCode : e.status;
      }
      if (e.error && e.error.code === 'ECONNREFUSED') e.message = 'Unable to suggest a policy, please contact administrator';
      logger.error({ e, stack: e.stack }, 'error occurred suggestAPolicy');
      throw e;
    }
  }

  async retrieveAPolicy(userId, userToken, orgId, type, target) {
    try {
      return this._retrieveAPolicy(userId, userToken, orgId, type, target);
    } catch (e) {
      if (!e.statusCode && !e.status) {
        e.status = 500;
      } else {
        e.status = e.statusCode ? e.statusCode : e.status;
      }

      if (e.error.code === 'ECONNREFUSED') e.message = 'Unable to retrieve a policy, please contact administrator';
      logger.error({ e, stack: e.stack }, 'error occurred retrieveAPolicy');
      throw e;
    }
  }

  // This method replaces the list of existing rules with the list provided.  This creates, updates and deletes rules.
  // The list of rules is the complete list of rules.  If you only need to add new rules without altering the existing
  // rules then use addPolicy()
  // INPUT
  //    - if target == ALL_APPS_AND_SUB_APPS_OF_ORG
  //              type='application' and rules is list of rules for all applications/sub-applications for org
  //              processing will determine target of each rule from direction and select source or destination
  //              OUTPUT:
  //                  {
  //                    target = ALL_APPS_AND_SUB_APPS_OF_ORG
  //                    rules = rules is list of rules for all applications/sub-applications for org (after policies have been written)
  //                  }
  //    - if target <> ALL_APPS_AND_SUB_APPS_OF_ORG
  //             target is an application or sub applicatio name, type= application and rules is a list of rules for target
  //              OUTPUT:
  //                  {
  //                   target = <input target>
  //                   rules = rules for target after policy has been written
  //                  }
  //
  async createUpdatePolicy(userId, userToken, orgId, type, targetIn = null, rulesIn = null, zeroTrustShouldBeEnabled = null) {
    try {
      // --- update zero trust if needed
      logger.info('Update zero trust settings...');
      await this._updateZeroTrustSetting(userId, userToken, orgId, zeroTrustShouldBeEnabled);
      // --- create a map from target name to list of rules
      let targetToRulesMap = {};
      if (targetIn.toUpperCase() === 'ALL_APPS_AND_SUB_APPS_OF_ORG') {
        targetToRulesMap = this._parseTargetToRuleMapFromRulesList(rulesIn);
      } else {
        targetToRulesMap[targetIn] = rulesIn;
      }
      // --- For each target update policy
      const allPromises = [];
      for (const oneTarget in targetToRulesMap) {
        const rulesForOneTarget = targetToRulesMap[oneTarget];
        logger.info({ oneTarget }, 'Requesting central collector to create/update policies for one target');
        allPromises.push(this._createUpdateOnePolicy(userId, userToken, orgId, type, oneTarget, rulesForOneTarget));
      }
      // --- wait for policies to be applied to all targets BEFORE changing zero trust
      await Promise.all(allPromises);
      logger.info('All create/update policy requests sent to central collector have completed.');

      // --- combine the results from each target and return a single object
      let newRules = [];
      await Promise.all(allPromises).then(function (values) {
        for (const valueIdx in values) {
          const oneValue = values[valueIdx];
          if (oneValue && (oneValue.length > 0)) {
            newRules = newRules.concat(oneValue);
          }
        }
      });
      // --- return object
      return {
        target: targetIn,
        precedence: 0,
        rules: newRules
      };
    } catch (e) {
      if (!e.statusCode && !e.status) {
        e.status = 500;
      } else {
        e.status = e.statusCode ? e.statusCode : e.status;
      }
      if (e.error && e.error.code === 'ECONNREFUSED') e.message = 'Unable to create a policy, please contact administrator';
      logger.error({ e, stack: e.stack }, 'error occurred createUpdateAPolicy');
      throw e;
    }
  }

  // This method creates new rules.  It does not remove.  The list of rules is just the list of new
  //    rules to be created/updated.
  // INPUT
  //             target is an application  name, type= application and rules is a list of rules for target
  //              OUTPUT:
  //                  {
  //                   target = <input target>
  //                   rules = rules for target after policy has been written
  //                  }
  //
  async addPolicy(userId, userToken, orgId, type, targetIn = null, rulesIn = null, zeroTrustShouldBeEnabled = null) {
    try {
      // --- update zero trust if needed
      logger.info('Update zero trust settings...');
      await this._updateZeroTrustSetting(userId, userToken, orgId, zeroTrustShouldBeEnabled);
      // --- add policy
      let newRules = [];
      if ((rulesIn != null) && (rulesIn.length > 0)) {
        // --- create a map from target name to list of rules
        await this._addPolicy(userId, userToken, orgId, type, targetIn, rulesIn);
        const newPolicies = await this._retrieveAPolicy(userId, userToken, orgId, type, targetIn);
        if ((newPolicies !== null) && (newPolicies.length > 0)) {
          const newPolicy = newPolicies[0];
          newRules = newPolicy.rules;
        }
      }
      // --- return object
      return {
        target: targetIn,
        precedence: 0,
        rules: newRules
      };
    } catch (e) {
      if (!e.statusCode && !e.status) {
        e.status = 500;
      } else {
        e.status = e.statusCode ? e.statusCode : e.status;
      }
      if (e.error && e.error.code === 'ECONNREFUSED') e.message = 'Unable to add a policy, please contact administrator';
      logger.error({ e, stack: e.stack }, 'error occurred addPolicy');
      throw e;
    }
  }

  async _updateZeroTrustSetting(userId, userToken, orgId, zeroTrustShouldBeEnabled = null) {
    if (zeroTrustShouldBeEnabled != null) {
      const zeroTrustEnabled = await this._getLockdownMode(userId, userToken, orgId);
      if (zeroTrustEnabled && !zeroTrustShouldBeEnabled) {
        logger.info('Disabling zero trust');
        await this._setLockdownMode(userId, userToken, orgId, 'test');
      } else if (!zeroTrustEnabled && zeroTrustShouldBeEnabled) {
        logger.info('Enabling zero trust');
        await this._setLockdownMode(userId, userToken, orgId, 'lockdown');
      } else {
        logger.info('Currently active zero trust setting matches the desired zero trust setting, nothing to do.');
      }
    } else {
      logger.info('No desired zero trust setting specified (zeroTrustEnabled), so nothing to do.');
    }
  }

  async _createUpdateOnePolicy(userId, userToken, orgId, type, target = null, rules = null) {
    // --- apply policy (add, remove, update) to target
    await this._createUpdatePolicy(userId, userToken, orgId, type, target, rules);
    // --- retrieve the updated policy and return it
    return this._retrieveAPolicy(userId, userToken, orgId, type, target);
  }

  // GET CENTRAL COLLECTOR IP
  async getAgentIpAddress() {
    // return 'https://localhost:8080'; // jimjimjim remove this - hack to work on local centralcollector
    const caveoAgent = await CaveoAgents.findOne({
      where: {
        agent_name: 'CentralCollector',
        $or: [{ isActive: { $ne: 'false' } }]
      }
    });
    logger.info({ ip: caveoAgent.ipAddress }, 'the ip of central collector');
    return caveoAgent.ipAddress;
  }

  // LOCKDOWN MODE
  async _setLockdownMode(userId, userToken, orgId, mode) {
    const formData = {
      userId, userToken, orgId, mode
    };
    const ipAddress = await this.getAgentIpAddress();
    const url = `${ipAddress}${this.uriPrefix}/enforcementMode`;
    const allow = [];
    allow[0] = await this.checkSupportedNetworkExists();
    allow[1] = await this.checkVCDExists(orgId);
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    if (_.every(allow, elem => !elem)) {
      const e = new Error('No supported network configured. Please contact your Caveonix Admin');
      e.status = 403;
      throw e;
    }
    return this.rp.post(url, { form: formData });
  }

  //
  // Returns
  //   true - lockdown (zero trust) enabled
  //   false - lockdown (zero trust) disabled or it is not enabled
  async _getLockdownMode(userId, userToken, orgId) {
    const qs = {
      userId, userToken, orgId
    };
    const ipAddress = await this.getAgentIpAddress();
    const url = `${ipAddress}${this.uriPrefix}/enforcementMode`;
    const allow = [];
    allow[0] = await this.checkSupportedNetworkExists();
    allow[1] = await this.checkVCDExists(orgId);
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    if ((_.every(allow, elem => !elem))) {
      const e = new Error('No supported network configured. Please contact your Caveonix Admin');
      e.status = 403;
      throw e;
    }
    const mode = await this.rp.get(url, { qs });
    if (!mode || (mode.length <= 0)) {
      logger.warn('No lockdown (zero trust) mode returned from central collector.  ' +
        'Check that networkcontroller.lockdown is true in centralcollector application.properties.  ' +
        'Assuming lockdown is not enabled.');
    }
    return (mode === 'lockdown');
  }

  // SECURITY GROUP REQUESTS
  async _getSecurityGroups(userId, userToken, orgId) {
    const formData = {
      userId, userToken, orgId
    };
    const ipAddress = await this.getAgentIpAddress();
    const url = `${ipAddress}${this.uriPrefix}/securityGroup`;
    const allow = [];
    allow[0] = await this.checkSupportedNetworkExists();
    allow[1] = await this.checkVCDExists(orgId);
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    if ((_.every(allow, elem => !elem))) {
      const e = new Error('No supported network configured. Please contact your Caveonix Admin');
      e.status = 403;
      throw e;
    }
    return this.rp.post(url, { form: formData });
  }

  // SECURITY TAG REQUESTS
  async _getSecurityTags(userId, userToken, orgId) {
    const qs = {
      userId, userToken, orgId
    };
    const ipAddress = await this.getAgentIpAddress();
    const url = `${ipAddress}${this.uriPrefix}/securityTags`;
    return this.rp.get(url, { qs });
  }

  async _createOrUpdateSecurityTags(userId, userToken, orgId, tags = [], assets = null) {
    if (!Array.isArray(assets)) assets = assets.split(',');
    const AssetArr = await Asset.findAll({
      where: { vmid: { $in: assets } },
      include: [{ model: AssetDetail, where: { asset_manager_id: { $ne: 0 } } }]
    });
    assets = AssetArr.map(a => {
      return a.vmId;
    });
    if (tags != null && tags.length < 1) {
      const e = new Error('missing parameters: tags');
      e.status = 400;
      throw e;
    }
    if (Array.isArray(tags)) {
      tags = tags.join(',');
    }
    if (Array.isArray(assets)) {
      assets = assets.join(',');
    }
    let formData;
    if (assets === '') assets = null;
    if (assets) {
      formData = {
        userId, userToken, orgId, tags, assets
      };
    } else {
      formData = {
        userId, userToken, orgId, tags
      };
    }
    const ipAddress = await this.getAgentIpAddress();
    const url = `${ipAddress}${this.uriPrefix}/createUpdateSecurityTags`;
    try {
      const allow = [];
      allow[0] = await this.checkSupportedNetworkExists();
      allow[1] = await this.checkVCDExists(orgId);
      process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
      if ((_.every(allow, elem => !elem))) {
        const e = new Error('No supported network configured. Please contact your Caveonix Admin');
        e.status = 403;
        throw e;
      }
      if (formData.assets) {
        return this.rp.post(url, { form: formData });
      }
      return true;
    } catch (error) {
      logger.error({ error, stack: error.stack, formData, url }, 'error occurred createupdate security tag');
      error.status = 503;
      throw error;
    }
  }

  async _deleteSecurityTags(userId, userToken, orgId, tags = []) {
    if (tags.length < 1) {
      const e = new Error('missing parameters: tags');
      e.status = 400;
      throw e;
    }
    if (Array.isArray(tags)) {
      tags = tags.join(',');
    }
    const formData = {
      userId, orgId, tags, userToken
    };
    const ipAddress = await this.getAgentIpAddress();
    const url = `${ipAddress}${this.uriPrefix}/deleteSecurityTags`;
    try {
      const allow = [];
      allow[0] = await this.checkSupportedNetworkExists();
      allow[1] = await this.checkVCDExists(orgId);
      process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
      if ((_.every(allow, elem => !elem))) {
        const e = new Error('No supported network configured. Please contact your Caveonix Admin');
        e.status = 403;
        throw e;
      }
      return this.rp.post(url, { form: formData });
    } catch (error) {
      logger.error({ error, stack: error.stack, formData, url }, 'error occurred in delete security tag');
      error.status = 503;
      throw error;
    }
  }

  async _detatchSecurityTags(userId, userToken, orgId, tags = [], assets = null) {
    if (!Array.isArray(assets)) assets = assets.split(',');
    const AssetArr = await Asset.findAll({
      where: { vmid: { $in: assets } },
      include: [{ model: AssetDetail, where: { asset_manager_id: { $ne: 0 } } }]
    });
    assets = AssetArr.map(a => {
      return a.vmId;
    });
    if (tags.length < 1) {
      const e = new Error('missing parameters: tags');
      e.status = 400;
      throw e;
    }
    if (Array.isArray(tags)) {
      tags = tags.join(',');
    }
    if (Array.isArray(assets)) {
      assets = assets.join(',');
    }
    let formData;
    if (assets) {
      formData = {
        userId, userToken, orgId, tags, assets
      };
    } else {
      const e = new Error('missing parameters: assets');
      e.status = 400;
      throw e;
    }
    logger.info({ formData }, 'form data');
    const ipAddress = await this.getAgentIpAddress();
    const url = `${ipAddress}${this.uriPrefix}/detachSecurityTagAssets`;

    try {
      const allow = [];
      allow[0] = await this.checkSupportedNetworkExists();
      allow[1] = await this.checkVCDExists(orgId);
      process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
      if (allow) {
        return this.rp.post(url, { formData, headers: { 'Content-Type': 'multipart/form-data', name: 'api' } });
      }
    } catch (error) {
      logger.error({ error, stack: error.stack, formData, url }, 'error occurred detatch security tag');
      error.status = 503;
      throw error;
    }
  }

  // POLICY MANAGER REQUESTS
  async _initQuarantine(userId, userToken, cOrgId, orgId, uniqueTag, force = false) {
    if (!uniqueTag) {
      const e = new Error('missing parameters: tags');
      e.status = 400;
      throw e;
    }

    const formData = {
      userId,
      userToken,
      cOrgId,
      orgId,
      quarantineId: `QU_${uniqueTag}`,
      quarantineAdminId: `QU_${uniqueTag}_ADMIN`,
      force
    };
    const ipAddress = await this.getAgentIpAddress();
    const url = `${ipAddress}${this.uriPrefix}/quarantineInit/`;
    try {
      return this.rp.post(url, { form: formData });
    } catch (error) {
      error.status = 503;
      throw error;
    }
  }

  async _quarantine(userId, userToken, orgId, type, ids = null, tag = null) {
    if (!ids) {
      const e = new Error('missing parameters: ids');
      e.status = 400;
      throw e;
    }
    if (Array.isArray(ids)) {
      ids = ids.join(',');
    }
    logger.info({ type }, 'type');
    if (!this.objectTypes.includes(type.toLowerCase()) || !type) {
      const e = new Error('malformed parameter: type');
      e.status = 400;
      throw e;
    }
    if (Array.isArray(tag)) {
      tag = tag.join(',');
    }

    let formData;
    if (tag) {
      formData = {
        userId, userToken, orgId, tag, ids, type
      };
    } else {
      formData = {
        userId, userToken, orgId, ids, type
      };
    }
    const ipAddress = await this.getAgentIpAddress();
    logger.info({ info: `${ipAddress}${this.uriPrefix}/quarantine`, formData }, 'the endpoint');
    const url = `${ipAddress}${this.uriPrefix}/quarantine`;
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    return this.rp.post(url, { form: formData });
  }

  async _unquarantine(userId, userToken, orgId, type, ids = null) {
    if (!ids) {
      const e = new Error('missing parameters: ids');
      e.status = 400;
      throw e;
    }
    if (Array.isArray(ids)) {
      ids = ids.join(',');
    }

    if (!this.objectTypes.includes(type.toLowerCase()) || !type) {
      const e = new Error('malformed parameter: type');
      e.status = 400;
      throw e;
    }
    const formData = {
      userId, userToken, orgId, ids, type
    };

    const ipAddress = await this.getAgentIpAddress();
    const url = `${ipAddress}${this.uriPrefix}/unquarantine`;
    const allow = [];
    allow[0] = await this.checkSupportedNetworkExists();
    allow[1] = await this.checkVCDExists(orgId);
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    if ((_.every(allow, elem => !elem))) {
      const e = new Error('No supported network configured. Please contact your Caveonix Admin');
      e.status = 403;
      throw e;
    }
    return this.rp.post(url, { form: formData });
  }

  async _markQuarantine(userId, userToken, orgId, type, ids) {
    logger.info({ ids, type }, 'params for marking');
    try {
      if (type.toLowerCase() === 'application') {
        await sequelize.query(`update application_tags set is_quarantined = 'marked' where security_tag_name in (:ids)`, { replacements: { ids } });
      } else if (type.toLowerCase() === 'sub-application') {
        await sequelize.query(`update sub_applications set is_quarantined = 'marked' where security_tag_name in (:ids)`, { replacements: { ids } });
      } else if (type.toLowerCase() === 'asset') {
        await sequelize.query(`update network_security_tag_assets set is_quarantined = 'marked' where asset_instance_uuid in (:ids)`, { replacements: { ids } });
      }
      return 'Success';
    } catch (e) {
      logger.error({ e }, 'error occurred marking for quarantine');
      throw e;
    }
  }

  async _unmarkQuarantine(userId, userToken, orgId, type, ids) {
    logger.info({ ids, type }, 'params for marking');
    try {
      if (type.toLowerCase() === 'application') {
        await sequelize.query(`update application_tags set is_quarantined = 'false' where security_tag_name in (:ids)`, { replacements: { ids } });
      } else if (type.toLowerCase() === 'sub-application') {
        await sequelize.query(`update sub_applications set is_quarantined = 'false' where security_tag_name in (:ids)`, { replacements: { ids } });
      } else if (type.toLowerCase() === 'asset') {
        await sequelize.query(`update network_security_tag_assets set is_quarantined = 'false' where asset_instance_uuid in (:ids)`, { replacements: { ids } });
      }

      return 'Success';
    } catch (e) {
      logger.error({ e }, 'error occurred unmarking for quarantine');
      throw e;
    }
  }

  async _suggestAPolicy(userId, userToken, orgId, type, target, connections = null) {
    if (!target) {
      const e = new Error('missing parameters: target');
      e.status = 400;
      throw e;
    }
    const orgChain = await Organization.getOrgChain(orgId);
    if (type.toLowerCase() === 'application' && (target.toUpperCase() !== 'EXTERNAL' && target.toUpperCase() !== 'INTERNET')) {
      const app = await ApplicationTag.findOne({
        where: { name: target, organization_id: orgChain },
        attributes: { include: ['security_tag_name'] }
      });
      target = _.get(app, 'security_tag_name', '');
    }
    if (type.toLowerCase() === 'sub-application' && (target.toUpperCase() !== 'EXTERNAL' && target.toUpperCase() !== 'INTERNET')) {
      const pg = await SubApplication.findOne({
        where: { name: target, organization_id: orgChain },
        attributes: { include: ['security_tag_name'] }
      });
      target = _.get(pg, 'security_tag_name', '');
    }
    let formData;
    if (connections && Array.isArray(connections)) {
      const cons = await this.validateConnections(connections, orgId);

      formData = {
        userId, userToken, orgId, target: target, connections: JSON.stringify(cons)
      };
    } else {
      formData = {
        userId, userToken, orgId, target: target
      };
    }

    const ipAddress = await this.getAgentIpAddress();
    const url = `${ipAddress}${this.uriPrefix}/suggestPolicyDefinition/`;
    const allow = [];
    allow[0] = await this.checkSupportedNetworkExists();
    allow[1] = await this.checkVCDExists(orgId);
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    if ((_.every(allow, elem => !elem))) {
      const e = new Error('No supported network configured. Please contact your Caveonix Admin');
      e.status = 403;
      throw e;
    }
    try {
      logger.info({formData}, "Sending suggestPolicy request to centralcollector")
      return this.rp.post(url, { formData, json: true });
    } catch (e) {
      e.status = 503;
      throw e;
    }

  }

  async _retrieveAPolicy(userId, userToken, orgId, type, target) {
    // logger.warn('returnning stubbed data')
    // return stubbedData

    if (type.toLowerCase() === 'application') {
      const app = await ApplicationTag.findOne({
        where: { name: target, organization_id: orgId },
        attributes: { include: ['security_tag_name'] }
      });
      target = app.security_tag_name;
    }
    if (type.toLowerCase() === 'sub-application') {
      const pg = await SubApplication.findOne({
        where: { name: target, organization_id: orgId },
        attributes: { include: ['security_tag_name'] }
      });
      target = pg.security_tag_name;
    }
    const formData = {
      userId, userToken, orgId, tag: target
    };
    const ipAddress = await this.getAgentIpAddress();
    const url = `${ipAddress}${this.uriPrefix}/retrievePolicyDefinition/`;
    const allow = [];
    allow[0] = await this.checkSupportedNetworkExists();
    allow[1] = await this.checkVCDExists(orgId);
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    if ((_.every(allow, elem => !elem))) {
      const e = new Error('No supported network configured. Please contact your Caveonix Admin');
      e.status = 403;
      throw e;
    }
    return this.rp.post(url, { formData, json: true });
  }

  _parseTargetToRuleMapFromRulesList(rules) {
    const targetToRulesMap = {};
    for (const oneRuleIdx in rules) {
      const oneRule = rules[oneRuleIdx];
      const direction = oneRule.direction || null;
      const source = oneRule.source || null;
      const destination = oneRule.destination || null;
      if (!direction || !source || !destination) {
        logger.warn({
          direction,
          source,
          destination
        }, 'Malformed rule while parsing rules to rule map.  Ignoring this rule.');
      } else {
        let target = null;
        if (direction.toLowerCase() === 'incoming') {
          target = destination;
        } else if (direction.toLowerCase() === 'outgoing') {
          target = source;
        }
        if (target != null) {
          if (target in targetToRulesMap) {
            const existingRules = targetToRulesMap[target];
            existingRules.push(oneRule);
            targetToRulesMap[target] = existingRules;
          } else {
            targetToRulesMap[target] = [oneRule];
          }
        }
      }
    }
    return targetToRulesMap;
  }

  async _addPolicy(userId, userToken, orgId, type, target, rules) {

    let securityTag;
    if (type.toLowerCase() === 'application') {
      const app = await ApplicationTag.findOne({
        where: { name: target, organization_id: orgId },
        attributes: { include: ['security_tag_name'] }
      });
      securityTag = app.security_tag_name;
    }

    if (type.toLowerCase() === 'sub-application') {
      const pg = await SubApplication.findOne({
        where: { $or: [{ name: target }, { security_tag_name: target }], organization_id: orgId },
        attributes: { include: ['security_tag_name'] }
      });
      securityTag = pg.security_tag_name;
    }
    let rulesWithTags = [];
    for (const oneRule of rules) {
      rulesWithTags.push(await this._addTagsToRuleSecondaryGroup(oneRule, orgId));
    }
    const formData = {
      userId, userToken, orgId, policyDefinition: JSON.stringify({ target: securityTag, rules: rulesWithTags })
    };
    const ipAddress = await this.getAgentIpAddress();
    const url = `${ipAddress}${this.uriPrefix}/addRulesToPolicy/`;
    const allow = [];
    allow[0] = await this.checkSupportedNetworkExists();
    allow[1] = await this.checkVCDExists(orgId);
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    if ((_.every(allow, elem => !elem))) {
      const e = new Error('No supported network configured. Please contact your Caveonix Admin');
      e.status = 403;
      throw e;
    }
    return this.rp.post(url, { formData, json: true });
  }

  async _addTagsToRuleSecondaryGroup(oneRule, orgId) {
    const secondaryGroup = oneRule.secondaryGroup;
    const type = secondaryGroup.type;
    if ((type !== 'application') && (type !== 'sub-application')) {
      return oneRule;
    }
    const destination = oneRule.destinationApplication;
    let securityTag;
    if (type.toLowerCase() === 'application') {
      const app = await ApplicationTag.findOne({
        where: { name: destination, organization_id: orgId },
        attributes: { include: ['security_tag_name'] }
      });
      securityTag = app.security_tag_name;
    }

    if (type.toLowerCase() === 'sub-application') {
      const pg = await SubApplication.findOne({
        where: { $or: [{ name: target }, { security_tag_name: target }], organization_id: orgId },
        attributes: { include: ['security_tag_name'] }
      });
      securityTag = pg.security_tag_name;
    }
    oneRule.secondaryGroup = {ids:[securityTag], type: "tag"};
    return oneRule;
  }

  async _createUpdatePolicy(userId, userToken, orgId, type, target, rules) {

    let securityTag;
    if (type.toLowerCase() === 'application') {
      const app = await ApplicationTag.findOne({
        where: { name: target, organization_id: orgId },
        attributes: { include: ['security_tag_name'] }
      });
      securityTag = app.security_tag_name;
    }

    if (type.toLowerCase() === 'sub-application') {
      const pg = await SubApplication.findOne({
        where: { $or: [{ name: target }, { security_tag_name: target }], organization_id: orgId },
        attributes: { include: ['security_tag_name'] }
      });
      securityTag = pg.security_tag_name;
    }
    const formData = {
      userId, userToken, orgId, policyDefinition: JSON.stringify({ target: securityTag, rules })
    };
    const ipAddress = await this.getAgentIpAddress();
    const url = `${ipAddress}${this.uriPrefix}/createUpdatePolicy/`;
    const allow = [];
    allow[0] = await this.checkSupportedNetworkExists();
    allow[1] = await this.checkVCDExists(orgId);
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    if ((_.every(allow, elem => !elem))) {
      const e = new Error('No supported network configured. Please contact your Caveonix Admin');
      e.status = 403;
      throw e;
    }
    return this.rp.post(url, { formData, json: true });
  }

  // UTIL FUNCTIONS
  async validateConnections(connections, orgId) {
    const resData = [];
    for (let i = 0; i < connections.length; i++) {
      const c = connections[i];
      if (!['incoming', 'outgoing'].includes(c.direction)) {
        const e = new Error({ status: 400, message: 'improper direction type' });
        throw e;
      }
      if (!this.objectTypes.includes(c.endpoint.type.toLowerCase())) {
        const e = new Error({ status: 400, message: 'improper type' });
        throw e;
      }
      if (c.endpoint.type.toLowerCase() === 'external' || c.endpoint.type.toLowerCase() === 'internet') {
        resData.push({
          direction: c.direction,
          port: c.port,
          endpoint: {
            type: c.endpoint.type,
            id: c.endpoint.name
          }
        });
      }
      if (c.endpoint.type.toLowerCase() === 'application' || c.endpoint.type.toLowerCase() === 'sub-application') {
        let securityTag;
        if (c.endpoint.type.toLowerCase() === 'application') {
          const app = await ApplicationTag.findOne({
            where: { name: c.endpoint.name, organization_id: orgId },
            attributes: { include: ['security_tag_name'] }
          });
          logger.info({ app }, 'stupid app');
          securityTag = app.security_tag_name;
        }

        if (c.endpoint.type.toLowerCase() === 'sub-application') {
          const pg = await SubApplication.findOne({
            where: { name: c.endpoint.name, organization_id: orgId },
            attributes: { include: ['security_tag_name'] }
          });
          securityTag = pg.security_tag_name;
        }

        resData.push({
          direction: c.direction,
          port: c.port,
          endpoint: {
            type: c.endpoint.type,
            id: securityTag
          }
        });
      }
    }
    return resData;
  }

  async removeAssetFromApplicationTag(userId, userToken, orgId, applicationId, tags = []) {
    const subApplications = await PolicySourceMembers.findAll({
      where: {
        source_id: applicationId,
        source_type: 'Application'
      }
    });
    const pgIds = subApplications.map((pg) => {
      return pg.subApplicationId;
    });
    const assets = await SubApplicationAssetMembers.findAll({
      where: { policy_group_id: pgIds },
      include: [{ model: Asset, where: { type: { $ne: 'InfraStructure' } }, attributes: { include: ['vmId'] } }]
    });
    const vmIds = assets.map((asset) => {
      return asset.Asset.vmId;
    });
    if (vmIds) {
      return this._detatchSecurityTags(userId, userToken, orgId, tags, vmIds);
    } else {
      return this._deleteSecurityTags(userId, userToken, orgId, tags);
    }
  }

  //  ========================================
  //  METHODS TO GET SUGGESTED RULES FOR WHOLE ORG

  //
  // result:
  //    {
  //    zeroTrustEnabled: <true or false>
  //    target: "<app or sub app target or special value meaning all (ALL_APPS_AND_SUB_APPS_OF_ORG)>"
  //    precedence: <number>,
  //    rules: [
  //            {
  //              secondaryGroup: {type: <ip-group>, ids: [<cidr>,...]},
  //              name: <rule name>,
  //              destination: <friendly name for destination>,
  //              from: <future>,
  //              source: <friendly name for source>,
  //              to: <future>,
  //              ports:
  //                [
  //                  {type: "ports",
  //                    details: { protocol: <tcp, udp>, name: <port name>, ports: <port numbers> }
  //                  }
  //                ]
  //              status: <existing, suggested>,
  //              direction: <incoming, outgoing>
  //            }, ...
  //          ]
  //    }
  async _getSuggestedRulesForOrg(userId, orgId, date, control, where, refresh, mode, source, destination, port, token = null, authToken = null) {
    // -- get policy compliance circle data (hopefully from cache) and lockdown mode

    const NetworkFlowService = require('../networkFlow/networkFlow.service');
    const networkFlowService = new NetworkFlowService();
    const dataArray = await Promise.all([
      networkFlowService.getPolicyComplianceCircle(orgId, date, control, where, refresh, mode, source, destination, port, token, authToken),
      this._getLockdownMode(userId, token, orgId)
    ]);

    // -- parse out the list of connections from the compliance circle data
    const suggestedRules = await this._getSuggestedRulesFromCaveoCircle(userId, token, orgId, dataArray[0]);
    return {
      target: 'ALL_APPS_AND_SUB_APPS_OF_ORG',
      precedence: 0,
      rules: suggestedRules,
      zeroTrustEnabled: dataArray[1]
    };
  }

  //
  // INPUT:  caveoCircle
  // OUTPUT:  Array of {
  //                    target: <app or sub app>,
  //                    type: <application, sub-application>,
  //                    connections: [
  //                                  {
  //                                   direction: <outgoing, incoming>,
  //                                   endpoint: {
  //                                              type: <internet, external, ??>,
  //                                              name: [ <ip or tag>,...]
  //                                             },
  //                                   port: "<port>"
  //                                  },...
  //                                ]
  //
  async _getSuggestedRulesFromCaveoCircle(userId, token, orgId, caveoCircle) {
    const containers = caveoCircle.data.containers || [];
    let suggestedRules = [];
    const containerToConnections = this._parseConnectionsFromContainerList(containers); // map from container name to list of connections (both incoming and outgoing), only for apps (internet/external will be added to correct apps as incoming)
    for (const oneContainerName in containerToConnections) {
      const connections = containerToConnections[oneContainerName];
      //TODO: Validate with chris/JC that we switched to always do suggestAPolicy with type 'application' - there is no way in UI to select sub-application anymore.
      const result = await this.suggestAPolicy(userId, token, orgId, 'application', oneContainerName, connections);
      const suggestedRulesForOneContainer = result.rules || [];
      suggestedRules = suggestedRules.concat(suggestedRulesForOneContainer);
    }
    return suggestedRules;
  }

  _parseConnectionsFromContainerList(containers) {
    const containerToConnections = {};
    for (const oneContainerIdx in containers) {
      const oneContainer = containers[oneContainerIdx];
      const containerName = oneContainer.containerName;
      const connections = this._parseConnectionsFromOneContainer(oneContainer);
      if ((containerName.toLowerCase() === 'internet') || (containerName.toLowerCase() === 'external')) {
        // --- Need to separate the connections into each application or sub-applications with direction == incoming
        for (const oneConnectionIdx in connections) {
          const oneConnection = connections[oneConnectionIdx];
          const connectionTarget = oneConnection.target;
          if (connectionTarget in containerToConnections) {
            containerToConnections[connectionTarget].push(oneConnection);
          } else {
            containerToConnections[connectionTarget] = [oneConnection];
          }
        }
      } else {
        const targetUnsplit = containerName;
        const targetSplit = targetUnsplit.split('^^');
        const targetApplication = targetSplit[0]; // just application

        if (targetApplication in containerToConnections) {
          const existingConnections = containerToConnections[targetApplication];
          const mergedConnections = connections.concat(existingConnections);
          containerToConnections[targetApplication] = mergedConnections;
        } else {
          containerToConnections[targetApplication] = connections;
        }
      }
    }
    return containerToConnections;
  }

  // OUTPUT:
  //            [
  //                                  {
  //                                   target: <app name, sub-app name>,
  //                                   direction: <outgoing, incoming>,
  //                                   endpoint: {
  //                                              type: <internet, external, application, sub-application, any>,
  //                                              name: [ <ip or tag>,...]
  //                                             },
  //                                   port: "<port>"
  //                                  },...
  //                                ]
  // NOTE:  currently only support connections for application
  _parseConnectionsFromOneContainer(oneContainer) {
    const connections = [];
    let direction = 'outgoing';
    let typeBasedOnContainer = null;
    let otherEndpointApplicationName = '';
    let targetBasedOnContainer = oneContainer.containerName;
    if (oneContainer.containerName.toLowerCase() === 'internet') {
      direction = 'incoming';
      typeBasedOnContainer = 'internet';
      targetBasedOnContainer = null;
    } else if (oneContainer.containerName.toLowerCase() === 'external') {
      direction = 'incoming';
      typeBasedOnContainer = 'external';
      targetBasedOnContainer = null;
    }
    const ribbons = oneContainer.ribbons;
    for (const oneRibbonIdx in ribbons) {
      const oneRibbon = ribbons[oneRibbonIdx];
      let connectionType = null;
      let targetOfConnection = null;
      if (!typeBasedOnContainer) {
        if (oneRibbon.destination.toLowerCase() === 'internet') {
          connectionType = 'internet';
        } else if (oneRibbon.destination.toLowerCase() == 'external') {
          connectionType = 'external';
        } else {
          //TODO: currently we assume all connections are application level, in future we may want to target sub-application
          connectionType = 'application';
          const otherEndpointUnsplit = oneRibbon.destination;
          const otherEndpointSplit = otherEndpointUnsplit.split('^^');
          otherEndpointApplicationName = otherEndpointSplit[0]; // just application name
        }
      } else {
        connectionType = typeBasedOnContainer;
      }
      if (!targetBasedOnContainer) {
        targetOfConnection = oneRibbon.destination;
      } else {
        targetOfConnection = targetBasedOnContainer;
      }
      const ports = oneRibbon.details.ports || [];
      for (const onePortIdx in ports) {
        const onePort = ports[onePortIdx];
        if (onePort.port.trim() !== '0') {
          const oneConnection = {};
          const oneEndpoint = {};

          // --- direction, port and type
          oneConnection.direction = direction;
          oneConnection.port = onePort.port;
          oneEndpoint.type = connectionType;

          // --- target
          const targetUnsplit = targetOfConnection;
          const targetSplit = targetUnsplit.split('^^');
          const targetApplication = targetSplit[0]; // just application
          oneConnection.target = targetApplication;

          // --- name
          if ((oneEndpoint.type === 'internet') || (oneEndpoint.type === 'external')) {
            if (direction.toLowerCase() === 'incoming') {
              oneEndpoint.name = this._parseIpsFromOnePort(onePort, 'sourceIps');
            } else {
              oneEndpoint.name = this._parseIpsFromOnePort(onePort, 'destinationIps');
            }
          } else if (oneEndpoint.type === 'application') {
            oneEndpoint.name = otherEndpointApplicationName;
          }
          oneConnection.endpoint = oneEndpoint;
          connections.push(oneConnection);
        }
      }
    }
    return connections;
  }

  _parseIpsFromOnePort(onePort, targetJsonKey) {
    let ips = [];
    const blockedBytes = onePort.blocked.bytes || 0;
    const allowedBytes = onePort.allowed.bytes || 0;
    if (blockedBytes > 0) {
      ips = onePort.blocked[targetJsonKey] || [];
    }
    if (allowedBytes > 0) {
      if (ips.length > 0) {
        ips = ips.concat(onePort.allowed[targetJsonKey] || []);
      } else {
        ips = onePort.allowed[targetJsonKey] || [];
      }
    }
    return ips;
  }

};
