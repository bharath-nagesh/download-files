const Sequelize = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();

/**
 * @swagger
 * components:
 *   schemas:
 *     Location:
 *       type: object
 *       required:
 *         - action_name
 *         - action_type
 *         - isActive
 *       properties:
 *         action_name:
 *           type: string
 *         action_type:
 *           type: string
 *         isActive:
 *           type: string
 * @param sequelize
 */
const anamolyActions = sequelize.define(
  'anamolyActions',
  {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },

    action_name: { type: Sequelize.STRING, allowNull: false },
    action_type: { type: Sequelize.STRING, allowNull: false },
    isActive: { type: Sequelize.STRING, field: 'is_active' },
    is_active: { type: Sequelize.STRING, field: 'is_active' }
  },
  {
    timestamps: true,
    freezeTableName: true,
    tableName: 'anamoly_actions',
    underscored: true
  }
);

module.exports = anamolyActions;
