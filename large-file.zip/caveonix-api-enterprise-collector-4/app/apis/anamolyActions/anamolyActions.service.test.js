const expect = require('chai').expect;
const proxyquire = require('proxyquire').noCallThru();

describe('AnamolyActionsService', function () {
  beforeEach(() => {

  });

  describe('getById', () => {
    it('getById', async () => {
      const anamolyId = 1;
      const response = { name: 'test amqp 1' };

      class AnamolyActions {
        constructor() {  }

        static findOne() {
          return Promise.resolve(response);
        }
      };
      const AnamolyActionsService = proxyquire('./anamolyActions.service', {
        './anamolyActions.model': AnamolyActions
      });
      const anamolyActionsService = new AnamolyActionsService();
      const data = await anamolyActionsService.getById(anamolyId);
      expect(data).to.be.equal(response);
    });
  });

  describe('getAllanamolyActions', () => {
    it('getAllanamolyActions', async () => {
      const response = [
        { name: 'test amqp 1', orgId: 1 },
        { name: 'test amqp ', orgId: 4 },
        { name: 'cant find me', orgId: 5 }
      ];
      const actionType = 'test_actions'; const limit = 10; const offset = 0;
      class AnamolyActions {
        constructor() { }

        static findAll(queryParams) {
          return Promise.resolve(response);
        }
      };

      const AnamolyActionsService = proxyquire('./anamolyActions.service', {
        './anamolyActions.model': AnamolyActions
      });
      const anamolyActionsService = new AnamolyActionsService();
      const data = await anamolyActionsService.getAllanamolyActions(actionType, limit, offset);
      expect(data.length).to.be.equal(3);

    });
  });

});
