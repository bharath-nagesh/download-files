const AnamolyActionsController = require('./anamolyActions.controller');

/**
 * @swagger
 * tags:
 *  - name: AnamolyActions
 *    description: Anamoly Actions endpoints
 */
module.exports = class AnamolyActionsRoutes {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.anamolyActionsController = new AnamolyActionsController();

      // initializing route
      if (type === 'Service Provider') {
        this.initServiceProvider();
      } else {
        this.initOrganization();
      }
    }
  }

  initOrganization() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/anamolyActions:
     *   get:
     *     tags:
     *       - AnamolyActions
     *     summary: Gets a list of Anamoly Actions
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of anamoly actions
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/`, this.anamolyActionsController.getAllanamolyActions);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/anamolyActions/{anamolyActionsId}:
     *   get:
     *     tags:
     *       - AnamolyActions
     *     summary: Gets a anamolyActions by it's id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: anamolyActionsId
     *         description: The id of the specified anamoly actions.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: anamolyActions
     */
    this.router.get(`${this.path}/:anamolyActionsId`, this.anamolyActionsController.getanamolyActionsById);
  }

  initServiceProvider() {
    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/anamolyActions:
     *   get:
     *     tags:
     *       - AnamolyActions
     *     summary: Gets a list of all anamoly actions
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: AnamolyActions
     */
    this.router.get(`${this.path}/`, this.anamolyActionsController.getAllanamolyActions);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/anamolyActions/{anamolyActionsId}:
     *   get:
     *     tags:
     *       - AnamolyActions
     *     summary: Gets a Anamoly Actions by it's id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: anamolyActionsId
     *         description: The id of the specified Anamoly Actions.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: anamolyActions
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/:anamolyActionsId`, this.anamolyActionsController.getanamolyActionsById);
  }
};
