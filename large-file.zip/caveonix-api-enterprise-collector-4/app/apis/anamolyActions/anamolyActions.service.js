const AnamolyActions = require('./anamolyActions.model');
const sequelize = require('sequelize');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-anamolyActionsService.service'
});

module.exports = class AnamolyActionsService {
  constructor() {
    logger.debug('called AnamolyActionsService constructor');
  }

  getById(Id) {
    return AnamolyActions.findOne({ where: { id: Id , $and: [{ is_active: { $ne: 'disabled' } }, { is_active: { $ne: 'false' } }] } });
  }

  getAllanamolyActions(actionType, limit, offset) {
    return AnamolyActions.findAll({
      where: { action_type: sequelize.where(sequelize.fn('LOWER', sequelize.col('action_type')), sequelize.fn('lower', actionType)) , $and: [{ is_active: { $ne: 'disabled' } }, { is_active: { $ne: 'false' } }] },
      order: [['action_name', 'ASC']],
      limit: limit,
      offset: offset
    });
  }

  getAllanamolyActionsCount(actionType) {
    return AnamolyActions.count({
      where:  { action_type: sequelize.where(sequelize.fn('LOWER', sequelize.col('action_type')), sequelize.fn('lower', actionType)) , $and: [{ is_active: { $ne: 'disabled' } }, { is_active: { $ne: 'false' } }] } });
  }
};
