const expect = require('chai').expect;
const proxyquire = require('proxyquire').noCallThru();
const httpMocks = require('node-mocks-http');

describe('AnamolyActionsController', function () {
  beforeEach(() => {

  });

  describe('getAllanamolyActions', () => {
    it('getAllanamolyActions', async () => {
      const anamolyDetails={ test:1 };
      const anamolyDetailsCount = 1;
      const orgId = 10;
      const limit = 10;
      const offset = 0;
      const page = 1;
      const action_type = 'test_action';
      const anamolyResponse = {
        total_page_count: 1,
        pageLimit: limit,
        total_record_count: 1,
        page_number: page,
        poc: anamolyDetails,
        pages: [{
          number:1,
          url:'null?page='+page
        }]
      };
      const anamolyActionsService = class AnamolyActionsService {
        constructor() {}

        getAllanamolyActions(action_type, limit, offset) { return Promise.resolve(anamolyDetails); }

        getAllanamolyActionsCount(action_type) { return Promise.resolve(anamolyDetailsCount); }
      };
      const AnamolyActionsController = proxyquire('./anamolyActions.controller', {
        './anamolyActions.service': anamolyActionsService
      });

      const anamolyActionsController = new AnamolyActionsController();
      const req = httpMocks.createRequest({ params: { orgId }, query: { page } });
      const res = httpMocks.createResponse({ locals:{ paginate: { limit,offset,page } } });
      const details = await anamolyActionsController.getAllanamolyActions(req, res);
      const anamoly = details._getData();
      expect(JSON.parse(anamoly)).to.deep.equal(anamolyResponse);
    });
  });

  describe('getanamolyActionsById', () => {
    it('getanamolyActionsById', async () => {
      const anamolyDetails={ test:1 };
      const anamolyActionsId=1;
      const anamolyActionsService = class AnamolyActionsService {
        constructor() {}

        getById(anamolyActionsId) { return Promise.resolve(anamolyDetails); }
      };
      const AnamolyActionsController = proxyquire('./anamolyActions.controller', {
        './anamolyActions.service': anamolyActionsService
      });

      const anamolyActionsController = new AnamolyActionsController();
      const req = httpMocks.createRequest({ params: { anamolyActionsId } });
      const res = httpMocks.createResponse();
      const details = await anamolyActionsController.getanamolyActionsById(req, res);
      const anamoly = details._getData();
      expect(JSON.parse(anamoly)).to.deep.equal(anamolyDetails);
    });
  });

});
