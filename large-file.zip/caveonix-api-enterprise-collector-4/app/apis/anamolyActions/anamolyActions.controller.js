const AnamolyActionsService = require('./anamolyActions.service');
const anamolyActionsService = new AnamolyActionsService();
const checkId = require('../../../utils/checkId');
const paginate = require('../../middlewares/paginate.middleware');
const errorHandler = require('../../../utils/errorHandler');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-anamolyActions.controller'
});

module.exports = class AnamolyActionsController {
  constructor() {
    this.anamolyActionsService = new AnamolyActionsService();
  }

  async getAllanamolyActions(req, res) {
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    const actionType = req.query.action_type;
    try{
      const results = await anamolyActionsService.getAllanamolyActions(actionType, limit, offset);
      const itemCount = await anamolyActionsService.getAllanamolyActionsCount(actionType);
      const pageCount = Math.ceil(itemCount / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        poc: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getanamolyActionsById(req, res) {
    const anamolyActionsId = req.params.anamolyActionsId;
    if (checkId(anamolyActionsId)) {
      const error = new Error('Error with anamolyActionsId');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const anamolyActions = await anamolyActionsService.getById(anamolyActionsId);
      return res.json(anamolyActions);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }
};
