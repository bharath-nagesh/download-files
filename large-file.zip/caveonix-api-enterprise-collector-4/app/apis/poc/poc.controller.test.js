const expect = require('chai').expect;
const proxyquire = require('proxyquire').noCallThru();
const httpMocks = require('node-mocks-http');

describe('POCController', function () {
  beforeEach(() => {

  });

  describe('POCController', () => {

    describe('getAllOrgPocs', () => {
      it('getAllOrgPocs', async () => {
        let resData = { data : 1 };
        const orgId = 1;
        const page = 1;
        const limit = 10;
        const offset = 0;
        const total_record_count = 10;
        const PocResponse = {
          total_page_count: 1,
          pageLimit: limit,
          total_record_count: total_record_count,
          page_number: page,
          poc: resData,
          pages: [{
            number: 1,
            url: 'null?page=' + page
          }]
        }


        const POCService = class POCService {
          getAllPoc(orgId, limit, offset, listParam){
            return Promise.resolve(resData);
          };

          getAllPocCount(orgId, listParam){
            return Promise.resolve(total_record_count);
          };
        };
        const POCController = proxyquire('./poc.controller', {
          './poc.service': POCService
        });

        const pOCController = new POCController();
        const req = httpMocks.createRequest({ params: { orgId }, query: { page } });
        const res = httpMocks.createResponse({ locals: { paginate: { limit, offset, page } } });
        const details = await pOCController.getAllOrgPocs(req, res);
        const pocData = details._getData();
        expect(JSON.parse(pocData)).to.deep.equal(PocResponse);
      });
    });


    describe('getOrgPoc', () => {
      it('getOrgPoc', async () => {
        let pocId = 1;
        let response = { data : 1};

        const POCService = class POCService {
          getPoc(pocId){
            return Promise.resolve(response);
          };
        };
        const POCController = proxyquire('./poc.controller', {
          './poc.service': POCService
        });

        const pOCController = new POCController();
        const req = httpMocks.createRequest({ params: { pocId } });
        const res = httpMocks.createResponse();
        const details = await pOCController.getOrgPoc(req, res);
        const pocData = details._getData();
        expect(JSON.parse(pocData)).to.deep.equal(response);
      });
    });

    
    describe('addOrgPoc', () => {
      it('addOrgPoc', async () => {
        const orgId = 1;
        const response = { data : 1 };
        const paraData = response;

        const POCService = class POCService {
          create(pocId){
            return Promise.resolve(response);
          };
        };
        const POCController = proxyquire('./poc.controller', {
          './poc.service': POCService
        });

        const pOCController = new POCController();
        const req = httpMocks.createRequest({ params: { orgId }, body : paraData});
        const res = httpMocks.createResponse();
        const details = await pOCController.addOrgPoc(req, res);
        const pocData = details._getData();
        expect(JSON.parse(pocData)).to.deep.equal(response);
      });
    });

    describe('updateOrgPoc', () => {
      it('updateOrgPoc', async () => {
        const pocId = 1;
        const orgId = 1;
        const response = { data : 1 };
        const paraData = response;

        const POCService = class POCService {
          updatePoc(paraData){
            return Promise.resolve(response);
          };
        };
        const POCController = proxyquire('./poc.controller', {
          './poc.service': POCService
        });

        const pOCController = new POCController();
        const req = httpMocks.createRequest({ params: { pocId, orgId }, body : paraData});
        const res = httpMocks.createResponse();
        const details = await pOCController.updateOrgPoc(req, res);
        const pocData = details._getData();
        expect(JSON.parse(pocData)).to.deep.equal(response);
      });
    });

    describe('deleteMultipleOrgPoc', () => {
      it('deleteMultipleOrgPoc', async () => {
        const response = [{ data : 1 },{ data : 2 },{ data : 3 }];
        const delArr = '1,2,3';
        const POCService = class POCService {
          deleteMultipleOrgPoc(paraData){
            return Promise.resolve(response);
          };
        };
        const POCController = proxyquire('./poc.controller', {
          './poc.service': POCService
        });

        const pOCController = new POCController();
        const req = httpMocks.createRequest({ query:{ id : delArr } });
        const res = httpMocks.createResponse();
        const details = await pOCController.deleteMultipleOrgPoc(req, res);
        const pocData = details._getData();
        expect(JSON.parse(pocData)).to.deep.equal(response);
      });
    });


  });
});