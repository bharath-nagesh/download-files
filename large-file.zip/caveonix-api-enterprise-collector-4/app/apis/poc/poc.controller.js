const checkId = require('../../../utils/checkId');
const errorHandler = require('../../../utils/errorHandler');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-poc.controller'
});
const paginate = require('../../middlewares/paginate.middleware');
const POCService = require('./poc.service');
const pocService = new POCService();
module.exports = class POCController {
  async getAllOrgPocs(req, res) {
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    const orgId = req.params.orgId;
    let list = req.query.list;

    if (!list) {
      list = 'true';
    }
    const listParam = list.toLowerCase();

    try {
      const results = await pocService.getAllPoc(orgId, limit, offset, listParam);
      const itemCount = await pocService.getAllPocCount(orgId, listParam);
      const pageCount = Math.ceil(itemCount / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        poc: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getOrgPoc(req, res) {
    const pocId = req.params.pocId;
    if (checkId(pocId)) {
      logger.error({ pocId }, 'Error with POC Id');
      const error = new Error('Error with POC Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const poc = await pocService.getPoc(pocId);
      return res.json(poc);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async addOrgPoc(req, res) {
    const params = req.body;
    const orgId = req.params.orgId;

    if (Object.keys(params).length === 0) {
      logger.error('Invalid parameters for POC creation');
      const error = new Error('Invalid parameters for POC creation');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const poc = await pocService.create(orgId, params);
      return res.json(poc);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async updateOrgPoc(req, res) {
    const params = req.body;
    const orgId = req.params.orgId;
    const pocId = req.params.pocId;

    if (Object.keys(params).length === 0) {
      logger.error('Invalid parameters for POC creation');
      const error = new Error('Invalid parameters for POC creation');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const poc = await pocService.updatePoc(orgId, pocId, params);
      return res.json(poc);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async deleteMultipleOrgPoc(req, res) {
    const pocId = req.query.id || '';
    try {
      const pocIdArr = pocId.split(',');
      const update = await pocService.deleteMultipleOrgPoc(pocIdArr);
      logger.info('Deleted multiple pocs');
      return res.json(update);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }
};
