const PocController = require('./poc.controller');

/**
 * @swagger
 * tags:
 *  - name: POC
 *    description: POC endpoints
 */
module.exports = class POCRoutes {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.pocController = new PocController();

      // initializing route
      if (type === 'Service Provider') {
        this.initServiceProvider();
      } else {
        this.initOrganization();
      }
    }
  }

  initOrganization() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/poc:
     *   get:
     *     tags:
     *       - POC
     *     summary: Gets a list of points of contacts
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of pocs
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/`, this.pocController.getAllOrgPocs);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/poc/{pocId}:
     *   get:
     *     tags:
     *       - POC
     *     summary: Gets a poc by it's id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: pocId
     *         description: The id of the specified Point of Contact.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: poc
     */
    this.router.get(`${this.path}/:pocId`, this.pocController.getOrgPoc);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/poc/{pocId}:
     *   put:
     *     tags:
     *       - POC
     *     summary: Updates a poc
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: pocId
     *         description: The id of the specified poc.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/POC'
     *     responses:
     *       200:
     *         description: location
     */
    this.router.put(`${this.path}/:pocId`, this.pocController.updateOrgPoc);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/poc/{pocId}:
     *   post:
     *     tags:
     *       - POC
     *     summary: Creates a poc
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/POC'
     *     responses:
     *       200:
     *         description: poc
     */
    this.router.post(`${this.path}/`, this.pocController.addOrgPoc);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/poc/{pocId}:
     *   delete:
     *     tags:
     *       - POC
     *     summary: Deletes a point of contact
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: pocId
     *         description: The id of the specified point of contact.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: poc
     */
    this.router.delete(`${this.path}/`, this.pocController.deleteMultipleOrgPoc);


  }

  initServiceProvider() {
  }
};
