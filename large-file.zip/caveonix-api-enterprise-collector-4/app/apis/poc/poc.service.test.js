const expect = require('chai').expect;
const proxyquire = require('proxyquire').noCallThru();

describe('poc Service', function () {
  beforeEach(() => {

  });

  describe('getPoc', () => {
    it('getPoc', async () => {
      
      const pocId = 1;
      const opts = {};
      const response = {
        data: 1
      };

      class PocStub {
        constructor() { }

        static findByPk() {
          return Promise.resolve(response);
        }
      };

      const POCService = proxyquire('./poc.service', {
        './poc.model': PocStub
      });
      const pOCService = new POCService();
      const data = await pOCService.getPoc(pocId, opts);
      expect(data).to.be.equal(response);
    });
  });
});
