const checkName = require('../../../utils/checkName');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-poc.service'
});
const Poc = require('./poc.model');
const removeSpace = require('../../../utils/checkSpaces');
const sequelize = require('../../../config/db.conf').getConnection();

module.exports = class POCService {
  constructor(services) {
    this.services = services;
    logger.debug('called constructor');
  }

  getPoc(pocId, opts) {
    return Poc.findByPk(pocId);
  }

  async updatePoc(orgId, pocId, update) {
    update.organization_id = orgId;
    const firstName = update.firstName;
    const lastName = update.lastName;
    const email = update.email;
    if (checkName(firstName) || checkName(lastName)) {
      const err = new Error('Invalid value for Username/LastName');
      err.status = 400;
      throw err;
    }
    const newFirstName = removeSpace.removeAllSpaces(firstName);
    const newLastName = removeSpace.removeAllSpaces(lastName);
    const exists = await this.checkNameForUpdate(newFirstName, newLastName, pocId, email,orgId);
    if (exists === 'update') {
      update.firstName = newFirstName;
      update.lastName = newLastName;
      if (update.isActive === '') {
        update.isActive = 'enabled';
      }
      await Poc.update(update, { where: { id: pocId } });
      return Poc.findByPk(pocId);
    } else {
      const err = new Error(exists);
      err.status = 400;
      throw err;
    }
  }

  async create(orgId, params) {
    params.organization_id = orgId;
    const firstName = params.firstName;
    const lastName = params.lastName;
    const email = params.email;
    if (checkName(firstName) || checkName(lastName)) {
      const err = new Error('Invalid value for Username/LastName');
      err.status = 400;
      throw err;
    }
    const newFirstName = removeSpace.removeAllSpaces(firstName);
    const newLastName = removeSpace.removeAllSpaces(lastName);
    const exists = await this.checkUsernameExists(newFirstName, newLastName, email, orgId);
    if (exists === 'update') {
      const update = {};
      update.firstName = newFirstName;
      update.lastName = newLastName;
      update.middleName = params.middleName;
      update.cellNumber = params.cellNumber;
      if (params.isActive !== '') {
        update.isActive = params.isActive;
      } else {
        update.isActive = 'enabled';
      }
      await Poc.update(update, { where: { email: email } });
      return Poc.findOne({ where: { email: email } });
    }
    if (exists === 'create') {
      params.firstName = newFirstName;
      params.lastName = newLastName;
      if (params.isActive === '') {
        params.isActive = 'enabled';
      }
      return Poc.create(params);
    } else {
      const err = new Error(exists);
      err.status = 400;
      throw err;
    }
  }

  async deleteById(pocId) {
    await Poc.update( { isActive: false }, { where: { id: pocId } });
    return Poc.findByPk(pocId);
  }

  async deleteMultipleOrgPoc(pocIdArr) {
    await Poc.update( { isActive: false }, { where: { id: { $in: pocIdArr } } });
    return Poc.findAll({ where: { id: { $in: pocIdArr } } });
  }

  getAllPoc(orgId, limit, offset, listParam = null) {
    if (listParam === 'false') {
      return Poc.findAll({
        where: {
          $and: [
            { is_active: { $ne: 'disabled' } },
            { is_active: { $ne: 'false' } },
            { organization_id: orgId }]
        },
        order: [['id', 'ASC']],
        limit: limit,
        offset: offset
      });
    }
    return Poc.findAll({
      where: { $and: [{ is_active: { $ne: 'false' } }, { organization_id: orgId }] },
      order: [['id', 'ASC']],
      limit: limit,
      offset: offset
    });
  }

  getAllPocCount(orgId, listParam = null) {
    if (listParam === 'false') {
      return Poc.count({
        where: {
          $and: [
            { is_active: { $ne: 'disabled' } },
            { is_active: { $ne: 'false' } },
            { organization_id: orgId }]
        }
      });
    }
    return Poc.count({
      where: { $and: [{ is_active: { $ne: 'false' } }, { organization_id: orgId }] }
    });
  }

  async checkUsernameExists(firstName, lastName, email, orgId) {
    let result = '';
    const user = await Poc.findOne({
      where: {
        email: sequelize.where(sequelize.fn('LOWER', sequelize.col('email')),
          sequelize.fn('lower', email)),
        organization_id: { $eq: orgId }
      }
    });
    if (user) {
      if (user.isActive === 'false' || user.isActive === false) {
        result = await Poc.findOne({
          where: {
            $and: [
              {
                firstName: sequelize.where(
                  sequelize.fn('LOWER', sequelize.col('first_name')),
                  sequelize.fn('lower', firstName)),
                lastName: sequelize.where(
                  sequelize.fn('LOWER', sequelize.col('last_name')),
                  sequelize.fn('lower', lastName)),
                isActive: { $ne: 'false' },
                organization_id: { $eq: orgId }
              }]
          }
        });
        if (result) {
          return 'Duplicate POC Username.';
        } else {
          return 'update';
        }
      } else {
        return 'Duplicate POC Email.';
      }
    } else {
      result = await Poc.findOne({
        where: {
          $and: [
            {
              firstName: sequelize.where(
                sequelize.fn('LOWER', sequelize.col('first_name')),
                sequelize.fn('lower', firstName)),
              lastName: sequelize.where(
                sequelize.fn('LOWER', sequelize.col('last_name')),
                sequelize.fn('lower', lastName)),
              isActive: { $ne: 'false' },
              organization_id: { $eq: orgId }
            }]
        }
      });
      if (result) {
        return 'Duplicate POC Username.';
      } else {
        return 'create';
      }
    }
  }

  async checkNameForUpdate(firstName, lastName, pocId, email, orgId) {
    let result = '';
    const user = await Poc.findOne({
      where: {
        email: sequelize.where(sequelize.fn('LOWER', sequelize.col('email')),
          sequelize.fn('lower', email)),
        organization_id: { $eq: orgId },
        id: { $ne: pocId }
      }
    });
    if (user) {
      if (user.isActive === 'false' || user.isActive === false) {
        result = await Poc.findOne({
          where: {
            $and: [
              {
                firstName: sequelize.where(
                  sequelize.fn('LOWER', sequelize.col('first_name')),
                  sequelize.fn('lower', firstName)),
                lastName: sequelize.where(
                  sequelize.fn('LOWER', sequelize.col('last_name')),
                  sequelize.fn('lower', lastName)),
                isActive: { $ne: 'false' },
                organization_id: { $eq: orgId },
                id: { $ne: pocId }
              }]
          }
        });
        if (result) {
          return 'Duplicate POC Username.';
        } else {
          return 'update';
        }

      } else {
        return 'Duplicate POC Email.';
      }
    } else {
      result = await Poc.findOne({
        where: {
          $and: [
            {
              firstName: sequelize.where(
                sequelize.fn('LOWER', sequelize.col('first_name')),
                sequelize.fn('lower', firstName)),
              lastName: sequelize.where(
                sequelize.fn('LOWER', sequelize.col('last_name')),
                sequelize.fn('lower', lastName)),
              isActive: { $ne: 'false' },
              organization_id: { $eq: orgId },
              id: { $ne: pocId }
            }]
        }
      });
      if (result) {
        return 'Duplicate POC Username.';
      } else {
        return 'update';
      }
    }
  }
};
