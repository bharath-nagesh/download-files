const Sequelize = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();

/**
 * @swagger
 * components:
 *   schemas:
 *     POC:
 *       type: object
 *       required:
 *         - firstName
 *         - email
 *         - isActive
 *       properties:
 *         firstName:
 *           type: string
 *         middleName:
 *           type: string
 *         lastName:
 *           type: string
 *         cellNumber:
 *           type: string
 *         email:
 *           type: string
 *         isActive:
 *           type: boolean
 * @param sequelize
 */

class Poc extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
      firstName: {
        type: Sequelize.STRING,
        field: 'first_name'
      },
      middleName: {
        type: Sequelize.STRING,
        field: 'middle_name'
      },
      lastName: {
        type: Sequelize.STRING,
        field: 'last_name'
      },
      cellNumber: {
        type: Sequelize.STRING,
        field: 'cell_number'
      },
      email: {
        type: Sequelize.STRING,
        field: 'email'
      },
      isActive: {
        type: Sequelize.BOOLEAN,
        field: 'is_active',
        defaultValue: true,
        allowNull: false
      },
      is_active: {
        type: Sequelize.BOOLEAN,
        field: 'is_active'

      }
    },
    { sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'poc_members',
      underscored: true,
      updatedAt: 'updated_at',
      createdAt: 'created_at'
    });
  }

  static associate(models) {
    Poc.belongsTo(models.Organization,{ foreignKey: 'organization_id' });
    Poc.belongsToMany(models.ApplicationTag, {
      through: models.ApplicationPocMember,
      as: 'businessOwner',
      otherKey: 'application_id',
      foreignKey: 'business_owner_poc_id'
    });
    Poc.belongsToMany(models.ApplicationTag, {
      through: models.ApplicationPocMember,
      as: 'infraPrimary',
      otherKey: 'application_id',
      foreignKey: 'infra_primary_poc_id'
    });
    Poc.belongsToMany(models.ApplicationTag, {
      through: models.ApplicationPocMember,
      as: 'infraSecondary',
      otherKey: 'application_id',
      foreignKey: 'infra_secondary_poc_id'
    });
    Poc.belongsToMany(models.ApplicationTag, {
      through: models.ApplicationPocMember,
      as: 'osPrimary',
      otherKey: 'application_id',
      foreignKey: 'os_primary_poc_id'
    });
    Poc.belongsToMany(models.ApplicationTag, {
      through: models.ApplicationPocMember,
      as: 'osSecondary',
      otherKey: 'application_id',
      foreignKey: 'os_secondary_poc_id'
    });
    Poc.belongsToMany(models.ApplicationTag, {
      through: models.ApplicationPocMember,
      as: 'dbPrimary',
      otherKey: 'application_id',
      foreignKey: 'db_primary_poc_id'
    });
    Poc.belongsToMany(models.ApplicationTag, {
      through: models.ApplicationPocMember,
      as: 'dbSecondary',
      otherKey: 'application_id',
      foreignKey: 'db_secondary_poc_id'
    });
    Poc.belongsToMany(models.ApplicationTag, {
      through: models.ApplicationPocMember,
      as: 'softwarePrimary',
      otherKey: 'application_id',
      foreignKey: 'software_primary_poc_id'
    });
    Poc.belongsToMany(models.ApplicationTag, {
      through: models.ApplicationPocMember,
      as: 'softwareSecondary',
      otherKey: 'application_id',
      foreignKey: 'software_secondary_poc_id'
    });
  }
}
module.exports = Poc;
