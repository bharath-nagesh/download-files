const CommonController = require('./common.controller');
const commonController = new CommonController();
const express = require('express');
const router = express.Router({ mergeParams: true });

/* Common Public Endpoints */
router.get('/saasProducts', commonController.getAllSaasProductOfferings);

module.exports = router;
