const MarketplaceCustomers = require('../auth/marketplaceCustomers.model');
const DirectRegistrations = require('../auth/directRegistrations.model');
const KeyGenerator = require('../../../utils/generateKeys');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-auth.service'
});

module.exports = class AuthService {
  constructor() {
    this.keyGenerator = new KeyGenerator();
  }

  async commonVerify(token, source) {
    try {
      token = Buffer.from(token, 'base64').toString('utf-8');
      token = await this.keyGenerator.decryptKeys(token);
    } catch (err) {
      logger.error({ err, stack: err.stack }, 'Verification Error');
      const error = new Error('Verification Error');
      error.status = 400;
      throw error;
    }
    if (source === 'direct') {
      const data = await DirectRegistrations.findOne({ where: { token, verified: true } });
      if (!data) {
        logger.error('Unauthorized Error');
        const error = new Error('Unauthorized Error');
        error.status = 400;
        throw error;
      }
    } else if (source === 'marketplace') {
      const marketplaceCustomersData = await MarketplaceCustomers.findOne({ where: { uuid: token } });
      if (!marketplaceCustomersData) {
        logger.error('Unauthorized Error');
        const error = new Error('Unauthorized Error');
        error.status = 400;
        throw error;
      }
    }
    return true;
  }
};
