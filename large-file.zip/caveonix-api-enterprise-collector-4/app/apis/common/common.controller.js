const errorHandler = require('../../../utils/errorHandler');
const CommonService = require('./common.service');
const commonService = new CommonService();
const paginate = require('../../middlewares/paginate.middleware');
const Validator = require('../../../utils/validator');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-saasProductOfferings.controller'
});
const SaasProductOfferingsService = require('../saasProductOfferings/saasProductOfferings.service');
const saasProductOfferingsService = new SaasProductOfferingsService();

module.exports = class ProductOfferingsController {
  async getAllSaasProductOfferings(req, res) {
    const limit = 5000;
    const offset = 0;
    const pageNumber = 1;
    req.query.page = req.query.page || 0;
    const params = req.query;
    try {
      await Validator.validateParams({
        token: 'required|string',
        source: 'required|in:direct,marketplace'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    try {
      await commonService.commonVerify(params.token, params.source);
      const results = await saasProductOfferingsService.getAllSaasProductOfferings(limit, offset);
      const itemCount = await saasProductOfferingsService.getAllSaasProductOfferingsCount();
      const pageCount = Math.ceil(itemCount / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        saasProductOffering: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      return errorHandler(req, res, error, { error : error.message });
    }
  }

};
