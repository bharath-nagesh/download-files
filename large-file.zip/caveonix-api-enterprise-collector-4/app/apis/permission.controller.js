const services = require('../services');
const errorHandler = require('../../../utils/errorHandler');
const logger = require('./../../utils/logger').logger.child({
  sub_name: 'IdentityService-permission.controller'
});
const checkId = require('./../../utils/checkId');
const permissionService = services.permissionService;

const controller = {
  async checkPermission(req, res) {
    const userId = req.user.id;
    const orgId = req.body.orgId;
    const verb = req.body.verb;
    const mod = req.body.module;
    if (checkId(userId) || !verb || !mod) {
      logger.error({ orgId }, 'Error with Org Id');
      const error = new Error('Bad Request Data');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const allowed = await permissionService.checkPermission(userId, orgId, mod, verb);
      return res.json(allowed);
    } catch (error) {
      logger.error({ error, stack: error.stack });
      return errorHandler(req, res, error);
    }
  }
};
module.exports = controller;
