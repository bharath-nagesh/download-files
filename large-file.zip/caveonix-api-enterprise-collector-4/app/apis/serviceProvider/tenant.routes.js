const ServiceProviderController = require('./serviceProvider.controller');
const multer = require('multer');
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });
const pngFilter = function (req, file, cb) {
  if (file.encoding == 'image/png' || file.mimetype == 'image/png') return cb(null, true);
  return cb(new Error('improper file format'), false);
};
const pngUpload = multer({ storage, fileFilter: pngFilter, limits: { fileSize: 50000 } }); // 50 mb
module.exports = class TenantRouter {
  constructor(path, router) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;

    }
    this.serviceProviderController = new ServiceProviderController();
    this.initServiceProvider();
  }

  initServiceProvider() {
// todo look into the use of OrganizationController vs UserController
    this.router.get(`${this.path}/vCenter`, this.serviceProviderController.getvCenterMappings);
    this.router.get(`${this.path}/`, this.serviceProviderController.getAllTenants); // get all top level organizations
//TODO remove this hacky endpoint
    this.router.get(`${this.path}/csp`, this.serviceProviderController.getAllTenantsAndCSP); // get all top level organizations and csp org chain
    this.router.get(`${this.path}/:tenantId`, this.serviceProviderController.getTenantById); // get tenant by id

    this.router.put(`${this.path}/:tenantId`, pngUpload.single('orgLogo'), this.serviceProviderController.updateTenant); // get tenant by id
    this.router.post(`${this.path}/`, pngUpload.single('orgLogo'), this.serviceProviderController.createOrganization);
    this.router.delete(`${this.path}/`, this.serviceProviderController.deleteMultipleOrg); //done delete org

  }
};

/*
create tenant
list tenant
delete tenants
create tenant user (org admin only)

 */
