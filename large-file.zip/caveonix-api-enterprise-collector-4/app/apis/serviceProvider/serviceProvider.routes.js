const AMQPRouter = require('../amqp/amqp.routes'); // CSP only
const AssetRepoEndpointRouter = require('../assetRepoEndpoint/assetRepoEndpoint.routes'); // BOTH ORG AND CSP
const express = require('express');
const HostingProviderRouter = require('../hostingProvider/hostingProvider.routes'); // CSP only
const ReferenceService = require('../../services/reference.service');

const JobRouter = require('../job/job.routes');
const router = express.Router();
const ServiceProviderController = require('./serviceProvider.controller');
const serviceProviderController = new ServiceProviderController();
const VcdVcenterDetailsRouter = require('../vCDvCenterDetails/vcdVcenterDetails.routes');
const OrgOnboardingStatusRouter = require('../orgOnboardingStatus/orgOnboardingStatus.routes');
const TenantRouter = require('./tenant.routes');
const definitions = require('../../definitions/serviceProvider.js');
const JobController = require('../job/job.controller');
const jobController = new JobController();
const AuthController = require('../auth/auth.controller');
const authController = new AuthController();
const multer = require('multer');
const uploadController = require('../upload.controller');
const storage = multer.memoryStorage();
const idCheckMiddlewareFactory = require('../../middlewares/idCheck.middleware');
let upload = multer({ storage: storage });
const pngFilter = function (req, file, cb) {
  if (file.encoding == 'image/png' || file.mimetype == 'image/png') return cb(null, true);
  return cb(new Error('improper file format'), false);
};
multer({ storage, fileFilter: pngFilter });
router.param('serviceProviderId', idCheckMiddlewareFactory('serviceProvider'));
router.get('/', serviceProviderController.getAllServiceProvider);
router.put('/:serviceProviderId', serviceProviderController.updateServiceProvider);
router.get('/:serviceProviderId', serviceProviderController.getServiceProvider);
router.get('/:serviceProviderId/showLicense', jobController.showLicense);
router.get('/:serviceProviderId/currentUsage', jobController.currentUsage);
router.post('/:serverProviderId/user/reset-password/url', authController.passwordResetUrl);
// AMQP
new AMQPRouter('/:serviceProviderId/amqpDetails', router, 'Service Provider');
// Asset Repo Endpoint
new AssetRepoEndpointRouter('/:serviceProviderId/assetRepoEndpoint', router, 'Service Provider');
// Hosting Provider
new HostingProviderRouter('/:serviceProviderId/hostingProvider', router, 'Service Provider');

// Tenant
new TenantRouter('/:serviceProviderId/tenant', router);

// vcdVcenter
new VcdVcenterDetailsRouter('/:serviceProviderId/vcdVcenterDetails', router, 'Service Provider');
new OrgOnboardingStatusRouter('/:serviceProviderId/onboarding', router, 'ServiceProvider');
new JobRouter('/:orgId/job', router, 'Service Provider');

router.get('/:serviceProviderId/billing', serviceProviderController.getBillingInfo);
router.get('/:serviceProviderId/organization/:orgId/billing', serviceProviderController.getBillingInfoForOrg);

router.put('/:serviceProviderId/organization/:orgId/saveFile', upload.fields([{
  name: 'file',
  maxCount: 1
}]), uploadController.customNVDFileProcessor);
router.get('/:serviceProviderId/license', serviceProviderController.getLicense); //done

const referenceService = new ReferenceService();
referenceService.addEndpoints('/api/serviceProvider/', router, definitions);

module.exports = router;
