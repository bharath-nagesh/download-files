const paginate = require('../../middlewares/paginate.middleware');
const checkId = require('../../../utils/checkId');
const checkName = require('../../../utils/checkName');
const BillingService = require('../../services/billing.service');
const billingService = new BillingService();
const OrgService = require('../organization/org.service');
const orgService = new OrgService();
const JobService = require('../job/job.service');
const AssetRepoEndpointService = require('../assetRepoEndpoint/assetRepoEndpoint.service');
const assetRepoEndpointService = new AssetRepoEndpointService();
const jobService = new JobService();
const config = require('../../../configure').get();
const moment = require('moment');
const errorHandler = require('../../../utils/errorHandler');
const Validator = require('../../../utils/validator');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-serviceProvider.controller'
});

module.exports = class ServiceProviderController {
  async getvCenterMappings(req, res) {
    const data = await assetRepoEndpointService.getvCenters();
    return res.json(data);
  }

  async createOrganization(req, res) {
    let orgId = '';
    const params = req.body;
    try {
      if (!params.isActive) {
        params.isActive = 'enabled';
      }
      params.isActive = params.isActive.toLowerCase();
      const validatorFields = {
        aliasName: 'required|string',
        bai_value: 'nullable',
        email: 'required|email',
        certificate_id: 'required|string',
        type: 'nullable',
        parentOrgId: 'required|integer',
        country: 'nullable',
        zip: 'string',
        state: 'nullable',
        city: 'nullable',
        addressLine1: 'nullable',
        addressLine2: 'nullable',
        phone: 'required|string',
        billingAccountId: 'nullable',
        isActive: 'required|in:enabled,disabled,true'
      };
      if (config.saas) {
        validatorFields.licenseType = 'required';
        validatorFields.licenseCount = 'required';
        validatorFields.startDate = 'required';
        validatorFields.endDate = 'required';

      }
      await Validator.validateParams(validatorFields, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    params.orgLogo = req.file ? req.file.buffer : null;
    const parentOrgId = params.parentOrgId;
    const token = req.authInfo;
    params.name = null;
    const userOrgId = req.params.orgId || req.params.serviceProviderId;
    const userId = req.user.id;
    const loginUserOrganizationId = req.user.Organizations[0].id;
    if (orgService.checkOrgId(parentOrgId)) {
      logger.error({ parentOrgId }, 'Error with Parent Org Id');
      const error = new Error('Error with Parent Org Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const org = await orgService.createOrganization(params, userOrgId, parentOrgId, userId, token);
      orgId = org.id;
      if (config.forensics_enabled === false || config.ml_enabled === true) {
        const name = 'watcherRequest' + orgId;
        const type = 'watcherRequest';
        const userToken = token;
        params.type_name = 'watcherRequest';
        params.cron_expression = '0 0/20 * * * ?';
        params.scan_type = 'watcherRequest';
        params.user_id = 1;
        params.asset_repo_id = 2;
        const scheduleJob = await jobService.createJob(orgId, name, params.user_id, params);
        await jobService.createModifyScheduleJob(scheduleJob, userId, userToken, loginUserOrganizationId, 'watcherSchedule', name, type);
        const result = await orgService.getOrganizationById(orgId);
        return res.json(result);
      }
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  /**
   *
   *this method used for get license details
   */
  async getLicense(req, res) {
    const orgId = req.params.orgId;
    try {
      const result = await orgService
        .getLicense(orgId);

      return res.json(result);

    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async changeOrgStatus(req, res) {
    const params = req.body;
    const orgId = req.params.orgId;
    try {
      await Validator.validateParams({
        isActive: 'required|in:enabled,disabled,true'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    try {
      const update = await orgService.changeOrgStatus(orgId, params);
      logger.info({ update, orgId }, 'Update');
      return res.json(update);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getTenantById(req, res) {
    const tenantId = req.params.tenantId;
    try {
      const tenant = await orgService.getTenantById(tenantId);
      return res.json(tenant);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getAllTenants(req, res) {
    const limit = res.locals.paginate.limit;
    const pageNumber = res.locals.paginate.page;
    const orgId = req.params.orgId || req.params.serviceProviderId;
    const includeCurrentOrg = req.query.includeCurrent || false;
    const dropdown = req.query.dropdown || false;

    try {
      const resData = await orgService.getTenants(orgId, dropdown);
      const results = resData[0];
      const itemCount = resData[1];
      const pageCount = Math.ceil(itemCount.length / limit);
      if ((includeCurrentOrg === true || includeCurrentOrg === 'true') && !results.find(o => parseInt(orgId) === o.id )) {
        const currentOrg = await orgService.getOrganizationById(orgId, false);
        results.push(currentOrg);
      }
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount.length,
        page_number: pageNumber,
        tenants: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  //TODO REMOVE THIS IS HACK
  async getAllTenantsAndCSP(req, res) {
    const orgId = req.params.serviceProviderId;
    const dropdown = req.query.dropdown || false;
    const type = req.query.type || 'all';
    try {
      const tenants = await orgService.getTenants(orgId, dropdown, type);
      const orgChain = await orgService.getOrgChain(orgId, true, dropdown, type);
      // orgChain = orgChain.map(oc => {
      //   oc = oc.toJSON();
      //   oc.id = oc.organization_id;
      //   return oc;
      // });
      const result = tenants[0].concat(orgChain);
      return res.json(result);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getServiceProvider(req, res) {
    const serviceProviderId = req.params.serviceProviderId;
    if (checkId(serviceProviderId)) {
      logger.error({ serviceProviderId }, 'Error with ServiceProvider Id');
      const error = new Error('Error with ServiceProvider Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const serviceProvider = await orgService.getOrganizationById(serviceProviderId);
      logger.silly('serviceProvider');
      if (!serviceProvider) {
        logger.error({ serviceProviderId }, 'ServiceProvider Not Found');
        return res.sendStatus(404);
      }
      return res.json(serviceProvider);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getAllServiceProvider(req, res) {
    try {
      const orgId = req.user.Organizations[0].id;
      const serviceProvider = await orgService.getAllServiceProviders(orgId);
      return res.json(serviceProvider);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  /**
   *
   *this method used for update the organization details of given orgId
   */
  async updateTenant(req, res) {
    const params = req.body;
    try {
      params.isActive = params.isActive ? params.isActive.toString().toLowerCase() : null;
      await Validator.validateParams({
        aliasName: 'required|string',
        bai_value: 'nullable',
        email: 'required|email',
        certificate_id: 'required|string',
        type: 'nullable',
        parentOrgId: 'required|integer',
        country: 'nullable',
        zip: 'string',
        state: 'nullable',
        city: 'nullable',
        addressLine1: 'nullable',
        addressLine2: 'nullable',
        phone: 'required|string',
        billingAccountId: 'nullable',
        isActive: 'required|in:enabled,disabled'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const orgId = req.params.tenantId;
    if(req.file){
      params.orgLogo = req.file.buffer;
    }
    try {
      const org = await orgService.updateOrg(orgId, params);
      return res.json(org);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async updateServiceProvider(req, res) {
    const params = req.body;
    const serviceProviderId = req.params.serviceProviderId;
    const orgId = req.params.serviceProviderId;
    let scheduleJob;
    const userToken = req.authInfo;
    const loginUserId = req.user.id;
    const loginUserOrganizationId = req.user.Organizations[0].id;
    let jobName;
    let type;
    if (checkId(serviceProviderId)) {
      logger.error({ serviceProviderId }, 'Error with Parent ServiceProvider Id');
      const error = new Error('Error with Parent ServiceProvider Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      params.isActive = params.isActive ? params.isActive.toString().toLowerCase() : 'enabled';
      await Validator.validateParams({
        isActive: 'required|in:enabled,disabled,true'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const isActive = params.isActive;
    params.type = 'Provider';
    try {
      const Job = require('../job/job.model');
      const ScheduleTask = require('../../models/scheduleTask.model');
      const watcherJob = await Job.findOne({ where: { name: 'watcherRequest' } });
      const tasklist = await ScheduleTask.findAll({
        where: {
          org_id: serviceProviderId,
          is_active: 'enabled',
          job_id: watcherJob.id
        }
      });
      if (config.forensics_enabled === false || config.ml_enabled === true) {
        if (tasklist.length < 1) {
          const name = 'watcherRequest' + orgId;
          const type = 'watcherRequest';
          params.type_name = 'watcherRequest';
          params.cron_expression = '0 0/20 * * * ?';
          params.scan_type = 'watcherRequest';
          params.user_id = 1;
          params.asset_repo_id = 2;
          const key = 'id';
          delete params[key];
          const job = await jobService.createJob(orgId, name, params.user_id, params);
          scheduleJob = job;
          await jobService.createModifyScheduleJob(scheduleJob, loginUserId, userToken, loginUserOrganizationId, 'watcherSchedule', name, type);
        }
      }
      const result = await ScheduleTask.findAll({ where: { org_id: orgId, is_active: 'enabled' } });
      if (isActive === 'disabled') {
        const Job = require('../job/job.model');
        await ScheduleTask.update({ isActive: 'disabled' }, { where: { org_id: orgId, is_active: 'enabled' } });
        for (let i = 0; i < result.length; i++) {
          scheduleJob = result[i];
          const jobId = scheduleJob.job_id;
          jobName = scheduleJob.name;
          const job = await Job.findOne({ where: { id: jobId } });
          type = job.name;
          await jobService.createModifyScheduleJob(scheduleJob, loginUserId, userToken, loginUserOrganizationId, 'unSchedule', jobName, type);
        }
      }
      const serviceProvider = await orgService.updateOrg(serviceProviderId, params);
      return res.json(serviceProvider);

    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  /**
   *
   * this method used for delete multiple organizations
   */
  async deleteMultipleOrg(req, res) {
    const orgId = req.query.id || '';
    if (orgId === undefined || orgId === '') {
      logger.error('Invalid Input');
      const error = new Error('Invalid Input');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    const orgIdArr = orgId.split(',');
    try {
      for (let ctr = 0; ctr < orgIdArr.length; ctr++) {
        await orgService.deleteOrg(orgIdArr[ctr]);
      }

      const result = await orgService.getMultipleOrg(orgIdArr);
      return res.json(result);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getBillingInfo(req, res) {
    try {
      const orgId = req.params.serviceProviderId || req.params.orgId;
      const d = await billingService.getBillingForMonth(orgId);
      return res.json(d);
    } catch (e) {
      return errorHandler(req, res, e);
    }
  }

  async getBillingInfoForOrg(req, res) {
    const orgId = req.params.orgId;
    const getHourly = req.query.hourly || false;
    const today = moment().toDate();
    const startDate = req.query.startDate ? moment(req.query.startDate).toDate() : moment().subtract(30, 'days').toDate();
    const endDate = req.query.endDate ? moment(req.query.endDate).toDate() : today;
    try {
      const d = await billingService.getBillingForOrg(orgId, startDate, endDate, getHourly);
      return res.json(d);
    } catch (e) {
      return errorHandler(req, res, e);
    }
  }

};
