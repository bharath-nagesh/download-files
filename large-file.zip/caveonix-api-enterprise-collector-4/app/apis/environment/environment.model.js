const Sequelize = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();
/**
 * @swagger
 * components:
 *   schemas:
 *     Environment:
 *       type: object
 *       required:
 *         - score
 *         - name
 *         - isActive
 *       properties:
 *         score:
 *           type: number
 *         name:
 *           type: string
 *         isActive:
 *           type: string
 * @param sequelize
 */

class Environment extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
      name: {
        type: Sequelize.STRING
      },
      score: {
        type: Sequelize.INTEGER
      },
      isActive: {
        type: Sequelize.STRING,
        field: 'is_active',
        allowNull: false,
        defaultValue: true
      },
      is_active: {
        type: Sequelize.STRING,
        field: 'is_active'

      }
    },
    { sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'environments',
      underscored: true
    });
  }
}
module.exports = Environment;
