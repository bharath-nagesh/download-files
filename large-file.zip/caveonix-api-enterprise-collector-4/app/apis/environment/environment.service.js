const Environment = require('./environment.model');
const sequelize = require('../../../config/db.conf').getConnection();
const removeSpace = require('../../../utils/checkSpaces');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-environment.service'
});

module.exports = class EnvironmentService {
  constructor() {
    logger.debug('called EnvironmentService constructor');
  }

  getEnvironment(environmentId, opts) {
    return Environment.findByPk(environmentId);
  }

  getEnvironmentByName(environmentName) {
    return Environment.findOne({
      where: {
        name: sequelize.where(sequelize.fn('LOWER', sequelize.col('name')), sequelize.fn('lower', environmentName))
      }
    });
  }

  getAllEnvironment(limit, offset) {
    return Environment.findAll({
      where: { $or: [{ isActive: { $ne: 'false' } }] },
      order: [['id', 'ASC']],
      limit: limit,
      offset: offset
    });
  }

  getEnvironmentCount() {
    return Environment.count(
      {
        where: {
          $or: [{ isActive: { $ne: 'false' } }]
        }
      });
  }

  async create(params) {
    const name = params.name;
    const newName = removeSpace.checkMultiSpace(name);
    const exists = await this.checkName(newName);
    if (exists) {
      const error = new Error('Duplicate Environment name.');
      error.status = 400;
      throw error;
    }
    params.name = newName;
    return Environment.create(params);
  }

  async deleteMultipleEnvironment(environmentIdIdArr) {
    await Environment.update({ isActive: false }, { where: { id: { $in: environmentIdIdArr } } });
    return Environment.findAll({ where: { id: { $in: environmentIdIdArr } } });
  }

  async updateEnvironment(environmentId, update) {
    const name = update.name;
    const newName = removeSpace.checkMultiSpace(name);
    const exists = await this.checkNameForUpdate(newName, environmentId);
    if (exists) {
      const err = new Error('Duplicate Environment name.');
      err.status = 400;
      throw err;
    }
    update.name = newName;
    const env = await Environment.findByPk(environmentId);
    return env.update(update);
  }

  checkName(name) {
    return Environment.findOne({
      where: {
        name: sequelize.where(sequelize.fn('LOWER', sequelize.col('name')), sequelize.fn('lower', name)),
        $or: [{ isActive: { $ne: 'false' } }]
      }
    });
  }

  checkNameForUpdate(name, environmentId) {
    return Environment.findOne({
      where: {
        name: sequelize.where(sequelize.fn('LOWER', sequelize.col('name')), sequelize.fn('lower', name)),
        $or: [{ isActive: { $ne: 'false' } }],
        id: { $ne: environmentId }
      }
    });
  }
};
