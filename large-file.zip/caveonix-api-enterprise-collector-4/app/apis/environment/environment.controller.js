const paginate = require('../../middlewares/paginate.middleware');
const checkId = require('../../../utils/checkId');
const checkName = require('../../../utils/checkName');
const EnvironmentService = require('./environment.service');
const errorHandler = require('../../../utils/errorHandler');
const Validator = require('../../../utils/validator');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-environment.controller'
});
const _ = require('lodash');

module.exports = class EnvironmentController {
  async getAllEnvironment(req, res) {
    const environmentService = new EnvironmentService();
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    try{
      const results = await environmentService.getAllEnvironment(limit, offset);
      const itemCount = await environmentService.getEnvironmentCount();
      const pageCount = Math.ceil(itemCount / limit);
      res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        environments: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getEnvironmentById(req, res) {
    const environmentService = new EnvironmentService();
    const environmentId = req.params.environmentId;
    if (checkId(environmentId)) {
      logger.error({ environmentId }, 'Error with Environment Id');
      const error = new Error(`Invalid Environment Id: ${environmentId}`);
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try{
      const environment = await environmentService.getEnvironment(environmentId);
      return res.json(environment);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getEnvironmentByName(req, res) {
    const environmentService = new EnvironmentService();
    const environmentName = req.params.environmentName;
    if (checkName(environmentName)) {
      logger.error({ environmentName }, 'Error with Environment Name');
      const error = new Error(`Invalid Environment Name: ${environmentName}`);
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try{
      const environment = await environmentService.getEnvironmentByName(environmentName);
      return res.json(environment);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async createEnvironment(req, res) {
    const environmentService = new EnvironmentService();
    const params = req.body;
    try {
      await Validator.validateParams({
        name: 'required|string',
        score: 'required|between:1,10'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    try{
      const environment = await environmentService.create(params);
      return res.json(environment);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async deleteEnvironment(req, res) {
    const environmentId = req.params.environmentId;
    if (checkId(environmentId)) {
      logger.error({ environmentId }, 'Error with Environment Id');
      const error = new Error(`Invalid Environment Id: ${environmentId}`);
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try{
      const environmentService = new EnvironmentService();
      const update = await environmentService.deleteById(environmentId)
      logger.info({ update, environmentId }, 'Update');
      return res.json(update);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async deleteMultipleEnvironment(req, res) {
    const environmentId = req.query.id || '';
    try{
      const environmentIds = environmentId.split(',');
      const environmentService = new EnvironmentService();
      const update = await environmentService.deleteMultipleEnvironment(environmentIds);
      logger.info(`Deleted multiple environments (${environmentId})`);
      return res.json(update);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async updateEnvironment(req, res) {
    const environmentService = new EnvironmentService();
    const update = req.body;
    try {
      if(update.isActive){ update.isActive=update.isActive.toLowerCase(); }
      await Validator.validateParams({
        name: 'required|string',
        score: 'required|between:1,10',
        isActive: 'required|in:enabled,disabled'
      }, update);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const environmentId = req.params.environmentId;
    if (checkId(environmentId)) {
      logger.error({ environmentId }, 'Error with Environment Id');
      const error = new Error(`Invalid Environment Id: ${environmentId}`);
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try{
      const environment = await environmentService.updateEnvironment(environmentId, update);
      logger.info({ environment });
      res.json(environment);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }
};
