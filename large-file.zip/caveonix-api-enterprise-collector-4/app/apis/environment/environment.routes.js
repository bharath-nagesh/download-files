const EnvironmentController = require('./environment.controller');

/**
 * @swagger
 * tags:
 *  - name: Environment
 *    description: Environment endpoints
 */
module.exports = class EnvironmentRouter {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.environmentController = new EnvironmentController();

      // initializing route
      this.initOrganization();
    }
  }

  /**
   * Route initialization and setup
   */
  initOrganization() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/environment:
     *   get:
     *     tags:
     *       - Environment
     *     summary: Gets a list of all environments
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: get all environments
     *       401:
     *         description: unauthorized
     */
    this.router.get(`${this.path}/`, this.environmentController.getAllEnvironment);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/environment/{environmentId}:
     *   get:
     *     tags:
     *       - Environment
     *     summary: Gets an environment by its id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: environmentId
     *         description: The id of the specified environment.
     *         in: path
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: Environment
     *       401:
     *         description: unauthorized
     */
    this.router.get(`${this.path}/:environmentId`, this.environmentController.getEnvironmentById);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/environment/environmentName/{environmentName}:
     *   get:
     *     tags:
     *       - Environment
     *     summary: Gets an environment by its name
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: environmentName
     *         description: The name of the requested environment.
     *         in: path
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: environment
     *       401:
     *         description: unauthorized
     */
    this.router.get(`${this.path}/environmentName/:environmentName`, this.environmentController.getEnvironmentByName);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/environment/:
     *   post:
     *     tags:
     *       - Environment
     *     summary: Creates an environment
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/Environment'
     *     responses:
     *       200:
     *         description: environment was created successfully
     *       401:
     *         description: unauthorized
     */
    this.router.post(`${this.path}/`, this.environmentController.createEnvironment);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/environment:
     *   put:
     *     tags:
     *       - Environment
     *     summary: Updates the specified environment
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/Environment'
     *     responses:
     *       200:
     *         description: login
     *       401:
     *         description: unauthorized
     */
    this.router.put(`${this.path}/:environmentId`, this.environmentController.updateEnvironment);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/environment/{environmentId}:
     *   delete:
     *     tags:
     *       - Environment
     *     summary: Deletes an environment by its id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: environmentId
     *         description: The id of the specified environment.
     *         in: path
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: deleted environment
     *       401:
     *         description: unauthorized
     */
    this.router.delete(`${this.path}/`, this.environmentController.deleteMultipleEnvironment);
  }
};
