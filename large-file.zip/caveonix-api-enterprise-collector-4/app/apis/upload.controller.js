const errorHandler = require('./../../utils/errorHandler');
const sequelize = require('../../config/db.conf').getConnection();
const JobService = require('./job/job.service');
const jobService = new JobService();
const logger = require('./../../utils/logger').logger.child({
  sub_name: 'IdentityService-upload.controller'
});
const controller = {
  async acceptFile(req, res) {
    try{
      const applicationId = req.params.applicationId;
      const certificateId = req.params.certificateId;
      const controlId = req.params.controlId;
      const implementationStatus = '';
      const notes = '';
      const result2 = await sequelize.query('select attachment,attachment_type, attachment_name from application_tag_controls_members where application_id = :application_id and certificate_id = :certificate_id and control_id = :control_id',
        {
          type: sequelize.QueryTypes.SELECT, replacements: { application_id: applicationId, certificate_id: certificateId, control_id: controlId }
        });
      const responce = result2[0].attachment_name;
      if (responce) {
        await sequelize.query('insert into application_tag_controls_members (id, application_id, certificate_id, control_id, implementation_status, notes, attachment_name, attachment_type, attachment, created_at, updated_at) VALUES (default, :application_id, :certificate_id, :control_id, :implementation_status, :notes,:fileName ,:type,:file , NOW(),NOW() )',
          {
            replacements: { type: req.file.mimetype, file: req.file.buffer, fileName: req.file.originalname, application_id: applicationId, certificate_id: certificateId, control_id: controlId, implementation_status: implementationStatus, notes: notes }
          });
        const result1 = await sequelize.query('select attachment,attachment_type, attachment_name from application_tag_controls_members where application_id = :application_id and certificate_id = :certificate_id and control_id = :control_id',
          {
            type: sequelize.QueryTypes.SELECT, replacements: { application_id: applicationId, certificate_id: certificateId, control_id: controlId }
          });
        return res.json({
          data: result1
        });
      } else {
        await sequelize.query('update application_tag_controls_members set attachment = :file, attachment_type = :type, attachment_name = :fileName where application_id = :application_id and certificate_id = :certificate_id and control_id = :control_id',
          {
            replacements: { type: req.file.mimetype, file: req.file.buffer, fileName: req.file.originalname, application_id: applicationId, certificate_id: certificateId, control_id: controlId }
          });
        const result1 = await sequelize.query('select attachment,attachment_type, attachment_name from application_tag_controls_members where application_id = :application_id and certificate_id = :certificate_id and control_id = :control_id',
          {
            type: sequelize.QueryTypes.SELECT, replacements: { application_id: applicationId, certificate_id: certificateId, control_id: controlId }
          });
        return res.json({
          file: result1[0].attachment,
          filename: result1[0].attachment_name,
          fileType: result1[0].attachment_type
        });
      }
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  },
  async returnFile(req, res) {
    const applicationId = req.params.applicationId;
    const certificateId = req.params.certificateId;
    const controlId = req.params.controlId;
    const result1 = await sequelize.query('select attachment, attachment_type, attachment_name from application_tag_controls_members where application_id = :application_id and certificate_id = :certificate_id and control_id = :control_id',
      { type: sequelize.QueryTypes.SELECT, replacements: { application_id: applicationId, certificate_id: certificateId, control_id: controlId } });
    return res.json({
      file: result1[0].attachment,
      filename: result1[0].attachment_name,
      fileType: result1[0].attachment_type
    });
  },

  async customNVDFileProcessor(req, res) {
    var file = req.files.file[0].buffer;
    const onlyFile = req.files.file[0];
    const orgId = req.user.Organizations[0].id;
    const userToken = req.authInfo;
    const userId = req.user.id;
    const checkStatus = true;
    var data = (file.toString('utf8'));

    if(onlyFile.mimetype !== 'application/json' || onlyFile.originalname.slice(-5).toLowerCase() !== '.json'){
      const err = new Error('Invalid NVD File. Allowed NVD file extension - .json');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    const status = await jobService.CustomNvdFileSave(data, orgId, userToken, userId, checkStatus);
    try {
      logger.info(status, 'statusCode');
      return res.json({status:'Custom NVD parsing started.'});
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }
};

module.exports = controller;
