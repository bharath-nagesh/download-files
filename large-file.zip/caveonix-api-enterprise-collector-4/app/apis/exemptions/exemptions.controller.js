const ExemptionsService = require('./exemptions.service');
const exemptionsService = new ExemptionsService();
const errorHandler = require('../../../utils/errorHandler');
const checkId = require('../../../utils/checkId');
const Validator = require('../../../utils/validator');
const paginate = require('../../middlewares/paginate.middleware');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-exemptions.controller'
});

module.exports = class ExemptionsController {

  async getExemptions(req, res) {
    const orgId = req.params.orgId;
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    const product = req.query.product || null;
    const cloudType = req.query.cloudType || null;
    const entityArn = req.query.entityArn || null;
    const controlId = req.query.controlId || null;
    const type = req.query.type || null;
    try {
      const results = await exemptionsService.getExemptions(orgId, limit, offset, product, cloudType, entityArn, controlId, type);
      const itemCount = await exemptionsService.getExemptionsCount(orgId, product, cloudType, entityArn, controlId, type);
      const pageCount = Math.ceil(itemCount / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        exemptionsService: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getExemptionById(req, res) {
    const exemptionId = req.params.exemptionId;
    if (checkId(exemptionId)) {
      logger.error({ exemptionId }, 'Error with exemption id');
      const error = new Error(`Invalid value for exemptionId: ${exemptionId}`);
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const orgId = req.params.orgId;
      const exemptionDetails = await exemptionsService.getExemptionById(orgId, exemptionId);
      return res.json(exemptionDetails);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async createExemption(req, res) {
    const params = req.body;
    try {
      await Validator.validateParams({
        entityArn: 'nullable',
        controlId: 'required|string',
        organizationId: 'required|integer',
        justification: 'nullable',
        type: 'required|in:False Positive,Exemption,Compensatory',
        exemptionValidTill: 'requiredIf:type,Exemption',
        product: 'required|string',
        cloudType: 'required|string',
        isActive: 'required|in:enabled,disabled,true'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const orgId = req.params.orgId;
    params.createdBy = req.user.id;
    params.updatedBy = req.user.id;
    try {
      const exemptionDetails = await exemptionsService.createExemption(orgId, params);
      return res.json(exemptionDetails);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async udpateExemption(req, res) {
    const params = req.body;
    const exemptionId = req.params.exemptionId;
    try {
      await Validator.validateParams({
        entityArn: 'nullable',
        controlId: 'required|string',
        organizationId: 'required|integer',
        justification: 'nullable',
        type: 'required|in:False Positive,Exemption,Compensatory',
        exemptionValidTill: 'requiredIf:type,Exemption',
        product: 'required|string',
        cloudType: 'required|string',
        isActive: 'required|in:enabled,disabled,true'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const orgId = req.params.orgId;
    params.updatedBy = req.user.id;
    try {
      const exemptionDetails = await exemptionsService.udpateExemption(orgId, exemptionId, params);
      return res.json(exemptionDetails);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async deleteExemption(req, res) {
    try {
      const exemptionId = req.query.id;
      const exemptionIdArr = exemptionId.split(',');
      const orgId = req.params.orgId;
      const userId = req.user.id;
      const exemptionDetails = await exemptionsService.deleteExemption(orgId, userId, exemptionIdArr);
      return res.json(exemptionDetails);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

};
