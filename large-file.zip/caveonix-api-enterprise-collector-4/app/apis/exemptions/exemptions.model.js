const Sequelize = require('sequelize');

class Exemptions extends Sequelize.Model {
  /**
   * @swagger
   * components:
   *   schemas:
   *     Exemptions:
   *       type: object
   *       required:
   *         - controlId
   *         - organizationId
   *         - type
   *         - createdBy
   *         - updatedBy
   *         - isActive
   *       properties:
   *         id:
   *           type: integer
   *         entityArn:
   *           type: string
   *         controlId:
   *           type: string
   *         organizationId:
   *           type: number
   *         exemptionValidTill:
   *           type: string
   *         justification:
   *           type: string
   *         type:
   *           type: string
   *         createdBy:
   *           type: string
   *         updatedBy:
   *           type: string
   *         isActive:
   *           type: string
   * @param sequelize
   */
  static init(sequelize) {
    return super.init({
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      entityArn: { type: Sequelize.STRING, field: 'entity_arn', allowNull: true },
      controlId: { type: Sequelize.STRING, field: 'control_id', allowNull: false },
      organizationId: { type: Sequelize.INTEGER, field: 'organization_id', allowNull: false },
      exemptionValidTill: { type: Sequelize.STRING, field: 'exemption_valid_till', allowNull: true },
      justification: { type: Sequelize.STRING, field: 'justification', allowNull: true },
      type: { type: Sequelize.STRING, field: 'type', allowNull: false },
      product: { type: Sequelize.STRING, field: 'product', allowNull: false },
      cloudType: { type: Sequelize.STRING, field: 'cloud_type', allowNull: false },
      createdBy: { type: Sequelize.INTEGER, field: 'created_by', allowNull: false },
      updatedBy: { type: Sequelize.INTEGER, field: 'updated_by', allowNull: false },
      isActive: { type: Sequelize.STRING, field: 'is_active', allowNull: false }
    },
    {
      sequelize,
      timestamps: true,
      freezeTableName: true,
      tableName: 'exemptions',
      underscored: true
    });
  }

  static associate(models) {
    Exemptions.belongsTo(models.Organization, { foreignKey: 'organization_id' });
    Exemptions.belongsTo(models.User, { as: 'createdByUser', foreignKey: 'created_by' });
    Exemptions.belongsTo(models.User, { as: 'updatedByUser', foreignKey: 'updated_by' });
  };
}

module.exports = Exemptions;
