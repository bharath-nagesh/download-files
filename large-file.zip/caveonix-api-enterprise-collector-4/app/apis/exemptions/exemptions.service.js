const Exemptions = require('./exemptions.model');
const Organization = require('../organization/organization.model');
const User = require('../user/user.model');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-exemptions.service'
});

module.exports = class ExemptionsService {

  async getExemptions(orgId, limit, offset, product = null, cloudType = null, entityArn = null, controlId = null, type = null) {
    const orgChain = await Organization.getOrgChain(orgId);
    const where = { isActive: { $ne: 'false' }, organization_id: orgChain };
    if(product) where.product = product;
    if(cloudType) where.cloudType = cloudType;
    if(entityArn) where.entityArn = entityArn;
    if(controlId) where.controlId = controlId;
    if(type) where.type = type;
    const data = await Exemptions.findAll({
      where,
      limit,
      offset,
      order: [['id', 'ASC']],
      include: [
        { model: Organization, attributes: ['id', 'name', 'aliasName', 'fullName'] },
        { model: User, as: 'createdByUser', attributes: ['id', 'username','first_name','last_name'] },
        { model: User, as: 'updatedByUser', attributes: ['id', 'username','first_name','last_name'] }
      ]
    });
    return data;
  }

  async getExemptionsCount(orgId, product = null, cloudType = null, entityArn = null, controlId = null, type = null) {
    const orgChain = await Organization.getOrgChain(orgId);
    const where = { isActive: { $ne: 'false' }, organization_id: orgChain };
    if(product) where.product = product;
    if(cloudType) where.cloudType = cloudType;
    if(entityArn) where.entityArn = entityArn;
    if(controlId) where.controlId = controlId;
    if(type) where.type = type;
    const data = await Exemptions.count({ where });
    return data;
  }

  async getExemptionById(orgId, exemptionId) {
    const orgChain = await Organization.getOrgChain(orgId);
    const data = await Exemptions.findOne({
      where: { isActive: { $ne: 'false' }, id: exemptionId, organization_id: orgChain },
      order: [['id', 'ASC']],
      include: [
        { model: Organization, attributes: ['id', 'name', 'aliasName', 'fullName'] },
        { model: User, as: 'createdByUser', attributes: ['id', 'username','first_name','last_name'] },
        { model: User, as: 'updatedByUser', attributes: ['id', 'username','first_name','last_name'] }
      ]
    });
    return data;
  }

  async createExemption(orgId, params) {
    const orgChain = await Organization.getOrgChain(orgId);
    if (!orgChain.includes(params.organizationId)) {
      const err = new Error('Unauthorized');
      err.status = 401;
      throw err;
    }
    params.type = params.type.toUpperCase();
    const data = await Exemptions.create(params);
    return data;
  }

  async udpateExemption(orgId, exemptionId, params) {
    const orgChain = await Organization.getOrgChain(orgId);
    if (!orgChain.includes(params.organizationId)) {
      const err = new Error('Unauthorized');
      err.status = 401;
      throw err;
    }
    params.type = params.type.toUpperCase();
    await Exemptions.update(params, { where: { id: exemptionId } });
    const data = await Exemptions.findOne({ where: { id: exemptionId } });
    return data;
  }

  async deleteExemption(orgId, userId, exemptionIdArr) {
    const orgChain = await Organization.getOrgChain(orgId);
    const data = await Exemptions.update({ isActive: 'false', updatedBy: userId }, {
      where: {
        id: exemptionIdArr,
        organization_id: orgChain
      }
    });
    return data;
  }

};
