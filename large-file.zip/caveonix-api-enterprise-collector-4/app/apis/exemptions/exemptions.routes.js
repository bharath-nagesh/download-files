const ExemptionsController = require('./exemptions.controller');

/**
 * @swagger
 * tags:
 *  - name: Exemptions
 *    description: Exemptions Endpoints
 */
module.exports = class ExemptionsRoutes {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.exemptionsController = new ExemptionsController();

      // initializing route
      if (type === 'Service Provider') {
        this.initServiceProvider();
      } else {
        this.initOrganization();
      }
    }
  }

  initOrganization() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/exemptions:
     *   get:
     *     tags:
     *       - Exemptions
     *     summary: Gets a list of exemptions of assets
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of Exemptions
     *       401:
     *          description: Unauthorized
     *       400:
     *          description: Bad Request
     *       500:
     *          description: API Request Error
     */
    this.router.get(`${this.path}/`, this.exemptionsController.getExemptions);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/exemptions/{exemptionId}:
     *   get:
     *     tags:
     *       - Exemptions
     *     summary: Gets the specified exemptions details
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: exemptionId
     *         description: The Exemption's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: Exemption Details
     *       401:
     *          description: Unauthorized
     *       400:
     *          description: Bad Request
     *       500:
     *          description: API Request Error
     */
    this.router.get(`${this.path}/:exemptionId`, this.exemptionsController.getExemptionById);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/exemptions:
     *   get:
     *     tags:
     *       - Exemptions
     *     summary: Create new exemption
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/Exemptions'
     *     responses:
     *       200:
     *          description: Exemption Details
     *       401:
     *          description: Unauthorized
     *       400:
     *          description: Bad Request
     *       500:
     *          description: API Request Error
     */
    this.router.post(`${this.path}/`, this.exemptionsController.createExemption);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/exemptions/{exemptionId}:
     *   get:
     *     tags:
     *       - Exemptions
     *     summary: Create new exemption
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: exemptionId
     *         description: The Exemption's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/Exemptions'
     *     responses:
     *       200:
     *          description: Exemption Details
     *       401:
     *          description: Unauthorized
     *       400:
     *          description: Bad Request
     *       500:
     *          description: API Request Error
     */
    this.router.put(`${this.path}/:exemptionId`, this.exemptionsController.udpateExemption);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/exemptions:
     *   delete:
     *     tags:
     *       - Exemptions
     *     summary: Delete exemptions
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: id
     *         description: Exemption ids to be deleted in comma sepeared values.
     *         in: query
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *          description: Deleted Exemption Details
     *       401:
     *          description: Unauthorized
     *       400:
     *          description: Bad Request
     *       500:
     *          description: API Request Error
     */
    this.router.delete(`${this.path}/`, this.exemptionsController.deleteExemption);

  }

  initServiceProvider() {}
};
