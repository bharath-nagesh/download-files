const AuthorizationInfoController = require('./authorizationInfo.controller');

/**
 * @swagger
 * tags:
 *  - name: AuthorizationInfo
 *    description: Authorization Info endpoints
 */
module.exports = class AuthorizationInfoRoutes {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.authorizationInfoController = new AuthorizationInfoController();

      // initializing route
      this.initOrganization();
    }
  }

  initOrganization() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/authorizationInfo:
     *   get:
     *     tags:
     *       - AuthorizationInfo
     *     summary: Gets a list of Authorization Infos
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of authorization Infos
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/`, this.authorizationInfoController.getAllAuthorizationInfo);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/authorizationInfo/{authorizationInfoId}:
     *   get:
     *     tags:
     *       - AuthorizationInfo
     *     summary: Gets Authorization Info by it's id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: authorizationInfoId
     *         description: The id of the specified Authorization Info.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: authorization info
     */
    this.router.get(`${this.path}/:authorizationInfoId`, this.authorizationInfoController.getAuthorizationInfoById);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/authorizationInfo:
     *   post:
     *     tags:
     *       - AuthorizationInfo
     *     summary: Creates a Authorization Info
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: authorizationInfoId
     *         description: The id of the specified Authorization Info.
     *         in: path
     *         required: true
     *         type: string
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/AuthorizationInfo'
     *     responses:
     *       200:
     *         description: authorizationInfo
     */
    this.router.post(`${this.path}/`, this.authorizationInfoController.createAuthorizationInfo);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/authorizationInfo/{authorizationInfoId}:
     *   put:
     *     tags:
     *       - AuthorizationInfo
     *     summary: Updates the specified Authorization Info
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: authorizationInfoId
     *         description: The id of the specified Authorization Info.
     *         in: path
     *         required: true
     *         type: string
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/AuthorizationInfo'
     *     responses:
     *       200:
     *         description: authorizationInfo
     */
    this.router.put(`${this.path}/:authorizationInfoId`, this.authorizationInfoController.updateAuthorizationInfo);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/authorizationInfo/{authorizationInfoId}:
     *   delete:
     *     tags:
     *       - AuthorizationInfo
     *     summary: Deletes the Authorization Info
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: authorizationInfoId
     *         description: The id of the specified Authorization Info.
     *         in: path
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: authorization info
     */
    this.router.delete(`${this.path}/`, this.authorizationInfoController.deleteMultipleAuthorizationInfo);
  }
};
