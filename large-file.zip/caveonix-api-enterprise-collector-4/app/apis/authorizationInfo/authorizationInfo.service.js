const uuidv4 = require('uuid/v4');

const AuthorizationInfo = require('./authorizationInfo.model');
const logger = require('../../../utils/logger').logger;
const Organization = require('../organization/organization.model');

const loggerLabel = 'AuthorizationInfoService';

module.exports = class AuthorizationInfoService {
  constructor() {
    logger.debug('called AuthorizationInfoService constructor');
  }

  async getAuthorizationInfo(orgId, authorizationInfoId, opts) {
    const authInfo = await AuthorizationInfo.findOne({
      where: {
        id: authorizationInfoId,
        isActive: { $ne: 'false' }
      },
      include: [
        { model: Organization, required: true }
      ]
    });
    const parentOrgId = await Organization.getParentOrg(authInfo.Organization.id);

    if (authInfo.Organization.id !== parentOrgId) {
      authInfo.setDataValue('subOrgId', authInfo.organization_id);
    }
    authInfo.setDataValue('parentOrgId', parentOrgId);
    return authInfo;
  }

  async getAllAuthorizationInfo(orgId, limit, offset) {
    logger.debug('Retrieving all authorization info', { loggerLabel });
    logger.silly(`for orgId ${orgId}`, { loggerLabel });

    return AuthorizationInfo.findAll({
      attributes: ['key', 'id', 'isActive', 'createdAt', 'token'],
      where: { isActive: { $ne: 'false' } },
      order: [['id', 'ASC']],
      limit: limit,
      offset: offset,
      include: [{ model: Organization, required: true, attributes: ['aliasName', 'fullName', 'name', 'createdAt'] }]
    });
  }

  async getAuthorizationInfoCount(orgId) {
    return AuthorizationInfo.count({
      where: { isActive: { $ne: 'false' } },
      order: [['id', 'ASC']]
    });

  }

  async create(orgId, loggedInUserId, userToken, params) {
    params.key = uuidv4();
    const authorizationInfoData = await AuthorizationInfo.create(params);
    return authorizationInfoData;
  }

  async updateAuthorizationInfo(orgId, loggedInUserId, userToken, authorizationInfoId, params) {
    const authorizationInfo = await AuthorizationInfo.findOne({
      where: {
        id: authorizationInfoId,
        isActive: { $ne: 'false' }
      }
    });
    params.key = authorizationInfo.key;
    const authorizationInfoData = await authorizationInfo.update(params);
    return authorizationInfoData;
  }

  async deleteById(orgId, loggedInUserId, userToken, authorizationInfoId) {
    await AuthorizationInfo.update(
      { isActive: false },
      {
        where: {
          id: authorizationInfoId
        }
      }
    );
    return AuthorizationInfo.findOne({ where: { id: authorizationInfoId } });
  }

  async deleteMultipleAuthorizationInfo(orgId, loggedInUserId, userToken, authorizationInfoIdArr) {
    await AuthorizationInfo.update(
      { isActive: false },
      { where: { id: authorizationInfoIdArr } }
    );
    return AuthorizationInfo.findAll({
      where: { id: authorizationInfoIdArr }
    });
  }
};
