const Sequelize = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();

/**
 * @swagger
 * components:
 *   schemas:
 *     AuthorizationInfo:
 *       type: object
 *       required:
 *         - key
 *         - token
 *         - isActive
 *       properties:
 *         key:
 *           type: string
 *         token:
 *           type: string
 *         isActive:
 *           type: string
 * @param sequelize
 */
class AuthorizationInfo extends Sequelize.Model {
  static init(sequelize) {
    return super.init(
      {
        key: { type: Sequelize.STRING, allowNull: false },
        token: { type: Sequelize.STRING, allowNull: true, defaultValue: ' ' },
        isActive: { type: Sequelize.BOOLEAN, field: 'is_active', allowNull: false, defaultValue: true },
        ecHostName: { type: Sequelize.STRING, allowNull: true, field: 'ec_host_name' },
        is_active: { type: Sequelize.BOOLEAN, field: 'is_active' }
      },
      { timestamps: true, freezeTableName: true, tableName: 'authorization_info', sequelize, underscored: true }
    );
  }

  static associate(models) {
    AuthorizationInfo.belongsTo(models.Organization, { required: true, foreignKey: 'organization_id' });
    AuthorizationInfo.belongsTo(models.Location, { required: true, foreignKey: 'location_id' });
    AuthorizationInfo.belongsTo(models.HostingProvider, { foreignKey: 'hosting_providers_id', required: true });
  };
}

module.exports = AuthorizationInfo;
