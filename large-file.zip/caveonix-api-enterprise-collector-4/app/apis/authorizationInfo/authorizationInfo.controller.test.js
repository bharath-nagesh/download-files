const expect = require('chai').expect;
const proxyquire = require('proxyquire').noCallThru();
const httpMocks = require('node-mocks-http');

describe('AuthorizationInfoController', function () {
  beforeEach(() => {

  });

  describe('getAllAuthorizationInfo', () => {

    it('getAllAuthorizationInfo', async () => {
      let orgId = 10;
      let limit = 10;
      let offset = 0;
      let page = 1;

      const authorizationInfoResponse = {
        total_page_count: 1,
        pageLimit: limit,
        total_record_count: 10,
        page_number: page,
        authorizationInfos: 10,
        pages: [{
          number: 1,
          url: "null?page=" + page
        }]
      }

      const authorizationInfoCount = 10;
      const authorizationInfoService = class AuthorizationInfoService {
        constructor() { }
        getAllAuthorizationInfo() { return Promise.resolve(orgId, limit, offset); }
        getAuthorizationInfoCount() { return Promise.resolve(authorizationInfoCount); }
      };
      const AuthorizationInfoController = proxyquire('./authorizationInfo.controller', {
        './authorizationInfo.service': authorizationInfoService
      });

      const authorizationInfoController = new AuthorizationInfoController();
      const req = httpMocks.createRequest({ params: { orgId }, query: { page } });
      const res = httpMocks.createResponse({ locals: { paginate: { limit, offset, page } } });
      const details = await authorizationInfoController.getAllAuthorizationInfo(req, res);
      const authorizationInfo = details._getData();
      expect(JSON.parse(authorizationInfo)).to.deep.equal(authorizationInfoResponse);
    });

  });

  describe('getAuthorizationInfoById', () => {

    it('getAuthorizationInfoById', async () => {
      const authorizationInfoResponse = { authInfo: 'data' };
      const authorizationInfoId = 10;
      const orgId = 1;
      const authorizationInfoService = class AuthorizationInfoService {
        constructor() { }
        getAuthorizationInfo(orgId, authorizationInfoId) { return Promise.resolve(authorizationInfoResponse); }
      };
      const AuthorizationInfoController = proxyquire('./authorizationInfo.controller', {
        './authorizationInfo.service': authorizationInfoService
      });

      const authorizationInfoController = new AuthorizationInfoController();
      const req = httpMocks.createRequest({ params: { orgId, authorizationInfoId } });
      const res = httpMocks.createResponse();
      const details = await authorizationInfoController.getAuthorizationInfoById(req, res);
      const authorizationInfo = details._getData();
      expect(JSON.parse(authorizationInfo)).to.deep.equal(authorizationInfoResponse);
    });

  });

  describe('createAuthorizationInfo', () => {

    it('createAuthorizationInfo', async () => {
      const authorizationInfoData = {
        organization_id: 1,
        location_id: 1,
        hosting_providers_id: 1,
        isActive: 'enabled'
      }
      const authorizationInfoService = class AuthorizationInfoService {
        constructor() { }
        create(orgId, authorizationInfoId) { return Promise.resolve(authorizationInfoData); }
      };
      const AuthorizationInfoController = proxyquire('./authorizationInfo.controller', {
        './authorizationInfo.service': authorizationInfoService
      });

      const authorizationInfoController = new AuthorizationInfoController();
      const req = httpMocks.createRequest({ body: authorizationInfoData });
      const res = httpMocks.createResponse();
      const details = await authorizationInfoController.createAuthorizationInfo(req, res);

      const authorizationInfo = details._getData();
      expect(JSON.parse(authorizationInfo)).to.deep.equal(authorizationInfoData);
    });

  });

  describe('updateAuthorizationInfo', () => {

    it('updateAuthorizationInfo', async () => {
      const authorizationInfoData = {
        organization_id: 1,
        location_id: 1,
        hosting_providers_id: 1,
        isActive: 'enabled'
      }
      const authorizationInfoId = 1;
      const orgId = 1;
      const authorizationInfoService = class AuthorizationInfoService {
        constructor() { }
        updateAuthorizationInfo(orgId, authorizationInfoId, params) { return Promise.resolve(authorizationInfoData); }
      };
      const AuthorizationInfoController = proxyquire('./authorizationInfo.controller', {
        './authorizationInfo.service': authorizationInfoService
      });

      const authorizationInfoController = new AuthorizationInfoController();
      const req = httpMocks.createRequest({ body: authorizationInfoData, params: { orgId, authorizationInfoId } });
      const res = httpMocks.createResponse();
      const details = await authorizationInfoController.updateAuthorizationInfo(req, res);

      const authorizationInfo = details._getData();
      expect(JSON.parse(authorizationInfo)).to.deep.equal(authorizationInfoData);
    });

  });

  describe('deleteMultipleAuthorizationInfo', () => {

    it('deleteMultipleAuthorizationInfo', async () => {
      const authorizationInfoData = [{
        organization_id: 1,
        location_id: 1,
        hosting_providers_id: 1,
        isActive: 'false',
        id: 1
      }, {
        organization_id: 1,
        location_id: 1,
        hosting_providers_id: 1,
        isActive: 'false',
        id: 2
      }];
      const authorizationInfoIdArr = '1,2';
      const orgId = 1;
      const authorizationInfoService = class AuthorizationInfoService {
        constructor() { }
        deleteMultipleAuthorizationInfo(authorizationInfoIdArr) { return Promise.resolve(authorizationInfoData); }
      };
      const AuthorizationInfoController = proxyquire('./authorizationInfo.controller', {
        './authorizationInfo.service': authorizationInfoService
      });

      const authorizationInfoController = new AuthorizationInfoController();
      const req = httpMocks.createRequest({ query: { id: authorizationInfoIdArr } });
      const res = httpMocks.createResponse();
      const details = await authorizationInfoController.deleteMultipleAuthorizationInfo(req, res);

      const authorizationInfo = details._getData();
      expect(JSON.parse(authorizationInfo)).to.deep.equal(authorizationInfoData);
    });

  });
});