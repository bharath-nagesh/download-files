const AuthorizationInfoService = require('./authorizationInfo.service');
const authorizationInfoService = new AuthorizationInfoService();
const checkId = require('../../../utils/checkId');
const errorHandler = require('../../../utils/errorHandler');
const Validator = require('../../../utils/validator');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-authorizationInfo.controller'
});
const paginate = require('../../middlewares/paginate.middleware');
module.exports = class AuthorizationInfoController {

  async getAllAuthorizationInfo(req, res) {
    const orgId = req.params.orgId;
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    try {
      const results = await authorizationInfoService.getAllAuthorizationInfo(orgId, limit, offset);
      const itemCount = await authorizationInfoService.getAuthorizationInfoCount(orgId);
      const pageCount = Math.ceil(itemCount / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        authorizationInfos: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getAuthorizationInfoById(req, res) {
    const orgId = req.params.orgId;
    const authorizationInfoId = req.params.authorizationInfoId;
    if (checkId(authorizationInfoId)) {
      logger.error({ authorizationInfoId }, 'Error with AuthorizationInfo Id');
      const error = new Error('Error with AuthorizationInfo Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const authorizationInfo = await authorizationInfoService.getAuthorizationInfo(orgId, authorizationInfoId);
      return res.json(authorizationInfo);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async createAuthorizationInfo(req, res) {
    const params = req.body;
    try {
      params.isActive = params.isActive ? params.isActive.toString().toLowerCase() : null;
      await Validator.validateParams({
        organization_id: 'required|integer',
        location_id: 'required|integer',
        hosting_providers_id: 'required|integer',
        isActive: 'required|in:enabled,disabled,true'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    try {
      const orgId = params.organization_id;
      const userToken = req.authInfo;
      const loggedInUserId = req.user.id;
      const authorizationInfo = await authorizationInfoService.create(orgId, loggedInUserId, userToken, params);
      return res.json(authorizationInfo);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async updateAuthorizationInfo(req, res) {
    const params = req.body;
    try {
      params.isActive = params.isActive ? params.isActive.toString().toLowerCase() : null;
      await Validator.validateParams({
        organization_id: 'required|integer',
        location_id: 'required|integer',
        hosting_providers_id: 'required|integer',
        isActive: 'required|in:enabled,disabled'
      }, params);

      await Validator.validateParams({
        authorizationInfoId: 'required|integer'
      }, req.params, { authorizationInfoId: 'Error with AuthorizationInfo Id' });

    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const authorizationInfoId = req.params.authorizationInfoId;
    try {
      const orgId = params.organization_id;
      const userToken = req.authInfo;
      const loggedInUserId = req.user.id;
      const authorizationInfo = await authorizationInfoService
        .updateAuthorizationInfo(orgId, loggedInUserId, userToken, authorizationInfoId, params);
      return res.json(authorizationInfo);

    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async deleteMultipleAuthorizationInfo(req, res) {
    const authorizationInfoId = req.query.id || '';
    const authorizationInfoIdArr = authorizationInfoId.split(',');
    try {
      const orgId = params.organization_id;
      const userToken = req.authInfo;
      const loggedInUserId = req.user.id;
      const update = await authorizationInfoService.deleteMultipleAuthorizationInfo(orgId, loggedInUserId, userToken, authorizationInfoIdArr);
      return res.json(update);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }
};
