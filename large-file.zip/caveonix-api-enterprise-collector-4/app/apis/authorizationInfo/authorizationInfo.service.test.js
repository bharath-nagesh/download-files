const expect = require('chai').expect;
const proxyquire = require('proxyquire').noCallThru();

describe('AuthorizationInfoService', function () {
  beforeEach(() => {

  });

  describe('getAuthorizationInfo', () => {
    it('getAuthorizationInfo', async () => {
      const authData = {
        id:1,
        Organization:{
          id:0
        }
      };
      const response = {
        id:1,
        Organization:{
          id:0
        },
        setDataValue(idType, id){
          authData[idType] = id;
          return authData;
        }
      };
      const orgArr = [1, 2, 3];
      const parentOrgId = 1;
      const orgId = 1;
      const authorizationInfoId = 1;
      const opts = null;
      class OrgDetailsStub {
        constructor() { }

        static getOrgChain() {
          return Promise.resolve(orgArr);
        }

        static getParentOrg() {
          return Promise.resolve(parentOrgId);
        }
      };

      class AuthorizationInfoDetailsStub {
        constructor() { }

        static findOne() {
          return Promise.resolve(response);
        }
      };

      class HostingProviderStub {
        constructor() {
        }

        static findOne() {
          return Promise.resolve(response);
        }
      };

      class LocationStub {
        constructor() {
        }

        static findOne() {
          return Promise.resolve(response);
        }
      };

      class OrgServiceStub {
        constructor() {
        }
      };


      const AuthorizationInfoService = proxyquire('./authorizationInfo.service', {
        '../organization/organization.model': OrgDetailsStub,
        './authorizationInfo.model':AuthorizationInfoDetailsStub,
        '../organization/org.service':OrgServiceStub,
        '../location/location.model':LocationStub,
        '../hostingProvider/hostingProvider.model':HostingProviderStub
      });
      const authorizationInfoService = new AuthorizationInfoService();
      const data = await authorizationInfoService.getAuthorizationInfo(orgId, authorizationInfoId, opts);
      expect(data).to.be.equal(response);
    });
  });
});