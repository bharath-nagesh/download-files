const CaveoAgentController = require('./caveoAgent.controller');

module.exports = class CaveoAgentRouter {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.caveoAgentController = new CaveoAgentController();
      this.initOrganization();
    }
  }

  initOrganization() {
    this.router.get(`${this.path}`, this.caveoAgentController.getAllCaveoAgents);
    this.router.get(`${this.path}/remote-collector`, this.caveoAgentController.getAllRCCaveoAgents);
    this.router.delete(`${this.path}/remote-collector`, this.caveoAgentController.deleteMultiCaveoAgent);

    this.router.delete(`${this.path}/services`, this.caveoAgentController.deleteMultiCaveoAgent);

  }
};
