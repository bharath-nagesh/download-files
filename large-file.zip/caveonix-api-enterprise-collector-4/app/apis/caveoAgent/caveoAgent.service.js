const sequelize = require('../../../config/db.conf').getConnection();
const CaveoAgent = require('../../models/caveoAgents.model');
const Organization = require('../organization/organization.model');
const { get, has } = require('lodash');
const logger = require('../../../utils/logger').logger;

const loggerLabel = 'CaveoAgentService';

module.exports = class CaveoAgentService {
  constructor(services) {
    this.services = services;
    logger.debug('called constructor');
  }

  async getAllRCCaveoAgents(limit, offset) {
    const orgArr1 = [];
    let ctr1 = 0;
    const combine = [];
    const CaveoAgentResult = await sequelize
      .query(
        `select distinct cav.id, cav.agent_name as "remote_collector_name", cav.ip_address as "remote_collector_IPAddress", cav.host_name as "remote_collector_host_name", cav.remote_address, cav.remote_ip_address, cav.agent_identifier as "RC Type", cav.is_active,session.authorization_info_clear
                from caveo_agents cav,session_info session where cav.id=session.caveo_agent_id and cav.is_active = 'true' and agent_name = 'RC' `,
        { replacements: ['RC'], type: sequelize.QueryTypes.SELECT }
      );
    CaveoAgentResult.filter((object) => {
      const clearId = (object.authorization_info_clear).split('-');
      const orgId = parseInt(clearId[0]);
      orgArr1[ctr1] = orgId;
      ctr1++;
    });
    const orgDetails = await Organization.findAll({ where: { id: { $in: orgArr1 } } });
    combine.res = CaveoAgentResult;
    combine.org = orgDetails;
    return combine;
  }

  async getAllCaveoAgents(orgId) {
    logger.debug('Retrieving all Caveo agents', { loggerLabel });
    logger.silly(`for orgId ${orgId}`, { loggerLabel });

    const orgDetails = await Organization.findOne({ where: { id: orgId }, attributes: ['id', 'name', 'aliasName'] });
    const data = await sequelize.query(`select case when org_id is null then ${get(orgDetails, 'id')} else org_id end as org_id, ca.id as caveo_agent_id,
    case when alias_name is null then '${get(orgDetails, 'aliasName')}' else alias_name end as alias_name, ca.* from
      (select o.id as org_id, o.alias_name, caveo_agent_id, max(s.created_at) from 
         organizations o 
         join session_info s on (CASE WHEN split_part(authorization_info_clear,'-',1) = '' THEN  split_part(authorization_info_clear,'-',2) ELSE split_part(authorization_info_clear,'-',1) END::integer) = o.id
         group by o.id,alias_name, caveo_agent_id
      ) t
      right join caveo_agents ca on ca.id = caveo_agent_id
      where ca.is_active in ('true','enabled','leader')`, {
      replacements: { orgId },
      type: sequelize.QueryTypes.SELECT
    });    
    let count = 0;
    data.forEach((obj) => {
      const host_health_parameters = JSON.parse(obj.host_health_parameters);
      if (has(host_health_parameters, 'time_stamp')) {
        data[count].lastReported = host_health_parameters.time_stamp;
      }
      count++;
    })
    return data;
  }

  getAllRCCaveoAgentsCount() {
    return sequelize
      .query(
        `select count(distinct(cav.id))  from caveo_agents cav,session_info session where cav.id = session.caveo_agent_id and cav.is_active = \'true\' and agent_name = ?`,
        { replacements: ['RC'], type: sequelize.QueryTypes.SELECT }
      );
  }

  async deleteRCCaveoAgentById(caveoAgentId, orgId, cavOrgId) {
    let caveoAgentArray = [];
    let caveoAgentCtr = 0;
    const otherCaveoAgentArray = [];
    let otherCaveoAgentCtr = 0;
    const caveoAgents = await sequelize
      .query(
        `select * from session_info where caveo_agent_id = :caveoAgentId`,
        { replacements: { caveoAgentId }, type: sequelize.QueryTypes.SELECT }
      );
    caveoAgents.filter((object) => {
      const clearId = (object.authorization_info_clear).split('-');
      const newOrgId = parseInt(clearId[0]);
      if (cavOrgId === newOrgId) {
        caveoAgentArray[caveoAgentCtr] = object.id;
        caveoAgentCtr++;
      }
      if (cavOrgId !== newOrgId) {
        otherCaveoAgentArray[otherCaveoAgentCtr] = object.id;
        otherCaveoAgentCtr++;
      }
    });
    if (otherCaveoAgentArray.length === 0) {
      await CaveoAgent.update({ isActive: false }, { where: { id: caveoAgentId } });
      sequelize.query(
        `delete from session_info where caveo_agent_id= :caveoAgentId`,
        { replacements: { caveoAgentId }, type: sequelize.QueryTypes.DELETE }
      );
    }
    if (otherCaveoAgentArray.length > 0) {
      if (caveoAgentArray.length === 0) caveoAgentArray = null;
      sequelize.query(
        `delete from session_info where caveo_agent_id= :caveoAgentId and id in (:caveoAgentArray)`,
        { replacements: { caveoAgentId, caveoAgentArray }, type: sequelize.QueryTypes.DELETE }
      );
    }
    return CaveoAgent.findOne({ where: { id: caveoAgentId } });
  }

  async deleteMultiCaveoAgent(caveoAgentArr) {
    const orgArr = caveoAgentArr;
    await CaveoAgent.update({ isActive: false }, { where: { id: { $in: orgArr } } });
    await sequelize.query(
      `delete from session_info where caveo_agent_id in (:orgArr)`,
      { replacements: { orgArr }, type: sequelize.QueryTypes.DELETE }
    );
    return CaveoAgent.findAll({ where: { id: { $in: orgArr } } });
  }

  getAllOtherCaveoAgents() {
    return CaveoAgent.findAll({ where: { agent_name: { $ne: 'RC' }, $and: [{ is_active: { $ne: 'false' } }] } });
  }

  getAllOtherCaveoAgentsCount() {
    return CaveoAgent.count({ where: { agent_name: { $ne: 'RC' }, $and: [{ is_active: { $ne: 'false' } }] } });
  }

  getCaveoAgentsById(caveoAgentId) {
    logger.debug('Retrieving caveo agents by id', { loggerLabel });
    logger.silly(`for caveoAgentId ${caveoAgentId}`, { loggerLabel });

    return CaveoAgent.findOne({ where: { id: caveoAgentId, $or: [{ is_active: { $ne: 'false' } }] } });
  }

  async deleteOtherCaveoAgentsById(caveoAgentId) {
    await CaveoAgent.update({ isActive: false }, { where: { id: caveoAgentId } });
    await sequelize.query(
      `delete from session_info where caveo_agent_id =:caveoAgentId`,
      { replacements: { caveoAgentId }, type: sequelize.QueryTypes.DELETE }
    );
    return CaveoAgent.findOne({ where: { id: caveoAgentId } });
  }
};
