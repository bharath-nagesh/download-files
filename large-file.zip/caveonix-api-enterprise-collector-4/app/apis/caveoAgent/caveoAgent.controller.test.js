const expect = require('chai').expect;
const proxyquire = require('proxyquire').noCallThru();
const httpMocks = require('node-mocks-http');

describe('CaveoAgentController', function () {
  beforeEach(() => {

  });

  describe('CaveoAgentController', () => {

    describe('getAllRCCaveoAgents', () => {
      it('getAllRCCaveoAgents', async () => {
        const methodData = [{ authorization_info_clear : '0-authinfo',organization_id:0 }];
        const resData = {
          methodData,
          res:{
            filter(){
              return methodData;
            }
          },
          org:{
            map(){
              return methodData;
            }
          }
        };
        const serviceProviderId = 0;
        const page = 1;
        const limit = 10;
        const offset = 0;
        const total_record_count = 10;
        const caveoAgentResponse = {
          total_page_count: 1,
          pageLimit: limit,
          total_record_count: total_record_count,
          page_number: page,
          caveoAgents: [],
          pages: [{
            number: 1,
            url: 'null?page=' + page
          }]
        };

        const CaveoAgentService = class CaveoAgentService {
          getAllRCCaveoAgents(limit, offset){
            return Promise.resolve(resData);
          };

          getAllRCCaveoAgentsCount(){
            return Promise.resolve([{ count:total_record_count }]);
          };
        };
        const CaveoAgentController = proxyquire('./caveoAgent.controller', {
          './caveoAgent.service': CaveoAgentService
        });

        const caveoAgentController = new CaveoAgentController();
        const req = httpMocks.createRequest({ params: { serviceProviderId }, query: { page } });
        const res = httpMocks.createResponse({ locals: { paginate: { limit, offset, page } } });
        const details = await caveoAgentController.getAllRCCaveoAgents(req, res);
        const caveoAgentData = details._getData();
        expect(JSON.parse(caveoAgentData)).to.deep.equal(caveoAgentResponse);
      });
    });

    describe('deleteMultiCaveoAgent', () => {
      it('deleteMultiCaveoAgent', async () => {
        const caveoAgentResponse = [{ authorization_info_clear : '0-authinfo',organization_id:0 }];
        const deleteIds = '1,2,3';

        const CaveoAgentService = class CaveoAgentService {
          deleteMultiCaveoAgent(caveoAgentId){
            return Promise.resolve(caveoAgentResponse);
          };

        };
        const CaveoAgentController = proxyquire('./caveoAgent.controller', {
          './caveoAgent.service': CaveoAgentService
        });

        const caveoAgentController = new CaveoAgentController();
        const req = httpMocks.createRequest({ query: { id:deleteIds } });
        const res = httpMocks.createResponse();
        const details = await caveoAgentController.deleteMultiCaveoAgent(req, res);
        const caveoAgentData = details._getData();
        expect(JSON.parse(caveoAgentData)).to.deep.equal(caveoAgentResponse);
      });
    });

    describe('getCaveoAgentsById', () => {
      it('getCaveoAgentsById', async () => {
        const caveoAgentResponse = [{ authorization_info_clear : '0-authinfo',organization_id:0 }];
        const serviceProviderId = 0;
        const caveoAgentId = 10;
        const CaveoAgentService = class CaveoAgentService {
          getCaveoAgentsById(caveoAgentId){
            return Promise.resolve(caveoAgentResponse);
          };

        };
        const CaveoAgentController = proxyquire('./caveoAgent.controller', {
          './caveoAgent.service': CaveoAgentService
        });

        const caveoAgentController = new CaveoAgentController();
        const req = httpMocks.createRequest({ params: { serviceProviderId,caveoAgentId } });
        const res = httpMocks.createResponse();
        const details = await caveoAgentController.getCaveoAgentsById(req, res);
        const caveoAgentData = details._getData();
        expect(JSON.parse(caveoAgentData)).to.deep.equal(caveoAgentResponse);
      });
    });

  });
});
