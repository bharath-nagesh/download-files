const paginate = require('../../middlewares/paginate.middleware');
const checkId = require('../../../utils/checkId');
const CaveoAgentService = require('./caveoAgent.service');
const caveoAgentService = new CaveoAgentService();
const errorHandler = require('../../../utils/errorHandler');
const logger = require('../../../utils/logger').logger;

const loggerLabel = 'CaveoAgentController';

module.exports = class CaveoAgentController {
  async getAllRCCaveoAgents(req, res) {
    const orgId = req.params.orgId;
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    if (checkId(orgId)) {
      logger.error({ orgId: orgId }, 'Error with Org Id');
      const error = new Error('Bad Org Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    const results = await caveoAgentService.getAllRCCaveoAgents(limit, offset);
    const itemCount = await caveoAgentService.getAllRCCaveoAgentsCount();
    results.res.filter(function (object) {
      const clearId = (object.authorization_info_clear).split('-');
      const orgId = parseInt(clearId[0]);
      const orgData = results.org.find((a) => orgId === a.id);
      object.authorization_info_clear = orgData.name;
      object.organization_id = orgData.id;
      return object;
    });
    const finalResult = results.res;
    const pageCount = Math.ceil(itemCount[0].count / limit);
    return res.json({
      total_page_count: pageCount,
      pageLimit: limit,
      total_record_count: itemCount[0].count,
      page_number: pageNumber,
      caveoAgents: finalResult,
      pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
    });

  }

  async getAllCaveoAgents(req, res) {
    const orgId = req.params.orgId;

    try {
      const results = await caveoAgentService.getAllCaveoAgents(orgId);
      return res.json(results);
    } catch (error) {
      logger.error('Error occurred: unable to get all caveo agents', { error, loggerLabel });
      return errorHandler(req, res, error);
    }
  }

  async deleteMultiCaveoAgent(req, res) {
    const caveoAgentId = req.query.id || '';
    if (!caveoAgentId) {
      const err = new Error('Invalid Input');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    try {
      const caveoAgentArr = caveoAgentId.split(',');
      const update = await caveoAgentService.deleteMultiCaveoAgent(caveoAgentArr);
      return res.json(update);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getAllOtherCaveoAgents(req, res) {
    const orgId = req.params.orgId;
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    if (checkId(orgId)) {
      logger.error({ orgId: orgId }, 'Error with Org Id');
      const error = new Error('Bad Org Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const results = await caveoAgentService.getAllOtherCaveoAgents(limit, offset);
      const itemCount = await caveoAgentService.getAllOtherCaveoAgentsCount();
      const pageCount = Math.ceil(itemCount[0] / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount[0],
        page_number: pageNumber,
        caveoAgents: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getCaveoAgentsById(req, res) {
    const orgId = req.params.orgId;
    const caveoAgentId = req.params.caveoAgentId;
    if (checkId(orgId)) {
      logger.error('unable to get caveo agent by id', { loggerLabel });
      const error = new Error('Error with Org Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    if (checkId(caveoAgentId)) {
      logger.error('unable to get caveo agent by id', { loggerLabel });
      const error = new Error('Error with caveoAgentId');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const caveoAgents = await caveoAgentService.getCaveoAgentsById(caveoAgentId);
      return res.json(caveoAgents);
    } catch (error) {
      logger.error('Error occurred: unable to get caveo agent by id', { error, loggerLabel });
      return errorHandler(req, res, error);
    }
  }
};
