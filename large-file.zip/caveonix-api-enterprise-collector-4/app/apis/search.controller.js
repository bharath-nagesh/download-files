const errorHandler = require('./../../utils/errorHandler');
const logger = require('./../../utils/logger').logger.child({

  sub_name: 'IdentityService-search.controller'
});
const ReferenceService = require('../services/reference.service');
const referenceService = new ReferenceService();
const orgQueries = require('../definitions/org.js');
const complianceQueries = require('../definitions/compliance.js');
const cyberQueries = require('../definitions/cyber.js');
const assetQueries = require('../definitions/asset.js');
const queries = [...orgQueries, ...complianceQueries, ...cyberQueries, ...assetQueries];

const controller = {
  async getSearch(req, res) {
    const term = req.query.term;
    const orgId = req.params.orgId;
    const searchType = req.query.searchType;
    let retval;
    try {
      if (searchType === 'CCI') {
        const def = queries.find((q) => {
          if (!Array.isArray(q.route) && q.route) {
            logger.info({ q, type: typeof q.route }, 'q');
            return q.route.includes(':cciId');
          }
        });
        const data = await referenceService.validateAndExecute(null, def.sql, null, {
          refresh: true,
          cciId: term,
          orgId,
          date:new Date()
        }, {});

        retval = await referenceService.PostProcessor.process({ cciId: term, orgId }, def.postStages, data);
      } else if (searchType === 'CVE') {
        const def = queries.find((q) => {
          if (!Array.isArray(q.route) && q.route) {
            return q.route.includes(':cveId');
          }
        });
        const data = await referenceService.validateAndExecute(null, def.sql, 'like', {
          refresh: true,
          cveId: term,
          orgId,
          date:new Date()
        }, {});
        retval = await referenceService.PostProcessor.process({ cveId: term, orgId }, def.postStages, data);
      } else if (searchType === 'software') {
        const def = queries.find((q) => {
          if (!Array.isArray(q.route) && q.route) {
            return q.route.includes(':softwareName');
          }
        });
        const data = await referenceService.validateAndExecute(null, def.sql, null, {
          refresh: true,
          softwareName: term,
          orgId
        }, {});
        retval = await referenceService.PostProcessor.process({ softwareName: term, orgId }, def.postStages, data);
      } else if (searchType === 'asset') {
        const def = queries.find((q) => {
          if (!Array.isArray(q.route) && q.route) {
            return q.name === 'assetLookUpByNameAdvancedSearch';
          }
        });
        logger.info(def, 'the def');
        const data = await referenceService.validateAndExecute(null, def.sql, 'name', {
          refresh: true,
          assetId: term,
          orgId
        }, {});
        retval = await referenceService.PostProcessor.process({ assetId: term, orgId }, def.postStages, data);
      } else {
        const def = queries.find((q) => {
          if (!Array.isArray(q.route) && q.route) {
            return q.route.includes(':assetId');
          }
        });
        const data = await referenceService.validateAndExecute(null, def.sql, 'name', {
          refresh: true,
          assetId: term,
          orgId
        }, {});
        retval = await referenceService.PostProcessor.process({ assetId: term, orgId }, def.postStages, data);
      }
      return res.json(retval);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'the error');
      return errorHandler(req, res, error);
    }
  }
};
module.exports = controller;
