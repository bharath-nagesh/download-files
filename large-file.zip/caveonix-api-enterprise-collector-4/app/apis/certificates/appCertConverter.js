const ApplicationCertification = require('./applicationCertification/applicationCertification.model');
const Application = require('../application/applicationTag.model');
const Certificates = require('./certificates.model');
module.exports = async (req, res, next, appCertId) => {
  try {
    const appCert = await ApplicationCertification.findByPk(appCertId, {
      include: [
        { model: Application, attributes: ['id'] }, { model: Certificates, attributes: ['id'] }
      ]
    });
    if (!appCert) return res.sendStatus(404);
    req.params.appId = appCert.ApplicationTag.id;
    req.params.certificateId = appCert.Certificate.id;
    next();
  } catch (e) {
    next();
  }
};
