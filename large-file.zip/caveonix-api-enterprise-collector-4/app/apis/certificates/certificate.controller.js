const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-certificate.service'
});
const CertificateService = require('./certificates.service');
const certificateService = new CertificateService();
const errorHandler = require('../../../utils/errorHandler');

module.exports = class CertificateController {

  /**
   *
   * this method is used for get list of Certificates of given orgId
   */
  async getCertificate(req, res) {
    const orgId = req.query.id || req.params.orgId;
    const includeAll = req.query.includeAll || false;
    try {
      const result = await certificateService.getCertificate(orgId, includeAll);
      return res.json(result);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getAllCertificate(req, res) {

    try {
      const result = await certificateService.getAllCertificates();
      return res.json(result);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getApplicationsByCertificateId(req, res) {
    const { orgId, certificateId } = req.params;
    try {
      const applications = await certificateService.getApplicationsByCertificateId(orgId, certificateId);
      return res.json(applications);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getCertificatesByApplicationId(req, res) {
    const { orgId, applicationTagId } = req.params;
    try {
      const applications = await certificateService.getCertificatesByApplicationId(orgId, applicationTagId);
      return res.json(applications);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getGrcCertificates(req, res) {
    const appId = req.query.appId;
    try {
      const certificates = await certificateService.getCertificateForGrc(appId);
      return res.json(certificates);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getOverlays(req, res) {
    const { certificateId } = req.params;
    try {
      const overlays = await certificateService.getOverlayProfiles(certificateId);
      return res.json(overlays);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }
};
