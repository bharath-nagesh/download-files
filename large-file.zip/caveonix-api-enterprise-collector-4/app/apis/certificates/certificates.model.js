const Sequelize = require('sequelize');

class Certificates extends Sequelize.Model {
  /**
   * @swagger
   * components:
   *   schemas:
   *     Certificate:
   *       type: object
   *       required:
   *         - name
   *       properties:
   *         id:
   *           type: integer
   *         name:
   *           type: string
   * @param sequelize
   */
  static init(sequelize) {
    return super.init({
        id: {
          type: Sequelize.INTEGER,
          primaryKey: true,
          autoIncrement: true
        },
        name: { type: Sequelize.STRING, field: 'name' },
        grc: { type: Sequelize.BOOLEAN, field: 'grc_flag' },
        isActive: { type: Sequelize.BOOLEAN, field: 'is_active' }
      },
      {
        sequelize,
        timestamps: false,
        freezeTableName: true,
        tableName: 'certificates',
        underscored: true
      });
  }

  static associate(models) {
    Certificates.belongsToMany(models.Organization, {
      through: models.OrgCertificateMembers,
      otherKey: 'organization_id',
      foreignKey: 'certificate_id',
      timestamps: false

    });
    Certificates.hasMany(models.RegulationControl);
    //TODO uncomment this and fix all places where gus
    //   Certificates.belongsToMany(models.ApplicationTag, {
    //     through: models.AppCertificateMembers,
    //     otherKey: 'application_tag_id',
    //     foreignKey: 'certificate_id'
    //   });
  };
}

module.exports = Certificates;
