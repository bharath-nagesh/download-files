const Sequelize = require('sequelize');
const _ = require('lodash');

class RegulationControl extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      domainId: { type: Sequelize.STRING, field: 'domain_id' },
      domainName: { type: Sequelize.STRING, field: 'domain_name' },
      domainDesc: { type: Sequelize.STRING, field: 'domain_desc' },
      familyId: { type: Sequelize.STRING, field: 'family_id' },
      familyName: { type: Sequelize.STRING, field: 'family_name' },
      familyDesc: { type: Sequelize.STRING, field: 'family_desc' },
      controlId: { type: Sequelize.STRING, field: 'control_id' },
      controlName: { type: Sequelize.STRING, field: 'control_name' },
      controlDesc: { type: Sequelize.STRING, field: 'control_desc' },
      controlGuidance: { type: Sequelize.STRING, field: 'control_guidance' },
      controlAdditionalInformation: { type: Sequelize.STRING, field: 'control_additional_information' },
      controlTestId: { type: Sequelize.STRING, field: 'control_test_id' },
      controlTest: { type: Sequelize.STRING, field: 'control_test' },
      controlBaseline: { type: Sequelize.STRING, field: 'control_base_line' },
      controlPriority: { type: Sequelize.STRING, field: 'control_priority' },
      subControlId: { type: Sequelize.STRING, field: 'sub_control_id' },
      subControlName: { type: Sequelize.STRING, field: 'sub_control_name' },
      subControlDesc: { type: Sequelize.STRING, field: 'sub_control_desc' },
      subControlGuidance: { type: Sequelize.STRING, field: 'sub_control_guidance' },
      subControlAdditionalInformation: { type: Sequelize.STRING, field: 'sub_control_additional_information' },
      subControlTestId: { type: Sequelize.STRING, field: 'sub_control_test_id' },
      subControlTest: { type: Sequelize.STRING, field: 'sub_control_test' },
      subControlBaseline: { type: Sequelize.STRING, field: 'sub_control_base_line' },
      subControlPriority: { type: Sequelize.STRING, field: 'sub_control_priority' },
      compliance: { type: Sequelize.STRING, field: 'compliance' },
      cnss1253CommonControls: { type: Sequelize.STRING, field: 'cnss1253_common_controls' },
      cnss1253Settings: { type: Sequelize.STRING, field: 'cnss1253_settings' },
      assessmentStatus: { type: Sequelize.STRING, field: 'assessment_status' },
      setAssessmentStatus: {
        type: Sequelize.VIRTUAL(Sequelize.BOOLEAN, ['assessmentStatus']),
        get() {
          return _.toUpper(this.assessmentStatus) == 'TRUE';
        }
      },
    }, {
      sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'regulation_controls',
      underscored: true
    });
  }

  static associate(models) {
    RegulationControl.belongsTo(models.Certificates, { foreignKey: 'certificate_id' });
    RegulationControl.belongsTo(models.Organization, { foreignKey: 'organization_id' });
    RegulationControl.hasMany(models.ApplicationAssessment, {
      foreignKey: 'control_id',
      sourceKey: 'controlId',
      scope: { assessment_control_id: { $col: 'RegulationControl.sub_control_id' } }
    });
  }
}

module.exports = RegulationControl;
