/*
This only mounts on application router
 */
const CertifcateController = require('./certificate.controller');
const certificateController = new CertifcateController();
const appCertConverter = require('./appCertConverter');
const informationTypeRouter = require('./informationType/informationType.routes');
const applicationCertificationRouter = require('./applicationCertification/applicationCertification.routes');
const controlParameterRouter = require('./controlParameters/controlParameter.routes');

function makeCertificateRouter(path, router) {
  router.get(`/certificate/:certificateId/overlays/types`, certificateController.getOverlays);
  router.get('/certificate/grc', certificateController.getGrcCertificates);
  informationTypeRouter(`${path}/:certificateId/information-type`, router);
  applicationCertificationRouter(`${path}/:certificateId/certification`, router);

}

function makeApplicationCertificationRouter(path, router) {
  router.param('appCertId', appCertConverter);
  informationTypeRouter(`${path}/:appCertId/information-type`, router);
  applicationCertificationRouter(`${path}`, router);
  controlParameterRouter(`${path}/:appCertId/control-parameter`, router);
}

module.exports = { makeCertificateRouter, makeApplicationCertificationRouter };
