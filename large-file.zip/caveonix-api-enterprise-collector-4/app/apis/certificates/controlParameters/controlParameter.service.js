const UserEditControlParameter = require('./applicationCertificationControlParameter.model');
const ApplicationCertification = require('../applicationCertification/applicationCertification.model');
const ControlParameter = require('./controlParameter.model');
const RegulationControl = require('../regulationControl.model');
const _ = require('lodash');
const logger = require('../../../../utils/logger').logger.child({
  sub_name: 'IdentityService-certificate.service'
});

module.exports = class ControlParameterService {
  constructor() {
    logger.debug('called constructor for certificate service');
  }

  async updateControlParameterForControl(appCertId, controlParameterId, parameterOne, parameterTwo, parameterThree, parameterFour) {
    const applicationCertification = await ApplicationCertification.findOne({
      where: {
        id: appCertId
      }
    });
    const controlParameter = await ControlParameter.findByPk(controlParameterId);
    const [edit] = await UserEditControlParameter.findOrCreate({
      where: { control_parameter_id: controlParameterId },
      include: [{ model: ApplicationCertification, where: { id: appCertId } }],
      defaults: {
        parameterOne,
        parameterTwo,
        parameterThree,
        parameterFour,
        ApplicationCertificationId: applicationCertification.id,
        ControlParameterId: controlParameter.id,
      }
    });
    return edit.update({
      parameterOne,
      parameterTwo,
      parameterThree,
      parameterFour,
      application_certification_id: applicationCertification.id,
      control_parameter_id: controlParameter.id
    });

  };

  async getControlParameterForControl(appCertId, controlId) {
    const appCert = await ApplicationCertification.findOne({
      where: {
        id: appCertId
      }
    });
    const regulationControl = await RegulationControl.findByPk(controlId, { attributes: ['controlId', 'subControlId'] });
    const control = regulationControl.subControlId || regulationControl.controlId;
    const controlParameterArray = await ControlParameter.findAll({
      where: { certificate_id: appCert.certificate_id, controlId: control },
      include: [{
        model: UserEditControlParameter,
        where: { application_certification_id: appCert.id },
        required: false
      }]
    });
    return controlParameterArray.map(it => {
      let { id, controlId, parameterId, parameterOne, parameterTwo, parameterThree, parameterFour, ApplicationCertificationControlParameter: userEdits } = it;
      userEdits = userEdits || {};
      return {
        id,
        controlId,
        parameterId,
        defaultParameterOne: parameterOne,
        defaultParameterTwo: parameterTwo,
        defaultParameterThree: parameterThree,
        defaultParameterFour: parameterFour,
        parameterOne: userEdits.parameterOne || parameterOne,
        parameterTwo: userEdits.parameterTwo || parameterTwo,
        parameterThree: userEdits.parameterThree || parameterThree,
        parameterFour: userEdits.parameterFour || parameterFour
      };
    });
  }

  async setAllControlParameterForApplication(appCertId, controlParameterArray) {
    return Promise.all(_.map(controlParameterArray, controlParameter => this.updateControlParameterForControl(appCertId, controlParameter.id, controlParameter.parameterOne, controlParameter.parameterTwo, controlParameter.parameterThree, controlParameter.parameterFour)));
  }
};
