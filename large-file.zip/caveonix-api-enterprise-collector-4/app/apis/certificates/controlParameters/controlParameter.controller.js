const logger = require('../../../../utils/logger').logger.child({
  sub_name: 'IdentityService-certificate.service'
});
const ControlParameterService = require('./controlParameter.service');
const controlParameterService = new ControlParameterService();
const errorHandler = require('../../../../utils/errorHandler');

module.exports = class ControlParameterController {

  async setControlParameterForControl(req, res) {
    const { appCertId, controlParameterId } = req.params;
    const { parameterOne, parameterTwo, parameterThree, parameterFour } = req.body;
    try {
      const response = await controlParameterService.updateControlParameterForControl(appCertId, controlParameterId, parameterOne, parameterTwo, parameterThree, parameterFour);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getControlParameterForControl(req, res) {
    const { appCertId, controlId } = req.params;
    try {
      const response = await controlParameterService.getControlParameterForControl(appCertId, controlId);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async setAllControlParameterForApplication(req, res) {
    const { appCertId } = req.params;
    const controlParameterArray = req.body;
    try {
      const response = await controlParameterService.setAllControlParameterForApplication(appCertId, controlParameterArray);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }
};
