const Sequelize = require('sequelize');

class ControlParameter extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
        controlId: {
          type: Sequelize.STRING,
          field: 'control_id'
        },
        parameterId: {
          type: Sequelize.STRING,
          field: 'parameter_id',
        },
        parameterOne: {
          type: Sequelize.STRING,
          field: 'param_1'
        },
        parameterTwo: {
          type: Sequelize.STRING,
          field: 'param_2'
        },
        parameterThree: {
          type: Sequelize.STRING,
          field: 'param_3'
        },
        parameterFour: {
          type: Sequelize.STRING,
          field: 'param_4'
        },

      },
      {
        sequelize,
        timestamps: false,
        freezeTableName: true,
        tableName: 'control_parameters',
        underscored: true
      });
  }

  static associate(models) {
    ControlParameter.belongsTo(models.Certificates);
    ControlParameter.hasOne(models.ApplicationCertificationControlParameters);
  }
}

module.exports = ControlParameter;
