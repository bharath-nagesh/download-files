const ControlParameterController = require('./controlParameter.controller');
const controlParameterController = new ControlParameterController();

function makeRouter(path, router) {
  router.put(`${path}/`, controlParameterController.setAllControlParameterForApplication);
  router.put(`${path}/:controlParameterId`, controlParameterController.setControlParameterForControl);
  router.get(`${path}/control/:controlId`, controlParameterController.getControlParameterForControl);

}

module.exports = makeRouter;
