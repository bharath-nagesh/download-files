const Sequelize = require('sequelize');

class ApplicationCertificationControlParameters extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
        // controlId: {
        //   type: Sequelize.STRING,
        //   field: 'control_id'
        // },
        parameterOne: {
          type: Sequelize.STRING,
          field: 'param_1'
        },
        parameterTwo: {
          type: Sequelize.STRING,
          field: 'param_2'
        },
        parameterThree: {
          type: Sequelize.STRING,
          field: 'param_3'
        },
        parameterFour: {
          type: Sequelize.STRING,
          field: 'param_4'
        },
        updatedBy: {
          type: Sequelize.INTEGER,
          field: 'updated_by',
          defaultValue: 0
        },
        createdBy: {
          type: Sequelize.INTEGER,
          field: 'created_by',
          defaultValue: 0
        }

      },
      {
        sequelize,
        timestamps: true,
        freezeTableName: true,
        tableName: 'application_certification_control_parameters',
        underscored: true
      });
  }

  static associate(models) {
    ApplicationCertificationControlParameters.belongsTo(models.ApplicationCertification);
    ApplicationCertificationControlParameters.belongsTo(models.Organization);
    ApplicationCertificationControlParameters.belongsTo(models.ControlParameter);
  }
}

module.exports = ApplicationCertificationControlParameters;
