const Certificate = require('./certificates.model');
const Organization = require('../organization/organization.model');
const ApplicationTag = require('../application/applicationTag.model');
const OverlayProfile = require('./overlayProfile.model');
const _ = require('lodash');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-certificate.service'
});

module.exports = class CertificateService {
  constructor() {
    logger.debug('called constructor for certificate service');
  }

  getAllCertificates() {
    return Certificate.findAll({
      where: { is_active: { $or: { $is: null, $eq: 'enabled' } } }
    });
  }

  /**
   *
   * @param orgId: int - the ID of the organization that we want to get certificates list
   * @returns certificate list of organization
   */
  async getCertificate(orgId, includeAll = false) {
    const orgChain = includeAll === 'true' ? await Organization.getOrgChain(orgId) : orgId;
    return Certificate.findAll({
      where: { is_active: { $or: { $is: null, $eq: 'enabled' } } },
      include: [{
        model: Organization,
        where: { id: orgChain },
        attributes: ['name', 'aliasName', 'fullName'],
        required: true
      }],
      order: [['name', 'ASC']]
    });
  }

  async getApplicationsByCertificateId(orgId, certificateId) {
    const orgChain = await Organization.getOrgChain(orgId);
    return ApplicationTag.findAll({
      include: [{
        model: Organization,
        attributes: ['id', 'name', 'aliasName', 'fullName'],
        where: { id: orgChain },
        required: true
      },
        { model: Certificate, where: { id: certificateId }, required: true }],
      order: [['name', 'ASC']]
    });
  }

  async getCertificatesByApplicationId(orgId, applicationTagId) {
    const orgChain = await Organization.getOrgChain(orgId);
    return ApplicationTag.findAll({
      where: { id: applicationTagId },
      include: [{ model: Organization, attributes: [], where: { id: orgChain }, required: true },
        { model: Certificate, required: true }],
      order: [['name', 'ASC']]
    });
  }

  async getCertificateForGrc(appId = null) {
    const where = { grc: true };

    if (_.isNil(appId)) {
      return Certificate.findAll({
        where
      });
    }
    return ApplicationTag.findByPk(appId, { include: Certificate, where }).then(app => _.get(app, 'Certificates'));
  }

  async getOverlayProfiles(certificateId) {
    const overlayArr = await OverlayProfile.findAll({
      where: { certificate_id: certificateId },
      attributes: [[OverlayProfile.sequelize.fn('DISTINCT', OverlayProfile.sequelize.col('type')), 'type']],
      distinct: true
    });
    return overlayArr.map((o) => o.type);
  }
};
