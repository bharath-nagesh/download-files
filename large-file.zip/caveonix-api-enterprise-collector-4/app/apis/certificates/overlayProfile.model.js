const Sequelize = require('sequelize');

class OverlayProfile extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
        type: {
          type: Sequelize.STRING,
          field: 'type'
        },
        controlNumber: {
          field: 'control_number',
          type: Sequelize.STRING
        },
        lowSelected: {
          type: Sequelize.VIRTUAL(Sequelize.BOOLEAN, ['low']),
          get() {
            return this.getDataValue('low').includes('+');
          }
        },
        moderateSelected: {
          type: Sequelize.VIRTUAL(Sequelize.BOOLEAN, ['moderate']),
          get() {
            return this.getDataValue('moderate').includes('+');
          }
        },
        highSelected: {
          type: Sequelize.VIRTUAL(Sequelize.BOOLEAN, ['high']),
          get() {
            return this.getDataValue('high').includes('+');
          }
        },
        low: {
          field: 'low',
          type: Sequelize.STRING,
          get() {
            const res = {
              controlStandard: this.getDataValue('low').includes('E') && this.controlStandardLow,
              supplementalGuidance: this.getDataValue('low').includes('G') && this.supplementalGuidanceLow,
              controlParameter: this.getDataValue('low').includes('V') && this.controlParameterLow,
              regulatory: this.getDataValue('low').includes('R') && this.regulatoryLow
            };
            return res;
          }
        },
        moderate: {
          field: 'moderate',
          type: Sequelize.STRING,
          get() {
            const res = {
              controlStandard: this.getDataValue('moderate').includes('E') && this.controlStandardModerate,
              supplementalGuidance: this.getDataValue('moderate').includes('G') && this.supplementalGuidanceModerate,
              controlParameter: this.getDataValue('moderate').includes('V') && this.controlParameterModerate,
              regulatory: this.getDataValue('moderate').includes('R') && this.regulatoryModerate
            };
            return res;
          }
        },
        high: {
          field: 'high',
          type: Sequelize.STRING,
          get() {
            const res = {
              controlStandard: this.getDataValue('high').includes('E') && this.controlStandardHigh,
              supplementalGuidance: this.getDataValue('high').includes('G') && this.supplementalGuidanceHigh,
              controlParameter: this.getDataValue('high').includes('V') && this.controlParameterHigh,
              regulatory: this.getDataValue('high').includes('R') && this.regulatoryHigh
            };
            return res;
          }
        },
        phi: {
          field: 'phi',
          type: Sequelize.STRING
        },
        classifiedInformation: {
          field: 'classified_information',
          type: Sequelize.STRING
        },
        spacePlatform: {
          field: 'space_platform',
          type: Sequelize.STRING
        },
        justificationSelectPlus: {
          field: 'justification_select_plus',
          type: Sequelize.STRING
        },
        justificationSelectMinus: {
          field: 'justification_select_minus',
          type: Sequelize.STRING
        },
        controlStandardLow: {
          field: 'control_standard_low',
          type: Sequelize.STRING
        },
        controlStandardModerate: {
          field: 'control_standard_moderate',
          type: Sequelize.STRING
        },
        controlStandardHigh: {
          field: 'control_standard_high',
          type: Sequelize.STRING
        },
        controlStandardPhi: {
          field: 'control_standard_phi',
          type: Sequelize.STRING
        },
        supplementalGuidanceLow: {
          field: 'supplemental_guidance_low',
          type: Sequelize.STRING
        },
        supplementalGuidanceModerate: {
          field: 'supplemental_guidance_moderate',
          type: Sequelize.STRING
        },
        supplementalGuidanceHigh: {
          field: 'supplemental_guidance_high',
          type: Sequelize.STRING
        },
        supplementalGuidancePhi: {
          field: 'supplemental_guidance_phi',
          type: Sequelize.STRING
        },
        regulatoryLow: {
          field: 'regulatory_low',
          type: Sequelize.STRING
        },
        regulatoryModerate: {
          field: 'regulatory_moderate',
          type: Sequelize.STRING
        },
        regulatoryHigh: {
          field: 'regulatory_high',
          type: Sequelize.STRING
        },
        regulatoryPhi: {
          field: 'regulatory_phi',
          type: Sequelize.STRING
        },
        controlParamLow: {
          field: 'control_param_low',
          type: Sequelize.STRING
        },
        controlParamModerate: {
          field: 'control_param_moderate',
          type: Sequelize.STRING
        },
        controlParamHigh: {
          field: 'control_param_high',
          type: Sequelize.STRING
        },
        controlParamPhi: {
          field: 'control_param_phi',
          type: Sequelize.STRING
        },
        controlStandard: {
          field: 'control_standard',
          type: Sequelize.STRING
        },
        supplementalGuidance: {
          field: 'supplemental_guidance',
          type: Sequelize.STRING
        },
        regulator: {
          field: 'regulator',
          type: Sequelize.STRING
        },
        controlParam: {
          field: 'control_param',
          type: Sequelize.STRING
        },
      },
      {
        sequelize,
        timestamps: false,
        freezeTableName: true,
        tableName: 'overlay_profiles',
        underscored: true
      });
  }
}

module.exports = OverlayProfile;
