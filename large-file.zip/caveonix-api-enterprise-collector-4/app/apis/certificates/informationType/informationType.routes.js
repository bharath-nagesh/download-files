const InformationTypeController = require('./informationType.controller');
const informationTypeController = new InformationTypeController();

function makeRouter(path,router) {
  router.put(`${path}/:informationTypeId`, informationTypeController.setInformationTypeForApplication);
  router.get(`${path}/`, informationTypeController.getInformationTypeForApplication);

  router.post(`${path}/`, informationTypeController.setAllInformationTypeForApplication);

}
module.exports = makeRouter;
