const Sequelize = require('sequelize');

class InformationType extends Sequelize.Model {
  static init(sequelize) {
    return super.init(
      {
        id: {
          type: Sequelize.INTEGER,
          primaryKey: true,
          autoIncrement: true
        },
        family: {
          type: Sequelize.STRING,
          allowNull: false

        },
        category: {
          type: Sequelize.STRING,
          allowNull: false,
          field: 'category'

        },
        informationType: {
          type: Sequelize.STRING,
          allowNull: false,
          field: 'information_type'

        },
        confidentiality: {
          type: Sequelize.STRING,
          allowNull: false,
          field: 'confidentiality'

        },
        availability: {
          type: Sequelize.STRING,
          allowNull: false,
          field: 'availability'

        },
        integrity: {
          type: Sequelize.NUMBER,
          field: 'integrity'
        },
        notes: {
          type: Sequelize.STRING,
          allowNull: false,
          field: 'notes'

        },
      },
      {
        timestamps: false,
        freezeTableName: true,
        tableName: 'information_types',
        underscored: true,
        sequelize
      }
    );
  }

  static associate(models) {
    InformationType.belongsTo(models.Organization, { foreignKey: 'organization_id' });
    InformationType.belongsTo(models.Certificates, { foreignKey: 'certificate_id' });
    InformationType.hasOne(models.ApplicationCertificateInformationType, { foreignKey: 'information_type_id' });
  };
}

module.exports = InformationType;
