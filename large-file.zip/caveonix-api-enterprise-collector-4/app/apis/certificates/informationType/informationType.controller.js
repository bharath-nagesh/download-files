const logger = require('../../../../utils/logger').logger.child({
  sub_name: 'IdentityService-certificate.service'
});
const InformationTypeService = require('./informationType.service');
const informationTypeService = new InformationTypeService();
const errorHandler = require('../../../../utils/errorHandler');

module.exports = class InformationTypeController {

  async setInformationTypeForApplication(req, res) {
    const { appId, certificateId, informationTypeId } = req.params;
    const { confidentiality, integrity, availability, justification } = req.body;
    try {
      const response = await informationTypeService.updateInformationTypeForApplication(appId, certificateId, informationTypeId, confidentiality, integrity, availability, justification);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }
  async getInformationTypeForApplication(req, res) {
    const { appId, certificateId,appCertId } = req.params;
    try {
      const response = await informationTypeService.getInformationTypeForApplication(appCertId);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async setAllInformationTypeForApplication(req, res) {
    const { appId, certificateId,appCertId } = req.params;
    const informationTypeArray = req.body;
    try {
      const response = await informationTypeService.setAllInformationTypeForApplication(appCertId, informationTypeArray);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }
};
