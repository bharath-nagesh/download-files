const Sequelize = require('sequelize');

class ApplicationCertificateInformationType extends Sequelize.Model {
  static init(sequelize) {
    return super.init(
      {
        id: {
          type: Sequelize.INTEGER,
          primaryKey: true,
          autoIncrement: true
        },

        confidentiality: {
          type: Sequelize.STRING,
          allowNull: false,
          field: 'confidentiality'

        },
        availability: {
          type: Sequelize.STRING,
          allowNull: false,
          field: 'availability'

        },
        integrity: {
          type: Sequelize.NUMBER,
          field: 'integrity'
        },
        justification: {
          type: Sequelize.STRING,
          allowNull: false,
          field: 'justification'

        },
      },
      {
        timestamps: false,
        freezeTableName: true,
        tableName: 'application_certificate_information_type_mappings',
        underscored: true,
        sequelize
      }
    );
  }

  static associate(models) {
    ApplicationCertificateInformationType.belongsTo(models.InformationType, { foreignKey: 'information_type_id' });
    ApplicationCertificateInformationType.belongsTo(models.ApplicationCertification, { foreignKey: 'application_certificate_member_id' });
  };
}

module.exports = ApplicationCertificateInformationType;
