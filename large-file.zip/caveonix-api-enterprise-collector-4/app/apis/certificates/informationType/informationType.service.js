const UserEditInformationType = require('./applicationCertificateInformationType.model');
const ApplicationCertification = require('../applicationCertification/applicationCertification.model');
const InformationType = require('./InformationType.model');
const _ = require('lodash');
const logger = require('../../../../utils/logger').logger.child({
  sub_name: 'IdentityService-certificate.service'
});

module.exports = class InformationTypeService {
  constructor() {
    logger.debug('called constructor for certificate service');
  }

  async updateInformationTypeForApplication(appId, certificateId, informationTypeId, confidentiality, integrity, availability, justification) {
    const appCertMember = await ApplicationCertification.findOne({
      where: {
        application_id: appId,
        certificate_id: certificateId
      }
    });
    const [edit] = await UserEditInformationType.findOrCreate({
      where: { information_type_id: informationTypeId },
      include: [{ model: ApplicationCertification, where: { application_id: appId, certificate_id: certificateId } }],
      defaults: {
        confidentiality,
        integrity,
        availability,
        justification,
        application_certificate_member_id: appCertMember.id
      }
    });

    return edit.update({ confidentiality, integrity, availability, justification });

  };

  async setAllInformationTypeForApplication(appCertId, informationTypeArray) {
    const appCertMember = await ApplicationCertification.findOne({
      where: {
        id: appCertId
      }
    });
    const transaction = await ApplicationCertification.sequelize.transaction();
    informationTypeArray = informationTypeArray.map(it => {
      it.application_certificate_member_id = appCertMember.id;
      it.information_type_id = it.information_type_id || it.informationTypeId;
      return it;
    });
    try {
      await UserEditInformationType.destroy({
        where: { application_certificate_member_id: appCertMember.id },
        transaction
      });
      const data = await UserEditInformationType.bulkCreate(informationTypeArray, { transaction });
      const x = (value) => {
        switch (_.lowerCase(value)) {
          case 'high':
            return 3;
            break;
          case 'moderate':
            return 2;
            break;
          case 'low':
            return 1;
            break;
          default:
            return 0;
            break;
        }
      };
      ['confidentiality', 'integrity', 'availability'].forEach((label) => {
        appCertMember[label] = _.maxBy(_.map(informationTypeArray, it => it[label]), x);
      });
      appCertMember.ciaValue = _.maxBy(['confidentiality', 'integrity', 'availability'].map((label) => appCertMember[label]), x);

      await appCertMember.save({ transaction });
      await transaction.commit();
      return data;
    } catch (error) {
      await transaction.rollback();
      throw error;
    }
  };

  async getInformationTypeForApplication(appCertId) {
    const appCertMember = await ApplicationCertification.findOne({
      where: {
        id: appCertId
      }
    });

    const informationTypeArray = await InformationType.findAll({
      where: { certificate_id: appCertMember.certificate_id },
      include: [{
        model: UserEditInformationType,
        where: { application_certificate_member_id: appCertMember.id },
        required: false
      }]
    });
    return informationTypeArray.map(it => {
      let { id, family, category, informationType, confidentiality, availability, integrity, notes, ApplicationCertificateInformationType: userEdits } = it;
      userEdits = userEdits || {};
      return {
        id,
        family,
        category,
        information_type: informationType,
        recommended_confidentiality: confidentiality,
        recommended_integrity: integrity,
        recommended_availability: availability,
        confidentiality: userEdits.confidentiality || confidentiality,
        integrity: userEdits.integrity || integrity,
        availability: userEdits.availability || availability,
        notes,
        justification: userEdits.justification,
        selected: !!it.ApplicationCertificateInformationType
      };
    });
  }

};
