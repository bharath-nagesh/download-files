const Sequelize = require('sequelize');

class CertificateWorkflowSteps extends Sequelize.Model {
  static init(sequelize) {
    return super.init(
      {
        id: {
          type: Sequelize.INTEGER,
          primaryKey: true,
          autoIncrement: true
        },
        name: {
          type: Sequelize.STRING,

        },
        stepSequence: {
          type: Sequelize.NUMBER,
          field: 'step_sequence'
        },
      },
      {
        timestamps: false,
        freezeTableName: true,
        tableName: 'certificate_workflow_steps',
        underscored: true,
        sequelize
      }
    );
  }

  static associate(models) {
    CertificateWorkflowSteps.belongsTo(models.Certificates, { foreignKey: 'certificate_id' });
    CertificateWorkflowSteps.belongsToMany(models.Module, {
      through: 'certificate_workflow_modules_members',
      foreignKey: 'certificate_workflow_step_id',
      otherKey:'module_id'
    });
  };
}

module.exports = CertificateWorkflowSteps;
