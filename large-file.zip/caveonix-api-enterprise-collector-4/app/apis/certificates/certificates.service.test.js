const expect = require('chai').expect;
const proxyquire = require('proxyquire').noCallThru();

describe('CertificateService', function () {
  beforeEach(() => {

  });

  describe('getAllCertificates', () => {
    it('getAllCertificates', async () => {

      const response = [{
        data: 1
      }];

      class CertificateModalStub {
        static findAll() {
          return Promise.resolve(response);
        }
      };

      const CertificateService = proxyquire('./certificates.service', {
        './certificates.model': CertificateModalStub
      });
      const certificateService = new CertificateService();
      const data = await certificateService.getAllCertificates();
      expect(data).to.be.equal(response);
    });
  });

  describe('getCertificate', () => {
    it('getCertificate', async () => {
      const orgId = 1;
      const orgChain = [1,2,3];
      const includeAll = 'true';
      const response = [{
        data: 1
      }];

      class CertificateModalStub {
        static findAll() {
          return Promise.resolve(response);
        }
      };

      class OrganizationStub {
        static getOrgChain(orgId) {
          return Promise.resolve(orgChain);
        }
      };

      const CertificateService = proxyquire('./certificates.service', {
        './certificates.model': CertificateModalStub,
        '../organization/organization.model': OrganizationStub
      });
      const certificateService = new CertificateService();
      const data = await certificateService.getCertificate(orgId, includeAll);
      expect(data).to.be.equal(response);
    });
  });

  describe('getApplicationsByCertificateId', () => {
    it('getApplicationsByCertificateId', async () => {
      const orgId = 1;
      const orgChain = [1,2,3];
      const certificateId = 1;
      const response = [{
        data: 1
      }];

      class ApplicationTagStubStub {
        static findAll() {
          return Promise.resolve(response);
        }
      };

      class OrganizationStub {
        static getOrgChain(orgId) {
          return Promise.resolve(orgChain);
        }
      };

      const CertificateService = proxyquire('./certificates.service', {
        '../applicationTag/applicationTag.model': ApplicationTagStubStub,
        '../organization/organization.model': OrganizationStub
      });
      const certificateService = new CertificateService();
      const data = await certificateService.getApplicationsByCertificateId(orgId, certificateId);
      expect(data).to.be.equal(response);
    });
  });

  describe('getCertificatesByApplicationId', () => {
    it('getCertificatesByApplicationId', async () => {
      const orgId = 1;
      const orgChain = [1,2,3];
      const applicationTagId = 1;
      const response = [{
        data: 1
      }];

      class ApplicationTagStubStub {
        static findAll() {
          return Promise.resolve(response);
        }
      };

      class OrganizationStub {
        static getOrgChain(orgId) {
          return Promise.resolve(orgChain);
        }
      };

      const CertificateService = proxyquire('./certificates.service', {
        '../applicationTag/applicationTag.model': ApplicationTagStubStub,
        '../organization/organization.model': OrganizationStub
      });
      const certificateService = new CertificateService();
      const data = await certificateService.getCertificatesByApplicationId(orgId, applicationTagId);
      expect(data).to.be.equal(response);
    });
  });

});
