const expect = require('chai').expect;
const proxyquire = require('proxyquire').noCallThru();
const httpMocks = require('node-mocks-http');

describe('CertificateController', function () {
  beforeEach(() => {

  });

  describe('CertificateController', () => {

    describe('getCertificate', () => {
      it('getCertificate', async () => {
        let resData = { data : 1 };
        const orgId = 1;
        const CertificateService = class CertificateService {
          getCertificate(orgId, includeAll){
            return Promise.resolve(resData);
          };
        };
        const CertificateController = proxyquire('./certificate.controller', {
          './certificates.service': CertificateService
        });

        const certificateController = new CertificateController();
        const req = httpMocks.createRequest({ params: { orgId } });
        const res = httpMocks.createResponse();
        const details = await certificateController.getCertificate(req, res);
        const certificateData = details._getData();
        expect(JSON.parse(certificateData)).to.deep.equal(resData);
      });
    });

    describe('getAllCertificate', () => {
      it('getAllCertificate', async () => {
        let resData = { data : 1 };
        const CertificateService = class CertificateService {
          getAllCertificates(orgId, includeAll){
            return Promise.resolve(resData);
          };
        };
        const CertificateController = proxyquire('./certificate.controller', {
          './certificates.service': CertificateService
        });

        const certificateController = new CertificateController();
        const req = httpMocks.createRequest();
        const res = httpMocks.createResponse();
        const details = await certificateController.getAllCertificate(req, res);
        const certificateData = details._getData();
        expect(JSON.parse(certificateData)).to.deep.equal(resData);
      });
    });

    describe('getApplicationsByCertificateId', () => {
      it('getApplicationsByCertificateId', async () => {
        let resData = { data : 1 };
        const orgId = 1;
        const certificateId = 1;
        const CertificateService = class CertificateService {
          getApplicationsByCertificateId(orgId, includeAll){
            return Promise.resolve(resData);
          };
        };
        const CertificateController = proxyquire('./certificate.controller', {
          './certificates.service': CertificateService
        });

        const certificateController = new CertificateController();
        const req = httpMocks.createRequest({ params: { orgId, certificateId } });
        const res = httpMocks.createResponse();
        const details = await certificateController.getApplicationsByCertificateId(req, res);
        const certificateData = details._getData();
        expect(JSON.parse(certificateData)).to.deep.equal(resData);
      });
    });

    describe('getCertificatesByApplicationId', () => {
      it('getCertificatesByApplicationId', async () => {
        let resData = { data : 1 };
        const orgId = 1;
        const applicationTagId = 1;
        const CertificateService = class CertificateService {
          getCertificatesByApplicationId(orgId, includeAll){
            return Promise.resolve(resData);
          };
        };
        const CertificateController = proxyquire('./certificate.controller', {
          './certificates.service': CertificateService
        });

        const certificateController = new CertificateController();
        const req = httpMocks.createRequest({ params: { orgId, applicationTagId } });
        const res = httpMocks.createResponse();
        const details = await certificateController.getCertificatesByApplicationId(req, res);
        const certificateData = details._getData();
        expect(JSON.parse(certificateData)).to.deep.equal(resData);
      });
    });

  });
});
