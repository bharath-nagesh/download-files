module.exports = {
  CATEGORIZED: 'Categorized System',
  INFORMATION: 'Information Type',
  SELECT: 'Select Controls',
  IMPLEMENT: 'Implement Controls',
  ASSESS: 'Assess Controls',
  AUDIT: 'Audit Review',
  AUTHORIZED: 'Authorized System',
  POAM: 'POA&M',
  TASK: 'Task',
};
