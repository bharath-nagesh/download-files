const ApplicationCertification = require('./applicationCertification.model');
const Application = require('../../application/applicationTag.model');
const AppControlMembers = require('./applicationAssignedControls/appCertificateControlMember.model');
const ApplicationAuthorize = require('../../application/applicationAuthorize.model');
const ApplicationService = require('../../application/applicationTag.service');
const RegulationControl = require('../regulationControl.model');
const Certificates = require('../certificates.model');
const CertificateWorkflowStep = require('../certificateWorkflowSteps.model');
const UserWorkflowMember = require('./userWorkflowMember.model');
const User = require('../../user/user.model');
const CertificateWorkflowSteps = require('../certificateWorkflowSteps.model');
const Artifact = require('./applicationAssignedControls/artifact.model');
const ApplicationCertificationArtifact = require('./applicationCertificationArtifact.model');
const artifactTypes = require('./artifact.types');
const appService = new ApplicationService();
const EmailConfigurationService = require('../../emailServer/emailServer.service');
const emailService = new EmailConfigurationService();
const logger = require('../../../../utils/logger').logger.child({
  sub_name: 'IdentityService-certificate.service'
});

const _ = require('lodash');
module.exports = class ApplicationCertificationService {
  constructor() {
    logger.debug('called constructor for certificate service');
  }

  async appCertUpdatedEventHandler(data) {
    const { appCertId } = data.data;
    const { systemOwner, organization_id: orgId } = await ApplicationCertification.findByPk(appCertId, {
      include: [{
        model: User,
        as: 'systemOwner',
        attributes: ['username']
      }]
    });
    const { username: email } = systemOwner;

    await emailService.sendEmail(orgId, null, 'CaveoNotification', 'Your System has been Updated', null, email);
  }

  async getWorkflowSteps(appCertId) {
    const appCert = await ApplicationCertification.findByPk(appCertId);
    if (!appCert) {
      const error = new Error('Application Certification not found');
      error.status = 404;
      throw error;
    }
    return CertificateWorkflowSteps.findAll({
      where: { certificate_id: appCert.certificate_id },
      order: ['stepSequence']
    });
  }

  async getUserPermission(appCertId) {
    const appCert = await ApplicationCertification.findByPk(appCertId);
    if (!appCert) {
      const error = new Error('Application Certification not found');
      error.status = 404;
      throw error;
    }
    const users = await User.findAll({
      attributes: ['id', 'username', 'firstName', 'lastName'],
      include: [
        {
          attributes: [],
          association: User.associations.Organizations,
          where: { id: appCert.organization_id }
        },

        {
          association: User.associations.UserWorkflowMembers,
          where: { application_certification_id: appCert.id },
          required: false,
          include: [{
            association: UserWorkflowMember.associations.CertificateWorkflowStep,
            attributes: ['name', 'step_sequence', 'id'],
            where: { certificate_id: appCert.certificate_id }
          }]
        }
      ]
    });
    return Promise.all(_.map(users, async (user) => {
      let userPerms = {};
      if (user.id == appCert.system_owner || user.id == appCert.created_by) {
        const steps = await CertificateWorkflowStep.findAll({
          where: { certificate_id: appCert.certificate_id },
          attributes: ['name', 'id']
        });
        userPerms = _.reduce(steps, (result, step) => {
          result[step.name] = { id: step.id, perm: 'leader', sysOwner: true };
          return result;
        }, {});
      } else {
        userPerms = _.reduce(user.UserWorkflowMembers, (result, uwfm) => {
          result[uwfm.CertificateWorkflowStep.name] = { id: uwfm.CertificateWorkflowStep.id, perm: uwfm.type };
          return result;
        }, {});
      }
      user.setDataValue('perms', userPerms);
      return user.toJSON();
    }));
  }

  async getUserPermissionByUserId(appCertId, userId) {
    const appCert = await ApplicationCertification.findByPk(appCertId);
    if (!appCert) {
      const error = new Error('Application Certification not found');
      error.status = 404;
      throw error;
    }

    const user = await User.findByPk(userId, {
      attributes: ['id', 'username', 'firstName', 'lastName'],
      include: [
        {
          attributes: [],
          association: User.associations.Organizations,
          where: { id: appCert.organization_id }
        },
        {
          association: User.associations.UserWorkflowMembers,
          where: { application_certification_id: appCert.id },
          required: false,
          include: [{
            association: UserWorkflowMember.associations.CertificateWorkflowStep,
            attributes: ['name', 'step_sequence', 'id'],
            where: { certificate_id: appCert.certificate_id }
          }]
        }
      ]
    });

    if (!user) {
      const error = new Error('User unauthorized');
      error.status = 403;
      throw error;
    }
    let userPerms = {};
    if (user.id == appCert.system_owner || user.id == appCert.created_by) {
      const steps = await CertificateWorkflowStep.findAll({
        where: { certificate_id: appCert.certificate_id },
        attributes: ['name', 'id']
      });
      userPerms = _.reduce(steps, (result, step) => {
        result[step.name] = { id: step.id, perm: 'leader', sysOwner: true };
        return result;
      }, {});
    } else {
      userPerms = _.reduce(user.UserWorkflowMembers, (result, uwfm) => {
        result[uwfm.CertificateWorkflowStep.name] = { id: uwfm.CertificateWorkflowStep.id, perm: uwfm.type };
        return result;
      }, {});
    }
    user.setDataValue('perms', userPerms);
    return user.toJSON();
  }

  async setUserPermission(appCertId, userPermissions = []) {
    const appCert = await ApplicationCertification.findByPk(appCertId);
    if (!appCert) {
      const error = new Error('Application Certification not found');
      error.status = 404;
      throw error;
    }
    const transaction = await ApplicationCertification.sequelize.transaction();
    try {
      await UserWorkflowMember.destroy({
        where: {
          application_certification_id: appCert.id
        },
        transaction
      });
      const instance = await UserWorkflowMember.bulkCreate(userPermissions.map(u => {
          u.application_certification_id = appCert.id;
          return u;
        }),
        {
          transaction
        });
      await transaction.commit();
      return instance;
    } catch (error) {
      await transaction.rollback();
      throw error;
    }
  }

  async setIndividualUserPermission(appCertId, userId, userPermissions = []) {
    const appCert = await ApplicationCertification.findByPk(appCertId);
    if (!appCert) {
      const error = new Error('Application Certification not found');
      error.status = 404;
      throw error;
    }
    const transaction = await ApplicationCertification.sequelize.transaction();
    try {
      await UserWorkflowMember.destroy({
        where: {
          application_certification_id: appCert.id,
          user_id: userId
        },
        transaction
      });
      const instance = await UserWorkflowMember.bulkCreate(userPermissions.map(u => {
          u.user_id = userId;
          u.application_certification_id = appCert.id;
          return u;
        }),
        {
          transaction
        });
      await transaction.commit();
      return instance;
    } catch (error) {
      await transaction.rollback();
      throw error;
    }
  }

  async deleteApplicationCertification(ids = []) {
    return ApplicationCertification.update({ isActive: 'false' }, { where: { id: ids, ccpProfile: false } });
  }

  async createApplicationCertification(appId, certificateId, orgId, userId, params) {
    const include = [];
    params.application_id = appId;
    if (params.systemOwner) {
      params.system_owner = parseInt(params.systemOwner);
      delete params.systemOwner;
    }
    params.ccpProfile = false;
    if (params.ApplicationAuthorize.atoDate) {
      params.ApplicationAuthorize.application_id = appId;
      params.ApplicationAuthorize.certificate_id = certificateId;
      include.push({ model: ApplicationAuthorize });
    }
    params.certificate_id = certificateId;
    params.organization_id = orgId;
    params.created_by = userId;
    params.updated_by = userId;
    if (params.associatedCcpIds && Array.isArray(params.associatedCcpIds)) params.associatedCcpIds = params.associatedCcpIds.filter(o => o).join(',');
    if (params.relatedLaws && Array.isArray(params.relatedLaws)) params.relatedLaws = params.relatedLaws.filter(o => o).join(',');
    if (params.overlayProfile && Array.isArray(params.overlayProfile)) params.overlayProfile = params.overlayProfile.filter(o => o).join(',');
    const applicationCertification = await ApplicationCertification.create(params, { include });

    return applicationCertification;
  }

  async updateApplicationCertification(appCertId, userId, params) {
    if (params.systemOwner) {
      params.system_owner = parseInt(params.systemOwner);
      delete params.systemOwner;
    }
    const applicationCertification = await ApplicationCertification.findByPk(appCertId, {
      order: [['id', 'desc']],
      include: [
        { model: Application, required: false },
        {
          model: Certificates,
          required: true
        },
        { model: ApplicationAuthorize },
        { model: User, as: 'systemOwner' }
      ]
    });
    applicationCertification.updated_by = userId;
    const { ApplicationAuthorize: appAuthorize } = params;
    delete params.ApplicationAuthorize;
    const appAuthorizeInstance = applicationCertification.ApplicationAuthorize
      ? applicationCertification.ApplicationAuthorize
      : ApplicationAuthorize.build(appAuthorize);
    if (!applicationCertification.ApplicationAuthorize) {
      appAuthorizeInstance.application_id = applicationCertification.application_id;
      appAuthorizeInstance.certificate_id = applicationCertification.certificate_id;
    } else {
      appAuthorizeInstance.update(appAuthorize);
    }
    if (appAuthorizeInstance.atoDate) {
      await applicationCertification.setApplicationAuthorize(appAuthorizeInstance);
    }
    if (params.associatedCcpIds && Array.isArray(params.associatedCcpIds)) params.associatedCcpIds = params.associatedCcpIds.filter(o => o).join(',');
    if (params.overlayProfile && Array.isArray(params.overlayProfile)) params.overlayProfile = params.overlayProfile.join(',');
    if (params.relatedLaws && Array.isArray(params.relatedLaws)) params.relatedLaws = params.relatedLaws.join(',');
    await applicationCertification.update(params);
    await applicationCertification.save();
    return applicationCertification;
  }

  async getApplicationCertification(appCertId) {
    const applicationCertification = await ApplicationCertification.findOne({
      where: { id: appCertId },
      order: [['id', 'desc']],
      include: [
        { model: Application, required: false },
        { model: Certificates, required: true },
        { model: ApplicationAuthorize, required: false },
        { model: User, as: 'systemOwner', attributes: ['username', 'id', 'fullName', 'firstName', 'lastName'] },
        { model: User, as: 'updatedBy', attributes: ['username', 'id', 'fullName', 'firstName', 'lastName'] }
      ]
    });
    return applicationCertification;
  }

  async getApplicationCertificationAssets(appId) {
    return appService.getApplicationAssets(appId);
  }

  async setAuthorizeStatus(appCertId, userId, params) {
    const user = await User.findByPk(userId);
    const appCert = await ApplicationCertification.findByPk(appCertId, { include: [{ association: ApplicationCertification.associations.ApplicationAuthorize }] });
    if (!appCert) {
      const error = new Error('Application Certification Not Found');
      error.status = 404;
      throw error;
    }
    const appAuth = appCert.ApplicationAuthorize ? appCert.ApplicationAuthorize : ApplicationAuthorize.build();
    appAuth.authorizerName = user.fullName;
    appAuth.application_id = appCert.application_id;
    appAuth.certificate_id = appCert.certificate_id;
    appAuth.application_certification_id = appCertId;
    appAuth.updated_by = user.id;
    appAuth.set(params);
    appAuth.atoDate = appAuth.atoDate || new Date();
    await appAuth.save();

    await appCert.setApplicationAuthorize(appAuth);
    return appCert;
  }

  async createArtifact(appCertId, params, controlList, file) {
    params.attachment = file.buffer;
    params.attachmentType = file.mimetype;
    switch (params.type) {
      case artifactTypes.IMPLEMENT:
      case artifactTypes.AUDIT:
      case artifactTypes.ASSESS:
        const transaction = await Artifact.sequelize.transaction();
        try {
          const regulationControls = await RegulationControl.findAll({
            where: { id: controlList },
            attributes: ['controlId', 'subControlId']
          });
          if (!regulationControls.length) {
            const e = new Error('No Regulation Controls Found');
            e.status = 404;
            throw e;
          }
          const regulationControlList = _(regulationControls).map(rc => [rc.controlId, rc.subControlId]).flatten().filter().value();
          const controls = await AppControlMembers.findAll({
            where: {
              controlId: regulationControlList,
              application_certification_id: appCertId
            },
            attributes: ['id']
          });
          const artifact = await Artifact.create(params, { transaction });
          await artifact.setAppCertificateControlMembers(controls, { transaction });

          await transaction.commit();
          return artifact;
        } catch (error) {
          await transaction.rollback();
          throw error;
        }
        break;

      case artifactTypes.CATEGORIZED:
      case artifactTypes.INFORMATION:
      case artifactTypes.AUTHORIZED:
      case artifactTypes.SELECT:
        params.application_certification_id = appCertId;
        const t = await Artifact.sequelize.transaction();
        try {
          const artifact = await ApplicationCertificationArtifact.create(params, { transaction: t });
          await t.commit();
          return artifact;
        } catch (error) {
          await t.rollback();
          throw error;
        }
      case artifactTypes.POAM:
      case artifactTypes.TASK:
      default:
        const e = new Error('Artifact Type is Not Found');
        e.status = 400;
        throw e;
    }
  }

  async getArtifact(appCertId, artifactId, type = 'blah') {
    let classThing;
    if (_.includes([artifactTypes.IMPLEMENT, artifactTypes.AUDIT, artifactTypes.ASSESS])) classThing = Artifact;
    if (_.includes([artifactTypes.CATEGORIZED, artifactTypes.INFORMATION, artifactTypes.AUTHORIZED, artifactTypes.SELECT], type)) classThing = ApplicationCertificationArtifact;
    try {
      if (!classThing) {
        const e = new Error('Artifact Type is Not Found');
        e.status = 400;
        throw e;
      }

      const artifact = await classThing.unscoped().findByPk(artifactId);
      return artifact;
    } catch (error) {
      throw error;
    }

  }

  async deleteArtifact(appCertId, artifactId, type = 'blah') {
    let classThing;
    if (_.includes([artifactTypes.IMPLEMENT, artifactTypes.AUDIT, artifactTypes.ASSESS])) classThing = Artifact;
    if (_.includes([artifactTypes.CATEGORIZED, artifactTypes.INFORMATION, artifactTypes.AUTHORIZED, artifactTypes.SELECT], type)) classThing = ApplicationCertificationArtifact;
    if (!classThing) {
      const e = new Error('Artifact Type is Not Found');
      e.status = 400;
      throw e;
    }

    const artifact = await classThing.update({ isActive: false }, { where: { id: artifactId } });
    return artifact;

  }
};
