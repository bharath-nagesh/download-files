const Sequelize = require('sequelize');

class ApplicationCertificationArtifact extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      notes: { type: Sequelize.TEXT, field: 'notes' },
      attachmentName: { type: Sequelize.STRING, field: 'attachment_name' },
      attachmentType: { type: Sequelize.STRING, field: 'attachment_type' },
      attachment: { type: Sequelize.BLOB, field: 'attachment' },
      type: { type: Sequelize.STRING, field: 'type' },

    }, {
      defaultScope: { attributes: { exclude: ['attachment'] } },
      sequelize,
      timestamps: true,
      freezeTableName: true,
      tableName: 'application_certification_artifacts',
      underscored: true,
      createdAt: 'created_at',
      updatedAt: false
    });
  }

  static associate(models) {

    ApplicationCertificationArtifact.belongsTo(models.User, { as: 'createdBy', foreignKey: 'created_by' });
    ApplicationCertificationArtifact.belongsTo(models.ApplicationCertification, { foreignKey: 'application_certification_id' });
  }
}

module.exports = ApplicationCertificationArtifact;
