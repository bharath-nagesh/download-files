const Sequelize = require('sequelize');

class UserWorkflowMember extends Sequelize.Model {
  static init(sequelize) {
    return super.init(
      {
        id: {
          type: Sequelize.INTEGER,
          primaryKey: true,
          autoIncrement: true
        },
        type: {
          type: Sequelize.ENUM(['member', 'leader']),
          field: 'type',
        }
      },
      {
        timestamps: false,
        freezeTableName: true,
        tableName: 'user_application_certificate_workflow_members',
        underscored: true,
        sequelize
      }
    );
  }

  static associate(models) {
    UserWorkflowMember.belongsTo(models.ApplicationCertification, { foreignKey: 'application_certification_id' });
    UserWorkflowMember.belongsTo(models.User, { foreignKey: 'user_id' });
    UserWorkflowMember.belongsTo(models.CertificateWorkflowSteps, { foreignKey: 'certificate_workflow_id' });

  };
}

module.exports = UserWorkflowMember;
