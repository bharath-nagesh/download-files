const logger = require('../../../../utils/logger').logger.child({
  sub_name: 'IdentityService-certificate.service'
});
const ApplicationCertification = require('./applicationCertification.model');
const _ = require('lodash');
module.exports = class CppApplicationCertificationService {
  constructor() {
    logger.debug('called constructor for certificate service');
  }

  async createCcpApplicationCertification(certificateId, orgId, userId, params) {
    if (params.systemOwner) {
      params.system_owner = parseInt(params.systemOwner);
      delete params.systemOwner;
    }
    delete params.associatedCcpIds;
    params.ccpProfile = true;
    params.certificate_id = certificateId;
    params.organization_id = orgId;
    params.created_by = userId;
    params.updated_by = userId;
    if (params.relatedLaws && Array.isArray(params.relatedLaws)) params.relatedLaws = params.relatedLaws.join(',');
    if (params.overlayProfile && Array.isArray(params.overlayProfile)) params.overlayProfile = params.overlayProfile.join(',');
    const applicationCertification = await ApplicationCertification.create(params);

    return applicationCertification;
  }

  async getCcpAppCerts(orgId) {

    const ccps = await ApplicationCertification.findAll({
      where: {
        ccpProfile: true,
        organization_id: orgId
      }
    });
    return ccps;
  }

  async getCcpAppCertControls(appCertId) {
    return ApplicationCertification.findByPk(appCertId, {
      attributes: [],
      include: [{
        association: ApplicationCertification.associations.AppCertificateControlMembers,
        attributes: ['id', 'controlId'],
        required: false
      }]
    });
  }
};
