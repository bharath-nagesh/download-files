const UserWorkflowMember = require('../userWorkflowMember.model');
const ApplicationCertification = require('../applicationCertification.model');
const CertificateWorkFlowStep = require('../../certificateWorkflowSteps.model');
module.exports = function (permissionNeeded = 'member') {
  const STEP_SEQUENCE = 4;
  return async (req, res, next) => {
    // ignoring permissions
    // return next();
    const { appCertId } = req.params;
    const appCert = await ApplicationCertification.findByPk(appCertId, /*{ include:[{model:ApplicationCertification}] }*/);
    const permissions = await UserWorkflowMember.findOne({
      where: {
        user_id: req.user.id,
        application_certification_id: appCert.id
      },
      include: [{
        model: CertificateWorkFlowStep,
        where: { stepSequence: STEP_SEQUENCE },
        attributes: ['stepSequence', 'name', 'id']
      }]
    });
    // system owner always allowed
    if (appCert.system_owner == req.user.id || appCert.created_by == req.user.id) return next();
    //no permissions set on app cert
    if (!permissions) return res.status(403).json();
    const workflowStepPermission = permissions.CertificateWorkflowStep;
    if (workflowStepPermission.stepSequence !== STEP_SEQUENCE) return res.status(403).json();
    if (permissions.type === 'member' && permissionNeeded === 'leader') return res.status(403).json();

    return next();
  };
};

