const multer = require('multer');
const ApplicationCertificationController = require('./applicationCertification.controller');
const applicationCertificationController = new ApplicationCertificationController();
const applicationAssignedControlsRouter = require('./applicationAssignedControls/applicationAssignedControls.routes');
const tasksRouter = require('../../tasks/tasks.routes');

function makeRouter(path, router) {
  router.post(`${path}`, applicationCertificationController.createApplicationCertification);
  router.delete(`${path}`, applicationCertificationController.deleteApplicationCertification);
  router.get(`${path}/:appCertId`, applicationCertificationController.getApplicationCertification);
  router.put(`${path}/:appCertId`, applicationCertificationController.updateApplicationCertification);

  router.get(`${path}/:appCertId/ccp`, applicationCertificationController.getCcpByAppCert);
  router.get(`${path}/:appCertId/ccp/:ccpId/controls`, applicationCertificationController.getCcpControls);

  router.get(`${path}/:appCertId/users`, applicationCertificationController.getUserPermissions);
  router.get(`${path}/:appCertId/users/:userId`, applicationCertificationController.getUserPermissionsById);
  router.post(`${path}/:appCertId/users/:userId`, applicationCertificationController.setIndividualUserPermissions);
  router.post(`${path}/:appCertId/users`, applicationCertificationController.setUserPermissions);
  // router.get(`${path}/authorize-status`, applicationCertificationController.setAuthorizeStatus);

  router.put(`${path}/:appCertId/authorize-status`, applicationCertificationController.setAuthorizeStatus);
  router.get(`${path}/:appCertId/workflow-steps`, applicationCertificationController.getWorkflowSteps);
  router.get(`${path}/:appCertId/assets`, applicationCertificationController.getAssetsByApplicationCertificationId);
  router.post(`${path}/:appCertId/artifacts`, multer().single('file'), applicationCertificationController.createArtifact);
  router.get(`${path}/:appCertId/artifacts/:artifactId`, applicationCertificationController.getArtifact);
  router.delete(`${path}/:appCertId/artifacts`, applicationCertificationController.deleteArtifacts);
  applicationAssignedControlsRouter(`${path}/:appCertId/controls`, router);
  tasksRouter(`${path}/:appCertId/tasks`, router);

}

module.exports = makeRouter;
