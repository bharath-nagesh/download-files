const Sequelize = require('sequelize');

class ApplicationCertification extends Sequelize.Model {

  static init(sequelize) {
    return super.init({

      name: {
        type: Sequelize.STRING,
        field: 'name',
      },
      version: {
        type: Sequelize.STRING,
        field: 'version',
        defaultValue: '0'
      },
      tags: {
        type: Sequelize.STRING,
        field: 'tags'
      },
      type: {
        type: Sequelize.STRING,
        field: 'type'
      },
      complianceType: {
        type: Sequelize.STRING,
        field: 'compliance_type'
      },
      abbreviation: {
        type: Sequelize.STRING,
        field: 'abbreviation'
      },
      internalId: {
        type: Sequelize.STRING,
        field: 'internal_id'
      },
      relatedLaws: {
        type: Sequelize.STRING,
        field: 'related_laws'
      },
      systemType: {
        type: Sequelize.STRING,
        field: 'system_type'
      },
      overlayProfile: {
        type: Sequelize.STRING,
        field: 'overlay_profile'
      },
      ccpProfile: {
        type: Sequelize.BOOLEAN,
        field: 'ccp_profile'
      },
      processType: {
        type: Sequelize.ENUM('Annual', 'Change Notification', 'New A&A', 'Security Categorization', 'Significant Change', 'Triennial'),
        field: 'process_type',
      },
      managementPoc: {
        type: Sequelize.STRING,
        field: 'management_poc'
      },
      technicalPoc: {
        type: Sequelize.STRING,
        field: 'techinical_poc'
      },
      systemAuthorizationBoundary: {
        type: Sequelize.STRING,
        field: 'system_authorization_boundary'
      },
      description: {
        type: Sequelize.STRING,
        field: 'description'
      },
      confidentiality: {
        type: Sequelize.STRING,
        field: 'confidentiality'
      },
      availability: {
        type: Sequelize.STRING,
        field: 'availability'
      },
      integrity: {
        type: Sequelize.STRING,
        field: 'integrity'
      },
      ciaValue: { type: Sequelize.STRING, field: 'overall_cia_value' },
      status: { type: Sequelize.STRING, field: 'status', defaultValue: 'Categorize' },
      associatedCcpIds: { type: Sequelize.STRING, field: 'associated_ccp_ids' },
      operationalStatus: { type: Sequelize.STRING, field: 'operational_status' },
      notes: { type: Sequelize.STRING, field: 'notes' }
    }, {
      sequelize,
      timestamps: true,
      freezeTableName: true,
      tableName: 'application_certifications',
      underscored: true
    });
  }

  static associate(models) {
    ApplicationCertification.belongsTo(models.ApplicationTag, { foreignKey: 'application_id' });
    ApplicationCertification.belongsTo(models.User, {
      as: 'systemOwner',
      foreignKey: { name: 'system_owner', type: Sequelize.INTEGER }
    });
    ApplicationCertification.belongsTo(models.User, {
      as: 'createdBy',
      foreignKey: { name: 'created_by', type: Sequelize.INTEGER }
    });
    ApplicationCertification.belongsTo(models.User, {
      as: 'updatedBy',
      foreignKey: { name: 'updated_by', type: Sequelize.INTEGER }
    });
    ApplicationCertification.belongsTo(models.Certificates, { foreignKey: 'certificate_id' });
    ApplicationCertification.belongsTo(models.Organization, { foreignKey: 'organization_id' });
    ApplicationCertification.hasOne(models.ApplicationAuthorize, { foreignKey: 'application_certification_id' });
    ApplicationCertification.hasMany(models.ApplicationCertificationArtifact, { foreignKey: 'application_certification_id' });
    ApplicationCertification.hasMany(models.Task, { foreignKey: 'application_certification_id' });
    ApplicationCertification.hasMany(models.AppCertificateControlMembers, {
      foreignKey: 'application_certification_id',
    });
  }
}

module.exports = ApplicationCertification;
