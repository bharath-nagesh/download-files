const logger = require('../../../../utils/logger').logger.child({
  sub_name: 'IdentityService-certificate.service'
});
const ApplicationCertificationService = require('./applicationCertification.service');
const applicationCertificationService = new ApplicationCertificationService();
const CcpApplicationCertificationService = require('./ccpApplicationCertification.service');
const ccpApplicationCertificationService = new CcpApplicationCertificationService();
const errorHandler = require('../../../../utils/errorHandler');

module.exports = class ApplicationCertificationController {
  async getCcpControls(req, res) {
    const { ccpId } = req.params;
    try {
      const response = await ccpApplicationCertificationService.getCcpAppCertControls(ccpId);
      return res.json(response);
    } catch (e) {
      return errorHandler(req, res, e);
    }
  }

  async getCcpByAppCert(req, res) {
    const orgId = req.user.Organizations[0].id;
    try {
      const response = await ccpApplicationCertificationService.getCcpAppCerts(orgId);
      return res.json(response);
    } catch (e) {
      return errorHandler(req, res, e);
    }
  }

  async createApplicationCertification(req, res) {
    let { appId, certificateId } = req.params;
    const params = req.body;
    const orgId = req.user.Organizations[0].id;
    const userId = req.user.id;
    certificateId = certificateId || req.body.certificate_id;
    appId = appId || req.body.application_id;
    try {
      const response = params.ccpProfile == 'true' || params.ccpProfile == 'Yes' ? await ccpApplicationCertificationService.createCcpApplicationCertification(certificateId, orgId, userId, params)
        : await applicationCertificationService.createApplicationCertification(appId, certificateId, orgId, userId, params);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async deleteApplicationCertification(req, res) {

    try {
      const ids = req.query.id.split(',');
      const response = await applicationCertificationService.deleteApplicationCertification(ids);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async updateApplicationCertification(req, res) {
    const { appCertId } = req.params;
    const params = req.body;
    const userId = req.user.id;
    try {
      const response = await applicationCertificationService.updateApplicationCertification(appCertId, userId, params);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getApplicationCertification(req, res) {
    const { appCertId } = req.params;
    try {
      const response = await applicationCertificationService.getApplicationCertification(appCertId);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getAssetsByApplicationCertificationId(req, res) {
    const { appId } = req.params;
    try {
      const response = await applicationCertificationService.getApplicationCertificationAssets(appId);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getUserPermissions(req, res) {
    const { appCertId } = req.params;
    try {
      const response = await applicationCertificationService.getUserPermission(appCertId);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getUserPermissionsById(req, res) {
    const { appCertId, userId } = req.params;
    try {
      const response = await applicationCertificationService.getUserPermissionByUserId(appCertId, userId);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getWorkflowSteps(req, res) {
    const { appCertId } = req.params;
    try {
      const response = await applicationCertificationService.getWorkflowSteps(appCertId);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async setUserPermissions(req, res) {
    const { appCertId } = req.params;
    const params = req.body;
    try {
      const response = await applicationCertificationService.setUserPermission(appCertId, params);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async setIndividualUserPermissions(req, res) {
    const { appCertId, userId } = req.params;
    const params = req.body;
    try {
      const response = await applicationCertificationService.setIndividualUserPermission(appCertId, userId, params);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async setAuthorizeStatus(req, res) {
    const { appCertId } = req.params;
    const params = req.body;
    const userId = req.user.id;
    try {
      const response = await applicationCertificationService.setAuthorizeStatus(appCertId, userId, params);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async createArtifact(req, res) {
    const createdByUserId = req.user.id;
    const { appCertId } = req.params;
    const { attachmentName, attachmentType, notes, type, controls } = req.body;
    const params = { attachmentName, attachmentType, notes, type, created_by: createdByUserId };
    const controlList = controls ? controls.split(',') : [];
    const file = req.file;
    try {
      const response = await applicationCertificationService.createArtifact(appCertId, params, controlList, file);
      return res.status(201).json({ id: response.id });
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getArtifact(req, res) {
    const { appCertId, artifactId } = req.params;
    const { type } = req.query;
    try {
      const response = await applicationCertificationService.getArtifact(appCertId, artifactId, type);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async deleteArtifacts(req, res) {
    const { appCertId } = req.params;
    const { id = '', type } = req.query;
    const artifactIds = id.split(',');
    try {
      const response = await applicationCertificationService.deleteArtifact(appCertId, artifactIds, type);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

};
