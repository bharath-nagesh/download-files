const AppControlMembers = require('./appCertificateControlMember.model');
const Application = require('../../../application/applicationTag.model');
const ApplicationCertification = require('../applicationCertification.model');
const ApplicationAssessment = require('../../../application/applicationAssessment.model');
const CcpApplicationCertificationService = require('../ccpApplicationCertification.service');
const OverlayProfile = require('../../overlayProfile.model');
const RegulationControl = require('../../regulationControl.model');
const moment = require('moment');
const User = require('../../../user/user.model');
const _ = require('lodash');
const xlsx = require('xlsx');
const logger = require('../../../../../utils/logger').logger.child({
  sub_name: 'IdentityService-certificate.service'
});
const ccpApplicationCertificationService = new CcpApplicationCertificationService();

module.exports = class ApplicationAssignedControlsService {
  constructor() {
    logger.debug('called constructor for certificate service');
  }

  async getApplicationControlByRegulationControlId(appCertId, regulationControlId) {

    const regulationControl = await RegulationControl.findByPk(regulationControlId);
    if (!regulationControl) {
      const e = new Error('Control Not Found');
      e.status = 404;
      throw e;
    }
    const controlId = regulationControl.subControlId || regulationControl.controlId;
    const appCert = await ApplicationCertification.findByPk(appCertId, { attributes: ['overlayProfile', 'ciaValue'] });
    const overlays = await OverlayProfile.findAll({
      where: {
        type: appCert.overlayProfile.split(','),
        controlNumber: controlId
      },
    });
    const appControlMember = await AppControlMembers.findOne({
      where: {
        application_certification_id: appCertId,
        controlId
      },
      include: [{ association: AppControlMembers.associations.Artifacts }, {
        association: AppControlMembers.associations.ImplementationAssignedUser,
        attributes: ['id', 'firstName', 'username', 'lastName']
      }]
    });
    if (!appControlMember) {
      const e = new Error('Control Not Associated with System');
      e.status = 404;
      throw e;
    }
    if (appControlMember.common_control_package_id) {
      const ccpControl = await AppControlMembers.findOne({
        where: {
          id: appControlMember.common_control_package_id
        },
        include: [{ association: AppControlMembers.associations.Artifacts }, {
          association: AppControlMembers.associations.ImplementationAssignedUser,
          attributes: ['id', 'firstName', 'username', 'lastName']
        }]
      });
      appControlMember.setDataValue('ccp', ccpControl);
    }
    const overlaysArray = _(overlays)
      .filter({ controlNumber: controlId })
      .map(o => {
        const includedDataFields = o[appCert.ciaValue.toLowerCase()];
        const obj = { overlay: o.type };
        if (includedDataFields.controlStandard) obj.overlayControlDesc = includedDataFields.controlStandard;
        if (includedDataFields.supplementalGuidance) obj.overlayControlGuidance = includedDataFields.supplementalGuidance;
        // if (includedDataFields.controlParameter) c.controlDesc += includedDataFields.controlParameter;
        if (includedDataFields.regulatory) obj.overlayRegulatory = includedDataFields.regulatory;
        return obj;
      }).value();
    regulationControl.setDataValue('overlays', overlaysArray);
    const testIds = await RegulationControl.findAll({
      where: {
        certificate_id: regulationControl.certificate_id,
        controlId
      }
    });
    appControlMember.setDataValue('control', regulationControl);
    appControlMember.setDataValue('assessmentTestIds', testIds);
    return appControlMember;
  }

  async updateApplicationControlByRegulationControlId(appCertId, regulationControlId, userId, params) {
    const regulationControl = await RegulationControl.findByPk(regulationControlId);
    const controlId = regulationControl.subControlId || regulationControl.controlId;
    const appControlMember = await AppControlMembers.findOne({
      where: {
        application_certification_id: appCertId,
        controlId
      }
    });
    params.updated_by = userId;
    await appControlMember.update(params);
    return appControlMember;
  }

  async getApplicationBaselineControls(appCertId) {
    const appBaselineControls = await AppControlMembers.findAll({
      where: {
        application_certification_id: appCertId,
        baseline: 'true'
      },
      attributes: ['baseline', 'controlId']
    });

    return appBaselineControls;
  }

  async getSelectedControls(appCertId) {
    const appCert = await ApplicationCertification.findByPk(appCertId, { attributes: ['overlayProfile', 'associatedCcpIds', 'ciaValue', 'certificate_id'] });
    const ov = appCert.overlayProfile;
    const overlays = await OverlayProfile.findAll({
      where: { type: ov ? ov.split(',') : null },
    });
    const controls = await RegulationControl.findAll({
      where: {
        certificate_id: appCert.certificate_id
      },
      attributes: ['id', 'controlId', 'controlDesc', 'controlName', 'controlGuidance', 'controlPriority', 'subControlPriority', 'subControlGuidance', 'subControlId', 'subControlName', 'subControlDesc', 'familyName', 'familyId'],
      order: ['id']
    });
    const associatedCcp = appCert.associatedCcpIds;
    const ccpPackages = await ApplicationCertification.findAll({
      where: {
        id: associatedCcp ? associatedCcp.split(',') : null
      },
      attributes: ['id', 'name'],
      include: [{ model: AppControlMembers, attributes: ['id', 'controlId'] }]
    });
    const baselineControlsObj = await AppControlMembers.unscoped().findAll({
      where: {
        $or: [{
          application_certification_id: appCertId,
        }, {
          application_certification_id: appCertId,
          isActive: 'false',
          baseline: 'true'
        }]
      },
      include: { model: User, attributes: ['id', 'fullName', 'firstName', 'lastName', 'username'], as: 'updatedBy' }
    });
    const updatedControl = _(baselineControlsObj).maxBy((control) => control.updatedAt);
    const updatedUser = updatedControl.updatedBy;
    updatedUser.setDataValue('updatedAt', updatedControl.updatedAt);
    updatedUser.setDataValue('updated_at', updatedControl.updatedAt);
    const data = controls.map((c) => {
      const controlId = c.subControlId ? c.subControlId : c.controlId;
      if (_.find(overlays, { controlNumber: controlId })) {
        const selectedOverlays = _.filter(overlays, { controlNumber: controlId });
        selectedOverlays.forEach((o) => {
          const includedDataFields = o[appCert.ciaValue.toLowerCase()];
          if (includedDataFields.controlStandard) c.controlDesc += includedDataFields.controlStandard;
          if (includedDataFields.supplementalGuidance) c.controlGuidance += includedDataFields.supplementalGuidance;
          // if (includedDataFields.controlParameter) c.controlDesc += includedDataFields.controlParameter;
          if (includedDataFields.regulatory) c.controlDesc += includedDataFields.regulatory;

          if (o[`${appCert.ciaValue.toLowerCase()}Selected`]) {
            if (!Array.isArray(c.dataValues.overlay)) c.setDataValue('overlay', []);
            c.dataValues.overlay.push(o.type.split(' ')[0]);
          }
        });
      }
      const appMemberData = _.find(baselineControlsObj, { controlId });
      if (appMemberData) {
        c.setDataValue('baseline', appMemberData.baseline);
        c.setDataValue('tailored', appMemberData.tailored ? appMemberData.tailored : '');
        c.setDataValue('selected', appMemberData.selected);

        ['baseline', 'tailored'].forEach((label) => {
          c.setDataValue(label, appMemberData[label]);
        });

        const availableCcpPackages = [];
        _.forEach(ccpPackages, (ccp) => {
          for (let i = 0; i < ccp.AppCertificateControlMembers.length; i++) {
            const ccpControl = ccp.AppCertificateControlMembers[i];
            if (controlId == ccpControl.controlId) {
              availableCcpPackages.push({
                id: ccp.id,
                name: ccp.name,
                selected: appMemberData.common_control_package_id == ccpControl.id
              });
              break;
            }
          }
        });
        c.setDataValue('ccp', availableCcpPackages);
      }
      return c.get({ plain: true });
    });
    return { data, lastUpdate: updatedUser.toJSON() };
  }

  async getImplementControls(appCertId) {

    const baselineControlsObj = await AppControlMembers.findAll({
      where: {
        application_certification_id: appCertId,
        tailored: { $ne: 'minus' }
      },
      order: ['id'],
      include: [{ model: User, as: 'updatedBy', attributes: ['id', 'firstName', 'lastName', 'username', 'fullName'] }, {
        association: AppControlMembers.associations.ImplementationAssignedUser,
        attributes: ['username', 'firstName', 'lastName', 'id']
      }, {
        model: AppControlMembers,
        attributes: ['baseline', 'implementationWorkStatus', 'tailored', 'implementationStatus', 'implementationStatusLock', 'updatedAt'],
        include: { model: ApplicationCertification, attributes: ['name'] },
        as: 'CCP',
        required: false
      }]
    });
    if (baselineControlsObj.length == 0) {
      const error = new Error('You must select controls from Select Step!');
      error.status = 400;
      throw error;
    }
    const updatedControl = _(baselineControlsObj).maxBy((control) => control.updatedAt);
    const updatedUser = updatedControl.updatedBy;
    updatedUser.setDataValue('updatedAt', updatedControl.updatedAt);
    updatedUser.setDataValue('updated_at', updatedControl.updatedAt);
    const controls = await RegulationControl.findAll({
      where: {
        certificate_id: baselineControlsObj[0].certificate_id,
        $or: [
          { controlId: baselineControlsObj.map(bc => bc.controlId) },
          { subControlId: baselineControlsObj.map(bc => bc.controlId) }
        ]
      },
      order: ['id'],
      attributes: ['id', 'controlId', 'controlDesc', 'controlName', 'controlGuidance', 'controlPriority', 'subControlPriority', 'subControlGuidance', 'subControlId', 'subControlName', 'subControlDesc', 'familyName', 'familyId']
    });
    const data = controls.map((c) => {
      const controlId = c.subControlId ? c.subControlId : c.controlId;
      const appMemberData = _.find(baselineControlsObj, { controlId });
      if (appMemberData) {
        c.setDataValue('baseline', appMemberData.baseline);
        c.setDataValue('notes', appMemberData.notes);
        c.setDataValue('tailored', appMemberData.tailored ? appMemberData.tailored : '');
        c.setDataValue('selected', appMemberData.selected);
        c.setDataValue('ccp', _.get(appMemberData, 'CCP.ApplicationCertification.name'));
        const ccpUpdated = (() => {
          const ccpDate = _.get(appMemberData, 'CCP.updatedAt');
          if (!ccpDate) return false;
          return moment(ccpDate) > moment(appMemberData.updatedAt);
        })();
        c.setDataValue('ccpUpdated', ccpUpdated);
        ['baseline', 'implementationWorkStatus', 'tailored', 'implementationStatus', 'implementationStatusLock', 'ImplementationAssignedUser'].forEach((label) => {
          c.setDataValue(label, appMemberData[label]);
        });
      }

      return c.get({ plain: true });
    }).filter(c => c.selected);
    return { data, lastUpdate: updatedUser.toJSON() };
  }

  async getAuditControls(appCertId) {

    const baselineControlsObj = await AppControlMembers.findAll({
      where: {
        application_certification_id: appCertId,
        tailored: { $ne: 'minus' }
      },
      order: ['id'],
      include: [{ model: User, as: 'updatedBy', attributes: ['id', 'firstName', 'lastName', 'fullName', 'username'] }, {
        association: AppControlMembers.associations.AuditAssignedUser,
        attributes: ['username', 'firstName', 'lastName', 'id']
      }, {
        model: AppControlMembers,
        attributes: ['baseline', 'auditWorkStatus', 'tailored', 'complianceStatus', 'auditStatusLock', 'updatedAt'],
        include: { model: ApplicationCertification, attributes: ['name'] },
        as: 'CCP',
        required: false
      }]
    });
    if (baselineControlsObj.length === 0) {
      const error = new Error('You must select controls from Select Step!');
      error.status = 400;
      throw error;
    }
    const updatedControl = _(baselineControlsObj).maxBy((control) => control.updatedAt);
    const updatedUser = updatedControl.updatedBy;
    updatedUser.setDataValue('updatedAt', updatedControl.updatedAt);
    updatedUser.setDataValue('updated_at', updatedControl.updatedAt);
    const controls = await RegulationControl.findAll({
      where: {
        certificate_id: baselineControlsObj[0].certificate_id,
        $or: [
          { controlId: baselineControlsObj.map(bc => bc.controlId) },
          { subControlId: baselineControlsObj.map(bc => bc.controlId) }
        ]
      },
      order: ['id'],
      attributes: ['id', 'controlId', 'controlDesc', 'controlName', 'controlGuidance', 'controlPriority', 'subControlPriority', 'subControlGuidance', 'subControlId', 'subControlName', 'subControlDesc', 'familyName', 'familyId']
    });
    const data = controls.map((c) => {
      const controlId = c.subControlId ? c.subControlId : c.controlId;
      const appMemberData = _.find(baselineControlsObj, { controlId });
      if (appMemberData) {
        c.setDataValue('baseline', appMemberData.baseline);
        c.setDataValue('notes', appMemberData.notes);
        c.setDataValue('tailored', appMemberData.tailored ? appMemberData.tailored : '');
        c.setDataValue('selected', appMemberData.selected);
        c.setDataValue('ccp', _.get(appMemberData, 'CCP.ApplicationCertification.name'));
        const ccpUpdated = (() => {
          const ccpDate = _.get(appMemberData, 'CCP.updatedAt');
          if (!ccpDate) return false;
          return moment(ccpDate) > moment(appMemberData.updatedAt);
        })();
        c.setDataValue('ccpUpdated', ccpUpdated);
        ['baseline', 'auditWorkStatus', 'tailored', 'complianceStatus', 'auditStatusLock', 'AuditAssignedUser'].forEach((label) => {
          c.setDataValue(label, appMemberData[label]);
        });
      }

      return c.get({ plain: true });
    }).filter(c => c.selected);
    return { data, lastUpdate: updatedUser.toJSON() };
  }

  async generateBaselineControls(appCertId, userId) {
    let controlIds = [];
    const applicationCertification = await ApplicationCertification.findByPk(appCertId);
    let { ciaValue, overlayProfile, ccpProfile } = applicationCertification;
    ciaValue = ciaValue || 'None';
    if (ccpProfile) return;
    const overCIA = ciaValue.toLowerCase().includes('high') ? 'H' : ciaValue.toLowerCase().includes('moderate') ? 'M' : 'L';
    const overlay = overlayProfile ? await OverlayProfile.findAll({
      where: { type: overlayProfile.split(',') }
    }) : [];
    const controls = await RegulationControl.findAll({
      where: {
        certificate_id: applicationCertification.certificate_id
      },
      attributes: ['controlBaseline', 'controlId', 'subControlId']
    });
    for (let i = 0; i < controls.length; i++) {
      const control = controls[i];
      if (_.filter(overlay.map(o => o[`${ciaValue.toLowerCase()}Selected`] && o.controlNumber)).includes(control.controlId) || control.controlBaseline.includes(overCIA)) {
        controlIds.push({ controlId: control.controlId, baseline: control.controlBaseline.includes(overCIA) });
      }
      if (_.filter(overlay.map(o => o[`${ciaValue.toLowerCase()}Selected`] && o.controlNumber)).includes(control.subControlId) || control.controlBaseline.includes(overCIA)) {
        controlIds.push({ controlId: control.subControlId, baseline: control.controlBaseline.includes(overCIA) });
      }
    }
    controlIds = _.uniqBy(controlIds, 'controlId');

    const transaction = await Application.sequelize.transaction();
    try {
      const baselineControls = controlIds.map(c => {
        return {
          application_id: applicationCertification.application_id,
          certificate_id: applicationCertification.certificate_id,
          controlId: c.controlId,
          organization_id: applicationCertification.organization_id,
          application_certification_id: applicationCertification.id,
          baseline: c.baseline,
          created_by: userId,
          updated_by: userId,
          isActive: 'true'
        };
      });
      const applicationControls = await AppControlMembers.bulkCreate(baselineControls, {
        updateOnDuplicate: ['baseline', 'updated_by', 'isActive'],
        transaction
      });
      await AppControlMembers.update({ isActive: 'false' }, {
        where: {
          application_certification_id: applicationCertification.id,
          controlId: { $notIn: _.map(controlIds, 'controlId') }
        },
        transaction
      });
      applicationCertification.status = 'Select';
      await applicationCertification.save({ transaction });
      await transaction.commit();
      return applicationControls;
    } catch (e) {
      transaction.rollback();
      throw e;
    }
  }

  async setSelectedApplicationControls(appCertId, userId, submitted = false, regulationControls = []) {
    /*
    LOGIC:
    1) get all controls from app control members
    2) cycle through the selected controls (controlIds)
        1) if in the selectedControls AND baseline == true: return empty string
        2) if in the selectedControls AND baseline != true: return plus
        3) if NOT in the selectedControls AND baseline == true: return minus
        if NOT in the selectedControls AND baseline != true: do nothing
     */
    const regulationControlIds = regulationControls.map(rc => rc.controlId);
    const ccpIds = await regulationControls.map(rc => rc.ccp);
    const ccpInstances = await Promise.all(ccpIds.map(ccpId => ccpApplicationCertificationService.getCcpAppCertControls(ccpId)));
    const appCert = await ApplicationCertification.findByPk(appCertId);
    const regulationControlsArr = await RegulationControl.findAll({
      where: {
        id: regulationControlIds,
      },
      attributes: ['id', 'subControlId', 'controlId']
    });
    const controlIds = regulationControlsArr.map(rc => {
      return {
        id: rc.id, controlId: rc.subControlId || rc.controlId
      };
    });
    const overlay = await OverlayProfile.findAll({
      where: {
        certificate_id: appCert.certificate_id,
        type: appCert.overlayProfile.split(',')
      }
    });
    const controlMembers = await AppControlMembers.unscoped().findAll({
      where: {
        $or: [{
          application_certification_id: appCertId,
          isActive: 'true'
        }, {
          application_certification_id: appCertId,
          isActive: 'false',
          baseline: 'true'
        }
        ]
      }
    });
// existing controls being updated
    const existingControlsSelected = _(controlMembers)
      .remove(cm => _.remove(controlIds, (c) => c.controlId == cm.controlId).length > 0)
      .map((cm) => {
        const ccp = _.find(ccpInstances, {
          id: cm.ccp
        });
        const isOverlayControl = _.filter(overlay.map(o => o[`${appCert.ciaValue.toLowerCase()}Selected`] && o.controlNumber)).includes(cm.controlId);
        cm.isActive = 'true';
        // if (cm.baseline && cm.isActive == 'false') cm.tailored = 'minus';
        if (cm.baseline && cm.isActive == 'true') cm.tailored = '';
        if (!cm.baseline && cm.isActive == 'true' && !isOverlayControl) cm.tailored = 'plus';
        // if (!cm.baseline && cm.isActive == 'false') cm.tailored = '';
        cm.updated_by = userId;
        if (ccp) cm.common_control_package_id = _.get(_.find(ccp.AppCertificateControlMembers, { controlId: cm.controlId }), 'id');

        return cm.toJSON();
      }).value();
    // existing controls not selected
    const existingControlsDeselected = _.map(controlMembers, cm => {
      const ccp = _.find(ccpInstances, {
        id: cm.ccp
      });
      cm.isActive = 'false';
      cm.tailored = cm.baseline ? 'minus' : '';
      cm.updated_by = userId;
      if (ccp) cm.common_control_package_id = ccp.id;

      return cm.toJSON();
    });
    logger.info({ existingControlsSelected }, 'existing controls');
    // new controls being created
    const newControls = _(controlIds).map(c => {
      const ccp = _.find(ccpInstances, {
        id: _.get(_.find(regulationControls, { controlId: c.id }), 'id')
      });
      const ccpId = ccp ? ccp.id : null;
      return {
        application_id: appCert.application_id,
        certificate_id: appCert.certificate_id,
        application_certification_id: appCertId,
        organization_id: appCert.organization_id,
        updated_by: userId,
        created_by: userId,
        controlId: c.controlId,
        isActive: 'true',
        baseline: false,
        tailored: 'plus',
        common_control_package_id: ccpId
      };
    }).value();
    const transaction = await AppControlMembers.sequelize.transaction();
    try {
      const applicationControls = await AppControlMembers.bulkCreate([...existingControlsDeselected, ...existingControlsSelected, ...newControls], {
        updateOnDuplicate: ['tailored', 'isActive', 'baseline', 'common_control_package_id', 'updated_by', 'created_by'],
        transaction
      });
      if (submitted) {
        appCert.status = 'Implementation';
        await appCert.save({ transaction });
      }
      await transaction.commit();
      return applicationControls;
    } catch (e) {
      transaction.rollback();
      throw e;
    }
  }

  async getSubControlsByRegulationControlId(appCertId, regulationControlId) {
    const appCert = await ApplicationCertification.findByPk(appCertId);
    const regulationControl = await RegulationControl.findByPk(regulationControlId, { attributes: ['controlId'] });
    const controlId = regulationControl.controlId;
    let subControlsInControl = await RegulationControl.findAll({
      where: {
        controlId, certificate_id: appCert.certificate_id,
      },
      attributes: ['id', 'subControlId']
    });
    const subControlList = _.map(subControlsInControl, 'subControlId');
    subControlList.push(controlId);
    subControlsInControl = _.map(subControlsInControl, c => {
      if (!c.subControlId) c.subControlId = controlId;
      return c;
    });
    const appControlMembers = await AppControlMembers.findAll({
      where: {
        application_certification_id: appCertId,
        controlId: subControlList
      },
      attributes: ['controlId'],
      include: { association: AppControlMembers.associations.ImplementationAssignedUser }
    });
    return _.filter(_.map(appControlMembers, (obj) => _.assign(obj, _.find(subControlsInControl, { subControlId: obj.controlId }))), 'id');
  }

  async getFamilyControlsByRegulationControlId(appCertId, appId, certificateId, regulationControlId) {
    const appCert = await ApplicationCertification.findByPk(appCertId);
    const regulationControl = await RegulationControl.findByPk(regulationControlId, { attributes: ['familyId'] });
    const familyId = regulationControl.familyId;
    const controlsInFamily = await RegulationControl.findAll({
      where: { familyId, certificate_id: appCert.certificate_id },
      attributes: ['id', 'controlId']
    });
    const controlList = _.map(controlsInFamily, 'controlId');
    const appControlMembers = await AppControlMembers.findAll({
      where: {
        application_certification_id: appCertId,
        controlId: controlList
      },
      attributes: ['controlId']
    });
    return _.filter(_.map(appControlMembers, (obj) => _.assign(obj, _.find(controlsInFamily, { controlId: obj.controlId }))), 'id');
  }

  async getArtifactDetailsForCertification(appCertId) {
    const appControlMember = await AppControlMembers.findAll({
      where: {
        application_certification_id: appCertId
      },
      attributes: ['controlId'],
      include: [{
        association: AppControlMembers.associations.Artifacts,
        include: [{ model: User, as: 'createdBy', attributes: ['firstName', 'lastName', 'fullName', 'id', 'username'] }]
      }]

    });
    const appCert = await ApplicationCertification.findByPk(appCertId, {
      include: [{
        association: ApplicationCertification.associations.ApplicationCertificationArtifacts,
        include: [{ model: User, as: 'createdBy', attributes: ['firstName', 'lastName', 'fullName', 'id', 'username'] }]
      }]
    });
    const artifactsMap = _(appControlMember)
      .map(acm => acm.Artifacts.map(a => {
        a.setDataValue('controlIds', [acm.controlId]);
        return a.toJSON();
      }))
      .flatten()
      .filter(a => a)
      .reduce((result, a) => {
        result[a.id] = result[a.id] || a;
        result[a.id].controlIds = result[a.id].controlIds || [];
        result[a.id].controlIds.push(...a.controlIds);
        result[a.id].controlIds = Array.from(new Set(result[a.id].controlIds));
        return result;
      }, {});
    return [
      ..._.values(artifactsMap),
      ..._.chain(appCert.ApplicationCertificationArtifacts).flatten().uniqBy(a => a.id).value()
    ];
  }

  async setStatus(appCertId, statusType, regulationControlData = []) {
    return Promise.all(regulationControlData.map(async ({ regulationControlIds, status, lockStatus }) => {
      const regulationControls = await RegulationControl.findAll({ where: { id: regulationControlIds } });
      const controlIds = _.map(regulationControls, rc => rc.subControlId || rc.controlId);
      const update = {};
      if (status) update[statusType] = status;
      if (lockStatus) update[`${statusType}Lock`] = lockStatus;
      //[t, appControlMember] =
      const appControlMember = await AppControlMembers.update(update, {
        returning: true,
        where: {
          application_certification_id: appCertId,
          controlId: controlIds
        }
      });

      return appControlMember[0];
    }));
  }

  async assignControlToUser(appCertId, assignedUserId, assignmentType, regulationControlIds = []) {
    const regulationControls = await RegulationControl.findAll({ where: { id: regulationControlIds } });
    const controlIds = _.map(regulationControls, rc => rc.subControlId || rc.controlId);
    const assignedUserString = `${assignmentType}_user_id`;
    const update = { [assignedUserString]: assignedUserId };
    const appControlMember = await AppControlMembers.update(update, {
      returning: true,
      where: {
        application_certification_id: appCertId,
        controlId: controlIds
      }
    });

    return appControlMember[1];
  }

  async getAssessmentList(appCertId, getAssessmentObjectives = true) {
    const appCert = await ApplicationCertification.findByPk(appCertId);
    const overlay = await OverlayProfile.findAll({
      where: {
        certificate_id: appCert.certificate_id,
        type: appCert.overlayProfile.split(',')
      }
    });
    const baselineControlsObj = await AppControlMembers.findAll({
      where: {
        certificate_id: appCert.certificate_id,
        application_certification_id: appCertId,
        tailored: { $ne: 'minus' }
      },
      order: ['id'],
      include: [{
        model: User, as: 'updatedBy'
      }, {
        association: AppControlMembers.associations.AssessmentAssignedUser,
        attributes: ['username', 'firstName', 'lastName', 'id']
      },
        {
          model: AppControlMembers,
          as: 'CCP',
          attributes: ['baseline', 'tailored', 'updatedAt'],
          include: { model: ApplicationCertification, attributes: ['name'] },
          required: false
        }]
    });
    if (baselineControlsObj.length == 0) {
      const error = new Error('You must select controls from Select Step!');
      error.status = 400;
      throw error;
    }
    //getAssessmentObjectives : if true go against cert 24 in order to get all controls and assessment objectives.
    // if false use cert id in order to just get selected controls

    const controls = await RegulationControl.findAll({
      where: {
        certificate_id: getAssessmentObjectives ? 24 : appCert.certificate_id,
        $or: [
          { controlId: baselineControlsObj.map(bc => bc.controlId).filter(c => c) },
          { subControlId: baselineControlsObj.map(bc => bc.controlId).filter(c => c) }
        ]
      },
      attributes: ['id', 'familyName', 'familyId', 'controlTest', 'controlId', 'controlName', 'subControlId', 'subControlName', 'subControlDesc', 'assessmentStatus', 'setAssessmentStatus'],
      include: [{
        model: ApplicationAssessment,
        where: { application_certification_id: appCertId },
        required: false
      }],
      order: ['id']
    });
    const data = controls.map((c) => {
      const controlId = c.subControlId ? c.subControlId : c.controlId;
      const appMemberData = _.find(baselineControlsObj, { controlId });
      if (appMemberData) {
        c.setDataValue('baseline', appMemberData.baseline);
        c.setDataValue('tailored', appMemberData.tailored ? appMemberData.tailored : '');
        c.setDataValue('selected', appMemberData.selected);
        c.setDataValue('ccp', _.get(appMemberData, 'CCP.ApplicationCertification.name'));
        const ccpUpdated = (() => {
          const ccpDate = _.get(appMemberData, 'CCP.updatedAt');
          if (!ccpDate) return false;
          return moment(ccpDate) > moment(appMemberData.updatedAt);
        })();
        c.setDataValue('ccpUpdated', ccpUpdated);
        ['baseline', 'tailored', 'assessmentStatus', 'assessmentWorkStatus', 'AssessmentAssignedUser'].forEach((label) => {
          c.setDataValue(label, appMemberData[label]);
        });
      }
      const overlayData = _.find(overlay, { controlNumber: controlId });
      if (overlayData) {
        const includedDataFields = overlayData[appCert.ciaValue.toLower];
      }
      return c.get({ plain: true });
    }).filter(c => c.selected);
    const updatedControl = _(baselineControlsObj).maxBy((control) => control.updatedAt);
    const updatedUser = updatedControl.updatedBy;
    updatedUser.setDataValue('updatedAt', updatedControl.updatedAt);
    updatedUser.setDataValue('updated_at', updatedControl.updatedAt);
    return { data, lastUpdate: updatedUser.toJSON() };
  }

  async getAssessmentListForControl(appCertId, regulationControlId) {
    const { controlId, subControlId } = await RegulationControl.findByPk(regulationControlId, { attributes: ['controlId', 'subControlId'] });
    const appCertMemberData = await AppControlMembers.findOne({
      where: {
        controlId: subControlId || controlId,
        application_certification_id: appCertId
      }
    });
    const controls = await RegulationControl.findAll({
      where: {
        certificate_id: 24,
        controlId: subControlId || controlId
      },
      attributes: ['id', 'controlTest', 'controlId', 'subControlId', 'subControlDesc', 'assessmentStatus', 'setAssessmentStatus', 'controlDesc', 'controlGuidance', 'controlAdditionalInformation'],
      include: [{
        model: ApplicationAssessment,
        where: { application_certification_id: appCertId },
        required: false
      }],
      order: ['id']

    });
    const topControl = controls.find(c => appCertMemberData.controlId == c.subControlId || c.controlId);
    topControl.setDataValue('assessmentWorkStatus', appCertMemberData.assessmentWorkStatus);
    return _.map(controls, c => c.toJSON());
  }

  async setAssessmentObjectiveStatus(userId, appCertId, assessmentControls) {
    const transaction = await ApplicationAssessment.sequelize.transaction();
    try {
      const data = await Promise.all(_(assessmentControls).map(async ac => {
        ac.application_certification_id = appCertId;
        ac.userId = userId;
        ac.updated_by = userId;
        ac.createdBy = userId;
        const [instance, created] = await ApplicationAssessment.findOrCreate({
          where: {
            application_certification_id: appCertId,
            assessmentControlId: ac.assessmentControlId,
            controlId: ac.controlId
          },
          defaults: ac,
          transaction
        });
        if (ac.assessmentWorkStatus) {
          const appCertMemberData = await AppControlMembers.findOne({
            where: {
              controlId: ac.assessmentControlId || ac.controlId,
              application_certification_id: appCertId
            }
          });
          appCertMemberData.assessmentWorkStatus = ac.assessmentWorkStatus;
          await appCertMemberData.save({ transaction });
        }
        delete ac.createdBy;
        if (!created) await instance.update(ac, { transaction });
        return instance;
      }).value());
      await transaction.commit();
      return data;
    } catch (error) {
      await transaction.rollback();
      throw error;
    }
  }

  async uploadControls(appCertId, userId, controlFile) {
    const appCert = await ApplicationCertification.findByPk(appCertId);
    if (!appCert) {
      const e = new Error('App Cert not Found');
      e.status = 404;
      throw e;
    }
    const { Sheets } = await xlsx.read(controlFile);
    const output = Object.values(Sheets)[0];
    if (!output) {
      const error = new Error('You must use the template provided');
      error.status = 400;
      throw error;
    }

    const transaction = await ApplicationCertification.sequelize.transaction();
    try {
      const controls = xlsx.utils.sheet_to_json(output);
      await AppControlMembers.update({ isActive: false }, {
        where: { application_certification_id: appCertId },
        transaction
      });
      const appControls = await AppControlMembers.bulkCreate(_.map(controls, (c) => {
        c.application_certification_id = appCertId;
        c.certificate_id = appCert.certificate_id;
        c.organization_id = appCert.organization_id;
        c.application_id = appCert.application_id;
        c.created_by = userId;
        c.updated_by = userId;
        return c;
      }), { transaction });
      await transaction.commit();
      return appControls;
    } catch (error) {
      await transaction.rollback();
      throw error;
    }
  }
};
