const Sequelize = require('sequelize');

class Artifact extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      notes: { type: Sequelize.TEXT, field: 'notes' },
      attachmentName: { type: Sequelize.STRING, field: 'attachment_name' },
      attachmentType: { type: Sequelize.STRING, field: 'attachment_type' },
      attachment: { type: Sequelize.BLOB, field: 'attachment' },
      type: { type: Sequelize.STRING, field: 'type' },

    }, {
      defaultScope: { attributes: { exclude: ['attachment'] } },
      sequelize,
      timestamps: true,
      freezeTableName: true,
      tableName: 'artifacts',
      underscored: true,
      createdAt: 'created_at',
      updatedAt: false
    });
  }

  static associate(models) {
    Artifact.belongsToMany(models.AppCertificateControlMembers, {
      through: 'application_tag_control_artifact_members',
      otherKey: 'application_tag_controls_member_id',
      timestamps: false
    });
    Artifact.belongsTo(models.User, { as: 'createdBy', foreignKey: 'created_by' });
  }
}

module.exports = Artifact;
