const Sequelize = require('sequelize');
const sequelize = require('../../../../../config/db.conf').getConnection();

class AppCertificateMembers extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
    },
    { sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'application_tag_certificate_members',
      underscored: true
    });
  }

  static associate(models) {
    AppCertificateMembers.belongsTo(models.ApplicationTag, { foreignKey: 'application_tag_id' });
    AppCertificateMembers.belongsTo(models.Certificates, { foreignKey: 'certificate_id' });
  };
}
module.exports = AppCertificateMembers;
