const ApplicationAssignedControlsController = require('./applicationAssignedControls.controller');
const assessmentPermissions = require('../assessment/assessment.permissions');
const auditPermissions = require('../audit/audit.permissions');
const implementPermissions = require('../implement/implement.permissions');
const selectPermissions = require('../select/select.permissions');
const multer = require('multer');
;
const upload = multer({ storage: multer.memoryStorage() });
const applicationAssignedControlsController = new ApplicationAssignedControlsController();

function makeRouter(path, router) {
  router.post(`${path}/upload`, upload.single('file'), applicationAssignedControlsController.uploadControls);
  router.get(`${path}/baseline`, auditPermissions('member'), applicationAssignedControlsController.getBaselineControls);
  router.get(`${path}/baseline/generate`, selectPermissions('leader'), applicationAssignedControlsController.generateBaselineControls);
  router.put(`${path}/approval/status`, auditPermissions('leader'), applicationAssignedControlsController.setApprovalStatus);
  router.put(`${path}/implementation/status`, implementPermissions('leader'), applicationAssignedControlsController.setImplementationStatus);
  router.put(`${path}/assessment/status`, assessmentPermissions('leader'), applicationAssignedControlsController.setAssessmentStatus);

  router.put(`${path}/implementation/user/:userId`, implementPermissions('leader'), applicationAssignedControlsController.setImplementationAssignedUsers);
  router.put(`${path}/assessment/user/:userId`, assessmentPermissions('leader'), applicationAssignedControlsController.setAssessmentAssignedUsers);
  router.put(`${path}/audit/user/:userId`, assessmentPermissions('leader'), applicationAssignedControlsController.setAuditAssignedUsers);

  router.get(`${path}/artifact`, applicationAssignedControlsController.getArtifactDetailsForApplicationCertification);

  router.get(`${path}/select`, selectPermissions('member'), applicationAssignedControlsController.getSelectedControls);
  router.post(`${path}/select`, selectPermissions('leader'), applicationAssignedControlsController.setSelectedApplicationControls);

  router.get(`${path}/implement`, implementPermissions('member'), applicationAssignedControlsController.getImplementControls);

  router.get(`${path}/audit`, implementPermissions('member'), applicationAssignedControlsController.getAuditControls);

  router.put(`${path}/assessments`, assessmentPermissions('member'), applicationAssignedControlsController.setAssessmentObjectiveStatus);
  router.get(`${path}/assessment-objectives`, assessmentPermissions('member'), applicationAssignedControlsController.getAssessmentObjectivesList);
  router.get(`${path}/assessments`, assessmentPermissions('member'), applicationAssignedControlsController.getAssessmentList);
  router.get(`${path}/:regulationControlId/assessments`, assessmentPermissions('member'), applicationAssignedControlsController.getAssessmentListByControlId);

  router.get(`${path}/:regulationControlId`, applicationAssignedControlsController.getControlByRegulationControlId);

  router.put(`${path}/:regulationControlId`, applicationAssignedControlsController.updateControlByRegulationControlId);

  router.get(`${path}/:regulationControlId/family-controls`, applicationAssignedControlsController.getFamilyControlsByControlRegulationId);
  router.get(`${path}/:regulationControlId/sub-controls`, applicationAssignedControlsController.getSubControlsByControlRegulationId);

}

module.exports = makeRouter;
