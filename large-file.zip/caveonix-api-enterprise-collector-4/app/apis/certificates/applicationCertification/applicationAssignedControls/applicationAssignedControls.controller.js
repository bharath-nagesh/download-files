const logger = require('../../../../../utils/logger').logger.child({
  sub_name: 'IdentityService-certificate.service'
});
const ApplicationAssignedControlsService = require('./applicationAssignedControls.service');
const applicationAssignedControlsService = new ApplicationAssignedControlsService();
const errorHandler = require('../../../../../utils/errorHandler');

module.exports = class ApplicationAssignedControlsController {
  async uploadControls(req, res) {
    const { appCertId } = req.params;
    const userId = req.user.id;
    if (!req.file) {
      const error = new Error('No File Uploaded');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    const controlFile = req.file.buffer;
    try {
      const response = await applicationAssignedControlsService.uploadControls(appCertId, userId, controlFile);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getBaselineControls(req, res) {
    const { appCertId } = req.params;
    try {
      const response = await applicationAssignedControlsService.getApplicationBaselineControls(appCertId);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async generateBaselineControls(req, res) {
    const { appCertId } = req.params;
    const userId = req.user.id;
    try {
      const response = await applicationAssignedControlsService.generateBaselineControls(appCertId, userId);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getSelectedControls(req, res) {
    const { appCertId } = req.params;
    try {
      const response = await applicationAssignedControlsService.getSelectedControls(appCertId);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getImplementControls(req, res) {
    const { appId, certificateId, appCertId } = req.params;
    try {
      const response = await applicationAssignedControlsService.getImplementControls(appCertId);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getAuditControls(req, res) {
    const { appId, certificateId, appCertId } = req.params;
    try {
      const response = await applicationAssignedControlsService.getAuditControls(appCertId);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getControlByRegulationControlId(req, res) {
    const { appId, certificateId, appCertId, regulationControlId } = req.params;
    try {
      const response = await applicationAssignedControlsService.getApplicationControlByRegulationControlId(appCertId, regulationControlId);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async updateControlByRegulationControlId(req, res) {
    const { appId, certificateId, appCertId, regulationControlId } = req.params;
    const params = req.body;
    const userId = req.user.id;
    try {
      const response = await applicationAssignedControlsService.updateApplicationControlByRegulationControlId(appCertId, regulationControlId, userId, params);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async setSelectedApplicationControls(req, res) {
    const { appCertId } = req.params;
    const regulationControls = req.body;
    const { submitted } = req.query;
    const userId = req.user.id;
    try {
      const response = await applicationAssignedControlsService.setSelectedApplicationControls(appCertId, userId, submitted, regulationControls);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getSubControlsByControlRegulationId(req, res) {

    try {
      const { appCertId, regulationControlId } = req.params;
      const response = await applicationAssignedControlsService.getSubControlsByRegulationControlId(appCertId, regulationControlId);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getFamilyControlsByControlRegulationId(req, res) {

    try {
      const { appId, certificateId, appCertId, regulationControlId } = req.params;
      const response = await applicationAssignedControlsService.getFamilyControlsByRegulationControlId(appCertId, appId, certificateId, regulationControlId);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }


  async getArtifactDetailsForApplicationCertification(req, res) {
    const { appCertId } = req.params;
    try {
      const response = await applicationAssignedControlsService.getArtifactDetailsForCertification(appCertId);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async setApprovalStatus(req, res) {
    const { appCertId } = req.params;
    const regulationControls = req.body;
    try {
      const response = await applicationAssignedControlsService.setStatus(appCertId, 'approvalStatus', regulationControls);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async setAssessmentStatus(req, res) {
    const { appCertId } = req.params;
    const regulationControls = req.body;
    try {
      const response = await applicationAssignedControlsService.setStatus(appCertId, 'assessmentStatus', regulationControls);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async setImplementationAssignedUsers(req, res) {
    const { appCertId, userId } = req.params;
    const regulationControlIds = req.body;
    try {
      const response = await applicationAssignedControlsService.assignControlToUser(appCertId, userId, 'implementation', regulationControlIds);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async setAssessmentAssignedUsers(req, res) {
    const { appCertId, userId } = req.params;
    const regulationControlIds = req.body;
    try {
      const response = await applicationAssignedControlsService.assignControlToUser(appCertId, userId, 'assessment', regulationControlIds);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async setAuditAssignedUsers(req, res) {
    const { appCertId, userId } = req.params;
    const regulationControlIds = req.body;
    try {
      const response = await applicationAssignedControlsService.assignControlToUser(appCertId, userId, 'audit', regulationControlIds);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async setAssessmentObjectiveStatus(req, res) {
    const { appCertId } = req.params;
    const userId = req.user.id;
    const assessmentControls = req.body;
    try {
      const response = await applicationAssignedControlsService.setAssessmentObjectiveStatus(userId, appCertId, assessmentControls);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getAssessmentListByControlId(req, res) {
    const { regulationControlId, appCertId } = req.params;
    try {
      const response = await applicationAssignedControlsService.getAssessmentListForControl(appCertId, regulationControlId);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getAssessmentList(req, res) {
    const { appCertId } = req.params;
    try {
      const response = await applicationAssignedControlsService.getAssessmentList(appCertId, false);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getAssessmentObjectivesList(req, res) {
    const { appCertId } = req.params;
    try {
      const response = await applicationAssignedControlsService.getAssessmentList(appCertId);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async setImplementationStatus(req, res) {
    const { appCertId } = req.params;
    const regulationControls = req.body;
    try {
      const response = await applicationAssignedControlsService.setStatus(appCertId, 'implementationStatus', regulationControls);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }
};
