const Sequelize = require('sequelize');

class AppCertificateControlMembers extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
        id: {
          type: Sequelize.INTEGER,
          primaryKey: true,
          autoIncrement: true
        },
        controlId: { type: Sequelize.STRING, field: 'control_id' },
        implementationStatus: {
          type: Sequelize.ENUM('In Place', 'Planned', 'Not Applicable', 'Pending'),
          field: 'implementation_status',
          set: function (val) {
            this.setDataValue('implementationStatus', val);
            const status = this.implementationWorkStatus === 'Completed' ? 'Completed' : 'In Process';
            this.setDataValue('implementationWorkStatus', status);
          },
          defaultValue: ''
        },
        notes: { type: Sequelize.TEXT, field: 'notes' },
        attachmentName: { type: Sequelize.STRING, field: 'attachment_name' },
        attachmentType: { type: Sequelize.STRING, field: 'attachment_type' },
        attachment: { type: Sequelize.BLOB, field: 'attachment' },
        baseline: { type: Sequelize.BOOLEAN, field: 'baseline' },
        selected: {
          type: Sequelize.VIRTUAL,
          get() {
            return this.isActive === 'true';
          }
        },
        tailored: { type: Sequelize.STRING, field: 'tailored', defaultValue: '' },
        type: { type: Sequelize.STRING, field: 'type' },
        tags: { type: Sequelize.STRING, field: 'tags' },
        complianceStatus: {
          type: Sequelize.ENUM('Compliant', 'Non-Compliant', 'Not Applicable', 'Pending'),
          field: 'audit_compliance_status',
          set: function (val) {
            this.setDataValue('complianceStatus', val);
            const status = this.auditWorkStatus === 'Completed' ? 'Completed' : 'In Process';
            this.setDataValue('auditWorkStatus', status);
          }
        },
        auditStatusDate: { type: Sequelize.DATE, field: 'audit_compliance_status_dt' },
        auditComments: { type: Sequelize.STRING, field: 'audit_compliance_comments' },
        implementationDetailComments: { type: Sequelize.STRING, field: 'implementation_detail_comments' },
        approvalStatus: {
          type: Sequelize.ENUM('Approve', 'Reject', 'Review', 'Pending'),
          field: 'approval_status',
          defaultValue: 'Pending',
          set: function (val) {
            this.setDataValue('approvalStatus', val);
            const status = val === 'Approve' ? 'Completed' : 'In Process';
            this.setDataValue('approvalWorkStatus', status);
          }
        },
        approvalStatusDate: { type: Sequelize.DATE, field: 'approval_status_dt' },
        estimatedCompletionDate: { type: Sequelize.DATE, field: 'estimated_completion_dt' },
        actualCompletionDate: { type: Sequelize.DATE, field: 'actual_completion_dt' },
        implementationStatusLock: {
          type: Sequelize.ENUM('Approve', 'Reject', 'Review', 'Pending'),
          field: 'implementation_lock'
        },
        auditStatusLock: {
          type: Sequelize.ENUM('Approve', 'Reject', 'Review', 'Pending'),
          field: 'audit_lock'
        },
        approvalStatusLock: {
          type: Sequelize.ENUM('Approve', 'Reject', 'Review', 'Pending'),
          field: 'approval_lock'
        },
        implementationWorkStatus: {
          type: Sequelize.ENUM('Completed', 'In Progress', 'Pending'),
          field: 'implementation_work_status',
          defaultValue: 'Pending'
        },
        auditWorkStatus: {
          type: Sequelize.ENUM('Completed', 'In Progress', 'Pending'),
          defaultValue: 'Pending',
          field: 'audit_review_work_status'
        },
        assessmentWorkStatus: {
          type: Sequelize.ENUM('Completed', 'In Progress', 'Pending'),
          defaultValue: 'Pending',
          field: 'assessment_work_status'
        },
        assessmentStatusLock: {
          type: Sequelize.ENUM('Approve', 'Reject', 'Review', 'Pending'),
          field: 'assessment_lock'
        },
        isActive: { type: Sequelize.STRING, field: 'is_active', defaultValue: 'enabled' },
      },
      {
        defaultScope: { attributes: { exclude: ['attachment'] }, where: { isActive: { $ne: 'false' } } },
        sequelize,
        timestamps: true,
        freezeTableName: true,
        tableName: 'application_tag_controls_members',
        underscored: true
      });
  }

  static associate(models) {
    AppCertificateControlMembers.belongsTo(models.ApplicationTag, { foreignKey: 'application_id' });
    AppCertificateControlMembers.belongsTo(models.AppCertificateControlMembers, {
      foreignKey: 'common_control_package_id',
      as: 'CCP'
    });
    AppCertificateControlMembers.belongsTo(models.Organization, { foreignKey: 'organization_id' });
    AppCertificateControlMembers.belongsTo(models.Certificates, { foreignKey: 'certificate_id' });
    AppCertificateControlMembers.belongsTo(models.ApplicationCertification, { foreignKey: 'application_certification_id' });
    AppCertificateControlMembers.belongsTo(models.User, { as: 'createdBy', foreignKey: 'created_by' });
    AppCertificateControlMembers.belongsTo(models.User, { as: 'updatedBy', foreignKey: 'updated_by' });
    AppCertificateControlMembers.belongsToMany(models.Artifact, {
      through: 'application_tag_control_artifact_members',
      foreignKey: 'application_tag_controls_member_id',
      timestamps: false
    });
    AppCertificateControlMembers.belongsTo(models.User, {
      as: 'ImplementationAssignedUser',
      foreignKey: 'implementation_user_id'
    });
    AppCertificateControlMembers.belongsTo(models.User, {
      as: 'AuditAssignedUser',
      foreignKey: 'audit_user_id'
    });
    AppCertificateControlMembers.belongsTo(models.User, {
      as: 'AssessmentAssignedUser',
      foreignKey: 'assessment_user_id'
    });

  }
}

module.exports = AppCertificateControlMembers;
