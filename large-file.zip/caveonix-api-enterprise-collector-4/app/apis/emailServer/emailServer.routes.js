const EmailServerController = require('./emailServer.controller');

/**
 * @swagger
 * tags:
 *  - name: EmailServer
 *    description: Email Server endpoints
 */
module.exports = class EmailServerRoutes {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.emailServerController = new EmailServerController();

      // initializing route
      if (type === 'Service Provider') {
        this.initServiceProvider();
      } else {
        this.initOrganization();
      }
    }
  }

  initOrganization() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/emailServer:
     *   get:
     *     tags:
     *       - EmailServer
     *     summary: Gets a list of organization emailServers
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of emailServers
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/`, this.emailServerController.getAllOrgEmailConfiguration);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/emailServer/{emailServerId}:
     *   get:
     *     tags:
     *       - EmailServer
     *     summary: Gets a emailServer by it's id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: emailServerId
     *         description: The id of the specified emailServer.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: emailServer
     */
    this.router.get(`${this.path}/:emailServerId`, this.emailServerController.getOrgEmailConfiguration);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/emailServer:
     *   post:
     *     tags:
     *       - EmailServer
     *     summary: Creates a emailServer
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: emailServerId
     *         description: The id of the specified emailServer.
     *         in: path
     *         required: true
     *         type: string
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/EmailServer'
     *     responses:
     *       200:
     *         description: emailServer
     */
    this.router.post(`${this.path}/`, this.emailServerController.addOrgEmailConfigurationId);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/emailServer/{emailServerId}:
     *   put:
     *     tags:
     *       - EmailServer
     *     summary: Updates a emailServer
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: emailServerId
     *         description: The id of the specified emailServer.
     *         in: path
     *         required: true
     *         type: string
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/EmailServer'
     *     responses:
     *       200:
     *         description: emailServer
     */
    this.router.put(`${this.path}/:emailServerId`, this.emailServerController.updateEmailConfiguration);
    this.router.delete(`${this.path}`, this.emailServerController.deleteMultipleOrgEmailConfigurationId);
    this.router.post(`${this.path}/testConnection`, this.emailServerController.testSMTPConnection);
  }

  initServiceProvider() {}
};
