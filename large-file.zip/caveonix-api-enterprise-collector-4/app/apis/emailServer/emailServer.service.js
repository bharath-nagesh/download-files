const EmailConfiguration = require('./emailConfiguration.model');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-emailServer.service'
});
const Organization = require('../organization/organization.model');
const OrgService = require('../organization/org.service');
const orgService = new OrgService();
const Poc = require('../poc/poc.model');
const nodemailer = require('nodemailer');
const dns = require('dns');
const KeyGenerator = require('../../../utils/generateKeys');
const sequelize = require('../../../config/db.conf').getConnection();

module.exports = class EmailServerService {
  constructor() {
    logger.debug('called EmailServerService constructor');
    this.keyGenerator = new KeyGenerator();
  }

  getEmailConfiguration(emailConfigurationId, opts) {
    return EmailConfiguration.findByPk(emailConfigurationId,
      { include: [{ model: Organization }] });
  }

  async updateEmailConfiguration(orgId, emailConfigurationId, update) {
    const userName = update.userName;
    const serviceName = update.serviceName;
    const organizationId = update.organization_id;
    const authRequired = update.authRequired;
    const priority = update.priority;
    if (authRequired === 'false' || authRequired === false) {
      update.userName = '';
      update.password = '';
      update.password_type = '';
    }
    const exists = await this.checkUserNameHostPortForUpdate(authRequired, userName, organizationId, priority, emailConfigurationId);
    if (exists) {
      const err = new Error('Duplicate Username and Priority.');
      err.status = 400;
      throw err;
    }
    const existstatus = await this.checkServiceNameOrgForUpdate(serviceName, organizationId, emailConfigurationId);
    if (existstatus) {
      const err = new Error('Duplicate Service name.');
      err.status = 400;
      throw err;
    }
    if (update.password) {
      update.password = await this.keyGenerator.generateKeys(update.password);
    }
    await EmailConfiguration.update(update, { where: { id: emailConfigurationId } });
    return EmailConfiguration.findByPk(emailConfigurationId, { include: [{ model: Organization }] });
  }

  async create(orgId, params) {
    const userName = params.userName;
    const serviceName = params.serviceName;
    const organizationId = params.organization_id;
    const authRequired = params.authRequired;
    const priority = params.priority;
    if (authRequired === 'false' || authRequired === false) {
      params.userName = '';
      params.password = '';
      params.password_type = '';
    }
    const exists = await this.checkUserNameHostPort(authRequired, userName, organizationId, priority);
    if (exists) {
      const err = new Error('Duplicate Username and Priority.');
      err.status = 400;
      throw err;
    }
    const existstatus = await this.checkServiceNameOrg(serviceName, organizationId);
    if (existstatus) {
      const err = new Error('Duplicate Service name.');
      err.status = 400;
      throw err;
    }
    if (params.password) {
      params.password = await this.keyGenerator.generateKeys(params.password);
    }
    const result = await EmailConfiguration.create(params);
    return EmailConfiguration.findOne({ where: { id: result.id }, include: [{ model: Organization }] });
  }

  checkUserNameHostPort(authRequired, userName, orgId, priority) {
    if (authRequired === 'false' || authRequired === false) {
      return EmailConfiguration.findOne({
        where: {
          priority: { $eq: priority },
          organization_id: { $eq: orgId },
          $or: [{ isActive: { $ne: 'false' } }]
        }
      });
    } else {
      return EmailConfiguration.findOne({
        where: {
          userName: sequelize.where(sequelize.fn('LOWER', sequelize.col('user_name')),
            sequelize.fn('lower', userName)),
          priority: { $eq: priority },
          organization_id: { $eq: orgId },
          $or: [{ isActive: { $ne: 'false' } }]
        }
      });
    }
  }

  checkServiceNameOrg(serviceName, orgId) {
    return EmailConfiguration.findOne({
      where: {
        service_name: sequelize.where(sequelize.fn('LOWER', sequelize.col('service_name')),
          sequelize.fn('lower', serviceName)),
        $or: [{ isActive: { $ne: 'false' } }],
        organization_id: { $eq: orgId }
      }
    });
  }

  checkUserNameHostPortForUpdate(authRequired, userName, orgId, priority, emailConfigurationId) {
    if (authRequired === 'false' || authRequired === false) {
      return EmailConfiguration.findOne({
        where: {
          priority: { $eq: priority },
          organization_id: { $eq: orgId },
          $or: [{ isActive: { $ne: 'false' } }],
          id: { $ne: emailConfigurationId }
        }
      });
    } else {
      return EmailConfiguration.findOne({
        where: {
          userName: sequelize.where(sequelize.fn('LOWER', sequelize.col('user_name')),
            sequelize.fn('lower', userName)),
          priority: { $eq: priority },
          organization_id: { $eq: orgId },
          $or: [{ isActive: { $ne: 'false' } }],
          id: { $ne: emailConfigurationId }
        }
      });
    }
  }

  checkServiceNameOrgForUpdate(serviceName, orgId, emailConfigurationId) {
    return EmailConfiguration.findOne({
      where: {
        service_name: sequelize.where(sequelize.fn('LOWER', sequelize.col('service_name')),
          sequelize.fn('lower', serviceName)),
        $or: [{ isActive: { $ne: 'false' } }],
        organization_id: { $eq: orgId },
        id: { $ne: emailConfigurationId }
      }
    });
  }

  async deleteMultipleEmailConfiguration(emailConfigurationArr) {
    await EmailConfiguration.update({ isActive: false }, { where: { id: { $in: emailConfigurationArr } } });
    return EmailConfiguration.findAll({
      where: { id: { $in: emailConfigurationArr } },
      include: [{ model: Organization }]
    });
  }

  async getAllEmailConfiguration(orgId, limit, offset) {
    const type = 'sub-organization';
    const orgList = await orgService.getProvider_SubOrg_SubOrgChain(orgId, type);
    const orgArr = orgList.map((object) => {
      return object.id;
    });
    return EmailConfiguration.findAll({
      where: { organization_id: { $in: orgArr }, $or: [{ is_active: { $ne: 'false' } }] },
      include: [{ model: Organization }],
      order: [['id', 'ASC']],
      limit: limit,
      offset: offset
    });
  }

  async getAllEmailConfigurationCount(orgId) {
    const type = 'sub-organization';
    const orgList = await orgService.getProvider_SubOrg_SubOrgChain(orgId, type);
    const orgArr = orgList.map((object) => {
      return object.id;
    });
    return EmailConfiguration.count({
      where: { organization_id: { $in: orgArr }, $or: [{ is_active: { $ne: 'false' } }] }
    });
  }

  async sendEmail(orgId, fileName, subject, text, attachment = null, email = null) {
    const errObj = [];
    const senderInfos = await EmailConfiguration.findAll(
      { where: { organization_id: orgId, isActive: { $ne: 'false' } } });
    // create reusable transporter object using the default SMTP transport
    const transports = await Promise.all(senderInfos.map(async senderInfo => {
      let xAuth;
      logger.silly({ senderInfo }, 'senderInfo');
      senderInfo.password = await this.keyGenerator.decryptKeys(senderInfo.password);
      if (senderInfo.userName && senderInfo.password) {
        xAuth = {
          user: senderInfo.userName,
          pass: senderInfo.password
        };
      }
      const transporter = nodemailer.createTransport({
        service: senderInfo.serviceName,
        host: senderInfo.smtpHostName,
        port: senderInfo.smtpPort,
        auth: xAuth,
        logger: true,
        tls: {
          rejectUnauthorized: false
        }
      });
      return { transporter, from: senderInfo.emailAddress };
    }));

    const org = await Organization.findByPk(orgId);
    if (!org) {
      const error = new Error('no org found with id');
      error.status = 400;
      throw error;
    }
    let emails = Array.isArray(email) ? email : [email];
    if (!email) {
      const POCs = await Poc.findAll({ where: { organization_id: orgId } });
      emails = POCs.map(poc => poc.email);
      logger.silly({ emails }, 'emails');
    }
    // Check atleast one email domain is valid.
    for (let i = 0; i < emails.length; i++) {
      const domain = emails[i].split('@');
      const promise = await new Promise(function (resolve, reject) {
        dns.resolve(domain[1], 'MX', function (err, addresses) {
          if (err) {
            resolve(null);
          } else {
            resolve(true);
          }
        });
      });
      if (!promise) errObj.push({ email: emails[i], error: 'Invalid Email Address' });
    }
    if (errObj.length == emails.length) {
      const error = new Error('Invalid Email Address');
      error.status = 400;
      logger.error({ error }, 'error occurred');
      throw error;
    }
    const attachments = attachment ? [{ filename: `${fileName}.zip`, content: attachment }] : null;
    // setup email data with unicode symbols
    for (let i = 0; i < transports.length; i++) {
      const mailOptions = {
        from: transports[i].from, // sender address
        to: emails.join(','), // list of receivers
        subject, // Subject line
        text, // plain text body
        attachments
      };
      // send mail with defined transport object
      try {
        await transports[i].transporter.verify();
        await transports[i].transporter.sendMail(mailOptions);
        return 'success';
      } catch (e) {
        logger.error({ e, stack: e.stack, from: transports[i].from }, 'error occurred');
        continue;
      }
    }
    const error = new Error('Failed to send email. Contact your email administrator');
    error.status = 400;
    logger.error({ error }, 'error occurred');

    throw error;
  }

  async testSMTPConnection(smtpHostName, smtpPort, userName, password) {
    let auth = '';
    if (userName && password) auth = { user: userName, pass: password };
    const transporter = await nodemailer.createTransport({
      host: smtpHostName,
      port: smtpPort,
      secure: false,
      auth,
      authMethod: 'LOGIN',
      logger: true,
      tls: {
        rejectUnauthorized: false
      }
    });
    try {
      const response = await transporter.verify();
      if (response) {
        logger.debug({ smtpHostName }, 'connection successful');
        return true;
      }
      return false;
    } catch (error) {
      error.status = 400;
      logger.error({ error, stack: error.stack }, 'error occurred connecting to smtp server');
      throw error;

    }
  }
};
