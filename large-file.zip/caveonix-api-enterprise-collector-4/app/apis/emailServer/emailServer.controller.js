const checkId = require('../../../utils/checkId');
const EmailService = require('./emailServer.service');
const errorHandler = require('../../../utils/errorHandler');
const Validator = require('../../../utils/validator');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-emailServer.controller'
});
const paginate = require('../../middlewares/paginate.middleware');
const emailServerService = new EmailService();

module.exports = class EmailServerController {
  async getAllOrgEmailConfiguration(req, res) {
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    const orgId = req.params.orgId;
    try {
      const results = await emailServerService.getAllEmailConfiguration(orgId, limit, offset);
      const itemCount = await emailServerService.getAllEmailConfigurationCount(orgId);
      const pageCount = Math.ceil(itemCount / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        poc: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getOrgEmailConfiguration(req, res) {
    const emailServerId = req.params.emailServerId;
    if (checkId(emailServerId)) {
      logger.error({ emailServerId }, 'Bad emailConfiguration Id');
      const error = new Error('Bad emailConfiguration Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const emailConfiguration = await emailServerService.getEmailConfiguration(emailServerId);
      return res.json(emailConfiguration);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async addOrgEmailConfigurationId(req, res) {
    const params = req.body;
    try {
      params.smtpPort = params.smtpPort ? params.smtpPort.toString().trim() : null;
      params.isActive = params.isActive ? params.isActive.toString().toLowerCase() : 'enabled';
      await Validator.validateParams({
        serviceName: 'required|string',
        smtpHostName: 'required|string',
        smtpPort: 'required|integer',
        authRequired: 'required|string',
        password_type: 'nullable',
        userName: 'nullable',
        password: 'nullable',
        priority: 'required|integer',
        sslEnabled: 'required|boolean',
        organization_id: 'required|integer',
        emailAddress: 'required|email',
        isActive: 'required|in:enabled,disabled,true'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const orgId = req.params.orgId;
    try {
      const emailServer = await emailServerService.create(orgId, params);
      return res.json(emailServer);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async updateEmailConfiguration(req, res) {
    const params = req.body;
    try {
      params.smtpPort = params.smtpPort ? params.smtpPort.toString().trim() : null;
      params.isActive = params.isActive ? params.isActive.toString().toLowerCase() : null;
      await Validator.validateParams({
        serviceName: 'required|string',
        smtpHostName: 'required|string',
        smtpPort: 'required|integer',
        authRequired: 'required|string',
        password_type: 'nullable',
        userName: 'nullable',
        password: 'nullable',
        priority: 'required|integer',
        sslEnabled: 'required|boolean',
        organization_id: 'required|integer',
        emailAddress: 'required|email',
        isActive: 'required|in:enabled,disabled'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const orgId = req.params.orgId;
    const emailServerId = req.params.emailServerId;
    try {
      const emailServerService = new EmailService();
      const emailServer = await emailServerService.updateEmailConfiguration(orgId, emailServerId, params);
      return res.json(emailServer);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async testSMTPConnection(req, res) {
    const params = req.body;
    const smtpHostName = params.smtpHostName;
    const smtpPort = params.smtpPort;
    let userName = params.userName;
    let password = params.password;

    if (!smtpHostName || !smtpPort) {
      logger.info('Please enter valid HostName / Port.');
      const err = new Error('Please enter valid HostName / Port.');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    if (!userName || !password) {
      userName = '';
      password = '';
    }
    try {
      const success = await emailServerService.testSMTPConnection(smtpHostName, smtpPort, userName, password);
      return res.json({ success });
    } catch (e) {
      return errorHandler(req, res, e);
    }
  }

  async deleteMultipleOrgEmailConfigurationId(req, res) {
    const emailServerId = req.query.id || '';
    const emailServerIdArr = emailServerId.split(',');
    try {
      const emailServerService = new EmailService();
      const emailServer = await emailServerService.deleteMultipleEmailConfiguration(emailServerIdArr);
      logger.info('Deleted Email Server');
      return res.json(emailServer);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }
};
