const Sequelize = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();
const Organization = require('../organization/organization.model');
/**
 * @swagger
 * components:
 *   schemas:
 *     EmailServer:
 *       type: object
 *       required:
 *         - name
 *         - isActive
 *       properties:
 *         serviceName:
 *           type: string
 *         smtpHostName:
 *           type: string
 *         smtpPort:
 *           type: integer
 *         authRequired:
 *           type: string
 *         password_type:
 *           type: string
 *         priority:
 *           type: integer
 *         sslEnabled:
 *           type: integer
 *         organization_id:
 *           type: string
 *         emailAddress:
 *           type: string
 *         isActive:
 *           type: string
 * @param sequelize
 */
const EmailConfiguration = sequelize.define(
  'emailConfiguration',
  {
    serviceName: {
      type: Sequelize.STRING,
      field: 'service_name'
    },
    smtpHostName: {
      type: Sequelize.STRING,
      field: 'smtp__host_name'
    },
    smtpPort: {
      type: Sequelize.INTEGER,
      field: 'smtp_port'
    },
    userName: {
      type: Sequelize.STRING,
      field: 'user_name'
    },
    password: {
      type: Sequelize.STRING,
      field: 'password'
    },
    authRequired: {
      type: Sequelize.STRING,
      field: 'auth_required'
    },
    password_type: {
      type: Sequelize.STRING,
      field: 'password_type'
    },
    priority: {
      type: Sequelize.INTEGER,
      field: 'priority'
    },
    sslEnabled: {
      type: Sequelize.INTEGER,
      field: 'ssl_enabled'
    },
    organization_id: {
      type: Sequelize.STRING,
      field: 'organization_id'
    },
    emailAddress: {
      type: Sequelize.STRING,
      field: 'email_address'
    },
    isActive: {
      type: Sequelize.STRING,
      field: 'is_active'
    },
    is_active: {
      type: Sequelize.STRING,
      field: 'is_active'
    }
  },
  {
    timestamps: true,
    freezeTableName: true,
    tableName: 'email_configurations',
    underscored: true,
    sequelize
  }
);

EmailConfiguration.associate = (models) => {
  EmailConfiguration.belongsTo(Organization, { foreignKey: 'organization_id' });
};

module.exports = EmailConfiguration;
