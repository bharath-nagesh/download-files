const AssetService = require('./asset.service');
const assetService = new AssetService();
const checkId = require('../../../utils/checkId');
const errorHandler = require('../../../utils/errorHandler');
const Validator = require('../../../utils/validator');
const isipaddresscheck = require('../../../utils/isipaddresscheck');
const OrgService = require('../organization/org.service');
const orgService = new OrgService();
const CentralCollectorClient = require('../../../utils/centralCollector.client');
const paginate = require('../../middlewares/paginate.middleware');
const SubApplicationService = require('../subApplication/subApplication.service');
const policyGroupService = new SubApplicationService();
const CheckIp = require('../../../utils/checkIp');
const { get } = require('lodash');

const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-asset.controller'
});

module.exports = class AssetController {
  async createAsset(req, res) {
    const orgId = req.params.orgId;
    const params = req.body;
    try {
      const asset = await assetService.create(orgId, params);
      return res.json(asset);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async uploadAssets(req, res) {
    const csvFile = req.file ? req.file.buffer.toString() : req.body.file;
    const hostingProviderId = req.body.hostingProviderId || 0;
    const locationId = req.body.locationId || 0;
    const organizationId = req.body.organizationId; // the org that will be owner of assets

    try {
      const assets = await assetService
        .uploadAssets(organizationId, locationId, hostingProviderId, csvFile);

      return res.json(assets);

    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getAssetById(req, res) {
    const assetId = req.params.assetId;
    if (checkId(assetId)) {
      logger.error({ assetId }, 'Error with Asset Id');
      const error = new Error(`Invalid Asset Id: ${assetId}`);
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const asset = await assetService.getAsset(assetId);
      if (!asset) {
        const e = new Error('Asset Not Found');
        return errorHandler(req, res, e);
      }
      return res.json(asset);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getAssetByVmId(req, res) {
    const vmId = req.params.vmId;
    logger.info({ vmId }, 'vmId');
    try {
      const asset = await assetService.getAssetByVmId(vmId);
      if (!asset) {
        return res.sendStatus(404);
      }
      return res.json(asset);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getAssetDistinctDetails(req, res) {
    const orgId = get(req, 'params.orgId');
    const assetRepoId = get(req, 'query.assetRepoId', 0);
    const attributes = Array.isArray(get(req, 'query.attributes')) ? get(req, 'query.attributes') : [get(req, 'query.attributes')];
    const modelAttributes = [];

    if (attributes.includes('dataCenterName')) {
      modelAttributes.push(['datacenter_name', 'dataCenterName']);
    }
    if (attributes.includes('folderName')) {
      modelAttributes.push(['vm_folder_name', 'folderName']);
    }
    if (attributes.includes('resourcePool')) {
      modelAttributes.push(['resource_pool', 'resourcePool']);
    }
    try {
      const results = await assetService.getAssetDistinctDetails(orgId, modelAttributes, assetRepoId);
      return res.json(results);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getAssetsForOrg(req, res) {
    const orgId = req.params.orgId;
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    try {
      const results = await assetService.getAllAsset(orgId, limit, offset);
      const itemCount = await assetService.getAssetCountForOrg(orgId);
      const pageCount = Math.ceil(itemCount / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        assets: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getAssetForApplication(req, res) {
    const policyGroupId = req.params.policyGroupId;
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    try {
      const results = await assetService.getAssetForApplication(policyGroupId, limit, offset);
      const itemCount = await assetService.getAssetForApplicationCount(policyGroupId);
      const pageCount = Math.ceil(itemCount / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        assets: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async bulkCreateAssets(req, res) {
    const params = req.body;
    let ipAddressArr = [];
    const finalData = {
      error: [],
      data: []
    };
    try {
      await Validator.validateParams({
        location_id: 'required|integer',
        hosting_provider_id: 'required|integer',
        application_id: 'nullable',
        sub_application_id: 'nullable',
        environment_id: 'integer',
        assets: 'required|array',
        'assets.*.assetName': 'required|string',
        'assets.*.ipAddress': 'required|string',
        'assets.*.operatingSystem': 'required|string',
        'assets.*.organization': 'required|integer'
      }, params);
      params.assets = params.assets.map(element => {
        element.registeredName = element.registeredName ? element.registeredName : element.assetName;
        ipAddressArr = element.ipAddress.split(',');
        ipAddressArr.map(ip => {
          if (!CheckIp.checkIp(ip)) {
            const error = new Error('Invalid IP Address Provided');
            logger.error({ error }, 'error occurred');
            error.status = 422;
            error.message = 'Invalid IP Address Provided';
            return errorHandler(req, res, error);
          }
        });
        return element;
      });
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const userId = req.user.id;
    const token = req.authInfo;
    const assetInfos = req.body.assets;
    const orgId = req.params.orgId;
    const hostingProviderId = req.body.hosting_provider_id;
    let appId = req.body.application_id;
    let subAppId = req.body.sub_application_id;
    const locationId = req.body.location_id;
    const environmentId = req.body.environment_id;
    if (!subAppId) {
      const subApp = await orgService.getDefaultSubApplication(orgId);
      subAppId = subApp.id;
    }

    if (!appId) {
      const app = await orgService.getDefaultApplication(orgId);
      appId = app.id;
    }

    try {
      const assets = await assetService.bulkCreateAssets(orgId, appId, subAppId, locationId, hostingProviderId, environmentId, userId, token, assetInfos);
      assets.forEach((a, i) => {
        if (a) finalData.data.push(a);
        else finalData.error.push({ message: 'Duplicate Asset', assetName: assetInfos[i].assetName });
      });
      if (finalData.error.length > 0) res.status(207);
      return res.json(finalData);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred in bulk upload');
      return errorHandler(req, res, error);
    }
  }

  async getAssetsByIds(req, res) {
    const orgId = req.params.orgId;
    let ids = req.query.ids;
    if (!Array.isArray(ids)) {
      if (typeof ids === 'string') {
        ids = Array.from(ids.split(','));
      } else {
        ids = Array.from(ids);
      }
    }
    if (!ids || ids.length === 0) {

      ids = null;
    }
    try {
      const assets = await assetService.getAssetsByIds(orgId, ids);
      return res.json(assets);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getAssetListForOrg(req, res) {
    const orgId = req.params.orgId;
    const limit = res.locals.paginate.limit;
    const pageNumber = res.locals.paginate.page;
    const managed = req.query.managed;
    const dropdown = req.query.dropdown || false;
    let assetSource = req.query.asset_source || [];
    if (typeof assetSource === 'string') {
      assetSource = [assetSource];
    }

    try {
      const results = await assetService.getAllAssetList(orgId, managed, dropdown, assetSource);
      if (results) {
        results.map(result => {
          const myRegexp = /([a-zA-Z0-9/(]{9}-[a-zA-Z0-9]{4}-[a-zA-Z0-9]{4}-[a-zA-Z0-9]{4}-[a-zA-Z0-9/)]{13})/g;

          let nameRegexpOut;
          const nameString = result.name;
          if (nameString) {
            nameRegexpOut = nameString.match(myRegexp);
          }
          if (nameRegexpOut) {
            result.name = nameString.replace(nameRegexpOut[0], '');
          }

          let realmRegexpOut;
          const realmString = result.realm;
          if (realmString) {
            realmRegexpOut = realmString.match(myRegexp);
          }
          if (realmRegexpOut) {
            result.realm = realmString.replace(realmRegexpOut[0], '');
          }
        });
      }
      const PCount = results.length;
      const pageCount = Math.ceil(PCount / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: PCount,
        page_number: pageNumber,
        assets: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error('Error occurred while attempting to retrieve asset list for org', { error });
      return errorHandler(req, res, error);
    }
  }

  // Copied block from getAssetListForOrg
  async getAssetList(req, res) {
    const orgId = req.params.orgId;
    const limit = res.locals.paginate.limit;
    const pageNumber = res.locals.paginate.page;
    const managed = req.query.managed;

    try {
      const results = await assetService.getAssetList(orgId, managed);
      if (results) {
        results.map(d => {
          const myRegexp = /([a-zA-Z0-9/(]{9}-[a-zA-Z0-9]{4}-[a-zA-Z0-9]{4}-[a-zA-Z0-9]{4}-[a-zA-Z0-9/)]{13})/g;
          const nameString = d.name;
          const realmString = d.realm;
          if (nameString) {
            var nameRegexpOut = nameString.match(myRegexp);
          }
          if (realmString) {
            var realmRegexpOut = realmString.match(myRegexp);
          }
          if (nameRegexpOut) {
            d.name = nameString.replace(nameRegexpOut[0], '');
          }
          if (realmRegexpOut) {
            d.realm = realmString.replace(realmRegexpOut[0], '');
          }
        });
      }
      const PCount = results.length;
      const pageCount = Math.ceil(PCount / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: PCount,
        page_number: pageNumber,
        assets: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getAssets(req, res) {
    const orgId = req.params.orgId;
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    let assetList = req.query.assetList;
    if (!assetList) {
      assetList = 'true';
    }
    try {
      const results = await assetService.getAssets(assetList, orgId, limit, offset);
      const itemCount = await assetService.getAssetsCount(assetList, orgId);
      const PCount = itemCount[0].count;
      const pageCount = Math.ceil(PCount / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: PCount,
        page_number: pageNumber,
        assets: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async addAssetToOrg(req, res) {
    const orgId = req.params.orgId;
    const assetId = req.params.assetId;
    if (checkId(assetId)) {
      logger.error({ assetId }, 'Error with Asset Id');
      const error = new Error('Error with Asset Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const asset = await assetService.addAssetToOrg(orgId, assetId);
      return res.status(201).json(asset);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async updateAsset(req, res) {
    const assetId = req.params.assetId;
    const update = req.body;
    if (checkId(assetId)) {
      logger.error({ assetId }, 'Error with Asset Id');
      const error = new Error('Error with Asset Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const asset = await assetService.updateAssetById(assetId, update);
      return res.json(asset);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async changeAssetOrganization(req, res) {
    const orgId = req.params.orgId;
    const update = req.body;
    const assets = update.assets;
    const userId = req.user.id;
    const token = req.authInfo;
    try {
      const asset = await assetService.changeAssetOrganization(assets, update, orgId, userId, token);
      return res.json(asset);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async changeAssetLocation(req, res) {
    const update = req.body;
    const assets = update.assets;
    try {
      const asset = await assetService.changeAssetLocation(assets, update);
      return res.json(asset);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async changeAssetEnvironment(req, res) {
    const update = req.body;
    const assets = update.assets;
    const assetArr = assets.split(',');
    try {
      const asset = await assetService.changeAssetEnvironment(assets, update);
      if (asset) {
        const updatedAsset = await assetService.getAssetByArray(assetArr);
        return res.json(updatedAsset);
      }
      return res.json(asset);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async deleteAssetbyId(req, res) {
    const assetId = req.params.assetId;
    const orgId = req.params.orgId;
    if (checkId(assetId)) {
      logger.error({ assetId }, 'Error with Asset Id');
      const error = new Error('Error with Asset Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const update = await assetService.deleteById(assetId, orgId);
      logger.info({ update, assetId }, 'deleted');
      return res.json(update);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async deleteMultipleAssets(req, res) {
    const assetIdList = req.query.id.split(',');
    const orgId = req.params.orgId;
    try {
      const update = await assetService.deleteMultipleAssets(assetIdList, orgId);
      logger.info({ update }, 'deleted');
      return res.json(update);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getAssetDetail(req, res) {
    const assetId = req.params.assetId;
    if (checkId(assetId)) {
      logger.error({ assetId }, 'Error with Asset Id');
      const error = new Error('Error with Asset Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const assetDetail = await assetService.getAssetDetail(assetId);
      if (!assetDetail) {
        logger.error({ assetId }, 'No Asset details for that Asset Id');
        return res.sendStatus(404);
      }
      return res.json(assetDetail);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async createAssetDetail(req, res) {
    const assetId = req.params.assetId;
    const params = req.body;
    if (checkId(assetId)) {
      logger.error({ assetId }, 'Error with Asset Id');
      const error = new Error('Error with Asset Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const assetDetail = await assetService.createAssetDetail(assetId, params);
      return res.json(assetDetail);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getAssetNetwork(req, res) {
    const assetId = req.params.assetId;
    if (checkId(assetId)) {
      logger.error({ assetId }, 'Error with Asset Id');
      const error = new Error('Error with Asset Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const assetNetwork = await assetService.getAssetNetwork(assetId);
      if (!assetNetwork) {
        const error = new Error('No Asset Network for that Asset Id');
        error.status = 404;
        logger.error({ assetId }, 'No Asset Network for that Asset Id');
        return errorHandler(req, res, error);
      }
      return res.json(assetNetwork);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getVMAssetNetwork(req, res) {
    const assetId = req.params.assetId;
    if (checkId(assetId)) {
      logger.error({ assetId }, 'Error with Asset Id');
      const error = new Error('Error with Asset Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const vmAssetNetworks = await assetService.getVMAssetNetwork(assetId);
      if (vmAssetNetworks.length === 0) {
        logger.error({ assetId }, 'No VM Asset Networks for that Asset Id');
      }
      return res.json(vmAssetNetworks);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async createVMAssetNetwork(req, res) {
    const assetId = req.params.assetId;
    const params = req.body;
    if (checkId(assetId)) {
      logger.error({ assetId }, 'Error with Asset Id');
      const error = new Error('Error with Asset Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const assetNetwork = await assetService.createVMAssetNetwork(assetId, params);
      return res.json(assetNetwork);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getPhysicalAssetNetwork(req, res) {
    const assetId = req.params.assetId;
    if (checkId(assetId)) {
      logger.error({ assetId }, 'Error with Asset Id');
      const error = new Error('Error with Asset Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const physicalAssetNetworks = await assetService.getPhysicalAssetNetwork(assetId);
      if (physicalAssetNetworks.length === 0) {
        logger.error({ assetId }, ' No Physical Asset Networks for that Asset Id');
      }
      return res.json(physicalAssetNetworks);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async createPhysicalAssetNetwork(req, res) {
    const assetId = req.params.assetId;
    const params = req.body;
    if (checkId(assetId)) {
      logger.error({ assetId }, 'Error with Asset Id');
      const error = new Error('Error with Asset Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const assetNetwork = await assetService.createAssetNetwork(assetId, params);
      return res.json(assetNetwork);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getAssetCount(req, res) {
    const orgId = req.params.orgId;
    const startDate = req.query.start;
    const endDate = req.query.end;
    try {
      const asset = await assetService.checkAssetCount(orgId, startDate, endDate);
      return res.json(asset);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getAssetByDays(req, res) {
    const orgId = req.params.serviceProviderId;
    const startDate = req.query.start;
    const endDate = req.query.end;
    try {
      const asset = await assetService.checkAssetCountByNoOfDays(orgId, startDate, endDate);
      return res.json(asset);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getTenantLevelRollUp(req, res) {
    const orgId = req.params.serviceProviderId;
    const startDate = req.query.start;
    const endDate = req.query.end;
    try {
      const asset = await assetService.getTenantLevelRollUp(orgId, startDate, endDate);
      return res.json(asset);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async ChangeAssetState(req, res) {
    const update = req.body;
    let assetId = update.asset_id;
    assetId = assetId.split(',');
    const managed = update.managed.toLowerCase();

    if (managed !== 'true' && managed !== 'false') {
      logger.info({ managed }, 'Invalid value for status field');
      const error = new Error('Invalid value for status field');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const asset = await assetService.ChangeAssetState(assetId, update);
      return res.json(asset);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async ChangeNetworkIp(req, res) {
    const update = req.body;
    const assetId = req.params.asset_id;
    const NetworkIp = update.network_ip;
    const ValidIp = isipaddresscheck(NetworkIp);
    if (ValidIp === false) {
      logger.info({ ValidIp }, 'Invalid NetworkIp');
      const error = new Error('Invalid NetworkIp');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const asset = await assetService.ChangeNetworkIp(assetId, update);
      return res.json(asset);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async AssignAssetToSubApp(req, res) {
    const update = req.body;
    const policyGroupId = update.policy_group_id;
    const assets = update.asset_id;
    const userId = req.user.id;
    const userToken = req.authInfo;
    const assetArr = assets.split(',');
    try {
      const result = await policyGroupService.addAssetToSubApplication(policyGroupId, assets, userId, userToken);
      if (result) {
        const updatedAsset = await assetService.getAssetByArray(assetArr);
        return res.json(updatedAsset);
      }
      return res.json(result);
    } catch (e) {
      return errorHandler(req, res, e);
    }
  }

  async AssetDiscovery(req, res) {
    const params = req.body;
    const userToken = req.authInfo;
    const userId = req.user.id;
    params.userId = userId;
    params.userToken = userToken;
    if (!userToken || !userId) {
      logger.info('Invalid parameters For Asset Discovery');
      const err = new Error('Invalid parameters For Asset Discovery');
      err.status = 400;
      return errorHandler(req, res, err);
    }

    try {
      const ccUrl = await CentralCollectorClient.CentralCollectorConnectionCheck();
      if (!ccUrl) {
        const error = new Error('No Central Collector Available. Please Contact your Caveonix Administrator');
        error.status = 400;
        return errorHandler(req, res, error);
      }

      const assetDiscoveryResp = await assetService.startAssetDiscovery(ccUrl, params);

      return res.json(assetDiscoveryResp);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }
};
