const expect = require('chai').expect;
const proxyquire = require('proxyquire').noCallThru();
const httpMocks = require('node-mocks-http');

const SubApplicationService = class SubApplicationService {
  constructor() { }

};

const CentralCollectorClient = class CentralCollectorClient {
  constructor() { }

};

const OrgService = class OrgService {
  constructor() { }

};

describe('AssetController', function () {
  beforeEach(() => {

  });

  describe('createAsset', () => {
    it('createAsset', async () => {
      const orgId = 1;
      const assetData = { data: 1 };

      const assetService = class AssetService {
        constructor() { }

        async create(orgId, params) {
          return assetData;
        }
      };

      const AssetController = proxyquire('./asset.controller', {
        './asset.service': assetService,
        '../../../utils/centralCollector.client': CentralCollectorClient,
        '../organization/org.service': OrgService,
        '../subApplication/subApplication.service': SubApplicationService
      });

      const assetController = new AssetController();
      const req = httpMocks.createRequest({ params: { orgId }, body: { assetData } });
      const res = httpMocks.createResponse();
      const details = await assetController.createAsset(req, res);
      const assetDetails = details._getData();
      expect(JSON.parse(assetDetails)).to.deep.equal(assetData);
    });
  });

  describe('uploadAssets', () => {
    it('uploadAssets', async () => {
      const orgId = 1;
      const assetData = { data: 1 };

      const assetService = class AssetService {
        constructor() { }

        async uploadAssets(organizationId, locationId, hostingProviderId, csvFile) {
          return assetData;
        }
      };

      const AssetController = proxyquire('./asset.controller', {
        './asset.service': assetService,
        '../../../utils/centralCollector.client': CentralCollectorClient,
        '../organization/org.service': OrgService,
        '../subApplication/subApplication.service': SubApplicationService
      });

      const assetController = new AssetController();
      const req = httpMocks.createRequest({ params: { orgId }, body: { file: true, organizationId: orgId } });
      const res = httpMocks.createResponse();
      const details = await assetController.uploadAssets(req, res);
      const assetDetails = details._getData();
      expect(JSON.parse(assetDetails)).to.deep.equal(assetData);
    });
  });

  describe('getAssetById', () => {
    it('getAssetById', async () => {
      const assetId = 1;
      const assetData = { data: 1 };

      const assetService = class AssetService {
        constructor() { }

        async getAsset(assetId) {
          return assetData;
        }
      };

      const AssetController = proxyquire('./asset.controller', {
        './asset.service': assetService,
        '../../../utils/centralCollector.client': CentralCollectorClient,
        '../organization/org.service': OrgService,
        '../subApplication/subApplication.service': SubApplicationService
      });

      const assetController = new AssetController();
      const req = httpMocks.createRequest({ params: { assetId } });
      const res = httpMocks.createResponse();
      const details = await assetController.getAssetById(req, res);
      const assetDetails = details._getData();
      expect(JSON.parse(assetDetails)).to.deep.equal(assetData);
    });
  });

  describe('getAssetByVmId', () => {
    it('getAssetByVmId', async () => {
      const vmId = 1;
      const assetData = { data: 1 };

      const assetService = class AssetService {
        constructor() { }

        async getAsset(vmId) {
          return assetData;
        }
      };

      const AssetController = proxyquire('./asset.controller', {
        './asset.service': assetService,
        '../../../utils/centralCollector.client': CentralCollectorClient,
        '../organization/org.service': OrgService,
        '../subApplication/subApplication.service': SubApplicationService
      });

      const assetController = new AssetController();
      const req = httpMocks.createRequest({ params: { vmId } });
      const res = httpMocks.createResponse();
      const details = await assetController.getAssetByVmId(req, res);
      const assetDetails = details._getData();
      expect(assetDetails).to.deep.equal(assetDetails);
    });
  });

  describe('getAssetsForOrg', () => {
    it('getAssetsForOrg', async () => {
      const orgId = 10;
      const limit = 10;
      const offset = 0;
      const page = 1;

      const assetResponse = {
        total_page_count: 1,
        pageLimit: limit,
        total_record_count: 10,
        page_number: page,
        assets: 10,
        pages: [{
          number: 1,
          url: 'null?page=' + page
        }]
      };
      const assetResponseCount = 10;
      const assetService = class AssetService {
        constructor() { }

        getAllAsset() { return Promise.resolve(orgId, limit, offset); }

        getAssetCountForOrg() { return Promise.resolve(assetResponseCount); }
      };

      const AssetController = proxyquire('./asset.controller', {
        './asset.service': assetService,
        '../../../utils/centralCollector.client': CentralCollectorClient,
        '../organization/org.service': OrgService,
        '../subApplication/subApplication.service': SubApplicationService
      });

      const assetController = new AssetController();
      const req = httpMocks.createRequest({ params: { orgId }, query: { page } });
      const res = httpMocks.createResponse({ locals: { paginate: { limit, offset, page } } });
      const details = await assetController.getAssetsForOrg(req, res);
      const assetDetails = details._getData();
      expect(JSON.parse(assetDetails)).to.deep.equal(assetResponse);
    });
  });

  describe('getAssetForApplication', () => {
    it('getAssetForApplication', async () => {
      const orgId = 10;
      const limit = 10;
      const offset = 0;
      const page = 1;
      const policyGroupId = 1;
      const assetResponse = {
        total_page_count: 1,
        pageLimit: limit,
        total_record_count: 10,
        page_number: page,
        assets: 10,
        pages: [{
          number: 1,
          url: 'null?page=' + page
        }]
      };
      const assetResponseCount = 10;
      const assetService = class AssetService {
        constructor() { }

        getAssetForApplication() { return Promise.resolve(orgId, limit, offset); }

        getAssetForApplicationCount() { return Promise.resolve(assetResponseCount); }
      };

      const AssetController = proxyquire('./asset.controller', {
        './asset.service': assetService,
        '../../../utils/centralCollector.client': CentralCollectorClient,
        '../organization/org.service': OrgService,
        '../subApplication/subApplication.service': SubApplicationService
      });

      const assetController = new AssetController();
      const req = httpMocks.createRequest({ params: { policyGroupId }, query: { page } });
      const res = httpMocks.createResponse({ locals: { paginate: { limit, offset, page } } });
      const details = await assetController.getAssetForApplication(req, res);
      const assetDetails = details._getData();
      expect(JSON.parse(assetDetails)).to.deep.equal(assetResponse);
    });
  });

  describe('bulkCreateAssets', () => {
    it('bulkCreateAssets', async () => {
      const assetData = {
        location_id: 1,
        hosting_provider_id: 1,
        application_id: 1,
        sub_application_id: 1,
        environment_id: 1,
        assets: [
          {
            assetName: '1',
            ipAddress: '10.1.1.1',
            operatingSystem: 'os',
            organization: 1
          },
          {
            assetName: '2',
            ipAddress: '10.1.1.1',
            operatingSystem: 'os1',
            organization: 1
          }]
      };
      const ccUrl = '10.1.1.1';
      const subApp = {id:1,name:'subapp'};
      const defApp = {id:1,name:'app'};
      const assetService = class AssetService {
        constructor() { }

        async bulkCreateAssets(orgId, appId, subAppId, locationId, hostingProviderId, environmentId, userId, token, assetInfos) {
          return assetData;
        }
      };

      const OrgService = class OrgService {
        constructor() { }

        async getDefaultSubApplication(orgId) {
          return subApp;
        }

        async getDefaultApplication(orgId) {
          return defApp;
        }
      };

      const CentralCollectorClient = class CentralCollectorClient {
        constructor() { }

        static CentralCollectorConnectionCheck() {
          return ccUrl;
        }
      };

      const AssetController = proxyquire('./asset.controller', {
        './asset.service': assetService,
        '../../../utils/centralCollector.client': CentralCollectorClient,
        '../organization/org.service': OrgService,
        '../subApplication/subApplication.service': SubApplicationService
      });

      const assetController = new AssetController();
      const req = httpMocks.createRequest({ user: { id: 1 }, authInfo: 1, body: assetData });
      const res = httpMocks.createResponse();
      const details = await assetController.bulkCreateAssets(req, res);
      const assetDetails = details._getData();
      expect(JSON.parse(assetDetails)).to.deep.equal(assetData);
    });
  });

  describe('getAssetsByIds', () => {
    it('getAssetsByIds', async () => {
      const ids = [1, 2, 3];
      const assetData = [{ data: 1 }, { data: 2 }, { data: 3 }];
      const orgId = 1;
      const assetService = class AssetService {
        constructor() { }

        async getAssetsByIds(orgId, ids) {
          return assetData;
        }
      };

      const AssetController = proxyquire('./asset.controller', {
        './asset.service': assetService,
        '../../../utils/centralCollector.client': CentralCollectorClient,
        '../organization/org.service': OrgService,
        '../subApplication/subApplication.service': SubApplicationService
      });

      const assetController = new AssetController();
      const req = httpMocks.createRequest({ params: { orgId }, query: { ids } });
      const res = httpMocks.createResponse();
      const details = await assetController.getAssetsByIds(req, res);
      const assetDetails = details._getData();
      expect(assetDetails).to.deep.equal(JSON.stringify(assetData));
    });
  });

  describe('getAssetListForOrg', () => {
    it('getAssetListForOrg', async () => {
      const orgId = 10;
      const limit = 10;
      const offset = 0;
      const page = 1;
      const assetData = [{ data: 1 }, { data: 2 }, { data: 3 }];
      const managed = true;
      const assetResponse = {
        total_page_count: 1,
        pageLimit: limit,
        total_record_count: 3,
        page_number: page,
        assets: assetData,
        pages: [{
          number: 1,
          url: 'null?page=' + page + '&managed=' + managed
        }]
      };

      const assetService = class AssetService {
        constructor() { }

        async getAllAssetList(orgId, ids) {
          return assetData;
        }
      };

      const AssetController = proxyquire('./asset.controller', {
        './asset.service': assetService,
        '../../../utils/centralCollector.client': CentralCollectorClient,
        '../organization/org.service': OrgService,
        '../subApplication/subApplication.service': SubApplicationService
      });

      const assetController = new AssetController();
      const req = httpMocks.createRequest({ params: { orgId }, query: { page, managed } });
      const res = httpMocks.createResponse({ locals: { paginate: { limit, offset, page } } });
      const details = await assetController.getAssetListForOrg(req, res);
      const assetDetails = details._getData();
      expect(JSON.parse(assetDetails)).to.deep.equal(assetResponse);
    });
  });

  describe('getAssetList', () => {
    it('getAssetList', async () => {
      const orgId = 10;
      const limit = 10;
      const offset = 0;
      const page = 1;
      const assetData = [{ data: 1 }, { data: 2 }, { data: 3 }];
      const managed = true;
      const assetResponse = {
        total_page_count: 1,
        pageLimit: limit,
        total_record_count: 3,
        page_number: page,
        assets: assetData,
        pages: [{
          number: 1,
          url: 'null?page=' + page + '&managed=' + managed
        }]
      };

      const assetService = class AssetService {
        constructor() { }

        async getAssetList(orgId, ids) {
          return assetData;
        }
      };

      const AssetController = proxyquire('./asset.controller', {
        './asset.service': assetService,
        '../../../utils/centralCollector.client': CentralCollectorClient,
        '../organization/org.service': OrgService,
        '../subApplication/subApplication.service': SubApplicationService
      });

      const assetController = new AssetController();
      const req = httpMocks.createRequest({ params: { orgId }, query: { page, managed } });
      const res = httpMocks.createResponse({ locals: { paginate: { limit, offset, page } } });
      const details = await assetController.getAssetList(req, res);
      const assetDetails = details._getData();
      expect(JSON.parse(assetDetails)).to.deep.equal(assetResponse);
    });
  });

  describe('getAssets', () => {
    it('getAssets', async () => {
      const orgId = 10;
      const limit = 10;
      const offset = 0;
      const page = 1;
      const assetData = [{ data: 1 }, { data: 2 }, { data: 3 }];
      const assetList = [];
      assetResponseCount = [{ count: 3 }];
      const assetResponse = {
        total_page_count: 1,
        pageLimit: limit,
        total_record_count: 3,
        page_number: page,
        assets: assetData,
        pages: [{
          number: 1,
          url: 'null?page=' + page
        }]
      };

      const assetService = class AssetService {
        constructor() { }

        getAssets(assetList, orgId, limit, offset) { return Promise.resolve(assetData); }
        getAssetsCount(assetList, orgId) { return Promise.resolve(assetResponseCount); }
      };

      const AssetController = proxyquire('./asset.controller', {
        './asset.service': assetService,
        '../../../utils/centralCollector.client': CentralCollectorClient,
        '../organization/org.service': OrgService,
        '../subApplication/subApplication.service': SubApplicationService
      });

      const assetController = new AssetController();
      const req = httpMocks.createRequest({ params: { orgId }, query: { page } });
      const res = httpMocks.createResponse({ locals: { paginate: { limit, offset, page } } });
      const details = await assetController.getAssets(req, res);
      const assetDetails = details._getData();
      expect(JSON.parse(assetDetails)).to.deep.equal(assetResponse);
    });
  });

  describe('addAssetToOrg', () => {
    it('addAssetToOrg', async () => {
      const assetId = 1;
      const assetIdorgId = 1;
      const assetData = { id: 1, data: 1 };

      const assetService = class AssetService {
        constructor() { }

        async addAssetToOrg(assetIdorgId, assetId) {
          return assetData;
        }
      };

      const AssetController = proxyquire('./asset.controller', {
        './asset.service': assetService,
        '../../../utils/centralCollector.client': CentralCollectorClient,
        '../organization/org.service': OrgService,
        '../subApplication/subApplication.service': SubApplicationService
      });

      const assetController = new AssetController();
      const req = httpMocks.createRequest({ params: { assetId } });
      const res = httpMocks.createResponse();
      const details = await assetController.addAssetToOrg(req, res);
      const assetDetails = details._getData();
      expect(JSON.parse(assetDetails)).to.deep.equal(assetData);
    });
  });

  describe('updateAsset', () => {
    it('updateAsset', async () => {
      const assetId = 1;
      const update = { id: 1, data: 1 };

      const assetService = class AssetService {
        constructor() { }

        async updateAssetById(assetId, update) {
          return update;
        }
      };

      const AssetController = proxyquire('./asset.controller', {
        './asset.service': assetService,
        '../../../utils/centralCollector.client': CentralCollectorClient,
        '../organization/org.service': OrgService,
        '../subApplication/subApplication.service': SubApplicationService
      });

      const assetController = new AssetController();
      const req = httpMocks.createRequest({ params: { assetId }, body: update });
      const res = httpMocks.createResponse();
      const details = await assetController.updateAsset(req, res);
      const assetDetails = details._getData();
      expect(JSON.parse(assetDetails)).to.deep.equal(update);
    });
  });

  describe('changeAssetOrganization', () => {
    it('changeAssetOrganization', async () => {
      const update = { assets: { id: 1, data: 1 } };
      const orgId = 1;
      const assetService = class AssetService {
        constructor() { }

        async changeAssetOrganization(assets, update, orgId, userId, token) {
          return update;
        }
      };

      const AssetController = proxyquire('./asset.controller', {
        './asset.service': assetService,
        '../../../utils/centralCollector.client': CentralCollectorClient,
        '../organization/org.service': OrgService,
        '../subApplication/subApplication.service': SubApplicationService
      });

      const assetController = new AssetController();
      const req = httpMocks.createRequest({ params: { orgId }, body: update, user: { id: 1 }, authInfo: 1 });
      const res = httpMocks.createResponse();
      const details = await assetController.changeAssetOrganization(req, res);
      const assetDetails = details._getData();
      expect(JSON.parse(assetDetails)).to.deep.equal(update);
    });
  });


  describe('changeAssetLocation', () => {
    it('changeAssetLocation', async () => {
      const update = { assets: '1,2,3' };
      const assetService = class AssetService {
        constructor() { }

        async changeAssetLocation(assets, update) {
          return update;
        }
      };

      const AssetController = proxyquire('./asset.controller', {
        './asset.service': assetService,
        '../../../utils/centralCollector.client': CentralCollectorClient,
        '../organization/org.service': OrgService,
        '../subApplication/subApplication.service': SubApplicationService
      });

      const assetController = new AssetController();
      const req = httpMocks.createRequest({ body: update });
      const res = httpMocks.createResponse();
      const details = await assetController.changeAssetLocation(req, res);
      const assetDetails = details._getData();
      expect(JSON.parse(assetDetails)).to.deep.equal(update);
    });
  });

  describe('changeAssetEnvironment', () => {
    it('changeAssetEnvironment', async () => {
      const update = { assets: '1,2,3' };
      const assetService = class AssetService {
        constructor() { }

        async changeAssetEnvironment(assets, update) {
          return update;
        }

        async getAssetByArray(assetArr) {
          return update;
        }
      };

      const AssetController = proxyquire('./asset.controller', {
        './asset.service': assetService,
        '../../../utils/centralCollector.client': CentralCollectorClient,
        '../organization/org.service': OrgService,
        '../subApplication/subApplication.service': SubApplicationService
      });

      const assetController = new AssetController();
      const req = httpMocks.createRequest({ body: update });
      const res = httpMocks.createResponse();
      const details = await assetController.changeAssetEnvironment(req, res);
      const assetDetails = details._getData();
      expect(JSON.parse(assetDetails)).to.deep.equal(update);
    });
  });

  describe('deleteAssetbyId', () => {
    it('deleteAssetbyId', async () => {
      const data = { id: 1, data: 1 };
      const assetId = 1;
      const orgId = 1;
      const assetService = class AssetService {
        constructor() { }

        async deleteById(assetId, orgId) {
          return data;
        }

      };

      const AssetController = proxyquire('./asset.controller', {
        './asset.service': assetService,
        '../../../utils/centralCollector.client': CentralCollectorClient,
        '../organization/org.service': OrgService,
        '../subApplication/subApplication.service': SubApplicationService
      });

      const assetController = new AssetController();
      const req = httpMocks.createRequest({ params: { assetId, orgId } });
      const res = httpMocks.createResponse();
      const details = await assetController.deleteAssetbyId(req, res);
      const assetDetails = details._getData();
      expect(JSON.parse(assetDetails)).to.deep.equal(data);
    });
  });

  describe('deleteMultipleAssets', () => {
    it('deleteMultipleAssets', async () => {
      const data = [{ id: 1, data: 1 }, { id: 2, data: 2 }, { id: 3, data: 3 }];
      const orgId = 1;
      const assetService = class AssetService {
        constructor() { }

        async deleteMultipleAssets(assetId, orgId) {
          return data;
        }

      };

      const AssetController = proxyquire('./asset.controller', {
        './asset.service': assetService,
        '../../../utils/centralCollector.client': CentralCollectorClient,
        '../organization/org.service': OrgService,
        '../subApplication/subApplication.service': SubApplicationService
      });

      const assetController = new AssetController();
      const req = httpMocks.createRequest({ params: { orgId }, query: { id: '1,2,3' } });
      const res = httpMocks.createResponse();
      const details = await assetController.deleteMultipleAssets(req, res);
      const assetDetails = details._getData();
      expect(JSON.parse(assetDetails)).to.deep.equal(data);
    });
  });

  describe('getAssetDetail', () => {
    it('getAssetDetail', async () => {
      const data = { id: 1, data: 1 };
      const assetId = 1;
      const assetService = class AssetService {
        constructor() { }

        async getAssetDetail(assetId, orgId) {
          return data;
        }

      };

      const AssetController = proxyquire('./asset.controller', {
        './asset.service': assetService,
        '../../../utils/centralCollector.client': CentralCollectorClient,
        '../organization/org.service': OrgService,
        '../subApplication/subApplication.service': SubApplicationService
      });

      const assetController = new AssetController();
      const req = httpMocks.createRequest({ params: { assetId } });
      const res = httpMocks.createResponse();
      const details = await assetController.getAssetDetail(req, res);
      const assetDetails = details._getData();
      expect(JSON.parse(assetDetails)).to.deep.equal(data);
    });
  });

  describe('createAssetDetail', () => {
    it('createAssetDetail', async () => {
      const data = { id: 1, data: 1 };
      const assetId = 1;
      const assetService = class AssetService {
        constructor() { }

        async createAssetDetail(assetId, params) {
          return data;
        }

      };

      const AssetController = proxyquire('./asset.controller', {
        './asset.service': assetService,
        '../../../utils/centralCollector.client': CentralCollectorClient,
        '../organization/org.service': OrgService,
        '../subApplication/subApplication.service': SubApplicationService
      });

      const assetController = new AssetController();
      const req = httpMocks.createRequest({ params: { assetId } });
      const res = httpMocks.createResponse();
      const details = await assetController.createAssetDetail(req, res);
      const assetDetails = details._getData();
      expect(JSON.parse(assetDetails)).to.deep.equal(data);
    });
  });

  describe('getAssetNetwork', () => {
    it('getAssetNetwork', async () => {
      const assetNetwork = { id: 1, data: 1 };
      const assetId = 1;
      const assetService = class AssetService {
        constructor() { }

        async getAssetNetwork(assetId, params) {
          return assetNetwork;
        }

      };

      const AssetController = proxyquire('./asset.controller', {
        './asset.service': assetService,
        '../../../utils/centralCollector.client': CentralCollectorClient,
        '../organization/org.service': OrgService,
        '../subApplication/subApplication.service': SubApplicationService
      });

      const assetController = new AssetController();
      const req = httpMocks.createRequest({ params: { assetId } });
      const res = httpMocks.createResponse();
      const details = await assetController.getAssetNetwork(req, res);
      const assetNetworkDetail = details._getData();
      expect(JSON.parse(assetNetworkDetail)).to.deep.equal(assetNetwork);
    });
  });

  describe('getVMAssetNetwork', () => {
    it('getVMAssetNetwork', async () => {
      const vmAssetNetworksdata = [{ id: 1, data: 1 }];
      const assetId = 1;
      const assetService = class AssetService {
        constructor() { }

        async getVMAssetNetwork(assetId, params) {
          return vmAssetNetworksdata;
        }

      };

      const AssetController = proxyquire('./asset.controller', {
        './asset.service': assetService,
        '../../../utils/centralCollector.client': CentralCollectorClient,
        '../organization/org.service': OrgService,
        '../subApplication/subApplication.service': SubApplicationService
      });

      const assetController = new AssetController();
      const req = httpMocks.createRequest({ params: { assetId } });
      const res = httpMocks.createResponse();
      const details = await assetController.getVMAssetNetwork(req, res);
      const vmAssetNetworksdataDetails = details._getData();
      expect(JSON.parse(vmAssetNetworksdataDetails)).to.deep.equal(vmAssetNetworksdata);
    });
  });

  describe('createVMAssetNetwork', () => {
    it('createVMAssetNetwork', async () => {
      const vmAssetNetworksdata = [{ id: 1, data: 1 }];
      const assetId = 1;
      const assetService = class AssetService {
        constructor() { }

        async createVMAssetNetwork(assetId, params) {
          return vmAssetNetworksdata;
        }

      };

      const AssetController = proxyquire('./asset.controller', {
        './asset.service': assetService,
        '../../../utils/centralCollector.client': CentralCollectorClient,
        '../organization/org.service': OrgService,
        '../subApplication/subApplication.service': SubApplicationService
      });

      const assetController = new AssetController();
      const req = httpMocks.createRequest({ params: { assetId }, body: vmAssetNetworksdata });
      const res = httpMocks.createResponse();
      const details = await assetController.createVMAssetNetwork(req, res);
      const vmAssetNetworksdataDetails = details._getData();
      expect(JSON.parse(vmAssetNetworksdataDetails)).to.deep.equal(vmAssetNetworksdata);
    });
  });

  describe('getPhysicalAssetNetwork', () => {
    it('getPhysicalAssetNetwork', async () => {
      const vmAssetNetworksdata = [{ id: 1, data: 1 }];
      const assetId = 1;
      const assetService = class AssetService {
        constructor() { }

        async getPhysicalAssetNetwork(assetId, params) {
          return vmAssetNetworksdata;
        }

      };

      const AssetController = proxyquire('./asset.controller', {
        './asset.service': assetService,
        '../../../utils/centralCollector.client': CentralCollectorClient,
        '../organization/org.service': OrgService,
        '../subApplication/subApplication.service': SubApplicationService
      });

      const assetController = new AssetController();
      const req = httpMocks.createRequest({ params: { assetId } });
      const res = httpMocks.createResponse();
      const details = await assetController.getPhysicalAssetNetwork(req, res);
      const vmAssetNetworksdataDetails = details._getData();
      expect(JSON.parse(vmAssetNetworksdataDetails)).to.deep.equal(vmAssetNetworksdata);
    });
  });


  describe('createPhysicalAssetNetwork', () => {
    it('createPhysicalAssetNetwork', async () => {
      const vmAssetNetworksdata = [{ id: 1, data: 1 }];
      const assetId = 1;
      const assetService = class AssetService {
        constructor() { }

        async createAssetNetwork(assetId, params) {
          return vmAssetNetworksdata;
        }

      };

      const AssetController = proxyquire('./asset.controller', {
        './asset.service': assetService,
        '../../../utils/centralCollector.client': CentralCollectorClient,
        '../organization/org.service': OrgService,
        '../subApplication/subApplication.service': SubApplicationService
      });

      const assetController = new AssetController();
      const req = httpMocks.createRequest({ params: { assetId }, body: vmAssetNetworksdata });
      const res = httpMocks.createResponse();
      const details = await assetController.createPhysicalAssetNetwork(req, res);
      const vmAssetNetworksdataDetails = details._getData();
      expect(JSON.parse(vmAssetNetworksdataDetails)).to.deep.equal(vmAssetNetworksdata);
    });
  });


  describe('getAssetCount', () => {
    it('getAssetCount', async () => {
      const start = '2020-01-01';
      const end = '2020-01-02';
      const assetData = { count: 10 };
      const orgId = 1;
      const assetService = class AssetService {
        constructor() { }

        async checkAssetCount(orgId, startDate, endDate) {
          return assetData;
        }
      };

      const AssetController = proxyquire('./asset.controller', {
        './asset.service': assetService,
        '../../../utils/centralCollector.client': CentralCollectorClient,
        '../organization/org.service': OrgService,
        '../subApplication/subApplication.service': SubApplicationService
      });

      const assetController = new AssetController();
      const req = httpMocks.createRequest({ params: { orgId }, query: { start, end } });
      const res = httpMocks.createResponse();
      const details = await assetController.getAssetCount(req, res);
      const assetDetails = details._getData();
      expect(JSON.parse(assetDetails)).to.deep.equal(assetData);
    });
  });

  describe('getAssetByDays', () => {
    it('getAssetByDays', async () => {
      const start = '2020-01-01';
      const end = '2020-01-02';
      const assetData = { count: 10 };
      const orgId = 1;
      const assetService = class AssetService {
        constructor() { }

        async checkAssetCountByNoOfDays(orgId, startDate, endDate) {
          return assetData;
        }
      };

      const AssetController = proxyquire('./asset.controller', {
        './asset.service': assetService,
        '../../../utils/centralCollector.client': CentralCollectorClient,
        '../organization/org.service': OrgService,
        '../subApplication/subApplication.service': SubApplicationService
      });

      const assetController = new AssetController();
      const req = httpMocks.createRequest({ params: { serviceProviderId: orgId }, query: { start, end } });
      const res = httpMocks.createResponse();
      const details = await assetController.getAssetByDays(req, res);
      const assetDetails = details._getData();
      expect(JSON.parse(assetDetails)).to.deep.equal(assetData);
    });
  });

  describe('getTenantLevelRollUp', () => {
    it('getTenantLevelRollUp', async () => {
      const start = '2020-01-01';
      const end = '2020-01-02';
      const assetData = { data: 1 };
      const orgId = 1;
      const assetService = class AssetService {
        constructor() { }

        async getTenantLevelRollUp(orgId, startDate, endDate) {
          return assetData;
        }
      };

      const AssetController = proxyquire('./asset.controller', {
        './asset.service': assetService,
        '../../../utils/centralCollector.client': CentralCollectorClient,
        '../organization/org.service': OrgService,
        '../subApplication/subApplication.service': SubApplicationService
      });

      const assetController = new AssetController();
      const req = httpMocks.createRequest({ params: { serviceProviderId: orgId }, query: { start, end } });
      const res = httpMocks.createResponse();
      const details = await assetController.getTenantLevelRollUp(req, res);
      const assetDetails = details._getData();
      expect(JSON.parse(assetDetails)).to.deep.equal(assetData);
    });
  });

  describe('ChangeAssetState', () => {
    it('ChangeAssetState', async () => {
      const assetData = { data: 1, asset_id: { split() { return [1, 2, 3] } }, managed: 'true' };
      const assetDataRes = { data: 1, asset_id: {}, managed: 'true' };
      const assetService = class AssetService {
        constructor() { }

        async ChangeAssetState(assetId, update) {
          return assetData;
        }
      };

      const AssetController = proxyquire('./asset.controller', {
        './asset.service': assetService,
        '../../../utils/centralCollector.client': CentralCollectorClient,
        '../organization/org.service': OrgService,
        '../subApplication/subApplication.service': SubApplicationService
      });

      const assetController = new AssetController();
      const req = httpMocks.createRequest({ body: assetData });
      const res = httpMocks.createResponse();
      const details = await assetController.ChangeAssetState(req, res);
      const assetDetails = details._getData();
      expect(JSON.parse(assetDetails)).to.deep.equal(assetDataRes);
    });
  });


  describe('ChangeNetworkIp', () => {
    it('ChangeNetworkIp', async () => {
      const asset_id = 1;

      const assetData = { data: 1, asset_id: 1, network_ip: '10.1.2.2' };
      const assetService = class AssetService {
        constructor() { }

        async ChangeNetworkIp(assetId, update) {
          return assetData;
        }
      };

      const AssetController = proxyquire('./asset.controller', {
        './asset.service': assetService,
        '../../../utils/centralCollector.client': CentralCollectorClient,
        '../organization/org.service': OrgService,
        '../subApplication/subApplication.service': SubApplicationService
      });

      const assetController = new AssetController();
      const req = httpMocks.createRequest({ params: { asset_id }, body: assetData });
      const res = httpMocks.createResponse();
      const details = await assetController.ChangeNetworkIp(req, res);
      const assetDetails = details._getData();
      expect(JSON.parse(assetDetails)).to.deep.equal(assetData);
    });
  });

  describe('AssignAssetToSubApp', () => {
    it('AssignAssetToSubApp', async () => {
      const assetData = { data: 1, asset_id: '1,2,3' };
      const assetService = class AssetService {
        constructor() { }

        async getAssetByArray(policyGroupId, assets, userId, userToken) {
          return assetData;
        }
      };

      const policyGroupService = class SubApplicationService {
        constructor() { }

        async addAssetToSubApplication() {
          return assetData;
        }
      };

      const AssetController = proxyquire('./asset.controller', {
        './asset.service': assetService,
        '../../../utils/centralCollector.client': CentralCollectorClient,
        '../organization/org.service': OrgService,
        '../subApplication/subApplication.service': policyGroupService
      });

      const assetController = new AssetController();
      const req = httpMocks.createRequest({ user: { id: 1 }, authInfo: 1, body: assetData });
      const res = httpMocks.createResponse();
      const details = await assetController.AssignAssetToSubApp(req, res);
      const assetDetails = details._getData();
      expect(JSON.parse(assetDetails)).to.deep.equal(assetData);
    });
  });

  describe('AssetDiscovery', () => {
    it('AssetDiscovery', async () => {
      const asset_id = 1;

      const assetData = { data: 1, asset_id: 1, network_ip: '10.1.2.2' };
      const ccUrl = '10.1.1.1';
      const assetService = class AssetService {
        constructor() { }

        async startAssetDiscovery(ccUrl, params) {
          return assetData;
        }
      };

      const CentralCollectorClient = class CentralCollectorClient {
        constructor() { }

        static CentralCollectorConnectionCheck() {
          return ccUrl;
        }
      };

      const AssetController = proxyquire('./asset.controller', {
        './asset.service': assetService,
        '../../../utils/centralCollector.client': CentralCollectorClient,
        '../organization/org.service': OrgService,
        '../subApplication/subApplication.service': SubApplicationService
      });

      const assetController = new AssetController();
      const req = httpMocks.createRequest({ user: { id: 1 }, authInfo: 1, body: assetData });
      const res = httpMocks.createResponse();
      const details = await assetController.AssetDiscovery(req, res);
      const assetDetails = details._getData();
      expect(JSON.parse(assetDetails)).to.deep.equal(assetData);
    });
  });
});
