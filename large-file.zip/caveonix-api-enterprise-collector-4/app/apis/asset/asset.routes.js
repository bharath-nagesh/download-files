const AssetController = require('./asset.controller');

/**
 * @swagger
 * tags:
 *  - name: Asset
 *    description: Asset endpoints
 */
module.exports = class AssetRoutes {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.assetController = new AssetController();

      // initializing route
      if (type === 'Service Provider') {
        this.initServiceProvider();
      } else {
        this.initOrganization();
      }
    }
  }

  initOrganization() {

    /**
     * @swagger
     *
     * /api/organization/{orgId}/asset/distinctDetails:
     *   get:
     *     tags:
     *       - Asset
     *     summary: Gets distinct asset details for list of organization assets
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of assets distinct details
     *       401:
     *          description: Unauthorized
     *       400:
     *          description: Bad Request
     *       500:
     *          description: API Request Error
     */
    this.router.get(`${this.path}/distinctDetails`, this.assetController.getAssetDistinctDetails);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/asset:
     *   get:
     *     tags:
     *       - Asset
     *     summary: Gets a list of organization assets
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of assets
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/`, this.assetController.getAssetsForOrg);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/asset/ids:
     *   get:
     *     tags:
     *       - Asset
     *     summary: Gets a list of assets from a list of ids
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: ids
     *         description: A comma delimited list of ids
     *         in: query
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: asset
     */
    this.router.get(`${this.path}/ids`, this.assetController.getAssetsByIds);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/asset/{assetId}:
     *   get:
     *     tags:
     *       - Asset
     *     summary: Gets a asset by it's id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: assetId
     *         description: The id of the specified asset.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: asset
     */
    this.router.get(`${this.path}/:assetId`, this.assetController.getAssetById);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/asset:
     *   post:
     *     tags:
     *       - Asset
     *     summary: Creates an asset
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/Asset'
     *     responses:
     *       200:
     *         description: asset
     */
    this.router.post(`${this.path}/`, this.assetController.createAsset);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/asset/updateAssetOrg:
     *   put:
     *     tags:
     *       - Asset
     *     summary: Updates an asset's organization
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/Asset'
     *     responses:
     *       200:
     *         description: asset
     */
    this.router.put(`${this.path}/updateAssetOrg`, this.assetController.changeAssetOrganization);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/asset/updateAssetLocation:
     *   put:
     *     tags:
     *       - Asset
     *     summary: Updates an asset's location
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/Asset'
     *     responses:
     *       200:
     *         description: asset
     */
    this.router.put(`${this.path}/updateAssetLocation`, this.assetController.changeAssetLocation);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/asset/updateAssetEnvironment:
     *   put:
     *     tags:
     *       - Asset
     *     summary: Updates an asset's environment
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/Asset'
     *     responses:
     *       200:
     *         description: asset
     */
    this.router.put(`${this.path}/updateAssetEnvironment`, this.assetController.changeAssetEnvironment);
  }

  initServiceProvider() {
    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/asset/updateAssetOrg:
     *   put:
     *     tags:
     *       - Asset
     *     summary: Updates an asset's organization
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/Asset'
     *     responses:
     *       200:
     *         description: asset
     */
    this.router.put(`${this.path}/updateAssetOrg`, this.assetController.changeAssetOrganization);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/asset/updateAssetLocation:
     *   put:
     *     tags:
     *       - Asset
     *     summary: Updates an asset's location
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/Asset'
     *     responses:
     *       200:
     *         description: asset
     */
    this.router.put(`${this.path}/updateAssetLocation`, this.assetController.changeAssetLocation);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/asset/updateAssetEnvironment:
     *   put:
     *     tags:
     *       - Asset
     *     summary: Updates an asset's environment
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/Asset'
     *     responses:
     *       200:
     *         description: asset
     */
    this.router.put(`${this.path}/updateAssetEnvironment`, this.assetController.changeAssetEnvironment);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/asset/ids:
     *   get:
     *     tags:
     *       - Asset
     *     summary: Gets a list of assets from a list of ids
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: ids
     *         description: A comma delimited list of ids
     *         in: query
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: asset
     */
    this.router.get(`${this.path}/ids`, this.assetController.getAssetsByIds);
  }
};
