const Sequelize = require('sequelize');

class AssetDetail extends Sequelize.Model {
  static init(sequelize) {
    super.init(
      {
        realm: { type: Sequelize.STRING },
        registeredName: { type: Sequelize.STRING,field:'realm' },
        operatingSystem: { type: Sequelize.STRING, field: 'operating_system', allowNull: true },
        organization_id: { type: Sequelize.INTEGER, field: 'organization_id' },
        dataCenterName: { type: Sequelize.STRING, field: 'datacenter_name' },
        vmFolderName: { type: Sequelize.STRING, field: 'vm_folder_name' },
        resourcePool: { type: Sequelize.STRING, field: 'resource_pool' }
      },
      { timestamps: true, freezeTableName: true, tableName: 'asset_details', sequelize, underscored: true }
    );
  }

  static associate(models) {
    AssetDetail.belongsTo(models.Asset, { foreignKey:'asset_id' });
    AssetDetail.belongsTo(models.Organization, { foreignKey: 'organization_id' });
    AssetDetail.belongsTo(models.AssetRepoEndpoint, { foreignKey: 'asset_manager_id' });
  };
}

module.exports = AssetDetail;
