const { each, has } = require('lodash');
const Sequelize = require('sequelize');
const complianceScoreQuery = require('../../definitions/scoringModules/complianceScore.view');
const cyberScoreQuery = require('../../definitions/scoringModules/cyberScore.view');
const sequelize = require('../../../config/db.conf').getConnection();
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'assetModel'
});
const where = require('../../definitions/common');

/**
 * @swagger
 * components:
 *   schemas:
 *     Asset:
 *       type: object
 *       required:
 *         - name
 *         - isActive
 *       properties:
 *         name:
 *           type: string
 *         assetName:
 *           type: string
 *         macAddress:
 *           type: string
 *         vmId:
 *           type: string
 *         organizationId:
 *           type: string
 *         organization_id:
 *           type: string
 *         parent_org_id:
 *           type: string
 *         source:
 *           type: string
 *         managed:
 *           type: string
 *         createdBy:
 *           type: string
 *         updatedBy:
 *           type: string
 *         isActive:
 *           type: string
 *         type:
 *           type: string
 * @param sequelize
 */
class Asset extends Sequelize.Model {
  static init(sequelize) {
    return super.init({
        name: { type: Sequelize.STRING },
        assetName: { type: Sequelize.STRING, field: 'name' },
        macAddress: { type: Sequelize.STRING, field: 'macaddress' },
        vmId: { type: Sequelize.STRING, field: 'vmid' },
        organizationId: { type: Sequelize.INTEGER, field: 'organization_id' },
        organization_id: { type: Sequelize.INTEGER, field: 'organization_id' },
        parent_org_id: { type: Sequelize.INTEGER, field: 'parent_org_id' },
        source: { type: Sequelize.STRING, field: 'source' },
        managed: { type: Sequelize.STRING, field: 'managed', defaultValue: true },
        createdBy: { type: Sequelize.STRING, field: 'created_by', defaultValue: 'Manual' },
        updatedBy: { type: Sequelize.STRING, field: 'updated_by', defaultValue: 'Manual' },
        isActive: { type: Sequelize.BOOLEAN, field: 'is_active', defaultValue: 'enabled' },
        is_active: { type: Sequelize.BOOLEAN, field: 'is_active' },
        type: { type: Sequelize.STRING, field: 'type', defaultValue: 'vm' }
      },
      {
        sequelize,
        timestamps: true,
        freezeTableName: true,
        tableName: 'assets',
        underscored: true
      });
  }

  static associate(models) {

    Asset.hasMany(models.AssetRemoteAccessDetailMembers);
    Asset.belongsTo(models.Organization, { foreignKey: 'organization_id' });
    Asset.belongsTo(models.Organization, { foreignKey: 'parent_org_id', as: 'ParentOrganization' });
    Asset.hasMany(models.AssetDetail);
    Asset.hasMany(models.AssetVMNetwork);
    Asset.belongsToMany(models.RemoteAccessDetail, {
      through: 'asset_remote_access_detail_members',
      foreignKey: 'asset_id',
      otherKey: 'remote_access_detail_id',
      timestamps: false
    });
  }

  static async getRiskScoreByVmIds(orgId, vmIds = []) {
    vmIds = vmIds.filter((val) => {
      return val;
    });
    if (vmIds.length === 0) return {};
    const query = cyberScoreQuery('vmid', { vmid: vmIds });

    const data = await sequelize.query(`select  p.name as priority, score.* from (${query}) score join priorities p on score.raw_weighted_risk <= p.max_value and score.raw_weighted_risk >= p.min_value`, {
      replacements: { orgId, date: new Date() },
      type: sequelize.QueryTypes.SELECT
    });
    const vmMap = {};
    const scoreObjArray = data || [];
    each(scoreObjArray, scoreObj => {
      if (has(scoreObj, 'label')) {
        vmMap[scoreObj.label] = scoreObj;
      }
    });
    return vmMap;
  };

  static async getComplianceScoreByVmIds(orgId, vmIds = []) {
    vmIds = vmIds.filter(val => val);
    if (vmIds.length === 0) return Promise.resolve({});
    const query = complianceScoreQuery('vmid', { vmid: vmIds });
    const data = await sequelize.query(`select  p.name as priority, score.* from (${query}) score join priorities p on score.raw_weighted_risk <= p.max_value and score.raw_weighted_risk >= p.min_value`, {
      replacements: { orgId, date: new Date() },
      type: sequelize.QueryTypes.SELECT
    });
    const vmMap = {};
    const scoreObjArray = data || [];
    each(scoreObjArray, scoreObj => {
      if (has(scoreObj, 'label')) {
        vmMap[scoreObj.label] = scoreObj;
      }
    });
    return vmMap;
  };

  static async getComplianceAssetCount(orgId) {
    const query =
      `select count(vmid), name as priority from (
        select vmid, compliance_count::float/total_count as final_count from (
        select vmid, count (dc.id) as total_count,
        sum(case when severity='low'
        then 2 when severity='medium'
        then 5 when severity='high'
        then 8 when severity='critical'
        then 10 end) as compliance_count from
        ${where.compliance.viewWithNist} dc join xccdf_rules x on dc.rule_id = x.rule_id group by vmid) as t) as k join priorities p on k.final_count <= p.max_value and  k.final_count >= p.min_value group by priority`;
    const data = await sequelize.query(query, {
      replacements: { orgId, date: new Date(Date.now()) },
      type: sequelize.QueryTypes.SELECT
    });
    logger.info({ data }, 'compliance asset data breakdown');
    return data || [];

  };

  static async getCyberAssetCount(orgId) {
    const query =
      'select count(vmid), name as priority from (select vmid, sum(cast (score as float))/count(cve_id) as avg_risk_score from daily_risk_score_view where organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id)  group by vmid   ) as t join priorities p on t.avg_risk_score <= p.max_value and t.avg_risk_score >= p.min_value group by priority';
    const data = await sequelize.query(query, { replacements: { orgId }, type: sequelize.QueryTypes.SELECT });
    return data;
  };

  static async getAssetDataByVmIds(vmIds = [null]) {
    vmIds = vmIds.filter((val) => val);
    if (vmIds.length === 0) return {};
    const query = 'select * from application_group_asset_view where vmid in (:vmIds)';
    const data = await sequelize.query(query, { replacements: { vmIds }, type: sequelize.QueryTypes.SELECT });
    const assetObjArray = data || [];
    const vmMap = {};
    each(assetObjArray, asset => {
      if (has(asset, 'vmid')) {
        vmMap[asset.vmid] = asset;
      }
    });
    return vmMap;
  };
}

module.exports = Asset;
