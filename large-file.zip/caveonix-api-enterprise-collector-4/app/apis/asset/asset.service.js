const csv = require('async-csv');
const { map } = require('lodash');
const moment = require('moment');
const rp = require('request-promise');
const uuid = require('uuid');

const ApplicationTag = require('../application/applicationTag.model');
const Asset = require('./asset.model');
const AssetDetail = require('./assetDetail.model');
const AssetEnvironmentMember = require('../../models/assetEnvironmentMember.model');
const AssetPhysicalNetwork = require('../../models/assetPhysicalNetwork.model');
const AssetRemoteAccessDetailMembers = require('../assetRemoteAccessDetailMembers/assetRemoteAccessDetailMembers.model');
const AssetRepoEndpoint = require('../assetRepoEndpoint/assetRepoEndpoint.model');
const AssetVMNetwork = require('../../models/assetVMNetwork.model');
const AssetRepoType = require('../assetRepoEndpoint/assetRepoType.model');
const Environment = require('../environment/environment.model');
const EnforcementService = require('../enforcement/enforcement.service');
const enforcementService = new EnforcementService();
const HostingProvider = require('../hostingProvider/hostingProvider.model');
const Location = require('../location/location.model');
const logger = require('../../../utils/logger').logger;
const OrgService = require('../organization/org.service');
const orgService = new OrgService();
const Organization = require('../organization/organization.model');
const SubApplication = require('../subApplication/subApplication.model');
const SubApplicationAssetMembers = require('../subApplication/subApplicationAssetMembers.model');
const SubApplicationService = require('../subApplication/subApplication.service');
const subApplicationService = new SubApplicationService();
const sequelize = require('../../../config/db.conf').getConnection();

const loggerLabel = 'AssetService';

module.exports = class AssetService {
  constructor() {
    logger.debug('called AssetService constructor');
  }

  async getAssetByVmId(vmId) {
    const cacheAsset = await Asset.findOne({ where: { vmId } });
    return cacheAsset;
  }

  async getAsset(assetId, opts) {
    const asset = await Asset.findByPk(assetId, {
      include: [
        {
          model: AssetDetail,
          include: [
            { model: Organization },
            { model: AssetRepoEndpoint, include: [{ model: AssetRepoType }] }
          ]
        },
        { model: Organization },
        { model: AssetVMNetwork }
      ]
    });

    const myRegexp = /([a-zA-Z0-9/(]{9}-[a-zA-Z0-9]{4}-[a-zA-Z0-9]{4}-[a-zA-Z0-9]{4}-[a-zA-Z0-9/)]{13})/g;
    const nameString = asset.name;
    const realmString = asset.AssetDetails[0].realm;
    const registerNameString = asset.AssetDetails[0].registeredName;
    if (nameString) var nameRegexpOut = nameString.match(myRegexp);
    if (realmString) var realmRegexpOut = realmString.match(myRegexp);
    if (registerNameString) var registerNameRegexpOut = registerNameString.match(myRegexp);
    if (nameRegexpOut) asset.name = nameString.replace(nameRegexpOut[0], '');
    if (realmRegexpOut) asset.AssetDetails[0].realm = realmString.replace(realmRegexpOut[0], '');
    if (registerNameRegexpOut) asset.AssetDetails[0].registeredName = registerNameString.replace(registerNameRegexpOut[0], '');
    return asset;
  }

  getAssetsForOrg(orgId) {
    return Asset.findAll({ where: { organization_id: orgId } });
  }

  async addAssetToOrg(orgId, assetId) {
    const asset = await Asset.findByPk(assetId);
    if (!asset) {
      const err = new Error('Asset not found.');
      err.status = 404;
      throw err;
    }
    asset.organization_id = orgId;
    return asset.save();
  }

  async create(orgId, params) {
    params.organization_id = orgId;
    return Asset.create(params);

  }

  async uploadAssets(orgId, locationId, hostingProviderId, csvFile) {
    const parse = csv.parse;
    try {
      const columns = ['Registered Name', 'Asset Name', 'IP Address', 'macaddress', 'Operating System'];
      let output = await parse(csvFile, {
        columns,
        relax_column_count: true,
        delimiter: ',',
        rtrim: true,
        ltrim: true
      });
      output = Array.from(new Set(output.map(JSON.stringify))).map(JSON.parse);
      if (output[0]['Asset Name'] && output[0]['Asset Name'] === columns[1] /* Asset Name*/) {
        output.splice(0, 1);
      }
      for (let i = 0; i < output.length; i++) {
        if (Object.entries(output[i]).every(tuple => {
          return tuple[0] === tuple[1];
        })) {
          return;
        }
        output[i].organization_id = orgId;
        await this.mutateAssetInfo(output[i], locationId, hostingProviderId);
      }
      output = output.map(asset => asset);
      return output;
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      error.message = 'invalid data type';
      error.status = 400;
      throw error;
    }
  }

  async updateAssetById(assetId, update) {
    const name = update.name;
    const exists = await this.checkNameForUpdate(name, assetId);
    if (exists) {
      const err = new Error('Duplicate name.');
      err.status = 400;
      throw err;
    }
    const asset = await Asset.findByPk(assetId);
    return asset.update(update);
  }

  checkNameForUpdate(name, assetId) {
    return Asset.findOne({
      where: {
        name: sequelize.where(sequelize.fn('LOWER', sequelize.col('name')), sequelize.fn('lower', name)),
        isActive: { $ne: 'false' },
        id: { $ne: assetId }
      }
    });
  }

  async getOrgChain(orgId, all = false) {
    //
    const orgChainArr = await sequelize
      .query(
        `WITH RECURSIVE org_cte(organization_id, name, type, parent_organization_id, depth, path) AS (
       SELECT tn.organization_id, o.name,o.type, tn.parent_organization_id, 1::INT AS depth, o.name::TEXT AS path
       FROM org_chains AS tn join organizations as o on o.id = tn.organization_id WHERE tn.organization_id = ? -- Pass the parent_org_id from the previous query to get all valid organizations
      UNION ALL
       SELECT c.organization_id, o.name, o.type,c.parent_organization_id,  p.depth + 1 AS depth, (p.path || '->' || o.name::TEXT)
        FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id  WHERE c.parent_organization_id = p.organization_id
      )
      SELECT * FROM org_cte AS n;
      `,
        { replacements: [orgId], model: Organization }
      );

    if (!all) {
      const orgChainArrData = [];
      let i;
      for (i = 0; i < orgChainArr.length; i++) {
        orgChainArrData.push(await row.getDataValue('organization_id'));
      }
      return orgChainArrData;
    } else {
      return orgChainArr;
    }

  }

  /**

   * Get distinct asset details

   * @param {string} orgId

   * @param {array} attributes

   * @param {string} assetRepoId

   */

  async getAssetDistinctDetails(orgId, attributes = [], assetRepoId = false) {

    attributes = Array.isArray(attributes) ? attributes : [attributes];

    const where = { };

    if (assetRepoId) {
      where.asset_manager_id = assetRepoId;
    }

    const data = await Promise.all(attributes.map(attribute => {
      attribute = Array.isArray(attribute) ? attribute : [attribute];
      return AssetDetail.findAll({
        where,
        attributes: [[sequelize.fn('DISTINCT', sequelize.col(attribute[0])), attribute[1] || attribute[0]]]
      });
    }));

    const assetDetails = { };
    attributes.forEach((attribute, index) => {
      attribute = Array.isArray(attribute) ? attribute : [attribute];
      assetDetails[attribute[1] || attribute[0]] = map(data[index], `dataValues.${attribute[1] || attribute[0]}`);
    });
    return assetDetails;
  }

  async getAllAsset(orgId, limit, offset) {
    let newArr = [];
    const org = await Organization.findByPk(orgId);
    if (org.type === 'Provider') {
      const result = await this.getAllOrganizations();
      newArr = result.map((object) => {
        return object.dataValues.id;
      });
      return Asset.findAll({
        where: { organization_id: newArr, isActive: { $ne: 'false' } },
        order: [['id', 'ASC']],
        include: [
          {
            model: AssetDetail,
            include: [
              { model: Organization },
              {
                model: AssetRepoEndpoint,
                include: [{ model: AssetRepoType }
                ]
              }]
          },
          { model: Organization },
          { model: AssetVMNetwork }
        ],
        limit: limit,
        offset: offset
      });
    } else {
      const orgChain = await orgService.getOrgChain(org.id, true);
      newArr = orgChain.map((object) => {
        return object.dataValues.organization_id;
      });
      return Asset.findAll({
        where: { organization_id: newArr, isActive: { $ne: 'false' } },
        order: [['id', 'ASC']],
        include: [
          {
            model: AssetDetail,
            include: [
              { model: Organization },
              { model: AssetRepoEndpoint, include: [{ model: AssetRepoType }] }
            ]
          },
          { model: Organization },
          { model: AssetVMNetwork }
        ],
        limit: limit,
        offset: offset
      });
    }
  }

  async getAssetForApplication(policyGroupId, limit, offset) {
    const assetArray = await SubApplicationAssetMembers.findAll({ where: { policy_group_id: policyGroupId } });
    const assetArr = assetArray.map((object) => {
      return object.asset_id;
    });
    return Asset.findAll({
      where: {
        id: assetArr,
        isActive: ['true', 'enabled', 'disabled']
      },
      order: [['id', 'ASC']],
      include: [{
        model: AssetDetail,
        attributes: ['id', 'operatingSystem', 'realm'],
        include: [{ model: Location, attributes: ['id', 'name'] }, {
          model: Organization,
          attributes: ['id', 'name', 'aliasName', 'fullName']
        }, { model: AssetRepoEndpoint, include: [{ model: AssetRepoType }] }]
      }, {
        model: Organization,
        attributes: ['id', 'name', 'aliasName', 'fullName']
      }, { model: AssetVMNetwork }, {
        model: SubApplication,
        attributes: ['id', 'name'],
        include: [{ model: ApplicationTag, attributes: ['id', 'name'] }]
      }],
      limit: limit,
      offset: offset
    });
  }

  async getAssetForApplicationCount(policyGroupId) {
    const assetArray = await SubApplicationAssetMembers.findAll({ where: { policy_group_id: policyGroupId } });
    const assetArr = assetArray.map((object) => {
      return object.asset_id;
    });
    return Asset.count({
      where: {
        id: assetArr,
        isActive: ['true', 'enabled', 'disabled']
      }
    });
  }

  getAllOrganizations(limit, offset) {
    return Organization.findAll({
      where: { isActive: { $ne: 'false' } },
      include: [{ all: true }],
      order: [['id', 'ASC']],
      limit: limit,
      offset: offset
    });
  }

  getAssetCount(orgId) {
    return Asset.count({ where: { organization_id: orgId, isActive: { $ne: 'false' } } });
  }

  async getAssetCountForOrg(orgId, actAsProvider = true) {
    let newArr = [];
    const org = await Organization.findByPk(orgId);
    if (org.type === 'Provider' && actAsProvider) {
      const result = await this.getAllOrganizations();
      newArr = result.map((object) => {
        return object.dataValues.id;
      });
      return Asset.count({
        where: { organization_id: newArr, isActive: { $ne: 'false' } },
        order: [['id', 'ASC']]
      });
    }
    const orgChain = await orgService.getOrgChain(org.id, true);
    newArr = orgChain.map((object) => {
      return object.dataValues.organization_id;
    });
    return Asset.count({
      where: { organization_id: newArr, isActive: { $ne: 'false' } },
      order: [['id', 'ASC']]
    });
  }

  getAssetDetail(assetId) {
    return AssetDetail.findOne({ where: { asset_id: assetId }, include: [{ model: Asset }] });
  }

  async createAssetDetail(assetId, params) {
    const assetDetail = await this.getAssetDetail(assetId);
    if (assetDetail) {
      const error = new Error('Asset Detail already exists for this Asset.');
      error.status = 400;
      logger.error({ error }, 'Asset Detail already exists.');
      throw error;
    }
    const asset = await Asset.findByPk(assetId);
    params.asset_id = assetId;
    params.organization_id = asset.organization_id;
    return AssetDetail.create(params);
  }

  async getAssetNetwork(assetId) {
    const vmAssetNetworks = await this.getVMAssetNetwork(assetId);
    const physicalAssetNetworks = await this.getPhysicalAssetNetwork(assetId);
    return { vmAssetNetworks, physicalAssetNetworks };
  }

  getVMAssetNetwork(assetId) {
    return AssetVMNetwork.findAll({ where: { asset_id: assetId }, include: [{ model: Asset }] });
  }

  createVMAssetNetwork(assetId, params) {
    params.asset_id = assetId;
    return AssetVMNetwork.create(params);
  }

  getPhysicalAssetNetwork(assetId) {
    return AssetPhysicalNetwork.findAll({ where: { asset_id: assetId }, include: [{ model: Asset }] });
  }

  createPhysicalAssetNetwork(assetId, params) {
    params.asset_id = assetId;
    return models.VMAssetNetwork.create(params);
  }

  async changeAssetOrganization(assets, update, orgId, userId, userToken) {
    const assetArr = assets.split(',');
    const assetArray = assetArr.map((object) => {
      return object;
    });
    const organizationId = update.organization_id;
    await Asset.update(update, { where: { id: { $in: assetArr } } });
    await AssetDetail.update(update, { where: { asset_id: { $in: assetArr } } });
    await AssetRemoteAccessDetailMembers.destroy({ where: { asset_id: { $in: assetArr } } });
    const orgDetails = await Organization.findOne({ where: { id: organizationId } });
    if (orgDetails.type.toLowerCase() !== 'sub-organization') {
      const Policy = await SubApplication.findOne({ where: { $and: [{ organization_id: organizationId }, { name: 'Sub-Application' }] } });
      const policyIdCustomAndDefault = await SubApplication.findAll({ where: { organization_id: organizationId } });
      const policyIdCustomAndDefaultArray = policyIdCustomAndDefault.map((object) => {
        return object.id;
      });
      const assetIdCustomAndDefault = await SubApplicationAssetMembers.findAll({ where: { policy_group_id: { $in: policyIdCustomAndDefaultArray } } });
      const assetIdCustomAndDefaultArray = assetIdCustomAndDefault.map((object) => {
        return object.asset_id;
      });
      const tags = policyIdCustomAndDefault.map((pg) => {
        return pg.security_tag_name;
      });
      const assets = await Asset.findAll({
        where: { id: { $in: assetArr } },
        attributes: { include: ['vmId'] }
      });
      const vmIds = assets.map((a) => {
        return a.vmId;
      }).filter((b) => b !== '');
      //TODO chris updateSecurityTags error
      try {
        if (vmIds) await enforcementService._detatchSecurityTags(userId, userToken, orgId, tags, vmIds);
        await enforcementService.createOrUpdateSecurityTag(userId, userToken, orgId, [Policy.security_tag_name], vmIds);
      } catch (error) {
        logger.error({ error, stack: error.stack }, 'detatchSecurityTags updateSecurityTags error');
      }
      if (Policy) {
        const policyGroupId = Policy.id;
        assetArray.map(async (object) => {
          if (!assetIdCustomAndDefaultArray.includes(object)) {
            await SubApplicationAssetMembers.destroy({ where: { asset_id: object } });
            SubApplicationAssetMembers.create({ policy_group_id: policyGroupId, asset_id: object });
          }
        });
      } else {
        const PolicyGrp = await SubApplication.findOne({ where: { $and: [{ organization_id: orgId }, { name: 'Sub-Application' }] } });
        if (PolicyGrp) {
          const policyIdCustomAndDefaultForSubOrg = await SubApplication.findAll({ where: { organization_id: orgId } });
          const policyIdCustomAndDefaultForSubOrgArray = policyIdCustomAndDefaultForSubOrg.map((object) => {
            return object.id;
          });
          const assetIdCustomAndDefaultForSubOrg = await SubApplicationAssetMembers.findAll({ where: { policy_group_id: { $in: policyIdCustomAndDefaultForSubOrgArray } } });
          const assetIdCustomAndDefaultForSubOrgArray = assetIdCustomAndDefaultForSubOrg.map((object) => {
            return object.asset_id;
          });
          const policyGroupId = PolicyGrp.id;
          assetArray.map(async (object) => {
            if (!assetIdCustomAndDefaultForSubOrgArray.includes(object)) {
              await SubApplicationAssetMembers.destroy({ where: { asset_id: object } });
              SubApplicationAssetMembers.create({ policy_group_id: policyGroupId, asset_id: object });
            }
          });
        }
      }
    }
    return Asset.findAll({ where: { id: { $in: assetArr } } });
  }

  async changeAssetLocation(assets, update) {
    const assetArr = assets.split(',');
    await AssetDetail.update(update, { where: { asset_id: { $in: assetArr } } });
    return AssetDetail.findAll({ where: { asset_id: { $in: assetArr } } });
  }

  async changeAssetEnvironment(assets, update) {
    const service = this;
    let exists = '';
    const assetArr = assets.split(',');
    let i;
    for (i = 0; i < assetArr.length; i++) {
      exists = await service.checkAssetEnvMember(assetArr[i]);
      if (!exists) {
        update.asset_id = assetArr[i];
        await AssetEnvironmentMember.create(update);
      } else {
        update.asset_id = undefined;
        await exists.update(update);
      }
    }
    return Asset.findAll({ where: { id: { $in: assetArr } }, include: [{ model: AssetEnvironmentMember }] });
  }

  checkAssetEnvMember(assetId) {
    return AssetEnvironmentMember.findOne({ where: { asset_id: assetId } });
  }

  getAssetByArray(assetArr) {
    return Asset.findAll({ where: { id: { $in: assetArr } }, include: [{ model: AssetEnvironmentMember }] });
  }

  /**
   * Gets list of all assets
   * @param {number} orgId
   * @param {string} managed
   * @param {string} dropdown
   * @param {string} assetSource
   * @returns {Promise<*>}
   */
  async getAllAssetList(orgId, managed, dropdown = null, assetSource = null) {
    logger.debug('Retrieving all asset list', { loggerLabel });
    if (managed === 'true') {
      managed = [managed, null];
    }

    const where = { isActive: { $notIn: ['deleted','false'] } };

    if (managed) {
      where.managed = managed;
    }

    let include = [
      { model: AssetVMNetwork },
      { model: Organization, attributes: ['name', 'type', 'aliasName', 'fullName'] },
      { model: Organization, attributes: ['name', 'aliasName', 'fullName'], as: 'ParentOrganization' },
      {
        model: AssetDetail,
        attributes: ['resourcePool', 'realm', 'vmFolderName', 'operatingSystem'],
        include: {
          model: AssetRepoEndpoint,
          attributes: ['id', 'connectionName'],
          include: [{ model: AssetRepoType }]
        }
      }
    ];

    let attributes = { exclude: [] };

    if (dropdown && dropdown === 'true') {
      attributes = ['id', 'name', 'vmid', 'source', 'type'];
      include = [
        { model: Organization, attributes: ['id', 'name', 'type', 'aliasName', 'fullName'] },
        { model: AssetDetail, attributes: ['resourcePool', 'realm', 'vmFolderName', 'operatingSystem'] },
        { model: AssetVMNetwork }
      ];
    }
    if (assetSource && assetSource.length > 0) {
      where.source = { $in: assetSource };
    }

    const assetListArray = await Asset.findAll({
      where,
      include,
      attributes
    });

    return assetListArray.map(assetItem => {
      assetItem.dataValues.networkIp = assetItem.AssetVMNetworks.map(avnd => avnd.networkIp).filter(avnd => avnd !== '');
      assetItem.dataValues.resourcePool = assetItem.AssetDetails.map(ad => ad.resourcePool).filter(ad => ad !== '');
      return assetItem;
    });
  }

  async getAssetList(orgId, managed) {

    const orgChain = await Organization.getOrgChain(orgId, false);
    if (managed === 'true') {
      managed = [managed, null];
    }
    const where = { organization_id: orgChain, isActive: { $ne: 'false' } };
    if (managed) where.managed = managed;
    let assetListArray = await Asset.findAll({
      where,
      include: [
        { model: AssetVMNetwork },
        { model: Organization, attributes: ['name', 'type', 'aliasName', 'fullName'] },
        { model: Organization, attributes: ['name', 'aliasName', 'fullName'], as: 'ParentOrganization' },
        {
          model: AssetDetail,
          attributes: ['resourcePool', 'realm', 'physicalHostName', 'vmFolderName', 'operatingSystem'],
          include: [
            { model: Location, attributes: ['name'] },
            { model: HostingProvider, attributes: ['name'] },
            {
              model: AssetRepoEndpoint,
              attributes: ['connectionName'],
              include: [{ model: AssetRepoType, attributes: ['name'] }]
            }
          ]
        },
        { model: SubApplication, attributes: ['name'], include: [{ model: ApplicationTag, attributes: ['name'] }] },
        { model: Environment, attributes: ['name'], through: { attributes: [] } }]
    });
    assetListArray = assetListArray.map(assetItem => {
      assetItem.dataValues.networkIp = assetItem.AssetVMNetworks.map(avnd => avnd.networkIp).filter(avnd => avnd !== '');
      assetItem.dataValues.environments = assetItem.Environments.map(env => env.name).filter(env => env !== '');
      assetItem.dataValues.resourcePool = assetItem.AssetDetails.map(ad => ad.resourcePool).filter(ad => ad !== '');
      return assetItem;
    });

    let serviceList = await sequelize.query(`select * from application_group_service_view agsv where agsv.organization_id in (:orgChain) and agsv.is_active != 'false' `, { replacements: { orgChain }, type: sequelize.QueryTypes.SELECT });
    serviceList = serviceList.map(s => {
      return Object.assign({
        id: s.service_id,
        name: s.product,
        assetName: s.product,
        Organization: {
          fullName: `${s.org_alias_name} (${s.organization_name})`,
          name: s.organization_name,
          type: s.organization_type,
          aliasName: s.org_alias_name
        },
        organizationId: s.organization_id,
        organization_id: s.organization_id,
        source: s.cloud_type,
        isActive: s.is_active,
        is_active: s.is_active,
        type: s.product,
        createdAt: s.service_created_at,
        updatedAt: s.service_updated_at
      }, s);
    });

    assetListArray.push(...serviceList);
    return assetListArray;
  }

  async checkAssetName(assetInfo) {

    const AssetData = await Asset.findOne({ where: { name: assetInfo['assetName'], is_active: { $ne: 'false' } }, attributes: ['id'] });
    if (AssetData) return true;

    const AssetDetailsData = await AssetDetail.findOne({ where: { realm: assetInfo['registeredName'] }, attributes: ['id'], include: [{ model: Asset, where: { is_active: { $ne: 'false' } }, attributes: ['id'] }] });
    if (AssetDetailsData) return true;

    const AssetVMNetworkData = await AssetVMNetwork.findOne({ where: { network_ip: assetInfo['ipAddress'] }, attributes: ['id'], include: [{ model: Asset, where: { is_active: { $ne: 'false' } }, attributes: ['id'] }] });
    if (AssetVMNetworkData) return true;

    return false;
  }

  async bulkCreateAssets(orgId, appId, subAppId, locationId, hostingProviderId, environmentId, userId, token, assetInfos = []) {
    logger.silly({ length: assetInfos.length }, `creating ${assetInfos.length} new assets`);

    return Promise.all(assetInfos.map(async (assetInfo) => {
      const exists = await this.checkAssetName(assetInfo);
      if (exists) {
        return;
      }
      await this.mutateAssetInfo(assetInfo, locationId, hostingProviderId);
      logger.info({ assetInfo }, 'the asset info to be created');
      const asset = await Asset.create(assetInfo);
      await Promise.all([
        asset,
        this.createVMAssetNetwork(asset.id, assetInfo),
        this.createAssetDetail(asset.id, assetInfo),
        subApplicationService.addAssetToSubApplication(subAppId, asset.id, userId, token, false)
      ]);
      if (environmentId) {
        await this.changeAssetEnvironment(asset.id, { environment_id: environmentId });
      }
      return asset;
    }));

  }

  async mutateAssetInfo(assetInfo, locationId, hostingProviderId) {
    assetInfo.organization_id = assetInfo.organization || assetInfo.organization_id || assetInfo.orgId;
    const org = await Organization.findByPk(assetInfo.organization_id);
    const hostingProvider = await HostingProvider.findByPk(hostingProviderId);
    const location = await Location.findByPk(locationId);
    logger.silly({ org, hostingProvider, location }, 'lookups');
    assetInfo.location = location.name;
    assetInfo.hosting_provider = hostingProvider.name;
    assetInfo.organization = org.name;
    assetInfo.parent_org_id = 0;//assetInfo.organization_id;
    assetInfo.source = 'Manual';
    assetInfo.type = 'vm';
    assetInfo.createdBy = assetInfo.createdBy || 'Manual';
    assetInfo.updatedBy = assetInfo.updatedBy || 'Manual';
    assetInfo.network = assetInfo.ipAddress;
    assetInfo.networkIp = assetInfo.ipAddress;

    assetInfo.realm = assetInfo.registeredName;
    assetInfo.asset_repo_type = 0;
    assetInfo.asset_manager_id = 0;
    assetInfo.privacy_identifier = 0;
    assetInfo.location_id = locationId;
    assetInfo.hosting_provider_id = hostingProviderId;
    assetInfo.vmId = uuid.v4();
  }

  async getAssetsByIds(orgId, ids) {
    let orgChain = await orgService.getOrgChain(orgId);
    orgChain = orgChain.map(o => o.organization_id);
    if (ids) {

      const assets = await Asset.findAll({
        where: { id: ids },
        include: [{ model: Organization }, { model: AssetVMNetwork }]
      });
      return assets.map(asset => {
        if (!orgChain.includes(asset.organizationId)) {
          return {
            id: asset.id,
            name: asset.name,
            createdAt: asset.createdAt,
            updatedAt: asset.updatedAt,
            message: 'asset not owned by organization'
          };
        }
        return asset;
      });
    }
    return [];
  }

  async getAssetListCountForOrg(assetList, orgId, managed) {
    let newArr = [];
    const org = await Organization.findByPk(orgId);
    if (org.type === 'Provider') {
      if (assetList === 'true' && managed === 'true') {
        const orgChain = await orgService.getProvider_SubOrg_SubOrgChain(org.id, 'sub-organization', null, null, true);
        newArr = orgChain.map((object) => {
          return object.id;
        });
        return sequelize
          .query(`select count(distinct(AssetListView.id)) from asset_list_view AS AssetListView INNER JOIN assets AS Assets ON AssetListView.id = Assets.id  AND (Assets.managed = 'true' OR Assets.managed IS NULL) where AssetListView.Organization_id in (` + newArr + `)`, { type: sequelize.QueryTypes.SELECT });

      }
      if (assetList === 'true') {
        const orgChain = await orgService.getProvider_SubOrg_SubOrgChain(org.id, 'sub-organization', null, null, true);
        newArr = orgChain.map((object) => {
          return object.id;
        });
        return sequelize
          .query(`select count(distinct(id)) from asset_list_view where Organization_id in (` + newArr + `)`, { type: sequelize.QueryTypes.SELECT });

      }
      if (assetList === 'false') {
        return sequelize
          .query(`select count(distinct(id)) from asset_list_view `, { type: sequelize.QueryTypes.SELECT });
      }
    } else {
      if (assetList === 'true' && managed === 'true') {
        const orgChain = await orgService.getOrgChain(org.id, true);
        newArr = orgChain.map((object) => {
          return object.dataValues.organization_id;
        });
        return sequelize
          .query(`select count(distinct(AssetListView.id)) from asset_list_view AS AssetListView INNER JOIN assets AS Assets ON AssetListView.id = Assets.id  AND (Assets.managed = 'true' OR Assets.managed IS NULL) where AssetListView.Organization_id in (` + newArr + `)`, { type: sequelize.QueryTypes.SELECT });

      }
      if (assetList === 'true') {
        const orgChain = await orgService.getOrgChain(org.id, true);
        newArr = orgChain.map((object) => {
          return object.dataValues.organization_id;
        });
        return sequelize
          .query(`select count(distinct(id)) from asset_list_view where Organization_id in (` + newArr + `)`, { type: sequelize.QueryTypes.SELECT });

      }
      if (assetList === 'false') {
        const orgChain = await orgService.getOrgChain(org.id, true);
        newArr = orgChain.map((object) => {
          return object.dataValues.organization_id;
        });
        return sequelize
          .query(`select count(distinct(id)) from asset_list_view where Organization_id in (` + newArr + `)`, { type: sequelize.QueryTypes.SELECT });

      }
    }
  }

  async getAssets(assetList, orgId, limit, offset) {
    logger.debug('Retrieving asset', { loggerLabel });
    const org = await Organization.findByPk(orgId);
    const orgChain = await orgService.getProvider_SubOrg_SubOrgChain(org.id, 'sub-organization', limit, offset, true);
    const newArr = orgChain.map((object) => {
      return object.id;
    });
    return sequelize
      .query(`(select id,name,network_ip from asset_list_view where Organization_id in (` + newArr + `))limit ? offset ?`, {
        replacements: [limit, offset],
        type: sequelize.QueryTypes.SELECT
      });
  }

  async getAssetsCount(assetList, orgId, limit, offset) {
    const org = await Organization.findByPk(orgId);
    const orgChain = await orgService.getProvider_SubOrg_SubOrgChain(org.id, 'sub-organization', limit, offset, true);
    const newArr = orgChain.map((object) => {
      return object.id;
    });
    return sequelize.query(`select count(*) from asset_list_view where Organization_id in (` + newArr + `)`, { type: sequelize.QueryTypes.SELECT });
  }

  async checkAssetCount(orgId, startDate, endDate) {
    startDate = startDate || moment().subtract(30, 'days').toDate();
    endDate = endDate || moment().toDate();
    const org = await Organization.findByPk(orgId);
    if (org.type === 'Provider') {
      const result = await sequelize.query(
        `select organization_id,organizations.name as organization_name,organizations.type as organization_type,  
        count(CASE WHEN (assets.is_active = 'unmanaged' or assets.is_active = 'disabled') THEN 1 END) as Unmanaged_Assets,
        count(CASE WHEN (assets.is_active = 'true' or assets.is_active = 'enabled') THEN 1 END) as Managed_Assets,
        count(CASE WHEN (assets.is_active = 'false') THEN 1 END) as Deleted_Assets,
        count(CASE WHEN (assets.is_active != '') THEN 1 END) as Total_Assets,
        to_char(date_trunc('hour',assets.created_at)::DATE,'mm-dd-yyyy') as created_date
        from assets,organizations where  assets.parent_org_id = 0 and assets.created_at BETWEEN :startDate and :endDate
        group by assets.organization_id,organizations.name,organizations.type,created_date
        order by created_date`, {
        replacements: { orgId, startDate, endDate },
        type: sequelize.QueryTypes.SELECT
      });
      return result;
    } else {
      const result = await sequelize.query(
        `select month, 
        sum(deleted)::numeric as deleted,
        round(sum(managed)::numeric/count(managed))::numeric as avg_managed,
        round(sum(unmanaged)::numeric/count(unmanaged))::numeric as avg_unmanged
        from ( 
        select to_char(dai.created_at, 'YYYY-MM') as month, 
                  (CASE WHEN (is_active = 'unmanaged' or is_active = 'disabled') THEN asset_count else 0 END) as unmanaged,
                  (CASE WHEN (is_active = 'true' or is_active = 'enabled') THEN asset_count else 0 END) as managed,
                  (CASE WHEN (is_active = 'false') THEN asset_count else 0 END) as deleted,
                  (CASE WHEN (is_active != '') THEN asset_count else 0 END) as total
        from daily_asset_summary dai 
        where  organization_id in 
                  ( ( WITH RECURSIVE org_cte( organization_id ) AS 
                  ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId
                  UNION ALL  SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id  WHERE c.parent_organization_id = p.organization_id ) 
                  SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id ) ) ) foo
          group by month order by month`, {
        replacements: { orgId, startDate, endDate },
        type: sequelize.QueryTypes.SELECT
      });
      return result;
    }
  }

  async checkAssetCountByNoOfDays(orgId, startDate, endDate) {
    const org = await Organization.findByPk(orgId);
    if (org.type === 'Provider') {
      const result = await sequelize.query(
        `select Unmanaged_Assets/noofdays as unmanaged, Managed_Assets/noofdays as managed, Deleted_Assets/noofdays as deleted, 
          Total_Assets/noofdays as total, noofdays
          from (
          select  
                    sum(CASE WHEN (assets.is_active = 'unmanaged' or assets.is_active = 'disabled') THEN asset_count END) as Unmanaged_Assets,
                    sum(CASE WHEN (assets.is_active = 'true' or assets.is_active = 'enabled') THEN asset_count END) as Managed_Assets,
                    sum(CASE WHEN (assets.is_active = 'false') THEN asset_count END) as Deleted_Assets,
                    sum(CASE WHEN (assets.is_active != '') THEN asset_count END) as Total_Assets,
                    trunc(date_part('day',:endDate::timestamp - :startDate::timestamp)) as noofdays
                    from daily_asset_summary as assets,organizations where  assets.organization_id=organizations.id and organization_id in 
                    ( ( WITH RECURSIVE org_cte( organization_id ) AS 
                    ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id 
                    UNION ALL  SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id  
                    WHERE c.parent_organization_id = p.organization_id ) 
                    SELECT * FROM org_cte AS n  ) ) and assets.created_at BETWEEN :startDate and :endDate ) as x`, {
        replacements: { startDate, endDate },
        type: sequelize.QueryTypes.SELECT
      });
      return result;
    }
  }

  async getTenantLevelRollUp(orgId, startDate, endDate) {
    const org = await Organization.findByPk(orgId);
    if (org.type === 'Provider') {
      const result = await sequelize.query(
        `select created_date, name, unmanaged_assets, managed_assets, deleted_assets, total_assets
          from (
          select parent_organization_id,created_date, sum (unmanaged_assets) as unmanaged_assets, 
                 sum(managed_assets) as managed_assets, sum(deleted_assets) as deleted_assets, sum(total_assets) as total_assets
          from (          
          select n.organization_id, (CASE WHEN (parent_organization_id = -1) THEN n.organization_id ELSE parent_organization_id END),
          x.path, x.depth,organization_name ,Unmanaged_Assets, Managed_Assets, Deleted_Assets,Total_Assets,created_date
          from (  
          select organization_id, organization_name ,Unmanaged_Assets, Managed_Assets, Deleted_Assets,Total_Assets,created_date
          from (
          select organization_id,organizations.name as organization_name,organizations.type as organization_type,  
                    count(CASE WHEN (assets.is_active = 'unmanaged' or assets.is_active = 'disabled') THEN 1 END) as Unmanaged_Assets,
                    count(CASE WHEN (assets.is_active = 'true' or assets.is_active = 'enabled') THEN 1 END) as Managed_Assets,
                    count(CASE WHEN (assets.is_active = 'false') THEN 1 END) as Deleted_Assets,
                    count(CASE WHEN (assets.is_active != '') THEN 1 END) as Total_Assets,
                    to_char(date_trunc('hour',assets.created_at)::DATE,'dd-mm-yyyy') as created_date
                    from assets,organizations where  assets.organization_id=organizations.id and organization_id in 
                    ( ( WITH RECURSIVE org_cte( organization_id ) AS 
                    ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id 
                    UNION ALL  SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id  
                    WHERE c.parent_organization_id = p.organization_id ) 
                    SELECT * FROM org_cte AS n  ) ) and assets.created_at BETWEEN :startDate and :endDate
                    group by to_char(date_trunc('hour',assets.created_at)::DATE,'dd-mm-yyyy'), organization_id,organizations.name,organizations.type  
                    order by to_char(date_trunc('hour',assets.created_at)::DATE,'dd-mm-yyyy'), organization_id ) as t) as n,           
                    ( WITH RECURSIVE org_cte(organization_id,  parent_organization_id, depth, path) AS (
           SELECT tn.organization_id,  tn.parent_organization_id, 1::INT AS depth, tn.organization_id::TEXT AS path
           FROM org_chains AS tn  
          UNION ALL
           SELECT c.organization_id, c.parent_organization_id, p.depth + 1 AS depth, (p.path || '->' || c.organization_id::TEXT)
            FROM org_cte AS p, org_chains AS c WHERE c.parent_organization_id = p.organization_id
          )
          SELECT * FROM org_cte AS n) as x
          where  n.organization_id = x.organization_id ) as f
          group by parent_organization_id,created_date ) as t, organizations o
          where t.parent_organization_id = o.id ;`, {
        replacements: { startDate, endDate },
        type: sequelize.QueryTypes.SELECT
      });
      return result;
    }
  }

  async ChangeAssetState(assetId, update) {
    const managed = update.managed;
    await Asset.update({ managed: managed }, { where: { id: { $in: assetId } } });
    return Asset.findAll({ where: { id: { $in: assetId } } });
  }

  async ChangeNetworkIp(assetId, update) {
    const networkIp = update.network_ip;
    await sequelize.query(
      `update asset_vm_network_details set network_ip=:network_ip where asset_id=:asset_id and 
      id in (select id from asset_vm_network_details where asset_id =:asset_id ORDER BY updated_at desc limit 1)`, {
      replacements: { network_ip: networkIp, asset_id: assetId },
      type: sequelize.QueryTypes.SELECT
    });
    return sequelize.query(
      `select * from  asset_vm_network_details  where asset_id=:asset_id and network_ip=:network_ip`, {
      replacements: { asset_id: assetId, network_ip: networkIp },
      type: sequelize.QueryTypes.SELECT
    });
  }

  async startAssetDiscovery(ipAddress, params) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const userToken = params.userToken;
    const userId = params.userId;
    const orgId = params.orgId;
    const ipRange = params.ipRange;
    const type = params.type;
    const ccUrl = `${ipAddress}/ec/api/v1/startPortScanner/?userToken=${userToken}&userId=${userId}&orgId=${orgId}&ipRange=${ipRange}&type=${type}`;
    logger.info({ ccUrl, params }, 'the url and params');
    // if(type == 'tenant'){
    //   request({
    //     url: ccUrl,
    //     method: 'POST'
    //   }, function (error, response, body) {
    //     if (error) {
    //       let err = new Error('CentralCollector request error' + error);
    //       err.status = 404;
    //       throw err;
    //     }
    //     logger.info("Asset Discovery Result ");
    //     if (response.statusCode == 200 || response.statusCode == 202) {
    //       checkStatus = false;
    //       logger.info("Status: " + response.statusCode + " Status Message: Success");
    //     } else {
    //       logger.info("Status: " + response.statusCode + " Status Message: Failed");
    //     }
    //   });
    // }else{
    let response;
    try {
      response = await rp.post({ url: ccUrl, json: true, rejectUnauthorized: false, resolveWithFullResponse: true });
    } catch (error) {
      logger.error({ error, response }, 'error occurred in response');
      const err = new Error('Error in Asset Discovery' + error);
      err.status = 400;
      throw err;
    }

    // todo look into this error
    const error = '';
    if (response.statusCode === 200 || response.statusCode === 202) {
      if (response.body) {
        return response.body;
      } else {
        const err = new Error('Error in Asset Discovery' + error);
        err.status = 404;
        throw err;
      }

    } else {
      const err = new Error('Error in Asset Discovery' + error);
      err.status = 404;
      throw err;
    }
    // }
  }

  async deleteById(assetId, orgId) {
    const assetdetails = await Asset.findOne({ where: { $and: [{ id: assetId, source: { $eq: 'Manual' } }] } });
    if (!assetdetails) {
      const err = new Error('Please select manually added asset.');
      err.status = 400;
      throw err;
    }
    await Asset.update({ isActive: false }, { where: { id: assetId } });
    return Asset.findByPk(assetId);
  }

  async deleteMultipleAssets(assetIdList, orgId) {
    const assetDetails = await Asset.findAll({
      where: {
        $and: [{
          id: { $in: assetIdList },
          source: { $eq: 'Manual' }
        }]
      }
    });
    if (assetDetails.length <= 0) {
      const err = new Error('Please select manually added assets.');
      err.status = 400;
      throw err;
    }
    const assetIds = [];
    for (let i = 0; i < assetDetails.length; i++) {
      const asset = assetDetails[i];
      const assetId = asset.id;
      assetIds.push(assetId);
    }
    await Asset.update({ isActive: false }, { where: { id: assetIds } });
    return Asset.findAll({ where: { id: { $in: assetIds } } });
  }
};
