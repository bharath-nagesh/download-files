const AssetController = require('./asset.controller');
const express = require('express');
const PolicyGroupController = require('../subApplication/subApplication.controller');
const router = express.Router({mergeParams:true});

// router.post('/', Controller.createAsset);

const assetController = new AssetController();
router.get('/:assetId', assetController.getAssetById);
router.put('/:assetId', assetController.updateAsset);
router.delete('/deleteAsset/:assetId', assetController.deleteAssetbyId);

router.get('/:assetId/vm/:vmId', assetController.getAssetByVmId);
router.get('/:assetId/assetDetail', assetController.getAssetDetail);
router.post('/:assetId/assetDetail', assetController.createAssetDetail);

router.get('/:assetId/assetNetwork', assetController.getAssetNetwork);

router.get('/:assetId/assetNetwork/physicalNetwork', assetController.getPhysicalAssetNetwork);
router.post('/:assetId/assetNetwork/physicalNetwork', assetController.createPhysicalAssetNetwork);

router.get('/:assetId/assetNetwork/vmNetwork', assetController.getVMAssetNetwork);
router.post('/:assetId/assetNetwork/vmNetwork', assetController.createVMAssetNetwork);

const policyGroupController = new PolicyGroupController();
router.get('/:assetId/subApplication', policyGroupController.getAssetPolicyGroup);
router.get('/:assetId/subApplication/:policyGroupId', policyGroupController.getPolicyGroupById);
router.put('/:assetId/subApplication/:policyGroupId', policyGroupController.addAssetToPolicyGroup);
router.delete('/:assetId/subApplication/:policyGroupId', policyGroupController.removeAssetToPolicyGroup);

module.exports = router;
