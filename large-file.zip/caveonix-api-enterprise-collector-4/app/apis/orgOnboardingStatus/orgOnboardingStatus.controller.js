const errorHandler = require('../../../utils/errorHandler');
const logger = require('../../../utils/logger').logger;
const OrgOnboardingStatusService = require('./orgOnboardingStatus.service');
const Validator = require('../../../utils/validator');

const orgOnboardingStatusService = new OrgOnboardingStatusService();
const loggerLabel = 'OrgOnboardingStatusController';

module.exports = class OrgOnboardingStatusController {
  async getOrgOnboardingStatus(req, res) {
    const orgId = req.params.serviceProviderId ? req.params.serviceProviderId : req.params.orgId;
    try {
      const orgOnboardingStatus = await orgOnboardingStatusService.getOrgOnboardingStatus(orgId);

      return res.json(orgOnboardingStatus);
    } catch (error) {
      logger.error('Error occurred while attempting retrieve org on boarding status', { error, loggerLabel });
      return errorHandler(req, res, error);
    }
  }

  async updateOrgOnboardingStatus(req, res) {
    const orgId = req.params.serviceProviderId ? req.params.serviceProviderId : req.params.orgId;
    const params = req.body;
    try {
      params.isActive = params.isActive ? params.isActive.toString().toLowerCase() : 'enabled';
      await Validator.validateParams({
        onboarding_step_id: 'required|integer',
        status: 'required|string'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    try {
      const orgOnboardingStatus = await orgOnboardingStatusService.updateOrgOnboardingStatus(orgId, params);
      return res.json(orgOnboardingStatus);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }
};
