const Sequelize = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();

/**
 * @swagger
 * components:
 *   schemas:
 *     OrgOnboardingStatus:
 *       type: object
 *       required:
 *         - organization_id
 *         - onboarding_step_id
 *         - status
 *       properties:
 *         organization_id:
 *           type: string
 *         onboarding_step_id:
 *           type: string
 *         status:
 *           type: string
 * @param sequelize
 */
class OrgOnboardingStatus extends Sequelize.Model {
  static init(sequelize) {
    return super.init({
        id: {
          type: Sequelize.INTEGER,
          primaryKey: true,
          autoIncrement: true
        },
        // organization_id: { type: Sequelize.INTEGER, field: 'organization_id', allowNull: false },
        // onboarding_step_id: { type: Sequelize.INTEGER, field: 'onboarding_step_id', allowNull: false },
        status: { type: Sequelize.STRING, field: 'status', allowNull: false },
        type: {
          type: Sequelize.ENUM(['Provider', 'Organization']),
          field: 'type',
          allowNull: false,
          default: 'Organization'
        }

      },
      {
        sequelize,
        timestamps: true,
        freezeTableName: true,
        tableName: 'organization_onboarding_status',
        underscored: true
      });
  }

  static associate(models) {
    OrgOnboardingStatus.belongsTo(models.Organization);
    OrgOnboardingStatus.belongsTo(models.OnboardingSteps);
  };
}

module.exports = OrgOnboardingStatus;
