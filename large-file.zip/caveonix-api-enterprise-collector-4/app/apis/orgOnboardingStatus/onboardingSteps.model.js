const Sequelize = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();
const OnboardingSteps = sequelize.define(
  'OnboardingSteps',
  {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    name: { type: Sequelize.STRING, field: 'name', allowNull: false }
  },
  {
    timestamps: false,
    freezeTableName: true,
    tableName: 'onboarding_steps',
    underscored: true
  }
);

module.exports = OnboardingSteps;
