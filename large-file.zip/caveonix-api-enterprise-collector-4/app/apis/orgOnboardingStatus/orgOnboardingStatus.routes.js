const OrgOnboardingStatusController = require('./orgOnboardingStatus.controller');

/**
 * @swagger
 * tags:
 *  - name: OrgOnboardingStatus
 *    description: Org Onboarding Status endpoints
 */
module.exports = class OrgOnboardingStatusRoutes {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.orgOnboardingStatusController = new OrgOnboardingStatusController();

      // initializing route
      this.initOrganization();
    }
  }

  initOrganization() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/orgOnboardingStatus:
     *   get:
     *     tags:
     *       - OrgOnboardingStatus
     *     summary: Gets the current onboarding status
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of org onboarding status
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/`, this.orgOnboardingStatusController.getOrgOnboardingStatus);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/orgOnboardingStatus:
     *   put:
     *     tags:
     *       - OrgOnboardingStatus
     *     summary: Updates the Onboarding Status
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/OrgOnboardingStatus'
     *     responses:
     *       200:
     *         description: orgOnboardingStatus
     */
    this.router.put(`${this.path}/`, this.orgOnboardingStatusController.updateOrgOnboardingStatus);
  }

  initServiceProvider() {
    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/orgOnboardingStatus:
     *   get:
     *     tags:
     *       - OrgOnboardingStatus
     *     summary: Gets the current org onboarding status
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: OrgOnboardingStatus
     */
    this.router.get(`${this.path}/`, this.orgOnboardingStatusController.getOrgOnboardingStatus);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/orgOnboardingStatus:
     *   put:
     *     tags:
     *       - OrgOnboardingStatus
     *     summary: Updates the Onboarding Status
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/OrgOnboardingStatus'
     *     responses:
     *       200:
     *         description: Org Onboarding Status
     *       400:
     *          description: Bad Request
     */
    this.router.put(`${this.path}/`, this.orgOnboardingStatusController.updateOrgOnboardingStatus);
  }
};
