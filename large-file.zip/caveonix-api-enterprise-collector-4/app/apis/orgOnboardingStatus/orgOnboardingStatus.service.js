const logger = require('../../../utils/logger').logger;
const OnboardingSteps = require('./onboardingSteps.model');
const OrgOnboardingStatus = require('./orgOnboardingStatus.model');
const Organization = require('../organization/organization.model');

const loggerLabel = 'OrgOnboardingStatusService';

module.exports = class OrgOnboardingStatusService {
  constructor(services) {
    logger.debug('called OrgOnboardingStatusService constructor');
  }

  async getOrgOnboardingStatus(orgId) {
    logger.debug('Retrieving org onboarding status', { loggerLabel });
    logger.silly(`for orgId ${orgId}`, { loggerLabel });

    const organization = await Organization.findOne({ where: { id: orgId } });
    let currentStep = await OrgOnboardingStatus.findOne({
      attributes: [Organization.sequelize.fn('MAX', Organization.sequelize.col('OnboardingStep.id')), 'status'],
      where: { type:organization.type },
      include: [{
        model: Organization,
        where: { id: orgId },
        attributes: [],
        required: true
      }, { model: OnboardingSteps }],
      order: [['onboarding_step_id', 'DESC']],
      group: ['onboarding_step_id', 'OnboardingStep.id', 'status']
    });
    let eulaStep = await OrgOnboardingStatus.findOne({
      where: { type:organization.type },
      include: [{ model: Organization, where: { id: orgId }, attributes: [], required: true }, {
        model: OnboardingSteps,
        where: { id: 0 },
        attributes: [],
        required: true
      }]
    });
    if (currentStep) {
      currentStep.OnboardingStep.setDataValue('status', currentStep.status);
      currentStep = currentStep.OnboardingStep;
    }

    eulaStep = eulaStep || { onboarding_step_id: 0, status: 'Not Completed' };
    return { currentStep, eulaStep };
  }

  async updateOrgOnboardingStatus(orgId, params) {
    const exists = await Organization.findOne({ where: { id: orgId } });
    if (!exists) {
      const err = new Error('Organization not found.');
      err.status = 400;
      throw err;
    }
    params.type = exists.type;
    if (params.status.toLowerCase() === 'accepted') {
      const orgOnboardingStatus = await OrgOnboardingStatus.findOne({
        where: {
          organization_id: orgId,
          type: exists.type,
          onboarding_step_id: { $eq: 0 }
        }
      });
      if (!orgOnboardingStatus) {
        params.organization_id = orgId;
        const newOrgOnboardingStatus = await OrgOnboardingStatus.create(params);
        return newOrgOnboardingStatus;

      }

    } else {
      const orgOnboardingStatus = await OrgOnboardingStatus.findOne({
        where: {
          organization_id: orgId,
          type: exists.type,
          onboarding_step_id: { $ne: 0 }
        }
      });
      if (orgOnboardingStatus) {
        await OrgOnboardingStatus.update(params, {
          where: {
            organization_id: orgId,
            type: exists.type,
            id: orgOnboardingStatus.id
          }
        });
        return this.getOrgOnboardingStatus(orgId);

      } else {
        params.organization_id = orgId;
        return OrgOnboardingStatus.create(params);
      }
    }

  }
};
