const Asset = require('../asset/asset.model');
const AssetRepoEndpoint = require('./assetRepoEndpoint.model');
const AssetDetail = require('../asset/assetDetail.model');
const AssetRepoEndpointMembers = require('./assetRepoEndpointMembers.model');
const AssetRepoType = require('./assetRepoType.model');
const { get, has, toLower } = require('lodash');
const HostingProvider = require('../hostingProvider/hostingProvider.model');
const AWS = require('aws-sdk');
const { Resource } = require('@google-cloud/resource');
const msRestNodeAuth = require('@azure/ms-rest-nodeauth');
const KeyGenerator = require('../../../utils/generateKeys');
const ldap = require('@caveonix/ldapjs');
const Location = require('../location/location.model');
const logger = require('../../../utils/logger').logger;
const SecurityHubDetails = require('../aws/securityHubDetails.model');
const MasterNode = require('../../models/masterNode.model');
const NetworkNetflow = require('../../models/networkNetflow.model');
const ObjTree = require('xml-objtree');
const objTree = new ObjTree();
const { Op } = require('sequelize');
const Organization = require('../organization/organization.model');
const PolicyGroupAssetMembers = require('../subApplication/subApplicationAssetMembers.model');
const removeSpace = require('../../../utils/checkSpaces');
const rp = require('request-promise');
const ScheduleTask = require('../../models/scheduleTask.model');
const sequelize = require('../../../config/db.conf').getConnection();
const validator = require('validator');
const VMCVcenterDetails = require('../../models/vmcVcenterDetails.model');
const VcdVcenterDetails = require('../../models/vcdVcenterDetails.model');
const OrgVCenter = require('../../models/orgVcenter.model');
const OrgLicense = require('../organization/orgLicense.model');
const VcenterResourceMappings = require('../../models/vcenterResourceMappings.model');
const CentralCollectorClient = require('../../../utils/centralCollector.client');
const config = require('../../../configure').get();
const cc_timeout = config.cc_timeout || 15000;
const _ = require('lodash');
const isAppliance = require('../../../utils/isAppliance');
const SERVICE_TYPE = isAppliance() ? 'ec' : 'centralcollector';
const AWSKMSService = require('../aws/awsKMS.service');
const awsKMSService = new AWSKMSService();

const loggerLabel = 'AssetRepoEndpointService';

module.exports = class AssetRepoEndpointService {
  constructor(services) {
    this.services = services;
    this.keyGenerator = new KeyGenerator();
    logger.debug('called constructor');
  }

  async getAssetRepoEndpoint(assetRepoEndpointId, orgId) {
    const include = [
      { model: SecurityHubDetails },
      {
        model: AssetRepoEndpointMembers,
      },
      { model: AssetRepoType },
      { model: Organization, attributes: ['id', 'name', 'aliasName', 'fullName'] },
      { model: MasterNode },
      { model: VcenterResourceMappings }
    ];
    const ifNotAppliance = [
      { model: HostingProvider, attributes: ['id', 'name'] },
      { model: Location, attributes: ['id', 'name'] },
      {
        model: NetworkNetflow,
        required: false,
        where: { is_active: { $ne: 'false' } }
      },
      { model: VMCVcenterDetails }, {
        model: VcdVcenterDetails,
        include: [{ model: Organization, attributes: ['name', 'aliasName', 'fullName'] }]
      }
    ];

    if (!isAppliance()) include.push(...ifNotAppliance);
    const assetRepoEndpoint = await AssetRepoEndpoint.findByPk(assetRepoEndpointId, {
      where: { organization_id: orgId },
      include
    });
    if (get(assetRepoEndpoint, 'parameters')) {
      const paramData = assetRepoEndpoint.parameters.includes('sqs') ? JSON.parse(assetRepoEndpoint.parameters) : null;
      assetRepoEndpoint.dataValues.ec2Notifications = paramData && paramData.sqsQueueName ? true : false;
      try {
        assetRepoEndpoint.dataValues.parameters = JSON.parse(assetRepoEndpoint.parameters);
      } catch (e) {
        assetRepoEndpoint.dataValues.parameters = assetRepoEndpoint.parameters;
      }
      if (assetRepoEndpoint.dataValues.parameters.assumeRole) {
        assetRepoEndpoint.dataValues.assumeRole = assetRepoEndpoint.dataValues.parameters.assumeRole;
      }
      if (assetRepoEndpoint.dataValues.parameters.assetApplicationTag) {
        assetRepoEndpoint.dataValues.assetApplicationTag = assetRepoEndpoint.dataValues.parameters.assetApplicationTag;
      }
    }
    if (assetRepoEndpoint.asset_repo_type_id == 2) {
      assetRepoEndpoint.dataValues.tenantCreation = assetRepoEndpoint.parameters ? 'auto' : 'manual';
      assetRepoEndpoint.dataValues.resourceType = assetRepoEndpoint.parameters ? assetRepoEndpoint.parameters : null;
      assetRepoEndpoint.dataValues.parameters = '';
    }
    return this.manageVcenterResourceMappings(assetRepoEndpoint);
  }

  manageVcenterResourceMappings(assetRepoEndpoint) {
    const folderObject = [];
    const clusterNameObject = [];
    const dataCenterObject = [];
    const resourcePoolObject = [];
    if (assetRepoEndpoint.VcenterResourceMappings && assetRepoEndpoint.VcenterResourceMappings.length > 0) {
      for (let i = 0; i < assetRepoEndpoint.VcenterResourceMappings.length; i++) {
        const oneResourceMapping = assetRepoEndpoint.VcenterResourceMappings[i];
        if (oneResourceMapping.folder) folderObject.push(oneResourceMapping.folder);
        if (oneResourceMapping.clusterName) clusterNameObject.push(oneResourceMapping.clusterName);
        if (oneResourceMapping.dataCenter) dataCenterObject.push(oneResourceMapping.dataCenter);
        if (oneResourceMapping.resourcePool) resourcePoolObject.push(oneResourceMapping.resourcePool);

        assetRepoEndpoint.dataValues.folderName = folderObject;
        assetRepoEndpoint.dataValues.clusterName = clusterNameObject;
        assetRepoEndpoint.dataValues.dataCenter = dataCenterObject;
        assetRepoEndpoint.dataValues.resourcePool = resourcePoolObject;
      }
    }

    return assetRepoEndpoint;
  }

  async getAllAssetRepoEndpoints(orgId, limit, offset, type, isServiceProvider, dropdown = false, parametersCheck = 'any') {
    logger.debug('Retrieving all asset repo endpoints', { loggerLabel });

    const adType = await AssetRepoType.findOne({ where: { name: 'Active Directory' } });
    const adBothType = await AssetRepoType.findOne({ where: { name: 'Active Directory Both' } });
    const repoTypeClause = [{ asset_repo_type_id: { $ne: adType.id } }, { asset_repo_type_id: { $ne: adBothType.id } }];

    if (!type || type !== 'All') {
      const data = await AssetRepoType.findOne({
        where: {
          name: sequelize.where(sequelize.fn('LOWER', sequelize.col('name')), sequelize.fn('lower', type)),
          isActive: { $ne: 'false' }
        }
      });

      if (!data) {
        const err = new Error(`Asset Repo Type(${type}) does not exist.`);
        err.status = 400;
        throw err;
      }

      const typeId = data.dataValues.id;
      repoTypeClause.push({ asset_repo_type_id: typeId });
    }
    let include = [
      { model: AssetRepoType, attributes: ['name'] },
      { model: Organization, attributes: ['id', 'name', 'aliasName', 'fullName'] }
    ];
    let condition = ['false'];
    let attributes = ['id', 'connectionName', 'username', 'isActive','name'];
    if (dropdown && dropdown === 'true') {
      condition = ['false', 'disabled', 'unmanaged'];
      attributes = ['id', 'connectionName', 'isActive', 'parameters', 'ecHostName', 'name'];
      include = [{ model: Organization, attributes: ['name', 'aliasName', 'fullName'] }];
    }
    const where = { $and: repoTypeClause, isActive: { $notIn: condition } };
    if (parametersCheck === 'isempty') {
      where.parameters = {$or: {$is: null, $eq: ''}};
    }

    return AssetRepoEndpoint.findAll({
      attributes,
      where,
      order: [['connectionName', 'ASC']],
      include,
      limit: limit,
      offset: offset
    });
  }

  async getAssetRepoEndpointsCount(orgId, type, parentChain = false) {
    const adType = await AssetRepoType.findOne({ where: { name: 'Active Directory' } });
    const adBothType = await AssetRepoType.findOne({ where: { name: 'Active Directory Both' } });
    if (!type || type === 'All') {
      return AssetRepoEndpoint.count({
        where: {
          $and: [{ asset_repo_type_id: { $ne: adType.id } }, { asset_repo_type_id: { $ne: adBothType.id } }],
          $or: [{ isActive: { $ne: 'false' } }]
        }
      });
    }
    const data = await AssetRepoType.findOne({
      where: {
        name: sequelize.where(sequelize.fn('LOWER', sequelize.col('name')), sequelize.fn('lower', type)),
        $or: [{ is_active: { $ne: 'false' } }]
      }
    });
    if (!data) return 0;
    return AssetRepoEndpoint.count({
      where: {
        asset_repo_type_id: data.id,
        isActive: { $ne: 'false' }
      }
    });
  }

  async updateAssetRepoEndpoint(loggedInUserId, userToken, assetRepoEndpointId, params, orgId) {
    if (params.connectionName.slice(-1) == '/') {
      params.connectionName = params.connectionName.slice(0, -1);
    }
    const connectionName = params.connectionName;
    const typeId = params.type_id;
    let username = params.username;
    const isActive = params.isActive;
    const newConnName = removeSpace.checkMultiSpace(connectionName);
    const scheduleIdArr = [];
    let ctr = 0;
    params.asset_repo_endpoint_id = assetRepoEndpointId;
    let sourceIdArr, newPassword;
    const exists = await this.checkType(typeId);
    if (!exists) {
      const err = new Error('Asset Repo Type does not exists.');
      err.status = 400;
      throw err;
    }
    const typeCheck = exists;
    if (params.sourceId && typeCheck.name.toLowerCase() === 'nsx-t') {
      sourceIdArr = params.sourceId.split(',');
    }
    if (typeCheck.name.toLowerCase() === 'vmc') {
      username = '';
    }
    const newUserName = removeSpace.removeAllSpaces(username);
    const exist = await this.checkNameForUpdate(newConnName, newUserName, assetRepoEndpointId, orgId);
    if (exist) {
      const err = new Error('Connection Name and Username already exists.');
      err.status = 400;
      throw err;
    }
    if (params.password) {
      newPassword = await this.keyGenerator.generateKeys(params.password);
      // TODO: Important remove comment after senthil testing.
      // params.password = config.saas ? 'dummy' : newPassword;
      params.password = newPassword; // TODO Remove this line after uncommneting above line
    }
    const locationId = params.location_id;
    const hostingProviderId = params.hosting_provider_id;
    const name = exists.name;
    if (name.toLowerCase() === 'vcd' || name.toLowerCase() === 'vcenter') {
      const assetRepoMembers = await AssetRepoEndpointMembers.findAll({ where: { asset_repo_enpoint_id_source_id: assetRepoEndpointId } });
      if (assetRepoMembers) {
        for (let i = 0; i < assetRepoMembers.length; i++) {
          const assetRepoEndpointId = assetRepoMembers[i].linkId;
          const result = await AssetRepoEndpoint.findOne({
            where: {
              id: assetRepoEndpointId,
              $or: [{ is_active: { $ne: 'false' } }]
            }
          });
          if (result) {
            const Id = result.id;
            await AssetRepoEndpoint.update({ location_id: locationId, hosting_provider_id: hostingProviderId }, {
              where: { id: Id }
            });
          }
        }
      }
    }
    params.connectionName = newConnName;
    params.username = newUserName;
    params.asset_repo_type_id = typeId;
    params.id = assetRepoEndpointId;
    const assetRepoEndpoint = await AssetRepoEndpoint.update(params, {
      where: { id: assetRepoEndpointId }
    });
    const assetRepoMember = await AssetRepoEndpointMembers.findOne({ where: { asset_repo_enpoint_id_link_id: assetRepoEndpointId } });
    delete params['id'];
    if (assetRepoMember) {
      if (params.sourceId) {
        if (name.toLowerCase() === 'nsx-t') {
          await AssetRepoEndpointMembers.destroy({ where: { asset_repo_enpoint_id_link_id: assetRepoEndpointId } });
          const sourceIdArray = params.sourceId.split(',');
          for (let i = 0; i < sourceIdArray.length; i++) {
            params.sourceId = sourceIdArray[i];
            params.linkId = assetRepoEndpointId;
            await AssetRepoEndpointMembers.create(params);
          }
        } else {
          await AssetRepoEndpointMembers.update(params, {
            where: { asset_repo_enpoint_id_link_id: assetRepoEndpointId }
          });
        }
      }
    } else {
      if (params.sourceId) {
        if (name.toLowerCase() === 'nsx-t') {
          const sourceIdArray = params.sourceId.split(',');
          for (let i = 0; i < sourceIdArray.length; i++) {
            params.sourceId = sourceIdArray[i];
            params.linkId = assetRepoEndpointId;
            await AssetRepoEndpointMembers.create(params);
          }
        } else {
          params.linkId = assetRepoEndpointId;
          await AssetRepoEndpointMembers.create(params);
        }
      }
    }
    if (params.observation_domain_id) {
      await this.updateNetworkNetflows(assetRepoEndpointId, params.observation_domain_id);
    }
    if (name.toLowerCase() === 'kubernetes' || name.toLowerCase() === 'openstack') {
      const masternode = await MasterNode.findOne({ where: { asset_repo_endpoint_id: assetRepoEndpointId } });
      if (masternode) {
        await MasterNode.update(params, {
          where: { asset_repo_endpoint_id: assetRepoEndpointId }
        });
      } else {
        await MasterNode.create(params);
      }
    }
    if (name.toLowerCase() === 'aws') {
      params.parameters = await this.createAwsResources(assetRepoEndpointId, params);

    }
    // creating mappings for vCenter
    if (name.toLowerCase() === 'vcenter') {
      let parameters = null;
      if (params.resourceType) {
        parameters = params.resourceType;
        params.parameters = parameters;
        await AssetRepoEndpoint.update({ parameters }, { where: { id: assetRepoEndpointId } });
      }
      await this.createVcenterResourceMappings(assetRepoEndpointId, params.folder, params.clusterName, params.dataCenter, params.resourcePool);
    }
    const result = await ScheduleTask.findAll({
      where: {
        asset_repo_id: assetRepoEndpointId,
        is_active: { $ne: 'false' }
      }
    });
    result.filter(function (object) {
      scheduleIdArr[ctr] = object.id;
      ctr++;
    });
    if (scheduleIdArr.length > 0) {
      await this.updateSchedules(scheduleIdArr, isActive);
    }

    if (name.toLowerCase() === 'nsx-t' || name.toLowerCase() === 'nsx-v' || name.toLowerCase() === 'nsx-v' || name.toLowerCase() === 'vmc' || name.toLowerCase() === 'vcd') {
      const source_org_id = orgId;
      const source_loc_id = params.location_id;
      const source_hosting_id = params.hosting_provider_id;
      const assetRepoInfo = await AssetRepoEndpoint.assetRepoInfo(assetRepoEndpointId, source_org_id, source_loc_id, source_hosting_id, name);
      if (('netflow_enabled' in params) && (params.netflow_enabled != null)) {
        const argumentsString = JSON.stringify({ netflow_enabled: params.netflow_enabled });
        params.parameters = JSON.parse(argumentsString);
        await AssetRepoEndpoint.update({ parameters: argumentsString }, { where: { id: assetRepoEndpointId } });
        try {
          if ((params.netflow_enabled === 'true') || (params.netflow_enabled === true)) {
            await this.netFlowOperations(loggedInUserId, userToken, orgId, assetRepoEndpointId, 'update', null, params);
          } else {
            try {
              await this.netFlowOperations(loggedInUserId, userToken, orgId, assetRepoEndpointId, 'delete', assetRepoInfo);
            } catch (error) {
              logger.error({
                error,
                action: 'delete',
                orgId,
                assetRepoEndpointId
              }, ' error occurred in netflow operations');
            }
          }
        } catch (error) {
          // Should not block updation on network call failure
          const err = new Error(error.message);
          err.status = 400;
          throw err;
        }
      }
    }
    if (name.toLowerCase() === 'vmc') {
      const vmcParams = {
        asset_repo_endpoint_vmc_id: params.asset_repo_endpoint_id,
        vcenter_url: params.vcenter_url,
        organization_id: params.organization_id,
        location_id: params.location_id,
        hosting_provider_id: params.hosting_provider_id,
        username: params.vcenter_user,
        password: params.vcenter_password,
        type_id: params.type_id
      };

      if (vmcParams.vcenter_url) {
        await this.encryptPassword(vmcParams);
        await VMCVcenterDetails.update(vmcParams, { where: { asset_repo_endpoint_vmc_id: params.asset_repo_endpoint_id } });
      }
    }
    try {
      const ccUrl = await CentralCollectorClient.CentralCollectorConnectionCheck();
      const url = `${ccUrl}/${SERVICE_TYPE}/api/v1/refresh/assetrepo/?userToken=` + userToken + '&userId=' + loggedInUserId + '&orgId=' + orgId;
      await rp.get(url, {
        json: true,
        rejectUnauthorized: false,
        resolveWithFullResponse: true
      });
    } catch (e) {
      logger.error(e);
    }
    if (config.saas) {
      params.id = assetRepoEndpointId;
      let ssmData;
      if (!newPassword) {
        ssmData = await this.storeGetAssetRepo(params);
      }
      const storeParams = {
        id: parseInt(assetRepoEndpointId),
        password: newPassword || ssmData.password,
        connection_name: params.connectionName,
        user_name: params.username,
        is_active: params.isActive,
        key: params.key || null,
        vcd_vms_only: params.vcd_vms_only || null,
        parameters: params.parameters || null,
        ec_host_name: params.ecHostName || null,
        port: params.port ? parseInt(params.port) : null,
        organization_id: parseInt(params.organization_id),
        asset_repo_type_id: parseInt(params.asset_repo_type_id),
        location_id: parseInt(params.location_id),
        hosting_provider_id: parseInt(params.hosting_provider_id)
      };
      //TODO Remove after testing
      if (typeId == '16') {
        storeParams.password = await this.keyGenerator.decryptKeys(storeParams.password);
      }
      await this.storeAddAssetRepo(storeParams);
      try {
        await awsKMSService.CentralCollectorServiceUpdate('assetRepo', assetRepoEndpointId, orgId, loggedInUserId, userToken);
      } catch (e) {
        logger.error(e);
      }
    }
    return this.getAssetRepoEndpoint(assetRepoEndpointId, orgId);
  }

  async updateNetworkNetflows(assetRepoEndpointId, observationDomainId) {
    const [networkNetflow, created] = await NetworkNetflow.findOrCreate({ where: { asset_repo_endpoint_id: assetRepoEndpointId } });
    await networkNetflow.update({ observationDomainId, asset_repo_endpoint_id: assetRepoEndpointId });
  }

  async createVcenterResourceMappings(assetRepoId, folder, clusterName, dataCenter, resourcePool) {
    let folderArray = [];
    let clusterArray = [];
    let dataCenterArray = [];
    let resourcePoolArray = [];
    if (folder && folder.length > 0) {
      //folderArray = folder.split(',');
      folderArray = [...new Set(folder)];
    }
    if (clusterName && clusterName.length > 0) {
      // clusterArray = clusterName.split(',');
      clusterArray = [...new Set(clusterName)];
    }
    if (dataCenter && dataCenter.length > 0) {
      //dataCenterArray = dataCenter.split(',');
      dataCenterArray = [...new Set(dataCenter)];
    }
    if (resourcePool && resourcePool.length > 0) {
      // resourcePoolArray = resourcePool.split(',');
      resourcePoolArray = [...new Set(resourcePool)];
    }

    await VcenterResourceMappings.destroy({ where: { asset_repo_endpoint_id: assetRepoId } });
    for (let i = 0; i < folderArray.length; i++) {
      const singleFolder = folderArray[i];
      await VcenterResourceMappings.create({
        asset_repo_endpoint_id: assetRepoId,
        resourcePool: '',
        dataCenter: '',
        folder: singleFolder,
        clusterName: ''
      });
    }
    for (let j = 0; j < clusterArray.length; j++) {
      const singleCluster = clusterArray[j];
      await VcenterResourceMappings.create({
        asset_repo_endpoint_id: assetRepoId,
        resourcePool: '',
        dataCenter: '',
        folder: '',
        clusterName: singleCluster
      });
    }
    for (let k = 0; k < dataCenterArray.length; k++) {
      const singleDataCenter = dataCenterArray[k];
      await VcenterResourceMappings.create({
        asset_repo_endpoint_id: assetRepoId,
        resourcePool: '',
        dataCenter: singleDataCenter,
        folder: '',
        clusterName: ''
      });
    }
    for (let l = 0; l < resourcePoolArray.length; l++) {
      const singleResourcePool = resourcePoolArray[l];
      await VcenterResourceMappings.create({
        asset_repo_endpoint_id: assetRepoId,
        resourcePool: singleResourcePool,
        dataCenter: '',
        folder: '',
        clusterName: ''
      });
    }
  }

  updateSchedules(scheduleIdArr, isActive) {
    return sequelize.query('update schedules set is_active= :isActive where id in (:scheduleIdArr)', {
      replacements: { scheduleIdArr, isActive }
    });
  }

  async getAssetRepoEndpointTypes(isServiceProvider, limit, offset) {
    const where = {
      $or: [{ is_active: { $ne: 'false' } }],
      $and: [{ name: { $ne: 'Active Directory' } }, { name: { $ne: 'Active Directory Both' } }]
    };
    if (!isServiceProvider) where.type = 'Organization';
    return AssetRepoType.findAll({
      where,
      order: [['name', 'ASC']],
      limit: limit,
      offset: offset
    });
  }

  async getAssetRepoEndpointTypesCount() {
    return AssetRepoType.count({
      where: {
        $or: [{ is_active: { $ne: 'false' } }],
        $and: [{ name: { $ne: 'Active Directory' } }, { name: { $ne: 'Active Directory Both' } }]
      }
    });
  }

  /**
   * Checks if the current connection name already exists. If it is Azure, the connection is a uuid so its case sensitive.
   * @param connectionName
   * @param username
   * @param assetRepoType
   * @returns {Promise<unknown>}
   */
  async checkConnName(connectionName, username, orgId) {
    const assetRepo = await AssetRepoEndpoint.findOne({
      where: {
        connectionName,
        username,
        organization_id: orgId
      }

    });
    if (!assetRepo) {
      return false;
    }
    return assetRepo;
  }

  checkKeyName(key) {
    return AssetRepoEndpoint.findOne({
      where: {
        key: sequelize.where(sequelize.fn('LOWER', sequelize.col('key')), sequelize.fn('lower', key)),
        $or: [{ isActive: { $ne: 'false' } }]
      }
    });
  }

  checkKeyForUpdate(key, assetRepoEndpointId) {
    return AssetRepoEndpoint.findOne({
      where: {
        key: sequelize.where(sequelize.fn('LOWER', sequelize.col('key')), sequelize.fn('lower', key)),
        $or: [{ isActive: { $ne: 'false' } }],
        id: { $ne: assetRepoEndpointId }
      }
    });
  }

  checkNameForUpdate(connectionName, username, assetRepoEndpointId, orgId) {
    return AssetRepoEndpoint.findOne({
      where: {
        [Op.or]: [{ connection_name: sequelize.where(sequelize.fn('LOWER', sequelize.col('connection_name')), sequelize.fn('lower', connectionName)) }],
        user_name: sequelize.where(sequelize.fn('LOWER', sequelize.col('user_name')), sequelize.fn('lower', username)),
        isActive: { $ne: 'false' },
        organization_id: { $eq: orgId },
        id: { $ne: assetRepoEndpointId }
      }
    });
  }

  async create(loggedInUserId, userToken, orgId, params) {
    params.organization_id = orgId;
    const typeId = params.type_id;
    if (params.connectionName.slice(-1) == '/') {
      params.connectionName = params.connectionName.slice(0, -1);
    }
    const connectionName = params.connectionName;
    let username = params.username;
    const newConnName = removeSpace.checkMultiSpace(connectionName);
    const typeCheck = await this.checkType(typeId);
    const repoType = toLower(typeCheck.name);
    if (repoType === 'vmc') {
      username = '';
    }
    const newUserName = removeSpace.removeAllSpaces(username);
    let sourceIdArr;
    if (params.sourceId && repoType === 'nsx-t') {
      sourceIdArr = params.sourceId.split(',');
      await this.checkVcenterExtracted(orgId, sourceIdArr);
    }
    const exists = await this.checkConnName(newConnName, newUserName, orgId);

    if (exists) {
      // if the user exists but is active then returning and error, otherwise making an update to the deleted item
      if (get(exists, 'isActive') !== 'false') {
        const err = new Error('Connection Name and Username already exists.');
        err.status = 400;
        throw err;
      } else {
        const assetRepoEndpointId = exists.id;
        if (repoType === 'aws') {
          await this.createAwsJobs(exists, loggedInUserId);
        }
        if (repoType === 'gcp') {
          await this.createGCPJobs(exists, loggedInUserId);
        }
        if (repoType === 'azure') {
          await this.createAzureJobs(exists, loggedInUserId);
        }
        return this.updateAssetRepoEndpoint(loggedInUserId, userToken, assetRepoEndpointId, params, orgId);
      }
    } else {
      params.connectionName = newConnName;
      params.asset_repo_type_id = typeId;
      delete params.id;
      const assetRepoUsername = newUserName;
      const assetRepoPassword = await this.keyGenerator.generateKeys(params.password);
      let assetRepoEndpoint;
      params.username = assetRepoUsername;
      if (config.saas) {
        // TODO: Important remove comment after senthil testing.
        // params.password = 'dummy';
        params.password = assetRepoPassword; // TODO Remove after testing
        assetRepoEndpoint = await AssetRepoEndpoint.create(params);
        params.password = assetRepoPassword;
      } else {
        params.password = assetRepoPassword;
        assetRepoEndpoint = await AssetRepoEndpoint.create(params);
      }

      // doing additional modifications and checks based off of repo type
      params.linkId = assetRepoEndpoint.id;
      params.asset_repo_endpoint_id = assetRepoEndpoint.id;

      // creating mappings for vCenter
      if (repoType === 'vcenter') {
        let parameters = null;
        if (params.resourceType) {
          parameters = params.resourceType;
          params.parameters = parameters;
          await AssetRepoEndpoint.update({ parameters }, { where: { id: assetRepoEndpoint.id } });
        }
        await this.createVcenterResourceMappings(assetRepoEndpoint.id, params.folder, params.clusterName, params.dataCenter, params.resourcePool);
      }

      if (params.sourceId) {
        if (repoType === 'nsx-t') {
          const sourceIdArray = params.sourceId.split(',');
          sourceIdArray.forEach(async (sourceId) => {
            params.sourceId = sourceId;
            await AssetRepoEndpointMembers.create(params);
          });
        } else {
          await AssetRepoEndpointMembers.create(params);
        }
      }
      if (params.observation_domain_id) {
        await this.updateNetworkNetflows(assetRepoEndpoint.id, params.observation_domain_id);
      }
      if (repoType === 'kubernetes' || repoType === 'openstack') {
        await MasterNode.create(params);
      }

      if (repoType === 'nsx-t' || repoType === 'nsx-v' || repoType === 'vmc' || repoType === 'vcd') {
        if (params.netflow_enabled) {
          const argumentsString = JSON.stringify({ netflow_enabled: params.netflow_enabled });
          params.parameters = JSON.parse(argumentsString);
          await AssetRepoEndpoint.update({ parameters: argumentsString }, { where: { id: assetRepoEndpoint.id } });
          try {
            if (params.netflow_enabled === 'true') {
              await this.netFlowOperations(loggedInUserId, userToken, orgId, assetRepoEndpoint.id, 'create', null);
            }
          } catch (error) {
            const err = new Error(error.message);
            err.status = 400;
            throw err;
          }
        }
      }

      if (repoType === 'vmc') {
        const vmcParams = {
          asset_repo_endpoint_vmc_id: assetRepoEndpoint.id,
          vcenter_url: params.vcenter_url,
          organization_id: params.organization_id,
          location_id: params.location_id,
          hosting_provider_id: params.hosting_provider_id,
          username: params.vcenter_user,
          password: params.vcenter_password,
          type_id: params.type_id
        };

        if (vmcParams.vcenter_url) {
          await this.encryptPassword(vmcParams);
          await VMCVcenterDetails.create(vmcParams);
        }
      }
      if (repoType === 'aws') {
        await this.createAwsJobs(assetRepoEndpoint, loggedInUserId);
        params.parameters = await this.createAwsResources(assetRepoEndpoint.id, params);
      }
      if (repoType === 'gcp') {
        await this.createGCPJobs(assetRepoEndpoint, loggedInUserId);
      }
      if (repoType === 'azure') {
        await this.createAzureJobs(assetRepoEndpoint, loggedInUserId);
      }
      if (!isAppliance()) {
        try {
          const ccUrl = await CentralCollectorClient.CentralCollectorConnectionCheck();
          const url = `${ccUrl}/${SERVICE_TYPE}/api/v1/refresh/assetrepo/?userToken=` + userToken + '&userId=' + loggedInUserId + '&orgId=' + orgId;
          await rp.get(url, {
            json: true,
            rejectUnauthorized: false,
            resolveWithFullResponse: true
          });
        } catch (e) {
          logger.error(e);
        }
      }
      if (config.saas) {
        const storeParams = {
          id: parseInt(assetRepoEndpoint.id),
          password: assetRepoPassword,
          connection_name: params.connectionName,
          user_name: params.username,
          is_active: params.isActive,
          key: params.key || null,
          vcd_vms_only: params.vcd_vms_only || null,
          parameters: params.parameters || null,
          ec_host_name: params.ecHostName || null,
          port: params.port ? parseInt(params.port) : null,
          organization_id: parseInt(params.organization_id),
          asset_repo_type_id: parseInt(params.asset_repo_type_id),
          location_id: parseInt(params.location_id),
          hosting_provider_id: parseInt(params.hosting_provider_id)
        };
        // TODO Remove
        if (typeId == '16') {
          storeParams.password = await this.keyGenerator.decryptKeys(assetRepoPassword);
        }
        await this.storeAddAssetRepo(storeParams);
        try {
          await awsKMSService.CentralCollectorServiceUpdate('assetRepo', assetRepoEndpoint.id, orgId, loggedInUserId, userToken);
        } catch (e) {
          logger.error(e);
        }
      }
      return this.getAssetRepoEndpoint(assetRepoEndpoint.id, orgId);
    }
  }

  async createAwsJobs(assetRepoEndpoint, userId) {
    const { organization_id: orgId, id: assetRepoId, connectionName } = assetRepoEndpoint;
    const cron = '0 0 0 1/1 * ? *';
    const orgDetails = await Organization.findOne({ where: { id: orgId }, attributes: ['id', 'name'] });
    const baseParams = { org_name: orgDetails.name, org_id: orgId, asset_repo_id: assetRepoId, user_id: userId, cron_expression: cron, isActive: 'enabled' };
    // TODO: hardcoded for now
    const jobsToCreate = [
      { id: 25, name: `AWS Asset Extract (${connectionName})` },
      { id: 26, name: `AWS Netflow Extract (${connectionName})` },
      { id: 44, name: `AWS Services Extract (${connectionName})` },
      { id: 45, name: `AWS CIS Compliance Scan (${connectionName})` }
    ];
    const jobs = await Promise.all(_.map(jobsToCreate, ({ id: jobId, name }) => {
      const params = _.clone(baseParams);
      params.job_id = jobId;
      params.name = name;
      return ScheduleTask.create(params);
    }));
    return jobs;
  }

  async createGCPJobs(assetRepoEndpoint, userId) {
    const { organization_id: orgId, id: assetRepoId, connectionName } = assetRepoEndpoint;
    const cron = '0 0 0 1/1 * ? *';
    const orgDetails = await Organization.findOne({ where: { id: orgId }, attributes: ['id', 'name'] });
    const baseParams = { org_name: orgDetails.name, org_id: orgId, asset_repo_id: assetRepoId, user_id: userId, cron_expression: cron, isActive: 'enabled' };
    // TODO: hardcoded for now
    const jobsToCreate = [
      { id: 46, name: `GCP Asset Extract (${connectionName})` },
      { id: 47, name: `GCP Services Extract (${connectionName})` },
      { id: 48, name: `GCP CIS Compliance Scan (${connectionName})` },
      { id: 54, name: `GCP Netflow Extract (${connectionName})` }
    ];
    const jobs = await Promise.all(_.map(jobsToCreate, ({ id: jobId, name }) => {
      const params = _.clone(baseParams);
      params.job_id = jobId;
      params.name = name;
      return ScheduleTask.create(params);
    }));
    return jobs;
  }

  async createAzureJobs(assetRepoEndpoint, userId) {
    const { organization_id: orgId, id: assetRepoId, connectionName } = assetRepoEndpoint;
    const cron = '0 0 0 1/1 * ? *';
    const orgDetails = await Organization.findOne({ where: { id: orgId }, attributes: ['id', 'name'] });
    const baseParams = { org_name: orgDetails.name, org_id: orgId, asset_repo_id: assetRepoId, user_id: userId, cron_expression: cron, isActive: 'enabled' };
    // TODO: hardcoded for now
    const jobsToCreate = [
      { id: 27, name: `Azure Asset Extract (${connectionName})` },
      { id: 28, name: `Azure Netflow Extract (${connectionName})` },
      { id: 49, name: `Azure Services Extract (${connectionName})` },
      { id: 50, name: `Azure CIS Compliance Scan (${connectionName})` }
    ];
    const jobs = await Promise.all(_.map(jobsToCreate, ({ id: jobId, name }) => {
      const params = _.clone(baseParams);
      params.job_id = jobId;
      params.name = name;
      return ScheduleTask.create(params);
    }));
    return jobs;
  }

  async createAwsResources(assetRepoEndpointId, params) {
    if (isAppliance()) return;
    const [securityHubDetail, created] = await SecurityHubDetails.findOrCreate({
      where: {
        asset_repo_endpoints_id: assetRepoEndpointId
      },
      defaults: {
        asset_repo_endpoints_id: assetRepoEndpointId,
        consume: params.consume,
        queueName: params.queueName,
        publish: params.publish,
        accountNumber: params.accountNumber
      }
    });
    if (!created) {
      await securityHubDetail.update({
        consume: params.consume,
        queueName: params.queueName,
        publish: params.publish,
        accountNumber: params.accountNumber
      });
    }
    // ec2Notifications
    // sqsQueueName
    // consume
    // publish
    // accountNumber
    // queueName
    let awsParams = {};
    if (params.ec2Notifications) {
      if (!params.sqsQueueName) {
        const e = new Error('Notifications Enabled but no Queue Name Received.');
        e.status = 400;
        throw e;
      }
      awsParams.sqsQueueName = params.sqsQueueName;
    }

    if (params.assumeRole) awsParams.assumeRole = params.assumeRole.trim();
    if (params.assetApplicationTag) awsParams.assetApplicationTag = params.assetApplicationTag;
    if (params.dataType) awsParams.dataType = params.dataType;

    if (Object.keys(awsParams).length <= 0) {
      awsParams = null;
    } else {
      awsParams = JSON.stringify(awsParams);
    }

    AssetRepoEndpoint.update({ parameters: awsParams }, { where: { id: assetRepoEndpointId } });
    return JSON.parse(awsParams);
  }

  /**T
   * Checks if the type exists and if it does encrypting the password
   * @param params
   * @returns {Promise<unknown>}
   */
  async encryptPassword(params) {
    const exists = await this.checkType(params.type_id);
    if (!exists) {
      const err = new Error('Invalid AssetRepoType.');
      err.status = 400;
      throw err;
    }
    return this.keyGenerator.generateKeys(params.password, params.key).then(newPassword => {
      params.password = newPassword;
    });
  }

  async createCRFAssetRepoEndpoint(loggedInUserId, userToken, orgId, params) {
    const service = this;
    params.organization_id = orgId;

    params.ConnectionName = params.vCDConnectionName;
    params.Username = params.vCDUserName;
    params.password = params.vCDPassword;
    const vcdAssetRepo = await this.createCRFAssetRepo(params);
    const sourceId = vcdAssetRepo.id;
    params.ConnectionName = params.lookupConnectionName;
    params.Username = params.lookupUserName;
    params.password = params.lookupPassword;
    const LookUpAssetRepo = await this.createCRFAssetRepo(params);
    const LinkId = LookUpAssetRepo.id;

    params.linkId = LinkId;
    params.sourceId = sourceId;
    await AssetRepoEndpointMembers.create(params);
    // return this.getAssetRepoEndpoint(sourceId, orgId);
    return AssetRepoEndpoint.findOne({ where: { id: sourceId, organization_id: orgId }, include: [{ all: true }] });
  }

  async createCRFAssetRepo(params) {
    const service = this;
    const type_id = params.typeId;
    params.type_id = params.typeId;
    if (params.ConnectionName.slice(-1) == '/') {
      params.ConnectionName = params.ConnectionName.slice(0, -1);
    }
    const ConnectionName = params.ConnectionName;
    const Username = params.Username;
    const newConnName = removeSpace.checkMultiSpace(ConnectionName);
    const newUserName = removeSpace.removeAllSpaces(Username);

    const exists = await this.checkConnName(newConnName, newUserName, params.organization_id);

    if (exists) {
      if (exists.isActive !== false) {
        const err = new Error('Connection Name and Username already exists.');
        err.status = 400;
        throw err;
      } else {
        await this.encryptPassword(params);
        const assetRepoId = exists.id;
        params.id = assetRepoId;
        params.connectionName = newConnName;
        params.username = newUserName;
        params.asset_repo_type_id = type_id;
        params.asset_repo_endpoint_id = assetRepoId;
        if (!params.location_id) {
          params.location_id = '0';
        }
        if (!params.hosting_provider_id) {
          params.hosting_provider_id = '0';
        }

        return AssetRepoEndpoint.update(params, { where: { id: assetRepoId } });
      }
    } else {
      await this.encryptPassword(params);
      params.connectionName = newConnName;
      params.username = newUserName;
      params.asset_repo_type_id = type_id;
      if (!params.location_id) {
        params.location_id = '0';
      }
      if (!params.hosting_provider_id) {
        params.hosting_provider_id = '0';
      }
      return AssetRepoEndpoint.create(params);
    }
  }

  async updateCRFAssetRepoEndpoint(loggedInUserId, userToken, assetRepoEndpointId, params, orgId) {
    if (params.vCDConnectionName.slice(-1) == '/') {
      params.vCDConnectionName = params.vCDConnectionName.slice(0, -1);
    }
    const connectionName = params.vCDConnectionName;
    const type_id = params.typeId;
    params.type_id = type_id;
    const username = params.vCDUserName;
    const newConnName = removeSpace.checkMultiSpace(connectionName);
    const newUserName = removeSpace.removeAllSpaces(username);
    params.asset_repo_endpoint_id = assetRepoEndpointId;
    const exists = await this.checkNameForUpdate(newConnName, newUserName, assetRepoEndpointId, orgId);
    if (exists) {
      const err = new Error('Connection Name and Username already exists.');
      err.status = 400;
      throw err;
    }
    const newPassword = await this.keyGenerator.generateKeys(params.vCDPassword, params.key);
    if (params.password) {
      params.password = newPassword;
    }
    const existsCheck = await this.checkType(type_id);
    if (!existsCheck) {
      const err = new Error('Asset Repo Type does not exists.');
      err.status = 400;
      throw err;
    }

    const name = existsCheck.name;
    if (name.toLowerCase() === 'vcd') {
      const assetRepoMembers = await AssetRepoEndpointMembers.findOne({ where: { asset_repo_enpoint_id_source_id: assetRepoEndpointId } });
      if (assetRepoMembers) {
        const assetRepoEndpoint_id = assetRepoMembers.linkId;
        const result = await AssetRepoEndpoint.findOne({
          where: {
            id: assetRepoEndpoint_id,
            $or: [{ is_active: { $ne: 'false' } }]
          }
        });
        if (result) {
          const Id = result.id;
          params.connectionName = params.lookupConnectionName;
          params.username = params.lookupUserName;
          params.asset_repo_type_id = result.asset_repo_type_id;
          await AssetRepoEndpoint.update(params, {
            where: { id: Id }
          });
          params.connectionName = newConnName;
          params.username = newUserName;
          params.asset_repo_type_id = type_id;
          await AssetRepoEndpoint.update(params, {
            where: { id: assetRepoEndpointId }
          });
          //return this.getAssetRepoEndpoint(assetRepoEndpointId, orgId);
          return AssetRepoEndpoint.findOne({
            where: { id: assetRepoEndpointId, organization_id: orgId },
            include: [{ all: true }]
          });
        }
      }
    }
  }

  checkType(type_id) {
    return AssetRepoType.findOne({ where: { id: type_id, $or: [{ is_active: { $ne: 'false' } }] } });
  }

  async getBulkAssetRepoEndpointMembersById(assetRepoEndpointId) {
    const newArr = [];
    let next = 0;
    const assetRepoEndpointArr = [];
    for (let i = 0; i < assetRepoEndpointId.length; i++) {
      const assetRepoEndpoint = await AssetRepoEndpoint.findOne({ where: { id: assetRepoEndpointId[i] } });
      const assetRepoEndpointMembers = await AssetRepoEndpointMembers.findAll({ where: { asset_repo_enpoint_id_source_id: assetRepoEndpointId[i] } });
      assetRepoEndpointMembers.filter(object => {
        newArr[next] = object.linkId;
        next++;
      });
      const result = await AssetRepoEndpoint.findAll({
        where: {
          id: { $in: newArr },
          $or: [{ is_active: { $ne: 'false' } }]
        }
      });
      const task = await ScheduleTask.findAll({
        where: {
          asset_repo_id: assetRepoEndpointId[i],
          $or: [{ is_active: { $ne: 'false' } }]
        }
      });
      const out = _.assign({ assetRepoEndpoint: assetRepoEndpoint }, { assetRepoEndpointMember: result }, { task: task });
      assetRepoEndpointArr.push(out);
    }
    return assetRepoEndpointArr;
  }

  async deleteById(loggedInUserId, userToken, assetRepoEndpointId, orgId) {
    const service = this;
    let assetRepoInfo;
    const assetIdArr = [];
    let ctr = 0;
    const assetRepoEndpointInfo = await this.getAssetRepoEndpoint(assetRepoEndpointId, orgId);
    const source_org_id = assetRepoEndpointInfo.organization_id;
    const source_loc_id = assetRepoEndpointInfo.location_id;
    const source_hosting_id = assetRepoEndpointInfo.hosting_provider_id;
    if (assetRepoEndpointInfo.AssetRepoType.name.toLowerCase() === 'nsx-t' || assetRepoEndpointInfo.AssetRepoType.name.toLowerCase() === 'vmc') {
      assetRepoInfo = await AssetRepoEndpoint.assetRepoInfo(assetRepoEndpointId, source_org_id, source_loc_id, source_hosting_id, assetRepoEndpointInfo.AssetRepoType.name);
    }
    return AssetRepoEndpoint.update(
      { isActive: false },
      {
        where: { id: assetRepoEndpointId }
      }
    ).then(assetRepoEndpoint => {
      return AssetRepoEndpointMembers.destroy({ where: { asset_repo_enpoint_id_link_id: assetRepoEndpointId } });
    }).then(assetRepoEndpoint => {
      return ScheduleTask.update(
        { isActive: false },
        {
          where: { asset_repo_id: assetRepoEndpointId }
        }
      );
    }).then(scheduleInfo => {
      return AssetDetail.findAll({ where: { asset_manager_id: assetRepoEndpointId } }).then(result => {
        result.filter(function (object) {
          assetIdArr[ctr] = object.asset_id;
          ctr++;
        });
        return Asset.update(
          { isActive: 'false' },
          {
            where: { id: { $in: assetIdArr } }
          }
        );
      }).then(() => {
        return PolicyGroupAssetMembers.destroy({ where: { asset_id: { $in: assetIdArr } } });
      });
    }).then(() => {
      return this.getAssetRepoEndpoint(assetRepoEndpointId, orgId).then(async function (result) {
        if (result.AssetRepoType.name.toLowerCase() === 'nsx-t' || result.AssetRepoType.name.toLowerCase() === 'nsx-v' || result.AssetRepoType.name.toLowerCase() === 'vmc' || result.AssetRepoType.name.toLowerCase() === 'vcd') {
          const parameters = JSON.parse(result.parameters);
          if (parameters.netflow_enabled) {
            try {
              if (parameters.netflow_enabled === 'true') {
                try {
                  await this.netFlowOperations(loggedInUserId, userToken, orgId, assetRepoEndpointId, 'delete', assetRepoInfo);
                } catch (error) {
                  logger.error({
                    error,
                    action: 'delete',
                    orgId,
                    assetRepoEndpointId
                  }, ' error occurred in netflow operations');
                }
              }
            } catch (error) {
              // Should not block creation on network call failure
              const err = new Error(error.message);
              err.status = 400;
              throw err;
            }
          }
        }
        return result;
      });
    });
  }

  async deleteMultipleAssetRepoEndpoints(assetRepoEndpointIdList, orgId, loggedInUserId, userToken) {
    const assetRepoInfo = [];
    let assetRepoInfoRes;
    const assetIdArr = [];
    let ctr = 0;
    assetRepoEndpointIdList = assetRepoEndpointIdList.filter(repoId => repoId !== 0);
    for (let i = 0; i < assetRepoEndpointIdList.length; i++) {
      const assetRepoEndpointInfo = await this.getAssetRepoEndpoint(assetRepoEndpointIdList[i], orgId);
      const assetRepoType = get(assetRepoEndpointInfo, 'AssetRepoType.name');
      if (assetRepoType.toLowerCase() === 'nsx-t' || assetRepoType.toLowerCase() === 'vmc') {
        const sourceOrgId = assetRepoEndpointInfo.organization_id;
        const sourceLocId = assetRepoEndpointInfo.location_id;
        const sourceHostingId = assetRepoEndpointInfo.hosting_provider_id;
        assetRepoInfoRes = await AssetRepoEndpoint.assetRepoInfo(assetRepoEndpointIdList[i], sourceOrgId, sourceLocId, sourceHostingId, assetRepoType);
        assetRepoInfo.push(assetRepoInfoRes);
      } else if (assetRepoType.toLowerCase() === 'vcenter') {
        await OrgVCenter.destroy({ where: { asset_repo_endpoint_id: { $eq: assetRepoEndpointIdList[i] } } });
      } else if (assetRepoType.toLowerCase() === 'aws') {
        await Organization.update({ isActive: 'false' }, {
          where: {
            source: { $eq: `AWS-${assetRepoEndpointIdList[i]}` },
            type: { $eq: 'Sub-Organization' }
          }
        });
        await sequelize.query(`UPDATE aws_organization_users set is_active = 'false' WHERE asset_repo_endpoint_id = :asset_repo_endpoint_id ;`, {
          type: sequelize.QueryTypes.UPDATE,
          replacements: { asset_repo_endpoint_id: assetRepoEndpointIdList[i] }
        });
      } else if (assetRepoType.toLowerCase() === 'vmc') {
        VMCVcenterDetails.destroy({ where: { asset_repo_endpoint_vmc_id: assetRepoEndpointIdList[i] } });
      }
      await this.storeDeleteAssetRepo({ id: assetRepoEndpointIdList[i], organization_id: orgId });
      try {
        await awsKMSService.CentralCollectorServiceUpdate('assetRepo', assetRepoEndpointIdList[i], orgId, loggedInUserId, userToken);
      } catch (e) {
        logger.error(e);
      }
    }
    return AssetRepoEndpoint.update(
      { isActive: false, parameters: null },
      {
        where: { id: { $in: assetRepoEndpointIdList } }
      }
    ).then(assetRepoEndpoint => {
      return AssetRepoEndpointMembers.destroy({ where: { asset_repo_enpoint_id_link_id: { $in: assetRepoEndpointIdList } } });
    }).then(assetRepoEndpoint => {
      return ScheduleTask.update(
        { isActive: false },
        {
          where: { asset_repo_id: { $in: assetRepoEndpointIdList } }
        }
      );
    }).then(scheduleInfo => {
      return AssetDetail.findAll({ where: { asset_manager_id: { $in: assetRepoEndpointIdList } } }).then(result => {
        result.filter(function (object) {
          assetIdArr[ctr] = object.asset_id;
          ctr++;
        });
        return Asset.update(
          { isActive: 'false' },
          {
            where: { id: { $in: assetIdArr } }
          }
        );
      }).then(() => {
        return PolicyGroupAssetMembers.destroy({ where: { asset_id: { $in: assetIdArr } } });
      });
    }).then(async () => {
      for (let i = 0; i < assetRepoEndpointIdList.length; i++) {
        const result = await this.getAssetRepoEndpoint(assetRepoEndpointIdList[i], orgId);
        const assetRepoType = get(result, 'AssetRepoType.name');
        if (assetRepoType.toLowerCase() === 'nsx-t' || assetRepoType.toLowerCase() === 'vmc' || assetRepoType.toLowerCase() === 'vcd') {
          const parameters = JSON.parse(get(result, 'dataValues.parameters'));
          if (has(parameters, 'netflow_enabled')) {
            if (parameters.netflow_enabled === 'true') {
              for (let j = 0; j < assetRepoInfo.length; j++) {
                const arr = assetRepoInfo[j];
                try {
                  if (assetRepoEndpointIdList[i] === get(arr, '[0].vcd_id')) {
                    try {
                      await this.netFlowOperations(loggedInUserId, userToken, orgId, assetRepoEndpointIdList[i], 'delete', assetRepoInfo);
                    } catch (error) {
                      logger.error({
                        error,
                        action: 'delete',
                        orgId,
                        assetRepoId: assetRepoEndpointIdList[i]
                      }, ' error occurred in netflow operations');
                    }
                  }
                } catch (error) {
                  const err = new Error(error.message);
                  err.status = 400;
                  throw err;
                }
              }
            }
          }
        }
      }
    }).then(async () => {
      const modifiedAssetRepoEndpoint = await AssetRepoEndpoint.findAll({
        where: { id: { $in: assetRepoEndpointIdList }, organization_id: orgId },
        include: [{ all: true }]
      });
      const result = modifiedAssetRepoEndpoint.map((object) => {
        object.dataValues.tenantCreation = object.parameters ? 'auto' : 'manual';
        object.dataValues.resourceType = object.parameters ? object.parameters : null;
        object.dataValues.parameters = '';
        return object;
      });
      return result;
    });
  }

  async addOrgVcenterMapping(orgId, assetRepoId, type, values = []) {
    if (_.isArray(values)) values = values.join(',');
    if (values.length === 0) {
      const e = new Error('Cannot Add Empty Mapping');
      e.status = 400;
      throw e;
    }
    const org = await Organization.findByPk(orgId);
    assetRepoId = _.isString(assetRepoId) ? parseInt(assetRepoId) : assetRepoId;
    return org.addAssetRepoEndpoint(assetRepoId, { through: { type, values } });
  }

  async getOrgVcenterMapping(orgId, assetRepoId) {
    return OrgVCenter.findAll({
      include: [{
        model: Organization,
        where: { id: orgId },
        attributes: ['name', 'aliasName', 'fullName'],
        required: true
      }, { model: AssetRepoEndpoint, where: { id: assetRepoId }, attributes: ['connectionName'], required: true }]
    });
  }

  // async deleteOrgVcenterMapping(orgId, assetRepoId) {
  //   const org = await Organization.findById(orgId);
  //   return org.addAssetRepoEndpoint(assetRepoId, { through: { type, values } });
  // }
  async getUnMappedVCenters() {
    return AssetRepoEndpoint.findAll({
      attributes: ['id', 'connectionName'],
      where: { parameters: null },
      include: [{ model: AssetRepoType, where: { name: 'vCenter' }, required: true }]
    });
  }

  async syncVcenter(assetRepoId) {
    const assetRepo = await AssetRepoEndpoint.findByPk(assetRepoId);
    if (!assetRepo) {
      const error = new Error('Asset Repo not Found');
      error.status = 404;
    }
    const { username, password, connectionName } = assetRepo;
    const decryptedPassword = await this.keyGenerator.decryptKeys(password);

    const a = require('url').parse(connectionName, true);
    const hostName = a.host;
    const protocol = a.protocol;
    const auth = 'Basic ' + Buffer.from(`${username}:${decryptedPassword}`).toString('base64');

    const { dataCenter, folderName, resourcePool, clusterName } = await this.connectToVcenter(protocol, hostName, auth);
    return this.createVcenterResourceMappings(assetRepoId, folderName.map(a => a.folder), clusterName.map(a => a.cluster), dataCenter.map(a => a.datacenter), resourcePool.map(a => a.resource_pool));

  }

  async connectToVcenter(protocol, hostName, auth) {
    const url = `${protocol}//${hostName}rest/com/vmware/cis/session`;
    const response = await rp.post(url, {
      headers: { Authorization: auth, 'Content-Type': 'application/json' },
      json: true,
      rejectUnauthorized: false,
      resolveWithFullResponse: true
    });
    const vcenterCookie = `vmware-api-session-id=${response.body.value}`;
    const getDataCenterUrl = protocol + '//' + hostName + 'rest/vcenter/datacenter';
    const getfolderUrl = protocol + '//' + hostName + 'rest/vcenter/folder';
    const getResourcePoolUrl = protocol + '//' + hostName + 'rest/vcenter/resource-pool';
    const getClusterUrl = protocol + '//' + hostName + 'rest/vcenter/cluster';
    const dataCenterData = await this.makeRequest('GET', getDataCenterUrl, vcenterCookie);
    const dataCenterArray = dataCenterData.value;

    const folderData = await this.makeRequest('GET', getfolderUrl, vcenterCookie);
    const folderArray = await this.removeDefaultFolder(folderData.value);

    const resourcePoolData = await this.makeRequest('GET', getResourcePoolUrl, vcenterCookie);
    const resourcePoolArray = await this.removeDefaultResourcePool(resourcePoolData.value);

    const clusterData = await this.makeRequest('GET', getClusterUrl, vcenterCookie);
    const clusterArray = clusterData.value;

    return {
      dataCenter: dataCenterArray,
      folderName: folderArray.filter(f => f.type == 'VIRTUAL_MACHINE'),
      resourcePool: resourcePoolArray,
      clusterName: clusterArray
    };

  }

  async removeDefaultResourcePool(resourcePoolData) {
    const defaultResourcePoolData = resourcePoolData.filter(a => {
      return a.name === 'Resources';
    });
    const defaultResourceSnoArr = defaultResourcePoolData.map(a => {
      return a.resource_pool.replace('resgroup-', '');
    });
    const minValue = Math.min(...defaultResourceSnoArr); // find min value of resource to find default
    return resourcePoolData.filter(a => {
      return a.resource_pool !== `resgroup-${minValue}`;
    });
  }

  async removeDefaultFolder(folderData) {
    const defaultFolderData = folderData.filter(a => {
      return a.name === 'vm';
    });
    const defaultResourceSnoArr = defaultFolderData.map(a => {
      return a.folder.replace('group-v', '');
    });
    const minValue = Math.min(...defaultResourceSnoArr); // find min value of folder to find default
    return folderData.filter(a => {
      return a.folder !== `group-v${minValue}`;
    });
  }

  async makeRequest(method, url, cookie) {
    try {
      const response = await rp({
        url: url,
        method: method,
        headers: { Cookie: cookie, 'Content-Type': 'application/json' },
        json: true,
        rejectUnauthorized: false
      });
      return response;
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      throw error;
    }
  }

  async testVCenterConnection(protocol, hostName, auth) {
    try {
      const data = await this.connectToVcenter(protocol, hostName, auth);
      if (data) {
        return data;
      } else {
        const error = new Error('cannot connect to vCenter');
        error.status = 400;
        logger.error({ error, stack: error.stack }, 'error occurred connecting to vcd');
        throw error;
      }
    } catch (error) {
      error.status = 400;
      if (error.message.includes('unauthenticated') || error.message.includes('Not authorized')) {
        error.status = 400;
        error.message = 'The vCenter Username or Password is invalid';
      } else if (error.message.includes('ENOTFOUND') || error.message.includes('Moved Permanently')) {
        error.status = 404;
        error.message = 'The vCenter URL is invalid';
      } else if (error.message.includes('ETIMEDOUT')) {
        error.status = 400;
        error.message = 'The vCenter Connection Timeout';
      } else {
        error.status = 400;
        error.message = 'The vCenter Connection Errror';
        error.message = 'Error occurred at vCenter';
      }
      logger.error({ error, stack: error.stack }, 'Error occurred at vCenter');
      throw error;
    }
  }

  async testNSXConnection(protocol, hostName, auth) {
    const url = protocol + '//' + hostName + 'api/2.0/services/usermgmt/user/admin';
    try {
      await rp.get(url, {
        headers: { Authorization: auth, 'Content-Type': 'application/json' },
        json: true,
        rejectUnauthorized: false,
        resolveWithFullResponse: true
      });
      return { connection: 'Connection Successful.' };
    } catch (error) {
      if (error.statusCode && (error.statusCode === 403 || error.statusCode === 401)) {
        error.status = 403;
        error.message = 'The NSX-V Username or Password is Invalid';
        logger.error({ error, stack: error.stack }, 'The NSX-V Username or Password is Invalid');
      } else if (error.statusCode && error.statusCode === 405) {
        error.status = 405;
        error.message = 'The NSX-V URL is invalid';
        logger.error({ error, stack: error.stack }, 'The NSX-V Server Error');
      } else if (error.statusCode && error.statusCode === 500) {
        error.status = 400;
        error.message = 'The NSX-V Server Error';
        logger.error({ error, stack: error.stack }, 'The NSX-V Server Error');
      } else {
        error.status = 400;
        error.message = 'The NSX-V Connection Error';
        logger.error({ error, stack: error.stack }, 'error occurred connecting to NSX-V');
      }
      throw error;
    }
  }

  async testNSXTConnection(protocol, hostName, auth) {
    const url = protocol + '//' + hostName + 'api/v1/aaa/user-info';
    try {
      await rp.get(url, {
        headers: { Authorization: auth, 'Content-Type': 'application/json' },
        json: true,
        rejectUnauthorized: false,
        resolveWithFullResponse: true
      });
      return { connection: 'Connection Successful.' };
    } catch (error) {
      if (error.statusCode && (error.statusCode === 403 || error.statusCode === 401)) {
        error.status = 403;
        error.message = 'The NSX-T Username or Password is Invalid';
        logger.error({ error, stack: error.stack }, 'The NSX-T Username or Password is Invalid');
      } else if (error.statusCode && error.statusCode === 405) {
        error.status = 405;
        error.message = 'The NSX-T URL is invalid';
        logger.error({ error, stack: error.stack }, 'The NSX-T Server Error');
      } else if (error.statusCode && error.statusCode === 500) {
        error.status = 400;
        error.message = 'The NSX-T Server Error';
        logger.error({ error, stack: error.stack }, 'The NSX-T Server Error');
      } else {
        error.status = 400;
        error.message = 'The NSX-T Connection Error';
        logger.error({ error, stack: error.stack }, 'error occurred connecting to NSX-T');
      }
      throw error;
    }
  }

  async testLookupAndAdConnection(connName, hostName, user, password, typeName, port) {
    let ldapUrl;
    if (typeName.toLowerCase() === 'lookupurl') {
      try {
        // todo this is not ideal,  LookupUrl needs to be tested using SOAP, this needs to be updated
        const response = await rp.get({ url: connName });

        // if the keyword vim25 doesn't exist, then the test has failed
        if (!response.includes('vim25')) {
          const error = new Error();
          error.message = 'The LookupUrl is invalid';
          error.statusCode = 400;
          throw error;
        }

        return { message: 'The LookupUrl connection test is successful', success: true };
      } catch (e) {
        logger.error({ e, stack: e.stack }, 'error occurred connecting lookup url');
        const message = get(e, 'message') || '';
        const statusCode = get(e, 'statusCode');
        // since this is currently done using REST, a success will always be 500, checking if the 'vim25' keyword is present, if so then its a success
        if (statusCode === 500 && message.includes('vim25')) {
          e.status = 200;
          e.message = 'The LookupUrl connection test is successful';
        } else {
          e.status = 400;
          e.message = 'The LookupUrl is invalid';
        }

        throw e;
      }
    }
    if (port) {
      ldapUrl = `ldap://${hostName}:${port}`;
    } else {
      ldapUrl = `ldap://${hostName}:389`;
    }
    try {
      const tlsOption = {
        rejectUnauthorized: true
      };
      const client = await ldap.createClient({
        url: ldapUrl,
        tlsOptions: tlsOption,
        timeLimit: 1000
      });
      if (user.includes('@')) {
        const str = user.split('@');
        const strDomain = str[1].split('.');
        user = 'cn=' + str[0] + ',cn=Users,dc=' + strDomain[0] + ',dc=' + strDomain[1];
      } else if (user.includes('/')) {
        const str = user.split('/');
        user = 'cn=' + str[1] + ',cn=Users,dc=' + str[0];
      } else {
        user = 'cn=' + user;
      }
      await client.on('connect', function () {
        client.bind(user, password, (err, response) => {
          if (err) {
            return { connection: 'Connection Failed.' };
          } else {
            return { connection: 'Connection Successful.' };
          }
        });
      });
      client.on('timeout', function (err) {
        if (err) {
          return { connection: 'Connection Failed.' };
        }
      });
      client.on('error', function (err) {
        if (err) {
          return { connection: 'Connection Failed.' };
        }
      });

    } catch (error) {
      error.status = 400;
      logger.error({ error, stack: error.stack }, 'error occurred connecting to vcd');
      throw error;
    }
  }

  async testVCDConnection(protocol, hostName, auth) {
    const url = `${protocol}//${hostName}api/versions`;
    const vcdLoginUrl = `${protocol}//${hostName}api/sessions`;
    const getVCenterUrl = `${protocol}//${hostName}api/admin/extension/vimServerReferences/query`;
    let response = {};
    try {
      response = await rp.get(url, {
        headers: {
          Authorization: auth,
          'Content-Type': 'application/json',
          Accept: 'anything'
        },
        json: true,
        rejectUnauthorized: false,
        resolveWithFullResponse: true
      });
      const jsonData = objTree.parseXML(response.body);
      const versionLength = get(jsonData, 'SupportedVersions.VersionInfo.length') - 1;
      const version = get(jsonData, `SupportedVersions.VersionInfo[${versionLength}].Version`);
      const accept = `application/*+xml;version=${version}`;
      const loginResponse = await rp.post(vcdLoginUrl, {
        headers: {
          Authorization: auth,
          'Content-Type': 'application/json',
          Accept: accept
        },
        json: true,
        rejectUnauthorized: false,
        resolveWithFullResponse: true
      });
      const vCloudCookie = loginResponse.headers['x-vcloud-authorization'];
      const data = await rp.get(getVCenterUrl, {
        headers: {
          Authorization: auth,
          'Content-Type': 'application/json',
          Accept: accept,
          'x-vcloud-authorization': vCloudCookie
        },
        json: true,
        rejectUnauthorized: false,
        resolveWithFullResponse: true
      });
      const vCenterJson = objTree.parseXML(data.body);
      const vCenterArray = [];
      const results = [];
      if (has(vCenterJson, 'QueryResultRecords.VirtualCenterRecord')) {
        results.push(vCenterJson.QueryResultRecords.VirtualCenterRecord);
        results.map((result) => {
          if (result.length > 1) {
            result.filter(res => {
              vCenterArray.push({ vcenter_url: res['-url'] });
            });
          } else {
            vCenterArray.push({ vcenter_url: result['-url'] });
          }
        });
      }
      return vCenterArray;
    } catch (error) {
      if (error.message.includes('ENOTFOUND')) {
        logger.error({ error, stack: error.stack }, 'The VCD URL is invalid');
        error.status = 404;
        error.message = 'The VCD URL is invalid';
      } else if (error.message.includes('ECONNREFUSED')) {
        logger.error({ error, stack: error.stack }, 'The VCD Connection Refused');
        error.status = 400;
        error.message = 'The VCD Connection Refused';
      } else if (error.message.includes('ETIMEDOUT')) {
        logger.error({ error, stack: error.stack }, 'The VCD Connection Timeout');
        error.status = 400;
        error.message = 'The VCD Connection Timeout';
      } else if (error.statusCode && error.statusCode == 401) {
        logger.error({ error, stack: error.stack }, 'The VCD Username or Password is invalid');
        error.status = 400;
        error.message = 'The VCD Username or Password is invalid';
      } else {
        logger.error({ error, stack: error.stack }, 'Error Connecting to VCD');
        error.status = 400;
        error.message = 'Error Connecting to VCD';
      }
      throw error;

    }
  }

  async testAWSConnection(accessKeyId, secretAccessKey, region) {
    AWS.config.update({ region });
    const organizations = new AWS.Organizations({
      accessKeyId,
      secretAccessKey
    });
    try {
      const params = {};
      const { $response, Accounts, NextToken } = await organizations.listAccounts(params).promise();
      return { connection: 'Connection Successful.' };
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'Error Connecting to AWS');
      error.status = _.get(error, 'statusCode', 400);
      const name = _.get(error, 'name', '');
      const invalidAccessExceptions = ['UnrecognizedClientException', 'InvalidSignatureException'];
      error.message = invalidAccessExceptions.includes(name) ? 'Invalid access key and/or secret key.' : error.message;
      throw error;
    }
  }

  async testGCPConnection(project, serviceAccountFile) {
    try {
      let credentials = serviceAccountFile.buffer.toString();
      if (serviceAccountFile.mimetype === 'application/json') {
        credentials = JSON.parse(credentials);
      }
      const resource = new Resource({ email: project, credentials });
      const [projects] = await resource.getProjects();
      return { connection: 'Connection Successful.' };
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'Error Connecting to GCP');
      error.status = _.get(error, 'statusCode', 400);
      throw error;
    }
  }

  async testAzureConnection(clientId, secret, domain) {
    try {
      await msRestNodeAuth.loginWithServicePrincipalSecretWithAuthResponse(clientId, secret, domain);
      return { connection: 'Connection Successful.' };
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'Error Connecting to Azure');
      error.status = _.get(error, 'statusCode', 400);
      throw error;
    }
  }

  async testOpenShiftConnection(protocol, hostName, auth) {
    const url = `${protocol}//${hostName}oauth/authorize?client_id=openshift-challenging-client&response_type=token`;
    try {
      await rp.get(url, {
        headers: {
          Authorization: auth,
          Accept: 'anything'
        },
        json: false,
        rejectUnauthorized: false,
        resolveWithFullResponse: true
      });
      return { connection: 'Connection Successful.' };
    } catch (error) {
      if (error.message.includes('ENOTFOUND')) {
        logger.error({ error, stack: error.stack }, 'The OpenShift URL is invalid');
        error.status = 404;
        error.message = 'The OpenShift URL is invalid';
      } else if (error.message.includes('ECONNREFUSED')) {
        logger.error({ error, stack: error.stack }, 'The OpenShift Connection Refused');
        error.status = 400;
        error.message = 'The OpenShift Connection Refused';
      } else if (error.message.includes('ETIMEDOUT')) {
        logger.error({ error, stack: error.stack }, 'The OpenShift Connection Timeout');
        error.status = 400;
        error.message = 'The OpenShift Connection Timeout';
      } else if (error.statusCode && error.statusCode == 401) {
        logger.error({ error, stack: error.stack }, 'The OpenShift Username or Password is invalid');
        error.status = 400;
        error.message = 'The OpenShift Username or Password is invalid';
      } else {
        logger.error({ error, stack: error.stack }, 'Error Connecting to OpenShift');
        error.status = 400;
        error.message = 'Error Connecting to OpenShift';
      }
      throw error;

    }
  }

  async testOpenStackConnection(protocol, hostName, port, user, password, auth) {
    port = port || 35357; //admin port
    hostName = hostName.includes(':') ? hostName : hostName.split('/')[0] + ':' + port + '/';
    const url = `${protocol}//${hostName}v3/auth/tokens`;
    const body = `{
      "auth": {
          "identity": {
              "methods": [
                  "password"
              ],
              "password": {
                  "user": {
                      "name": "${user}",
                      "domain": {
                          "name": "Default"
                      },
                      "password": "${password}"
                  }
              }
          }
      }
  }`;
    try {
      await rp.post(url, {
        body,
        headers: {
          'Content-Type': 'application/json',
          Accept: 'anything'
        },
        json: false,
        rejectUnauthorized: false,
        resolveWithFullResponse: true
      });
      return { connection: 'Connection Failed.' };
    } catch (error) {
      if (error.message.includes('ENOTFOUND')) {
        logger.error({ error, stack: error.stack }, 'The OpenStack URL is invalid');
        error.status = 404;
        error.message = 'The OpenStack URL is invalid';
      } else if (error.message.includes('ECONNREFUSED')) {
        logger.error({ error, stack: error.stack }, 'The OpenStack Connection Refused');
        error.status = 400;
        error.message = 'The OpenStack Connection Refused';
      } else if (error.message.includes('ETIMEDOUT')) {
        logger.error({ error, stack: error.stack }, 'The OpenStack Connection Timeout');
        error.status = 400;
        error.message = 'The OpenStack Connection Timeout';
      } else if (error.statusCode && error.statusCode == 401) {
        logger.error({ error, stack: error.stack }, 'The OpenStack Username or Password is invalid');
        error.status = 400;
        error.message = 'The OpenStack Username or Password is invalid';
      } else {
        logger.error({ error, stack: error.stack }, 'Error Connecting to OpenStack');
        error.status = 400;
        error.message = 'Error Connecting to OpenStack';
      }
      throw error;

    }
  }

  async validateAssetRepo(orgId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const allAssetRepo = await AssetRepoEndpoint.findAll({
      where: {
        organization_id: orgId,
        isActive: { $eq: 'enabled' }
      },
      include: [{ model: AssetRepoType }]
    });
    const responseArray = [];
    for (let i = 0; i < allAssetRepo.length; i++) {
      let result = '';
      let testConnResp = '';
      const oneAssetRepoResponse = {};
      const user = allAssetRepo[i].username;
      let password = allAssetRepo[i].password;
      let connName = allAssetRepo[i].connectionName;
      const typeName = allAssetRepo[i].AssetRepoType.name;
      password = await this.keyGenerator.decryptKeys(password);
      const auth = `Basic ${Buffer.from(user + ':' + password).toString('base64')}`;

      let hostName = '';
      let protocol = '';
      let pathName;
      let port;
      const stringLength = connName.length;
      const lastChar = connName.charAt(stringLength - 1);
      if (lastChar === '/') {
        connName = connName.slice(0, -1);
      }

      if (user && password && connName && typeName) {
        if (validator.contains(connName, '://')) {
          const a = require('url').parse(connName, true);
          hostName = a.host;
          protocol = a.protocol;
          pathName = a.path;
          port = a.port;
        } else {
          connName = 'https://' + connName;
          const a = require('url').parse(connName, true);
          hostName = a.host;
          protocol = a.protocol;
          pathName = a.path;
          port = a.port;
        }

        if (pathName != null) {
          hostName = hostName + pathName;
        }
        try {
          if (typeName.toLowerCase() === 'vcenter') {
            testConnResp = await this.validateVCenterConnection(protocol, hostName, auth);
            if (testConnResp.connection === 'Connection Failed.') {
              result = 'Fail';
            } else {
              result = 'Pass';
            }
          } else if (typeName.toLowerCase() === 'nsx-v') {
            testConnResp = await this.testNSXConnection(protocol, hostName, auth);
            if (testConnResp.connection === 'Connection Failed.') {
              result = 'Fail';
            } else {
              result = 'Pass';
            }
          } else if (typeName.toLowerCase() === 'nsx-t') {
            testConnResp = await this.testNSXTConnection(protocol, hostName, auth);
            if (testConnResp.connection === 'Connection Failed.') {
              result = 'Fail';
            } else {
              result = 'Pass';
            }
          } else if (typeName.toLowerCase() === 'lookupurl' || typeName.toLowerCase() === 'ad') {
            if (hostName.includes(':')) {
              hostName = hostName.split(':')[0];
              if (pathName != null) {
                hostName = hostName + pathName;
              }
            }
            testConnResp = await this.testLookupAndAdConnection(connName, hostName, user, password, typeName, port);
            if (testConnResp.connection === 'Connection Failed.') {
              result = 'Fail';
            } else {
              result = 'Pass';
            }
          } else if (typeName.toLowerCase() === 'vcd') {
            testConnResp = await this.validateVCDConnection(protocol, hostName, auth);
            if (testConnResp.connection === 'Connection Failed.') {
              result = 'Fail';
            } else {
              result = 'Pass';
            }
          }
        } catch (e) {
          result = 'Fail';
        }
      } else {
        result = 'Fail';
      }
      oneAssetRepoResponse.id = allAssetRepo[i].id;
      oneAssetRepoResponse.connName = connName;
      oneAssetRepoResponse.result = result;
      responseArray.push(oneAssetRepoResponse);
    }

    return responseArray;
  }

  async validateVCenterConnection(protocol, hostName, auth) {
    const url = protocol + '//' + hostName + 'rest/com/vmware/cis/session';
    let response = {};
    try {
      response = await rp.post(url, {
        headers: { Authorization: auth, 'Content-Type': 'application/json' },
        json: true,
        rejectUnauthorized: false,
        resolveWithFullResponse: true
      });
      const vcenterCookie = 'vmware-api-session-id=' + response.body.value;
      if (vcenterCookie) {
        return { connection: 'Connection Successful.' };
      } else {
        return { connection: 'Connection Failed.' };
      }
    } catch (error) {
      return { connection: 'Connection Failed.' };
    }
  }

  async validateVCDConnection(protocol, hostName, auth) {
    const url = protocol + '//' + hostName + 'api/versions';
    const vcdLoginUrl = protocol + '//' + hostName + 'api/sessions';
    let response = {};
    try {
      response = await rp.get(url, {
        headers: {
          Authorization: auth,
          'Content-Type': 'application/json',
          Accept: 'anything'
        },
        json: true,
        rejectUnauthorized: false,
        resolveWithFullResponse: true
      });
      const jsonData = objTree.parseXML(response.body);
      const Length = jsonData.SupportedVersions.VersionInfo.length - 1;
      const Version = jsonData.SupportedVersions.VersionInfo[Length].Version;
      const accept = 'application/*+xml;version=' + Version;
      const loginResponse = await rp.post(vcdLoginUrl, {
        headers: {
          Authorization: auth,
          'Content-Type': 'application/json',
          Accept: accept
        },
        json: true,
        rejectUnauthorized: false,
        resolveWithFullResponse: true
      });
      const vCloudCookie = loginResponse.headers['x-vcloud-authorization'];
      if (vCloudCookie) {
        return { connection: 'Connection Successful.' };
      } else {
        return { connection: 'Connection Failed.' };
      }
    } catch (error) {
      return { connection: 'Connection Failed.' };
    }
  }

  async netFlowOperations(userId, userToken, orgId, nsxId, action, assetRepoInformation, params = null) {
    try {
      let ccUrl = await CentralCollectorClient.getCentralCollectorAddress();
      if (!ccUrl) {
        const err = new Error('No Central Collector Available. Please Contact your Caveonix Administrator');
        err.status = 404;
        throw err;
      }
      if (action === 'create') {
        ccUrl = ccUrl + `/${SERVICE_TYPE}/api/v1/netflowInstall?userToken=` + userToken + '&userId=' + userId + '&orgId=' + orgId + '&nsxId=' + nsxId;
      } else if (action === 'update') {
        const observationDomainId = params.observation_domain_id ? `&observationDomainId=${params.observation_domain_id}` : '';
        ccUrl = ccUrl + `/${SERVICE_TYPE}/api/v1/netflowReinstall?userToken=` + userToken + '&userId=' + userId + '&orgId=' + orgId + '&nsxId=' + nsxId + observationDomainId;

      } else if (action === 'delete') {
        const assetRepoInfo = JSON.stringify(assetRepoInformation[0]);
        ccUrl = ccUrl + `/${SERVICE_TYPE}/api/v1/netflowUninstallWithAssetRepoInfo?userToken=` + userToken + '&userId=' + userId + '&orgId=' + orgId + '&nsxId=' + nsxId + '&assetRepoInfo=' + assetRepoInfo;
      }
      const result = await rp.post(ccUrl, { json: true, rejectUnauthorized: false, resolveWithFullResponse: true });
      logger.info(result);
    } catch (error) {
      let errMessage = 'Central Collector Error';
      let errStatus = 400;
      if (typeof error.error === 'object') {
        errMessage = error.error.message ? error.error.message : errMessage;
      } else if (error.error) {
        errMessage = error.error;
      }
      if ((error.status && error.status == 503) || error.message.includes('ECONNREFUSED')) {
        errMessage = 'Central Collector Unavailable. Please Contact your Caveonix Administrator';
        errStatus = 503;
      } else if (error.message.includes('ETIMEDOUT')) {
        errMessage = 'Central Collector Timeout Error';
        errStatus = 400;
      }
      const e = new Error(errMessage);
      e.status = errStatus;
      logger.error({ error, stack: error.stack }, errMessage);
      throw e;
    }
  }

  async checkVcenterExtracted(orgId, sourceId) {
    return sequelize
      .query(
        `select vmid, a.organization_id from assets a, asset_details ad where a.id = ad.asset_id  and ad.asset_manager_id  in (:sourceId) and vmid != '' 
         and vmid is not null and is_active != 'false'   and a.organization_id in (WITH RECURSIVE org_cte(organization_id)
         AS (SELECT tn.organization_id  FROM org_chains AS tn  join organizations as o on o.id = tn.organization_id and organization_id = :orgId  
         UNION ALL  SELECT c.organization_id  FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id  
         WHERE c.parent_organization_id = p.organization_id  ) SELECT organization_id FROM org_cte AS n) ;`,
        { type: sequelize.QueryTypes.SELECT, replacements: { sourceId: sourceId, orgId: orgId } }
      );
  }

  async getVMCVcenterDetails(userToken, userId, orgId, body) {
    let result;
    const connectionName = body.connectionName;
    const password = body.password;
    try {
      let ccUrl = await CentralCollectorClient.CentralCollectorConnectionCheck();
      if (!ccUrl) {
        const error = new Error('No Central Collector Available. Please Contact your Caveonix Administrator');
        error.status = 400;
        throw error;
      }
      ccUrl = ccUrl + `/${SERVICE_TYPE}/api/v1/vmc/extract/vcenterdetails/?userToken=` + userToken + '&userId=' + userId + '&orgId=' + orgId + '&connectionName=' + connectionName + '&password=' + password;
      result = await rp.post(ccUrl, {
        json: true,
        rejectUnauthorized: false,
        resolveWithFullResponse: false,
        timeout: cc_timeout
      });
      logger.info(result);
      return result;
    } catch (error) {
      const err = new Error(error.message);
      err.status = 400;
      throw err;
    }
  }

  async storeGetAssetRepo(assetRepoEndpoint) {
    if (!config.saas) return false;
    const orgData = await Organization.findOne({ where: { id: assetRepoEndpoint.organization_id }, attributes: ['name', 'aliasName'] });
    const Name = `/${orgData.name}/assetRepo/${assetRepoEndpoint.id}`;
    const ssmData = await awsKMSService.getSSMParameter(Name);
    const assetRepoData = await this.keyGenerator.decryptKeys(ssmData[0].Value);
    return JSON.parse(assetRepoData);
  }

  async storeAddAssetRepo(assetRepoEndpoint) {
    if (!config.saas) return false;
    const KMSData = await OrgLicense.findOne({ where: { organization_id: assetRepoEndpoint.organization_id }, attributes: ['kmsKeyId'] });
    const KeyId = await this.keyGenerator.decryptKeys(KMSData.kmsKeyId);
    const Value = await this.keyGenerator.generateKeys(JSON.stringify(assetRepoEndpoint).replace(/"/g, '\\"'));
    const orgData = await Organization.findOne({ where: { id: assetRepoEndpoint.organization_id }, attributes: ['name', 'aliasName'] });
    const Name = `/${orgData.name}/assetRepo/${assetRepoEndpoint.id}`;
    await awsKMSService.createSSMParameter(Name, Value, KeyId);
    return true;
  }

  async storeDeleteAssetRepo(assetRepoEndpoint) {
    if (!config.saas) return false;
    const orgData = await Organization.findOne({ where: { id: assetRepoEndpoint.organization_id }, attributes: ['name', 'aliasName'] });
    const Name = `/${orgData.name}/assetRepo/${assetRepoEndpoint.id}`;
    await awsKMSService.deleteSSMParameter(Name);
    return true;
  }

};
