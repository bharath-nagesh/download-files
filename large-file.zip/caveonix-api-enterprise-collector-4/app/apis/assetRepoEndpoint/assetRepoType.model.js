const { Model, DataTypes } = require('sequelize');

class AssetRepoType extends Model {
  static init(sequelize) {
    return super.init({
        name: { type: DataTypes.STRING },
        isActive: { type: DataTypes.STRING, field: 'is_active' },
        type: { type: DataTypes.STRING }
      },
      {
        sequelize,
        timestamps: false,
        freezeTableName: true,
        tableName: 'asset_repo_types',
        underscored: true
      }
    );
  }
}

module.exports = AssetRepoType;
