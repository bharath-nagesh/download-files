const AssetRepoEndpointController = require('./assetRepoEndpoint.controller');

/**
 * @swagger
 * tags:
 *  - name: AssetRepoEndpoint
 *    description: Asset Repo Endpoint endpoints
 */
module.exports = class AssetRepoEndpointRoutes {
  constructor(path, router) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.assetRepoEndpointController = new AssetRepoEndpointController();

      this.initOrganization();
    }
  }

  initOrganization() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/assetRepoEndpoint:
     *   get:
     *     tags:
     *       - AssetRepoEndpoint
     *     summary: Gets all assetRepoEndpoint
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: assetRepoEndpointId
     *         description: The id of the specified assetRepoEndpoint.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: assetRepoEndpoint
     */
    this.router.get(`${this.path}/`, this.assetRepoEndpointController.getAllAssetRepoEndpoint);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/assetRepoEndpoint/types:
     *   get:
     *     tags:
     *       - AssetRepoEndpoint
     *     summary: Gets a list of Asset Repo Endpoints types
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of asset Repo Endpoints types
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/types`, this.assetRepoEndpointController.getAssetRepoEndpointTypes);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/validateAllAssetRepo:
     *   get:
     *     tags:
     *       - AssetRepoEndpoint
     *     summary: Gets all assetRepoEndpoint
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: id
     *         description: The id of the specified assetRepoEndpoint.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: assetRepoEndpoint
     */
    this.router.get(`${this.path}/validate`, this.assetRepoEndpointController.validateAssetRepo);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/assetRepoEndpoint/:assetRepoEndpointId:
     *   get:
     *     tags:
     *       - AssetRepoEndpoint
     *     summary: Gets all assetRepoEndpoint
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: assetRepoEndpointId
     *         description: The id of the specified assetRepoEndpoint.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: assetRepoEndpoint
     */
    this.router.get(`${this.path}/:assetRepoEndpointId`, this.assetRepoEndpointController.getAssetRepoEndpointById);
  }
};
