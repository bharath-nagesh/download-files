const { DataTypes, Model } = require('sequelize');
const connection = require('../../../config/db.conf').getConnection();

/**
 * @swagger
 * components:
 *   schemas:
 *     AssetRepoEndpoint:
 *       type: object
 *       required:
 *         - key
 *         - connectionName
 *         - username
 *         - password
 *         - isActive
 *       properties:
 *         key:
 *           type: string
 *         connectionName:
 *           type: string
 *         port:
 *           type: number
 *         username:
 *           type: string
 *         password:
 *           type: string
 *         vcd_vms_only:
 *           type: string
 *         parameters:
 *           type: string
 *         isActive:
 *           type: string
 * @param sequelize
 */
class AssetRepoEndpoint extends Model {
  static init(sequelize) {
    return super.init({
        key: { type: DataTypes.STRING, allowNull: false, defaultValue: ' ' },
        name: { type: DataTypes.STRING, allowNull: true, field: 'name' },
        connectionName: { type: DataTypes.STRING, allowNull: false, field: 'connection_name' },
        port: { type: DataTypes.INTEGER },
        username: { type: DataTypes.STRING, field: 'user_name', allowNull: false },
        password: { type: DataTypes.STRING, field: 'password', allowNull: false },
        vcd_vms_only: { type: DataTypes.STRING, field: 'vcd_vms_only', allowNull: true },
        ecHostName: { type: DataTypes.STRING, allowNull: true, field: 'ec_host_name' },
        isActive: { type: DataTypes.STRING, field: 'is_active', allowNull: false, defaultValue: 'enabled' },
        is_active: { type: DataTypes.STRING, field: 'is_active' },
        parameters: { type: DataTypes.STRING, field: 'parameters', allowNull: true }
      },
      {
        sequelize,
        timestamps: true,
        freezeTableName: true,
        tableName: 'asset_repo_endpoints',
        underscored: true
      });
  }

  static associate(models) {
    AssetRepoEndpoint.hasMany(models.AssetRepoEndpointMembers, { allowNull: false, foreignKey: 'linkId' });
    AssetRepoEndpoint.belongsTo(models.Organization, { allowNull: false, foreignKey: 'organization_id' });
    AssetRepoEndpoint.belongsTo(models.AssetRepoType, { allowNull: false, foreignKey: 'asset_repo_type_id' });
    AssetRepoEndpoint.hasMany(models.MasterNode, { allowNull: false, foreignKey: 'asset_repo_endpoint_id' });
    AssetRepoEndpoint.hasMany(models.vcdVcenterDetails, { allowNull: false, foreignKey: 'asset_repo_endpoint_vcd_id' });
    AssetRepoEndpoint.hasMany(models.SecurityHubDetail,{ foreignKey:'asset_repo_endpoints_id' });
    AssetRepoEndpoint.hasMany(models.VcenterResourceMappings, {
      allowNull: false,
      foreignKey: 'asset_repo_endpoint_id'
    });
  };
}

// setting up the async instance method
AssetRepoEndpoint.assetRepoInfo = async (assetRepoEndpointId, source_org_id, source_loc_id, source_hosting_id, assetRepoType) => {
  let condition = 'ar.id = arem.asset_repo_enpoint_id_source_id';
  if ((assetRepoType.toLowerCase() === 'nsx-t') || (assetRepoType.toLowerCase() === 'nsx-v')) {
    condition = 'ar.id = arem.asset_repo_enpoint_id_link_id';
  }
  const query = `select * from  (select ar.id as vcd_id, organization_id as source_org_id,location_id as source_loc_id,hosting_provider_id as
        source_hosting_id, connection_name, user_name, password, arem.asset_repo_enpoint_id_source_id as source_id, arem.asset_repo_enpoint_id_link_id lookup_id
       from asset_repo_endpoints ar, asset_repo_endpoint_members arem where asset_repo_type_id in (select id from asset_repo_types where name = :assetRepoType)  
       and (ar.is_active='enabled' or ar.is_active = 'true' or ar.is_active = 'disabled')  and ${condition} and ar.id = :id) vcd, (select connection_name as link_connection_name,
        user_name as link_user_name, password as link_password, ar1.id as lookup_ref_id from asset_repo_endpoints ar1 ) vlookup where lookup_ref_id = source_id 
        and source_org_id =:source_org_id and source_loc_id =:source_loc_id and source_hosting_id = :source_hosting_id`;

  const data = await connection.query(query, {
    replacements: {
      id: assetRepoEndpointId,
      source_org_id: source_org_id,
      source_loc_id: source_loc_id,
      source_hosting_id: source_hosting_id,
      assetRepoType: assetRepoType
    },
    type: connection.QueryTypes.SELECT
  });
  return data || [];
};

module.exports = AssetRepoEndpoint;
