const validator = require('validator');
const checkId = require('../../../utils/checkId');
const CheckIp = require('../../../utils/checkIp');
const paginate = require('../../middlewares/paginate.middleware');
const JobService = require('../job/job.service');
const jobService = new JobService();
const AssetRepoEndpointService = require('./assetRepoEndpoint.service');
const assetRepoEndpointService = new AssetRepoEndpointService();
const AssetRepoType = require('./assetRepoType.model');
const errorHandler = require('../../../utils/errorHandler');
const Validator = require('../../../utils/validator');
const isAppliance = require('../../../utils/isAppliance');
const url = require('url');
const logger = require('../../../utils/logger').logger;
const { toLower } = require('lodash');

const loggerLabel = 'AssetRepoEndpointController';

module.exports = class AssetRepoEndpointController {
  constructor() {
    logger.debug('assetRepoEndpointController constructor', { loggerLabel });
  }

  async getAllAssetRepoEndpoint(req, res) {
    const orgId = req.params.orgId || req.params.serviceProviderId;
    const isServiceProvider = req.params.serviceProviderId ? true : false;
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    const dropdown = req.query.dropdown || false;
    const parametersCheck = req.query.parameters || 'any';
    let type = req.query.type;

    if (!type) {
      type = 'All';
    }
    if (type.toLowerCase() === 'software') {
      const results = [];
      return res.json({
        total_page_count: 0,
        pageLimit: limit,
        total_record_count: 0,
        page_number: pageNumber,
        assetRepoEndpoints: results,
        pages: paginate.getArrayPages(req)(3, 0, req.query.page)
      });
    }
    const assetType = type;
    try {
      const results = await assetRepoEndpointService.getAllAssetRepoEndpoints(orgId, limit, offset, assetType, isServiceProvider, dropdown, parametersCheck);
      const itemCount = results.length;
      const pageCount = Math.ceil(itemCount / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        assetRepoEndpoints: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error('Unable to get asset repos', { loggerLabel, error });
      return errorHandler(req, res, error);
    }
  }

  async getAssetRepoEndpointTypes(req, res) {
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    const isServiceProvider = req.params.serviceProviderId ? true : false;
    try {
      const results = await assetRepoEndpointService.getAssetRepoEndpointTypes(isServiceProvider, limit, offset);
      const itemCount = await assetRepoEndpointService.getAssetRepoEndpointTypesCount();
      const pageCount = Math.ceil(itemCount / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        assetRepoEndpointsType: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      return errorHandler(req, res, error);
    }

  }

  async getAssetRepoEndpointById(req, res) {
    const assetRepoEndpointId = req.params.assetRepoEndpointId;
    const orgId = req.params.orgId || req.params.serviceProviderId;
    if (checkId(assetRepoEndpointId)) {
      logger.error({ assetRepoEndpointId }, 'Error with AssetRepoEndpoint Id');
      const e = new Error('Bad AssetRepoEndpoint Id');
      e.status = 400;
      return errorHandler(req, res, e);
    }
    try {
      const assetRepoEndpoint = await assetRepoEndpointService.getAssetRepoEndpoint(assetRepoEndpointId, orgId);
      if (!assetRepoEndpoint) {
        const e = new Error('Asset Repo Endpoint not found');
        e.status = 404;
        throw e;
      }
      return res.json(assetRepoEndpoint);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async updateAssetRepoEndpoint(req, res) {
    const orgId = req.params.orgId || req.params.serviceProviderId;
    const params = req.body;
    params.organization_id = orgId;

    // validating parameters
    try {
      params.isActive = params.isActive ? params.isActive.toString().toLowerCase() : null;
      if(params.type_id && parseInt(params.type_id) === 2 && !params.tenantCreation) {
        params.tenantCreation = 'manual';
      }
      if(params.type_id && parseInt(params.type_id) === 16 && req.file){
        if(req.file.mimetype === 'application/json'){
          try{
            JSON.parse(req.file.buffer.toString());
          } catch(e){
            const error = new Error('Invalid JSON File Uploaded');
            logger.error({ error }, 'Invalid JSON File Uploaded');
            error.status = 400;
            return errorHandler(req, res, error);
          }
        }
        params.password = req.file.buffer.toString('base64');
      }
      await Validator.validateParams({
        assetRepoEndpointId: 'integer',
        connectionName: 'sometimes|string',
        username: 'nullable',
        password: 'nullable',
        type_id: 'required|integer',
        sourceId: 'nullable',
        folder: 'array',
        dataCenter: 'array',
        resourcePool: 'array',
        masterNode_host_name: 'nullable',
        masterNode_username: 'nullable',
        masterNode_password: 'nullable',
        organization_id: 'required|integer',
        location_id: 'required|integer',
        hosting_provider_id: 'required|integer',
        tenantCreation: 'requiredIf:type_id,2|in:auto,manual',
        resourceType: 'requiredIf:type_id,2|requiredIf:tenantCreation,auto|in:ResourcePool,Folder,Datacenter',
        isActive: 'required|in:enabled,disabled'
      }, params);
      if (params.type_id != '8' && params.type_id != '12' && params.type_id != '16') { // exluding AWS and Azure
        if (!CheckIp.checkIp(params.connectionName)) {
          const urlParts = url.parse(params.connectionName);
          if (urlParts.protocol !== 'http:' && urlParts.protocol !== 'https:' && urlParts.protocol !== 'ldap:') {
            const error = new Error('Invalid Connection Name');
            logger.error({ error }, 'Invalid Connection Name');
            error.status = 422;
            return errorHandler(req, res, error);
          }
        }
      }
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }

    // updating and scheduling if necessary
    const assetRepoEndpointId = req.params.assetRepoEndpointId;
    let scheduleJob;
    const userToken = req.authInfo;
    const loggedInUserId = req.user.id;
    const loginUserOrganizationId = req.user.Organizations[0].id;
    let jobName;
    let type;
    try {
      // updating the asset repo
      const ScheduleTask = require('../../models/scheduleTask.model');
      const Job = require('../job/job.model');
      const updateResult = await assetRepoEndpointService.updateAssetRepoEndpoint(loggedInUserId, userToken, assetRepoEndpointId, params, orgId);
      const result = await ScheduleTask.findAll({
        where: {
          asset_repo_id: assetRepoEndpointId,
          is_active: { $ne: 'false' }
        }
      });

      // scheduling jobs based off of the repo's status
      const isActive = params.isActive === 'disabled' ? params.isActive : 'enabled';
      const createModifyJob = isActive === 'disabled' ? 'unSchedule' : 'Modify';
      await ScheduleTask.update({ isActive }, {
        where: {
          asset_repo_id: assetRepoEndpointId,
          is_active: { $ne: 'false' }
        }
      });
      for (let i = 0; i < result.length; i++) {
        scheduleJob = result[i];
        const jobId = scheduleJob.job_id;
        jobName = scheduleJob.name;
        const job = await Job.findOne({ where: { id: jobId } });
        type = job.name;
        await jobService.createModifyScheduleJob(scheduleJob, loggedInUserId, userToken, loginUserOrganizationId, createModifyJob, jobName, type);
      }
      return res.json(updateResult);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async createAssetRepoEndpoint(req, res) {
    const params = req.body;
    const orgId = req.params.orgId || req.params.serviceProviderId;
    params.organization_id = orgId;
    try {
      params.isActive = params.isActive ? params.isActive.toString().toLowerCase() : 'enabled';
      if(params.type_id && parseInt(params.type_id) === 2 && !params.tenantCreation) {
        params.tenantCreation = 'manual';
      }
      if(params.type_id && parseInt(params.type_id) === 16){
        if(req.file && req.file.mimetype === 'application/json'){
          try{
            JSON.parse(req.file.buffer.toString());
          } catch(e){
            const error = new Error('Invalid JSON File Uploaded');
            logger.error({ error }, 'Invalid JSON File Uploaded');
            error.status = 400;
            return errorHandler(req, res, error);
          }
        }
        params.password = req.file ? req.file.buffer.toString('base64') : null;
      }
      if (!isAppliance()) {
        await Validator.validateParams({
          connectionName: 'sometimes|string',
          username: 'nullable',
          password: 'requiredIf:type_id,16',
          type_id: 'required|integer',
          sourceId: 'nullable',
          folder: 'array',
          dataCenter: 'array',
          resourcePool: 'array',
          masterNode_host_name: 'nullable',
          masterNode_username: 'nullable',
          masterNode_password: 'nullable',
          organization_id: 'required|integer',
          location_id: 'required|integer',
          hosting_provider_id: 'required|integer',
          tenantCreation: 'requiredIf:type_id,2|in:auto,manual',
          resourceType: 'requiredIf:type_id,2|requiredIf:tenantCreation,auto|in:ResourcePool,Folder,Datacenter',
          isActive: 'required|in:enabled,disabled,true'
        }, params);
      }

      if (params.type_id != '8' && params.type_id != '12' && params.type_id != '16') { // exluding AWS and Azure
        const urlParts = url.parse(params.connectionName);
        urlParts.hostname = urlParts.hostname || urlParts.href;
        if (!CheckIp.checkIp(urlParts.hostname)) {
          if (urlParts.protocol && (urlParts.protocol !== 'http:' && urlParts.protocol !== 'https:' && urlParts.protocol !== 'ldap:')) {
            const error = new Error('Invalid Connection Protocol');
            logger.error({ error }, 'Invalid Connection Protocol');
            error.status = 422;
            return errorHandler(req, res, error);
          }
          if (!/^(?!:\/\/)([a-zA-Z0-9-]+\.){0,5}[a-zA-Z0-9-][a-zA-Z0-9-]+\.[a-zA-Z]{2,64}?$/gi.test(urlParts.hostname)) {
            const error = new Error('Invalid Connection Name');
            logger.error({ error }, 'Invalid Connection Name');
            error.status = 422;
            return errorHandler(req, res, error);
          }
        }
      }
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const userToken = req.authInfo;
    const loggedInUserId = req.user.id;
    params.vcd_vms_only = (params.type_id === '1') ? params.vcd_vms_only || null : null; // for VCD only
    try {
      const createResponse = await assetRepoEndpointService.create(loggedInUserId, userToken, orgId, params);
      return res.json(createResponse);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async updateCRFAssetRepoEndpoint(req, res) {
    const params = req.body;
    try {

      await Validator.validateParams({
        LookupConnectionName: 'required|string',
        vCDConnectionName: 'required|string',
        isActive: 'required|in:enabled,disabled'
      }, params);

    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }

    const assetRepoEndpointId = req.params.assetRepoEndpointId;
    const orgId = req.params.orgId || req.params.serviceProviderId;
    const userToken = req.authInfo;
    const loggedInUserId = req.user.id;
    try {
      const assetRepoEndpoint = await assetRepoEndpointService.updateCRFAssetRepoEndpoint(loggedInUserId, userToken, assetRepoEndpointId, params, orgId);
      return res.json(assetRepoEndpoint);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async createCRFAssetRepoEndpoint(req, res) {
    const params = req.body;
    try {
      params.isActive = params.isActive ? params.isActive.toString().toLowerCase() : 'enabled';
      await Validator.validateParams({
        LookupConnectionName: 'required|string',
        vCDConnectionName: 'required|string',
        isActive: 'required|in:enabled,disabled,true'
      }, params);

    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const orgId = req.params.orgId || req.params.serviceProviderId;
    const userToken = req.authInfo;
    const loggedInUserId = req.user.id;
    try {
      const assetRepoEndpoint = await assetRepoEndpointService.createCRFAssetRepoEndpoint(loggedInUserId, userToken, orgId, params);
      return res.json(assetRepoEndpoint);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getBulkAssetRepoEndpointMembersById(req, res) {
    const assetRepoEndpointIdList = req.query.id.split(',');
    try {
      const assetRepoEndpoint = await assetRepoEndpointService.getBulkAssetRepoEndpointMembersById(assetRepoEndpointIdList);
      if (!assetRepoEndpoint) {
        const result = 'not found';
        return res.json(result);
      }
      return res.json(assetRepoEndpoint);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async assetRepoTestConnection(req, res) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const params = req.body;
    try {
      if(params.type_id && parseInt(params.type_id, 10) === 16 && req.file) {
        params.password = req.file.buffer.toString();
      }
      await Validator.validateParams({
        connectionName: 'required|string',
        username: 'required|string',
        password: 'required|string',
        type_id: 'required|integer'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const user = params.username;
    const password = params.password;
    let connName = params.connectionName;
    const typeId = params.type_id;
    const auth = 'Basic ' + Buffer.from(user + ':' + password).toString('base64');

    let hostName = '';
    let protocol = '';
    let pathName;
    let port;
    const stringLength = connName.length;
    const lastChar = connName.charAt(stringLength - 1);
    if (lastChar === '/') {
      connName = connName.slice(0, -1);
    }
    if (validator.contains(connName, '://')) {
      const a = require('url').parse(connName, true);
      hostName = a.host;
      protocol = a.protocol;
      pathName = a.path;
      port = a.port;
    } else {
      connName = `https://${connName}`;
      const a = require('url').parse(connName, true);
      hostName = a.host;
      protocol = a.protocol;
      pathName = a.path;
      port = a.port;
    }
    if (pathName != null) {
      hostName = hostName + pathName;
    }
    const assetType = await AssetRepoType.findOne({ where: { id: typeId } });
    const typeName = toLower(assetType.name);
    let result = false;
    try {
      if (typeName === 'vcenter') {
        result = await assetRepoEndpointService.testVCenterConnection(protocol, hostName, auth);
      } else if (typeName === 'nsx-v') {
        result = await assetRepoEndpointService.testNSXConnection(protocol, hostName, auth);
      } else if (typeName === 'nsx-t') {
        result = await assetRepoEndpointService.testNSXTConnection(protocol, hostName, auth);
      } else if (typeName === 'lookupurl' || typeName === 'ad') {
        if (hostName.includes(':')) {
          hostName = hostName.split(':')[0];
          if (pathName != null) {
            hostName = hostName + pathName;
          }
        }
        result = await assetRepoEndpointService.testLookupAndAdConnection(connName, hostName, user, password, typeName, port);
      } else if (typeName === 'vcd') {
        result = await assetRepoEndpointService.testVCDConnection(protocol, hostName, auth);
      } else if (typeName === 'aws') {
        const region = params.connectionName;
        const accessKeyId = params.username;
        const secretAccessKey = params.password;
        result = await assetRepoEndpointService.testAWSConnection(accessKeyId, secretAccessKey, region);
      } else if (typeName === 'gcp') {
        const project = params.username;
        if (!req.file) {
          const error = new Error(`GCP Service Account Key File Missing`);
          error.status = 400;
          throw error;
        }
        result = await assetRepoEndpointService.testGCPConnection(project, req.file);
      } else if (typeName === 'azure') {
        const clientId = params.username;
        const secret = params.password;
        const domain = params.key;
        result = await assetRepoEndpointService.testAzureConnection(clientId, secret, domain);
      } else if (typeName === 'openshift') {
        result = await assetRepoEndpointService.testOpenShiftConnection(protocol, hostName, auth);
      } else if (typeName === 'openstack') {
        result = await assetRepoEndpointService.testOpenStackConnection(protocol, hostName, port, user, password, auth);
      }
      if (!result) {
        const error = new Error(`Test Connection for ${typeName} is not available`);
        error.status = 400;
        throw error;
      }
      return res.json(result);
    } catch (e) {
      return errorHandler(req, res, e);
    }
  }

  async CRFassetRepoTestConnection(req, res) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const params = req.body;
    const VCDuser = params.vCDUserName;
    const VCDpassword = params.vCDPassword;
    let VCDconnName = params.vCDConnectionName;
    const lookUpuser = params.lookupUserName;
    const lookUppassword = params.lookupPassword;
    let lookUpconnName = params.lookupConnectionName;
    const typeId = params.typeId;
    let typeName;
    const auth = 'Basic ' + new Buffer(VCDuser + ':' + VCDpassword).toString('base64');

    let VCDhostName;
    let VCDprotocol;
    let VCDpathName;
    let VCDport;
    const stringLength = VCDconnName.length;
    const lastChar = VCDconnName.charAt(stringLength - 1);
    if (lastChar === '/') {
      VCDconnName = VCDconnName.slice(0, -1);
    }
    if (!VCDuser || !VCDpassword) {
      logger.info('Enter valid User Name / Password');
      const err = new Error('Enter valid User Name / Password');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    if (!typeId) {
      logger.info('Enter valid Asset Repository Type');
      const err = new Error('Enter valid Asset Repository Type');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    let a;
    if (!validator.contains(VCDconnName, '://')) {
      VCDconnName = 'https://' + VCDconnName;
    }
    a = require('url').parse(VCDconnName, true);
    VCDhostName = a.host;
    VCDprotocol = a.protocol;
    VCDpathName = a.path;
    VCDport = a.port;
    if (VCDpathName != null) {
      VCDhostName = VCDhostName + VCDpathName;
    }

    //====

    let lookUphostName;
    let lookUpprotocol;
    let lookUppathName;
    let lookUpport;
    const stringLULength = lookUpconnName.length;
    const lastLUChar = lookUpconnName.charAt(stringLULength - 1);
    if (lastLUChar === '/') {
      lookUpconnName = lookUpconnName.slice(0, -1);
    }
    if (!lookUpuser || !lookUppassword) {
      logger.info('Enter valid User Name / Password');
      const err = new Error('Enter valid User Name / Password');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    let b;

    if (!validator.contains(lookUpconnName, '://')) {
      lookUpconnName = 'https://' + lookUpconnName;
    }
    b = require('url').parse(lookUpconnName, true);

    lookUphostName = b.host;
    lookUpprotocol = b.protocol;
    lookUppathName = b.path;
    lookUpport = b.port;
    if (lookUppathName != null) {
      lookUphostName = lookUphostName + lookUppathName;
    }
    const assetType = await assetRepoEndpointService.checkType(typeId);
    typeName = assetType.name;

    let LookUpresult = '';
    let VCDresult = '';

    try {
      if (typeName.toLowerCase() === 'vcd') {
        VCDresult = await assetRepoEndpointService.testVCDConnection(VCDprotocol, VCDhostName, auth);

        if (lookUphostName.includes(':')) {
          lookUphostName = lookUphostName.split(':')[0];
          if (lookUppathName != null) {
            lookUphostName = lookUphostName + lookUppathName;
          }
        }
        LookUpresult = await assetRepoEndpointService.testLookupAndAdConnection(lookUpconnName, lookUphostName, lookUpuser, lookUppassword, 'lookupurl', lookUpport);

        if (!(VCDresult.length > 0 && LookUpresult.connection.includes('Connection Successful.'))) {
          LookUpresult.connection = 'Connection Failed.';
        }
      }
      return res.json(LookUpresult);
    } catch (e) {
      return errorHandler(req, res, e);
    }
  }

  async deleteMultipleAssetRepoEndpoints(req, res) {
    const userToken = req.authInfo;
    const loggedInUserId = req.user.id;
    const loginUserOrganizationId = req.user.Organizations[0].id;
    const createModifyJob = 'Delete';
    let scheduleJob;
    let typeName;
    let jobName;
    const assetRepoEndpointIdList = req.query.id.split(',');
    const orgId = req.params.orgId || req.params.serviceProviderId;
    try {
      // todo look into the use of models in this controller
      const ScheduleTask = require('../../models/scheduleTask.model');
      const Job = require('../job/job.model');
      const multiDeleteResponse = await assetRepoEndpointService.deleteMultipleAssetRepoEndpoints(assetRepoEndpointIdList, orgId, loggedInUserId, userToken);
      const result = await ScheduleTask.findAll({ where: { asset_repo_id: { $in: assetRepoEndpointIdList } } });
      await ScheduleTask.update({ isActive: 'false' }, { where: { asset_repo_id: { $in: assetRepoEndpointIdList } } });
      for (let i = 0; i < result.length; i++) {
        scheduleJob = result[i];
        const jobId = scheduleJob.job_id;
        jobName = scheduleJob.name;
        const job = await Job.findOne({ where: { id: jobId } });
        typeName = job.name;
        await jobService.createModifyScheduleJob(scheduleJob, loggedInUserId, userToken, loginUserOrganizationId, createModifyJob, jobName, typeName);
      }
      return res.json(multiDeleteResponse);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async validateAssetRepo(req, res) {
    const orgId = req.params.orgId || req.params.serviceProviderId;
    try {
      const validAssetRepoJSON = await assetRepoEndpointService.validateAssetRepo(orgId);
      return res.json(validAssetRepoJSON);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async syncVCenter(req, res) {
    const assetRepoId = req.params.assetRepoEndpointId;

    try {
      const data = await assetRepoEndpointService.syncVcenter(assetRepoId);
      return res.json(data);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getUnmappedVCenters(req, res) {
    try {
      const data = await assetRepoEndpointService.getUnMappedVCenters();
      return res.json(data);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }

  }

  async addOrgMappingToVCenter(req, res) {
    const { assetRepoEndpointId } = req.params;
    const { type, values, orgId } = req.body;
    try {
      const data = await assetRepoEndpointService.addOrgVcenterMapping(orgId, assetRepoEndpointId, type, values);
      return res.json(data);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      error.status = error.status || 400;
      return errorHandler(req, res, error);
    }
  }

  async getOrgMappingToVCenter(req, res) {
    const { serviceProviderId, assetRepoEndpointId } = req.params;
    try {
      const data = await assetRepoEndpointService.getOrgVcenterMapping(serviceProviderId, assetRepoEndpointId);
      return res.json(data);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async deleteOrgMappingToVCenter(req, res) {
    const { serviceProviderId, assetRepoEndpointId } = req.params;
    try {
      const data = await assetRepoEndpointService.deleteOrgVcenterMapping(serviceProviderId, assetRepoEndpointId);
      return res.json(data);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getVMCVcenterDetails(req, res) {
    const userToken = req.authInfo;
    const loggedInUserId = req.user.id;
    const loginUserOrganizationId = req.user.Organizations[0].id;
    const body = req.body;
    try {
      const result = await assetRepoEndpointService.getVMCVcenterDetails(userToken, loggedInUserId, loginUserOrganizationId, body);
      return res.json(result);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }
};
