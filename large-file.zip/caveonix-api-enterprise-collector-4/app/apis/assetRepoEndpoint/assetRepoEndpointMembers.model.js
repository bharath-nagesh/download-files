const Sequelize = require('sequelize');

class AssetRepoEndpointMembers extends Sequelize.Model {
  static init(sequelize) {
    return super.init(
      {
        /* id: {
          type: Sequelize.INTEGER,
          primaryKey: true,
          autoIncrement: true
        }, */
        //asset_repo_enpoint_id_source_id: { type: Sequelize.STRING,field: 'asset_repo_enpoint_id_source_id'},
        sourceId: { type: Sequelize.STRING, field: 'asset_repo_enpoint_id_source_id' },
        linkId: { type: Sequelize.STRING, field: 'asset_repo_enpoint_id_link_id' }
      },
      {
        timestamps: false,
        freezeTableName: true,
        tableName: 'asset_repo_endpoint_members',
        underscored: true,
        sequelize
      }
    );
  }

 static associate(models) {
    /* // AssetRepoEndpointMembers.hasMany(models.AssetRepoEndpoint,{foreignKey: 'id'});
    AssetRepoEndpointMembers.belongsTo(models.AssetRepoEndpoint,{foreignKey: 'id'}); */
    AssetRepoEndpointMembers.belongsTo(models.AssetRepoEndpoint,
      { foreignKey: 'asset_repo_enpoint_id_source_id', targetKey: 'id' });
  };
}

module.exports = AssetRepoEndpointMembers;
