const expect = require('chai').expect;
const proxyquire = require('proxyquire').noCallThru();
const httpMocks = require('node-mocks-http');

describe('AMQPController', function () {
  beforeEach(() => {

  });

  describe('getAllAmqp', () => {
    it('should return a list of amqp', async () => {
      const amqpResponse = { test: 'test' };
      const amqpServiceStub = class AMQPService {
        constructor() { }

        getAllAmqpDetails() { return amqpResponse; }
      };
      const AMQPController = proxyquire('./amqp.controller', {
        './amqp.service': amqpServiceStub
      });

      const amqpController = new AMQPController();
      const req = httpMocks.createRequest({});
      const res = httpMocks.createResponse();
      const details = await amqpController.getAllAmqp(req, res);
      const amqp = details._getJSONData();
      expect(amqp).to.deep.equal(amqpResponse);
    });

    it('should not return a list of amqp', async () => {
      const amqpServiceStub = class AMQPService {
        constructor() { }

        getAllAmqpDetails() {
          const e = new Error('Bad request');
          e.status = 400;
          throw e;
        }
      };
      const AMQPController = proxyquire('./amqp.controller', {
        './amqp.service': amqpServiceStub
      });

      const amqpController = new AMQPController();
      const req = httpMocks.createRequest({});
      const res = httpMocks.createResponse();
      await amqpController.getAllAmqp(req, res);

      expect(res.statusCode).to.be.equal(400);
    });
  });

  describe('getAmqpDetailsByOrgId', () => {
    it('should return getAmqpDetailsByOrgId data', async () => {
      const orgId = 10;
      const limit = 10;
      const offset = 0;
      const page = 1;

      const amqpResponse = {
        total_page_count: 1,
        pageLimit: limit,
        total_record_count: 10,
        page_number: page,
        ampqDetails: 10,
        pages: [{
          number: 1,
          url: 'null?page=' + page
        }]
      };

      const amqpResponseCount = 10;
      const amqpServiceStub = class AMQPService {
        constructor() { }

        getAmqpDetailsByOrgId() { return Promise.resolve(orgId, limit, offset); }

        getAmqpDetailsCount() { return Promise.resolve(amqpResponseCount); }
      };
      const AMQPController = proxyquire('./amqp.controller', {
        './amqp.service': amqpServiceStub
      });

      const amqpController = new AMQPController();
      const req = httpMocks.createRequest({ params: { orgId }, query: { page } });
      const res = httpMocks.createResponse({ locals: { paginate: { limit, offset, page } } });
      const details = await amqpController.getAmqpDetailsByOrgId(req, res);
      const amqp = details._getData();
      expect(JSON.parse(amqp)).to.deep.equal(amqpResponse);
    });
  });

  describe('getAmqpDetailsById', () => {
    it('should return getAmqpDetailsById data', async () => {
      const amqpDetails = { test: 1 };
      const amqpDetailsId = 1;
      const amqpServiceStub = class AMQPService {
        constructor() { }

        getAmqpDetailsId() { return Promise.resolve(amqpDetails); }
      };
      const AMQPController = proxyquire('./amqp.controller', {
        './amqp.service': amqpServiceStub
      });

      const amqpController = new AMQPController();
      const req = httpMocks.createRequest({ params: { amqpDetailsId } });
      const res = httpMocks.createResponse();
      const details = await amqpController.getAmqpDetailsById(req, res);
      const amqp = details._getData();
      expect(JSON.parse(amqp)).to.deep.equal(amqpDetails);
    });
  });

  describe('createAmqpDetails', () => {
    it('should return createAmqpDetails data', async () => {
      const amqpBody = {
        body: {
          host_name: 'test amqp 01',
          port: {
            trim(){
              return 10;
            }
          },
          virtual_host: 'vhost',
          user_name: 'username',
          password: 'passw',
          exchange_name: 'exc',
          exchange_type: 'Topic',
          queue_name: 'quename',
          routing_key: 'key',
          durable: 'true',
          organization_id: 0,
          source_manager_id: 0,
          isActive: 'enabled',
          auto_delete: 'true',
          queue_durable: 'true',
          queue_auto_delete: 'true'
        }
      };
      const amqpServiceStub = class AMQPService {
        constructor() { }

        create() { return Promise.resolve(amqpBody); }
      };
      const AMQPController = proxyquire('./amqp.controller', {
        './amqp.service': amqpServiceStub
      });

      const amqpController = new AMQPController();
      const req = httpMocks.createRequest(amqpBody);
      const res = httpMocks.createResponse();
      const details = await amqpController.createAmqpDetails(req, res);
      const amqp = details._getData();
      expect(JSON.parse(amqp)).to.deep.equal(amqpBody);
    });
  });

  describe('updateAmqpDetailsById', () => {
    it('should return updateAmqpDetailsById data', async () => {
      const amqpDetailsId = 10;
      const amqpBody = {
        body: {
          host_name: 'test amqp 01',
          port: {
            trim(){
              return 10;
            }
          },
          virtual_host: 'vhost',
          user_name: 'username',
          password: 'passw',
          exchange_name: 'exc',
          exchange_type: 'Topic',
          queue_name: 'quename',
          routing_key: 'key',
          durable: 'true',
          organization_id: 0,
          source_manager_id: 0,
          isActive: 'enabled',
          auto_delete: 'true',
          queue_durable: 'true',
          queue_auto_delete: 'true'
        },
        params: { amqpDetailsId }
      };
      const amqpServiceStub = class AMQPService {
        constructor() { }

        updateAmqpDetailsById() { return Promise.resolve(amqpBody); }
      };
      const AMQPController = proxyquire('./amqp.controller', {
        './amqp.service': amqpServiceStub
      });

      const amqpController = new AMQPController();
      const req = httpMocks.createRequest(amqpBody);
      const res = httpMocks.createResponse();
      const details = await amqpController.updateAmqpDetailsById(req, res);
      const amqp = details._getData();
      expect(JSON.parse(amqp)).to.deep.equal(amqpBody);
    });
  });

  describe('deleteMultipleAmqp', () => {
    it('should return getAmqpDetailsByOrgId data', async () => {
      const amqpResponseArr = 10;
      const amqpServiceStub = class AMQPService {
        constructor() { }

        deleteMultipleAmqpDetails() { return Promise.resolve(amqpResponseArr); }
      };
      const AMQPController = proxyquire('./amqp.controller', {
        './amqp.service': amqpServiceStub
      });

      const amqpController = new AMQPController();
      const req = httpMocks.createRequest({});
      const res = httpMocks.createResponse();
      const details = await amqpController.deleteMultipleAmqp(req, res);
      const amqp = details._getJSONData();
      expect(amqp).to.deep.equal(amqpResponseArr);
    });
  });

  describe('amqpTestConnection', () => {
    it('should return amqpTestConnection data', async () => {
      const amqpBody = {
        body: {
          host_name: 'test amqp 01',
          port: 10,
          hostname: 'vhost',
          user: 'username',
          password: 'passw',
          vhost: 'a'
        }
      };
      const success = {
        message: 'AMQP test connection is successful.',
        success: true
      };
      const amqpServiceStub = class amqp {
        constructor() { }
      };
      const amqplibStub = class amqp {
        constructor() { }

        static async connect(uri) {
          let finaldata =  await success;
          return finaldata;
        }
      };
      const AMQPController = proxyquire('./amqp.controller', {
        './amqp.service': amqpServiceStub,
        'amqplib': amqplibStub
      });

      const amqpController = new AMQPController();
      const req = httpMocks.createRequest(amqpBody);
      const res = httpMocks.createResponse();
      const details = await amqpController.amqpTestConnection(req, res);
      const amqp = details._getData();
      expect(JSON.parse(amqp)).to.deep.equal(success);
    });
  });
});
