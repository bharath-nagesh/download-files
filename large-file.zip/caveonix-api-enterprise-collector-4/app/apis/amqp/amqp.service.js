const AmqpDetails = require('./amqpDetails.model');
const AssetRepoEndpoint = require('../assetRepoEndpoint/assetRepoEndpoint.model');
const AssetRepoType = require('../assetRepoEndpoint/assetRepoType.model');
const sequelize = require('sequelize');
const validator = require('validator');
const KeyGenerator = require('../../../utils/generateKeys');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-amqp.service'
});
const Organization = require('../organization/organization.model');

module.exports = class AMQPService {
  constructor() {
    this.keyGenerator = new KeyGenerator();
    logger.debug('called AMQPService constructor');
  }

  async getAllAmqpDetails() {
    const data = await AmqpDetails.findAll({
      where: { isActive: { $ne: 'false' } },
      order: [['id', 'ASC']],
      include: [{ model: Organization }, {
        model: AssetRepoEndpoint,
        include: [{ model: AssetRepoType }]
      }]
    });
    return data;
  }

  async getAmqpDetailsByOrgId(orgId, limit, offset) {
    const orgChain = await Organization.getOrgChain(orgId);
    const data = await AmqpDetails.findAll({
      where: { isActive: { $ne: 'false' }, organization_id: orgChain },
      order: [['id', 'ASC']],
      limit: limit,
      offset: offset,
      include: [{ model: Organization }, {
        model: AssetRepoEndpoint,
        include: [{ model: AssetRepoType }]
      }]
    });
    return data;
  }

  async getAmqpDetailsCount(orgId) {
    const orgChain = await Organization.getOrgChain(orgId);

    return AmqpDetails.count({
      where: { organization_id: orgChain, isActive: { $ne: 'false' } }
    });
  }

  async getAmqpDetailsId(amqpDetailsId) {

    return AmqpDetails.findOne({
      where: {
        id: amqpDetailsId,
        $or: [{ isActive: { $ne: 'false' } }]
      },
      include: [{ model: Organization }, {
        model: AssetRepoEndpoint,
        include: [{ model: AssetRepoType }]
      }]
    });
  }

  async create(params) {
    let host_name = params.host_name;
    let hostName = '';
    let exists = await this.checkHostName(host_name);
    if (exists) {
      const error = new Error('Duplicate Hostname.');
      error.status = 400;
      throw error;
    }
    let newPassword = await this.keyGenerator.generateKeys(params.password);
    params.password = newPassword;

    if (validator.contains(host_name, '://')) {
      // todo look into this deprecated function
      const parsedUrl = require('url').parse(host_name, true);
      hostName = parsedUrl.host;
      params.host_name = hostName;
    } else {
      host_name = 'https://' + host_name;
      const parsedUrl = require('url').parse(host_name, true);
      hostName = parsedUrl.host;
      params.host_name = hostName;
    }
    let result = await AmqpDetails.create(params);
    return AmqpDetails.findOne({
      where: { id: result.id },
      include: [{ model: Organization }, {
        model: AssetRepoEndpoint,
        include: [{ model: AssetRepoType }]
      }]
    });
  }

  checkHostName(host_name) {
    return AmqpDetails.findOne({
      where: {
        $and: [{
          host_name: sequelize.where(sequelize.fn('LOWER', sequelize.col('host_name')), sequelize.fn('lower', host_name)),
          isActive: { $ne: 'false' }
        }]
      }
    });
  }

  async updateAmqpDetailsById(amqpDetailsId, update) {
    let host_name = update.host_name;
    let hostName = '';

    let exists = await this.checkHostNameForUpdate(host_name, amqpDetailsId);
    if (exists) {
      const error = new Error('Duplicate Hostname.');
      error.status = 400;
      throw error;
    }
    if (update.password) {
      let newPassword = await this.keyGenerator.generateKeys(update.password);
      update.password = newPassword;
    }
    if (validator.contains(host_name, '://')) {
      const parsedUrl = require('url').parse(host_name, true);
      hostName = parsedUrl.host;
      update.host_name = hostName;
    } else {
      host_name = 'https://' + host_name;
      const parsedUrl = require('url').parse(host_name, true);
      hostName = parsedUrl.host;
      update.host_name = hostName;
    }
    let amqpDetails = await AmqpDetails.findOne({ where: { id: amqpDetailsId } });
    let result = await amqpDetails.update(update);
    return AmqpDetails.findOne({
      where: { id: result.id },
      include: [{ model: Organization }, {
        model: AssetRepoEndpoint,
        include: [{ model: AssetRepoType }]
      }]
    });

  }

  checkHostNameForUpdate(host_name, amqpDetailsId) {
    return AmqpDetails.findOne({
      where: {
        $and: [{
          host_name: sequelize.where(sequelize.fn('LOWER', sequelize.col('host_name')), sequelize.fn('lower', host_name)),
          isActive: {
            $ne: 'false'
          }
        }],
        id: {
          $ne: amqpDetailsId
        }
      }
    });
  }

  async deleteById(amqpDetailsId) {
    await AmqpDetails.update({ isActive: false }, { where: { id: amqpDetailsId } });
    return AmqpDetails.findOne({ where: { id: amqpDetailsId } });
  }

  async deleteMultipleAmqpDetails(amqpDetailsIdArr) {
    await AmqpDetails.update({ isActive: false }, { where: { id: amqpDetailsIdArr } });
    return AmqpDetails.findAll({ where: { id: { $in: amqpDetailsIdArr } } });
  }
};
