const AMQPController = require('./amqp.controller');

/**
 * @swagger
 * tags:
 *  - name: AMQP
 *    description: AMQP endpoints
 */
module.exports = class AMQPRouter {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.amqpController = new AMQPController();

      // initializing route
      this.initServiceProvider();
    }
  }

  /**
   * Route initialization and setup
   */
  initServiceProvider() {
    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/amqpDetails:
     *   get:
     *     tags:
     *       - AMQP
     *     summary: Gets a list of all AMQP instances
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: serviceProviderId
     *         description: The Service Provider's Id
     *         in: path
     *         required: true
     *         type: number
     *       - name: orgId
     *         description: The Organizations's Id
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: get all amqp instances
     *       401:
     *         description: unauthorized
     */
    this.router.get(`${this.path}/`, this.amqpController.getAllAmqp);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/amqpDetails/organization/{orgId}:
     *   get:
     *     tags:
     *       - AMQP
     *     summary: Gets a list of all AMQP instances
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: serviceProviderId
     *         description: The Service Provider's Id
     *         in: path
     *         required: true
     *         type: number
     *       - name: orgId
     *         description: The Organizations's Id
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: get all amqp instances
     *       401:
     *         description: unauthorized
     */
    this.router.get(`${this.path}/organization/:orgId`, this.amqpController.getAmqpDetailsByOrgId);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/amqpDetails:
     *   post:
     *     tags:
     *       - AMQP
     *     summary: Creates a AMQP repo
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: serviceProviderId
     *         description: The Service Provider's Id
     *         in: path
     *         required: true
     *         type: number
     *       - name: orgId
     *         description: The Organizations's Id
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/AMQP'

     *     responses:
     *       200:
     *         description: get all amqp instances
     *       401:
     *         description: unauthorized
     */
    this.router.post(`${this.path}/`, this.amqpController.createAmqpDetails);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/amqpDetails/{amqpDetailsId}:
     *   put:
     *     tags:
     *       - AMQP
     *     summary: Updates a specified AMQP repo
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: serviceProviderId
     *         description: The Service Provider's Id
     *         in: path
     *         required: true
     *         type: number
     *       - name: orgId
     *         description: The Organizations's Id
     *         in: path
     *         required: true
     *         type: number
     *       - name: amqpDetailsId
     *         description: The id of the AMQP instance
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/AMQP'
     *     responses:
     *       200:
     *         description: updated instance
     *       401:
     *         description: unauthorized
     */
    this.router.put(`${this.path}/:amqpDetailsId`, this.amqpController.updateAmqpDetailsById);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/amqpDetails/{amqpDetailsId}:
     *   get:
     *     tags:
     *       - AMQP
     *     summary: Gets the AMQP Details by Id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: serviceProviderId
     *         description: The Service Provider's Id
     *         in: path
     *         required: true
     *         type: number
     *       - name: orgId
     *         description: The Organizations's Id
     *         in: path
     *         required: true
     *         type: number
     *       - name: amqpDetailsId
     *         description: The id of the AMQP instance
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: updated instance
     *       401:
     *         description: unauthorized
     */
    this.router.get(`${this.path}/:amqpDetailsId`, this.amqpController.getAmqpDetailsById);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/amqpDetails/testConnection:
     *   post:
     *     tags:
     *       - AMQP
     *     summary: Tests a connection to a AMQP repo
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: serviceProviderId
     *         description: The Service Provider's Id
     *         in: path
     *         required: true
     *         type: number
     *       - name: orgId
     *         description: The Organizations's Id
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/AMQP'
     *     responses:
     *       200:
     *         description: tested AMQP repo
     *       401:
     *         description: unauthorized
     */
    this.router.post(`${this.path}/testConnection`, this.amqpController.amqpTestConnection);

    this.router.delete(`${this.path}/`, this.amqpController.deleteMultipleAmqp);


  }
};
