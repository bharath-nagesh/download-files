const amqp = require('amqplib');
const AMQPService = require('./amqp.service');
const amqpDetailsService = new AMQPService();
const checkId = require('../../../utils/checkId');
const checkName = require('../../../utils/checkName');
const errorHandler = require('../../../utils/errorHandler');
const Validator = require('../../../utils/validator');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-amqp.controller'
});
const paginate = require('../../middlewares/paginate.middleware');
const _ = require('lodash');

module.exports = class AMQPController {
  async getAllAmqp(req, res) {
    try {
      const amqps = await amqpDetailsService.getAllAmqpDetails();
      return res.json(amqps);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getAmqpDetailsByOrgId(req, res) {
    const orgId = req.params.orgId;
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    try {
      const amqpDetailsService = new AMQPService();
      const results = await amqpDetailsService.getAmqpDetailsByOrgId(orgId, limit, offset);
      const itemCount = await amqpDetailsService.getAmqpDetailsCount(orgId);
      const pageCount = Math.ceil(itemCount / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        ampqDetails: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getAmqpDetailsById(req, res) {
    const amqpDetailsId = req.params.amqpDetailsId;

    // amqpIdCheck
    if (checkId(amqpDetailsId)) {
      logger.error({ amqpDetailsId }, 'Error with amqp details id');
      const error = new Error(`Invalid value for amqpDetailsId: ${amqpDetailsId}`);
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const amqpDetailsService = new AMQPService();
      const amqpDetails = await amqpDetailsService.getAmqpDetailsId(amqpDetailsId);
      return res.json(amqpDetails);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async createAmqpDetails(req, res) {
    const params = req.body;
    try {
      params.port = params.port ? params.port.toString().trim() : null;
      await Validator.validateParams({
        host_name: 'required|string',
        port: 'required|integer',
        virtual_host: 'required|string',
        user_name: 'required|string',
        password: 'nullable',
        exchange_name: 'nullable',
        exchange_type: 'required|string',
        queue_name: 'nullable',
        routing_key: 'nullable|string',
        durable: 'nullable|boolean',
        organization_id: 'required|integer',
        source_manager_id: 'required|integer',
        isActive: 'required|in:enabled,disabled,true',
        auto_delete: 'required|boolean',
        queue_durable: 'required|boolean',
        queue_auto_delete: 'required|boolean'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const hostName = params.host_name;
    if (checkName(hostName)) {
      const error = new Error(`Invalid value for host_name: ${hostName}`);
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const result = await amqpDetailsService.create(params);
      return res.json(result);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      if (_.get(error, 'name') === 'SequelizeDatabaseError') {
        error.status = 400;
      }
      return errorHandler(req, res, error);
    }
  }

  async updateAmqpDetailsById(req, res) {
    const update = req.body;
    try {
      params.port = params.port ? params.port.toString().trim() : null;
      await Validator.validateParams({
        host_name: 'required|string',
        port: 'required|integer',
        virtual_host: 'required|string',
        user_name: 'required|string',
        password: 'nullable',
        exchange_name: 'nullable',
        exchange_type: 'required|string',
        queue_name: 'nullable',
        routing_key: 'nullable|string',
        durable: 'nullable|boolean',
        organization_id: 'required|integer',
        source_manager_id: 'required|integer',
        auto_delete: 'required|boolean',
        queue_durable: 'required|boolean',
        queue_auto_delete: 'required|boolean',
        isActive: 'required|in:enabled,disabled'
      }, update);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const amqpDetailsId = req.params.amqpDetailsId;

    // id check
    if (checkId(amqpDetailsId)) {
      logger.error({ amqpDetailsId }, 'Error with amqp details id');
      const error = new Error(`Invalid value for amqpDetailsId: ${amqpDetailsId}`);
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const amqpDetails = await amqpDetailsService.updateAmqpDetailsById(amqpDetailsId, update);
      return res.json(amqpDetails);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async deleteMultipleAmqp(req, res) {
    const amqpDetailsId = req.query.id || '';

    try {
      const amqpDetailsIdArr = amqpDetailsId.split(',');
      const update = await amqpDetailsService.deleteMultipleAmqpDetails(amqpDetailsIdArr);
      logger.info(`Deleted multiple AMQP Repos with the ids ${amqpDetailsIdArr}`);
      return res.json(update);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async amqpTestConnection(req, res) {
    const params = req.body;
    try {
      await Validator.validateParams({
        user: 'required|string',
        password: 'nullable',
        hostname: 'required|string',
        vhost: 'nullable',
        port: 'required|integer'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const username = params.user;
    const password = params.password;
    const hostname = params.hostname;
    const port = params.port;
    const vhost = params.vhost;
    const uri = `amqp://${username}:${password}@${hostname}:${port}/${vhost}`;
    try {
      const amqpConnection = await amqp.connect(uri);

      return res.json({
        message: 'AMQP test connection is successful.',
        success: true
      });
    } catch (error) {
      if (error.message.includes('ENOTFOUND') || error.message.includes('EHOSTUNREACH') || (error.statusCode && error.statusCode === 404)) {
        logger.error({ error, stack: error.stack }, 'AMQP hostname is invalid or unreachable');
        error.status = 400;
        error.message = 'AMQP hostname is invalid or unreachable';
      } else if (error.message.includes('ETIMEDOUT')) {
        logger.error({ error, stack: error.stack }, 'AMQP Connection Timeout');
        error.status = 400;
        error.message = 'AMQP Connection Timeout';
      } else if (error.message.includes('ECONNREFUSED')) {
        logger.error({ error, stack: error.stack }, 'AMQP Connection Refused');
        error.status = 400;
        error.message = 'AMQP Connection Refused';
      } else if (error.statusCode && error.statusCode === 401) {
        logger.error({ error, stack: error.stack }, 'AMQP Username or Password is invalid');
        error.status = 400;
        error.message = 'AMQP Username or Password is invalid';
      } else {
        error.status = 400;
        error.message = error.message || `Connection Failed: ${error.code || 'Unknown Failure'}`;
      }
      return errorHandler(req, res, error);
    }
  }
};
