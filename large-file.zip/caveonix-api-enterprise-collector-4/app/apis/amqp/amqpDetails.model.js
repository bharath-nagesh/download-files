const Sequelize = require('sequelize');

/**
 * @swagger
 * components:
 *   schemas:
 *     AMQP:
 *       type: object
 *       required:
 *         - host_name
 *         - isActive
 *         - port
 *         - virtual_host
 *         - user_name
 *         - durable
 *         - exchange_type
 *         - exchange_durable
 *         - auto_delete
 *         - queue_durable
 *         - queue_auto_delete
 *         - organization_id
 *         - source_manager_id
 *       properties:
 *         host_name:
 *           type: string
 *         port:
 *           type: integer
 *         virtual_host:
 *           type: string
 *         user_name:
 *           type: string
 *         password:
 *           type: string
 *         exchange_name:
 *           type: string
 *         exchange_type:
 *           type: string
 *         queue_name:
 *           type: string
 *         routing_key:
 *           type: string
 *         durable:
 *           type: string
 *         organization_id:
 *           type: integer
 *         source_manager_id:
 *           type: integer
 *         isActive:
 *           type: string
 *         auto_delete:
 *           type: string
 *         queue_durable:
 *           type: string
 *         queue_auto_delete:
 *           type: string
 * @param sequelize
 */

class AmqpDetails extends Sequelize.Model {
  static init(sequelize) {
    return super.init(
      {
        id: {
          type: Sequelize.INTEGER,
          primaryKey: true,
          autoIncrement: true
        },
        host_name: {
          type: Sequelize.STRING,
          field: 'host_name'
        },
        port: {
          type: Sequelize.INTEGER,
          field: 'port'
        },
        virtual_host: {
          type: Sequelize.STRING,
          field: 'virtual_host'
        },
        user_name:
          {
            type: Sequelize.STRING,
            field: 'user_name'
          },
        password: {
          type: Sequelize.STRING,
          field: 'password'
        },
        exchange_name: {
          type: Sequelize.STRING,
          field: 'exchange_name'
        },
        exchange_type: {
          type: Sequelize.STRING,
          field: 'exchange_type'
        },
        queue_name: {
          type: Sequelize.STRING,
          field: 'queue_name'
        },
        routing_key: {
          type: Sequelize.STRING,
          field: 'routing_key'
        },
        durable: {
          type: Sequelize.STRING,
          field: 'durable'
        },
        organization_id: {
          type: Sequelize.INTEGER,
          field: 'organization_id'
        },
        source_manager_id:
          {
            type: Sequelize.INTEGER,
            field: 'source_manager_id'
          },
        isActive: {
          type: Sequelize.STRING,
          field: 'is_active'
        },
        is_active: {
          type: Sequelize.STRING,
          field: 'is_active'
        },
        auto_delete: {
          type: Sequelize.STRING,
          field: 'auto_delete'
        },
        queue_durable: {
          type: Sequelize.STRING,
          field: 'queue_durable'
        },
        queue_auto_delete: {
          type: Sequelize.STRING,
          field: 'queue_auto_delete'
        }
      },
      {
        timestamps: false,
        freezeTableName: true,
        tableName: 'amqp_details',
        underscored: true,
        sequelize
      }
    );
  }

  static associate(models) {
    AmqpDetails.belongsTo(models.Organization, { foreignKey: 'organization_id' });
    AmqpDetails.belongsTo(models.AssetRepoEndpoint, { foreignKey: 'source_manager_id' });
  };
}

module.exports = AmqpDetails;
