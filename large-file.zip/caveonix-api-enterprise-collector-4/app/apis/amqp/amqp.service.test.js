const expect = require('chai').expect;
const proxyquire = require('proxyquire').noCallThru();

describe('amqp service', function () {
  beforeEach(() => {

  });

  describe('getAllAmqpDetails', () => {
    it('get list of AMQPs', async () => {
      const response = [
        { name: 'test amqp 1' },
        { name: 'test amqp 2' }
      ];

      class AmqpDetailsStub {
        constructor() {
        }

        static findAll() {
          return Promise.resolve(response);
        }
      };
      const AMQPService = proxyquire('./amqp.service', {
        './amqpDetails.model': AmqpDetailsStub
      });
      const amqpService = new AMQPService();
      const data = await amqpService.getAllAmqpDetails();
      expect(data.length).to.be.equal(2);
      expect(data[0].name).to.be.equal('test amqp 1');
      expect(data[1].name).to.be.equal('test amqp 2');
    });
  });
  describe('getAmqpDetailsByOrgId', () => {
    it('get list of AMQPs by orgId', async () => {
      const response = [
        { name: 'test amqp 1', orgId: 1 },
        { name: 'test amqp ', orgId: 4 },
        { name: 'cant find me', orgId: 5 }
      ];

      class AmqpDetailsStub {
        constructor() {
        }

        static findAll(queryParams) {
          return Promise.resolve(response);
        }
      };

      class OrgStub {
        constructor() {
        }

        static async getOrgChain() {
          return [1, 2, 3];
        }
      }

      const AMQPService = proxyquire('./amqp.service', {
        './amqpDetails.model': AmqpDetailsStub,
        '../organization/organization.model': OrgStub
      });
      const amqpService = new AMQPService();
      const data = await amqpService.getAmqpDetailsByOrgId(0);
      expect(data.length).to.be.equal(3);
      expect(data[0].name).to.be.equal('test amqp 1');
      expect(data[1].name).to.be.equal('test amqp ');

    });
  });
  describe('getAmqpDetailsCount', () => {
    it('getAmqpDetailsCount', async () => {
      const amqpCount = 10;

      class AmqpDetailsStub {
        constructor() { }

        static count() {
          return Promise.resolve(amqpCount);
        }
      };

      class OrgStub {
        constructor() { }

        static async getOrgChain() {
          return [1, 2, 3];
        }
      }
      const AMQPService = proxyquire('./amqp.service', {
        './amqpDetails.model': AmqpDetailsStub,
        '../organization/organization.model': OrgStub
      });
      const amqpService = new AMQPService();
      const data = await amqpService.getAmqpDetailsCount();
      expect(data).to.be.equal(amqpCount);
    });
  });

  describe('getAmqpDetailsId', () => {
    it('getAmqpDetailsId', async () => {
      const response = { name: 'test amqp 1', orgId: 1 };

      class AmqpDetailsStub {
        constructor() { }

        static findOne() {
          return Promise.resolve(response);
        }
      };

      const AMQPService = proxyquire('./amqp.service', {
        './amqpDetails.model': AmqpDetailsStub
      });
      const amqpService = new AMQPService();
      const data = await amqpService.getAmqpDetailsId();
      expect(data).to.be.equal(response);
    });
  });

  describe('create', () => {
    it('create', async () => {
      const amqpBody = {
        body: {
          host_name: 'test amqp 01xd',
          port: 10,
          virtual_host: 'vhost',
          user_name: 'username',
          password: 'passw',
          exchange_name: 'exc',
          exchange_type: 'Topic',
          queue_name: 'quename',
          routing_key: 'key',
          durable: 'true',
          organization_id: 0,
          source_manager_id: 0,
          isActive: 'enabled',
          auto_delete: 'true',
          queue_durable: 'true',
          queue_auto_delete: 'true'
        }
      };
      const amqpParams = amqpBody.body;
      let findOneCounter = 0;
      class AmqpDetailsStub {
        constructor() { }

        static async findOne() {
          const data = [false, amqpParams];
          return data[findOneCounter++];
        }

        static async create() {
          return amqpParams;
        }
      };

      class OrgStub {
        constructor() { }

        static async getOrgChain() {
          return [1, 2, 3];
        }
      }

      const AMQPService = proxyquire('./amqp.service', {
        './amqpDetails.model': AmqpDetailsStub,
        '../organization/organization.model': OrgStub
      });

      const amqpService = new AMQPService();
      const data = await amqpService.create(amqpParams);
      expect(data).to.be.equal(amqpParams);
    });
  });

  describe('checkHostName', () => {
    it('checkHostName', async () => {
      const response = { name: 'test amqp 1', orgId: 1 };
      const host_name = '10.1.1.1';
      class AmqpDetailsStub {
        constructor() { }

        static findOne() {
          return Promise.resolve(response);
        }
      };

      const AMQPService = proxyquire('./amqp.service', {
        './amqpDetails.model': AmqpDetailsStub
      });
      const amqpService = new AMQPService();
      const data = await amqpService.checkHostName(host_name);
      expect(data).to.be.equal(response);
    });
  });

  describe('updateAmqpDetailsById', () => {
    it('updateAmqpDetailsById', async () => {
      const response = { name: 'test amqp 1', orgId: 1 };
      const amqpId = 1;
      const hostName = '10.1.1.1';
      const amqpBody = {
        body: {
          id:1,
          host_name: hostName,
          port: 10,
          virtual_host: 'vhost',
          user_name: 'username',
          password: 'passw',
          exchange_name: 'exc',
          exchange_type: 'Topic',
          queue_name: 'quename',
          routing_key: 'key',
          durable: 'true',
          organization_id: 0,
          source_manager_id: 0,
          isActive: 'enabled',
          auto_delete: 'true',
          queue_durable: 'true',
          queue_auto_delete: 'true'
        }
      };
      const amqpParams = amqpBody.body;
      const updateResposne = {
        amqpParams,
        update(){ return amqpParams; }
      };
      let findOneCounter = 0;
      class AmqpDetailsStub {
        constructor() { }

        static async findOne() {
          const data = [false, updateResposne, amqpParams];
          return data[findOneCounter++];
        }

        static async update() {
          return amqpParams;
        }
      };

      const AMQPService = proxyquire('./amqp.service', {
        './amqpDetails.model': AmqpDetailsStub
      });
      const amqpService = new AMQPService();
      console.log(amqpParams)
      const data = await amqpService.updateAmqpDetailsById(amqpId, amqpParams);
      console.log(data)
      expect(data).to.be.equal(amqpParams);
    });
  });

  describe('checkHostNameForUpdate', () => {
    it('checkHostNameForUpdate', async () => {
      const response = { name: 'test amqp 1', orgId: 1 };
      const host_name = '10.1.1.1';
      class AmqpDetailsStub {
        constructor() { }

        static findOne() {
          return Promise.resolve(response);
        }
      };

      const AMQPService = proxyquire('./amqp.service', {
        './amqpDetails.model': AmqpDetailsStub
      });
      const amqpService = new AMQPService();
      const data = await amqpService.checkHostNameForUpdate(host_name);
      expect(data).to.be.equal(response);
    });
  });

  describe('deleteById', () => {
    it('deleteById', async () => {
      const response = { name: 'test amqp 1', orgId: 1 };
      const amqpid = 10;
      class AmqpDetailsStub {
        constructor() { }

        static update(response) {
          return Promise.resolve(response);
        }

        static findOne(amqpid) {
          return Promise.resolve(response);
        }

      };

      const AMQPService = proxyquire('./amqp.service', {
        './amqpDetails.model': AmqpDetailsStub
      });
      const amqpService = new AMQPService();
      const data = await amqpService.deleteById(amqpid);
      expect(data).to.be.equal(response);
    });
  });

  describe('deleteMultipleAmqpDetails', () => {
    it('deleteMultipleAmqpDetails', async () => {
      const response = [{ name: 'test amqp 1', orgId: 1 }, { name: 'test amqp 2', orgId: 1 }, { name: 'test amqp 3', orgId: 1 }];
      const amqpid = [1, 2, 3];
      class AmqpDetailsStub {
        constructor() { }

        static update(response) {
          return Promise.resolve(response);
        }

        static findAll(amqpid) {
          return Promise.resolve(response);
        }

      };

      const AMQPService = proxyquire('./amqp.service', {
        './amqpDetails.model': AmqpDetailsStub
      });
      const amqpService = new AMQPService();
      const data = await amqpService.deleteMultipleAmqpDetails(amqpid);
      expect(data).to.be.equal(response);
    });
  });
});
