const SoftwareController = require('./softwareTag.controller');

/**
 * @swagger
 * tags:
 *  - name: Software
 *    description: Software endpoints
 */
module.exports = class SoftwareRoutes {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.softwareController = new SoftwareController();

      // initializing route
      if (type === 'Service Provider') {
        this.initServiceProvider();
      } else {
        this.initOrganization();
      }
    }
  }

  initOrganization() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/softwareTag:
     *   get:
     *     tags:
     *       - Software
     *     summary: Gets a list of all Software
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of software
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/`, this.softwareController.getSoftwareTagsForOrg);

    // todo look into what to do with these
    //router.get('/:orgId/softwareTag/:softwareTagId', SoftwareController.getSoftwareTagById);
    // router.post('/:orgId/softwareTag', SoftwareController.createSoftwareTag);
    // router.put('/:orgId/:softwareTagId', SoftwareController.updateSoftwareTag);
    // router.delete('/:orgId/:softwareTagId', SoftwareController.deleteSoftwareTag);
    // router.get('/:orgId/softwareTagName/:name', SoftwareController.getSoftwareTagByName);


  }

  initServiceProvider() {
    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/softwareTag:
     *   get:
     *     tags:
     *       - Software
     *     summary: Gets a list of all Software
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of software
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/`, this.softwareController.getSoftwareTagsForOrg);

    // todo look into what to do with these
    // router.get('/:serviceProviderId/organization/:orgId/softwareTag/:softwareTagId', SoftwareController.getSoftwareTagById);
    // router.post('/:serviceProviderId/organization/:orgId/softwareTag', SoftwareController.createSoftwareTag);
    // router.put('/:serviceProviderId/organization/:orgId/:softwareTagId', SoftwareController.updateSoftwareTag);
    // router.delete('/:serviceProviderId/organization/:orgId/:softwareTagId', SoftwareController.deleteSoftwareTag);
    // router.get('/:serviceProviderId/organization/:orgId/softwareTagName/:name', SoftwareController.getSoftwareTagByName);


  }
};
