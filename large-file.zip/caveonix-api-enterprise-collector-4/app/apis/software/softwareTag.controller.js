const checkId = require('../../../utils/checkId');
const checkName = require('../../../utils/checkName');
const errorHandler = require('../../../utils/errorHandler');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-softwareTag.controller'
});
const paginate = require('../../middlewares/paginate.middleware');
const SoftwareService = require('./softwareTag.service');
const Validator = require('../../../utils/validator');

const softwareTagService = new SoftwareService();
module.exports = class SoftwareController {
  async createSoftwareTag(req, res) {
    const orgId = req.params.orgId;
    const params = req.body;
    try {
      params.isActive = params.isActive ? params.isActive.toString().toLowerCase() : 'enabled';
      await Validator.validateParams({
        isActive: 'required|in:enabled,disabled,true'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    try {
      const softwareTag = await softwareTagService.create(orgId, params);
      return res.json(softwareTag);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getSoftwareTagById(req, res) {
    const softwareTagId = req.params.softwareTagId;
    if (checkId(softwareTagId)) {
      logger.error({ softwareTagId }, 'Error with SoftwareTag Id');
      const error = new Error('Error with SoftwareTag Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const softwareTagService = new SoftwareService();
      const softwareTag = await softwareTagService.getSoftwareTag(softwareTagId);
      if (!softwareTag) {
        return res.sendStatus(404);
      }
      return res.json(softwareTag);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getSoftwareTagByName(req, res) {
    const name = req.params.name;

    if (checkName(name)) {
      logger.error({ name }, 'Error with SoftwareTag Name');
      const error = new Error('Error with SoftwareTag Name');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const softwareTagService = new SoftwareService();
      const softwareTag = await softwareTagService.getSoftwareTagByName(name);
      return res.json(softwareTag);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getSoftwareTagsForOrg(req, res) {
    const limit = req.query.limit || res.locals.paginate.limit;
    const offset = req.query.offset || res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    const orgId = req.params.orgId;
    const search = req.query.search || null;
    const dropdown = req.query.dropdown || null;
    try {
      const softwareTagService = new SoftwareService();
      const results = await softwareTagService.getAllSoftwareTag(orgId, limit, offset, search, dropdown);
      const itemCount = await softwareTagService.getAllSoftwareTagCount(orgId, search);
      const count = itemCount[0].dataValues.count;
      const pageCount = Math.ceil(count / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: count,
        page_number: pageNumber,
        softwareTags: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async updateSoftwareTag(req, res) {
    const softwareTagId = req.params.softwareTagId;
    const update = req.body;
    const params = req.body;
    try {
      await Validator.validateParams({
        isActive: 'required|in:enabled,disabled'
      }, params);

      await Validator.validateParams({
        softwareTagId: 'required|integer'
      }, req.params, { softwareTagId: 'Error with softwareTag Id' });

    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    try {
      await softwareTagService.updateSoftwareTagById(softwareTagId, update);
      return res.sendStatus(204);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async deleteSoftwareTag(req, res) {
    const softwareTagId = req.params.softwareTagId;
    if (checkId(softwareTagId)) {
      logger.error({ softwareTagId }, 'Error with SoftwareTag Id');
      const error = new Error('Error with SoftwareTag Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      await softwareTagService.deleteSoftwareTagById(softwareTagId);
      return res.sendStatus(204);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }
};
