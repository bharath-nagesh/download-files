const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-softwareTag.service'
});
const Organization = require('../organization/organization.model');
const sequelize = require('../../../config/db.conf').getConnection();
const SoftwareTag = require('../../models/softwareTag.model');

module.exports = class SoftwareTagService {
  constructor() {
    logger.debug('called SoftwareTag constructor');
  }

  getSoftwareTag(softwareTagId, opts) {
    return SoftwareTag.findByPk(softwareTagId, { include: [{ all: true }] });
  }

  getSoftwareTagsForOrg(orgId) {
    return SoftwareTag.findAll({ where: { organization_id: orgId } });
  }

  create(orgId, params) {
    params.organization_id = orgId;
    return SoftwareTag.create(params);
  }

  updateSoftwareTagById(softwareTagId, update) {
    return SoftwareTag.update(update, {
      where: { id: softwareTagId }
    });
  }

  deleteById(softwareTagId) {
    return SoftwareTag.update(
      { isActive: false },
      {
        where: { id: softwareTagId }
      }
    );
  }

  getAllSoftwareTag(orgId, limit, offset, search = null, dropdown = false) {
    search = (search != null && search !== '') ? '%' + search + '%' : '%%';
    if (dropdown && dropdown === 'true') {
      return sequelize.query(
        `select distinct st.name from software_tags st inner join asset_software_tags_members astm on st.id = astm.software_tags_id 
        inner join assets a on a.id = astm.asset_id where a.organization_id in (select org_chain_list(?))
      limit ? offset ?`,
        { replacements: [orgId, limit, offset], model: Organization }
      );
    }
    return sequelize
      .query(
        `select *,vm.network_ip from((select st.id,st.part,st.vendor,st.name,st.description,st.version,st.update,st.edition,st.lang,st.sw_edition,st.target_sw,st.target_hw,st.other,st.full_cpe,st.hash_cpe,
      a.id as asset_id,astm.id as asset_software_member_id,a.name as asset_name,a.macaddress,a.organization_id,st.created_at,st.updated_at
      from assets as a,asset_software_tags_members as astm, software_tags as st
      where (a.name ILIKE :search OR st.name ILIKE :search ) AND  (a.managed != 'false' or a.managed is NULL) and a.is_active != 'false' and a.id=astm.asset_id and astm.software_tags_id=st.id and a.organization_id in (select org_chain_list(:orgId)) order by st.id asc) as assetDetails
      LEFT OUTER JOIN (select DISTINCT ON (asset_id) asset_id,network_ip from asset_vm_network_details where isipaddresscheck(network_ip::text) order by asset_id,created_at DESC) vm ON 
      assetDetails.asset_id = vm.asset_id )
      limit :limit offset :offset`,
        { replacements: { search, orgId, limit, offset }, model: Organization }
      );
  }

  getAllSoftwareTagCount(orgId, search = '') {
    search = (search != null && search !== '') ? '%' + search + '%' : '%%';
    return sequelize
      .query(
        `select count(a.*) from assets as a,asset_software_tags_members as astm, software_tags as st
      where ( a.name ILIKE ? OR st.name ILIKE ? ) AND  (a.managed != 'false' or a.managed is NULL) and a.is_active != 'false' and a.id=astm.asset_id and astm.software_tags_id=st.id and (a.organization_id=? or a.organization_id in ((WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id
      FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = ?
      UNION ALL  
      SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id
      WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n)))`,
        { replacements: [search, search, orgId, orgId], model: Organization }
      );
  }

  getSoftwareTagByName(name) {
    return SoftwareTag.findOne({ where: { name: sequelize.where(sequelize.fn('LOWER', sequelize.col('name')), sequelize.fn('lower', name)) } });
  }
};
