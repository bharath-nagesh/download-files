const express = require('express');
const SoftwareController = require('./softwareTag.controller');
const router = express.Router({mergeParams:true});

const softwareController = new SoftwareController();
router.post('/', softwareController.createSoftwareTag);

router.get('/:softwareTagId', softwareController.getSoftwareTagById);
router.put('/:softwareTagId', softwareController.updateSoftwareTag);
router.delete('/:softwareTagId', softwareController.deleteSoftwareTag);
router.get('/softwareTagName/:name', softwareController.getSoftwareTagByName);
// router.get('/:softwareTagId/softwareTagDetail', Controller.getSoftwareTagDetail);
// router.post('/:softwareTagId/softwareTagDetail', Controller.createSoftwareTagDetail);

module.exports = router;
