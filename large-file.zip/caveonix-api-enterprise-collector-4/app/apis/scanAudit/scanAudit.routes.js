const ScanAuditController = require('./scanAudit.controller');

/**
 * @swagger
 * tags:
 *  - name: AuditScan
 *    description: Audit Scan History endpoints
 */
module.exports = class ScanAuditRoutes {
  constructor(path, router) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.scanAuditController = new ScanAuditController();

      // initializing route
      this.initOrganization();
    }
  }

  initOrganization() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/auditScanHistory:
     *   get:
     *     summary: Returns a list of the audit scan history
     *     tags:
     *       - AuditScan
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: scanType
     *         description: The type of scan.
     *         in: query
     *         required: true
     *         type: string
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: startDate
     *         description: First scan date.
     *         in: query
     *         required: true
     *         type: string
     *       - name: endDate
     *         description: Last scan date.
     *         in: query
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: login
     */
    this.router.get(`${this.path}/`, this.scanAuditController.getScanHistory);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/auditScanHistory/{scheduleId}:
     *   get:
     *     summary: Gets a scan by it's schedule id
     *     tags:
     *       - AuditScan
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: scheduleId
     *         description: The schedule's id.
     *         in: path
     *         required: true
     *         type: number
     *
     *     responses:
     *       200:
     *         description: login
     */
    this.router.get(`${this.path}/:scheduleId`, this.scanAuditController.getScanHistoryWithScheduleId);
  }
};
