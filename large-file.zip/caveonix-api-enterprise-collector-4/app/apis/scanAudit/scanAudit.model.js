const Sequelize = require('sequelize');

class ScanAudit extends Sequelize.Model {
  static init(sequelize) {
    return super.init({
      scanType: { type: Sequelize.INTEGER, field: 'scan_type' },
      status: { type: Sequelize.STRING, field: 'status' },
      message: { type: Sequelize.STRING, field: 'message' }
    },
    {
      sequelize,
      timestamps: true,
      createdAt: 'created_at',
      updatedAt: false,
      freezeTableName: true,
      tableName: 'job_status',
      underscored: true
    });
  }

  static associate(models) {
    ScanAudit.belongsTo(models.Organization, { foreignKey: 'organization_id' });
    ScanAudit.belongsTo(models.User, { foreignKey: 'user_id' });
    ScanAudit.hasMany(ScanAudit, { as: 'scanAuditRef', foreignKey: 'parent_id', targetKey: 'id' });
    ScanAudit.belongsTo(models.ScheduleTask, { foreignKey: 'job_id' });
    ScanAudit.belongsTo(models.ReportType, { foreignKey: 'report_type_id' });
  };
}

module.exports = ScanAudit;
