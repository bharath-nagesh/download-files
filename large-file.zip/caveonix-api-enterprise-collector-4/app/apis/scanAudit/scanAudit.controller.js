const errorHandler = require('../../../utils/errorHandler');
const ScanAuditService = require('./scanAudit.service');
const scanAuditService = new ScanAuditService();
const logger = require('../../../utils/logger').logger;

module.exports = class ScanAuditController {
  async getScanHistory(req, res) {
    const scanType = req.query.scanType;
    const orgId = req.params.orgId;
    const startDate = req.query.startDate;
    const endDate = req.query.endDate;
    try {
      const response = await scanAuditService.getScanHistory(scanType, orgId, startDate, endDate);
      res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getScanHistoryWithScheduleId(req, res) {
    const orgId = req.params.orgId;
    const scheduleId = req.params.scheduleId;
    try {
      const response = await scanAuditService.getScanHistoryWithScheduleId(orgId, scheduleId);
      res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }
};
