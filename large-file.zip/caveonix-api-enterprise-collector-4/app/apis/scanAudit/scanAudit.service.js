const { get } = require('lodash');
const Job = require('../job/job.model');
const logger = require('../../../utils/logger').logger;
const Organization = require('../organization/organization.model');
const ScanAudit = require('./scanAudit.model');
const ScheduleTask = require('../../models/scheduleTask.model');
const sequelize = require('../../../config/db.conf').getConnection();
const User = require('../user/user.model');
const moment = require('moment');
const _ = require('lodash');


const loggerLabel = 'ScanAuditService';

module.exports = class ScanAuditService {
  constructor() {
    logger.debug('called ScanAuditService constructor');
  }

  async getScanHistory(scanType, organizationId, startDate, endDate) {
    logger.debug('getting scan history', { loggerLabel });
    logger.silly(`for org ${organizationId}`, { loggerLabel });

    const option = {};
    option.organizationId = organizationId;
    const orgChain = await Organization.getOrgChain(organizationId);
    startDate = startDate || moment().subtract(30, 'days').toDate();
    endDate = endDate || moment().toDate();
    const where = { created_at: { $between: [startDate, endDate] } };
    if (scanType) {
      const job = await Job.findOne({ where: { name: scanType } });
      where.jobId = job.id;
    } else {
      const data = await sequelize.query(`SELECT id
      FROM(
      SELECT id,job_id,
        row_number() OVER (PARTITION BY job_id ORDER BY created_at DESC) AS rownum
      FROM (
        SELECT distinct id,job_id,created_at FROM job_status
        where organization_id in (:org_id) and parent_id = 0
        order by created_at desc
      ) history
      ) top10 WHERE rownum <= 3 ;`,
      {
        type: sequelize.QueryTypes.SELECT, replacements: { org_id: orgChain }
      });
      if(data.length > 0){
        where.$or = [{ parent_id: data.map(d => { return d.id; }) },{ id: data.map(d => { return d.id; }) }];
      }
    }

    const finalData = await ScanAudit.findAll({
      where,
      include: [
        {
          model: Organization,
          required: true,
          where: { id: { $in: orgChain } },
          attributes: ['id', 'name', 'fullName', 'aliasName']
        },
        {
          model: ScheduleTask,
          include: [
            { model:Job }
          ],
          required: false
        },
        {
          model: User,
          attributes: ['id', 'username']
        }
        
      ]
    });
    return finalData.map(a => {
      a.dataValues.executionId = `${!get(a, 'parent_id') ? get(a, 'id') : get(a, 'parent_id')}-${get(a, 'ScheduleTask.name') ? get(a, 'ScheduleTask.name'): a.scanType}`;
      a.dataValues.scanType = (get(a, 'ScheduleTask') && get(a, 'job_id') !== -1) ? get(a, 'ScheduleTask.Job.dataValues.description') ? get(a, 'ScheduleTask.Job.dataValues.description') : get(a, 'ScheduleTask.Job.dataValues.name') : a.scanType;
      return a;
    });
  }

  async getScanHistoryWithScheduleId(orgId, scheduleId) {
    const organizationId = parseInt(orgId);
    const option = {};
    option.organization_id = organizationId;
    option.job_id = parseInt(scheduleId);
    const finalData = await ScanAudit.findAll({
      where: option,
      include: [
        {
          model: Organization,
          required: true,
          attributes: ['id', 'name', 'fullName', 'aliasName']
        },
        {
          model: ScheduleTask,
          include: [
            { model:Job }
          ],
          required: false
        },
        {
          model: User,
          attributes: ['id', 'username']
        }
      ]
    });
    return finalData.map(a => {
      a.dataValues.executionId = a.parent_id === 0 ? `${a.id}${'-' + _.get(a, 'ScheduleTask.name') || ''}` : a.dataValues.executionId = `${a.parent_id}${'-' + _.get(a, 'ScheduleTask.name') || ''}`;
      a.dataValues.scanType = (a.ScheduleTask && a.job_id !== -1) ? a.ScheduleTask.Job.dataValues.description ? a.ScheduleTask.Job.dataValues.description : a.ScheduleTask.Job.dataValues.name : a.scanType;
      return a;
    });
  }
};
