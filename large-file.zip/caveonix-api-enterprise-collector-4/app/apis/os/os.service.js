const Os = require('./os.model');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-os.service'
});

module.exports = class OperatingSystemService {
  constructor(services) {
    this.services = services;
    logger.debug('called constructor');
  }

  async getOs(osId, opts) {
    const os = await Os.findByPk(osId);
    return os;
  }

  async getAllOs() {
    return Os.findAll();
  }

  async create(params) {
    try {
      const os = await Os.create(params);
      return os;
    } catch (error) {
      logger.error({ stack: error.stack, error }, 'error');
      throw error;
    }
  }

  async deleteById(osId) {
    return Os.update({ isActive: false }, { where: { id: osId }, returning:true });
  }
};
