const OperatingSystemService = require('./os.service');
const osService = new OperatingSystemService();
const checkId = require('../../../utils/checkId');
const errorHandler = require('../../../utils/errorHandler');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-os.controller'
});

module.exports = class OperatingSystemController {
  async getAllOS(req, res) {
    try {
      const oses = await osService.getAllOs();
      return res.json(oses);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getOSById(req, res) {
    const osId = req.params.osId;
    if (checkId(osId)) {
      logger.error({ osId }, 'Error with OS Id');
      const error = new Error('Error with OS Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const os = await osService.getOs(osId);
      return res.json(os);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async createOS(req, res) {
    const params = req.body;
    if (Object.keys(params).length === 0) {
      logger.error('Invalid parameters for OS creation');
      const error = new Error('Invalid parameters for OS creation');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const os = await osService.create(params);
      return res.json(os);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async deleteOS(req, res) {
    const osId = req.params.osId;
    if (checkId(osId)) {
      logger.error({ osId }, 'Error with OS Id');
      const error = new Error('Error with OS Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const update = await osService.deleteById(osId);
      logger.info({ update, osId }, 'update');
      return res.sendStatus(204);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }
};
