const Sequelize = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();

/**
 * @swagger
 * components:
 *   schemas:
 *     OS:
 *       type: object
 *       required:
 *         - name
 *         - isActive
 *       properties:
 *         name:
 *           type: string
 *         isActive:
 *           type: string
 * @param sequelize
 */
const Os = sequelize.define(
  'Os',
  {
    name: {
      type: Sequelize.STRING
    },
    isActive: {
      type: Sequelize.BOOLEAN,
      field: 'is_active'
    },
    is_active: {
      type: Sequelize.BOOLEAN,
      field: 'is_active'
    }
  },
  {
    timestamps: false,
    freezeTableName: true,
    tableName: 'os',
    underscored: true,
    $autoQueryFallback:false
  }
);

module.exports = Os;
