const expect = require('chai').expect;
const proxyquire = require('proxyquire').noCallThru();
const httpMocks = require('node-mocks-http');

describe('OperatingSystemController', function () {
  beforeEach(() => {

  });

  describe('OperatingSystemController', () => {

    describe('getAllOS', () => {
      it('getAllOS', async () => {
        let resData = { data : 1 };
        const OperatingSystemServiceStub = class OperatingSystemServiceStub {
          getAllOs(){
            return Promise.resolve(resData);
          };
        };
        const OperatingSystemController = proxyquire('./os.controller', {
          './os.service': OperatingSystemServiceStub
        });

        const operatingSystemController = new OperatingSystemController();
        const req = httpMocks.createRequest();
        const res = httpMocks.createResponse();
        const details = await operatingSystemController.getAllOS(req, res);
        const osData = details._getData();
        expect(JSON.parse(osData)).to.deep.equal(resData);
      });
    });

    describe('getOSById', () => {
      it('getOSById', async () => {
        let resData = { data : 1 };
        let osId = 1;
        const OperatingSystemServiceStub = class OperatingSystemServiceStub {
          getOs(osId){
            return Promise.resolve(resData);
          };
        };
        const OperatingSystemController = proxyquire('./os.controller', {
          './os.service': OperatingSystemServiceStub
        });

        const operatingSystemController = new OperatingSystemController();
        const req = httpMocks.createRequest({ params: { osId:osId } });
        const res = httpMocks.createResponse();
        const details = await operatingSystemController.getOSById(req, res);
        const osData = details._getData();
        expect(JSON.parse(osData)).to.deep.equal(resData);
      });
    });

    describe('createOS', () => {
      it('createOS', async () => {
        let resData = [{ data : 1 }];
        let osId = 1;
        const OperatingSystemServiceStub = class OperatingSystemServiceStub {
          create(params){
            return Promise.resolve(resData);
          };
        };
        const OperatingSystemController = proxyquire('./os.controller', {
          './os.service': OperatingSystemServiceStub
        });

        const operatingSystemController = new OperatingSystemController();
        const req = httpMocks.createRequest({ body:resData });
        const res = httpMocks.createResponse();
        const details = await operatingSystemController.createOS(req, res);
        const osData = details._getData();
        expect(JSON.parse(osData)).to.deep.equal(resData);
      });
    });

    
    describe('deleteOS', () => {
      it('deleteOS', async () => {
        let resData = { data : 1 };
        let osId = 1;
        const OperatingSystemServiceStub = class OperatingSystemServiceStub {
          deleteById(osId){
            return Promise.resolve(resData);
          };
        };
        const OperatingSystemController = proxyquire('./os.controller', {
          './os.service': OperatingSystemServiceStub
        });

        const operatingSystemController = new OperatingSystemController();
        const req = httpMocks.createRequest({ params: { osId:osId } });
        const res = httpMocks.createResponse();
        const details = await operatingSystemController.deleteOS(req, res);
        expect(details.statusCode).to.deep.equal(204);
      });
    });


  });
});
