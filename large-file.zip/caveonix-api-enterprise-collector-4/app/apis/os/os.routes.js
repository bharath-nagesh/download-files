const OperatingSystemController = require('./os.controller');

/**
 * @swagger
 * tags:
 *  - name: Operating System
 *    description: Operating System endpoints
 */
module.exports = class OperatingSystemRoutes {
  constructor(path, router) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.osController = new OperatingSystemController();

      this.initOrganization();
    }
  }

  initOrganization() {

    /**
     // * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/os:
     *   get:
     *     tags:
     *       - Operating System
     *     summary: Gets a list of all Operating Systems
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of operating systems
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/`, this.osController.getAllOS);

    /**
     // * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/os/{osId}:
     *   get:
     *     tags:
     *       - Operating System
     *     summary: Gets an Operating System by its id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: osId
     *         description: The id of the specified Operating System,
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: operating system
     */
    this.router.get(`${this.path}/:osId`, this.osController.getOSById);
    /**
     // * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/os:
     *   post:
     *     tags:
     *       - Operating System
     *     summary: Creates an Operating System
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/OS'
     *     responses:
     *       200:
     *         description: AWS VPS AdminHost
     */
    this.router.post(`${this.path}/`, this.osController.createOS);
  }
};
