const expect = require('chai').expect;
const proxyquire = require('proxyquire').noCallThru();

describe('Os Service', function () {
  beforeEach(() => {

  });

  describe('getOs', () => {
    it('getOs', async () => {
      
      const osId = 1;
      const opts = {};
      const response = {
        data: 1
      };

      class OsStub {
        constructor() { }

        static findByPk() {
          return Promise.resolve(response);
        }
      };

      const OperatingSystemService = proxyquire('./os.service', {
        './os.model': OsStub
      });
      const operatingSystemService = new OperatingSystemService();
      const data = await operatingSystemService.getOs(osId, opts);
      expect(data).to.be.equal(response);
    });
  });

  describe('getAllOs', () => {
    it('getAllOs', async () => {
      
     const response = [{
        data: 1
      },{
        data: 2
      }];

      class OsStub {
        constructor() { }

        static findAll() {
          return Promise.resolve(response);
        }
      };

      const OperatingSystemService = proxyquire('./os.service', {
        './os.model': OsStub
      });
      const operatingSystemService = new OperatingSystemService();
      const data = await operatingSystemService.getAllOs();
      expect(data).to.be.equal(response);
    });
  });

  describe('create', () => {
    it('create', async () => {
      
     const response = [{
        data: 1
      },{
        data: 2
      }];

      class OsStub {
        constructor() { }

        static create(response) {
          return Promise.resolve(response);
        }
      };

      const OperatingSystemService = proxyquire('./os.service', {
        './os.model': OsStub
      });
      const operatingSystemService = new OperatingSystemService();
      const data = await operatingSystemService.create(response);
      expect(data).to.be.equal(response);
    });
  });

  
  describe('deleteById', () => {
    it('deleteById', async () => {
      
      const osId = 1;
      const params = {
        data: 1
      };
      const response = { isActive: false }; 
      class OsStub {
        constructor() { }

        static update(params) {
          return Promise.resolve(response);
        }
      };

      const OperatingSystemService = proxyquire('./os.service', {
        './os.model': OsStub
      });
      const operatingSystemService = new OperatingSystemService();
      const data = await operatingSystemService.deleteById(osId);
      expect(data).to.be.equal(response);
    });
  });

});
