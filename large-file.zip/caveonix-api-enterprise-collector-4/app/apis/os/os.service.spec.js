const logger = require('../../../utils/logger').logger;
const mock = require('mock-require');
mock('sequelize', 'sequelize-mock');
const chai = require('chai');
const chaiHttp = require('chai-http');
let dbConnection = require('../../../config/db.conf');

// const app = require('../../../server');
// Configure chai
chai.use(chaiHttp);
chai.should();


describe('Os', () => {
  let Os, osService;
  before(async () => {

    await dbConnection.dbInit();
    await dbConnection.registerModels();
    let OsService = require('./os.service');

    osService = new OsService();
    Os = require('./os.model');
  });
  describe('Create', () => {
    it('Create::Positive Creation Case', async () => {
      let expected = { id: 3, name: 'test OS', isActive: true };
      let os = await osService.create(expected);

      chai.expect(os.name).to.be.equal(expected.name);
      chai.expect(os.isActive).to.be.equal(expected.isActive);

    });

  });
  describe('GetOs', () => {
    it('GetOs::Positive Creation Case', async () => {

      let expected = Os.build({ id: 4, name: 'test OS1', isActive: true });
      Os.$queueResult(expected);
      let id = expected.id;
      let os = await osService.getOs(id);
      chai.expect(os.id).to.be.equal(id);
      chai.expect(os.name).to.be.equal(expected.name);

    });
  });
  describe('DeleteById', () => {
    it('DeleteById::Positive Creation Case', async () => {
      let expected = Os.build({ id: 5, name: 'test OS2', isActive: false });
      Os.$queueResult(expected);

      let res = await osService.deleteById(expected.id);
      Os.$queueResult(res[0]);
      let os = await Os.findOne({ where: { id: expected.id } });
      os.get('id').should.equal(expected.id);
      os.isActive.should.equal(false);

    });
  });
});


