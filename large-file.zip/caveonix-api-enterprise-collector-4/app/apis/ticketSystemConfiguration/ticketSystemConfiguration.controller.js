const CentralCollectorClient = require('../../../utils/centralCollector.client');
const checkId = require('../../../utils/checkId');
const errorHandler = require('../../../utils/errorHandler');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-ticketSystemConfiguration.controller'
});
const paginate = require('../../middlewares/paginate.middleware');
const TicketSystemConfigurationService = require('./ticketSystemConfiguration.service');
const ticketSystemConfigurationService = new TicketSystemConfigurationService();
const Validator = require('../../../utils/validator');

module.exports = class TicketSystemConfigurationController {
  async getAllTicketSystemConfiguration(req, res) {
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    const orgId = req.params.orgId;
    try {
      const results = await ticketSystemConfigurationService.getAllTicketSystemConfiguration(orgId, limit, offset);
      const itemCount = await ticketSystemConfigurationService.getAllTicketSystemConfigurationCount(orgId);
      const pageCount = Math.ceil(itemCount / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        ticketSystemConfiguration: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getTicketSystemConfigurationById(req, res) {
    const ticketSystemConfigurationId = req.params.ticketSystemConfigurationId;
    if (checkId(ticketSystemConfigurationId)) {
      logger.error({ ticketSystemConfigurationId }, 'Error with ticketSystemConfigurationId');
      const err = new Error('Bad ticketSystemConfigurationId');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    try{
      const ticketSystemConfiguration = await ticketSystemConfigurationService.getTicketSystemConfigurationById(ticketSystemConfigurationId);
      return res.json(ticketSystemConfiguration);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getTicketSystemTypeById(req, res) {
    const ticketSystemConfigurationId = req.params.ticketSystemConfigurationId;
    if (checkId(ticketSystemConfigurationId)) {
      logger.error({ ticketSystemConfigurationId }, 'Error with ticketSystemConfigurationId');
      const err = new Error('Bad ticketSystemConfigurationId');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    try{
      const ticketSystemConfiguration = await ticketSystemConfigurationService.getTicketSystemConfigurationTypeById(ticketSystemConfigurationId);
      return res.json(ticketSystemConfiguration);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async updateTicketSystemConfigurationById(req, res) {
    const update = req.body;
    const orgId = req.params.orgId;
    const ticketSystemConfigurationId = req.params.ticketSystemConfigurationId;
    const name = update.name;
    const loginUrl = update.login_url;
    const username = update.username;
    const ticketUrl = update.ticket_url;

    if (!name || !loginUrl || !username || !ticketUrl) {
      logger.info('Invalid Parameters for update ');
      const err = new Error('Invalid Parameters  for update ');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    if (checkId(ticketSystemConfigurationId)) {
      logger.error({ ticketSystemConfigurationId }, 'Error with ticketSystemConfigurationId');
      const err = new Error('Bad ticketSystemConfigurationId');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    try{
      const ticketSystemConfiguration = await ticketSystemConfigurationService.updateTicketSystemConfigurationById(update, ticketSystemConfigurationId, orgId);
      return res.json(ticketSystemConfiguration);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async deleteTicketSystemConfigurationById(req, res) {
    const ticketSystemConfigurationId = req.params.ticketSystemConfigurationId;
    if (checkId(ticketSystemConfigurationId)) {
      logger.error({ ticketSystemConfigurationId }, 'Error with ticketSystemConfigurationId');
      const err = new Error('Bad ticketSystemConfigurationId');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    try{
      const ticketSystemConfiguration = await ticketSystemConfigurationService.deleteTicketSystemConfigurationById(ticketSystemConfigurationId);
      logger.info({ ticketSystemConfiguration, ticketSystemConfigurationId }, 'deleted');
      return res.json(ticketSystemConfiguration);
    } catch (error) {
      return errorHandler(req, res, error);
    }

  }

  async deleteMultipleTicketSystemConfiguration(req, res) {
    const ticketSystemConfigurationId = req.query.id;
    if (ticketSystemConfigurationId === undefined || ticketSystemConfigurationId === '') {
      const err = new Error('Invalid Input');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    try{
      const ticketSystemConfigurationIdArr = ticketSystemConfigurationId.split(',');
      const ticketSystemConfiguration = await ticketSystemConfigurationService.deleteMultipleTicketSystemConfiguration(ticketSystemConfigurationIdArr);
      return res.json(ticketSystemConfiguration);
    } catch (error) {
      return errorHandler(req, res, error);
    }

  }

  async createTicketSystemConfiguration(req, res) {
    const update = req.body;
    try {
      update.isActive = update.isActive ? update.isActive.toString().toLowerCase() : 'enabled';
      await Validator.validateParams({
        name: 'required|string',
        login_url: 'required|string',
        username: 'required|string',
        ticket_url: 'required|string',
        password: 'required|string',
        isActive: 'required|in:enabled,disabled,true'
      }, update);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const orgId = req.params.orgId;
    try{
      const ticketSystemConfiguration = await ticketSystemConfigurationService.createTicketSystemConfiguration(update, orgId);
      return res.json(ticketSystemConfiguration);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async testTicketSystemConfiguration(req, res) {
    const update = req.body;
    const userToken = req.authInfo;
    const userId = req.user.id;
    const orgId = req.params.orgId;
    let ccUrl;
    try {
      ccUrl = await CentralCollectorClient.CentralCollectorConnectionCheck();
      if (!ccUrl) {
        const error = new Error('No Central Collector Available. Please Contact Administrator');
        error.status = 400;
        throw error;
      }
      const response = await ticketSystemConfigurationService.testTicketSystemConfiguration(ccUrl, update, userToken, userId, orgId);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async describeJIRATicket(req, res) {
    const params = req.body;
    const userToken = req.authInfo;
    const userId = req.user.id;
    const orgId = req.params.orgId;
    try {
      await Validator.validateParams({
        projectId: 'required|string',
        issueKey: 'required|string'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    let ccUrl;
    try {
      ccUrl = await CentralCollectorClient.CentralCollectorConnectionCheck();
      if (!ccUrl) {
        const error = new Error('No Central Collector Available. Please Contact Administrator');
        error.status = 400;
        throw error;
      }
      const response = await ticketSystemConfigurationService.describeJIRATicket(ccUrl, params, userToken, userId, orgId);
      return res.json({ response });
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }
};
