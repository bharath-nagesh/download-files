const Sequelize = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();

class TicketSystemConfiguration extends Sequelize.Model {
  static init(sequelize) {
    return super.init({
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      name: { type: Sequelize.STRING, field: 'name' },
      login_url: { type: Sequelize.STRING, field: 'login_url' },
      username: { type: Sequelize.STRING, field: 'username' },
      password: { type: Sequelize.STRING, field: 'password' },
      ticket_url: { type: Sequelize.STRING, field: 'ticket_url' },
      ticket_json: { type: Sequelize.STRING, field: 'ticket_json' },
      organization_id: { type: Sequelize.INTEGER, field: 'organization_id' },
      isActive: { type: Sequelize.STRING, field: 'is_active', defaultValue: 'enabled' },
      is_active: { type: Sequelize.STRING, field: 'is_active'},
      type: { type: Sequelize.STRING, field: 'type' }
    },
    { sequelize,
      timestamps: true,
      freezeTableName: true,
      tableName: 'ticket_system_configuration',
      underscored: true
    });
  }

  static associate(models) {
    TicketSystemConfiguration.belongsTo(models.Organization, { foreignKey: 'organization_id' });
  }
}

module.exports = TicketSystemConfiguration;
