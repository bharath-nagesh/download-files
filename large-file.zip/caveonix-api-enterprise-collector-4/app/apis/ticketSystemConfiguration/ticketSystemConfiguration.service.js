const KeyGenerator = require('../../../utils/generateKeys');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-ticketSystemConfiguration.service'
});
const Organization = require('../organization/organization.model');
const OrgService = require('../organization/org.service');
const orgService = new OrgService();
const rp = require('request-promise');
const sequelize = require('sequelize');
const _ = require('lodash');
const TicketSystemConfiguration = require('./ticketSystemConfiguration.model');
const isAppliance = require('../../../utils/isAppliance');
const SERVICE_TYPE = isAppliance() ? 'ec' : 'centralcollector';
module.exports = class TicketSystemConfigurationService {
  constructor() {
    this.keyGenerator = new KeyGenerator();
    this.rp = rp.defaults({ insecure: true, rejectUnauthorized: false });
    this.uriPrefix = `/${SERVICE_TYPE}/api/v1`;
    logger.debug('called constructor');
  }

  getTicketSystemConfigurationById(Id) {
    return TicketSystemConfiguration.findOne({
      where: { id: Id, $or: [{ is_active: { $ne: 'false' } }] },
      include: [{ model: Organization }]
    });
  }

  async getTicketSystemConfigurationTypeById(Id) {
    const ticket = await TicketSystemConfiguration.findOne({
      where: {
        id: Id,
        $or: [{ is_active: { $ne: 'false' } }]
      }
    });

    if (!ticket) {
      const e = new Error('Not Found');
      e.status = 404;
      throw e;
    }
    const { ticket_json: ticketJson } = ticket;
    const ticketDetails = ticketJson ? JSON.parse(ticketJson) : {};
    const keys = Object.keys(ticketDetails);
    return _.reduce(keys, (accumulator, key) => {
      accumulator[key] = ticketDetails[key];
      return accumulator;
    }, {});

  }

  async getAllTicketSystemConfiguration(orgId, limit, offset) {
    const type = 'sub-organization';
    const orgList = await orgService.getProvider_SubOrg_SubOrgChain(orgId, type);
    const orgArr = orgList.map((object) => {
      return object.id;
    });
    return TicketSystemConfiguration.findAll({
      where: { organization_id: { $in: orgArr }, $or: [{ is_active: { $ne: 'false' } }] },
      order: [['id', 'ASC']],
      limit: limit,
      offset: offset,
      include: [{ model: Organization }]
    });
  }

  async getAllTicketSystemConfigurationCount(orgId) {
    const type = 'sub-organization';
    const orgList = await orgService.getProvider_SubOrg_SubOrgChain(orgId, type);
    const orgArr = orgList.map((object) => {
      return object.id;
    });
    return TicketSystemConfiguration.count({
      where: { organization_id: { $in: orgArr }, $or: [{ is_active: { $ne: 'false' } }] }
    });
  }

  async createTicketSystemConfiguration(params, orgId) {
    const type = params.type;
    params.organization_id = orgId;
    params.ticket_json = (typeof (params.ticket_json) === 'object') ? JSON.stringify(params.ticket_json) : params.ticket_json;
    const exists = await this.checkType(type, orgId);
    if (exists) {
      const err = new Error('Duplicate Type.');
      err.status = 400;
      throw err;
    }
    const newPassword = await this.keyGenerator.generateKeys(params.password);
    params.password = newPassword;
    return TicketSystemConfiguration.create(params);
  }

  checkType(type, orgId) {
    return TicketSystemConfiguration.findOne({
      where: {
        type: sequelize.where(sequelize.fn('LOWER', sequelize.col('type')), sequelize.fn('lower', type)),
        organization_id: orgId,
        $or: [{ is_active: { $ne: 'false' } }]
      }
    });
  }

  async updateTicketSystemConfigurationById(update, ticketSystemConfigurationId, orgId) {
    const type = update.type;
    update.organization_id = orgId;
    update.ticket_json = (typeof (update.ticket_json) === 'object') ? JSON.stringify(update.ticket_json) : update.ticket_json;
    const exists = await this.checkTypeForUpdate(type, ticketSystemConfigurationId, orgId);
    if (exists) {
      const err = new Error('Duplicate Type.');
      err.status = 400;
      throw err;
    }
    if (update.password) {
      const newPassword = await this.keyGenerator.generateKeys(update.password);
      update.password = newPassword;
    }
    await TicketSystemConfiguration.update(update, { where: { id: ticketSystemConfigurationId } });
    return TicketSystemConfiguration.findByPk(ticketSystemConfigurationId);
  }

  checkTypeForUpdate(type, ticketSystemConfigurationId, orgId) {
    return TicketSystemConfiguration.findOne({
      where: {
        type: sequelize.where(sequelize.fn('LOWER', sequelize.col('type')), sequelize.fn('lower', type)),
        organization_id: orgId,
        $or: [{ is_active: { $ne: 'false' } }],
        id: { $ne: ticketSystemConfigurationId }
      }
    });
  }

  async deleteTicketSystemConfigurationById(Id) {
    await TicketSystemConfiguration.update({ is_active: false }, { where: { id: Id } });
    return TicketSystemConfiguration.findOne({ where: { id: Id } });
  }

  async deleteMultipleTicketSystemConfiguration(ticketSystemConfigurationIdArr) {
    await TicketSystemConfiguration.update({ is_active: false }, { where: { id: { $in: ticketSystemConfigurationIdArr } } });
    return TicketSystemConfiguration.findAll({ where: { id: { $in: ticketSystemConfigurationIdArr } } });
  }

  async testTicketSystemConfiguration(ipAddress, params, userToken, userId, orgId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const projectName = params.name;
    const ticketURL = params.ticket_url;
    const userName = params.username;
    const password = params.password;
    const formData = {
      userToken, userId, orgId, projectName, ticketURL, userName, password
    };
    const url = `${ipAddress}${this.uriPrefix}/testTicketConnection/`;
    const obj = {};

    try {
      const response = await this.rp.post(url, { form: formData, resolveWithFullResponse: true });
      if (response.statusCode === 200 || response.statusCode === 202) {
        logger.info('Status: ' + response.statusCode + ' Status Message: Success');
        obj.response = JSON.parse(response.body);
        obj.status = 'Success';
        return obj;
      } else {
        logger.info('Status: ' + response.statusCode + ' Status Message: Failed');
        obj.response = response.message;
        obj.status = 'Failed';
        return obj;
      }
    } catch (error) {
      logger.error({ error, stack: error.stack, formData, url }, 'System Configuration Request Error');
      const err = new Error('System Configuration Request Error');
      if (error.error) err.message = error.error;
      err.status = 400;
      throw err;
    }
  }

  async describeJIRATicket(ipAddress, params, userToken, userId, orgId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const url = `${ipAddress}${this.uriPrefix}/describeJIRATicket/?userToken=${userToken}&userId=${userId}&orgId=${orgId}&projectId=${params.projectId}&issueKey=${params.issueKey}`;
    try {
      const response = await this.rp.post(url, { resolveWithFullResponse: true });
      if (response.statusCode === 200 || response.statusCode === 202) {
        logger.info('Status: ' + response.statusCode + ' Status Message: Success');
        try{
          return JSON.parse(response.body);
        } catch(e){
          return response.body;
        }
      } else {
        logger.info('Status: ' + response.statusCode + ' Status Message: Failed');
        return response.message;
      }
    } catch (error) {
      logger.error({ error, stack: error.stack, url }, 'Ticket Description Error');
      return error.message;
    }
  }
};
