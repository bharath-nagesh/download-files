const TicketSystemConfigurationController = require('./ticketSystemConfiguration.controller');

/**
 * @swagger
 * tags:
 *  - name: TicketSystemConfiguration
 *    description: Ticket System Configuration endpoints
 */
module.exports = class TicketSystemConfigurationRoutes {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.ticketSystemConfigurationController = new TicketSystemConfigurationController();

      // initializing route
      this.initOrganization();
    }
  }

  initOrganization() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/ticketSystemConfiguration:
     *   get:
     *     description: Returns a list of ticket system information
     *     tags:
     *       - TicketSystemConfiguration
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: Organization id
     *         in: path
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: all ticket system configurations
     */
    this.router.get(`${this.path}/`, this.ticketSystemConfigurationController.getAllTicketSystemConfiguration);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/ticketSystemConfiguration/:ticketSystemConfigurationId:
     *   get:
     *     description: Returns the specified ticket system configuration
     *     tags:
     *       - TicketSystemConfiguration
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: ticketSystemConfigurationId
     *         description: The ticket system's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: The specified ticket system
     */
    this.router.get(`${this.path}/:ticketSystemConfigurationId`, this.ticketSystemConfigurationController.getTicketSystemConfigurationById);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/ticketSystemConfiguration/{ticketSystemConfigurationId}:
     *   put:
     *     summary: Updates a ticket system by it's id
     *     tags:
     *       - TicketSystemConfiguration
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: ticketSystemConfigurationId
     *         description: The ticket system's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: ticket system configuration
     */
    this.router.put(`${this.path}/:ticketSystemConfigurationId`, this.ticketSystemConfigurationController.updateTicketSystemConfigurationById);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/ticketSystemConfiguration:
     *   post:
     *     summary: Creates a ticket system configuration
     *     tags:
     *       - TicketSystemConfiguration
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: ticket system configuration
     */
    this.router.post(`${this.path}/`, this.ticketSystemConfigurationController.createTicketSystemConfiguration);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/ticketSystemConfiguration/{ticketSystemConfigurationId}:
     *   delete:
     *     description: Deletes a ticket system by its id
     *     tags:
     *       - TicketSystemConfiguration
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: id
     *         description: A comma delimited list of ids
     *         in: query
     *         required: true
     *         type: string
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: ticket system configuration
     */
    this.router.delete(`${this.path}/`, this.ticketSystemConfigurationController.deleteMultipleTicketSystemConfiguration);

    // todo correct this (TicketSystemType)
    /**
     * @swagger
     *
     * /api/organization/{orgId}/ticketSystemConfiguration/TicketSystemType/{ticketSystemConfigurationId}:
     *   get:
     *     summary: Gets a ticket system type by it's id
     *     tags:
     *       - TicketSystemConfiguration
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: ticketSystemConfigurationId
     *         description: The id of the ticket system.
     *         in: path
     *         required: true
     *         type: string
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: ticket system configuration
     */
    this.router.get(`${this.path}/ticketSystemType/:ticketSystemConfigurationId`, this.ticketSystemConfigurationController.getTicketSystemTypeById);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/ticketSystemConfiguration/testConnection:
     *   get:
     *     summary: Tests the connection for the specified ticket system
     *     tags:
     *       - TicketSystemConfiguration
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: name
     *         description: The name of the ticket system.
     *         in: formData
     *         required: true
     *         type: string
     *       - name: ticket_url
     *         description: The url for the ticket system.
     *         in: formData
     *         required: true
     *         type: number
     *       - name: password
     *         description: The password for the ticket system.
     *         in: formData
     *         required: true
     *         type: string
     *       - name: username
     *         description: The username for the ticket system.
     *         in: formData
     *         required: true
     *         type: string
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: login
     */
    this.router.post(`${this.path}/testConnection`, this.ticketSystemConfigurationController.testTicketSystemConfiguration);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/ticketSystemConfiguration/describeJIRATicket:
     *   post:
     *     description: Updates a JIRA Ticket
     *     tags:
     *       - TicketSystemConfiguration
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: password
     *         description: First scan date.
     *         in: formData
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: login
     */
    this.router.post(`${this.path}/describeJIRATicket`, this.ticketSystemConfigurationController.describeJIRATicket);
  }
};
