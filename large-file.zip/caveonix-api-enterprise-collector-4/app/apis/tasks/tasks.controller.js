const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-tasks.controller'
});
const errorHandler = require('../../../utils/errorHandler');
const TasksService = require('./tasks.service');
const tasksService = new TasksService();

module.exports = class tasksController {
  async createTask(req, res) {
    const { appCertId } = req.params;
    const params = req.body;
    const userId = req.user.id;
    try {
      const response = await tasksService.createTask(appCertId, userId, params);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getTaskById(req, res) {
    const { taskId } = req.params;
    try {
      const response = await tasksService.getTaskById(taskId);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async updateTask(req, res) {
    const { taskId } = req.params;
    const params = req.body;
    try {
      const response = await tasksService.updateTask(taskId, params);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getTasksByApplicationCertificationId(req, res) {
    const { appCertId } = req.params;
    try {
      const response = await tasksService.getTasks(appCertId);
      return res.json(response);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }
};
