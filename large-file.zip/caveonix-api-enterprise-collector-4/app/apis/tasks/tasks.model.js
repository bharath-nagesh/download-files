const Sequelize = require('sequelize');

/**
 * @swagger
 * components:
 *   schemas:
 *     Tasks:
 *       type: object
 *       required:
 *         - createdUserId
 *         - organizationId
 *         - cveIds
 *       properties:
 *         createdUserId:
 *           type: string
 *         organizationId:
 *           type: string
 *         cveIds:
 *           type: string
 *         cceIds:
 *           type: string
 *         assetIds:
 *           type: string
 *         assignedUserId:
 *           type: string
 *         ticketId:
 *           type: string
 *         summary:
 *           type: string
 *         notes:
 *           type: string
 *         isActive:
 *           type: string
 * @param sequelize
 //  */
//  ticket_id   weakness_name | weakness_desc | weakness_detector_source | weakness_source_identifier |
// asset_identifier | point_of_contant | resources_required | overall_remediation_plan | original_detection_dt | scheduled_completion_dt |
// scheduled_completion_change_dt | actual_completion_dt | last_updated_dt | vendor_dependency | last_vendor_check_in_dt |
// vendor_dependent_product_name | original_risk_rating | adjusted_risk_rating | risk_adjustment | false_prositive | operational_requirement |
// deviation_rational | comments | created_at | created_by | updated_at | updated_by | is_active
class Task extends Sequelize.Model {
  static init(sequelize) {
    return super.init(
      {
        name: { type: Sequelize.INTEGER, field: 'name' },
        type: { type: Sequelize.STRING, field: 'type' },
        controlNumber: { type: Sequelize.STRING, field: 'control_number' },
        controlFamily: { type: Sequelize.STRING, field: 'control_family' },
        controlName: { type: Sequelize.STRING, field: 'control_name' },
        controlDesc: { type: Sequelize.STRING, field: 'control_desc' },
        controlAssessmentNumber: { type: Sequelize.STRING, field: 'control_assetment_number' },
        workflow: { type: Sequelize.STRING, field: 'workflow' },
        weaknessName: { type: Sequelize.STRING, field: 'weakness_name' },
        weaknessDesc: { type: Sequelize.STRING, field: 'weakness_desc' },
        weaknessDetectorSource: { type: Sequelize.STRING, field: 'weakness_detector_source' },
        weaknessSourceIdentifier: { type: Sequelize.STRING, field: 'weakness_source_identifier' },
        assetIdentifier: { type: Sequelize.STRING, field: 'asset_identifier' },
        ticketId: { type: Sequelize.STRING, field: 'ticket_id' },
        isActive: { type: Sequelize.STRING, field: 'is_active', defaultValue: 'enabled' },

        severity: { type: Sequelize.STRING, field: 'severity' },
        falsePositive: { type: Sequelize.STRING, field: 'false_positive' },
        pointOfContact: { type: Sequelize.STRING, field: 'point_of_contact' },
        originalDetectionDate: {
          type: Sequelize.DATE,
          field: 'original_detection_dt',
          set(val) {
            if (!val) val = null;
            this.setDataValue('originalDetectionDate', val);
          }
        },
        scheduledCompletionDate: {
          type: Sequelize.DATE,
          field: 'scheduled_completion_dt',
          set(val) {
            if (!val) val = null;
            this.setDataValue('scheduledCompletionDate', val);
          }
        },
        scheduledCompletionChangeDate: {
          type: Sequelize.STRING,
          field: 'scheduled_completion_change_dt',
          set(val) {
            if (!val) val = null;
            this.setDataValue('scheduledCompletionChangeDate', val);
          }
        },
        actualCompletionDate: {
          type: Sequelize.DATE,
          field: 'actual_completion_dt',
          set(val) {
            if (!val) val = null;
            this.setDataValue('actualCompletionDate', val);
          }
        },
        vendorDependency: { type: Sequelize.STRING, field: 'vendor_dependency' },
        lastVendorCheckDate: { type: Sequelize.DATE,
          field: 'last_vendor_check_in_dt',
          set(val) {
            if (!val) val = null;
            this.setDataValue('lastVendorCheckDate', val);
          }},
        vendorDependentProductName: { type: Sequelize.STRING, field: 'vendor_dependent_product_name' },
        originalRiskRating: { type: Sequelize.STRING, field: 'original_risk_rating' },
        adjustedRiskRating: { type: Sequelize.STRING, field: 'adjusted_risk_rating' },
        riskAdjustment: { type: Sequelize.STRING, field: 'risk_adjustment' },
        operationalRequirement: { type: Sequelize.STRING, field: 'operational_requirement' },
        deviationRationale: { type: Sequelize.STRING, field: 'deviation_rational' },
        comments: { type: Sequelize.STRING, field: 'comments' },

      },
      {
        sequelize,
        timestamps: true,
        freezeTableName: true,
        tableName: 'tasks',
        underscored: true
      }
    );
  }

  static associate(models) {
    Task.belongsTo(models.Organization, { foreignKey: 'organization_id' });
    Task.belongsTo(models.ApplicationTag, { foreignKey: 'application_id' });
    Task.belongsTo(models.ApplicationCertification, { foreignKey: 'application_certification_id' });
    Task.belongsTo(models.User, {
      as: 'createdBy',
      foreignKey: { name: 'created_by', type: Sequelize.INTEGER }
    });
    Task.belongsTo(models.User, {
      as: 'updatedBy',
      foreignKey: { name: 'updated_by', type: Sequelize.INTEGER }
    });
  };
}

module.exports = Task;
