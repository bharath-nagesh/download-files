const Task = require('./tasks.model');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-certificate.service'
});

module.exports = class TaskService {
  constructor() {
    logger.debug('called constructor for certificate service');
  }

  async createTask(applicationCertificationId, userId, params) {
    params.created_by = userId;
    params.updated_by = userId;

    params.application_certification_id = applicationCertificationId;
    const task = await Task.create(params);
    return task;
  }

  async getTaskById(taskId) {
    return Task.findByPk(taskId);
  }

  async updateTask(taskId, params) {
    const task = await Task.findByPk(taskId);
    await task.update(params);
    await task.save();
    return task;
  }

  async getTasks(appCertId) {
    return Task.findAll({ where: { application_certification_id: appCertId } });
  }
};
