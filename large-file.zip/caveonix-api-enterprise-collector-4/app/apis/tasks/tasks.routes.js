const TasksController = require('./tasks.controller');
const tasksController = new TasksController();

function makeRouter(path,router) {
  router.get(`${path}/:taskId`, tasksController.getTaskById);
  router.put(`${path}/:taskId`, tasksController.updateTask);
  router.get(`${path}/`, tasksController.getTasksByApplicationCertificationId);

  router.post(`${path}/`, tasksController.createTask);

}
module.exports = makeRouter;
