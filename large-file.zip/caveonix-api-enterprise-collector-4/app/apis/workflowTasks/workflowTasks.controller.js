const checkId = require('../../../utils/checkId');
const CentralCollectorClient = require('../../../utils/centralCollector.client');
const Validator = require('../../../utils/validator');
const errorHandler = require('../../../utils/errorHandler');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-workflowTasks.controller'
});
const paginate = require('../../middlewares/paginate.middleware');
const WorkflowTasksService = require('./workflowTasks.service');
const workflowTasksService = new WorkflowTasksService();

module.exports = class WorkflowTasksController {
  async updateWorkFlowTasksById(req, res) {
    const workFlowTaskId = req.params.workFlowTaskId;
    const update = req.body;
    try {
      update.isActive = update.isActive ? update.isActive.toString().toLowerCase() : null;
      await Validator.validateParams({
        createdUserId: 'required|integer',
        isActive: 'required|in:enabled,disabled'
      }, update);

      await Validator.validateParams({
        workFlowTaskId: 'required|integer'
      }, req.params, { workFlowTaskId: 'Error with workFlowTask Id' });

    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    try {
      const result = await workflowTasksService.updateWorkFlowTasksById(workFlowTaskId, update);
      return res.json(result);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getAllWorkFlowTasks(req, res) {
    const orgId = req.params.orgId;
    const userId = req.params.userId;
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    try {
      const results = await workflowTasksService.getAllWorkFlowTasksDetails(orgId, limit, offset, userId);
      const itemCount = await workflowTasksService.getAllWorkFlowTasksCount(orgId);
      const pageCount = Math.ceil(itemCount / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        workFlowTasks: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getWorkFlowTasksById(req, res) {
    const orgId = req.params.orgId;
    const workFlowTaskId = req.params.workFlowTaskId;
    if (checkId(workFlowTaskId)) {
      const err = new Error('Bad workFlowTask Id');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    try {
      const result = await workflowTasksService.getWorkFlowTasksById(workFlowTaskId, orgId);
      return res.json(result);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async deleteWorkflows(req, res) {
    const workFlowTaskId = req.query.id || '';
    if (workFlowTaskId === undefined || workFlowTaskId === '') {
      const err = new Error('Invalid WorkFlow TaskId');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    const workFlowTaskArr = workFlowTaskId.split(',');
    try {
      const result = await workflowTasksService.deleteMultipleWorkFlowTasks(workFlowTaskArr);
      return res.json(result);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async createWorkflow(req, res) {
    const params = req.body;
    try{

      await Validator.validateParams({
        ticketType: 'required|string',
        ticketTypeId: 'required|integer',
        summary: 'required|string',
        ticketSystem: 'required|integer',
        projectId: 'required|string',
        type: 'required|string',
        notes:'nullable',
        cveIds:'nullable',
        cceIds:'nullable',
        assetIds:'nullable'
      }, params);

      if(params.cveIds && Array.isArray(params.cveIds)) params.cveIds = params.cveIds.filter((a) => a );
      if(params.assetIds && Array.isArray(params.assetIds)) params.assetIds = params.assetIds.filter((a) => a );

    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }

    const userToken = req.authInfo;
    const userId = req.user.id;
    const orgId = req.params.orgId;

    try {
      const ccUrl = await CentralCollectorClient.CentralCollectorConnectionCheck();
      if (!ccUrl) {
        const error = new Error('No Central Collector Available. Please Contact your Caveonix Administrator');
        error.status = 400;
        throw error;
      }
      await workflowTasksService.createWorkflow(userId, userToken, orgId, ccUrl, params);
      return res.json({ Status: 'Successfully Created WorkFlow Task' });
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }
};
