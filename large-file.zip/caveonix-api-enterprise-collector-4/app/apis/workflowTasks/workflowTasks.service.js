const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-workflowTasks.service'
});
const WorkflowTasks = require('../../models/workflowTasks.model');
const OrgService = require('../organization/org.service');
const Organization = require('../organization/organization.model');
const TicketSystemConfiguration = require('../ticketSystemConfiguration/ticketSystemConfiguration.model');
const User = require('../user/user.model');
const Asset = require('../asset/asset.model');
const orgService = new OrgService();
const rp = require('request-promise');
const isAppliance = require('../../../utils/isAppliance');
const SERVICE_TYPE = isAppliance() ? 'ec' : 'centralcollector';
module.exports = class WorkflowTasksService {
  constructor() {
    logger.debug('called WorkflowTasksService constructor');
  }

  async updateWorkFlowTasksById(workFlowTaskId, update) {
    const workFlowTaskDetails = await WorkflowTasks.findOne({ where: { id: workFlowTaskId } });
    const result = await workFlowTaskDetails.update(update);
    return WorkflowTasks.findOne({ where: { id: result.id }, include: [{ model: Organization }] });
  }

  async getWorkFlowTasksById(workFlowTaskId, organizationId) {
    const workflow = await WorkflowTasks.findOne({
      where: {
        id: workFlowTaskId,
        organization_id: organizationId,
        $or: [{ is_active: { $ne: 'false' } }]
      },
      include: [{ model: Organization },{ model: TicketSystemConfiguration },{ model: User }]
    });
    let assetIds = workflow.assetIds;
    workflow.setDataValue('is_active ', 'Open');
    assetIds = assetIds ? assetIds.split(',') : [];
    const assets = await Asset.findAll({ where: { id: { $in: assetIds } } });
    workflow.setDataValue('assetDetails', assets.map(a => {
      return { name: a.name, vmId: a.vmId, id: a.id };
    }));
    return workflow;
  }

  async getAllWorkFlowTasksDetails(orgId, limit, offset, userId = null) {

    const orgChain = await orgService.getOrgChain(orgId);

    let workflows = await WorkflowTasks.findAll({
      where: {
        organization_id: { $in: orgChain },
        $and: [{ is_active: { $ne: 'false' } }]
      },
      order: [['id', 'ASC']],
      limit: limit,
      offset: offset,
      include: [{ model: Organization },{ model: TicketSystemConfiguration },{ model: User }]
    });

    try {
      if (userId) {
        workflows = workflows.filter((workflow) => {
          return parseInt(workflow.assignedUserId) === parseInt(userId);
        });
      }
      return Promise.all(workflows.map(async (workflow) => {
        let assetIds = workflow.assetIds;
        assetIds = assetIds ? assetIds.split(',') : [];
        assetIds = assetIds.filter(a => { return !isNaN(parseInt(a)); });
        const assets = await Asset.findAll({ where: { id: { $in: assetIds } } });
        workflow.setDataValue('is_active ', 'Open');
        workflow.setDataValue('assetDetails', assets.map(a => {
          return { name: a.name, vmId: a.vmId, id: a.id };
        }));
        return workflow;
      }));
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      error.status = 400;
      throw error;
    }
  }

  async getAllWorkFlowTasksCount(orgId) {
    const type = 'sub-organization';
    const orgList = await orgService.getProvider_SubOrg_SubOrgChain(orgId, type);
    const orgArr = orgList.map((object) => {
      return object.id;
    });
    return WorkflowTasks.count({ where: { organization_id: { $in: orgArr }, $and: [{ is_active: { $ne: 'false' } }] } });
  }

  async deleteWorkFlowTasksById(workFlowTaskId) {
    await WorkflowTasks.update(
      { isActive: false },
      {
        where: { id: workFlowTaskId }
      }
    );
    return WorkflowTasks.findOne({ where: { id: workFlowTaskId } });
  }

  async deleteMultipleWorkFlowTasks(workFlowTaskIdArr) {
    await WorkflowTasks.update(
      { isActive: false },
      {
        where: { id: { $in: workFlowTaskIdArr } }
      }
    );
    return WorkflowTasks.findAll({ where: { id: { $in: workFlowTaskIdArr } } });
  }

  async createWorkflow(userId, userToken, orgId, ipAddress, params) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

    let options = '';
    if (params.cveIds) options = options + '&cveIds=' + params.cveIds;
    if (params.cceIds) options = options + '&cceIds=' + params.cceIds;
    if (params.assetIds) options = options + '&assetIds=' + params.assetIds;
    if (params.assignedUsers) options = options + '&assignedUsers=' + params.assignedUsers;
    if (params.notes) options = options + '&notes=' + params.notes;
    if (params.summary) options = options + '&summary=' + params.summary;
    if (params.type) options = options + '&type=' + params.type;
    if (params.ticketSystem) options = options + '&ticketSystem=' + params.ticketSystem;

    const ccUrl = `${ipAddress}/${SERVICE_TYPE}/api/v1/createTask/?userToken=${userToken}&userId=${userId}&orgId=${orgId}&ticketType=${params.ticketType}&projectId=${params.projectId}${options}`;
    try {
      const body = await rp({
        url: ccUrl,
        method: 'POST'
      });
      return body;
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred in workflow creation');
      const err = new Error('Jira task creation request error');
      err.status = 400;
      throw err;
    }
  }
};
