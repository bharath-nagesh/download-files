const WorkflowTasksController = require('./workflowTasks.controller');

/**
 * @swagger
 * tags:
 *  - name: WorkflowTasks
 *    description: Workflow task endpoints
 */
module.exports = class WorkflowTasksRoutes {
  constructor(path, router) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.workflowTasksController = new WorkflowTasksController();

      // initializing route
      this.initOrganization();
    }
  }

  initOrganization() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/workflow:
     *   get:
     *     tags:
     *       - WorkflowTasks
     *     summary: Gets a list of Workflow Tasks
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of workflow Tasks
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/`, this.workflowTasksController.getAllWorkFlowTasks);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/workflow/{workFlowTaskId}:
     *   get:
     *     tags:
     *       - WorkflowTasks
     *     summary: Gets a Workflow Task by it's id
     *     produces-:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: workFlowTaskId
     *         description: The id of the specified Workflow task.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: workflowTasks
     */
    this.router.get(`${this.path}/:workFlowTaskId`, this.workflowTasksController.getWorkFlowTasksById);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/workflow/create:
     *   post:
     *     tags:
     *       - WorkflowTasks
     *     summary: Creates a Workflow task
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/WorkflowTasks'
     *     responses:
     *       200:
     *         description: workflowTasks
     * @todo make this more RESTful aka remove create
     */
    this.router.post(`${this.path}/create`, this.workflowTasksController.createWorkflow);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/workflow/{workFlowTaskId}:
     *   put:
     *     tags:
     *       - WorkflowTasks
     *     summary: Updates a Workflow task
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: workFlowTaskId
     *         description: The id of the specified Workflow task.
     *         in: path
     *         required: true
     *         type: string
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/WorkflowTasks'
     *     responses:
     *       200:
     *         description: workflowTasks
     */
    this.router.put(`${this.path}/:workFlowTaskId`, this.workflowTasksController.updateWorkFlowTasksById);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/workflow:
     *   delete:
     *     tags:
     *       - WorkflowTasks
     *     summary: Deletes a Workflow task
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: workflowTasks
     */
    this.router.delete(`${this.path}/`, this.workflowTasksController.deleteWorkflows);
  }
};
