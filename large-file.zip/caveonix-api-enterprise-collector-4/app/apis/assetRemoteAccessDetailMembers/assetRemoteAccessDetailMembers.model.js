const Sequelize = require('sequelize');
const connection = require('../../../config/db.conf').getConnection();

/**
 * @swagger
 * components:
 *   schemas:
 *     AssetRemoteAccessDetailMembers:
 *       type: object
 *       required:
 *         - remoteAccessDetailId
 *         - assetId
 *       properties:
 *         remoteAccessDetailId:
 *           type: integer
 *         assetId:
 *           type: integer
 * @param sequelize
 */
class AssetRemoteAccessDetailMembers extends Sequelize.Model {
  static init(sequelize) {
    return super.init({
        id: {
          type: Sequelize.INTEGER,
          primaryKey: true,
          autoIncrement: true
        },
        vmId: { type: Sequelize.STRING, field: 'vmid' },
        assetId: { type: Sequelize.INTEGER, field: 'asset_id' },
        remoteAccessDetailId: { type: Sequelize.INTEGER, field: 'remote_access_detail_id' }

      },
      {
        sequelize,
        timestamps: false,
        freezeTableName: true,
        tableName: 'asset_remote_access_detail_members',
        underscored: true
      }
    );
  }
}

module.exports = AssetRemoteAccessDetailMembers;
