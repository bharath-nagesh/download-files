const ApplicationTag = require('../application/applicationTag.model');
const Asset = require('../asset/asset.model');
const AssetDetail = require('../asset/assetDetail.model');
const AssetRemoteAccessDetailMembers = require('./assetRemoteAccessDetailMembers.model');
const RemoteAccessDetail = require('../remoteAccessDetail/remoteAccessDetail.model');
const AssetRepoEndpoint = require('../assetRepoEndpoint/assetRepoEndpoint.model');
const AssetRepoType = require('../assetRepoEndpoint/assetRepoType.model');
const AssetVMNetwork = require('../../models/assetVMNetwork.model');
const Location = require('../location/location.model');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-assetRemoteAccessDetailMembers.service'
});
const Organization = require('../organization/organization.model');
const PolicyGroup = require('../subApplication/subApplication.model');
const AWSKMSService = require('../aws/awsKMS.service');
const awsKMSService = new AWSKMSService();

module.exports = class AssetRemoteAccessDetailMembersService {
  constructor(services) {
    this.services = services;
    logger.debug('called constructor');
  }

  getAllAssetRemoteAccessDetailMembers(orgId, limit, offset) {
    return AssetRemoteAccessDetailMembers.findAll({
      order: [['id', 'ASC']],
      limit: limit,
      offset: offset
    });
  }

  getAssetRemoteAccessDetailMembersCount(orgId, type) {
    return AssetRemoteAccessDetailMembers.count();
  }

  async getAssetRemoteAccessDetailMembersWithAssetDetails(remoteAccessDetailId, limit, offset) {
    const assetArray = await AssetRemoteAccessDetailMembers.findAll({ where: { remote_access_detail_id: remoteAccessDetailId } });
    const assetArr = assetArray.map((object) => {
      return object.assetId;
    });
    return Asset.findAll({
      where: {
        id: assetArr,
        isActive: ['enabled', 'true', 'disabled']
      },
      order: [['id', 'ASC']],
      include: [{
        model: AssetDetail,
        attributes: ['id', 'operatingSystem', 'realm'],
        include: [
          { model: Organization, attributes: ['id', 'name', 'aliasName', 'fullName'] },
          { model: AssetRepoEndpoint, include: [{ model: AssetRepoType }] }]
      },
      { model: Organization, attributes: ['id', 'name', 'aliasName', 'fullName'] },
      { model: AssetVMNetwork }
      ],
      limit: limit,
      offset: offset
    });
  }

  async getAssetRemoteAccessDetailMembersWithAssetDetailsCount(remoteAccessDetailId, type) {
    const assetArray = await AssetRemoteAccessDetailMembers.findAll({ where: { remote_access_detail_id: remoteAccessDetailId } });
    const assetArr = assetArray.map((object) => {
      return object.assetId;
    });
    return Asset.count({
      where: {
        id: assetArr,
        isActive: ['enabled', 'true', 'disabled']
      }
    });
  }

  async createAssetRemoteAccessDetailMembers(orgId, params, loggedInUserId, userToken) {
    params.organization_id = orgId;
    const exists = await this.checkAssetId(params.assetId);
    if (exists) {
      const err = new Error('AssetId already exists.');
      err.status = 400;
      throw err;
    }
    const Asset = await Asset.findOne({ where: { id: params.assetId } });
    if (!Asset) {
      const err = new Error('No Asset Id found in Asset Remote Access Association.');
      err.status = 404;
      throw err;
    }
    const RemoteAccessDetail = await RemoteAccessDetail.findOne({ where: { id: params.remoteAccessDetailId } });
    if (!RemoteAccessDetail) {
      const err = new Error('No Asset Id found in Assets. ');
      err.status = 404;
      throw err;
    }
    const assetRemoteAccessDetailMembers = await AssetRemoteAccessDetailMembers.create(params);
    try {
      await awsKMSService.CentralCollectorServiceUpdate('assetRemoteAccessDetails', assetRemoteAccessDetailMembers.id, orgId, loggedInUserId, userToken);
    } catch (e) {
      logger.error(e);
    }
    return assetRemoteAccessDetailMembers;
  }

  checkAssetId(AssetId) {
    return AssetRemoteAccessDetailMembers.findOne({ where: { asset_id: AssetId } });
  }

  async updateAssetRemoteAccessDetailMembers(assetId, orgId, params, loggedInUserId, userToken) {
    params.assetId = assetId;
    const AssetRemoteAccessDetailMember = await AssetRemoteAccessDetailMembers.findOne({ where: { asset_id: assetId } });
    if (!AssetRemoteAccessDetailMember) {
      const err = new Error('No Asset Id found in Asset Remote Access Association.');
      err.status = 404;
      throw err;
    }
    const Asset = await Asset.findOne({ where: { id: params.assetId } });
    if (!Asset) {
      const err = new Error('No Asset Id found in Assets.');
      err.status = 404;
      throw err;
    }
    const RemoteAccessDetail = await RemoteAccessDetail.findOne({ where: { id: params.remoteAccessDetailId } });
    if (!RemoteAccessDetail) {
      const err = new Error('No Remote Access Details found.');
      err.status = 404;
      throw err;
    }
    const assetRemoteAccessDetailMembers = await AssetRemoteAccessDetailMembers.findOne({ where: { asset_id: assetId } });
    const assetRemoteAccessDetail = await assetRemoteAccessDetailMembers.update(params);
    try {
      await awsKMSService.CentralCollectorServiceUpdate('assetRemoteAccessDetails', params.id, orgId, loggedInUserId, userToken);
    } catch (e) {
      logger.error(e);
    }
    return assetRemoteAccessDetail;
  }

  async deleteByIdAssetRemoteAccessDetailMembers(assetId, orgId, loggedInUserId, userToken) {
    const AssetRemoteAccessDetailMember = await AssetRemoteAccessDetailMembers.findOne({ where: { asset_id: assetId } });
    if (!AssetRemoteAccessDetailMember) {
      const err = new Error('No Asset Id found in Asset Remote Access Association.');
      err.status = 404;
      throw err;
    }
    await AssetRemoteAccessDetailMembers.destroy({ where: { asset_id: assetId } });
    try {
      await awsKMSService.CentralCollectorServiceUpdate('assetRemoteAccessDetails', AssetRemoteAccessDetailMember.id, orgId, loggedInUserId, userToken);
    } catch (e) {
      logger.error(e);
    }
    return AssetRemoteAccessDetailMember;
  }
};
