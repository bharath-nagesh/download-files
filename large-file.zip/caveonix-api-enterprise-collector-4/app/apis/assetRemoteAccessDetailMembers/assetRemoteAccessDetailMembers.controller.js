const AssetRemoteAccessDetailMembersService = require('./assetRemoteAccessDetailMembers.service');
const checkId = require('../../../utils/checkId');
const errorHandler = require('../../../utils/errorHandler');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-assetRemoteAccessDetailMembers.controller'
});
const paginate = require('../../middlewares/paginate.middleware');

module.exports = class AssetRemoteAccessDetailMembersController {
  async getAllAssetRemoteAccessDetailMembers(req, res) {
    const orgId = req.params.orgId;
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;

    const assetRemoteAccessDetailMembersService = new AssetRemoteAccessDetailMembersService();
    try{
      const results = await assetRemoteAccessDetailMembersService.getAllAssetRemoteAccessDetailMembers(orgId, limit, offset);
      const itemCount = await assetRemoteAccessDetailMembersService.getAssetRemoteAccessDetailMembersCount(orgId);
      const pageCount = Math.ceil(itemCount / limit);
      res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        assetRemoteAccessDetailMembers: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getAssetRemoteAccessDetailMembersWithAssetDetails(req, res) {
    const remoteAccessDetailId = req.params.remoteAccessDetailId;
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;

    try{
      const assetRemoteAccessDetailMembersService = new AssetRemoteAccessDetailMembersService();
      const results = await assetRemoteAccessDetailMembersService.getAssetRemoteAccessDetailMembersWithAssetDetails(remoteAccessDetailId, limit, offset);
      const itemCount = await assetRemoteAccessDetailMembersService.getAssetRemoteAccessDetailMembersWithAssetDetailsCount(remoteAccessDetailId);
      const pageCount = Math.ceil(itemCount / limit);
      res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        assetRemoteAccessDetailMembers: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async createAssetRemoteAccessDetailMembers(req, res) {
    const params = req.body;
    const orgId = req.params.orgId;
    const userToken = req.authInfo;
    const loggedInUserId = req.user.id;
    try{
      const assetRemoteAccessDetailMembersService = new AssetRemoteAccessDetailMembersService();
      const assetRemoteAccessDetailMembers = await assetRemoteAccessDetailMembersService.createAssetRemoteAccessDetailMembers(orgId, params, loggedInUserId, userToken);
      return res.json(assetRemoteAccessDetailMembers);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async updateAssetRemoteAccessDetailMembers(req, res) {
    const assetId = req.params.assetId;
    const params = req.body;
    if (checkId(assetId)) {
      logger.error({ assetId }, 'Error with Asset Id');
      const error = new Error('Error with Asset Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    const userToken = req.authInfo;
    const orgId = req.params.orgId;
    const loggedInUserId = req.user.id;
    try{
      const assetRemoteAccessDetailMembersService = new AssetRemoteAccessDetailMembersService();
      const assetRemoteAccessDetailMembers = await assetRemoteAccessDetailMembersService.updateAssetRemoteAccessDetailMembers(assetId, orgId, params, loggedInUserId, userToken);
      return res.json(assetRemoteAccessDetailMembers);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async deleteAssetRemoteAccessDetailMembers(req, res) {
    const assetId = req.params.assetId;
    if (checkId(assetId)) {
      logger.error({ assetId }, 'Error with Asset Id');
      const error = new Error('Error with Asset Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    const userToken = req.authInfo;
    const orgId = req.params.orgId;
    const loggedInUserId = req.user.id;
    try{
      const assetRemoteAccessDetailMembersService = new AssetRemoteAccessDetailMembersService();
      const update = await assetRemoteAccessDetailMembersService.deleteByIdAssetRemoteAccessDetailMembers(assetId, orgId, loggedInUserId, userToken);
      logger.info({ update, assetId }, 'Update');
      return res.json(update);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }
};
