const AssetRemoteAccessDetailMembersController = require('./assetRemoteAccessDetailMembers.controller');

/**
 * @swagger
 * tags:
 *  - name: AssetRemoteAccessDetailMembers
 *    description: Asset Remote Access Detail Members endpoints
 */
module.exports = class AssetRemoteAccessDetailMembersRouter {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.assetRemoteAccessDetailMembersController = new AssetRemoteAccessDetailMembersController();

      // initializing route
      if (type === 'Service Provider') {
        this.initServiceProvider();
      } else {
        this.initOrganization();
      }
    }
  }

  /**
   * Route initialization and setup
   */
  initOrganization() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/assetRemoteAccessMembers:
     *   get:
     *     tags:
     *       - AssetRemoteAccessDetailMembers
     *     summary: Gets a list of all asset remote access detail members
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: get all assetRemoteAccessDetailMembers
     *       401:
     *         description: unauthorized
     */
    this.router.get(`${this.path}/`, this.assetRemoteAccessDetailMembersController.getAllAssetRemoteAccessDetailMembers);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/assetRemoteAccessMembers:
     *   post:
     *     tags:
     *       - AssetRemoteAccessDetailMembers
     *     summary: Creates an asset Remote Access Detail Member
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/AssetRemoteAccessDetailMembers'
     *     responses:
     *       200:
     *         description: asset Remote Access Detail Members was created successfully
     *       401:
     *         description: unauthorized
     */
    this.router.post(`${this.path}/`, this.assetRemoteAccessDetailMembersController.createAssetRemoteAccessDetailMembers);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/assetRemoteAccessMembers/{assetId}:
     *   put:
     *     tags:
     *       - AssetRemoteAccessDetailMembers
     *     summary: Updates the specified assetRemoteAccessDetailMembers
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: assetId
     *         description: The assets's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/AssetRemoteAccessDetailMembers'
     *     responses:
     *       200:
     *         description: login
     *       401:
     *         description: unauthorized
     */
    this.router.put(`${this.path}/:assetId`, this.assetRemoteAccessDetailMembersController.updateAssetRemoteAccessDetailMembers);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/assetRemoteAccessMembers/{assetId}:
     *   delete:
     *     tags:
     *       - AssetRemoteAccessDetailMembers
     *     summary: Deletes an assetRemoteAccessDetailMembers by its id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: assetId
     *         description: The id of the specified asset.
     *         in: path
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: deleted assetRemoteAccessDetailMembers
     *       401:
     *         description: unauthorized
     */
    this.router.delete(`${this.path}/:assetRemoteAccessDetailMembersId`, this.assetRemoteAccessDetailMembersController.deleteAssetRemoteAccessDetailMembers);


  }

  /**
   * Route initialization and setup
   */
  initServiceProvider() {
    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/assetRemoteAccessMembers:
     *   get:
     *     tags:
     *       - AssetRemoteAccessDetailMembers
     *     summary: Gets a list of all asset remote access detail members
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: serviceProviderId
     *         description: The Service Provider's Id
     *         in: path
     *         required: true
     *         type: string
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: get all assetRemoteAccessDetailMembers
     *       401:
     *         description: unauthorized
     */
    this.router.get(`${this.path}/`, this.assetRemoteAccessDetailMembersController.getAllAssetRemoteAccessDetailMembers);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/assetRemoteAccessMembers:
     *   post:
     *     tags:
     *       - AssetRemoteAccessDetailMembers
     *     summary: Creates an asset Remote Access Detail Member
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: serviceProviderId
     *         description: The Service Provider's Id
     *         in: path
     *         required: true
     *         type: string
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/AssetRemoteAccessDetailMembers'
     *     responses:
     *       200:
     *         description: asset Remote Access Detail Members was created successfully
     *       401:
     *         description: unauthorized
     */
    this.router.post(`${this.path}/`, this.assetRemoteAccessDetailMembersController.createAssetRemoteAccessDetailMembers);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/assetRemoteAccessMembers/{assetId}:
     *   put:
     *     tags:
     *       - AssetRemoteAccessDetailMembers
     *     summary: Updates the specified assetRemoteAccessDetailMembers
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: serviceProviderId
     *         description: The Service Provider's Id
     *         in: path
     *         required: true
     *         type: string
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: assetId
     *         description: The assets's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/AssetRemoteAccessDetailMembers'
     *     responses:
     *       200:
     *         description: login
     *       401:
     *         description: unauthorized
     */
    this.router.put(`${this.path}/:assetId`, this.assetRemoteAccessDetailMembersController.updateAssetRemoteAccessDetailMembers);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/assetRemoteAccessMembers/{assetId}:
     *   delete:
     *     tags:
     *       - AssetRemoteAccessDetailMembers
     *     summary: Deletes an assetRemoteAccessDetailMembers by its id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: serviceProviderId
     *         description: The Service Provider's Id
     *         in: path
     *         required: true
     *         type: string
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: assetId
     *         description: The id of the specified asset.
     *         in: path
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: deleted assetRemoteAccessDetailMembers
     *       401:
     *         description: unauthorized
     */
    this.router.delete(`${this.path}/:assetRemoteAccessDetailMembersId`, this.assetRemoteAccessDetailMembersController.deleteAssetRemoteAccessDetailMembers);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/assetRemoteAccessDetailMembers/MultiAssetRemoteAccessDetailMembers:
     *   delete:
     *     tags:
     *       - AssetRemoteAccessDetailMembers
     *     summary: Deletes multiple assetRemoteAccessDetailMembers with a list of ids
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: serviceProviderId
     *         description: The Service Provider's Id
     *         in: path
     *         required: true
     *         type: string
     *       - name: assetRemoteAccessDetailMembersId
     *         description: A comma delimited list of ids.
     *         in: query
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: login
     *       401:
     *         description: unauthorized
     */
    this.router.delete(`${this.path}/MultiAssetRemoteAccessDetailMembers`, this.assetRemoteAccessDetailMembersController.deleteMultipleAssetRemoteAccessDetailMembers);


  }
};
