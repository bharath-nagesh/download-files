const KibanaMachineLearningService = require('../services/kibanaMachineLearning.service');
const kibanaMachineLearningService = new KibanaMachineLearningService();
const KibanaDashBoardService = require('.//kibanaDashboard/kibanaDashBoard.service');
const kibanaDashBoardService = new KibanaDashBoardService();
const errorHandler = require('./../../utils/errorHandler');
const logger = require('./../../utils/logger').logger.child({
  sub_name: 'IdentityService-kibanaMachineLearning.controller'
});

const controller = {
  async createJob(req, res) {
    const orgId = req.params.orgId;
    const sid = req.query.cookie;
    try {
      const data = await kibanaDashBoardService.getDashBoard(orgId, sid);
      if (data.length === 3) {
        const machineLearningData = await kibanaMachineLearningService.createAnomalyExp(orgId, data);
        return res.send(machineLearningData);
      }
    } catch (error) {
      return res.send(error);
    }
  },
  async getAnomalyExplorer(req, res) {
    const orgId = req.params.orgId;
    const sid = req.query.cookie;
    try {
      const data = await kibanaDashBoardService.getDashBoard(orgId, sid);
      if (data.length === 3) {
        const machineLearningData = await kibanaMachineLearningService.getLinuxLogJob(orgId, sid, data);
        return res.send(machineLearningData);
      }
    } catch (error) {
      return res.send(error);
    }
  }
};

module.exports = controller;
