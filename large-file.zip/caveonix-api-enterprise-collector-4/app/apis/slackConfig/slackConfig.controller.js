const checkId = require('../../../utils/checkId');
const errorHandler = require('../../../utils/errorHandler');
const Validator = require('../../../utils/validator');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-slackConfig.controller'
});
const paginate = require('../../middlewares/paginate.middleware');
const requestPromise = require('request-promise');
const SlackConfigService = require('./slackConfig.service');
const slackConfigService = new SlackConfigService();

module.exports = class SlackConfigController {
  async getAllOrgSlackConfig(req, res) {
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    const orgId = req.params.orgId;
    const slackConfigService = new SlackConfigService();
    try {
      const slackConfig = await slackConfigService.getAllSlackConfig(orgId, limit, offset);
      const itemCount = await slackConfigService.getAllSlackConfigCount(orgId);
      const pageCount = Math.ceil(itemCount / limit);
      res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        slackConfig,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getSlackConfigById(req, res) {
    const slackConfigId = req.params.slackConfigId;
    if (checkId(slackConfigId)) {
      logger.error({ slackConfigId }, 'Invalid slackConfigId');
      const error = new Error('Invalid slackConfigId');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const slackConfigService = new SlackConfigService();
      const slackConfig = await slackConfigService.getById(slackConfigId);
      return res.json(slackConfig);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async addSlackConfig(req, res) {
    const params = req.body;
    try {
      params.isActive = params.isActive ? params.isActive.toString().toLowerCase() : 'enabled';
      await Validator.validateParams({
        name: 'required|string',
        slack_url: 'required|url',
        channel_name: 'string',
        organization_id: 'required|integer',
        isActive: 'required|in:enabled,disabled,true'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const orgId = req.params.orgId;
    try {
      const slackConfig = await slackConfigService.create(orgId, params);
      return res.json(slackConfig);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async updateSlackConfig(req, res) {
    const params = req.body;
    try {
      params.isActive = params.isActive ? params.isActive.toString().toLowerCase() : null;
      await Validator.validateParams({
        name: 'required|string',
        slack_url: 'required|url',
        channel_name: 'string',
        organization_id: 'required|integer',
        isActive: 'required|in:enabled,disabled'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const orgId = req.params.orgId;
    const slackConfigId = req.params.slackConfigId;
    try {
      const slackConfigService = new SlackConfigService();
      const slackConfig = await slackConfigService.updateSlackConfig(orgId, slackConfigId, params);
      return res.json(slackConfig);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async testSlackConfig(req, res) {
    const param = req.body;
    const webhookUri = param.slack_url;
    if (!webhookUri.includes('hooks.slack.com/services')) {
      const e = new Error('Not a slack webhook URL');
      e.status = 400;
      return errorHandler(req, res, e);
    }
    const myJSONObject = { text: 'Slack Connection Test Successful.' };
    try {
      const response = await requestPromise({
        url: webhookUri,
        method: 'POST',
        json: true,
        body: myJSONObject,
        resolveWithFullResponse: true
      });
      if (response && (response.statusCode === 200 || response.statusCode === 202)) {
        return res.json({ connection: 'Connection Successful.' });
      } else {
        return res.json({ connection: 'Connection Failed.' });
      }
    } catch (error) {
      error.status = 422;
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async deleteSlackConfigId(req, res) {
    const slackConfigId = req.params.slackConfigId;

    if (checkId(slackConfigId)) {
      logger.error({ slackConfigId }, 'Error with slackConfigId');
      const error = new Error('Error with slackConfigId');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const slackConfigService = new SlackConfigService();
      const update = await slackConfigService.deleteSlackConfigId(slackConfigId);
      logger.info({ update, slackConfigId }, 'update');
      return res.json(update);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async deleteMultipleSlackConfigId(req, res) {
    const slackConfigId = req.query.id;
    if (slackConfigId === undefined || slackConfigId === '') {
      logger.error('Invalid Input');
      const error = new Error('Invalid Input');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const slackConfigIdArr = slackConfigId.split(',');
      const slackConfigService = new SlackConfigService();
      const update = await slackConfigService.deleteMultipleSlackConfigId(slackConfigIdArr);
      logger.info('Deleted');
      return res.json(update);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }
};
