const Sequelize = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();
/**
 * @swagger
 * components:
 *   schemas:
 *     Slack:
 *       type: object
 *       required:
 *         - name
 *         - slack_url
 *         - channel_name
 *         - organization_id
 *         - isActive
 *       properties:
 *         name:
 *           type: string
 *         slack_url:
 *           type: string
 *         channel_name:
 *           type: string
 *         organization_id:
 *           type: string
 *         isActive:
 *           type: string
 * @param sequelize
 */
const SlackConfig = sequelize.define(
  'slackConfig',
  {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },

    name: { type: Sequelize.STRING, allowNull: false },
    slack_url: { type: Sequelize.STRING, allowNull: false },
    channel_name: { type: Sequelize.STRING, allowNull: false },
    organization_id: { type: Sequelize.INTEGER, field: 'organization_id', allowNull: false },
    isActive: { type: Sequelize.STRING, field: 'is_active' },
    is_active: { type: Sequelize.STRING, field: 'is_active' }

  },
  { timestamps: true, freezeTableName: true, tableName: 'slack_configuration', underscored: true }
);

SlackConfig.associate = (models) => {
  SlackConfig.belongsTo(models.Organization, { foreignKey: 'organization_id' });
};

module.exports = SlackConfig;
