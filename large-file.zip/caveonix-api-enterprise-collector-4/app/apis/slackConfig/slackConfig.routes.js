const SlackConfigController = require('./slackConfig.controller');

/**
 * @swagger
 * tags:
 *  - name: Slack
 *    description: Slack endpoints
 */
module.exports = class SlackConfigRoutes {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.slackConfigController = new SlackConfigController();

      // initializing route
      this.initOrganization();
    }
  }

  initOrganization() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/slackConfig:
     *   get:
     *     tags:
     *       - Slack
     *     summary: Gets a list of slack configurations
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of slack configurations
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/`, this.slackConfigController.getAllOrgSlackConfig);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/slackConfig/{slackConfigId}:
     *   get:
     *     tags:
     *       - Slack
     *     summary: Gets a slack configuration by it's id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: slackConfigId
     *         description: The id of the specified slack configuration
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: slack configuration
     */
    this.router.get(`${this.path}/:slackConfigId`, this.slackConfigController.getSlackConfigById);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/slackConfig/{slackConfigId}:
     *   put:
     *     tags:
     *       - Slack
     *     summary: Updates a slack config
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: slackConfigId
     *         description: The id of the specified slack configuration.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/Slack'
     *     responses:
     *       200:
     *         description: Slack Config
     */
    this.router.put(`${this.path}/:slackConfigId`, this.slackConfigController.updateSlackConfig);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/slackConfig:
     *   post:
     *     tags:
     *       - Slack
     *     summary: Creates a slack config
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/Slack'
     *     responses:
     *       200:
     *         description: Slack Config
     */
    this.router.post(`${this.path}/`, this.slackConfigController.addSlackConfig);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/slackConfig:
     *   delete:
     *     tags:
     *       - Slack
     *     summary: Deletes a slack configuration
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: id
     *         description: a comma delimited list of slack ids
     *         in: query
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: delete slack config
     */
    this.router.delete(`${this.path}/`, this.slackConfigController.deleteMultipleSlackConfigId);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/slackConfig/testConnection:
     *   post:
     *     tags:
     *       - Slack
     *     summary: Creates a slack config
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       required: true
     *       content:
     *         application/json:
     *           schema:
     *              type: object
     *              properties:
     *                slack_url:
     *                  type: string
     *     responses:
     *       200:
     *         description: Slack Config
     */
    this.router.post(`${this.path}/testConnection`, this.slackConfigController.testSlackConfig);
  }
};
