const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-slackConfigService.service'
});
const Organization = require('../organization/organization.model');
const OrgService = require('../organization/org.service');
const orgService = new OrgService();
const sequelize = require('sequelize');
const SlackConfig = require('./slackConfig.model');

module.exports = class SlackConfigService {
  constructor() {
    logger.debug('called SlackConfig Service constructor');
  }

  getById(id, opts) {
    return SlackConfig.findByPk(id, { include: [{ model: Organization }] });
  }

  async updateSlackConfig(orgId, slackConfigId, update) {
    const name = update.name;
    const slackUrl = update.slack_url;
    const type = 'sub-organization';
    let exists;
    const orgList = await orgService.getProvider_SubOrg_SubOrgChain(orgId, type);
    const orgArr = orgList.map((object) => {
      return object.id;
    });
    exists = await this.checkSlackNameForUpdate(name, slackConfigId, orgArr);
    if (exists) {
      const err = new Error('Duplicate Slack name.');
      err.status = 400;
      throw err;
    }
    exists = await this.checkSlackUrlForUpdate(slackUrl, slackConfigId, orgArr);
    if (exists) {
      const err = new Error('Duplicate Slack URL.');
      err.status = 400;
      throw err;
    }
    await SlackConfig.update(update, { where: { id: slackConfigId } });
    return SlackConfig.findByPk(slackConfigId, { include: [{ model: Organization }] });
  }

  async create(orgId, params) {
    const name = params.name;
    const slackUrl = params.slack_url;

    const orgList = await Organization.getOrgChain(orgId);
    let exists = await this.checkSlackName(name, orgList);
    if (exists) {
      const err = new Error('Duplicate Slack name.');
      err.status = 400;
      throw err;
    }
    exists = await this.checkSlackUrl(slackUrl, orgList);
    if (exists) {
      const err = new Error('Duplicate Slack URL.');
      err.status = 400;
      throw err;
    }
    const result = await SlackConfig.create(params);
    return SlackConfig.findOne({ where: { id: result.id }, include: [{ model: Organization }] });
  }

  checkSlackName(name, orgArr) {
    return SlackConfig.findOne({
      where: {
        $and: [
          {
            name: sequelize.where(sequelize.fn('LOWER', sequelize.col('name')),
              sequelize.fn('lower', name)),
            is_active: { $ne: 'false' }
          }],
        organization_id: orgArr
      }
    });
  }

  checkSlackNameForUpdate(name, slackId, orgArr) {
    return SlackConfig.findOne({
      where: {
        $and: [
          {
            name: sequelize.where(sequelize.fn('LOWER', sequelize.col('name')), sequelize.fn('lower', name)),
            is_active: { $ne: 'false' }
          }],
        organization_id: orgArr,
        id: { $ne: slackId }
      }
    });
  }

  checkSlackUrl(slackUrl, orgArr) {
    return SlackConfig.findOne({
      where: {
        $and: [
          {
            slack_url: sequelize.where(
              sequelize.fn('LOWER', sequelize.col('slack_url')),
              sequelize.fn('lower', slackUrl)),
            is_active: { $ne: 'false' }
          }],
        organization_id: orgArr
      }
    });
  }

  checkSlackUrlForUpdate(slackUrl, slackId, orgArr) {
    return SlackConfig.findOne({
      where: {
        $and: [
          {
            slack_url: sequelize.where(
              sequelize.fn('LOWER', sequelize.col('slack_url')),
              sequelize.fn('lower', slackUrl)),
            is_active: { $ne: 'false' }
          }],
        organization_id: orgArr,
        id: { $ne: slackId }
      }
    });
  }

  async deleteSlackConfigId(slackConfigId) {
    await SlackConfig.update({ is_active: false }, { where: { id: slackConfigId } });
    return SlackConfig.findByPk(slackConfigId, { include: [{ model: Organization }] });
  }

  async deleteMultipleSlackConfigId(slackConfigIdArr) {
    await SlackConfig.update({ is_active: false }, { where: { id: { $in: slackConfigIdArr } } });
    return SlackConfig.findAll({ where: { id: { $in: slackConfigIdArr } }, include: [{ model: Organization }] });
  }

  async getAllSlackConfig(orgId, limit, offset) {
    const type = 'sub-organization';
    const orgList = await orgService.getProvider_SubOrg_SubOrgChain(orgId, type);
    const orgArr = orgList.map((object) => {
      return object.id;
    });
    return SlackConfig.findAll({
      where: {
        organization_id: { $in: orgArr },
        $or: [{ is_active: { $ne: 'false' } }]
      },
      include: [{ model: Organization }],
      order: [['id', 'ASC']],
      limit: limit,
      offset: offset
    });
  }

  async getAllSlackConfigCount(orgId) {
    const type = 'sub-organization';
    const orgList = await orgService.getProvider_SubOrg_SubOrgChain(orgId, type);
    const orgArr = orgList.map((object) => {
      return object.id;
    });
    return SlackConfig.count({ where: { organization_id: { $in: orgArr }, $or: [{ is_active: { $ne: 'false' } }] } });
  }
};
