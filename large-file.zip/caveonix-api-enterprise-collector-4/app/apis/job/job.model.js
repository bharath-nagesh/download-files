const Sequelize = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();

/**
 * @swagger
 * components:
 *   schemas:
 *     Job:
 *       type: object
 *       required:
 *         - name
 *         - isActive
 *       properties:
 *         name:
 *           type: string
 *         description:
 *           type: string
 *         org_type:
 *           type: string
 *         organization_id:
 *           type: string
 * @param sequelize
 */
class Job extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      name: { type: Sequelize.STRING, allowNull: false },
      description: { type: Sequelize.STRING, field: 'description', allowNull: false },
      org_type: { type: Sequelize.STRING, field: 'org_type', allowNull: true },
      organization_id: { type: Sequelize.VIRTUAL }
    },
    {
      sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'jobs',
      underscored: true
    });
  }

  // model associations
  static associate(models) {
    Job.hasMany(models.ScheduleTask);

  };
}

module.exports = Job;
