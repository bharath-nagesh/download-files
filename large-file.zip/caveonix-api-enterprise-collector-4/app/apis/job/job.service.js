const CaveoAgents = require('../../models/caveoAgents.model');
const EmailServerService = require('../emailServer/emailServer.service');
const fs = require('fs');
const util = require('util');
const fs_writeFile = util.promisify(fs.writeFile);
const { get, toLower, split, compact } = require('lodash');
const Job = require('./job.model');
const logger = require('../../../utils/logger').logger;
const moment = require('moment');
const Organization = require('../organization/organization.model');
const { Op, QueryTypes } = require('sequelize');
const removeSpace = require('../../../utils/checkSpaces');
const ReportService = require('../reports/report.service');
const requestPromise = require('request-promise');
const ScheduleTask = require('../../models/scheduleTask.model');
const sequelize = require('../../../config/db.conf').getConnection();
const ScanTypes = require('../../models/scanTypes.model');
const AssetRepoEndpoint = require('../../apis/assetRepoEndpoint/assetRepoEndpoint.model');
const ScanAudit = require('../../apis/scanAudit/scanAudit.model');
const RemoteAccessDetail = require('./../remoteAccessDetail/remoteAccessDetail.model');
const CentralCollectorClient = require('../../../utils/centralCollector.client');
const _ = require('lodash');
const config = require('../../../configure').get();
const isAppliance = require('../../../utils/isAppliance');

const ccTimeout = config.cc_timeout || 10000;
const SERVICE_TYPE = isAppliance() ? 'ec' : 'centralcollector';
const loggerLabel = 'JobService';

module.exports = class JobService {
  constructor() {
    logger.debug('called JobService constructor');
    this.rp = requestPromise.defaults({ insecure: true, rejectUnauthorized: false });
    this.uriPrefix = isAppliance() ? '/ec/api/v1' : '/centralcollector/api/v1';
  }

  async getJob(scheduleId, orgId, backupRestore = null) {
    logger.debug('getting job', { loggerLabel });
    logger.silly(`with id ${scheduleId} for org ${orgId}`, { loggerLabel });

    if (backupRestore) {
      const result = await ScheduleTask.findAll({ where: { id: scheduleId }, include: [{ all: true }] });
      const resultArr = [];
      result.map(function (object) {
        if (object.parameters) {
          object.setDataValue('liveDataPeriod', JSON.parse(object.parameters).liveDataPeriod);
          object.setDataValue('backupRetentionPeriod', JSON.parse(object.parameters).backupRetentionPeriod);
          resultArr.push(object);
        }
      });
      return resultArr;
    }
    const job = await ScheduleTask.findAll({
      where: { id: scheduleId },
      include: [
        { model: Organization, attributes: ['id', 'name', 'aliasName', 'fullName', 'type', 'orgType'] },
        { model: AssetRepoEndpoint, attributes: { exclude: ['username', 'password'] } },
        { model: Job },
        { model: RemoteAccessDetail, attributes: ['id', 'connectionName', 'type', 'ecHostName', 'organization_id'] }
      ]
    });
    const typeName = toLower(get(job, '[0].scan_type'));
    try {
      job[0].parameters = get(job, '[0].parameters') ? JSON.parse(get(job, '[0].parameters')) : {};
    } catch (error) {
      logger.error('JSON fallback to string', { error, loggerLabel });
    }
    switch (typeName) {
      case 'nsx-v flow collection':
        job[0].scan_type = 'NSX-V Flow Collection';
        break;
      case 'nsx-v ipfix topology collection':
        job[0].scan_type = 'NSX-V IPFIX Topology Collection';
        break;
      case 'vmc topology':
        job[0].scan_type = 'VMC Topology';
        break;
      case 'aws netflow extract':
        job[0].vpc_name = get(job, '[0].parameters');
        break;
    }
    return job;
  }

  getAllJobs(orgType, limit, offset) {
    logger.debug('getting all jobs', { loggerLabel });

    const opts = {
      where: {
        // organization_id: { $or: [{ $eq: null }, { $eq: orgId }] }
      },
      include: [{ all: true }]
    };
    if (orgType.toLowerCase() === 'sub-organization') {
      orgType = 'Organization';
      return Job.findAll({
        where: {
          org_type: sequelize.where(sequelize.fn('LOWER', sequelize.col('org_type')), sequelize.fn('lower', orgType)),
          $and: [{ name: { $ne: 'watcherRequest' } }, { name: { $ne: 'billingInformation' } }, { name: { $ne: 'Backup Index Datastore' } }],
          $or: [{ is_active: { $ne: 'false' } }]
        },
        opts,
        order: [['name', 'ASC']],
        limit,
        offset
      });
    }
    return Job.findAll({
      where: {
        $and: [{ name: { $ne: 'watcherRequest' } }, { name: { $ne: 'billingInformation' } }, { name: { $ne: 'Backup Index Datastore' } }],
        $or: [{ is_active: { $ne: 'false' } }]
      },
      opts,
      order: [['name', 'ASC']],
      limit,
      offset
    });
  }

  getBackupJobsJobs() {
    return Job.findAll({ where: { name: { $eq: 'Backup Index Datastore' } }, order: [['name', 'ASC']] });
  }

  async getAllJobSchedule(orgId, limit, offset, isProvider, backupRestore = null) {
    logger.debug('getting all job schedules', { loggerLabel });
    logger.silly(`for org ${orgId}`, { loggerLabel });

    if (backupRestore) {
      const results = await Job.findAll({ where: { $or: [{ name: 'Backup Index Datastore' }] } });
      const jobIdArr = results.map(o => o.id);
      const tasks = await ScheduleTask.findAll({
        where: { job_id: { $in: jobIdArr }, $or: [{ is_active: { $ne: 'false' } }] },
        order: [['id', 'ASC']],
        limit: limit,
        offset: offset,
        include: [{ all: true }]
      });
      return tasks.map((object) => {
        if (object.parameters) {
          object.setDataValue('liveDataPeriod', JSON.parse(object.parameters).liveDataPeriod);
          object.setDataValue('backupRetentionPeriod', JSON.parse(object.parameters).backupRetentionPeriod);
        }
        return object;
      });
    } else {
      const res = await Job.findAll({ where: { $or: [{ name: { $eq: 'watcherRequest' } }, { name: { $eq: 'billingInformation' } }, { name: { $eq: 'Backup Index Datastore' } }] } });
      const ScanTypesData = await ScanTypes.findAll();
      const idArr = res.map(o => o.id);
      idArr.push(0); // removing schedules of type report
      let ScheduleTaskData = await ScheduleTask.findAll({
        where: { job_id: { [Op.notIn]: idArr }, $or: [{ is_active: { $ne: 'false' } }] },
        order: [['id', 'ASC']],
        limit: limit,
        offset: offset,
        include: [
          { model: Organization, attributes: ['id', 'name', 'aliasName', 'fullName'] },
          { model: AssetRepoEndpoint },
          { model: Job }
        ]
      });
      ScheduleTaskData = ScheduleTaskData.map(e => {
        if (e.scan_type) {
          let scanType_type;
          if (e.Job.name === 'NSX-T Extract') {
            scanType_type = 'nsx-t';
          } else if (e.Job.name === 'NSX-V Extract') {
            scanType_type = 'nsx-v';
          } else if (e.Job.name === 'VMC Topology') scanType_type = 'vmc';
          e.dataValues.scan_type_description = [];
          e.scan_type.split(',').map(a => {
            let ScanTypesObj = null;
            if (scanType_type) {
              ScanTypesObj = ScanTypesData.find(o => (o.name === a && o.type === scanType_type));
            } else {
              ScanTypesObj = ScanTypesData.find(o => (o.name === a));
            }
            if (ScanTypesObj) {
              e.dataValues.scan_type_description.push(ScanTypesObj.comments || ScanTypesObj.name || a);
            } else {
              e.dataValues.scan_type_description.push(a);
            }
          });
        }
        if (e.dataValues.scan_type_description) e.dataValues.scan_type_description = e.dataValues.scan_type_description.join(',');
        return e;
      });
      return ScheduleTaskData;
    }
  }

  async getScanTypeByName(scanTypes = [], orgId) {
    logger.debug('Retrieving scan types by name', { loggerLabel });
    logger.silly(`for scanTypes ${scanTypes} for orgId ${orgId}`, { loggerLabel });

    scanTypes = Array.isArray(scanTypes) ? scanTypes : [scanTypes];
    const where = { type: scanTypes.map(s => s.toLowerCase()), isActive: 'enabled' };
    return ScanTypes.findAll({
      where,
      order: [['id', 'ASC']]
    });
  }

  async getAllScanTypes() {
    logger.debug('getting all scan types', { loggerLabel });

    return ScanTypes.findAll({
      where: { isActive: 'enabled' },
      order: [['id', 'ASC']],
      include: [{ all: true }]
    });
  }

  async getJobsCount(orgId, backupRestore = null) {
    const orgArr = await Organization.getOrgChain(orgId);

    if (backupRestore) {
      const res = await Job.findAll({ where: { $or: [{ name: 'Backup Index Datastore' }] } });
      const jobIdArr = res.map(function (object) {
        return object.id;
      });
      return ScheduleTask.count({
        where: {
          org_id: { $in: orgArr },
          job_id: { $in: jobIdArr },
          $or: [{ is_active: { $ne: 'false' } }]
        }
      });
    }
    const res = await Job.findAll({ where: { $or: [{ name: { $eq: 'watcherRequest' } }, { name: { $eq: 'billingInformation' } }, { name: { $eq: 'Backup Index Datastore' } }] } });
    const idArr = res.map(function (object) {
      return object.id;
    });
    idArr.push(0); // removing schedules of type report
    return ScheduleTask.count({
      where: {
        org_id: orgId,
        job_id: { [Op.notIn]: idArr },
        $or: [{ is_active: { $ne: 'false' } }]
      }
    });
  }

  async createJob(orgId, name, userId, params) {
    const newName = removeSpace.checkMultiSpace(name);
    const exists = await this.checkName(newName, orgId, params.type_name);
    if (exists) {
      const err = new Error('Name already exists.');
      err.status = 400;
      throw err;
    }
    params.name = newName;
    let typeName = params.type_name;
    typeName = typeName ? typeName.toLowerCase() : typeName;
    if (typeName === 'compliance audit report' || typeName === 'compliance report' || typeName === 'cyber risk report' || typeName === 'compliance delta report' || typeName === 'cyber risk delta report') {
      params.scan_type = '';
      params.asset_repo_id = -1;
      return this.scheduleReportJob(orgId, params);
    } else {
      return this.scheduleJob(orgId, params);
    }
  }

  async updateJob(orgId, scheduleId, update) {
    const name = update.name;
    const newName = removeSpace.checkMultiSpace(name);
    const exists = await this.checkNameForUpdate(newName, scheduleId, orgId, update.type_name);
    if (exists) {
      const err = new Error('Name already exists.');
      err.status = 400;
      throw err;
    }
    update.name = newName;
    const typeName = update.type_name;
    if (typeName.toLowerCase() === 'compliance audit report' || typeName.toLowerCase() === 'compliance report' || typeName.toLowerCase() === 'cyber risk report' || typeName.toLowerCase() === 'compliance delta report' || typeName.toLowerCase() === 'cyber risk delta report') {
      update.scan_type = '';
      update.asset_repo_id = -1;
      return this.updateReportJob(orgId, update, scheduleId);
    } else {
      return this.updateScheduleJob(orgId, update, scheduleId);
    }
  }

  async scheduleJob(orgId, params) {
    const typeName = params.type_name;
    const typeId = parseInt(params.typeId);
    const cronExpression = params.cron_expression;
    const assetRepoId = params.asset_repo_id;
    const scantype = params.scan_type;
    params.scan_type = scantype;
    const organization = await Organization.findOne({ where: { id: orgId } });
    if (!organization) {
      const err = new Error('Organization not found.');
      err.status = 404;
      throw err;
    }
    const orgName = organization.name;

    if (typeId === 1) {

      const dataCenter = params.dataCenter ? params.dataCenter : 'null';
      const folderName = params.folderName ? params.folderName : 'null';
      const resourcePool = params.resourcePool ? params.resourcePool : 'null';
      const clusterName = params.clusterName ? params.clusterName : 'null';

      const argumentsJson = {
        dataCenter,
        folderName,
        resourcePool,
        clusterName
      };

      params.parameters = JSON.stringify(argumentsJson);
    }

    if (params.parameters) {
      params.parameters = JSON.parse(params.parameters);

      if (params.alertActions) {
        params.parameters.alertActions = params.alertActions;
      }

      if (params.alertEmails) {
        params.parameters.alertEmails = params.alertEmails;
      }

      params.parameters = JSON.stringify(params.parameters);
    }

    params.org_name = orgName;
    const includedAssetRepoTypes = [25, 26, 29, 35, 36, 37, 43, 44, 45, 27, 49, 50, 28, 46, 47, 48, 51, 52, 53, 21, 3, 15, 22, 21, 2, 1, 32, 8, 45, 46];
    const xincludedAssetRepoTypes = [
      'aws asset extract',
      'aws sqs extract - ec2',
      'aws infrastructure compliance',
      'aws netflow extract',
      'aws cloudtrail extract',
      'aws security hub sqs extract',
      'aws cis compliance scan',
      'aws services extract',
      'azure asset extract',
      'azure services extract',
      'azure cis compliance scan',
      'azure netflow extract',
      'gcp asset extract',
      'gcp services extract',
      'gcp cis compliance scan',
      'gcp netflow extract',
      'hytrust infrastructure scan',
      'hytrust syslog extract',
      'hytrust user role extract',
      'kubernetes asset extract',
      'nsx-t extract',
      'nsx-v extract',
      'openstack asset extract',
      'vcd asset extract',
      'vcenter asset extract',
      'vmc asset extract',
      'vmware vulnerability scan',
      'vmware infrastructure scan',
      'amqp'
    ];

    // not vmware, asset scan, reports
    if (!includedAssetRepoTypes.includes(typeId)) {
      params.asset_repo_id = -1;
    }

    const job = await Job.findOne({ where: { name: typeName, $or: [{ is_active: { $ne: 'false' } }] } });
    if (!job) {
      const err = new Error('Job type ' + typeName + ' not found.');
      err.status = 404;
      throw err;
    }
    const jobId = job.id;
    params.job_id = jobId;
    params.org_id = orgId;
    const exists = await this.checkJobType(jobId, cronExpression, orgId, assetRepoId, typeName, scantype, params.parameters);
    if (exists) {
      const err = new Error(`${typeName} job already exists with the same schedule.`);
      err.status = 400;
      throw err;
    }
    if (typeName.toLowerCase() === 'asset scan' || typeName.toLowerCase() === 'log extract' || typeName.toLowerCase() === 'software extract' || typeName.toLowerCase() === 'nsx-v extract' || typeName.toLowerCase() === 'nsx-t extract') {
      if (typeName.toLowerCase() === 'nsx-v extract' || typeName.toLowerCase() === 'nsx-t extract') {
        // let assetRepoType = typeName.toLowerCase() === 'nsx-v extract'? 'NSX-V':'NSX-T';
        if (typeName.toLowerCase() === 'asset scan' && params.scan_type === 'all') {
          params.scan_type = 'vulnerability,patch,xccdf';
        }
        await sequelize.query(`select id from asset_repo_endpoints where id in (select distinct (asset_manager_id) from asset_details where organization_id=:orgId) and asset_repo_type_id = 1 and (is_active='enabled' or is_active = 'true')`, {
          replacements: { orgId },
          type: QueryTypes.SELECT
        });
        // if (nsxresult.length === 0 || !nsxresult) {
        //   nsxresult = await sequelize.query(`select * from
        //     (select ar.id as vcd_id, organization_id as source_org_id,location_id as source_loc_id,hosting_provider_id as source_hosting_id,
        //     connection_name, user_name, password, arem.asset_repo_enpoint_id_source_id as vcd_id, arem.asset_repo_enpoint_id_link_id lookup_id
        //     from asset_repo_endpoints ar, asset_repo_endpoint_members arem
        //     where asset_repo_type_id in (select id from asset_repo_types where name = 'vCenter') and ar.id in (select id from asset_repo_endpoints where id in (select distinct (asset_manager_id) from asset_details where organization_id= :orgId)
        //     and asset_repo_type_id = 2)
        //     and (ar.is_active='enabled' or ar.is_active = 'true') and ar.id = arem.asset_repo_enpoint_id_source_id) vcd,
        //     (select connection_name as link_connection_name, user_name as link_user_name, password as link_password,
        //     ar1.id as lookup_ref_id, ar1.asset_repo_type_id as vlookup_asset_repo_type_id from asset_repo_endpoints ar1 ) vlookup
        //     where lookup_ref_id = lookup_id and vlookup_asset_repo_type_id in (select id from asset_repo_types where name = :assetRepoType)`, {
        //     replacements: { orgId, assetRepoType },
        //     type: QueryTypes.SELECT
        //   })
        //    if (nsxresult.length === 0 || !nsxresult) {
        //      const err = new Error(`Please configure the ${assetRepoType} Asset Repository before configuring the task`);
        //      err.status = 404;
        //      throw err;
        //    }
        //    return ScheduleTask.create(params);
        // }
        return ScheduleTask.create(params);
      } else if (typeName.toLowerCase() === 'vcd asset extract') {
        const vcdresult = await sequelize.query(`select id from asset_repo_endpoints where asset_repo_type_id in (select id from asset_repo_types where name='VCD') 
      and organization_id=:orgId and (is_active='enabled' or is_active = 'true')`, {
          replacements: { orgId },
          type: QueryTypes.SELECT
        });
        if (vcdresult.length === 0 || !vcdresult) {
          const err = new Error('Please configure the VCD Asset Repository before configuring the task');
          err.status = 404;
          throw err;
        }
        return ScheduleTask.create(params);
      } else if (typeName.toLowerCase() === 'amqp') {
        const amqpresult = await sequelize.query(`select id from amqp_details where organization_id=:orgId and (is_active='enabled' or is_active = 'true')`, {
          replacements: { orgId },
          type: QueryTypes.SELECT
        });
        if (amqpresult.length === 0 || !amqpresult) {
          const err = new Error('Please configure the AMQP Asset Repository before configuring the task');
          err.status = 404;
          throw err;
        }
        return ScheduleTask.create(params);
      }
      return ScheduleTask.create(params);
    } else if (typeName.toLowerCase() === 'backup index datastore') {

      const liveDataPeriod = params.liveDataPeriod ? params.liveDataPeriod : 'null';
      const backupRetentionPeriod = params.backupRetentionPeriod ? params.backupRetentionPeriod : 'null';

      const argJson = {
        liveDataPeriod,
        backupRetentionPeriod
      };
      params.parameters = JSON.stringify(argJson);
    } else if (typeName.toLowerCase() === 'aws netflow extract') {
      params.parameters = params.vpc_name;
    }
    return ScheduleTask.create(params);
  }

  async updateScheduleJob(orgId, update, scheduleId) {
    const typeName = update.type_name;
    const cronExpression = update.cron_expression;
    const assetRepoId = update.asset_repo_id;
    const scanType = update.scan_type;
    const organization = await Organization.findOne({ where: { id: orgId } });
    update.id = scheduleId;
    if (!organization) {
      const err = new Error('Organization Not Found');
      err.status = 404;
      throw err;
    }
    const orgName = organization.name;

    if (typeName.toLowerCase() === 'vcenter asset extract') {

      const dataCenter = update.dataCenter ? update.dataCenter : 'null';
      const folderName = update.folderName ? update.folderName : 'null';
      const resourcePool = update.resourcePool ? update.resourcePool : 'null';
      const clusterName = update.clusterName ? update.clusterName : 'null';

      const argumentsJson = {
        dataCenter,
        folderName,
        resourcePool,
        clusterName
      };

      update.parameters = JSON.stringify(argumentsJson);
    }
    if (typeName.toLowerCase() === 'backup index datastore') {
      const liveDataPeriod = update.liveDataPeriod ? update.liveDataPeriod : 'null';
      const backupRetentionPeriod = update.backupRetentionPeriod ? update.backupRetentionPeriod : 'null';

      const argJson = {
        liveDataPeriod,
        backupRetentionPeriod
      };
      update.parameters = JSON.stringify(argJson);
    }
    update.org_name = orgName;

    // todo turn this into a reusable method
    const includedAssetRepoTypes = [
      'asset scan',
      'aws asset extract',
      'aws sqs extract - ec2',
      'aws infrastructure compliance',
      'aws netflow extract',
      'aws cloudtrail extract',
      'aws security hub sqs extract',
      'aws cis compliance scan',
      'aws services extract',
      'azure asset extract',
      'azure services extract',
      'azure cis compliance scan',
      'azure netflow extract',
      'gcp asset extract',
      'gcp services extract',
      'gcp cis compliance scan',
      'gcp netflow extract',
      'hytrust infrastructure scan',
      'hytrust syslog extract',
      'hytrust user role extract',
      'kubernetes asset extract',
      'log extract',
      'nsx-t extract',
      'nsx-v extract',
      'openstack asset extract',
      'software extract',
      'vcd asset extract',
      'vcenter asset extract',
      'vmc asset extract',
      'vmware vulnerability scan',
      'vmware infrastructure scan',
      'amqp'
    ];

    if (update.parameters) {
      update.parameters = JSON.parse(update.parameters);

      if (update.alertActions) {
        update.parameters.alertActions = update.alertActions;
      }

      if (update.alertEmails) {
        update.parameters.alertEmails = update.alertEmails;
      }

      update.parameters = JSON.stringify(update.parameters);
    }

    // not vmware, asset scan, reports
    if (!includedAssetRepoTypes.includes(typeName.toLowerCase())) {
      update.asset_repo_id = -1;
    }

    const job = await Job.findOne({ where: { name: typeName, $or: [{ is_active: { $ne: 'false' } }] } });
    if (!job) {
      const err = new Error(`Job type ${typeName} Not Found`);
      err.status = 404;
      throw err;
    }
    const jobId = job.id;
    update.job_id = jobId;
    const exists = await this.checkJobTypeForUpdate(jobId, cronExpression, scheduleId, orgId, assetRepoId, typeName, scanType, update.parameters);
    if (exists) {
      const err = new Error(`Schedule is already created for job type ${typeName}.`);
      err.status = 400;
      throw err;
    }

    if (typeName.toLowerCase() === 'asset scan' || typeName.toLowerCase() === 'log extract' || typeName.toLowerCase() === 'software extract' ||
      typeName.toLowerCase() === 'nsx-v extract' || typeName.toLowerCase() === 'nsx-t extract') {
      if (typeName.toLowerCase() === 'nsx-v extract' || typeName.toLowerCase() === 'nsx-t extract') {
        let assetRepoType;
        if (typeName.toLowerCase() === 'nsx-v extract') {
          assetRepoType = 'NSX-V';
        } else {
          assetRepoType = 'NSX-T';
        }
        let nsxresult = await sequelize.query(`select id from asset_repo_endpoints where id in (select distinct (asset_manager_id) from asset_details where organization_id=:orgId) and asset_repo_type_id = 1 and (is_active='enabled' or is_active = 'true')`, {
          replacements: { orgId },
          type: QueryTypes.SELECT
        });
        if (nsxresult.length === 0 || !nsxresult) {
          nsxresult = await sequelize.query(`select * from  
        (select ar.id as vcd_id, organization_id as source_org_id,location_id as source_loc_id,hosting_provider_id as source_hosting_id,
        connection_name, user_name, password, arem.asset_repo_enpoint_id_source_id as vcd_id, arem.asset_repo_enpoint_id_link_id lookup_id 
        from asset_repo_endpoints ar, asset_repo_endpoint_members arem 
        where asset_repo_type_id in (select id from asset_repo_types where name = 'vCenter') and ar.id in ( select distinct(ar.id) from asset_details a, asset_repo_endpoints ar where a.asset_manager_id=ar.id 
        and ar.asset_repo_type_id in (select id from asset_repo_types where name='vCenter') and a.organization_id=:orgId)
        and (ar.is_active='enabled' or ar.is_active = 'true') and ar.id = arem.asset_repo_enpoint_id_source_id) vcd, 
        (select connection_name as link_connection_name, user_name as link_user_name, password as link_password, 
        ar1.id as lookup_ref_id, ar1.asset_repo_type_id as vlookup_asset_repo_type_id from asset_repo_endpoints ar1 ) vlookup 
        where lookup_ref_id = lookup_id and vlookup_asset_repo_type_id in (select id from asset_repo_types where name =:assetRepoType)`, {
            replacements: { orgId, assetRepoType },
            type: QueryTypes.SELECT
          });
          /*if (nsxresult.length === 0 || !nsxresult) {
            const err = new Error(`Please configure the ${assetRepoType} Asset Repository before configuring the task`);
            err.status = 404;
            throw err;
          }*/
          await ScheduleTask.update(update, { where: { id: scheduleId } });
          return ScheduleTask.findOne({ where: { id: scheduleId } });
        }
        await ScheduleTask.update(update, { where: { id: scheduleId } });
        return ScheduleTask.findOne({ where: { id: scheduleId } });
      } else if (typeName.toLowerCase() === 'vcd asset extract') {
        const vcdresult = await sequelize.query(`select id from asset_repo_endpoints where asset_repo_type_id in (select id from asset_repo_types where name='VCD') 
          and organization_id=:orgId and (is_active='enabled' or is_active = 'true')`, {
          replacements: { orgId },
          type: QueryTypes.SELECT
        });
        if (vcdresult.length === 0 || !vcdresult) {
          const err = new Error('Please configure the VCD Asset Repository before configuring the task');
          err.status = 404;
          throw err;
        }
        await ScheduleTask.update(update, { where: { id: scheduleId } });
        return ScheduleTask.findOne({ where: { id: scheduleId } });

      } else if (typeName.toLowerCase() === 'amqp') {
        const amqpresult = await sequelize.query(`select id from amqp_details where organization_id=:orgId and (is_active='enabled' or is_active = 'true')`, {
          replacements: { orgId },
          type: QueryTypes.SELECT
        });
        if (amqpresult.length === 0 || !amqpresult) {
          const err = new Error('Please configure the AMQP Asset Repository before configuring the task');
          err.status = 404;
          throw err;
        }
        await ScheduleTask.update(update, { where: { id: scheduleId } });
        return ScheduleTask.findOne({ where: { id: scheduleId } });
      }
      await ScheduleTask.update(update, { where: { id: scheduleId } });
      return ScheduleTask.findOne({ where: { id: scheduleId } });
    } else if (typeName.toLowerCase() === 'aws netflow extract') {
      update.parameters = update.vpc_name;
    }
    await ScheduleTask.update(update, { where: { id: scheduleId } });
    return ScheduleTask.findOne({ where: { id: scheduleId } });
  }

  async viewScheduledJob(jobId, scheduleTaskId) {
    const job = await Job.findByPk(jobId, {
      include: [{
        model: ScheduleTask,
        where: { id: scheduleTaskId },
        required: true
      }]
    });
    if (!job) {
      const err = new Error('Scheduled Task Not Found');
      err.status = 404;
      throw err;
    }
    return job.ScheduleTasks;
  }

  async viewScheduledJobs(jobId, scheduleTaskId) {
    const job = await Job.findByPk(jobId, { include: [{ model: ScheduleTask }] });
    if (!job) {
      const err = new Error('Job Not Found');
      err.status = 404;
      throw err;
    }
    return job.ScheduleTasks;
  }

  async deleteScheduledById(scheduleId) {
    await ScheduleTask.update({ isActive: false }, { where: { id: scheduleId } });
    return ScheduleTask.findOne({ where: { id: scheduleId }, include: [{ all: true }] });
  }

  async deleteMultipleSchedulesById(scheduleIdList) {
    await ScheduleTask.update({ isActive: false }, { where: { id: { $in: scheduleIdList } } });
    return ScheduleTask.findAll({ where: { id: { $in: scheduleIdList } }, include: [{ all: true }] });
  }

  async startvCenterExtract(ipAddress, params, userToken, userId, orgId, scheduleId, assetRepoId) {
    logger.debug('Starting vCenter extract', { loggerLabel });
    logger.silly(`for org ${orgId}`, { loggerLabel });

    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const vCenterId = params.vCenterId;
    const softwareExtract = params.softwareExtract || false;
    const formData = { userToken, userId, orgId, vCenterId, softwareExtract, assetRepoId };

    if (scheduleId) {
      formData.scheduleId = scheduleId;
      const scheduleData = await ScheduleTask.findOne({ where: { id: scheduleId }, attributes: ['parameters'] });
      if (get(scheduleData, 'parameters')) {
        formData.parameters = get(scheduleData, 'parameters');
      }
    }

    if (params.applicationTagId) {
      formData.application_tag_id = params.applicationTagId;
    }

    const url = `${ipAddress}${this.uriPrefix}/extract/assets/vcenter`;
    await this.requestPost(url, formData, 'vCenterExtract Scan Result ', 'vCenter Extract Request Error');
  }

  async startVCDExtract(ipAddress, params, userToken, userId, orgId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    let orgName = params.orgName;
    const softwareExtract = params.softwareExtract || false;
    const organization = await Organization.findOne({ where: { id: orgId } });
    if (organization.type === 'Provider') orgName = '';
    const formData = { userToken, userId, orgId, softwareExtract, assetRepoId };
    if (scheduleId) formData.scheduleId = scheduleId;
    if (orgName) formData.orgName = orgName;
    const url = `${ipAddress}${this.uriPrefix}/extract/assets/vcd/`;
    await this.requestPost(url, formData, 'VCD Extract Scan Result ', 'VCD Extract Request Error');
  }

  async startOrgAssetScan(ipAddress, params, userToken, userId, orgId, scheduleId =-1, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const scanTypes = params.scanType;
    const assetId = params.assetId;
    const scanType = toLower(scanTypes);
    const formData = { userToken, userId, orgId, scanType, assetRepoId };
    if (scheduleId) formData.scheduleId = scheduleId;
    if (assetId) formData.assetId = assetId;
    const url = `${ipAddress}${this.uriPrefix}/extract/scan`;
    await this.requestPost(url, formData, 'Org Asset Scan Result ', 'Org Asset Scan Request Error');
  }

  async startOvalExtract(ipAddress, params, userToken, userId, orgId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const url = `${ipAddress}${this.uriPrefix}/caveoscap/fromsupport/getlatest?userToken=` + userToken + '&userId=' + userId + '&orgId=' + orgId;
    await this.requestGet(url, 'Oval Files Extract Started ', 'Oval Files Extract Request Error');
  }

  async startNSXScan(ipAddress, params, userToken, userId, orgId, scheduleId, assetRepoId) {
    logger.debug('Starting NSX scan', { loggerLabel });
    logger.silly(`for org ${orgId}`, { loggerLabel });

    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const vCenterId = params.vCenterId;
    let scanTypes = toLower(params.scanType);
    const flowsPeriod = params.flowsPeriod;
    const assetId = params.assetId;
    const nsxType = params.nsxType;
    if ((params.type === 'NSX-T' && scanTypes !== 'topology') || (params.type === 'NSX-V' && scanTypes !== 'flows')) {
      scanTypes = 'all';
    }
    const scanType = compact(split(toLower(scanTypes), ','));
    const formData = { userToken, userId, scanType, orgId, assetRepoId };
    if (scheduleId) {
      formData.scheduleId = scheduleId;
    }
    if (flowsPeriod) {
      formData.flowsPeriod = flowsPeriod;
    }
    if (vCenterId) {
      formData.vCenterId = vCenterId;
    }
    if (assetId) {
      formData.assets = assetId;
    }
    if (nsxType) {
      formData.type = nsxType;
    }
    const url = `${ipAddress}${this.uriPrefix}/extract/network/vcenter`;
    await this.requestPost(url, formData, 'NSX Extract Scan Result', 'NSX Extract Request Error');
  }

  async startSoftwareExtract(ipAddress, params, userToken, userId, orgId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const assetId = params.assetId;
    const formData = { userToken, userId, orgId, assetRepoId };
    if (scheduleId) formData.scheduleId = scheduleId;
    if (assetId) formData.assetId = assetId;
    const url = `${ipAddress}${this.uriPrefix}/extract/software`;
    await this.requestPost(url, formData, 'Software Extract Result', 'Software Extract Request Error');
  }

  async startLogExtract(ipAddress, params, userToken, userId, orgId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const assetId = params.assetId;
    const type = params.type;
    const endDate = moment().format('MM/DD/YYYY HH:MM');
    const startDate = moment().subtract('days', 1).format('MM/DD/YYYY HH:MM');
    const formData = { userToken, userId, orgId, type, startDate, endDate, assetRepoId };
    if (scheduleId) formData.scheduleId = scheduleId;
    if (assetId) formData.assetId = assetId;
    const url = `${ipAddress}${this.uriPrefix}/extract/log`;
    await this.requestPost(url, formData, 'LogExtract Scan Result ', 'Log Extract Scan Request Error');
  }

  async startAMQPExtract(ipAddress, params, userToken, userId, orgId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const formData = { userToken, userId, orgId, assetRepoId };
    if (scheduleId) formData.scheduleId = scheduleId;
    const url = `${ipAddress}${this.uriPrefix}/startAMQPExtract/`;
    await this.requestPost(url, formData, 'AMQPExtract Scan Result ', 'AMQP Extract Request Error');
  }

  async startVMWareScan(ipAddress, params, userToken, userId, orgId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const repoId = params.assetRepoId;
    const scanType = params.scanType;
    const repoType = params.repoType;
    const formData = { userToken, userId, orgId, repoId, scanType, repoType, assetRepoId };
    if (scheduleId) formData.scheduleId = scheduleId;
    const url = `${ipAddress}${this.uriPrefix}/infrastructure/scan/compliance`;
    await this.requestPost(url, formData, 'VMWare Scan Result ', 'VMWare Scan Request Error');
  }

  async startWatcherRequest(ipAddress, params, userToken, userId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const orgId = params.orgId;
    const formData = { userToken, userId, orgId };
    const url = `${ipAddress}${this.uriPrefix}/watcherRequest/`;
    await this.requestPost(url, formData, 'WatcherRequest Result ', 'Watcher Request Error');
  }

  async startVMWareVulnerabilityScan(ipAddress, params, userToken, userId, orgId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const repoId = params.assetRepoId;
    const scanType = params.scanType;
    const repoType = params.repoType;
    const formData = { userToken, userId, orgId, repoId, scanType, repoType, assetRepoId };
    if (scheduleId) formData.scheduleId = scheduleId;
    const url = `${ipAddress}${this.uriPrefix}/infrastructure/scan/vulnerability`;
    await this.requestPost(url, formData, 'VMWare Vulnerability Scan Result ', 'VMWare Vulnerability Request Error');
  }

  async startContainerExtract(ipAddress, params, userToken, userId, orgId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

    const formData = { userToken, userId, orgId, assetRepoId };
    if (scheduleId) formData.scheduleId = scheduleId;
    const url = `${ipAddress}${this.uriPrefix}/extract/assets/kubernetes`;
    await this.requestPost(url, formData, 'Container Extract Result', 'Container Extract Request Error');
  }

  async startContainerCompliance(ipAddress, params, userToken, userId, orgId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const formData = { userToken, userId, orgId, assetRepoId };
    if (scheduleId) formData.scheduleId = scheduleId;
    const url = `${ipAddress}${this.uriPrefix}/kubernetes/extract/compliance/`;
    await this.requestPost(url, formData, 'Container Compliance Result', 'Container Compliance Request Error');
  }

  async startOpenSackExtract(ipAddress, params, userToken, userId, orgId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const formData = { userToken, userId, orgId, assetRepoId };
    if (scheduleId) formData.scheduleId = scheduleId;
    const url = `${ipAddress}${this.uriPrefix}/extract/assets/openstack/`;
    await this.requestPost(url, formData, 'OpenSack Extract Result', 'OpenSack Extract Request Error');
  }

  async startOpenShiftExtract(ipAddress, params, userToken, userId, orgId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const formData = { userToken, userId, orgId, assetRepoId };
    if (scheduleId) formData.scheduleId = scheduleId;
    const url = `${ipAddress}${this.uriPrefix}/extract/assets/openshift/`;
    await this.requestPost(url, formData, 'OpenShift Extract Result', 'OpenShift Extract Request Error');
  }

  async startOpenSackVulnerability(ipAddress, params, userToken, userId, orgId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const formData = { userToken, userId, orgId, assetRepoId };
    if (scheduleId) formData.scheduleId = scheduleId;
    const url = `${ipAddress}${this.uriPrefix}/startOpenStackVulnerability/`;
    await this.requestPost(url, formData, 'OpenSack Vulnerability Result', 'OpenSack Vulnerability Request Error');
  }

  async startKubernetesVulnerability(ipAddress, params, userToken, userId, orgId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const formData = { userToken, userId, orgId, assetRepoId };
    if (scheduleId) formData.scheduleId = scheduleId;
    const url = `${ipAddress}${this.uriPrefix}/kubernetes/extract/vulnerability/`;
    await this.requestPost(url, formData, 'Container Vulnerability Result', 'Container Vulnerability Request Error');
  }

  async startOpenSackCompliance(ipAddress, params, userToken, userId, orgId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    // fixme look into orgId
    const formData = { userToken, userId, orgId, assetRepoId };
    if (scheduleId) formData.scheduleId = scheduleId;
    const url = `${ipAddress}${this.uriPrefix}/startOpenStackCompliance/`;
    await this.requestPost(url, formData, 'OpenSack Compliance Result', 'OpenSack Compliance Request Error');
  }

  async startVmcAssetExtract(ipAddress, params, userToken, userId, orgId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const orgName = params.orgName;
    const vcdvmsOnly = params.vcdvmsOnly;
    const formData = { userToken, userId, orgId, scheduleId, assetRepoId };
    if (scheduleId) formData.scheduleId = scheduleId;
    if (orgName) formData.orgName = orgName;
    if (vcdvmsOnly) formData.vcdvmsOnly = vcdvmsOnly;

    const url = `${ipAddress}${this.uriPrefix}/extract/assets/vmc/`;
    await this.requestPost(url, formData, 'VMC Netflow Extract Result ', 'VMC Netflow Extract request error');
  }

  async startVmcTopologyScan(ipAddress, params, userToken, userId, orgId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const orgName = params.orgName;
    const vcdvmsOnly = params.vcdvmsOnly;
    const formData = { userToken, userId, orgId, scanType: 'topology', assetRepoId };
    if (scheduleId) formData.scheduleId = scheduleId;
    if (orgName) formData.orgName = orgName;
    if (vcdvmsOnly) formData.vcdvmsOnly = vcdvmsOnly;

    const url = `${ipAddress}${this.uriPrefix}/extract/network/vmc/`;
    await this.requestPost(url, formData, 'VMC Topology Extract Result ', 'VMC Topology Extract request error');
  }

  async startAWSSQSExtract(ipAddress, params, userToken, userId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const orgId = params.orgId;
    const formData = { userToken, userId, orgId, scheduleId, assetRepoId };
    const url = `${ipAddress}${this.uriPrefix}/extract/queue/ec2`;
    const data = await this.requestPost(url, formData, 'AWS SQS Extract EC2 Result ', 'AWS SQS Extract EC2 Request Error');
    return data;
  }

  async startAWSExtract(ipAddress, params, userToken, userId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const orgId = params.orgId;
    const formData = { userToken, userId, orgId, scheduleId, assetRepoId };
    const url = `${ipAddress}${this.uriPrefix}/extract/assets/aws/`;
    await this.requestPost(url, formData, 'AWS Extract Result ', 'AWS Extract Request Error');
  }

  async startGKEAssetExtract(ipAddress, params, userToken, userId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';    
    const orgId = params.orgId;
    const formData = { userToken, userId, orgId, scheduleId, assetRepoId };
    const url = `${ipAddress}${this.uriPrefix}/extract/assets/gke`;
    await this.requestPost(url, formData, 'GKE Extract Result', 'GKE Extract Request Error');
  } 

  async startAKSAssetExtract(ipAddress, params, userToken, userId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';    
    const orgId = params.orgId;
    const formData = { userToken, userId, orgId, scheduleId, assetRepoId };
    const url = `${ipAddress}${this.uriPrefix}/extract/assets/aks`;
    await this.requestPost(url, formData, 'AKS Extract Result', 'AKS Extract Request Error');
  }  

  async startEKSAssetExtract(ipAddress, params, userToken, userId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';    
    const orgId = params.orgId;
    const formData = { userToken, userId, orgId, scheduleId, assetRepoId };
    const url = `${ipAddress}${this.uriPrefix}/extract/assets/eks`;
    await this.requestPost(url, formData, 'EKS Extract Result', 'EKS Extract Request Error');
  }  

  async startS3Extract(ipAddress, params, userToken, userId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const orgId = params.orgId;
    const formData = { userToken, userId, orgId, scheduleId, assetRepoId };
    const url = `${ipAddress}${this.uriPrefix}/extract/s3config/`;
    await this.requestPost(url, formData, 's3 Extract Result ', 's3 Extract Request Error');
  }

  async startCloudtrailExtract(ipAddress, params, userToken, userId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const orgId = params.orgId;
    const formData = { userToken, userId, orgId, scheduleId, assetRepoId };
    if (params.flowsPeriod) formData.flowsPeriod = params.flowsPeriod;
    const url = `${ipAddress}${this.uriPrefix}/extract/cloudtrail/`;
    await this.requestPost(url, formData, 'CloudTrail Extract Result ', 'CloudTrail Extract Request Error');
  }

  async startAWSNetflowExtract(ipAddress, params, userToken, userId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const orgId = params.orgId;
    if (!params.vpc_name) {
      const err = new Error('VPC Name is missing for AWS Netflow extract');
      err.status = 400;
      throw err;
    }
    const vpcName = params.vpc_name;
    const endTime = moment().format('MM/DD/YYYY HH:MM');
    const startTime = moment().subtract('days', 1).format('MM/DD/YYYY HH:MM');
    const formData = { userToken, userId, orgId, startTime, endTime, scheduleId, assetRepoId, vpcName };
    const url = `${ipAddress}${this.uriPrefix}extract/aws/netflows/`;
    await this.requestPost(url, formData, 'AWS NetFlow Extract Result ', 'AWS NetFlow Extract Request Error');
  }

  async startAWSComplianceScan(ipAddress, params, userToken, userId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const orgId = params.orgId;
    const endDt = moment().format('MM/DD/YYYY HH:MM');
    const startDt = moment().subtract('days', 1).format('MM/DD/YYYY HH:MM');
    const form = { userId, orgId, startTime: startDt, endTime: endDt, scheduleId, assetRepoId, userToken };
    const ccUrl = `${ipAddress}/${this.uriPrefix}/extract/compliance/securityhub/`;
    try {
      const response = await requestPromise({
        url: ccUrl,
        method: 'POST',
        form
      });
      logger.info('AWS NetFlow Extract Result ');
      return response;
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred ');
      if (error.error && !_.isObject(error.error)) {
        error.message = error.error || error.message;
      }
      error.status = 404;
      throw error;
    }
  }

  async startAzureAssetExtract(ipAddress, params, userToken, userId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const orgId = params.orgId;
    const formData = { userToken, userId, orgId, scheduleId, assetRepoId };
    const url = `${ipAddress}${this.uriPrefix}/extract/assets/azure`;
    await this.requestPost(url, formData, 'Azure Extract Result', 'Azure Extract request error');
  }

  async startAzureServicesExtract(ipAddress, params, userToken, userId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const orgId = params.orgId;
    const formData = { userToken, userId, orgId, scheduleId, assetRepoId };
    const url = `${ipAddress}${this.uriPrefix}/extract/azure/services`;
    await this.requestPost(url, formData, 'GCP Extract Result', 'GCP Extract request error');
  }

  async startAzureInfrastructureScan(ipAddress, params, userToken, userId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const orgId = params.orgId;
    const formData = { userToken, userId, orgId, scheduleId, assetRepoId };
    const url = `${ipAddress}${this.uriPrefix}/extract/azure/compliance`;
    await this.requestPost(url, formData, 'GCP Extract Result', 'GCP Extract request error');
  }

  async startGCPServicesExtract(ipAddress, params, userToken, userId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const orgId = params.orgId;
    const formData = { userToken, userId, orgId, scheduleId, assetRepoId };
    const url = `${ipAddress}${this.uriPrefix}/extract/gcp/services`;
    await this.requestPost(url, formData, 'GCP Extract Result', 'GCP Extract request error');
  }

  async startGCPInfrastructureScan(ipAddress, params, userToken, userId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const orgId = params.orgId;
    const formData = { userToken, userId, orgId, scheduleId, assetRepoId };
    const url = `${ipAddress}${this.uriPrefix}/extract/gcp/compliance`;
    await this.requestPost(url, formData, 'GCP Extract Result', 'GCP Extract request error');
  }

  async startGCPAssetExtract(ipAddress, params, userToken, userId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const orgId = params.orgId;
    const formData = { userToken, userId, orgId, scheduleId, assetRepoId };
    const url = `${ipAddress}${this.uriPrefix}/extract/assets/gcp`;
    await this.requestPost(url, formData, 'GCP Extract Result', 'GCP Extract request error');
  }

  async startGCPNetflowExtract(ipAddress, params, userToken, userId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const orgId = params.orgId;
    const formData = { userToken, userId, orgId, scheduleId, assetRepoId };
    const url = `${ipAddress}${this.uriPrefix}/extract/gcp/netflows/`;
    await this.requestPost(url, formData, 'GCP Netflow Extract Result ', 'GCP Netflow Extract request error');
  }

  async startAWSSecurityHubExtract(ipAddress, params, userToken, userId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const orgId = params.orgId;
    const formData = { userToken, userId, orgId, scheduleId, assetRepoId };
    const url = `${ipAddress}${this.uriPrefix}/extract/queue/securityhub?userToken=${userToken}&userId=${userId}&orgId=${orgId}&assetRepoId=${assetRepoId}`;
    await this.requestPost(url, formData, 'AWS Security Hub Extract Results', 'AWS Security Hub Extract request error');
  }

  async startAWSServicesExtract(ipAddress, params, userToken, userId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const orgId = params.orgId;
    const formData = { userToken, userId, orgId, scheduleId, assetRepoId };
    const url = `${ipAddress}${this.uriPrefix}/extract/services?userToken=${userToken}&userId=${userId}&orgId=${orgId}&assetRepoId=${assetRepoId}`;
    await this.requestPost(url, formData, 'AWS Services Extract Results', 'AWS Services Extract request error');
  }

  async startAWSCISCompliance(ipAddress, params, userToken, userId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const orgId = params.orgId;
    const formData = { userToken, userId, orgId, scheduleId, assetRepoId };
    const url = `${ipAddress}${this.uriPrefix}/extract/compliance/cis?userToken=${userToken}&userId=${userId}&orgId=${orgId}&assetRepoId=${assetRepoId}`;
    await this.requestPost(url, formData, 'AWS CIS Compliance Results', 'AWS CIS Compliance request error');
  }

  async startAzureNetflowExtract(ipAddress, params, userToken, userId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const orgId = params.orgId;
    const formData = { userToken, userId, orgId, scheduleId, assetRepoId };
    const url = `${ipAddress}${this.uriPrefix}/extract/azure/netflows/`;
    await this.requestPost(url, formData, 'Azure Netflow Extract Result ', 'Azure Netflow Extract request error');
  }

  async startHytrustInfrastructureScan(ipAddress, params, userToken, userId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const orgId = params.orgId;
    const formData = { userToken, userId, orgId, scheduleId, assetRepoId };
    const url = `${ipAddress}${this.uriPrefix}/hytrust/compliance/?userToken=${userToken}&userId=${userId}&orgId=${orgId}&assetRepoId=${assetRepoId}`;
    await this.requestPost(url, formData, 'Hytrust Infrastructure Scan Results', 'Hytrust Infrastructure Scan request error');
  }

  async startHytrustSyslogExtract(ipAddress, params, userToken, userId, scheduleId, assetRepoId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const orgId = params.orgId;
    const flowsPeriod = params.flowsPeriod ? params.flowsPeriod : '1'; // Default 1 Hour
    const formData = { userToken, userId, orgId, scheduleId, assetRepoId, flowsPeriod };
    const url = `${ipAddress}${this.uriPrefix}/hytrust/logextract?userToken=${userToken}&userId=${userId}&orgId=${orgId}&assetRepoId=${assetRepoId}`;
    await this.requestPost(url, formData, 'Hytrust Syslog Extract Results', 'Hytrust Syslog Extract request error');
  }

  async startRelationalDatastoreBackup(ipAddress, params, userToken, userId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const orgId = params.orgId;
    const liveDataPeriod = params.liveDataPeriod;
    const scheduleId = params.jobId;
    const formData = { userToken, userId, orgId, scheduleId, liveDataPeriod };
    const url = `${ipAddress}${this.uriPrefix}/indexbackup/`;
    await this.requestPost(url, formData, 'Relational Datastore Backup Result ', 'Relational Datastore Backup Request Error');
  }

  async startRelationalDatastoreRestore(ipAddress, params, userToken, userId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const orgId = params.orgId;
    const fromDate = params.fromDate;
    const toDate = params.toDate;
    const type = params.restoreType;
    const scheduleId = params.jobId;
    const formData = { userToken, userId, orgId, type, fromDate, toDate, scheduleId };
    const url = `${ipAddress}${this.uriPrefix}/indexrestore/`;
    await this.requestPost(url, formData, 'Relational Datastore Restore Result ', 'Relational Datastore Restore Error');
  }

  async startRelationalDatastoreDeleteBackup(ipAddress, params, userToken, userId) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const orgId = params.orgId;
    const backupRetentionPeriod = params.backupRetentionPeriod;
    const scheduleId = params.jobId;
    const liveDataPeriod = params.liveDataPeriod;
    const formData = { userToken, userId, orgId, liveDataPeriod, scheduleId, backupRetentionPeriod };
    const url = `${ipAddress}${this.uriPrefix}/deletebackup/`;
    await this.requestPost(url, formData, 'Relational Datastore Delete Backup Result ', 'Relational Datastore Delete Backup Error');
  }

  async createModifyScheduleJob(scheduleJob, userId, token, OrganizationId, createModifyJob, jobName, type) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const userToken = token;
    const orgId = OrganizationId;
    const id = scheduleJob.id;
    const vCenterId = scheduleJob.asset_repo_id;
    const orgName = scheduleJob.org_name;
    const cronExp = scheduleJob.cron_expression;
    const scanTypes = scheduleJob.scan_type;
    const activeCCAddress = await CentralCollectorClient.getCentralCollectorAddress();
    if (!activeCCAddress) {
      const err = new Error('Central Collector Not Found');
      err.status = 404;
      throw err;
    }

    let ccUrl = '';
    let options = '';
    if (scheduleJob.flowsPeriod) {
      options = '&flowsPeriod=' + scheduleJob.flowsPeriod;
    }
    if (type.toLowerCase() === 'audit report' || type.toLowerCase() === 'compliance report' || type.toLowerCase() === 'compliance delta report' || type.toLowerCase() === 'cyber risk report' || type.toLowerCase() === 'cyber risk delta report') {
      if (scheduleJob.parameters) {
        const jsonObject = JSON.parse(scheduleJob.parameters);
        const regulation = jsonObject.regulation;
        const applicationId = jsonObject.applicationId;
        const email = jsonObject.email;
        if (applicationId) {
          options = '&applicationId=' + applicationId;
        }
        if (regulation) {
          options = options + '&regulation=' + regulation;
        }
        if (email) {
          options = options + '&email=' + email;
        }
      }
    }
    if (type.toLowerCase() === 'backup index datastore') {
      if (scheduleJob.parameters) {
        const jsonObject = JSON.parse(scheduleJob.parameters);
        const liveDataPeriod = jsonObject.liveDataPeriod;
        const backupRetentionPeriod = jsonObject.backupRetentionPeriod;
        if (liveDataPeriod) {
          options = '&liveDataPeriod=' + liveDataPeriod;
        }
        if (backupRetentionPeriod) {
          options = options + '&backupRetentionPeriod=' + backupRetentionPeriod;
        }
      }
    }
    if (createModifyJob === 'Modify') {
      ccUrl = activeCCAddress + `/${SERVICE_TYPE}/api/v1/restartScheduler/?userToken=` + userToken + '&userId=' + userId + '&orgId=' + orgId + '&jobName=' + jobName + '&id=' + id + '&vCenterId=' + vCenterId + '&orgName=' + orgName + '&cronExp=' + cronExp + '&scanTypes=' + scanTypes + '&type=' + type + options;
    } else if (createModifyJob === 'unSchedule') {
      ccUrl = activeCCAddress + `/${SERVICE_TYPE}/api/v1/restartScheduler/?userToken=` + userToken + '&userId=' + userId + '&orgId=' + orgId + '&jobName=' + jobName + '&id=' + id;
    } else if (createModifyJob === 'Delete') {
      ccUrl = activeCCAddress + `/${SERVICE_TYPE}/api/v1/deleteScheduleJob/?userToken=` + userToken + '&userId=' + userId + '&orgId=' + orgId + '&jobName=' + jobName + '&id=' + id;
    } else if (createModifyJob === 'watcherSchedule') {
      ccUrl = activeCCAddress + `/${SERVICE_TYPE}/api/v1/createScheduleJob/?userToken=` + userToken + '&userId=' + userId + '&orgId=' + orgId + '&jobName=' + jobName + '&id=' + id + '&vCenterId=' + vCenterId + '&orgName=' + orgName + '&cronExp=' + cronExp + '&scanTypes=' + scanTypes + '&type=' + type + '&loginOrgId=' + orgId + options;
    } else {
      ccUrl = activeCCAddress + `/${SERVICE_TYPE}/api/v1/createScheduleJob/?userToken=` + userToken + '&userId=' + userId + '&orgId=' + orgId + '&jobName=' + jobName + '&id=' + id + '&vCenterId=' + vCenterId + '&orgName=' + orgName + '&cronExp=' + cronExp + '&scanTypes=' + scanTypes + '&type=' + type + options;
    }
    try {
      const response = await requestPromise({
        url: ccUrl,
        method: 'GET',
        resolveWithFullResponse: true,
        timeout: ccTimeout
      });
      logger.info('Scheduled Job Modified.. ');
      if (response.statusCode === 200 || response.statusCode === 202) {
        logger.info('Status: ' + response.statusCode + ' Status Message: Success');
      } else {
        logger.info('Status: ' + response.statusCode + ' Status Message: Failed');
      }

    } catch (error) {
      const err = new Error('CentralCollector request error' + error);
      err.status = 404;
      throw err;
    }


  }

  getCaveoAgents(agent) {
    return CaveoAgents.findOne({ where: { agent_name: agent, $or: [{ isActive: { $ne: 'false' } }] } });
  }

  async checkNameForUpdate(name, scheduleId, orgId, type) {
    const job = await Job.findOne({ where: { name: type } });
    return ScheduleTask.findOne({
      where: {
        name: sequelize.where(sequelize.fn('LOWER', sequelize.col('name')), sequelize.fn('lower', name)),
        org_id: orgId,
        job_id: job.id,
        $or: [{ isActive: { $ne: 'false' } }],
        id: { $ne: scheduleId }
      }
    });
  }

  checkJobTypeForUpdate(jobId, cronExpression, scheduleId, orgId, assetRepoId, typeName, scantype, arguementsString) {
    if (typeName.toLowerCase() === 'vcenter') {
      return ScheduleTask.findOne({
        where: {
          asset_repo_id: assetRepoId,
          cron_expression: cronExpression,
          parameters: arguementsString,
          org_id: orgId,
          $or: [{ isActive: { $ne: 'false' } }],
          id: { $ne: scheduleId }
        }
      });
    }
    if (typeName.toLowerCase() === 'get latest vulnerabilities') {
      return ScheduleTask.findOne({
        where: {
          job_id: jobId,
          $or: [{ isActive: { $ne: 'false' } }],
          id: { $ne: scheduleId }
        }
      });
    }
    const where = {
      job_id: jobId,
      cron_expression: cronExpression,
      org_id: orgId,
      isActive: { $ne: 'false' },
      id: { $ne: scheduleId }
    };
    if (scantype) {
      where.scan_type = scantype;
    }
    return ScheduleTask.findOne({ where });
  }

  async checkName(name, orgId, type) {
    return ScheduleTask.findOne({
      where: {
        name: sequelize.where(sequelize.fn('LOWER', sequelize.col('ScheduleTask.name')), sequelize.fn('lower', name)),
        org_id: orgId,
        isActive: { $ne: 'false' }
      },
      include: [
        { model: Job, where: { name: type }, attributes: [] }
      ]
    });
  }

  checkJobType(jobId, cronExpression, orgId, assetRepoId, typeName, scantype, arguementsString) {
    if (typeName.toLowerCase() === 'vcenter') {
      return ScheduleTask.findOne({
        where: {
          asset_repo_id: assetRepoId,
          cron_expression: cronExpression,
          parameters: arguementsString,
          org_id: orgId,
          $or: [{ isActive: { $ne: 'false' } }]
        }
      });
    }
    if (typeName.toLowerCase() === 'get latest vulnerabilities') {
      return ScheduleTask.findOne({ where: { job_id: jobId, $or: [{ isActive: { $ne: 'false' } }] } });
    }
    return ScheduleTask.findOne({
      where: {
        job_id: jobId,
        cron_expression: cronExpression,
        org_id: orgId,
        scan_type: scantype,
        $or: [{ isActive: { $ne: 'false' } }]
      }
    });
  }

  async loadNVDFiles() {
    let checkStatus = true;
    const service = this;
    const caveoagents = await CaveoAgents.findAll({
      where: {
        agent_name: 'CentralCollector',
        $or: [{ isActive: { $ne: 'false' } }]
      }
    });
    if (!caveoagents) {
      const err = new Error('Central Collector Not Found');
      err.status = 404;
      throw err;
    }
    for (let i = 0; i < caveoagents.length; i++) {
      const agent = caveoagents[i];
      const ipAddress = agent.ipAddress;
      const urlToCheckStatus = `${ipAddress}${service.uriPrefix}/status/`;
      process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
      try {
        const response = await requestPromise({ url: urlToCheckStatus, method: 'GET', resolveWithFullResponse: true });
        if (response && checkStatus === true) {
          if (response.statusCode === 200 || response.statusCode === 202) {
            try {
              checkStatus = false;
              //TODO
              /*
              const currrentYear = new Date().getFullYear();
              const currrentYear = new Date().getFullYear();
              const urlToLoadNVD = `${ipAddress}${service.uriPrefix}/load/nvdfiles?type=delta&year=${currrentYear}`;
              const loadNVDResponse = await service.rp.get(urlToLoadNVD);
              const urlToLoadNVD = `${ipAddress}${service.uriPrefix}/load/nvdfiles?type=delta&year=${currrentYear}`;
              */
              const urlToLoadNVD = `${ipAddress}${service.uriPrefix}/load/nvdfiles?type=full&year=2002`;
              const loadNVDResponse = await this.rp.get(urlToLoadNVD, {
                resolveWithFullResponse: true,
                timeout: 20000
              });
              logger.info('LoadNVD: ' + loadNVDResponse + ' Status Message: Success');
            } catch (error) {
              if (error.message.includes('ESOCKETTIMEDOUT')) {
                logger.error({ error, stack: error.stack }, 'Central Collector timeout and success'); // Hit and say success if timeout
                return 'timeout and success';
              } else {
                logger.error('LoadNVD: ' + error.statusCode + ' Status Message: Failed');
              }
            }
          }
        }
      } catch (error) {
        logger.error({ error, stack: error.stack }, 'Central Collector Request Error');
        return { message: error.message };
      }
    }
  }

  async CustomNvdFileSave(data, orgId, userToken, userId, checkStatus) {
    const filePath = '/tmp';
    const finalPath = '/tmp/persistent/customNVDAPI';
    if (!fs.existsSync(filePath)) fs.mkdirSync(filePath);
    if (!fs.existsSync('/tmp/persistent')) fs.mkdirSync('/tmp/persistent');
    if (!fs.existsSync('/tmp/persistent/customNVDAPI')) fs.mkdirSync('/tmp/persistent/customNVDAPI');
    const filePathWithName = finalPath + '/CustomNVDFile' + '_' + orgId;
    logger.info('before save file:  ' + filePathWithName);
    fs.writeFileSync(filePathWithName, data, function (err) {
      if (!err) {
        console.log('Saved!');
      }
    });
    logger.info('after saved file:  ' + filePathWithName);
    const activeCCAddress = await CentralCollectorClient.getCentralCollectorAddress();
    if (!activeCCAddress) {
      const err = new Error('Central Collector Not Found');
      err.status = 404;
      throw err;
    }
    const caveoagents = await CaveoAgents.findAll({
      where: {
        agent_name: 'CentralCollector',
        $or: [{ isActive: { $ne: 'false' } }]
      }
    });
    for (let i = 0; i < caveoagents.length; i++) {
      const agent = caveoagents[i];
      try {
        const ccUrl = agent.ipAddress + `/${SERVICE_TYPE}/api/v1/customnvdparser/?userToken=` + userToken + '&userId=' + userId + '&orgId=' + orgId;
        logger.info('before central collector request:    ' + ccUrl);
        const formData = {
          inputFile: fs.createReadStream(filePathWithName)
        };
        try {
          const response = await this.rp.post(ccUrl, { formData: formData, resolveWithFullResponse: true });
          logger.info('after central collector request:' + response.statusMessage);
          if (response.statusCode === 200 || response.statusCode === 202) {
            checkStatus = false;
            logger.info('Status: ' + response.statusCode + ' Status Message: Success');
          } else {
            logger.info('Status: ' + response.statusCode + ' Status Message: Failed');
          }
        } catch (error) {
          const err = new Error('CentralCollector request error' + error);
          err.status = 404;
          throw err;
        }
      } catch (error) {
        continue;
      }
    }
  }

  async scheduleReportJob(orgId, params) {
    const typeName = params.type_name;
    const cronExpression = params.cron_expression;
    const Organization = require('../organization/organization.model');
    const organization = await Organization.findOne({ where: { id: orgId } });
    if (!organization) {
      const err = new Error('Organization not found.');
      err.status = 404;
      throw err;
    }
    if (!params.email) {
      logger.warn(params, 'the params');
      const err = new Error('Invalid value for email field');
      err.status = 400;
      throw err;
    }
    const orgName = organization.name;
    const argumentsString = '';
    let argumentsJson = {};
    if (typeName.toLowerCase() === 'compliance audit report') {
      const applicationId = params.applicationId ? params.applicationId : 'null';
      const regulation = params.regulation ? params.regulation : 'null';
      const email = params.email ? params.email : 'null';

      argumentsJson = {
        applicationId,
        regulation,
        email
      };
    } else if (typeName.toLowerCase() === 'compliance report' || typeName.toLowerCase() === 'compliance delta report') {
      const regulation = params.regulation ? params.regulation : 'null';
      const email = params.email ? params.email : 'null';

      argumentsJson = {
        regulation,
        email
      };
    } else if (typeName.toLowerCase() === 'cyber risk report' || typeName.toLowerCase() === 'cyber risk delta report') {
      const email = params.email ? params.email : 'null';

      argumentsJson = {
        email
      };
    }
    params.parameters = JSON.stringify(argumentsJson);
    params.org_name = orgName;
    const job = await Job.findOne({ where: { name: typeName, $or: [{ is_active: { $ne: 'false' } }] } });
    if (!job) {
      const err = new Error('Job type ' + typeName + ' not found.');
      err.status = 404;
      throw err;
    }
    const jobId = job.id;
    params.job_id = jobId;
    params.org_id = orgId;

    const exists = await ScheduleTask.findOne({
      where: {
        job_id: jobId,
        cron_expression: cronExpression,
        parameters: argumentsString,
        org_id: orgId,
        $or: [{ isActive: { $ne: 'false' } }]
      }
    });

    if (exists) {
      const err = new Error(`${typeName} job already exists with the same schedule.`);
      err.status = 400;
      throw err;
    }
    return ScheduleTask.create(params);
  }

  async updateReportJob(orgId, params, scheduleId) {
    const typeName = params.type_name;
    const cronExpression = params.cron_expression;
    const Organization = require('../organization/organization.model');
    const organization = await Organization.findOne({ where: { id: orgId } });
    if (!organization) {
      const err = new Error('Organization Not Found');
      err.status = 404;
      throw err;
    }
    if (!params.email) {
      const err = new Error('Invalid value for email field');
      err.status = 400;
      throw err;
    }
    const orgName = organization.name;
    const argumentsString = '';
    let argumentsJson = {};
    if (typeName.toLowerCase() === 'compliance audit report') {
      const applicationId = params.applicationId ? params.applicationId : 'null';
      const regulation = params.regulation ? params.regulation : 'null';
      const email = params.email ? params.email : 'null';

      argumentsJson = {
        applicationId,
        regulation,
        email
      };
    } else if (typeName.toLowerCase() === 'compliance report' || typeName.toLowerCase() === 'compliance delta report') {
      const regulation = params.regulation ? params.regulation : 'null';
      const email = params.email ? params.email : 'null';

      argumentsJson = {
        regulation,
        email
      };
    } else if (typeName.toLowerCase() === 'cyber risk report' || typeName.toLowerCase() === 'cyber risk delta report') {
      const email = params.email ? params.email : 'null';

      argumentsJson = {
        email
      };
    }
    params.parameters = JSON.stringify(argumentsJson);
    params.org_name = orgName;
    const job = await Job.findOne({ where: { name: typeName, $or: [{ is_active: { $ne: 'false' } }] } });
    if (!job) {
      const err = new Error('Job type ' + typeName + ' Not Found');
      err.status = 404;
      throw err;
    }
    const jobId = job.id;
    params.job_id = jobId;
    params.org_id = orgId;

    const exists = await ScheduleTask.findOne({
      where: {
        job_id: jobId,
        cron_expression: cronExpression,
        parameters: argumentsString,
        org_id: orgId,
        $or: [{ isActive: { $ne: 'false' } }],
        id: { $ne: scheduleId }
      }
    });
    if (exists) {
      const err = new Error('Schedule is already created for job type ' + typeName + '.');
      err.status = 400;
      throw err;
    }

    await ScheduleTask.update(params, { where: { id: scheduleId } });
    return ScheduleTask.findOne({ where: { id: scheduleId } });
  }

  async createAuditReport(orgId, token, regulation, applicationId, email, reportType) {
    try {
      const reportService = new ReportService();
      let data;
      switch (reportType) {
        case 'Audit Report':
          if (regulation == null) {
            const e = new Error('no regulation provided for audit report');
            e.status = 400;
            throw e;
          }
          if (applicationId == null) {
            applicationId = 0;
          }
          data = await reportService.createAuditReport(orgId, token, regulation, applicationId);
          break;
        case 'Compliance Report':
          if (regulation == null) {
            const e = new Error('no regulation provided for audit report');
            e.status = 400;
            throw e;
          }
          data = await reportService.createComplianceReport(orgId, token, regulation);
          break;
        case 'Cyber Risk Report':
          data = await reportService.createCyberReport(orgId, token);
          break;
        case 'Compliance Delta Report':
          if (regulation == null) {
            const e = new Error('no regulation provided for audit report');
            e.status = 400;
            throw e;
          }
          data = await reportService.createComplianceDeltaReport(orgId, token, regulation);
          break;
        case 'Cyber Risk Delta Report':
          data = await reportService.createCyberDeltaReport(orgId, token);
          break;
        default:
          const e = new Error('unknown report type');
          e.status = 400;
          throw e;
      }

      const emailServerService = new EmailServerService();
      const result = emailServerService.sendEmail(orgId, reportType, 'this is a report', data);
      return result;
    } catch (error) {
      if (error.message.includes('ECONNREFUSED')) {
        const e = new Error('Error in connection to report service.');
        e.status = 400;
        throw e;
      }
      logger.error({ error, stack: error.stack }, 'error occurred');
      throw error;
    }
  }

  async requestPost(url, formData, successMessage, errMessage) {
    logger.debug('making post request to the central collector', { loggerLabel });
    try {
      const response = await this.rp.post(url, { form: formData, resolveWithFullResponse: true, timeout: ccTimeout });
      logger.silly(successMessage, { loggerLabel });
      return response;
    } catch (error) {
      const status = get(error, 'statusCode');
      const errorMessage = get(error, 'message', 'Central Collector Error. Please contact your Caveonix administrator.');
      if ((status === 503) || errorMessage.includes('ECONNREFUSED') || errorMessage.includes('ENOTFOUND') || errorMessage.includes('Unavailable')) {
        logger.error('Central Collector Error', { error, loggerLabel });
        error.status = status || 400;
        error.message = 'Central Collector Unavailable. Please contact your Caveonix administrator.';
      } else if (errorMessage.includes('ETIMEDOUT') || errorMessage.includes('ESOCKETTIMEDOUT')) {
        logger.error('Central Collector Timeout', { error, loggerLabel });
        error.status = 400;
        error.message = 'Central Collector Timeout. Please contact your Caveonix administrator.';
      } else if (errorMessage.includes('Internal')) {
        logger.error('Central Collector Error', { error, loggerLabel });
        error.status = 400;
        error.message = 'Central Collector Error. Please contact your Caveonix administrator.';
      } else if (status === 500) {
        logger.error('Central Collector Error', { error, loggerLabel });
        error.status = 400;
        error.message = get(error, 'error') || 'Central Collector Unavailable. Please contact your Caveonix administrator.';
      } else {
        logger.error(errMessage, { error, loggerLabel });
        error.message = get(error, 'error') || errMessage;
        error.message = get(error, 'message') ? get(error, 'message').replace(/\n/g, '<br>') : error.message;
        error.status = get(error, 'statusCode');
      }
      throw error;
    }
  }

  async requestGet(url, successMessage, errMessage) {
    logger.debug('Making get request to the Central Collector', { loggerLabel });

    try {
      const response = await this.rp.get(url, { resolveWithFullResponse: true, timeout: ccTimeout });
      logger.silly(successMessage, { loggerLabel });
      return response;
    } catch (error) {
      const status = get(error, 'statusCode');
      const errorMessage = get(error, 'message', 'Central Collector Error. Please contact your Caveonix administrator.');
      if ((status === 503) || errorMessage.includes('ECONNREFUSED') || errorMessage.includes('ENOTFOUND') || errorMessage.includes('Unavailable')) {
        logger.error('Central Collector Error', { error, loggerLabel });
        error.status = status || 400;
        error.message = 'Central Collector Unavailable. Please contact your Caveonix administrator.';
      } else if (errorMessage.includes('ETIMEDOUT') || errorMessage.includes('ESOCKETTIMEDOUT')) {
        logger.error('Central Collector Timeout', { error, loggerLabel });
        error.status = 400;
        error.message = 'Central Collector Timeout. Please contact your Caveonix administrator.';
      } else if (errorMessage.includes('Internal')) {
        logger.error('Central Collector Error', { error, loggerLabel });
        error.status = 400;
        error.message = 'Central Collector Error. Please contact your Caveonix administrator.';
      } else if (status === 500) {
        logger.error('Central Collector Error', { error, loggerLabel });
        error.status = 400;
        error.message = get(error, 'error') || 'Central Collector Unavailable. Please contact your Caveonix administrator.';
      } else if (errorMessage.includes('ESOCKETTIMEDOUT')) {
        logger.error('Central Collector timeout and success', { error, loggerLabel }); // Hit and say success if timeout
        return successMessage;
      } else {
        logger.error(errMessage, { error, loggerLabel });
        error.message = get(error, 'error') || errMessage;
        error.status = get(error, 'statusCode');
      }
      throw error;
    }
  }

  async checkRemoteAccess(params) {

    //Checking remote access for orgids or orgIds from asset id is present
    let orgIds = [params.orgId];
    const assetIds = params.assetId ? ((!Array.isArray(params.assetId)) ? params.assetId.split(',') : [params.assetId]) : [];

    if (assetIds.length > 0) {
      const orgData = await sequelize.query(`select distinct (organization_id) from application_group_asset_view where id in (:assetIds)`, {
        replacements: { assetIds },
        type: QueryTypes.SELECT
      });
      orgIds = orgData.map(a => {
        return a.organization_id;
      });
    }
    if (orgIds.length <= 0) return false;
    //checking default , asset specific and service account remote access
    let remoteAccessData = await RemoteAccessDetail.count({
      where: {
        type: { $in: ['default', 'asset','service account'] },
        organization_id: { $in: orgIds },
        is_active: { $in: ['enabled', 'true'] }
      }
    });
    if (remoteAccessData) return true;

    //checking remote access is present if default is not there
    remoteAccessData = await sequelize.query(`Select count(*) as count from remote_access_details where is_active in ('enabled','true') and id in 
    (select remote_access_detail_id from asset_remote_access_detail_members 
     where asset_id in (select id from application_group_asset_view where organization_id in (:orgIds)));`, {
      replacements: { orgIds },
      type: QueryTypes.SELECT
    });
    if (parseInt(remoteAccessData[0].count) > 0) return true;

    return false;
  }

  async ovalUpload(data, userToken, userId, orgId, fileSize, mimeType) {
    const scanAudit = await ScanAudit.create({
      scanType: 'Oval File Upload',
      status: 'Started',
      user_id: userId,
      organization_id: orgId,
      job_id: '-1',
      parent_id: 0
    });
    if (!['application/gzip', 'application/x-gzip', 'application/x-tar', 'application/x-gtar', 'application/x-tgz'].includes(mimeType)) {
      ScanAudit.create({
        scanType: 'Oval File Upload',
        status: 'Error',
        user_id: userId,
        organization_id: orgId,
        job_id: '-1',
        parent_id: scanAudit.id,
        message: 'Invalid file format. Allowed file extension - .tar.gz'
      });
      const r = new Error('Invalid file format. Allowed file extension - .tar.gz');
      r.status = 400;
      throw r;
    }
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const filePath = '/tmp';
    const finalPath = '/tmp/persistent/ovalFile';
    if (!fs.existsSync(filePath)) fs.mkdirSync(filePath);
    if (!fs.existsSync('/tmp/persistent')) fs.mkdirSync('/tmp/persistent');
    if (!fs.existsSync('/tmp/persistent/ovalFile')) fs.mkdirSync('/tmp/persistent/ovalFile');
    const filePathWithName = finalPath + '/caveoscap.tar.gz';
    await fs_writeFile(filePathWithName, data).then((data) => {
      this.ovalUploadtoCentralCollector(data, userToken, userId, orgId, fileSize, filePathWithName, scanAudit);
      logger.info(`Saved Successfully in ${filePathWithName}`);
      return true;
    }).catch(function (e) {
      ScanAudit.create({
        scanType: 'Oval File Upload',
        status: 'Error',
        user_id: userId,
        organization_id: orgId,
        job_id: '-1',
        parent_id: scanAudit.id,
        message: e.message
      });
      logger.error(e);
      e.message = 'Oval File uploading Error';
      e.status = 400;
      throw e;
    });

  }

  async ovalUploadtoCentralCollector(data, userToken, userId, orgId, fileSize, filePathWithName, scanAudit) {
    const activeCCAddress = await CentralCollectorClient.getCentralCollectorAddress();
    if (!activeCCAddress) {
      ScanAudit.create({
        scanType: 'Oval File Upload',
        status: 'Error',
        user_id: userId,
        organization_id: orgId,
        job_id: '-1',
        parent_id: scanAudit.id,
        message: 'Central Collector Not Found'
      });
      const err = new Error('Central Collector Not Found');
      err.status = 404;
      throw err;
    }
    const caveoagents = await CaveoAgents.findAll({
      where: {
        agent_name: 'CentralCollector',
        $or: [{ isActive: { $ne: 'false' } }]
      }
    });
    for (let i = 0; i < caveoagents.length; i++) {
      const agent = caveoagents[i];
      const ccUrl = agent.ipAddress + `/${SERVICE_TYPE}/api/v1/caveoscap/fromapi/upload?userToken=` + userToken + '&userId=' + userId + '&orgId=' + orgId + '&fileSize=' + fileSize + '&jobStatusId=' + scanAudit.id;
      logger.info('central collector request:    ' + ccUrl);
      const formData = {
        jovalFile: fs.createReadStream(filePathWithName)
      };
      try {
        logger.info('ccUrl' + ccUrl);
        ScanAudit.create({
          scanType: 'Oval File Upload',
          status: 'Running',
          user_id: userId,
          organization_id: orgId,
          job_id: '-1',
          parent_id: scanAudit.id
        });
        const response = await this.rp.post(ccUrl, { formData, resolveWithFullResponse: true });
        logger.info('central collector response:' + response);
        ScanAudit.create({
          scanType: 'Oval File Upload',
          status: 'Completed',
          user_id: userId,
          organization_id: orgId,
          job_id: '-1',
          parent_id: scanAudit.id
        });
      } catch (error) {
        let statusState = 'Error';
        const statusMessage = error.error;
        if (error.statusCode === 412 || error.statusCode === 409) statusState = 'Info';
        ScanAudit.create({
          scanType: 'Oval File Upload',
          status: statusState,
          user_id: userId,
          organization_id: orgId,
          job_id: '-1',
          parent_id: scanAudit.id,
          message: statusMessage
        });
      }
    }
  }

  async packageUpload(data, userToken, userId, orgId, fileSize, mimeType) {
    const scanAudit = await ScanAudit.create({
      scanType: 'Remote Collector Package File Upload',
      status: 'Started',
      user_id: userId,
      organization_id: orgId,
      job_id: '-1',
      parent_id: 0
    });
    if (!['application/gzip', 'application/x-gzip', 'application/x-tar', 'application/x-gtar', 'application/x-tgz'].includes(mimeType)) {
      ScanAudit.create({
        scanType: 'Remote Collector Package File Upload',
        status: 'Error',
        user_id: userId,
        organization_id: orgId,
        job_id: '-1',
        parent_id: scanAudit.id,
        message: 'Invalid file format. Allowed file extension - .tar.gz'
      });
      const r = new Error('Invalid file format. Allowed file extension - .tar.gz');
      r.status = 400;
      throw r;
    }
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const filePath = '/tmp';
    const finalPath = '/tmp/persistent/rcpackage';
    if (!fs.existsSync(filePath)) fs.mkdirSync(filePath);
    if (!fs.existsSync('/tmp/persistent')) fs.mkdirSync('/tmp/persistent');
    if (!fs.existsSync('/tmp/persistent/rcpackage')) fs.mkdirSync('/tmp/persistent/rcpackage');
    const filePathWithName = `${finalPath}/rcpackage-${Date.now()}.tar.gz`;

    try {
      fs.writeFileSync(filePathWithName, data);
      this.packageUploadtoCentralCollector(userToken, userId, orgId, fileSize, filePathWithName, scanAudit);
      logger.info(`Saved Successfully in ${filePathWithName}`);
      return true;
    } catch (e) {
      ScanAudit.create({
        scanType: 'Remote Collector Package File Upload',
        status: 'Error',
        user_id: userId,
        organization_id: orgId,
        job_id: '-1',
        parent_id: scanAudit.id,
        message: e.message
      });
    }

  }

  async packageUploadtoCentralCollector(userToken, userId, orgId, fileSize, filePathWithName, scanAudit) {
    const activeCCAddress = await CentralCollectorClient.getCentralCollectorAddress();
    if (!activeCCAddress) {
      ScanAudit.create({
        scanType: 'Remote Collector Package File Upload',
        status: 'Error',
        user_id: userId,
        organization_id: orgId,
        job_id: '-1',
        parent_id: scanAudit.id,
        message: 'Central Collector Not Found'
      });
      const err = new Error('Central Collector Not Found');
      err.status = 404;
      throw err;
    }

    const ccUrl = activeCCAddress + '/centralcollector/api/v1/packageupdate/fromapi/upload?userToken=' + userToken + '&userId=' + userId + '&orgId=' + orgId + '&fileSize=' + fileSize + '&jobStatusId=' + scanAudit.id;
    logger.info('central collector request:    ' + ccUrl);
    const formData = {
      rcpackage: fs.createReadStream(filePathWithName)
    };
    try {
      logger.info('ccUrl' + ccUrl);
      ScanAudit.create({
        scanType: 'Remote Collector Package File Upload',
        status: 'Running',
        user_id: userId,
        organization_id: orgId,
        job_id: '-1',
        parent_id: scanAudit.id
      });
      const response = await this.rp.post(ccUrl, { formData, resolveWithFullResponse: true });
      logger.info('central collector response:' + response);
      ScanAudit.create({
        scanType: 'Remote Collector Package File Upload',
        status: 'Completed',
        user_id: userId,
        organization_id: orgId,
        job_id: '-1',
        parent_id: scanAudit.id
      });
    } catch (error) {
      let statusState = 'Error';
      const statusMessage = error.error;
      if (error.statusCode === 412 || error.statusCode === 409) statusState = 'Info';
      ScanAudit.create({
        scanType: 'Remote Collector Package File Upload',
        status: statusState,
        user_id: userId,
        organization_id: orgId,
        job_id: '-1',
        parent_id: scanAudit.id,
        message: statusMessage
      });
    }
    fs.unlinkSync(filePathWithName);
  }

};
