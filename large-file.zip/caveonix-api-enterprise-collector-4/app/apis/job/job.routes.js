const JobController = require('./job.controller');
/**
 * @swagger
 * tags:
 *  - name: Job
 *    description: Job endpoints
 */
module.exports = class JobRoutes {
  constructor(path, router) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.jobController = new JobController();

      // initializing route
      this.initOrganization();
    }
  }

  initOrganization() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/job:
     *   get:
     *     tags:
     *       - Job
     *     summary: Gets a list of jobs
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of jobs
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/`, this.jobController.getAllJobs);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/job/{jobId}/schedule:
     *   delete:
     *     tags:
     *       - Job
     *     summary: Gets a list of scheduled jobs
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: jobId
     *         description: The id of the specified job.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: job
     */
    this.router.get(`${this.path}/:jobId/schedule`, this.jobController.viewScheduledJobs);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/job/schedule/{scheduleTaskId}:
     *   get:
     *     tags:
     *       - Job
     *     summary: Gets a gets a scheduled job
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: scheduleTaskId
     *         description: The scheduled task's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: job
     */
    this.router.get(`${this.path}/:jobId/schedule/:scheduleTaskId`, this.jobController.viewScheduledJob);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/job/{jobId}/schedule:
     *   post:
     *     tags:
     *       - Job
     *     summary: Schedules a job
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: jobId
     *         description: The id of the specified job.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/Job'
     *     responses:
     *       200:
     *         description: job
     */
    this.router.get(`${this.path}/:jobId/schedule`, this.jobController.scheduleJob);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/job/schedule:
     *   delete:
     *     tags:
     *       - Job
     *     summary: Deletes one ore more scheduled jobs
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: id
     *         description: A comma delimited list of job ids
     *         in: query
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: jobs are successfully deleted
     */
    this.router.delete(`${this.path}/schedule`, this.jobController.deleteMultipleJobs);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/job/runNow:
     *   post:
     *     tags:
     *       - Job
     *     summary: Deletes one ore more scheduled jobs
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/Job'
     *     responses:
     *       200:
     *         description: the job has successfully been initiated
     */
    this.router.post(`${this.path}/runNow`, this.jobController.runNow);

    this.router.get(`${this.path}/backup`, this.jobController.getBackupJobs);
    this.router.get(`${this.path}/schedule/list`, this.jobController.getAllJobSchedule);
    this.router.get(`${this.path}/schedule/:scheduleId`, this.jobController.getJob);
    this.router.post(`${this.path}/schedule`, this.jobController.addJob);
    this.router.put(`${this.path}/schedule/:scheduleId`, this.jobController.updateJob);
    this.router.get(`${this.path}/scanTypes`, this.jobController.getAllScanTypes);
    this.router.get(`${this.path}/scanTypes/:scanType`, this.jobController.getScanTypeByName);

  }
};
