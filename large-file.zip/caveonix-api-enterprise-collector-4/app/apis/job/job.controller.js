const { get, has } = require('lodash');

const CentralCollectorClient = require('../../../utils/centralCollector.client');
const checkId = require('../../../utils/checkId');
const checkName = require('../../../utils/checkName');
const cronValidator = require('../../../utils/cronValidator');
const errorHandler = require('../../../utils/errorHandler');
const JobService = require('./job.service');
const jobService = new JobService();
const logger = require('../../../utils/logger').logger;
const paginate = require('../../middlewares/paginate.middleware');
const UserService = require('../user/user.service');
const userService = new UserService();
const Validator = require('../../../utils/validator');

const loggerLabel = 'JobController';

module.exports = class JobController {
  async getAllOrgJobs(req, res) {
    const orgId = req.params.orgId;
    try {
      const jobs = await jobService.getAllJobs(orgId);
      return res.json(jobs);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getAllScanTypes(req, res) {
    const orgId = req.params.orgId;
    //TODO FIX ME: DO NOT COPY THIS APPROACH. not the right approach to creating a handler
    const { selector } = req.query;
    try {
      const scanTypes = selector ? await jobService.getScanTypeByName(selector, orgId) : await jobService.getAllScanTypes();
      if (!scanTypes) {
        logger.error('ScanTypeId not found', {});
        return res.sendStatus(404);
      }
      return res.json(scanTypes);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getScanTypeByName(req, res) {
    const orgId = req.params.orgId;
    const scanType = req.params.scanType;
    try {
      const ScanTypes = await jobService.getScanTypeByName(scanType, orgId);
      logger.silly({ ScanTypes }, 'org');
      if (!ScanTypes) {
        logger.error({ orgId }, 'ScanTypeId not found');
        return res.sendStatus(404);
      }
      return res.json(ScanTypes);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getAllJobs(req, res) {
    const type = has(req, 'query.type') ? req.query.type : 'All';
    const jobs = await jobService.getAllJobs(type);
    return res.json(jobs);
  }

  async getBackupJobs(req, res) {
    try {
      const jobs = await jobService.getBackupJobsJobs();
      return res.json(jobs);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getAllJobsAndScanTypes(req, res) {
    let type = req.query.type;
    if (!type) {
      type = 'All';
    }
    type = type.toLowerCase();
    let scanType = 'All';
    try {
      scanType = scanType.toLowerCase();
      const jobs = await jobService.getAllJobs(type);
      return res.json(jobs);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getAllJobSchedule(req, res) {
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    const orgId = req.params.orgId;
    const backupRestore = req.query.backupRestore;
    const isProvider = req.isProvider || null;
    try {
      const results = await jobService.getAllJobSchedule(orgId, limit, offset, isProvider, backupRestore);
      const itemCount = await jobService.getJobsCount(orgId, backupRestore);
      const pageCount = Math.ceil(itemCount / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        JobSchedule: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getJob(req, res) {
    const orgId = req.params.orgId;
    const backupRestore = req.query.backupRestore;
    const scheduleId = req.params.scheduleId;
    if (checkId(scheduleId)) {
      logger.error({ scheduleId }, 'Error with schedule Id');
      const error = new Error('Error with schedule Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const job = await jobService.getJob(scheduleId, orgId, backupRestore);
      return res.json(job);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async addJob(req, res) {
    const params = req.body;
    params.orgId = params.orgId || req.params.orgId;
    try {
      params.isActive = params.isActive ? params.isActive.toString().toLowerCase() : 'enabled';
      await Validator.validateParams({
        orgId: 'required|integer',
        name: 'required|string',
        type_name: 'required|string',
        typeId: 'required|integer',
        scan_type: 'nullable',
        email: 'nullable',
        applicationId: 'nullable',
        regulation: 'nullable',
        cron_expression: 'required',
        user_id: 'nullable',
        folder: 'nullable',
        clusterName: 'nullable',
        resourcePool: 'nullable',
        dataCenter: 'nullable',
        asset_repo_id: 'nullable',
        type: 'in:applications,sub_applications,folders,resource_pools,clusters,data_centers,vpcs',
        typeValues: 'generalSymbols',
        includeSubResources: 'boolean',
        isActive: 'required|in:enabled,disabled,true'
      }, params);

      if (params.email) {
        const emailArr = params.email;
        const emailCheck = {};
        for (let i = 0; i < emailArr.length; i++) {
          emailCheck.email = emailArr[i];
          await Validator.validateParams({
            email: 'email'
          }, emailCheck);
        }
      }

    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const name = req.body.name;
    const userId = req.user.id;
    const orgId = req.body.orgId;
    const token = req.authInfo;
    const type = params.type_name;
    const typeId = parseInt(params.typeId);
    params.user_id = userId;
    let scheduleJob;
    const createModifyJob = 'Create';
    const userOrgId = req.user.Organizations[0].id;
    if (checkName(name)) {
      const err = new Error('Invalid value for name.');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    if ([37, 3, 15].includes(typeId)) {
      params.flowsPeriod = 24;
    }
    if ((typeId === 37 || typeId === 3 || typeId === 15) && (!params.flowsPeriod || params.flowsPeriod === '')) {
      params.flowsPeriod = 24;
    }
    if (typeId === 37 && params.flowsPeriod > 24) params.flowsPeriod = 24;
    try {
      const job = await jobService.createJob(orgId, name, userId, params);
      scheduleJob = job;
      await jobService.createModifyScheduleJob(scheduleJob, userId, token, userOrgId, createModifyJob, name, type);
      return res.json(job);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async updateJob(req, res) {
    const params = req.body;
    try {
      params.isActive = params.isActive ? params.isActive.toString().toLowerCase() : null;
      await Validator.validateParams({
        orgId: 'required|integer',
        name: 'required|string',
        type_name: 'required|string',
        typeId: 'required|integer',
        scan_type: 'nullable',
        email: 'nullable',
        applicationId: 'nullable',
        regulation: 'nullable',
        cron_expression: 'required',
        user_id: 'nullable',
        folder: 'nullable',
        clusterName: 'nullable',
        resourcePool: 'nullable',
        dataCenter: 'nullable',
        asset_repo_id: 'nullable',
        type: 'in:applications,sub_applications,folders,resource_pools,clusters,data_centers,vpcs',
        typeValues: 'generalSymbols',
        includeSubResources: 'boolean',
        isActive: 'required|in:enabled,disabled'
      }, params);

      if (params.email) {
        const emailArr = params.email;
        const emailCheck = {};
        for (let i = 0; i < emailArr.length; i++) {
          emailCheck.email = emailArr[i];
          await Validator.validateParams({
            email: 'email'
          }, emailCheck);
        }
      }
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const scheduleId = req.params.scheduleId;
    const orgId = req.body.orgId;
    const userOrgId = req.user.Organizations[0].id;
    const isActive = params.isActive;
    const userToken = req.authInfo;
    const userId = req.user.id;
    const type = params.type_name;
    const typeId = parseInt(params.typeId);
    params.user_id = userId;
    let scheduleJob;
    const createModifyJob = 'Modify';
    if (checkId(scheduleId)) {
      logger.error({ scheduleId }, 'Error with Job Id');
      const error = new Error('Bad Job Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    if ((typeId === 37 || typeId === 3 || typeId === 15) && (!params.flowsPeriod || params.flowsPeriod === '')) {
      params.flowsPeriod = 24;
    }
    if (typeId === 37 && params.flowsPeriod > 24) params.flowsPeriod = 24;
    const name = req.body.name;
    if (checkName(name)) {
      const err = new Error('Invalid value for name.');
      err.status = 400;
      throw err;
    }
    try {
      const update = await jobService.updateJob(orgId, scheduleId, params);
      scheduleJob = update;
      logger.info({ scheduleId }, 'update');

      if (isActive === 'disabled') {
        await jobService.createModifyScheduleJob(scheduleJob, userId, userToken, userOrgId, 'unSchedule', name, type);
      } else {
        await jobService.createModifyScheduleJob(scheduleJob, userId, userToken, userOrgId, createModifyJob, name, type);
      }
      return res.json(update);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async viewScheduledJob(req, res) {
    const jobId = req.params.jobId;
    const scheduleTaskId = req.params.scheduleTaskId;
    try {
      const scheduleTasks = await jobService.viewScheduledJob(jobId, scheduleTaskId);
      return res.json(scheduleTasks);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async viewScheduledJobs(req, res) {
    const jobId = req.params.jobId;
    try {
      const scheduleTasks = await jobService.viewScheduledJobs(jobId);
      return res.json(scheduleTasks);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async scheduleJob(req, res) {
    const jobId = req.params.jobId;
    const username = req.body.username;
    const keyFile = req.body.keyFile;
    const hostname = req.body.hostName;
    const port = req.body.port;
    const cronExpression = req.body.cronExpression;
    try {
      cronValidator(cronExpression);
      const scheduleTask = await jobService
        .scheduleJob(jobId, username, keyFile, hostname, port, cronExpression);
      return res.json(scheduleTask);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async startvCenterExtract(req, res) {
    const params = req.body;
    if (Object.keys(params).length === 0) {
      logger.error({ params }, 'Invalid Parameters For vCenter Extract');
      const error = new Error('Invalid Parameters For vCenter Extract');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      await jobService.startvCenterExtract(params);
      return res.send('vCenter Extract Scan started');
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async startVCDExtract(req, res) {
    const params = req.body;
    if (Object.keys(params).length === 0) {
      logger.error({ params }, 'Invalid Parameters For VCD Extract');
      const error = new Error('Invalid Parameters For VCD Extract');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const status = await jobService.startVCDExtract(params);
      logger.info(status, 'statusCode');
      return res.send('VCD Extract Scan started');
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async startOrgAssetScan(req, res) {
    const params = req.body;
    if (Object.keys(params).length === 0) {
      logger.error({ params }, 'Invalid Parameters For Org Asset Scan');
      const error = new Error('Invalid Parameters For Org Asset Scan');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const status = await jobService.startOrgAssetScan(params);
      logger.info(status, 'statusCode');
      return res.send('Org Asset Scan started');
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async runNow(req, res) {
    const params = req.body;
    let regulation, applicationId, email, ccUrl;
    const userToken = req.authInfo;
    const userId = req.user.id;
    const typeId = parseInt(params.typeId);
    let orgId = params.orgId || req.params.orgId;
    orgId = parseInt(orgId);
    const { assetRepoId } = req.body;
    const scheduleId = params.scheduleId;
    // scan validations
    if (Object.keys(params).length === 0) {
      const err = new Error('Invalid Parameters For Org Asset Scan');
      err.status = 400;
      return errorHandler(req, res, err);
    }

    if (!await userService.checkUserSession(orgId, userId, userToken)) {
      await userService.addUserSessionForMspUser({ orgId, userId, userToken });
    }

    const centralCollectorConnectionNotCheckList = [19, 18, 17, 16];
    if (!centralCollectorConnectionNotCheckList.includes(typeId)) {
      ccUrl = await CentralCollectorClient.CentralCollectorConnectionCheck();
      if (!ccUrl) {
        const err = new Error('There is no Central Collector available. Please contact your Caveonix Administrator');
        err.status = 400;
        return errorHandler(req, res, err);
      }
    }
    switch (typeId) {
      case 1: { //'vcenter asset extract'

        try {
          await jobService.startvCenterExtract(ccUrl, params, userToken, userId, orgId, scheduleId, assetRepoId);
          return res.json({ Status: 'vCenter Extract started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 2: { // 'vcd asset extract'
        try {
          await jobService.startVCDExtract(ccUrl, params, userToken, userId, orgId, scheduleId, assetRepoId);
          return res.json({ Status: 'VCD Extract started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 5: { // 'asset scan'
        const scanType = params.scanType;
        if (!scanType) {
          logger.info('Invalid Parameters For Org Asset Scan');
          const err = new Error('Invalid Parameters For Org Asset Scan');
          err.status = 400;
          return errorHandler(req, res, err);
        }
        try {
          if (!await jobService.checkRemoteAccess(params)) {
            const err = new Error('Failed to get necessary asset remote details or asset details');
            err.status = 400;
            return errorHandler(req, res, err);
          }
          await jobService.startOrgAssetScan(ccUrl, params, userToken, userId, orgId, scheduleId, assetRepoId);
          return res.json({ Status: 'Org Asset Scan started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 3: // 'nsx-v extract'
      case 15: { // 'nsx-t extract'
        params.nsxType = 'NSX-V';
        if (params.scanType && (typeId === 3)) {
          // -- normalize scantype from ui to match required values for api
          const topologyUiScanTypes = ['nsx-v ipfix topology collection'];
          const flowUiScanTypes = ['nsx-v flow collection'];
          if (params.scanType.toLowerCase().includes(topologyUiScanTypes) && params.scanType.toLowerCase().includes(flowUiScanTypes)) {
            params.scanType = 'all';
          } else if (topologyUiScanTypes.includes(params.scanType.toLowerCase())) {
            params.scanType = 'topology';
          } else if (flowUiScanTypes.includes(params.scanType.toLowerCase())) {
            params.scanType = 'flows';
          }
        }
        if (typeId === 15) {
          params.nsxType = 'NSX-T';
        }
        try {
          await jobService.startNSXScan(ccUrl, params, userToken, userId, orgId, scheduleId, assetRepoId);
          return res.json({ Status: 'NSX Extract started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 6: { // 'software extract'
        try {
          if (!await jobService.checkRemoteAccess(params)) {
            const err = new Error('Failed to get necessary asset remote details or asset details');
            err.status = 400;
            return errorHandler(req, res, err);
          }
          await jobService.startSoftwareExtract(ccUrl, params, userToken, userId, orgId, scheduleId, assetRepoId);
          return res.json({ Status: 'Software Extract started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 7: { // 'log extract'
        try {
          if (!await jobService.checkRemoteAccess(params)) {
            const err = new Error('Failed to get necessary asset remote details or asset details');
            err.status = 400;
            return errorHandler(req, res, err);
          }
          ccUrl = await CentralCollectorClient.CentralCollectorConnectionCheck();
          await jobService.startLogExtract(ccUrl, params, userToken, userId, orgId, scheduleId, assetRepoId);
          return res.json({ Status: 'Log Extract started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 8: { // 'amqp'
        try {
          await jobService.startAMQPExtract(ccUrl, params, userToken, userId, orgId, scheduleId, assetRepoId);
          return res.json({ Status: 'AMQP Extract started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 10: { // 'vmware infrastructure scan'
        const repoId = params.assetRepoId;
        if (!repoId) {
          logger.info('Invalid Parameters For VMWare Infrastructure Scan');
          const err = new Error('Invalid Parameters For VMWare Infrastructure Scan');
          err.status = 400;
          return errorHandler(req, res, err);
        }
        try {
          await jobService.startVMWareScan(ccUrl, params, userToken, userId, orgId, scheduleId, assetRepoId);
          return res.json({ Status: 'VMWare Infrastructure Scan started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 12: { // 'watcherRequest'
        try {
          await jobService.startWatcherRequest(ccUrl, params, userToken, userId);
          return res.json({ Status: 'watcherRequest' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 11: { // 'vmware vulnerability scan'
        const repoId = params.assetRepoId;
        if (!repoId) {
          logger.info('Invalid Parameters For VMWare Vulnerability Scan');
          const err = new Error('Invalid Parameters For VMWare Vulnerability Scan');
          err.status = 400;
          return errorHandler(req, res, err);
        }
        try {
          await jobService.startVMWareVulnerabilityScan(ccUrl, params, userToken, userId, orgId, scheduleId, assetRepoId);
          return res.json({ Status: 'VMWare Vulnerability Scan started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 21: { // 'kubernetes asset extract'
        try {
          await jobService.startContainerExtract(ccUrl, params, userToken, userId, orgId, scheduleId, assetRepoId);
          return res.json({ Status: 'Container Extract started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 24: { // 'kubernetes infrastructure compliance scan'
        try {
          await jobService.startContainerCompliance(ccUrl, params, userToken, userId, orgId, scheduleId, assetRepoId);
          return res.json({ Status: 'Kubernetes Infrastructure Compliance scan started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 31: { // 'kubernetes infrastructure vulnerability scan'
        try {
          await jobService.startKubernetesVulnerability(ccUrl, params, userToken, userId, orgId, scheduleId, assetRepoId);
          return res.json({ Status: 'Kubernetes infrastructure vulnerability scan started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }

      case 22: { // 'openstack asset extract'
        try {
          await jobService.startOpenSackExtract(ccUrl, params, userToken, userId, orgId, scheduleId, assetRepoId);
          return res.json({ Status: 'OpenStack Extract started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 39: { // 'openshift asset extract'
        try {
          await jobService.startOpenShiftExtract(ccUrl, params, userToken, userId, orgId, scheduleId, assetRepoId);
          return res.json({ Status: 'OpenShift Extract started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 23: { // 'openstack compliance'
        try {
          await jobService.startOpenSackCompliance(ccUrl, params, userToken, userId, orgId, scheduleId, assetRepoId);
          return res.json({ Status: 'VMWare OpenStack Compliance scan started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 30: { // 'openstack vulnerability'
        try {
          await jobService.startOpenSackVulnerability(ccUrl, params, userToken, userId, orgId, scheduleId, assetRepoId);
          return res.json({ Status: 'VMWare OpenStack vulnerability scan started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 14: { // 'get latest vulnerabilities'
        try {
          const status = await jobService.loadNVDFiles();
          logger.info(status, 'statusCode');
          return res.json({ Status: 'Loaded Recent and Modified files into ES' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 16: { // 'audit report'
        regulation = params.regulation;
        applicationId = params.applicationId;
        email = params.email;
        try {
          const status = await jobService.createAuditReport(orgId, userToken, regulation, applicationId, email, type);
          logger.info(status, 'statusCode');
          return res.json({ Status: 'Audit Report Created' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 17: { // 'compliance report'
        regulation = params.regulation;
        email = params.email;
        try {
          const status = await jobService.createAuditReport(orgId, userToken, regulation, null, email, type);
          return res.json({ Status: 'Compliance Report Created' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 18: { // 'cyber risk report'
        email = params.email;
        try {
          const status = await jobService.createAuditReport(orgId, userToken, null, null, email, type);
          return res.json({ Status: 'Cyber Risk Report Created' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 19: { // 'compliance delta report'
        regulation = params.regulation;
        email = params.email;
        try {
          const status = await jobService.createAuditReport(orgId, userToken, regulation, null, email, type);
          logger.info(status, 'statusCode');
          return res.json({ Status: 'Compliance Delta Report Created' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 20: { // 'cyber risk delta report'
        email = params.email;
        try {
          const status = await jobService.createAuditReport(orgId, userToken, null, null, email, type);
          logger.info(status, 'statusCode');
          return res.json({ Status: 'Cyber Risk Delta Report Created' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 35: { // 'aws sqs extract - ec2'
        try {
          const extract = await jobService.startAWSSQSExtract(ccUrl, params, userToken, userId, scheduleId, assetRepoId);
          const statusCode = get(extract, 'statusCode');
          res.status(statusCode);
          const status = statusCode === 200 || statusCode === 202 ? 'AWS SQS Extract EC2 started' : get(extract, 'body');
          return res.json({ status, statusCode });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 25: { // 'aws asset extract'
        try {
          await jobService.startAWSExtract(ccUrl, params, userToken, userId, scheduleId, assetRepoId);
          return res.json({ Status: 'AWS Extract started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 36: { // 'aws s3 configuration extract'
        try {
          await jobService.startS3Extract(ccUrl, params, userToken, userId, scheduleId, assetRepoId);
          return res.json({ Status: 's3 Extract started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 37: { // 'aws cloudtrail extract'
        try {
          await jobService.startCloudtrailExtract(ccUrl, params, userToken, userId, scheduleId, assetRepoId);
          return res.json({ Status: 'Cloudtrail Extract started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 26: { // 'aws netflow extract'
        try {
          await jobService.startAWSNetflowExtract(ccUrl, params, userToken, userId, scheduleId, assetRepoId);
          return res.json({ Status: 'Netflow Extract started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 29: { // 'aws infrastructure compliance'
        try {
          await jobService.startAWSComplianceScan(ccUrl, params, userToken, userId, scheduleId, assetRepoId);
          return res.json({ Status: 'AWS infrastructure compliance scan started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 43: { // 'aws security hub sqs extract'
        try {
          await jobService.startAWSSecurityHubExtract(ccUrl, params, userToken, userId, scheduleId, assetRepoId);
          return res.json({ Status: 'AWS Security Hub extract started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 44: { // 'aws services extract'
        try {
          await jobService.startAWSServicesExtract(ccUrl, params, userToken, userId, scheduleId, assetRepoId);
          return res.json({ Status: 'AWS services extract started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 45: { // 'aws cis compliance scan'
        try {
          await jobService.startAWSCISCompliance(ccUrl, params, userToken, userId, scheduleId, assetRepoId);
          return res.json({ Status: 'AWS CIS Compliance started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 27: { //'azure asset extract'
        try {
          await jobService.startAzureAssetExtract(ccUrl, params, userToken, userId, scheduleId, assetRepoId);
          return res.json({ Status: 'Azure Extract started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 28: { // 'azure netflow extract'
        try {
          await jobService.startAzureNetflowExtract(ccUrl, params, userToken, userId, scheduleId, assetRepoId);
          return res.json({ Status: 'Azure Netflow Extract started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 49: { // 'azure services extract'
        try {
          await jobService.startAzureServicesExtract(ccUrl, params, userToken, userId, scheduleId, assetRepoId);
          return res.json({ Status: 'Azure Services Extract Started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 50: { // 'azure cis compliance scan'
        try {
          await jobService.startAzureInfrastructureScan(ccUrl, params, userToken, userId, scheduleId, assetRepoId);
          return res.json({ Status: 'Azure CIS Scan Started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 46: { // 'gcp asset extract'
        try {
          await jobService.startGCPAssetExtract(ccUrl, params, userToken, userId, scheduleId, assetRepoId);
          return res.json({ Status: 'GCP Extract started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 47: { // 'gcp services extract'
        try {
          await jobService.startGCPServicesExtract(ccUrl, params, userToken, userId, scheduleId, assetRepoId);
          return res.json({ Status: 'GCP Services Extract Started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 48: { // 'gcp cis compliance scan'
        try {
          await jobService.startGCPInfrastructureScan(ccUrl, params, userToken, userId, scheduleId, assetRepoId);
          return res.json({ Status: 'GCP CIS Scan Started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 54: { // 'gcp netflow extract'
        try {
          await jobService.startGCPNetflowExtract(ccUrl, params, userToken, userId, scheduleId, assetRepoId);
          return res.json({ Status: 'GCP Netflow Extract started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 51: { // 'hytrust infrastructure scan'
        try {
          await jobService.startHytrustInfrastructureScan(ccUrl, params, userToken, userId, scheduleId, assetRepoId);
          return res.json({ Status: 'Hytrust Infrastructure Scan Started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 52: { // 'hytrust syslog extract'
        try {
          await jobService.startHytrustSyslogExtract(ccUrl, params, userToken, userId, scheduleId, assetRepoId);
          return res.json({ Status: 'Hytrust Syslog Extract Started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 32: { // 'vmc asset extract'
        try {
          await jobService.startVmcAssetExtract(ccUrl, params, userToken, userId, orgId, scheduleId, assetRepoId);
          return res.json({ Status: 'vmc asset extract started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 33: { // 'vmc topology'
        try {
          await jobService.startVmcTopologyScan(ccUrl, params, userToken, userId, orgId, scheduleId, assetRepoId);
          return res.json({ Status: 'vmc topology extract started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 38: { // 'oval files extract'
        try {
          await jobService.startOvalExtract(ccUrl, params, userToken, userId, orgId, scheduleId, assetRepoId);
          return res.json({ Status: 'oval files extract started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 64: { // 'AKS Asset Extract'
        try {
          await jobService.startAKSAssetExtract(ccUrl, params, userToken, userId, scheduleId, assetRepoId);
          return res.json({ Status: 'AKS Asset extract started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 65: { // 'EKS Asset Extract'
        try {
          await jobService.startEKSAssetExtract(ccUrl, params, userToken, userId, scheduleId, assetRepoId);
          return res.json({ Status: 'EKS Asset extract started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      case 66: { // 'GKE Asset Extract'
        try {
          await jobService.startGKEAssetExtract(ccUrl, params, userToken, userId, scheduleId, assetRepoId);
          return res.json({ Status: 'GKE Asset extract started' });
        } catch (error) {
          logger.error('unable to run job', { error, loggerLabel });
          return errorHandler(req, res, error);
        }
        break;
      }
      default: {
        logger.info(`Job type Id ${typeId} not found`);
        const err = new Error(`Job type ${typeId} not found`);
        err.status = 400;
        return errorHandler(req, res, err);
      }
    }
  }

  async showLicense(req, res) {
    try {
      const licenseInfo = await CentralCollectorClient.getLicenseInfo();
      return res.json(licenseInfo);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async currentUsage(req, res) {
    try {
      const currentUsage = await CentralCollectorClient.getCurrentUsage();
      res.json({ currentUsage });
    } catch (error) {
      error.status = error.status || 503;
      error.message = error.message || 'service unavailable';
      return errorHandler(req, res, error);
    }
  }

  async deleteMultipleJobs(req, res) {
    const userToken = req.authInfo;
    const userId = req.user.id;
    const userOrgId = req.user.Organizations[0].id;
    let output = [];
    let scheduleJob;
    let type;
    let name = '';
    const createModifyJob = 'Delete';
    const scheduleIdList = req.query.id.split(',');

    try {
      const update = await jobService.deleteMultipleSchedulesById(scheduleIdList);
      output = update;
      logger.info({ update }, 'Update');
      output.forEach(function (object) {
        scheduleJob = object;
        name = object.name;
        type = object.Job.name;
        jobService.createModifyScheduleJob(scheduleJob, userId, userToken, userOrgId, createModifyJob, name, type);
      });
      return res.json(update);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async startRelationalDatastoreBackup(req, res) {
    const params = req.body;
    let ccUrl;
    const userToken = req.authInfo;
    const userId = req.user.id;
    const orgId = params.orgId;
    if (!userToken || !userId) {
      logger.info('Invalid Parameters For Relational DatastoreRestore Backup');
      const err = new Error('Invalid Parameters ForRelational DatastoreRestore Backup');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    if ((!orgId && !orgId === 0) || orgId == null) {
      logger.info('Invalid Parameters For Relational DatastoreRestore Backup');
      const err = new Error('Invalid Parameters For Relational DatastoreRestore Backup');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    try {
      ccUrl = await CentralCollectorClient.CentralCollectorConnectionCheck();
      if (!ccUrl) {
        const error = new Error('No Central Collector Available. Please Contact your Caveonix Administrator');
        error.status = 400;
        throw error;
      }
      await jobService.startRelationalDatastoreBackup(ccUrl, params, userToken, userId);
      return res.json({ Status: 'Relational DatastoreRestore Backup started' });
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async startRelationalDatastoreRestore(req, res) {
    const params = req.body;
    let ccUrl;
    const userToken = req.authInfo;
    const userId = req.user.id;
    const orgId = params.orgId;
    if (!userToken || !userId) {
      logger.info('Invalid Parameters For Relational DatastoreRestore Restore');
      const err = new Error('Invalid Parameters For Relational DatastoreRestore Restore');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    if ((!orgId && !orgId === 0) || orgId == null) {
      logger.info('Invalid Parameters For Software Extract');
      const err = new Error('Invalid Parameters For Relational DatastoreRestore Restore');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    try {
      ccUrl = await CentralCollectorClient.CentralCollectorConnectionCheck();
      if (!ccUrl) {
        const error = new Error('No Central Collector Available. Please Contact your Caveonix Administrator');
        error.status = 400;
        throw error;
      }
      await jobService.startRelationalDatastoreRestore(ccUrl, params, userToken, userId);
      return res.json({ Status: 'Relational DatastoreRestore Restore started' });
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async startRelationalDatastoreDeleteBackup(req, res) {
    const params = req.body;
    let ccUrl;
    const userToken = req.authInfo;
    const userId = req.user.id;
    try {
      await Validator.validateParams({
        body: 'required|array',
        'body.*.orgId': 'required|integer',
        'body.*.backupRetentionPeriod': 'required|integer',
        'body.*.jobId': 'required|integer',
        'body.*.liveDataPeriod': 'required|integer'
      }, req,
      {
        'body.*.orgId': 'Invalid Org Id',
        'body.*.backupRetentionPeriod': 'Invalid Backup Retention Period',
        'body.*.jobId': 'Invalid jobId',
        'body.*.liveDataPeriod': 'Invalid live DataPeriod Period'
      });

    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    if (!userToken || !userId) {
      logger.info('Invalid Parameters For Relational DatastoreRestore Backup');
      const err = new Error('Invalid Parameters ForRelational DatastoreRestore Backup Delete');
      err.status = 400;
      return errorHandler(req, res, err);
    }
    try {
      ccUrl = await CentralCollectorClient.CentralCollectorConnectionCheck();
      if (!ccUrl) {
        const error = new Error('No Central Collector Available. Please Contact your Caveonix Administrator');
        error.status = 400;
        throw error;
      }
      /*
      jobService.startRElationalDatastoreDeleteBAckup returns a promise. so the params.map function returns an array of Promises.
      Promise.all then waits for all promises in the array and returns a single promise with an array of the results. we await the Promise.all
      and therefore we wait for all functionality to finish before saying the job has started
       */
      await Promise.all(params.map(p => jobService.startRelationalDatastoreDeleteBackup(ccUrl, p, userToken, userId)));
      return res.json({ Status: 'Relational DatastoreRestore Backup Delete started' });

    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async loadNVDFiles(req, res) {
    try {
      const status = await jobService.loadNVDFiles();
      logger.info(status, 'statusCode');
      return res.send('Loaded Recent and Modified files into ES');
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async ovalUpload(req, res) {
    try {
      if (!req.files.ovalFile) {
        const err = new Error('Missing Ovalfile for upload');
        err.status = 400;
        return errorHandler(req, res, err);
      }
      var ovalFile = req.files.ovalFile[0].buffer;
      const file = req.files.ovalFile[0];
      const orgId = req.user.Organizations[0].id;
      const userToken = req.authInfo;
      const userId = req.user.id;
      await jobService.ovalUpload(ovalFile, userToken, userId, orgId, file.size, file.mimetype);
      return res.json({ status: 'Upload Success' });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async packageUpload(req, res) {
    try {
      if (!req.files || !req.files.packageFile) {
        const err = new Error('Missing Remote Collector Package for upload');
        err.status = 400;
        return errorHandler(req, res, err);
      }
      var packageFile = req.files.packageFile[0].buffer;
      const file = req.files.packageFile[0];
      const orgId = req.user.Organizations[0].id;
      const userToken = req.authInfo;
      const userId = req.user.id;
      await jobService.packageUpload(packageFile, userToken, userId, orgId, file.size, file.mimetype);
      return res.json({ status: 'Upload Success' });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

};
