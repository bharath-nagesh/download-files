const Sequelize = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();

/**
 * @swagger
 * components:
 *   schemas:
 *     GCPRegions:
 *       type: object
 *       properties:
 *         name:
 *           type: string
 *         fullName:
 *           type: string
 * @param sequelize
 */
const GCPRegions = sequelize.define(
  'gcpRegions',
  {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    name: { type: Sequelize.STRING, field: 'name' },
    fullName: { type: Sequelize.STRING, field: 'full_name' }
  },
  { timestamps: false, freezeTableName: true, tableName: 'gcp_regions', underscored: true }
);

module.exports = GCPRegions;
