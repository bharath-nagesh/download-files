const GCPService = require('./gcp.service');
const errorHandler = require('../../../utils/errorHandler');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-gcp.controller'
});
const paginate = require('../../middlewares/paginate.middleware');
const gcpService = new GCPService();

module.exports = class GCPController {

  async getAllGCPRegions(req, res) {
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    try {
      const results = await gcpService.getAllGCPRegions(limit, offset);
      const itemCount = await gcpService.getAllGCPRegionsCount();
      const pageCount = Math.ceil(itemCount / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        GCPRegions: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

};
