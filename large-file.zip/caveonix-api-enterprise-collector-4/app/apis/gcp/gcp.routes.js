const GCPController = require('./gcp.controller');

/**
 * @swagger
 * tags:
 *  - name: GCP VPC
 *    description: GCP VPC endpoints
 */
module.exports = class GCPRoutes {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.gcpController = new GCPController();
      this.initOrganization();

    }
  }

  initOrganization() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/gcp/region:
     *   get:
     *     tags:
     *       - GCP VPC
     *     summary: Gets a list of all GCP Regions
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of regions
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/region`, this.gcpController.getAllGCPRegions);

  }
};
