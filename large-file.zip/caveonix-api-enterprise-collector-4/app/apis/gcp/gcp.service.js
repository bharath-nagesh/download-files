const GCPRegions = require('./gcpRegions.model');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-gcpService.service'
});

/**
 * GCP Service that handles all of the queries to the database
 * @type {GCPService}
 */
module.exports = class GCPService {

  getAllGCPRegions(limit, offset) {
    return GCPRegions.findAll(
      { order: [['name', 'ASC']], limit: limit, offset: offset });
  }

  getAllGCPRegionsCount() {
    return GCPRegions.count({});
  }

};
