const ActiveDirectoryService = require('./activeDirectory.service');
const activeDirectoryService = new ActiveDirectoryService();
const config = require('../../../configure').get();
const checkId = require('../../../utils/checkId');
const errorHandler = require('../../../utils/errorHandler');
const Validator = require('../../../utils/validator');
const KibanaUserRolesService = require('../kibanaUserRoles/kibanaUserRoles.service');
const kibanaUserRolesService = new KibanaUserRolesService();
const RoleService = require('../roles/role.service');
const roleService = new RoleService();
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'activeDirectory.controller'
});
const paginate = require('../../middlewares/paginate.middleware');
const UserService = require('../user/user.service');
const userService = new UserService();
module.exports = class ActiveDirectoryController {

  async getActiveDirectoryById(req, res) {
    const activeDirectoryId = req.params.activeDirectoryId;
    const orgId = req.params.orgId;
    if (checkId(activeDirectoryId)) {
      logger.error({ activeDirectoryId }, 'Error with ActiveDirectory Id');
      const error = new Error('Error with ActiveDirectory Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const activeDirectory = await activeDirectoryService.getActiveDirectoryById(orgId, activeDirectoryId);
      return res.json(activeDirectory);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async deleteActiveDirectory(req, res) {
    const orgId = req.params.orgId;
    const activeDirectoryId = req.params.activeDirectoryId;
    try {
      const activeDirectory = await activeDirectoryService.deleteActiveDirectoryById(orgId, activeDirectoryId);
      return res.json(activeDirectory);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async deleteMultipleActiveDirectories(req, res) {
    const orgId = req.params.orgId;
    let activeDirectoryIdList = req.query.id || '';
    activeDirectoryIdList = activeDirectoryIdList.split(',');
    const adResponse = { data: [], error: [] };
    try {
      for (let a = 0; a < activeDirectoryIdList.length; a++) {
        const activeDirectoryId = activeDirectoryIdList[a];
        try {
          await activeDirectoryService.deleteActiveDirectoryById(orgId, activeDirectoryId);
          adResponse.data.push({ id: activeDirectoryId, message: 'Deletion Successful' });
        } catch (error) {
          if (error.message.includes('Cannot')) {
            adResponse.error.push({
              id: activeDirectoryId,
              message: error.message,
              connectionName: error.connectionName
            });
          }
        }
      }
      if (adResponse.error.length > 0 && adResponse.data.length != 0) res.status(207);
      if (adResponse.error.length > 0 && adResponse.data.length == 0) res.status(400);
      return res.send(adResponse);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getActiveDirectory(req, res) {
    const orgId = req.params.orgId;
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    try {
      const results = await activeDirectoryService.getAllActiveDirectory(orgId, limit, offset);
      const itemCount = await activeDirectoryService.getAllActiveDirectory(orgId);
      const pageCount = Math.ceil(itemCount.length / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount.length,
        page_number: pageNumber,
        activeDirectory: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async createActiveDirectory(req, res) {
    const params = req.body;
    try {
      params.isActive = params.isActive ? params.isActive.toString().toLowerCase() : 'enabled';
      await Validator.validateParams({
        key: 'nullable',
        connectionName: 'required|string',
        username: 'required|string',
        password: 'required|string',
        baseDN: 'nullable',
        type_id: 'required|integer',
        sourceId: 'nullable',
        location_id: 'required|integer',
        hosting_provider_id: 'required|integer',
        isActive: 'required|in:enabled,disabled,true'
      }, params);

      const urlParts = require('url').parse(params.connectionName, true);
      urlParts.protocol = urlParts.protocol ? urlParts.protocol.slice(0, -1) : 'ldap';
      urlParts.hostname = urlParts.hostname ? urlParts.hostname : urlParts.pathname;
      urlParts.port = urlParts.port ? urlParts.port : '389';
      urlParts.connectionName = `${urlParts.protocol}://${urlParts.hostname}:${urlParts.port}`;
      await Validator.validateParams({
        protocol: 'required|in:ldap,ldaps',
        hostname: 'required|string'
      }, urlParts,
      {
        protocol: 'Invalid Active Directory protocol (e.g. ldap://ds.example.com:389)',
        hostname: 'Invalid Active Directory hostname (e.g. ldap://ds.example.com:389)'
      });
      params.connectionName = urlParts.connectionName;
      params.port = urlParts.port;
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const orgId = req.params.orgId;
    try {
      const activeDirectoryService = new ActiveDirectoryService();
      const activeDirectory = await activeDirectoryService.createActiveDirectory(orgId, params, req, res);
      return res.json(activeDirectory);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async updateActiveDirectory(req, res) {
    const params = req.body;
    try {
      params.isActive = params.isActive ? params.isActive.toString().toLowerCase() : null;
      await Validator.validateParams({
        key: 'nullable',
        connectionName: 'required|string',
        username: 'required|string',
        password: 'nullable',
        baseDN: 'nullable',
        type_id: 'required|integer',
        sourceId: 'nullable',
        location_id: 'required|integer',
        hosting_provider_id: 'required|integer',
        isActive: 'required|in:enabled,disabled'
      }, params);

      const urlParts = require('url').parse(params.connectionName, true);
      urlParts.protocol = urlParts.protocol ? urlParts.protocol.slice(0, -1) : 'ldap';
      urlParts.hostname = urlParts.hostname ? urlParts.hostname : urlParts.pathname;
      urlParts.port = urlParts.port ? urlParts.port : '389';
      urlParts.connectionName = `${urlParts.protocol}://${urlParts.hostname}:${urlParts.port}`;
      await Validator.validateParams({
        protocol: 'required|in:ldap,ldaps',
        hostname: 'required|string'
      }, urlParts,
      {
        protocol: 'Invalid Active Directory protocol (e.g. ldap://ds.example.com:389)',
        hostname: 'Invalid Active Directory hostname (e.g. ldap://ds.example.com:389)'
      });
      params.connectionName = urlParts.connectionName;
      params.port = urlParts.port;

      await Validator.validateParams({
        activeDirectoryId: 'required|integer'
      }, req.params, { activeDirectoryId: 'Error with ActiveDirectory Id' });

    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const orgId = req.params.orgId;

    try {
      const activeDirectoryId = req.params.activeDirectoryId;
      const activeDirectory = await activeDirectoryService.updateActiveDirectory(orgId, activeDirectoryId, params, req, res);
      return res.json(activeDirectory);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async getActiveDirectoryUsers(req, res) {

    try {
      await Validator.validateParams({
        activeDirectoryId: 'required|integer'
      }, req.params, { activeDirectoryId: 'Error with ActiveDirectory Id' });

    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    try {
      const filter = req.query.filter || null;
      const desiredPage = req.query.desiredPage || 1;
      const activeDirectoryId = req.params.activeDirectoryId;
      const activeDirectory = await activeDirectoryService.getActiveDirectoryUsers(activeDirectoryId, desiredPage, filter);
      return res.json(activeDirectory);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async activeDirectoryTestConnection(req, res) {
    const params = req.body;
    try {
      await Validator.validateParams({
        connectionName: 'required|string',
        key: 'nullable',
        username: 'required|string',
        password: 'required|string'
      }, params);

    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    try {
      const activeDirectory = await activeDirectoryService.activeDirectoryTestConnection(params);
      return res.json(activeDirectory);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }

  async createADUser(req, res) {
    const userArray = req.body;
    const newAr = { data: userArray };
    try {
      await Validator.validateParams({
        data: 'required|array',
        'data.*.username': 'required|string',
        'data.*.firstName': 'nullable',
        'data.*.lastName': 'nullable',
        'data.*.role_id': 'required|integer',
        'data.*.organization_id': 'required|integer',
        'data.*.activeDirectoryId': 'required|integer',
        'data.*.isActive': 'required|in:enabled,disabled,true'
      }, newAr);

      await Validator.validateParams({
        orgId: 'required|integer'
      }, req.params, { orgId: 'The organization id in url params in invalid' });

    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const newUserArray = { data: [], error: [] };
    for (let u = 0; u < userArray.length; u++) {
      const params = userArray[u];
      const username = params.username;
      const pw = 'not valid';
      const firstname = params.firstName;
      const lastname = params.lastName;
      const roleId = params.role_id;
      const organizationId = params.organization_id;
      const orgId = req.params.orgId;
      const update = {};
      try {
        const user = await userService.createUser(username, pw, firstname, lastname, roleId, organizationId, params, false);
        newUserArray.data.push(user);
        update.username = username;
        update.fullname = firstname + lastname;
        update.email = username;
        update.password = pw;
        if (config.forensics_enabled === false || config.ml_enabled === true) {
          const roleInfo = await roleService.getRole(params.role_id, orgId, '');
          if (roleInfo.name.toLowerCase() === ('msp_owner') || roleInfo.name.toLowerCase() === ('mssp_owner')) {
            kibanaUserRolesService.createRolesForMspAndMsspUsers(params.assigned_org_ids, update);
          } else {
            kibanaUserRolesService.createUserRoles(orgId, update, 'all');
          }
        }
      } catch (error) {
        if (error.message.includes('Duplicate Username.')) {
          newUserArray.error.push({ email: params.username, message: 'Duplicate username address' });
          continue;
        }
        return errorHandler(req, res, error);
      }
    }
    if (newUserArray.error.length > 0) res.status(207);
    return res.json(newUserArray);
  }

  async getActiveDirectoryTypes(req, res) {
    try {
      const results = await activeDirectoryService.getADAssetRepoEndpointTypes();
      return res.json({
        activeDirectoryType: results
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }
};
