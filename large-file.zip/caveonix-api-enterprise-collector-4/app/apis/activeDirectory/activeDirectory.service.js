const ActiveDirectory = require('@caveonix/activedirectory');

const AssetRepoEndpointService = require('../assetRepoEndpoint/assetRepoEndpoint.service');
const assetRepoEndpointService = new AssetRepoEndpointService();
const AssetRepoEndpoint = require('../assetRepoEndpoint/assetRepoEndpoint.model');
const AssetRepoType = require('../assetRepoEndpoint/assetRepoType.model');
const Organization = require('../organization/organization.model');
const OrgMembers = require('../../apis/organization/orgMembers.model');
const KeyGenerator = require('../../../utils/generateKeys');
const User = require('../user/user.model');
const ActiveDirectoryLdap = require('./activeDirectoryLdap.service');
const config = require('../../../configure').get();
const util = require('util');
util.promisify(ActiveDirectory);
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'activeDirectory.service'
});
const removeSpace = require('../../../utils/checkSpaces');

module.exports = class ActiveDirectoryService {
  constructor() {
    this.keyGenerator = new KeyGenerator();
    logger.debug('called ActiveDirectoryService constructor');
  }

  async createActiveDirectory(orgId, params, req, res) {

    if(!params.username.includes('@')){
      const error = new Error('Active Directory Username supported format is username@domain');
      error.status = 400;
      throw error;
    }

    const connName = params.connectionName;
    const typeId = params.type_id;
    const user = params.username;
    let password = params.password;
    const newConnName = removeSpace.checkMultiSpace(connName);
    const newUserName = removeSpace.removeAllSpaces(user);
    password = await this.keyGenerator.generateKeys(password, '');
    params.username = newUserName;
    params.password = password;
    params.connectionName = newConnName;
    params.organization_id = orgId;
    if (params.baseDN) {
      params.key = params.baseDN;
      delete params.baseDN;
    } else {
      const atSPlit = params.username.split('@');
      const domainSplit = atSPlit[1].split('.');
      params.key = domainSplit.map(a => {
        return `DC=${a}`;
      }).join(',');
    }
    params.asset_repo_type_id = typeId;
    const exists = await assetRepoEndpointService.checkConnName(newConnName, newUserName, orgId);
    if (exists) {
      if (exists.isActive !== 'false') {
        const err = new Error('Connection Name and Username already exists.');
        err.status = 400;
        throw err;
      } else {
        const activeDirId = exists.id;
        params.id = activeDirId;
        try {
          logger.info({ params }, 'the params');
          let ad = await AssetRepoEndpoint.update(params, { where: { id: activeDirId } });
          ad = this.getActiveDirectoryById(orgId, activeDirId);
          return ad;
        } catch (e) {
          logger.error({ e, stack: e.stack }, 'Error occurred in creating Active Directory');
          throw e;
        }
      }
    }
    try {
      logger.info({ params }, 'the params');
      const ad = await AssetRepoEndpoint.create(params);
      return ad;
    } catch (e) {
      logger.error({ e, stack: e.stack }, 'Error occurred in creating Active Directory');
      throw e;
    }
  }

  async updateActiveDirectory(orgId, activeDirectoryId, params, req, res) {

    if(!params.username.includes('@')){
      const error = new Error('Active Directory Username supported format is username@domain');
      error.status = 400;
      throw error;
    }

    const connName = params.connectionName;
    const user = params.username;
    const typeId = params.type_id;
    const newConnName = removeSpace.checkMultiSpace(connName);
    const newUserName = removeSpace.removeAllSpaces(user);
    if (params.password) params.password = await this.keyGenerator.generateKeys(params.password, '');
    params.username = newUserName;
    params.connectionName = newConnName;
    params.organization_id = orgId;
    if (params.baseDN) {
      params.key = params.baseDN;
      delete params.baseDN;
    } else {
      const atSPlit = params.username.split('@');
      const domainSplit = atSPlit[1].split('.');
      params.key = domainSplit.map(a => {
        return `DC=${a}`;
      }).join(',');
    }
    params.asset_repo_type_id = typeId;
    const exists = await assetRepoEndpointService.checkNameForUpdate(newConnName, newUserName, activeDirectoryId, params.organization_id);
    if (exists) {
      const error = new Error('Connection Name and Username already exists.');
      error.status = 400;
      throw error;
    } else {
      params.id = activeDirectoryId;
      try {
        logger.info({ params }, 'the params');
        let ad = await AssetRepoEndpoint.update(params, { where: { id: activeDirectoryId } });
        ad = this.getActiveDirectoryById(orgId, activeDirectoryId);
        return ad;
      } catch (e) {
        logger.error({ e, stack: e.stack }, 'Error occurred in updating Active Directory');
        throw e;
      }
    }
  }

  async activeDirectoryTestConnection(params) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '1';
    if(typeof config.checkActiveDirectoryCertificate === 'boolean' && config.checkActiveDirectoryCertificate === false){
      process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    }
    let baseDN;
    if(!params.username.includes('@')){
      const error = new Error('Active Directory Username supported format is username@domain');
      error.status = 400;
      throw error;
    }
    if (!params.key) {
      const atSPlit = params.username.split('@');
      const domainSplit = atSPlit[1].split('.');
      baseDN = domainSplit.map(a => {
        return `DC=${a}`;
      }).join(',');
    } else {
      baseDN = params.key;
    }

    const configOptions = {
      url: params.connectionName,
      baseDN,
      username: params.username,
      password: params.password
    };
    try {
      const ad = new ActiveDirectory(configOptions);
      const auth = await new Promise((resolve, reject) => {
        ad.authenticate(params.username, params.password, function (err, auth) {
          if (err) {
            reject(err);
          } else if (auth) {
            resolve(true);
          } else {
            resolve(null);
          }
        });
      });
      if (!auth) {
        const error = new Error('Active Directory Connection Error.');
        error.status = 401;
        throw error;
      }
      return { connection: 'Connection Successful.' };
    } catch (err) {
      logger.error({ err, stack: err.stack }, 'error');
      const error = new Error('Active Directory Connection Error.');
      if (err.message.includes('525')) error.message = 'User Not Found.';
      else if (err.message.includes('52e')) error.message = 'Invalid Active Directory Credentials.';
      else if (err.message.includes('530')) error.message = 'Active Directory Not Permitted To Login';
      else if (err.message.includes('775')) error.message = 'User Account is Locked';
      else if (err.message.includes('verify the first certificate')) error.message = 'Active Directory SSL Verification Error';
      else if (err.message.includes('ETIMEDOUT')) error.message = 'Active Directory Connection Timeout';
      error.status = 400;
      throw error;
    }
  }

  async getAllActiveDirectory(orgId, limit = null, offset = null) {
    try {
      const adType = await AssetRepoType.findOne({ where: { name: 'Active Directory' } });
      const adBothType = await AssetRepoType.findOne({ where: { name: 'Active Directory Both' } });
      const ad = await AssetRepoEndpoint.findAll({
        where: {
          isActive: { $ne: 'false' }
        },
        include: [{ model: Organization, attributes: ['id', 'name', 'aliasName', 'fullName'], where: { id: orgId } },
          {
            model: AssetRepoType,
            attributes: ['name'],
            where: {
              id: [adType.id, adBothType.id]
            },
            required: true
          }],
        limit: limit,
        offset: offset
      });
      return ad;
    } catch (e) {
      logger.error({ e, stack: e.stack }, 'error occurred finding all active directory');
      throw e;
    }
  }

  async getActiveDirectoryById(orgId, activeDirectoryId) {
    try {
      const adType = await AssetRepoType.findOne({ where: { name: 'Active Directory' } });
      const adBothType = await AssetRepoType.findOne({ where: { name: 'Active Directory Both' } });
      const ad = await AssetRepoEndpoint.findOne({
        where: {
          id: activeDirectoryId,
          organization_id: orgId,
          $or: [{ asset_repo_type_id: adType.id }, { asset_repo_type_id: adBothType.id }]
        }
      });
      return ad;
    } catch (e) {
      logger.error({ e, stack: e.stack }, 'error occurred finding active directory');
      throw e;
    }
  }

  async deleteActiveDirectoryById(orgId, activeDirectoryId) {
    const adUsers = await User.findAll({
      where: {
        active_directory_id: activeDirectoryId,
        is_active: { $in: ['enabled', 'true'] }
      }
    });
    if (adUsers.length > 0) {
      const error = new Error('Cannot delete Active Directory with users');
      error.status = 401;
      throw error;
    }
    const adType = await AssetRepoType.findAll({ where: { name: ['Active Directory', 'Active Directory Both'] } });

    const activeDirectory = await AssetRepoEndpoint.findByPk(activeDirectoryId, {
      include: [
        { model: Organization, where: { id: orgId } },
        { model: AssetRepoType, where: { id: adType.map(ad => ad.id) } }
      ]
    });
    if (!activeDirectory) {
      const e = new Error('Active Directory not found');
      e.status = 404;
      throw e;
    }
    try {
      return activeDirectory.update({ isActive: 'false' });
    } catch (e) {
      logger.error({
        e,
        stack: e.stack,
        host: activeDirectory.connectionName
      }, 'error occurred deleting active directory');
      e.connectionName = activeDirectory.connectionName;
      throw e;
    }
  }

  async getActiveDirectoryUsers(activeDirectoryId, desiredPage = 1, filter = null) {
    const adDetails = await AssetRepoEndpoint.findOne({ where: { id: activeDirectoryId, isActive: { $ne: 'false' } } });
    if (!adDetails) {
      const error = new Error('Active Directory not found');
      error.status = 404;
      throw error;
    }
    const newPass = await this.keyGenerator.decryptKeys(adDetails.password);
    let baseDN;
    if (!adDetails.key) {
      const atSPlit = adDetails.username.split('@');
      const domainSplit = atSPlit[1].split('.');
      baseDN = domainSplit.map(a => {
        return `DC=${a}`;
      }).join(',');
    } else {
      baseDN = adDetails.key;
    }
    const config = {
      url: adDetails.connectionName,
      baseDN: baseDN,
      username: adDetails.username,
      password: newPass
    };
    const query = 'cn=*';
    try {
      /*const ad = new ActiveDirectory(config);
      ad.findUsers = util.promisify(ad.findUsers);
      const users = await ad.findUsers(query, true);
      return users.filter(u => u.userPrincipalName);
      */
      const ldap = new ActiveDirectoryLdap();
      const users = await ldap.findUsers(config, desiredPage, filter);
      return users;
    } catch (e) {
      logger.error({ e, stack: e.stack }, 'active directory error');
      const error = new Error('Active Directory Connection Error');
      error.status = 400;
      if (e.code && e.code == 'ETIMEDOUT') {
        error.message = 'Active Directory Connection Timeout';
      } else if (e.code && e.code == 10) {
        error.message = 'Active Directory BaseDN Invalid';
      } else if (e.code && e.code == 49) error.message = 'Active Directory Credentials Invalid';
      throw error;
    }
  }

  async getADAssetRepoEndpointTypes() {
    return AssetRepoType.findAll({
      where: {
        is_active: {
          $ne: 'false'
        },
        $or: [
          {
            name: 'Active Directory'
          },
          {
            name: 'Active Directory Both'
          }
        ]
      }
    });
  }
};
