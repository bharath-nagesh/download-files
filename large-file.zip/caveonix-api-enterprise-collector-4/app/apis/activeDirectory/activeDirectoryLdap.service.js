const ldap = require('ldapjs');
const config = require('../../../configure').get();
const util = require('util');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'activeDirectory.service'
});
module.exports = class ActiveDirectoryLdapService {
  constructor() {
  }

  async findUsers(configOptions, desiredPage = 1, filter = null) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '1';
    if(typeof config.checkActiveDirectoryCertificate === 'boolean' && config.checkActiveDirectoryCertificate === false){
      process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    }
    const server = configOptions.url;
    const userPrincipalName = configOptions.username;
    const password = configOptions.password;
    const adSuffix = configOptions.baseDN;
    desiredPage = parseInt(desiredPage, 10);

    const client = ldap.createClient({
      url: `${server}`
    });

    const filterCondition = filter ? `(&(&(userPrincipalName=*)(objectclass=user))(|(userPrincipalName=*${filter}*)(givenName=*${filter}*)(cn=*${filter}*)(sn=*${filter}*)))` : '(&(userPrincipalName=*)(objectclass=user))';
    const searchOptions = {
      filter: filterCondition,
      paged: {
        pageSize: 100,
        pagePause: true
      },
      scope: 'sub',
      attributes: ['givenName', 'userPrincipalName', 'sAMAccountName', 'whenCreated', 'pwdLastSet', 'userAccountControl', 'sn', 'cn', 'displayName']
    };
    return new Promise((resolve, reject) => {
      let page = 1;
      client.bind = util.promisify(client.bind);
      client.search = util.promisify(client.search);
      client.search = util.promisify(client.search);

      client.on('error', reject);
      return client.bind(userPrincipalName, password)
        .then(() => client.search(adSuffix, searchOptions))
        .then((res) => {
          const users = [];
          res.on('error', reject);
          res.on('searchEntry', entry => {
            if (page == desiredPage) {
              users.push(entry.object);
            }
          });
          res.on('page', function (result, cb) {

            if (page == desiredPage) {
              resolve(users.filter(u => u.userPrincipalName));
              return;
            }
            if(!cb) {
              resolve([]);
              return;
            }
            page++;
            cb();

          });
          res.on('end', () => resolve(users.filter(u => u.userPrincipalName)));

        });
    });

  };

};
