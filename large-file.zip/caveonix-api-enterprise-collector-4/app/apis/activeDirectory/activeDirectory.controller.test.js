const expect = require('chai').expect;
const proxyquire = require('proxyquire').noCallThru();
const httpMocks = require('node-mocks-http');

describe('ActiveDirectoryController', function () {
  beforeEach(() => {

  });

  describe('ActiveDirectoryController', () => {

    describe('getActiveDirectoryById', () => {
      it('getActiveDirectoryById', async () => {
        const aDResponse = { data: 1 };
        const orgId = 1;
        const activeDirectoryId = 1;
        let j = -1;
        const ActiveDirectoryService = class ActiveDirectoryService {
          async getActiveDirectoryById(orgId, activeDirectory) {

            j++;
            if (j == 1) throw 'error';
            return aDResponse;

          };
        };

        const KibanaUserRolesService = class KibanaUserRolesService {
          constructor() { }
        };

        const UserService = class UserService {
          constructor() { }
        };
        const ActiveDirectoryController = proxyquire('./activeDirectory.controller', {
          './activeDirectory.service': ActiveDirectoryService,
          '../kibanaUserRoles/kibanaUserRoles.service': KibanaUserRolesService,
          '../user/user.service': UserService
        });

        const activeDirectoryController = new ActiveDirectoryController();
        const req = httpMocks.createRequest({ params: { activeDirectoryId, orgId } });
        const res = httpMocks.createResponse();
        let i;
        const testData = [1, 'a', 2];
        for (i = 0; i < 3; i++) {
          req.params.activeDirectoryId = testData[i];
          const details = await activeDirectoryController.getActiveDirectoryById(req, res);
          if (i == 0) {
            console.log('test 200');
            aDData = details._getData();
            expect(JSON.parse(aDData)).to.deep.equal(aDResponse);
          } else if (i == 1) {
            console.log('test 400');
            expect(details.statusCode).to.deep.equal(400);
          } else if (i == 2) {
            console.log('test 500');
            expect(details.statusCode).to.deep.equal(500);
          }
        }
      });
    });

    describe('deleteActiveDirectory', () => {
      it('deleteActiveDirectory', async () => {
        const aDResponse = { data: 1 };
        const orgId = 1;
        const activeDirectoryId = 1;
        let test = 0;
        class ActiveDirectoryService {
          deleteActiveDirectoryById(orgId, activeDirectory) {
            test++;
            if (test == 2) throw 'error';
            return Promise.resolve(aDResponse);
          };
        };

        const KibanaUserRolesService = class KibanaUserRolesService {
          constructor() { }
        };

        const UserService = class UserService {
          constructor() { }
        };
        const ActiveDirectoryController = proxyquire('./activeDirectory.controller', {
          './activeDirectory.service': ActiveDirectoryService,
          '../kibanaUserRoles/kibanaUserRoles.service': KibanaUserRolesService,
          '../user/user.service': UserService
        });

        const activeDirectoryController = new ActiveDirectoryController();
        const req = httpMocks.createRequest({ params: { activeDirectoryId, orgId } });
        const res = httpMocks.createResponse();

        let details = await activeDirectoryController.deleteActiveDirectory(req, res);
        const aDData = details._getData();
        expect(JSON.parse(aDData)).to.deep.equal(aDResponse);

        details = await activeDirectoryController.deleteActiveDirectory(req, res);
        expect(details.statusCode).to.deep.equal(500);

      });
    });

    describe('deleteMultipleActiveDirectories', () => {
      it('deleteMultipleActiveDirectories', async () => {
        const aDResponse = { ids: [1, 2, 3] };
        const orgId = 1;
        const activeDirectoryId = 1;
        const ids = '1,2,3';
        let test = 0;
        class ActiveDirectoryService {
          deleteActiveDirectoryById(orgId, activeDirectory) {
            test++;
            if (test >= 4) throw 'error';
            return Promise.resolve(aDResponse);
          };
        };

        const KibanaUserRolesService = class KibanaUserRolesService {
          constructor() { }
        };

        const UserService = class UserService {
          constructor() { }
        };
        const ActiveDirectoryController = proxyquire('./activeDirectory.controller', {
          './activeDirectory.service': ActiveDirectoryService,
          '../kibanaUserRoles/kibanaUserRoles.service': KibanaUserRolesService,
          '../user/user.service': UserService
        });

        const activeDirectoryController = new ActiveDirectoryController();
        const req = httpMocks.createRequest({ params: { activeDirectoryId, orgId }, query: { id: ids } });
        const res = httpMocks.createResponse();

        let details = await activeDirectoryController.deleteMultipleActiveDirectories(req, res);
        expect(details.statusCode).to.deep.equal(202);

        details = await activeDirectoryController.deleteMultipleActiveDirectories(req, res);
        expect(details.statusCode).to.deep.equal(500);
      });
    });

    describe('getActiveDirectory', () => {
      it('getActiveDirectory', async () => {
        const serData = [{ data: 1 }];
        const resData = { data: 1 };
        const orgId = 1;
        const page = 1;
        const limit = 10;
        const offset = 0;
        const total_record_count = 1;
        const AdResponse = {
          total_page_count: 1,
          pageLimit: limit,
          total_record_count: total_record_count,
          page_number: page,
          activeDirectory: serData,
          pages: [{
            number: 1,
            url: 'null?page=' + page
          }]
        };

        let test = 0;
        class ActiveDirectoryService {
          getAllActiveDirectory(orgId, limit, offset) {
            test++;
            if (test == 3) throw error;
            return Promise.resolve(serData);
          };
        };
        const KibanaUserRolesService = class KibanaUserRolesService {
          constructor() { }
        };

        const UserService = class UserService {
          constructor() { }
        };
        const ActiveDirectoryController = proxyquire('./activeDirectory.controller', {
          './activeDirectory.service': ActiveDirectoryService,
          '../kibanaUserRoles/kibanaUserRoles.service': KibanaUserRolesService,
          '../user/user.service': UserService
        });

        const activeDirectoryController = new ActiveDirectoryController();
        const req = httpMocks.createRequest({ params: { orgId }, query: { page } });
        const res = httpMocks.createResponse({ locals: { paginate: { limit, offset, page } } });
        let details = await activeDirectoryController.getActiveDirectory(req, res);

        const aDData = details._getData();
        expect(JSON.parse(aDData)).to.deep.equal(AdResponse);

        details = await activeDirectoryController.getActiveDirectory(req, res);
        expect(details.statusCode).to.deep.equal(500);
      });
    });

    describe('createActiveDirectory', () => {
      it('createActiveDirectory', async () => {
        const aDResponse = {
          key: '111',
          connectionName: '10.1.1.1',
          username: 'username',
          password: 'password',
          type_id: '1',
          sourceId: '1',
          location_id: '1',
          hosting_provider_id: '1',
          isActive: 'enabled'
        };
        const orgId = 1;
        const activeDirectoryId = 1;
        let test = 0;
        class ActiveDirectoryService {
          createActiveDirectory(orgId, params, req, res) {
            test++;
            if (test == 2) throw 'error';
            aDResponse.id = activeDirectoryId;
            return Promise.resolve(aDResponse);
          };
        };
        const KibanaUserRolesService = class KibanaUserRolesService {
          constructor() { }
        };

        const UserService = class UserService {
          constructor() { }
        };
        const ActiveDirectoryController = proxyquire('./activeDirectory.controller', {
          './activeDirectory.service': ActiveDirectoryService,
          '../kibanaUserRoles/kibanaUserRoles.service': KibanaUserRolesService,
          '../user/user.service': UserService
        });

        const activeDirectoryController = new ActiveDirectoryController();
        const req = httpMocks.createRequest({ params: { orgId }, body: aDResponse });
        const res = httpMocks.createResponse();
        let details = await activeDirectoryController.createActiveDirectory(req, res);
        const aDData = details._getData();
        expect(JSON.parse(aDData)).to.deep.equal(aDResponse);

        details = await activeDirectoryController.createActiveDirectory(req, res);
        expect(details.statusCode).to.deep.equal(500);

        req.body.connectionName = null;
        details = await activeDirectoryController.createActiveDirectory(req, res);
        expect(details.statusCode).to.deep.equal(422);
      });
    });

    describe('updateActiveDirectory', () => {
      it('updateActiveDirectory', async () => {
        const aDResponse = {
          key: '111',
          connectionName: '10.1.1.1',
          username: 'username',
          password: 'password',
          type_id: '1',
          sourceId: '1',
          location_id: '1',
          hosting_provider_id: '1',
          isActive: 'enabled',
          activeDirectoryId: '1'
        };
        const orgId = 1;
        const activeDirectoryId = 1;

        let test = 0;
        class ActiveDirectoryService {
          updateActiveDirectory(orgId, activeDirectoryId, params, req, res) {
            test++;
            if(test == 2) throw 'error';
            return Promise.resolve(aDResponse);
          };
        };

        const KibanaUserRolesService = class KibanaUserRolesService {
          constructor() { }
        };

        const UserService = class UserService {
          constructor() { }
        };
        const ActiveDirectoryController = proxyquire('./activeDirectory.controller', {
          './activeDirectory.service': ActiveDirectoryService,
          '../kibanaUserRoles/kibanaUserRoles.service': KibanaUserRolesService,
          '../user/user.service': UserService
        });

        const activeDirectoryController = new ActiveDirectoryController();
        const req = httpMocks.createRequest({ params: { orgId, activeDirectoryId }, body: aDResponse });
        const res = httpMocks.createResponse();

        let details = await activeDirectoryController.updateActiveDirectory(req, res);
        const aDData = details._getData();
        expect(JSON.parse(aDData)).to.deep.equal(aDResponse);

        details = await activeDirectoryController.updateActiveDirectory(req, res);
        expect(details.statusCode).to.deep.equal(500);

        req.body.connectionName = null;
        details = await activeDirectoryController.updateActiveDirectory(req, res);
        expect(details.statusCode).to.deep.equal(422);
      });
    });

    describe('getActiveDirectoryUsers', () => {
      it('getActiveDirectoryUsers', async () => {
        const aDResponse = { data: 1 };
        const orgId = 1;
        const activeDirectoryId = 1;
        let test = 0;
        class ActiveDirectoryService {
          getActiveDirectoryUsers(activeDirectoryId) {
            test++;
            if(test == 2) throw 'error';
            return Promise.resolve(aDResponse);
          };
        };

        const KibanaUserRolesService = class KibanaUserRolesService {
          constructor() { }
        };

        const UserService = class UserService {
          constructor() { }
        };
        const ActiveDirectoryController = proxyquire('./activeDirectory.controller', {
          './activeDirectory.service': ActiveDirectoryService,
          '../kibanaUserRoles/kibanaUserRoles.service': KibanaUserRolesService,
          '../user/user.service': UserService
        });

        const activeDirectoryController = new ActiveDirectoryController();
        const req = httpMocks.createRequest({ params: { activeDirectoryId, orgId } });
        const res = httpMocks.createResponse();
        let details = await activeDirectoryController.getActiveDirectoryUsers(req, res);
        const aDData = details._getData();
        expect(JSON.parse(aDData)).to.deep.equal(aDResponse);

        details = await activeDirectoryController.getActiveDirectoryUsers(req, res);
        expect(details.statusCode).to.deep.equal(500);

        req.params.activeDirectoryId = null;
        details = await activeDirectoryController.getActiveDirectoryUsers(req, res);
        expect(details.statusCode).to.deep.equal(422);
      });
    });

    describe('createADUser', () => {
      it('createADUser', async () => {
        const aDusersData = [{
          username: 'u',
          firstName: 'f',
          lastName: 'l',
          role_id: '1',
          organization_id: '1',
          isActive: 'enabled'
        }];
        const orgId = 1;
        const aDusersDataFinal = [aDusersData];
        const test = 0;
        const UserService = class UserService {
          createUser(username, pw, firstname, lastname, roleId, organizationId, isActive, params, passCheck) {
            return Promise.resolve(aDusersData);
          };
        };

        class ActiveDirectoryService {
          constructor() { }
        }

        const KibanaUserRolesService = class KibanaUserRolesService {
          constructor() { }

          createUserRoles(orgId, update, type) {
            return true;
          }
        };

        const RoleService = class RoleService {
          constructor() { }

          getRole(orgId, update, type) {
            return { name:{
              toLowerCase(){
                return 'csp';
              }
            } };
          }
        };

        const ActiveDirectoryController = proxyquire('./activeDirectory.controller', {
          './activeDirectory.service': ActiveDirectoryService,
          '../kibanaUserRoles/kibanaUserRoles.service': KibanaUserRolesService,
          '../user/user.service': UserService,
          '../roles/role.service':RoleService
        });

        const activeDirectoryController = new ActiveDirectoryController();
        const req = httpMocks.createRequest({ params: { orgId }, body: aDusersData });
        const res = httpMocks.createResponse();
        let details = await activeDirectoryController.createADUser(req, res);
        console.log(details)
        const aDData = details._getData();
        expect(JSON.parse(aDData)).to.deep.equal(aDusersDataFinal);

        req.body.data = null;
        details = await activeDirectoryController.createADUser(req, res);
        expect(details.statusCode).to.deep.equal(422);
      });
    });

    describe('getActiveDirectoryTypes', () => {
      it('getActiveDirectoryTypes', async () => {
        const serRes = { data: 1 };
        const aDResponse = { activeDirectoryType: serRes };
        const orgId = 1;
        const activeDirectoryId = 1;
        let test = 0;
        class ActiveDirectoryService {
          getADAssetRepoEndpointTypes() {
            test++;
            if(test == 2) throw 'error';
            return Promise.resolve(serRes);
          };
        };

        const KibanaUserRolesService = class KibanaUserRolesService {
          constructor() { }
        };

        const UserService = class UserService {
          constructor() { }
        };
        const ActiveDirectoryController = proxyquire('./activeDirectory.controller', {
          './activeDirectory.service': ActiveDirectoryService,
          '../kibanaUserRoles/kibanaUserRoles.service': KibanaUserRolesService,
          '../user/user.service': UserService
        });

        const activeDirectoryController = new ActiveDirectoryController();
        const req = httpMocks.createRequest({ params: { activeDirectoryId, orgId } });
        const res = httpMocks.createResponse();
        let details = await activeDirectoryController.getActiveDirectoryTypes(req, res);
        const aDData = details._getData();
        expect(JSON.parse(aDData)).to.deep.equal(aDResponse);

        details = await activeDirectoryController.getActiveDirectoryTypes(req, res);
        expect(details.statusCode).to.deep.equal(500);
      });
    });

  });
});
