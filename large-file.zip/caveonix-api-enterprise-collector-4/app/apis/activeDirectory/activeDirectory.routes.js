const ActiveDirectoryController = require('./activeDirectory.controller');

/**
 * @swagger
 * tags:
 *  - name: ActiveDirectory
 *    description: Active Directory endpoints
 */
module.exports = class ActiveDirectoryRoutes {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.activeDirectoryController = new ActiveDirectoryController();

      // initializing route
      if (type === 'Service Provider') {
        this.initServiceProvider();
      } else {
        this.initOrganization();
      }
    }
  }

  initOrganization() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/activeDirectory:
     *   get:
     *     tags:
     *       - ActiveDirectory
     *     summary: Gets a list of Active Directories
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of active directories
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/`, this.activeDirectoryController.getActiveDirectory);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/activeDirectory/{activeDirectoryId}:
     *   get:
     *     tags:
     *       - ActiveDirectory
     *     summary: Gets a activeDirectory by it's id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: activeDirectoryId
     *         description: The id of the specified activeDirectory.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: activeDirectory
     */
    this.router.get(`${this.path}/:activeDirectoryId`, this.activeDirectoryController.getActiveDirectoryById);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/activeDirectory:
     *   post:
     *     tags:
     *       - ActiveDirectory
     *     summary: Creates a Active Directory
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - in: body
     *         name: Active Ditectory
     *         description: Creates a Active Directory
     *         schema:
     *           type: object
     *           required:
     *             - username
     *             - password
     *             - connectionName
     *             - baseDN
     *             - type_id
     *             - location_id
     *             - hosting_provider_id
     *           properties:
     *             username:
     *               type: string
     *             password:
     *               type: string
     *             connectionName:
     *               type: string
     *             baseDN:
     *               type: string
     *             type_id:
     *               type: integer
     *             location_id:
     *               type: integer
     *             hosting_provider_id:
     *               type: integer
     *             sourceId:
     *               type: integer
     *             key:
     *               type: string
     *     responses:
     *       200:
     *         description: activeDirectory
     */
    this.router.post(`${this.path}/`, this.activeDirectoryController.createActiveDirectory);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/activeDirectory/testConnection:
     *   post:
     *     tags:
     *       - ActiveDirectory
     *     summary: Creates a Active Directory
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - in: body
     *         name: Active Ditectory
     *         description:  tests connection to Active Directory
     *         schema:
     *           type: object
     *           required:
     *             - username
     *             - password
     *             - connectionName
     *             - baseDN
     *             - type_id
     *             - location_id
     *             - hosting_provider_id
     *           properties:
     *             username:
     *               type: string
     *             password:
     *               type: string
     *             connectionName:
     *               type: string
     *             baseDN:
     *               type: string
     *             type_id:
     *               type: integer
     *             location_id:
     *               type: integer
     *             hosting_provider_id:
     *               type: integer
     *             sourceId:
     *               type: integer
     *             key:
     *               type: string
     *     responses:
     *       200:
     *         description: activeDirectory
     */
    this.router.post(`${this.path}/testConnection`, this.activeDirectoryController.activeDirectoryTestConnection);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/activeDirectory/{activeDirectoryId}:
     *   put:
     *     tags:
     *       - ActiveDirectory
     *     summary: Updates a Active Directory
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: activeDirectoryId
     *         description: The id of the specified Active Directory.
     *         in: path
     *         required: true
     *         type: number
     *       - in: body
     *         name: Active Ditectory
     *         description: Creates a Active Directory
     *         schema:
     *           type: object
     *           required:
     *             - username
     *             - password
     *             - connectionName
     *             - baseDN
     *             - type_id
     *             - location_id
     *             - hosting_provider_id
     *           properties:
     *             username:
     *               type: string
     *             password:
     *               type: string
     *             connectionName:
     *               type: string
     *             baseDN:
     *               type: string
     *             type_id:
     *               type: integer
     *             location_id:
     *               type: integer
     *             hosting_provider_id:
     *               type: integer
     *             sourceId:
     *               type: integer
     *             key:
     *               type: string
     *     responses:
     *       200:
     *         description: activeDirectory
     */
    this.router.put(`${this.path}/:activeDirectoryId`, this.activeDirectoryController.updateActiveDirectory);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/activeDirectory/{activeDirectoryId}:
     *   delete:
     *     tags:
     *       - ActiveDirectory
     *     summary: Deletes a Active Directory
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: activeDirectoryId
     *         description: The id of the specified Active Directory.
     *         in: path
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: activeDirectory
     */
    this.router.delete(`${this.path}/`, this.activeDirectoryController.deleteMultipleActiveDirectories);
  }

  initServiceProvider() {
    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/activeDirectory:
     *   get:
     *     tags:
     *       - ActiveDirectory
     *     summary: Gets a list of all active directories
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: ActiveDirectory
     */
    this.router.get(`${this.path}/`, this.activeDirectoryController.getActiveDirectory);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/activeDirectory/{activeDirectoryId}:
     *   get:
     *     tags:
     *       - ActiveDirectory
     *     summary: Gets a Active Directory by it's id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: activeDirectoryId
     *         description: The id of the specified Active Directory.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: activeDirectory
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/:activeDirectoryId`, this.activeDirectoryController.getActiveDirectoryById);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/activeDirectory:
     *   post:
     *     tags:
     *       - ActiveDirectory
     *     summary: Creates a Active Directory
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *       - in: body
     *         name: Active Ditectory
     *         description: Creates a Active Directory
     *         schema:
     *           type: object
     *           required:
     *             - username
     *             - password
     *             - connectionName
     *             - baseDN
     *             - type_id
     *             - location_id
     *             - hosting_provider_id
     *           properties:
     *             username:
     *               type: string
     *             password:
     *               type: string
     *             connectionName:
     *               type: string
     *             baseDN:
     *               type: string
     *             type_id:
     *               type: integer
     *             location_id:
     *               type: integer
     *             hosting_provider_id:
     *               type: integer
     *             sourceId:
     *               type: integer
     *             key:
     *               type: string
     *     responses:
     *       200:
     *         description: Active Directory
     *       400:
     *          description: Bad Request
     */
    this.router.post(`${this.path}`, this.activeDirectoryController.createActiveDirectory);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/activeDirectory/testConnection:
     *   post:
     *     tags:
     *       - ActiveDirectory
     *     summary: Creates a Active Directory
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - in: body
     *         name: Active Ditectory
     *         description:  tests connection to Active Directory
     *         schema:
     *           type: object
     *           required:
     *             - username
     *             - password
     *             - connectionName
     *             - baseDN
     *             - type_id
     *             - location_id
     *             - hosting_provider_id
     *           properties:
     *             username:
     *               type: string
     *             password:
     *               type: string
     *             connectionName:
     *               type: string
     *             baseDN:
     *               type: string
     *             type_id:
     *               type: integer
     *             location_id:
     *               type: integer
     *             hosting_provider_id:
     *               type: integer
     *             sourceId:
     *               type: integer
     *             key:
     *               type: string
     *     responses:
     *       200:
     *         description: activeDirectory
     */
    this.router.post(`${this.path}/testConnection`, this.activeDirectoryController.activeDirectoryTestConnection);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/activeDirectory/{activeDirectoryId}:
     *   put:
     *     tags:
     *       - ActiveDirectory
     *     summary: Updates a Active Directory
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: activeDirectoryId
     *         description: The id of the specified active directory.
     *         in: path
     *         required: true
     *         type: string
     *       - in: body
     *         name: Active Ditectory
     *         description: Creates a Active Directory
     *         schema:
     *           type: object
     *           required:
     *             - username
     *             - password
     *             - connectionName
     *             - baseDN
     *             - type_id
     *             - location_id
     *             - hosting_provider_id
     *           properties:
     *             username:
     *               type: string
     *             password:
     *               type: string
     *             connectionName:
     *               type: string
     *             baseDN:
     *               type: string
     *             type_id:
     *               type: integer
     *             location_id:
     *               type: integer
     *             hosting_provider_id:
     *               type: integer
     *             sourceId:
     *               type: integer
     *             key:
     *               type: string
     *     responses:
     *       200:
     *         description: Active Directory
     *       400:
     *          description: Bad Request
     */
    this.router.put(`${this.path}/:activeDirectoryId`, this.activeDirectoryController.updateActiveDirectory);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/activeDirectory/{activeDirectoryId}:
     *   delete:
     *     tags:
     *       - ActiveDirectory
     *     summary: Deletes a Active Directory
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: activeDirectoryId
     *         description: The id of the specified Active Directory.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: Active Directory
     *       400:
     *          description: Bad Request
     */
    this.router.delete(`${this.path}/:activeDirectoryId`, this.activeDirectoryController.deleteActiveDirectory);
  }
};
