const expect = require('chai').expect;
const proxyquire = require('proxyquire').noCallThru();

describe('ActiveDirectoryService', function () {
  beforeEach(() => {

  });

  describe('createActiveDirectory', () => {
    it('createActiveDirectory', async () => {
      
      const params = {
        key: '111',
        connectionName: '10.1.1.1',
        username: 'username',
        password: 'password',
        type_id: '1',
        sourceId: '1',
        location_id: '1',
        hosting_provider_id: '1',
        isActive: 'enabled',
        baseDN:'DC=test,DC=com'
      };
      const repoType = {
        data : 1
      }
      const orgId = 1;
      
      const req = {};
      const res = {};

      const urlResponse = {
        port : 1,
        protocol:'http:/',
        hostname:'example.com'
      }
      class AssetRepoEndpoint {
        constructor() { }

        static create() {
          return (params);
        }
      };
      
      class AssetRepoEndpointService{
        checkConnName(newConnName, newUserName){
          return false;
        }
      }

      class removeSpace{
        static checkMultiSpace(connectionName){
          return params.connectionName;
        }

        static removeAllSpaces(username){
          return params.username;
        }
      }

      class AssetRepoType{
        findOne(){
          return repoType;
        }
      }

      class url{
        static parse(newConnName, parseQueryString){
          return urlResponse;
        }
      }

      class KeyGenerator{

        constructor() { }

        generateKeys(password,salt){
          return params.password;
        }
      }

      class Orgstub{
        constructor() { }
      }

      const ActiveDirectoryService = proxyquire('./activeDirectory.service', {
        '../assetRepoEndpoint/assetRepoEndpoint.model': AssetRepoEndpoint,
        '../assetRepoEndpoint/assetRepoEndpoint.service':AssetRepoEndpointService,
        '../assetRepoEndpoint/assetRepoType.model':AssetRepoType,
        '../../../utils/checkSpaces':removeSpace,
        '../../../utils/generateKeys':KeyGenerator,
        '../organization/organization.model':Orgstub,
        url:url
      });
      const activeDirectoryService = new ActiveDirectoryService();
      const data = await activeDirectoryService.createActiveDirectory(orgId, params, req, res);
      console.log('adser')
      console.log(data)
      expect(data).to.be.equal(params);
      
    });
  });
});
