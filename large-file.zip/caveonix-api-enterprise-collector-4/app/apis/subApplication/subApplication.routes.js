const SubApplicationController = require('./subApplication.controller');

/**
 * @swagger
 * tags:
 *  - name: SubApplication
 *    description: Policy Group endpoints
 */
module.exports = class SubApplicationRoutes {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.subApplicationController = new SubApplicationController();

      // initializing route
      if (type === 'Service Provider') {
        this.initServiceProvider();
      } else {
        this.initOrganization();
      }
    }
  }

  initOrganization() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/subApplication:
     *   get:
     *     tags:
     *       - SubApplication
     *     summary: Gets a list of Policy Groups
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of policy groups
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/`, this.subApplicationController.getAssetSubApplication);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/subApplication/{subApplicationId}:
     *   get:
     *     tags:
     *       - SubApplication
     *     summary: Gets a subApplication by it's id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: subApplicationId
     *         description: The id of the specified Policy Group.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: subApplication
     */
    this.router.get(`${this.path}/:subApplicationId`, this.subApplicationController.getSubApplicationById);

    //router.put('/:orgId/subApplication/:subApplicationId', PolicyController.addAssetToSubApplication);
    //router.delete('/:orgId/subApplication/:subApplicationId', PolicyController.removeAssetToSubApplication);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/subApplication:
     *   post:
     *     tags:
     *       - SubApplication
     *     summary: Creates a Policy Group
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: subApplicationId
     *         description: The id of the specified Policy Group.
     *         in: path
     *         required: true
     *         type: string
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/SubApplication'
     *     responses:
     *       200:
     *         description: subApplication
     */
    this.router.post(`${this.path}/`, this.subApplicationController.createSubApplication);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/subApplication/{subApplicationId}:
     *   put:
     *     tags:
     *       - SubApplication
     *     summary: Updates a Policy Group
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: subApplicationId
     *         description: The id of the specified Policy Group.
     *         in: path
     *         required: true
     *         type: string
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/SubApplication'
     *     responses:
     *       200:
     *         description: subApplication
     */
    this.router.put(`${this.path}/:subApplicationId`, this.subApplicationController.modifySubApplication);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/subApplication/{subApplicationId}:
     *   delete:
     *     tags:
     *       - SubApplication
     *     summary: Deletes a Policy Group
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: subApplicationId
     *         description: The id of the specified Policy Group.
     *         in: path
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: subApplication
     */
    this.router.delete(`${this.path}/`, this.subApplicationController.deleteMultipleSubApplication);
  }

  initServiceProvider() {}
};
