const Sequelize = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();
/**
 * @swagger
 * components:
 *   schemas:
 *     SubApplication:
 *       type: object
 *       required:
 *         - name
 *         - isActive
 *       properties:
 *         name:
 *           type: string
 *         description:
 *           type: string
 *         sequence_num:
 *           type: string
 *         security_tag_name:
 *           type: string
 *         isActive:
 *           type: string
 * @param sequelize
 */

class PolicyGroup extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
      name: { type: Sequelize.STRING, allowNull: false },
      description: { type: Sequelize.STRING },
      isActive: { type: Sequelize.BOOLEAN, field: 'is_active', defaultValue: true },
      is_active: { type: Sequelize.BOOLEAN, field: 'is_active' },
      sequence_num: { type: Sequelize.INTEGER, field: 'sequence_num' },
      security_tag_name: { type: Sequelize.STRING, field: 'security_tag_name' }
    },
    { sequelize, timestamps: true, freezeTableName: true, tableName: 'sub_applications', underscored: true });
  }

  static associate(models) {
    PolicyGroup.belongsTo(models.Organization, { required: true, foreignKey: 'organization_id' });
    PolicyGroup.hasMany(models.PolicySourceMembers, { foreignKey: 'policyGroupId' });
    //PolicyGroup.hasMany(models.policyGroupAssetMembers, { foreignKey: 'policy_group_id' });
    PolicyGroup.belongsToMany(models.Asset, {
      through: 'sub_application_asset_members',
      foreignKey: 'policy_group_id',
      otherKey: 'asset_id',
      timestamps: false
    });
    PolicyGroup.belongsToMany(models.ApplicationTag, {
      through: 'sub_application_members',
      foreignKey: 'policy_group_id',
      otherKey: 'source_id',
      timestamps: false
    });
  };
}
module.exports = PolicyGroup;
