const ApplicationTag = require('../application/applicationTag.model');
const Asset = require('../asset/asset.model');
const EnforcementService = require('../enforcement/enforcement.service');
const enforcementService = new EnforcementService();
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-subApplication.service'
});
const PolicySourceMembers = require('../../models/policySourceMember.model');
const Organization = require('../organization/organization.model');
const OrgService = require('../organization/org.service');
const orgService = new OrgService();
const SubApplication = require('./subApplication.model');
const SubApplicationAssetMembers = require('./subApplicationAssetMembers.model');
const { QueryTypes } = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();
const removeSpace = require('../../../utils/checkSpaces');
const uuid = require('uuid/v4');

module.exports = class SubApplicationService {
  constructor() {
    logger.debug('called SubApplicationService constructor');
  }

  /*
   TODO only have one get by id method
   This is not the right way to do this and is completely wrong * DO NOT COPY *
   */

  async getSubApplication(subApplicationId, opts) {
    return SubApplication.findByPk(subApplicationId);
  }

  async getSubApplicationById(subApplicationId, opts) {
    const subApp = await SubApplication.findByPk(subApplicationId, {
      include: [{
        model: Organization,
        attributes: ['id', 'name', 'type', 'aliasName', 'fullName']
      }, { model: Asset, attributes: ['id'] }, { model: ApplicationTag, attributes: ['id'] }]
    });

    if (!subApp) {

      const err = new Error('SubApplication Not Found');
      err.status = 404;
      throw err;
    }
    return subApp;
  }

  getSubApplications(subApplicationIdArr) {
    return SubApplication.findAll({
      where: { id: { $in: subApplicationIdArr } },
      include: [{ model: Asset, required: false, where: { $or: [{ isActive: { $ne: 'false' } }] } },
        { model: Organization }, { model: PolicySourceMembers, include: [{ model: ApplicationTag }] }]
    });
  }

  async getAllSubApplication(orgId, dropdown = false) {
    const orgArr = await Organization.getOrgChain(orgId);
    const where = { isActive: { $ne: 'false' } };
    if(dropdown && dropdown === 'true'){
      where.isActive = { $eq:'enabled' };
    }
    return SubApplication.findAll({
      where,
      include: [{ model: Organization, where: { id: orgArr } }, {
        model: ApplicationTag,
        attributes: ['name', 'id']
      }]
    });

  }

  async getAllSubApplicationCount(orgId, dropdown = false) {
    let isActive = ['enabled','disabled'];
    if(dropdown && dropdown === 'true'){
      isActive = ['enabled'];
    }
    const orgArr = await orgService.getOrgChain(orgId);
    return sequelize
      .query(
        `SELECT  count("SubApplication".id) FROM (SELECT "SubApplication"."id", "SubApplication"."name", "SubApplication"."description", "SubApplication"."is_active" AS "isActive", "SubApplication"."sequence_num", "SubApplication"."security_tag_name", "SubApplication"."created_at", "SubApplication"."updated_at", "SubApplication"."organization_id" FROM "sub_applications" AS "SubApplication"
          WHERE "SubApplication"."organization_id" IN (:orgArr)
          AND ("SubApplication"."is_active" in (:isActive) )
          ORDER BY "SubApplication"."id" ASC LIMIT 5000 OFFSET 0) AS "SubApplication" LEFT OUTER JOIN "organizations" AS "Organization" ON "SubApplication"."organization_id" = "Organization"."id" LEFT OUTER JOIN "sub_application_members" AS "PolicySourceMembers" ON "SubApplication"."id" = "PolicySourceMembers"."policy_group_id" LEFT OUTER JOIN "application_tags" AS "PolicySourceMembers->ApplicationTag" ON "PolicySourceMembers"."source_id" = "PolicySourceMembers->ApplicationTag"."id";`,
        { replacements: { orgArr, isActive }, type: QueryTypes.SELECT }
      );

  }

  async create(userId, token, orgId, params) {
    params.organization_id = orgId;
    const assets = params.assets;
    const assetArray = assets.split(',');
    const name = params.name;
    const update = {};
    let subApplication = {};
    const newName = removeSpace.checkMultiSpace(name);
    params.name = newName;
    const securityTag = `sub_application^${name.replace(new RegExp(':', 'g'), '_').replace(new RegExp(' ', 'g'), '_')}^${uuid()}`;
    params.security_tag_name = securityTag;
    const exists = await this.checkName(newName, orgId);
    if (exists && (exists.isActive === true || exists.isActive === 'enabled')) {
      const err = new Error('Duplicate Sub Application Name.');
      err.status = 400;
      throw err;
    } else if (exists && (exists.isActive === false)) {
      subApplication = exists;
      params.id = exists.id;
      await SubApplication.update(params, { where: { id: subApplication.id } });
    } else {
      subApplication = await SubApplication.create(params);
    }
    if (params.assets) {
      const Policy = await SubApplication.findOne({ where: { $and: [{ name: 'Sub-Application' }, { organization_id: orgId }] } });
      const assetArr = assetArray;
      const result = await SubApplicationAssetMembers.findAll({ where: { $and: [{ asset_id: { $in: assetArr } }, { policy_group_id: Policy.id }] } });
      const pGArr = result.map(function (object) {
        return object.asset_id;
      });
      const assetArrayvmIdsToDetach = await Asset.findAll({ where: { id: { $in: pGArr } } });
      const assetArrayvmIdsToCreate = await Asset.findAll({ where: { id: { $in: assetArray } } });
      const vmIdsToDetach = assetArrayvmIdsToDetach.map((asset) => {
        return asset.vmId;
      });
      const vmIdsToCreate = assetArrayvmIdsToCreate.map((asset) => {
        return asset.vmId;
      });
      if (vmIdsToDetach.length !== 0) {
        // await service.services.enforcementService._detatchSecurityTags(userId, token, orgId, [tags], vmIdsToDetach);
      }
      if (vmIdsToCreate.length !== 0) {
        // await service.services.enforcementService.createOrUpdateSecurityTag(userId, token, orgId, [securityTag], vmIdsToCreate);
      }
      await SubApplicationAssetMembers.destroy({ where: { $and: [{ asset_id: { $in: pGArr } }, { policy_group_id: Policy.id }] } });
      await subApplication.addAsset(assetArray);
    }
    if (params.applicationgroupId) {
      update.subApplicationId = subApplication.id;
      update.sourceId = params.applicationgroupId;
      update.sourceType = 'Application';
      if (Array.isArray(update.sourceId)) {
        const sourceIdArr = update.sourceId;
        sourceIdArr.forEach(a => {
          update.sourceId = a;
          PolicySourceMembers.create(update);
        });
      } else {
        await PolicySourceMembers.create(update);
      }
    }
    return this.getSubApplication(subApplication.id);
  }

  async update(params, subApplicationId, orgId) {
    const orgChain = await Organization.getOrgChain(orgId);
    const assets = params.assets;
    const assetArray = assets.split(',');
    const name = params.name;
    const newName = removeSpace.checkMultiSpace(name);
    const userId = params.userId;
    const userToken = params.token;
    params.name = newName;
    const subApplicationExist = await this.getSubApplication(subApplicationId);
    if (!subApplicationExist) {
      const err = new Error('Sub Application Not Found.');
      err.status = 404;
      throw err;
    }
    if (!orgChain.includes(subApplicationExist.organization_id)) {
      const err = new Error('Unauthorized');
      err.status = 401;
      throw err;
    }
    orgId = subApplicationExist.organization_id;
    params.organization_id = orgId;
    const exists = await this.checkNameForUpdate(newName, subApplicationId, orgId);
    if (exists) {
      const err = new Error('Duplicate Sub Application Name.');
      err.status = 400;
      throw err;
    }
    const subApplication = await subApplicationExist.update(params);
    const Policy = await SubApplication.findOne({ where: { $and: [{ name: 'Sub-Application' }, { organization_id: orgId }] } });
    const PGAM = await SubApplicationAssetMembers.findAll({ where: { policy_group_id: subApplicationId } });
    const assetArr1 = [];
    const ctr1 = 0;
    for (let i = 0; i < PGAM.length; i++) {
      const object = PGAM[i];
      assetArr1[ctr1] = object.asset_id;
      const assetId = assetArr1[ctr1];
      const PGAM1 = await SubApplicationAssetMembers.findAll({ where: { $and: [{ policy_group_id: { $ne: subApplicationId } }, { asset_id: assetId }] } });
      if (PGAM1.length >= 1) {
        const assetReturned = await Asset.findOne({ where: { id: assetId } });
        const vmIdsToDetach = assetReturned.vmId;
        if (vmIdsToDetach) {
          //TODO chris updateSecurityTags error
          try {
            await enforcementService._detatchSecurityTags(userId, userToken, orgId, [subApplication.security_tag_name], vmIdsToDetach);
          } catch (error) {
            logger.error({ error, stack: error.stack }, 'updateSecurityTags error');
          }
        }
        await SubApplicationAssetMembers.destroy({ where: { $and: [{ policy_group_id: subApplicationId }, { asset_id: assetId }] } });
      } else {
        const assetReturned = await Asset.findOne({ where: { id: assetId } });
        const vmIdsToCreate = assetReturned.vmId;
        if (vmIdsToCreate) {
          //TODO chris updateSecurityTags error
          try {
            await enforcementService.createOrUpdateSecurityTag(userId, userToken, orgId, [Policy.security_tag_name], vmIdsToCreate);
          } catch (error) {
            logger.error({ error, stack: error.stack }, 'createOrUpdateSecurityTag error');
          }
        }
        await SubApplicationAssetMembers.update({ policy_group_id: Policy.id }, { where: { asset_id: assetId } });
      }
    }
    if (params.assets) {
      const result = await SubApplicationAssetMembers.findAll({ where: { $and: [{ asset_id: { $in: assetArray } }, { policy_group_id: Policy.id }] } });
      if (result.length > 0) {
        const defaultAssetId = result.map(function (object) {
          return object.asset_id;
        });
        const assetArrayvmIdsToDetach = await Asset.findAll({ where: { id: { $in: defaultAssetId } } });
        const assetArrayvmIdsToCreate = await Asset.findAll({ where: { id: { $in: assetArray } } });
        const vmIdsToDetach = assetArrayvmIdsToDetach.map((asset) => {
          return asset.vmId;
        });
        const vmIdsToCreate = assetArrayvmIdsToCreate.map((asset) => asset.vmId);
        if (vmIdsToDetach.length !== 0) {
          //TODO chris updateSecurityTags error
          try {
            await enforcementService._detatchSecurityTags(userId, userToken, orgId, [Policy.security_tag_name], vmIdsToDetach);
          } catch (error) {
            logger.error({ error, stack: error.stack }, '_detatchSecurityTags error');
          }
        }
        if (vmIdsToCreate.length !== 0) {
          //TODO chris updateSecurityTags error
          try {
            await enforcementService.createOrUpdateSecurityTag(userId, userToken, orgId, [subApplication.security_tag_name], vmIdsToCreate);
          } catch (error) {
            logger.error({ error, stack: error.stack }, 'createOrUpdateSecurityTag error');
          }
        }
        await SubApplicationAssetMembers.destroy({ where: { asset_id: { $in: defaultAssetId } } });
        await subApplication.addAsset(assetArray);
        const update = {};
        update.subApplicationId = subApplication.id;
        update.sourceId = params.applicationgroupId;
        update.sourceType = 'Application';
        await PolicySourceMembers.destroy({ where: { policy_group_id: subApplication.id } });
        if (!Array.isArray(update.sourceId)) update.sourceId = update.sourceId.split(',');
        const sourceIdArr = update.sourceId;
        sourceIdArr.forEach(a => {
          update.sourceId = a;
          PolicySourceMembers.create(update);
        });
        return this.getSubApplication(subApplicationId);

      } else {
        const assetArrayvmIdsToCreate = await Asset.findAll({ where: { id: { $in: assetArray } } });
        const vmIdsToCreate = assetArrayvmIdsToCreate.map((asset) => {
          return asset.vmId;
        });
        if (vmIdsToCreate.length !== 0) {
          //TODO chris updateSecurityTags error
          try {
            await enforcementService.createOrUpdateSecurityTag(userId, userToken, orgId, [subApplication.security_tag_name], vmIdsToCreate);
          } catch (error) {
            logger.error({ error, stack: error.stack }, 'createOrUpdateSecurityTag error');
          }
        }
        await subApplication.addAsset(assetArray);
        const update = {};
        update.subApplicationId = subApplication.id;
        update.sourceId = params.applicationgroupId;
        update.sourceType = 'Application';
        await PolicySourceMembers.destroy({ where: { policy_group_id: subApplication.id } });
        if (!Array.isArray(update.sourceId)) update.sourceId = update.sourceId.split(',');
        const sourceIdArr = update.sourceId;
        sourceIdArr.forEach(a => {
          update.sourceId = a;
          PolicySourceMembers.create(update);
        });
        return this.getSubApplication(subApplicationId);
      }
    } else {
      const update = {};
      update.subApplicationId = subApplication.id;
      update.sourceId = params.applicationgroupId;
      update.sourceType = 'Application';
      //TODO chris updateSecurityTags error
      try {
        await enforcementService.createOrUpdateSecurityTag(userId, userToken, orgId, [subApplication.security_tag_name]);
      } catch (error) {
        logger.error({ error, stack: error.stack }, 'createOrUpdateSecurityTag error');
      }
      await PolicySourceMembers.destroy({ where: { policy_group_id: subApplication.id } });
      if (!Array.isArray(update.sourceId)) update.sourceId = update.sourceId.split(',');
      const sourceIdArr = update.sourceId;
      sourceIdArr.forEach(a => {
        update.sourceId = a;
        PolicySourceMembers.create(update);
      });
      return this.getSubApplication(subApplicationId);
    }
  }

  async deleteById(subApplicationId, userId, userToken, orgId) {
    const assetsInSubAppCount = await SubApplicationAssetMembers.count({ where: { policy_group_id: subApplicationId } });
    if (assetsInSubAppCount > 0) {
      const e = new Error('Cannot delete sub-application that has assets associated with it.');
      e.status = 400;
      throw e;
    }
    await PolicySourceMembers.destroy({ where: { policy_group_id: subApplicationId } });
    return SubApplication.update({ isActive: false }, { where: { id: subApplicationId } });
  }

  async addAssetToSubApplication(subApplicationId, assetId, userId, userToken, updateSecurityTags = true) {
    const subApplication = await this.getSubApplication(subApplicationId);
    if (!subApplication) {
      const error = new Error('No Application found.');
      error.status = 404;
      throw error;
    }
    const assetArray = assetId.split(',');
    await SubApplicationAssetMembers.destroy({ where: { asset_id: assetArray } });
    await subApplication.addAsset(assetArray);
    if (updateSecurityTags) {
      await enforcementService.addAssetsToSubAppSecurityTag(userId, userToken, subApplication.organization_id, subApplicationId);
    }
    return this.getSubApplication(subApplicationId);
  }

  async removeAssetToSubApplication(subApplicationId, assetId, userId, userToken) {
    const subApplication = await this.getSubApplication(subApplicationId);
    if (!subApplication) {
      const error = new Error('No Application found.');
      error.status = 404;
      throw error;
    }
    const assetArray = assetId.split(',');
    await subApplication.removeAsset(assetArray);
    await enforcementService.removeAssetFromSubAppSecurityTag(userId, userToken, subApplication.organization_id, subApplicationId, assetArray);
    return this.getSubApplication(subApplicationId);
  }

  checkName(name, orgId) {
    return SubApplication.findOne({
      where: {
        name: sequelize.where(sequelize.fn('LOWER', sequelize.col('name')), sequelize.fn('lower', name)),
        organization_id: { $eq: orgId }
      }
    });
  }

  checkNameForUpdate(name, subApplicationId, orgId) {
    return SubApplication.findOne({
      where: {
        name: sequelize.where(sequelize.fn('LOWER', sequelize.col('name')), sequelize.fn('lower', name)),
        $or: [{ isActive: { $ne: 'false' } }],
        organization_id: { $eq: orgId },
        id: { $ne: subApplicationId }
      }
    });
  }

  async deleteMultipleId(subApplicationIdArr, userId, userToken, orgId) {
    try {
      await Promise.all(subApplicationIdArr.map(subApplicationId => this.deleteById(subApplicationId, userId, userToken, orgId)));
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred deleting sub app');
      throw error;
    }
    return this.getSubApplications(subApplicationIdArr);
  }
};
