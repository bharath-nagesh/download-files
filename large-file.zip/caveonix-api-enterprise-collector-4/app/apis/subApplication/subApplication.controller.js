const checkId = require('../../../utils/checkId');
const checkName = require('../../../utils/checkName');
const errorHandler = require('../../../utils/errorHandler');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-subApplication.controller'
});
const paginate = require('../../middlewares/paginate.middleware');
const SubApplicationService = require('./subApplication.service');

module.exports = class SubApplicationController {
  async getAssetSubApplication(req, res) {
    const limit = res.locals.paginate.limit;
    const pageNumber = res.locals.paginate.page;
    const orgId = req.params.orgId;
    const dropdown = req.query.dropdown || false;
    const subApplicationService = new SubApplicationService();
    try{
      const results = await subApplicationService.getAllSubApplication(orgId, dropdown);
      const itemCount = await subApplicationService.getAllSubApplicationCount(orgId, dropdown);
      const pageCount = Math.ceil(itemCount / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        subApplications: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }

  }

  async addAssetToSubApplication(req, res) {
    const params = req.body;
    const assetId = params.assets;
    const subApplicationId = req.params.subApplicationId;
    const userId = req.user.id;
    const token = req.authInfo;
    if (checkId(subApplicationId)) {
      logger.error({ subApplicationId }, 'Error with Application Id');
      const error = new Error('Error with Application Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    if (checkName(assetId)) {
      logger.error({ assetId }, 'Error with Asset Id');
      const error = new Error('Error with Asset Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try{
      const subApplicationService = new SubApplicationService();
      let ret = await subApplicationService.addAssetToSubApplication(subApplicationId, assetId, userId, token);
      return res.json(ret);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async removeAssetToSubApplication(req, res) {
    const params = req.body;
    const assetId = params.assets;
    const subApplicationId = req.params.subApplicationId;
    const userId = req.user.id;
    const token = req.authInfo;
    if (checkId(subApplicationId)) {
      logger.error({ subApplicationId }, 'Error with Application Id');
      const error = new Error('Error with Application Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    if (checkName(assetId)) {
      logger.error({ assetId }, 'Error with Asset Id');
      const error = new Error('Error with Asset Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try{
      const subApplicationService = new SubApplicationService();
      const ret = await subApplicationService.removeAssetToSubApplication(subApplicationId, assetId, userId, token);
      return res.json(ret);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getSubApplicationById(req, res) {
    const subApplicationId = req.params.subApplicationId;
    if (checkId(subApplicationId)) {
      logger.error({ subApplicationId }, 'Error with Application Id');
      const error = new Error('Error with Application Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try{
      const subApplicationService = new SubApplicationService();
      const subApplication = await subApplicationService.getSubApplicationById(subApplicationId);
      return res.json(subApplication);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async createSubApplication(req, res) {
    const orgId = req.params.orgId;
    const params = req.body;
    const userId = req.user.id;
    const token = req.authInfo;
    params.userId = userId;
    params.token = token;
    if (Object.keys(params).length === 0) {
      logger.error('Invalid parameters for Application creation');
      const error = new Error('Invalid parameters for Application creation');
      error.status = 400;
      return errorHandler(req, res, error);
    }

    try{
      const subApplicationService = new SubApplicationService();
      const subApplication = await subApplicationService.create(userId, token, orgId, params);
      return res.json(subApplication);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async modifySubApplication(req, res) {
    const orgId = req.params.orgId;
    const params = req.body;
    const subApplicationId = req.params.subApplicationId;
    const userId = req.user.id;
    const token = req.authInfo;
    params.userId = userId;
    params.token = token;
    if (Object.keys(params).length === 0) {
      logger.error('Invalid parameters for Application update');
      const error = new Error('Invalid parameters for Application update');
      error.status = 400;
      return errorHandler(req, res, error);
    }

    try{
      const subApplicationService = new SubApplicationService();
      const subApplication = await subApplicationService.update(params, subApplicationId, orgId);
      return res.json(subApplication);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async deleteSubApplication(req, res) {
    const subApplicationId = req.params.subApplicationId;
    const userId = req.user.id;
    const token = req.authInfo;
    const orgId = req.params.orgId;
    if (checkId(subApplicationId)) {
      logger.error({ subApplicationId }, 'Error with Application Id');
      const error = new Error('Error with Application Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try{
      const subApplicationService = new SubApplicationService();
      const update = await subApplicationService.deleteById(subApplicationId, userId, token, orgId);
      logger.info({ update, subApplicationId }, 'update');
      return res.json(update);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async deleteMultipleSubApplication(req, res) {
    const userId = req.user.id;
    const token = req.authInfo;
    const orgId = req.params.orgId;
    const subApplicationId = req.query.id || '';
    const subApplicationIdArr = subApplicationId.split(',');
    const subApplicationService = new SubApplicationService();
    try {
      const result = await subApplicationService.deleteMultipleId(subApplicationIdArr, userId, token, orgId);
      return res.json(result);
    } catch (error) {
      return errorHandler(req, res, error);
    }
  }
};
