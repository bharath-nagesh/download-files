const Sequelize = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();


class PolicyGroupAssetMembers extends Sequelize.Model {

  static init(sequelize) {
    return super.init({
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      policy_group_id: { type: Sequelize.INTEGER, field: 'policy_group_id' },
      asset_id: { type: Sequelize.STRING, field: 'asset_id' }
    },
    { sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'sub_application_asset_members',
      underscored: true
    });
  }

  static associate(models) {
    PolicyGroupAssetMembers.belongsTo(models.Asset);
  };
}
module.exports = PolicyGroupAssetMembers;
