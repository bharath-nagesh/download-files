const Sequelize = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();

const ReportType = sequelize.define(
  'ReportType',
  {
    name: Sequelize.STRING,
    isActive: {
      type: Sequelize.BOOLEAN,
      field: 'is_active',
      defaultValue: 'enabled'
    },
    is_active: {
      type: Sequelize.BOOLEAN,
      field: 'is_active'
    }
  },
  {
    timestamps: false,
    freezeTableName: true,
    tableName: 'report_types',
    underscored: true
  }
);

module.exports = ReportType;
