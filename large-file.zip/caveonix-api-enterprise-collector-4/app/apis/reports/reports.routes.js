const ReportController = require('./reports.controller');

/**
 * @swagger
 * tags:
 *  - name: Report
 *    description: Report endpoints
 */
module.exports = class ReportRouter {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.reportController = new ReportController();

      // initializing route
      this.initOrganization();
    }
  }

  /**
   * Route initialization and setup
   */
  initOrganization() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/report:
     *   get:
     *     tags:
     *       - Report
     *     summary: Gets a list of all reports
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: get all reports
     *       401:
     *         description: unauthorized
     */
    this.router.get(`${this.path}/`, this.reportController.getReports);
    this.router.get(`${this.path}/types`, this.reportController.getReportTypes);
    this.router.post(`${this.path}/create`, this.reportController.createReport);

    this.router.get(`${this.path}/:reportId`, this.reportController.getReportById);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/report/{reportId}/view:
     *   get:
     *     tags:
     *       - Report
     *     summary: Gets an report by its id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: reportId
     *         description: The id of the specified report.
     *         in: path
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: Report
     *       401:
     *         description: unauthorized
     */
    this.router.get(`${this.path}/:reportId/view`, this.reportController.viewReport);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/report/{reportId}:
     *   put:
     *     tags:
     *       - Report
     *     summary: Updates the specified report
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: reportId
     *         description: The id of the specified report.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/Report'
     *     responses:
     *       200:
     *         description: login
     *       401:
     *         description: unauthorized
     */
    this.router.put(`${this.path}/:reportId`, this.reportController.updateReport);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/report/{reportId}/schedule:
     *   post:
     *     tags:
     *       - Report
     *     summary: Schedules a report
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: reportId
     *         description: The id of the specified report.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/Report'
     *     responses:
     *       200:
     *         description: report was created successfully
     *       401:
     *         description: unauthorized
     */
    this.router.post(`${this.path}/:reportId/schedule`, this.reportController.scheduleReport);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/report/{reportId}/email:
     *   post:
     *     tags:
     *       - Report
     *     summary: Emails a report
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: reportId
     *         description: The id of the specified report.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/Report'
     *     responses:
     *       200:
     *         description: report was created successfully
     *       401:
     *         description: unauthorized
     */
    this.router.post(`${this.path}/:reportId/email`, this.reportController.emailReport);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/report/:
     *   delete:
     *     tags:
     *       - Report
     *     summary: Deletes an report
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: deleted report
     *       401:
     *         description: unauthorized
     */
    this.router.delete(`${this.path}/`, this.reportController.deleteReports);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/report/{reportId}/history:
     *   get:
     *     tags:
     *       - Report
     *     summary: List History of Scheduled Reports
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: reportId
     *         description: The reportd's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: List History
     *       401:
     *         description: unauthorized
     */
    this.router.get(`${this.path}/:reportId/history`, this.reportController.getReportHistory);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/report/{reportId}/history/{resultId}/view:
     *   get:
     *     tags:
     *       - Report
     *     summary: Get Scheduled Report Based on History
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: reportId
     *         description: The reportd's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: resultId
     *         description: The history result's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: View Report
     *       401:
     *         description: unauthorized
     */
    this.router.get(`${this.path}/:reportId/history/:resultId/view`, this.reportController.viewReportHistory);

  }
};
