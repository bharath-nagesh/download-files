const Sequelize = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();
/**
 * @swagger
 * components:
 *   schemas:
 *     Report:
 *       type: object
 *       required:
 *         - name
 *         - status
 *         - parameters
 *         - result
 *         - resultBin
 *       properties:
 *         name:
 *           type: string
 *         status:
 *           type: string
 *         parameters:
 *           type: string
 *         result:
 *           type: string
 *         resultBin:
 *           type: string
 * @param sequelize
 */
const Report = sequelize.define(
  'Report',
  {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    name: Sequelize.STRING,
    status: {
      type: Sequelize.ENUM('Completed','In Progress','Scheduled','Error'),
      field: 'status',
      defaultValue: 'In Progress'
    },
    statusDetail:{
      type:Sequelize.STRING,
      field:'status_detail'
    },
    parameters: {
      type: Sequelize.STRING,
      field: 'parameters'
    },
    result: {
      type: Sequelize.STRING,
      field: 'result'
    },
    resultBin: {
      type: Sequelize.BLOB,
      field: 'result_bin'
    }
  },
  {
    timestamps: true,
    freezeTableName: true,
    tableName: 'reports',
    underscored: true
  }
);
Report.associate = (models) => {
  Report.belongsTo(models.Organization, { foreignKey: { name: 'organizationId', field: 'organization_id' } });
  Report.belongsTo(models.ReportType, { foreignKey: { name: 'reportTypeId', field: 'report_type_id' } });
  Report.belongsTo(models.ScheduleTask, { foreignKey: { name: 'scheduleId', field: 'schedule_id' } });
  Report.belongsTo(models.User, { foreignKey: { name: 'userId', field: 'user_id' } });
};

module.exports = Report;
