const ApplicationTagService = require('../application/applicationTag.service');
const applicationTagService = new ApplicationTagService();
const Organization = require('../organization/organization.model');
const Certificates = require('../certificates/certificates.model');
const config = require('../../../configure').get();
const csv = require('async-csv');
const EmailServerService = require('../emailServer/emailServer.service');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-vendor.service'
});
const LocationService = require('../location/location.service');
const moment = require('moment');
const NetworkFlowService = require('../networkFlow/networkFlow.service');
const ObjectsToCsv = require('objects-to-csv');
const parse = csv.parse;
const Poc = require('../poc/poc.model');
const { QueryTypes } = require('sequelize');
const ReferenceService = require('../../services/reference.service');
const referenceService = new ReferenceService();
const Report = require('./report.model');
const ReportType = require('./reportType.model');
const ReportResults = require('./reportResults.model');
const reportTemplate = require('../../../utils/reportEmailTemplate');
const rp = require('request-promise');
const sequelize = require('../../../config/db.conf').getConnection();
const ScheduleTask = require('../../models/scheduleTask.model');
const assetDefinition = require('../../definitions/asset');
const complianceDefinition = require('../../definitions/compliance');
const cyberDefinition = require('../../definitions/cyber');
const CentralCollectorClient = require('../../../utils/centralCollector.client');
[assetDefinition, complianceDefinition, cyberDefinition].map(def => referenceService.addEndpoints(null, null, def));
module.exports = class ReportService {
  constructor() {
    this.reportUrl = config.reports_url;
    this.checkReportCertificate = config.checkreportCertificate || false;
    logger.debug('called ReportService constructor');
  }

  async getReportTypes() {
    return ReportType.findAll({ where: { isActive: { $in: ['Enabled', 'True'] } } });
  }

  async startReportCreation(orgId, userId, reportTypeId, name, parameters) {
    const reportCheck = await Report.findAll({ where: { name, organization_id: orgId }, attributes: ['id', 'name'] });
    if (reportCheck.length > 0) {
      const e = new Error('Duplicate Report Name');
      e.status = 400;
      throw e;
    }
    logger.silly({ orgId, userId, reportTypeId, name, parameters }, 'inputs');
    try {
      const status = 'In Progress';
      if (parameters.where.organization_id) {
        if (!Array.isArray(parameters.where.organization_id)) parameters.where.organization_id = [parameters.where.organization_id];
        parameters.where.organization_id.map(o => {
          parseInt(o);
        });
        const organizations = await Organization.findAll({
          where: { id: { $in: parameters.where.organization_id } },
          attributes: ['id', 'name']
        });
        if (organizations) {
          parameters.where.organization = organizations.map(o => {
            return o.name;
          });
        }
      }
      const reportType = isNaN(reportTypeId) ? await ReportType.findOne({ where: { name: reportTypeId } }) : await ReportType.findByPk(reportTypeId);
      if (!reportType) {
        const e = new Error('ReportType Not Found');
        e.status = 404;
        throw e;
      }
      reportTypeId = reportType.id;
      const report = await Report.create({
        organizationId: orgId,
        userId,
        reportTypeId,
        status,
        name,
        parameters: JSON.stringify(parameters)
      });
      return report;
    } catch (error) {
      logger.error({ error, stacK: error.stack }, 'error occurred');
      throw error;
    }
  }

  async createReportByType(reportType, orgId, token, parameters, reportId) {
    let applicationId, regulation;
    const networkFlowService = new NetworkFlowService();
    switch (reportType) {
      case 'Audit Report':
        applicationId = parameters.where.application_grp_id && parameters.where.application_grp_id[0] ? parameters.where.application_grp_id[0] : parameters.applicationId;
        regulation = parameters.regulation;
        if (!applicationId) {
          applicationId = 0;
        }//let error = new Error('missing applicationId'); error.status = 400; throw error}
        if (!regulation) {
          const error = new Error('missing regulation');
          error.status = 400;
          throw error;
        }
        return this.createAuditReport(orgId, token, regulation, applicationId, reportId, parameters);
        break;
      case 'Compliance Report':
        regulation = parameters.regulation;
        if (!regulation) {
          const error = new Error('missing regulation');
          error.status = 400;
          throw error;
        }
        return this.createComplianceReport(orgId, token, regulation, reportId, parameters);
        break;
      case 'Cyber Risk Report':
        return this.createCyberReport(orgId, token, reportId, parameters);
        break;
      case 'Compliance Delta Report':
        regulation = parameters.regulation;
        if (!regulation) {
          const error = new Error('missing regulation');
          error.status = 400;
          throw error;
        }
        return this.createComplianceDeltaReport(orgId, token, regulation, reportId, parameters);
        break;
      case 'Cyber Risk Delta Report':
        return this.createCyberDeltaReport(orgId, token, reportId, parameters);
        break;
      case 'Infrastructure Compliance':
        regulation = parameters.regulation;
        return this.createExcelReport(orgId, token, 'regulationControlViewDownload', regulation, parameters);
      case 'Infrastructure Vulnerabilities':
        return this.createExcelReport(orgId, token, 'vulnerabilityDistribution', 'tabular', parameters);

      case 'Netflows':
        return this.getNetworkFlowsReport(orgId, token, new Date(), reportId, parameters.where);
      //return flowD.location.flowTabularData.data;
      case 'Traffic Distribution':
        const trafficFlowD = await networkFlowService.getNetworkFlowsPage(orgId, new Date(), null, parameters.where);
        return trafficFlowD.location.flowTabularData.data;

      case 'Security Policies':
        return this.getPolicyRiskPageReport(orgId, token, applicationId, new Date(), reportId, parameters.where);
      //return policyD.policyTabularData.data;
      case 'Threat Detection':
        return this.createExcelReport(orgId, token, 'threatWidget', 'default', parameters);
      case 'Software':
        return this.createSoftwareReport(orgId, token, 'Software Report', reportId, parameters);
      case 'Assets':
        return this.createAssetReport(orgId, token, 'Asset Report', applicationId, reportId, parameters);
      case 'Compliance Risk Reduction':
        return this.createComplianceRiskReductionReport(orgId, token, 'Compliance Risk Reduction Report', applicationId, reportId, parameters);
      case 'Cyber Risk Reduction':
        return this.createCyberRiskReductionReport(orgId, token, 'Cyber Risk Reduction Report', applicationId, reportId, parameters);
      case 'AWS Inventory Report':
        return this.createAwsInventoryReport(orgId, token, 'AWS Inventory Report', applicationId, reportId, parameters);
      case 'GCP Inventory Report':
        return this.createGcpInventoryReport(orgId, token, 'GCP Inventory Report', applicationId, reportId, parameters);
      case 'AZURE Inventory Report':
        return this.createAzureInventoryReport(orgId, token, 'AZURE Inventory Report', applicationId, reportId, parameters);
      case 'Hytrust Compliance Delta Report':
        regulation = parameters.regulation;
        if (!regulation) {
          const error = new Error('missing regulation');
          error.status = 400;
          throw error;
        }
        return this.createHytrustComplianceDeltaReport(orgId, token, regulation, applicationId, reportId, parameters);
      case 'Hytrust User Privilege Analysis Report':
        return this.createHytrustUserRightsReport(orgId, token, applicationId, reportId, parameters);
      default:
        const error = new Error('unknown report type');
        error.status = 400;
        throw error;
    }
  }

  async getReports(orgId) {
    const reports = await Report.findAll({
      where: { organizationId: orgId },
      include: [{ all: true }],
      attributes: { exclude: ['result', 'resultBin'] }
    });
    return reports.map((report) => {
      if (typeof report.parameters === 'string') {
        report.setDataValue('parameters', JSON.parse(report.parameters));
      }
      if (report.ScheduleTask && report.ScheduleTask.parameters && typeof report.ScheduleTask.parameters === 'string') {
        report.ScheduleTask.setDataValue('parameters', JSON.parse(report.ScheduleTask.parameters));
      }
      return report;
    });
  }

  async getReportById(orgId, reportId) {
    try {
      const report = await Report.findByPk(reportId, {
        where: { organizationId: orgId },
        include: [{ all: true }],
        attributes: { exclude: ['result', 'resultBin'] }
      });

      if (!report) {
        const error = new Error('report not found');
        error.status = 404;
        throw error;
      }
      report.setDataValue('parameters', JSON.parse(report.parameters));
      return report;

    } catch (e) {
      logger.error({ e, stack: e.stack }, 'error occurred');
      throw e;
    }
  }

  async deleteReports(orgId, userId, token, reportIds = []) {
    try {
      const reports = await Report.findAll({ where: { id: reportIds, organizationId: orgId } });

      await Promise.all(reports.map(async report => {
        if(report.scheduleId){
          await this.scheduleReportCron('delete', { token,user_id:userId,orgId,id:report.scheduleId,name:report.name,reportId:report.id });
          await ScheduleTask.update({ isActive:'false' },{ where: { id: report.scheduleId } });
        }
        report.destroy();
      }));
      return 'success';

    } catch (e) {
      logger.error({ e, stack: e.stack }, 'error occurred');
      throw e;
    }
  }

  async updateReport(orgId, reportId, update, whereClause, token) {
    const reportCheck = await Report.findAll({ where: { name: update.name, organization_id: orgId, id: { $ne: reportId } }, attributes: ['id', 'name'] });
    if (reportCheck.length > 0) {
      const e = new Error('Duplicate Report Name');
      e.status = 400;
      throw e;
    }
    const report = await Report.findOne({ where: { organizationId: orgId, id: reportId }, include: [{ all: true }] });
    if (whereClause.organization_id) {
      if (!Array.isArray(whereClause.organization_id)) whereClause.organization_id = [whereClause.organization_id];
      whereClause.organization_id.map(o => {
        parseInt(o);
      });
      const organizations = await Organization.findAll({
        where: { id: { $in: whereClause.organization_id } },
        attributes: ['id', 'name']
      });
      if (organizations) {
        whereClause.organization = organizations.map(o => {
          return o.name;
        });
      }
    }
    if (!report) {
      const error = new Error('Report Not Found');
      error.status = 404;
      throw error;
    }
    const parameters = JSON.parse(report.parameters);
    parameters.where = whereClause;
    if (update.applicationId) parameters.applicationId = update.applicationId;
    if (update.filter) parameters.filter = update.filter;
    if (update.startDate) parameters.startDate = update.startDate;
    if (update.endDate) parameters.endDate = update.endDate;
    update.parameters = JSON.stringify(parameters);

    update.status = 'In Progress';
    await report.update(update);
    report.setDataValue('parameters', JSON.parse(report.parameters));
    const reportType = report.ReportType.name;
    //Generating report asynchronously
    try {
      const reportData = await this.createReportByType(reportType, orgId, token, report.parameters, report.id);
      return report;
      /* Now saving reports in reportGenerator
      report.status = 'Completed';
      report.save({ fields: ['resultBin', 'result', 'status'] });
      */
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      if (error.message.toLowerCase().includes('no assigned controls')) {
        report.statusDetail = 'No Assigned Controls';
      }
      report.status = 'Error';

      report.save({ fields: ['status'] });
      return report;
    }

  }

  async emailReport(orgId, reportId, email) {
    const report = await Report.findOne({ where: { organizationId: orgId, id: reportId }, include: [{ all: true }] });
    const data = report ? (report.resultBin ? report.resultBin : report.result) : null;
    if (!report || !data) {
      logger.error({ does_report_exist: !!report }, 'report not found or data does not exist');
      const e = new Error('Report Not Found');
      e.status = 404;
      throw e;
    }
    const params = typeof report.parameters === 'string' ? JSON.parse(report.parameters) : report.parameters;
    const today = moment().format('YYYY-MM-DD');
    const regulation = params.regulation;
    let applicationNameArray = [];
    let locationNameArray = [];
    let severityArray = [];
    logger.info({ params }, 'params');

    if (params.applicationId) {
      const app = applicationTagService.getApplicationTag(params.applicationId, orgId);
      applicationNameArray.push(app.name);
    }
    if (params.where && params.where.application_grp_id) {
      const apps = await applicationTagService.getApplicationTags(params.where.application_grp_id, orgId);
      apps.forEach(a => {
        applicationNameArray.push(a.name);
      });
      if (params.where.application) applicationNameArray.push(...params.where.application);

    }
    if (params.where && params.where.location_id) {
      const locationService = new LocationService();
      const locations = await locationService.getLocationsById(params.where.location_id);
      locations.forEach(l => {
        locationNameArray.push(l.name);
      });
      if (params.where.location) locationNameArray.push(...params.where.location);
    }
    if (params.where && params.where.severity) {
      severityArray.push(...params.where.severity);
    }
    severityArray = Array.from(new Set(severityArray));
    locationNameArray = Array.from(new Set(locationNameArray));
    applicationNameArray = Array.from(new Set(applicationNameArray));

    const text = reportTemplate(email, report.name, report.ReportType.name, report.Organization.name, today, regulation, applicationNameArray, locationNameArray, severityArray);
    const emailServerService = new EmailServerService();
    const result = await emailServerService.sendEmail(orgId, report.name, report.ReportType.name, text, data, email);
    return result;
  }

  async scheduleReport(orgId, reportId, cronExpression, userId, token, email = null) {
    if (!email) {
      const POCs = await Poc.findAll({ where: { organization_id: orgId } });
      const emails = POCs.map(poc => poc.email);
      email = emails.join(',');
    }
    const report = await Report.findOne({
      where: { organizationId: orgId, id: reportId },
      include: [{ model: ReportType }],
      attributes: {
        exclude: ['result', 'resultBin']
      }
    });
    if (!report) {
      logger.error({ does_report_exist: !!report }, 'report not found or data does not exist');
      const e = new Error('Report Not Found');
      e.status = 404;
      throw e;
    }
    const parameters = typeof report.parameters === 'string' ? JSON.parse(report.parameters) : report.parameters;
    const scheduledTask = await this.scheduleReportJob(orgId, {
      type_name: report.ReportType.name,
      applicationId: parameters.applicationId,
      org_id: report.organizationId,
      name: report.name,
      user_id: userId,
      email: parameters.email || email,
      regulation: parameters.regulation,
      cron_expression: cronExpression,
      schedule_id:report.scheduleId,
      report_id:report.id,
      token
    });
    report.scheduleId = scheduledTask.id;
    report.status = 'Scheduled';
    report.save();

    return scheduledTask;
  }

  async viewReport(orgId, reportId) {
    const report = await Report.findOne({ where: { organizationId: orgId, id: reportId } });
    const data = report ? (report.resultBin ? {
      result: report.resultBin,
      type: 'application/zip'
    } : { result: JSON.parse(report.result), type: 'application/json' }) : null;
    if (!report || !data) {
      logger.error({ does_report_exist: !!report }, 'report not found or data does not exist');
      const e = new Error('Report Not Found');
      e.status = 404;
      throw e;
    }
    return { name: `${report.name}.zip`, data: data.result, type: data.type };
  }

  async createCSV(data) {
    const csv = new ObjectsToCsv(data);
    const csvString = await csv.toString(true);
    return parse(csvString, { relax_column_count: true, delimiter: ',', rtrim: true, ltrim: true });

  }

  async createExcelReport(orgId, token, handlerName, handlerSelector, parameters = {}) {
    parameters.orgId = orgId;
    parameters.name = handlerName;
    let data = await referenceService.runNamedQuery(handlerName, handlerSelector, parameters, true);
    if (data.data) data = data.data;
    return data;

  }

  async createCyberReport(orgId, token, reportId, parameters = {}) {
    let where = {};
    if (parameters.where) where = parameters.where;
    const url = `${this.reportUrl}/api/cyberReport/create`;
    parameters.endDate = moment().format('YYYY-MM-DD');
    const body = { orgId, endDate: parameters.endDate, token, where, reportId };
    return rp.post(url, {
      body,
      json: true,
      rejectUnauthorized: this.checkReportCertificate
    });
  }

  async createComplianceReport(orgId, token, regulation, reportId, parameters = {}) {
    let where = {};
    if (parameters.where) where = parameters.where;
    const url = `${this.reportUrl}/api/complianceReport/create`;
    const body = { orgId, token, regulation, where, reportId };
    return rp.post(url, {
      body,
      json: true,
      rejectUnauthorized: this.checkReportCertificate
    });
  }

  async createAwsInventoryReport(orgId, token, regulation, applicationId, reportId, parameters = {}) {
    let where = {};
    if (parameters.where) where = parameters.where;
    const url = `${this.reportUrl}/api/awsInventoryReport/create`;
    const body = { orgId, token, regulation, where, reportId };
    return rp.post(url, {
      body,
      json: true,
      rejectUnauthorized: this.checkReportCertificate
    });
  }

  async createGcpInventoryReport(orgId, token, regulation, applicationId, reportId, parameters = {}) {
    let where = {};
    if (parameters.where) where = parameters.where;
    const url = `${this.reportUrl}/api/gcpInventoryReport/create`;
    const body = { orgId, token, regulation, where, reportId };
    return rp.post(url, {
      body,
      json: true,
      rejectUnauthorized: this.checkReportCertificate
    });
  }

  async createAzureInventoryReport(orgId, token, regulation, applicationId, reportId, parameters = {}) {
    let where = {};
    if (parameters.where) where = parameters.where;
    const url = `${this.reportUrl}/api/azureInventoryReport/create`;
    const body = { orgId, token, regulation, where, reportId };
    return rp.post(url, {
      body,
      json: true,
      rejectUnauthorized: this.checkReportCertificate
    });
  }

  async createHytrustComplianceDeltaReport(orgId, token, regulation, applicationId, reportId, parameters = {}) {
    let where = {};
    if (parameters.where) where = parameters.where;
    const url = `${this.reportUrl}/api/hytrustComplianceDeltaReport/create`;
    parameters.endDate = parameters.endDate ? moment(parameters.endDate).format('YYYY-MM-DD') : null;
    parameters.startDate = parameters.startDate ? moment(parameters.startDate).format('YYYY-MM-DD') : null;
    const body = { orgId, token, regulation, where, reportId, reportType:'Hytrust Compliance Delta Report' };
    if (parameters.endDate) body.endDate = parameters.endDate;
    if (parameters.startDate) body.startDate = parameters.startDate;
    return rp.post(url, {
      body,
      json: true,
      rejectUnauthorized: this.checkReportCertificate
    });
  }

  async createHytrustUserRightsReport(orgId, token, applicationId, reportId, parameters = {}) {
    let where = {};
    if (parameters.where) where = parameters.where;
    const url = `${this.reportUrl}/api/hytrustUserRightsReport/create`;
    parameters.endDate = parameters.endDate ? moment(parameters.endDate).format('YYYY-MM-DD') : null;
    parameters.startDate = parameters.startDate ? moment(parameters.startDate).format('YYYY-MM-DD') : null;
    const body = { orgId, token, where, reportId, reportType: 'Hytrust User Privilege Analysis Report' };
    if (parameters.endDate) body.endDate = parameters.endDate;
    if (parameters.startDate) body.startDate = parameters.startDate;
    return rp.post(url, {
      body,
      json: true,
      rejectUnauthorized: this.checkReportCertificate
    });
  }

  async createSoftwareReport(orgId, token, reportType, reportId, parameters = {}) {
    let where = {};
    if (parameters.where) where = parameters.where;
    const url = `${this.reportUrl}/api/softwareReport/create`;
    const body = { orgId, token, reportType, where, reportId };
    return rp.post(url, {
      body,
      json: true,
      rejectUnauthorized: this.checkReportCertificate
    });
  }

  async createAssetReport(orgId, token, reportType, applicationId, reportId, parameters = {}) {
    let where = {};
    if (parameters.where) where = parameters.where;
    const url = `${this.reportUrl}/api/assetReport/create`;
    const body = { orgId, token, reportType, where, applicationId, reportId };
    return rp.post(url, {
      body,
      json: true,
      rejectUnauthorized: this.checkReportCertificate
    });
  }

  async createComplianceRiskReductionReport(orgId, token, reportType, applicationId, reportId, parameters = {}) {
    let where = {};
    if (parameters.where) where = parameters.where;
    const url = `${this.reportUrl}/api/complianceRiskReductionReport/create`;
    const body = { orgId, token, reportType, where, applicationId, reportId };
    return rp.post(url, {
      body,
      json: true,
      rejectUnauthorized: this.checkReportCertificate
    });
  }

  async createCyberRiskReductionReport(orgId, token, reportType, applicationId, reportId, parameters = {}) {
    let where = {};
    if (parameters.where) where = parameters.where;
    const url = `${this.reportUrl}/api/cyberRiskReductionReport/create`;
    const body = { orgId, token, reportType, where, applicationId, reportId };
    return rp.post(url, {
      body,
      json: true,
      rejectUnauthorized: this.checkReportCertificate
    });
  }

  async createAuditReport(orgId, token, regulation, applicationId, reportId, parameters = {}) {
    const certificate = await Certificates.findOne({ where: { name: sequelize.where(sequelize.fn('LOWER', sequelize.col('name')), sequelize.fn('lower', regulation)) } });
    const certId = certificate.id;
    const d = await applicationTagService.getApplicationTagControls(applicationId, certId);
    if (d.length === 0) throw new Error('No Assigned Controls');
    let where = {};
    if (parameters.where) where = parameters.where;
    const url = `${this.reportUrl}/api/auditReport/create`;
    parameters.endDate = parameters.endDate ? moment(parameters.endDate).format('YYYY-MM-DD') : null;
    parameters.startDate = parameters.startDate ? moment(parameters.startDate).format('YYYY-MM-DD') : null;
    const body = { orgId, token, regulation, applicationId, where, reportId };
    if (parameters.endDate) body.endDate = parameters.endDate;
    if (parameters.startDate) body.startDate = parameters.startDate;
    return rp.post(url, {
      body,
      json: true,
      rejectUnauthorized: this.checkReportCertificate
    });
  }

  async createCyberDeltaReport(orgId, token, reportId, parameters = {}) {
    let where = {};
    if (parameters.where) where = parameters.where;
    const url = `${this.reportUrl}/api/cyberDeltaReport/create`;
    const data = await sequelize.query(`select * from (select date_trunc('day', scan.created_at) as date,
      ROW_NUMBER()
    over ( order by date_Trunc('day', scan.created_at) desc ) rownum
    from daily_scan_xccdf_results scan join assets a on scan.asset_id = a.id where a.organization_id = 0
    group by date_Trunc('day',scan.created_at)) t where t.rownum <= 2`, { type: QueryTypes.SELECT });
    const [endDate, startDate] = data.map(obj => obj.date);
    parameters.startDate = startDate;
    parameters.endDate = endDate;
    const body = { orgId, token, startDate, endDate, where, reportType: 'Cyber Delta Report', reportId };
    return rp.post(url, {
      body,
      json: true,
      rejectUnauthorized: this.checkReportCertificate
    });
  }

  async createComplianceDeltaReport(orgId, token, regulation, reportId, parameters = {}) {
    let where = {};
    if (parameters.where) where = parameters.where;
    const url = `${this.reportUrl}/api/complianceDeltaReport/create`;

    const data = await sequelize.query(`select * from (select date_trunc('day', scan.created_at) as date,
      ROW_NUMBER()
    over ( order by date_Trunc('day', scan.created_at) desc ) rownum
    from daily_scan_xccdf_results scan join assets a on scan.asset_id = a.id where a.organization_id = 0
    group by date_Trunc('day',scan.created_at)) t where t.rownum <= 2`, { type: QueryTypes.SELECT });
    let [endDate, startDate] = data.map(obj => obj.date);
    if (!startDate) startDate = moment(endDate).subtract(7, 'days').toDate();
    parameters.startDate = startDate;
    parameters.endDate = endDate;
    const body = {
      orgId,
      token,
      startDate,
      endDate,
      regulation,
      where,
      reportType: 'Compliance Delta Report',
      reportId
    };
    return rp.post(url, {
      body,
      json: true,
      rejectUnauthorized: this.checkReportCertificate
    });
  }

  async scheduleReportJob(orgId, params) {
    const typeName = params.type_name;
    const cronExpression = params.cron_expression;
    const organization = await Organization.findOne({ where: { id: orgId } });
    if (!organization) {
      const err = new Error('Organization not found.');
      err.status = 404;
      throw err;
    }
    if (!params.email) {
      logger.warn(params, 'the params');
      const err = new Error('Invalid value for email field');
      err.status = 400;
      throw err;
    }
    const orgName = organization.name;
    let argumentsJson;
    const email = params.email ? params.email : 'null';
    if (typeName.toLowerCase() === 'audit report') {
      const applicationId = params.applicationId ? params.applicationId : 'null';
      const regulation = params.regulation ? params.regulation : 'null';

      argumentsJson = {
        applicationId,
        regulation,
        email
      };
    } else if (typeName.toLowerCase() === 'compliance report' || typeName.toLowerCase() === 'compliance delta report') {
      const regulation = params.regulation ? params.regulation : 'null';

      argumentsJson = {
        regulation,
        email
      };
    } else if (typeName.toLowerCase() === 'cyber risk report' || typeName.toLowerCase() === 'cyber risk delta report') {

      argumentsJson = {
        email
      };
    } else {
      argumentsJson = {
        email
      };
    }
    params.parameters = JSON.stringify(argumentsJson);
    params.org_name = orgName;
    const reportType = await ReportType.findOne({ where: { name: typeName, $or: [{ is_active: { $ne: 'false' } }] } });
    if (!reportType) {
      const err = new Error(`Report type ${typeName} not found.`);
      err.status = 404;
      throw err;
    }
    params.job_id = '0';
    params.org_id = orgId;
    params.type = 'reports';
    params.report_type_id = reportType.id;

    let finalData;
    if (params.schedule_id) {
      await ScheduleTask.update(params, { where: { id: params.schedule_id } });
      finalData = await ScheduleTask.findOne({ where: { id: params.schedule_id } });
      await this.scheduleReportCron('delete', { token:params.token,user_id:params.user_id,orgId:params.org_id,id:params.schedule_id,name:params.name,cronExpression:params.cron_expression,reportId:params.report_id });
    } else {
      finalData = await ScheduleTask.create(params);
    }
    await this.scheduleReportCron('create', { token:params.token,user_id:params.user_id,orgId:params.org_id,id:finalData.id,name:params.name,cronExpression:params.cron_expression,reportId:params.report_id });
    return finalData;
  }

  async getNetworkFlowsReport(orgId, token, date, reportId, parameters = {}) {
    let where = {};
    if (parameters.where) where = parameters.where;
    const url = `${this.reportUrl}/api/netflowsReport/create`;
    const body = { orgId, token, reportId, where, reportType: 'Netflows Report' };
    return rp.post(url, {
      body,
      json: true,
      rejectUnauthorized: this.checkReportCertificate
    });
  }

  async getPolicyRiskPageReport(orgId, token, applicationId, date, reportId, parameters = {}) {
    let where = {};
    if (parameters.where) where = parameters.where;
    const url = `${this.reportUrl}/api/securityPoliciesReport/create`;
    const body = { orgId, token, reportId, applicationId, where, reportType: 'Security Policies Report' };
    return rp.post(url, {
      body,
      json: true,
      rejectUnauthorized: this.checkReportCertificate
    });
  }

  async scheduleReportCron(mode, params){
    try {
      let ccUrl = await CentralCollectorClient.getCentralCollectorAddress();
      if (!ccUrl) {
        const err = new Error('No Central Collector Available. Please Contact your Caveonix Administrator');
        err.status = 400;
        throw err;
      }
      if(mode === 'create'){
        ccUrl = ccUrl + '/centralcollector/api/V1/schedule/report/create?userToken=' + params.token + '&userId=' + params.user_id + '&orgId=' + params.orgId + '&id=' + params.id + '&jobName=' + params.name + '&cronExp=' + params.cronExpression + '&reportId=' + params.reportId;
      } else if(mode === 'delete') {
        ccUrl = ccUrl + '/centralcollector/api/V1/deleteScheduleJob/?userToken=' + params.token + '&userId=' + params.user_id + '&orgId=' + params.orgId + '&jobName=' + params.name + '&id=' + params.id + '&reportId=' + params.reportId;
      }
      const response = await rp({
        url: ccUrl,
        method: 'POST',
        resolveWithFullResponse: true,
        timeout: 100000,
        rejectUnauthorized: this.checkReportCertificate
      });
      if (response.statusCode === 200 || response.statusCode === 202) {
        logger.info('Status: ' + response.statusCode + ' Status Message: Success');
      } else {
        logger.info('Status: ' + response.statusCode + ' Status Message: Failed');
      }
      return response;
    } catch (error) {
      const err = new Error('CentralCollector request error' + error);
      err.status = 400;
      throw err;
    }

  }

  async getReportHistory(orgId, reportId) {
    const orgChain = await Organization.getOrgChain(orgId);
    return ReportResults.findAll({ where: { reportId, organizationId:orgChain }, attributes:['id','reportId','organizationId','scheduleId','name','created_at'], order: [['created_at', 'DESC']] });
  }

  async viewReportHistory(orgId, reportId, resultId) {
    const orgChain = await Organization.getOrgChain(orgId);
    const reportResult = await ReportResults.findOne({ where:{ id:resultId, reportId, organizationId:orgChain }, attributes:['id','name','reportId','scheduleId','resultBin','result'] });
    if (!reportResult) {
      logger.error({ does_reportResult_exist: !!reportResult }, 'reportResult not found or data does not exist');
      const e = new Error('reportResult Not Found');
      e.status = 400;
      throw e;
    }
    const data = reportResult.resultBin ? { result: reportResult.resultBin, type: 'application/zip' } : { result: JSON.parse(reportResult.result), type: 'application/json' };
    return { name: `${reportResult.name}.zip`, data: data.result, type: data.type };
  }

};

// max date
// select * from (select date_trunc('day', scan.created_at) as date,
// ROW_NUMBER()
// over ( order by date_Trunc('day', scan.created_at) desc ) rownum
// from daily_scan_xccdf_results scan join assets a on scan.asset_id = a.id where a.organization_id = 0
// group by date_Trunc('day',scan.created_at)) t where t.rownum <= 2
