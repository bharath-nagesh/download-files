const cronValidator = require('../../../utils/cronValidator');
const errorHandler = require('../../../utils/errorHandler');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-internal.controller'
});
const ReportService = require('./report.service');
const reportService = new ReportService();
const fs = require('fs');

module.exports = class ReportController {
  async getReportTypes(req, res) {
    const data = await reportService.getReportTypes();
    return res.json(data);
  }

  async getReportById(req, res) {
    const reportId = req.params.reportId;
    const orgId = req.params.orgId;
    try {
      const report = await reportService.getReportById(orgId, reportId);
      return res.json(report);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getReports(req, res) {
    const orgId = req.params.orgId;
    try {
      const reports = await reportService.getReports(orgId);
      return res.json(reports);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async emailReport(req, res) {
    const orgId = req.params.orgId;
    const reportId = req.params.reportId;
    const email = req.body.email;
    try {
      await reportService.emailReport(orgId, reportId, email);
      return res.sendStatus(204);
    } catch (error) {
      logger.error({ error, stack: error.stack });
      return errorHandler(req, res, error);
    }
  }

  async viewReport(req, res) {
    const orgId = req.params.orgId;
    const reportId = req.params.reportId;
    try {
      const { name, data, type } = await reportService.viewReport(orgId, reportId);
      if (Buffer.isBuffer(data)) {
        res.setHeader('Content-disposition', `inline;filename="${name}"`);
        res.setHeader('Content-type', type);
        return res.send(data);

      } else {
        res.setHeader('Content-disposition', `inline;filename="${name}"`);
        res.setHeader('Content-type', type);
        res.send(data);
      }
    } catch (error) {
      logger.error({ error, stack: error.stack });
      return errorHandler(req, res, error);
    }
  }

  async scheduleReport(req, res) {
    const reportId = req.params.reportId;
    const orgId = req.params.orgId;
    const cronExpression = req.body.cronExpression;
    const email = req.body.email;
    const userId = req.user.id;
    const token = req.authInfo;
    try {
      cronValidator(cronExpression);
      await reportService.scheduleReport(orgId, reportId, cronExpression, userId, token, email);
      return res.sendStatus(204);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async updateReport(req, res) {
    const reportId = req.params.reportId;
    const orgId = req.params.orgId;
    const update = req.body;
    const where = req.body.where;
    let token = req.headers.authorization || req.authInfo;
    token = token.replace('bearer ', '');
    token = token.replace('Bearer ', '');
    try {
      const report = await reportService.updateReport(orgId, reportId, update, where, token);
      return res.json(report);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async deleteReports(req, res) {
    const reportIds = req.query.id || [];
    const orgId = req.params.orgId;
    const userId = req.user.id;
    const token = req.authInfo;
    try {
      await reportService.deleteReports(orgId, userId, token, reportIds);
      return res.sendStatus(204);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async createReport(req, res) {
    const reportType = req.body.reportType;
    const where = req.body.where;
    const filter = req.body.filter;
    let token = req.headers.authorization || req.authInfo;
    token = token.replace('bearer ', '');
    token = token.replace('Bearer ', '');
    const orgId = req.params.orgId;
    const endDate = req.body.endDate;
    const startDate = req.body.startDate;
    const userId = req.user.id;
    const name = req.body.name || `${reportType} for ${orgId}`;
    const regulation = req.body.regulation;
    const applicationId = req.body.applicationId;
    const parameters = { regulation, startDate, endDate, applicationId, filter, where };
    let report;
    try {
      report = await reportService.startReportCreation(orgId, userId, reportType, name, parameters);
      res.json(report);
    } catch (e) {
      return errorHandler(req, res, e);
    }
    try {
      await reportService.createReportByType(reportType, orgId, token, parameters, report.id);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      if (error.message.toLowerCase().includes('no data')) {
        report.statusDetail = 'No Data';
        report.status = 'Error';
      }
      if (error.message.toLowerCase().includes('no assigned controls')) {
        report.status = 'Error';
        report.statusDetail = 'No Assigned Controls';
      } else {
        report.result = null;
        report.resultBin = null;
        report.status = 'Error';
      }
      report.save();
      return res.finished ? null : res.json(report);
    }
  }

  async createScheduledReport(req, res){
    const orgId = req.body.orgId;
    const reportId = req.body.reportId;
    let token = req.headers.authorization || req.authInfo;
    token = token.replace('bearer ', '');
    token = token.replace('Bearer ', '');
    const report = await reportService.getReportById(orgId, reportId);
    const reportType = report.ReportType.name;
    const parameters = report.parameters;
    const data = await reportService.createReportByType(reportType, orgId, token, parameters, reportId);
    return res.json(data);
  }

  async getReportHistory(req, res) {
    const orgId = req.params.orgId;
    const reportId = req.params.reportId;
    try {
      const reports = await reportService.getReportHistory(orgId, reportId);
      return res.json(reports);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async viewReportHistory(req, res) {
    const orgId = req.params.orgId;
    const reportId = req.params.reportId;
    const resultId = req.params.resultId;
    try {
      const { name, data, type } = await reportService.viewReportHistory(orgId, reportId, resultId);
      if (Buffer.isBuffer(data)) {
        res.setHeader('Content-disposition', `inline;filename="${name}"`);
        res.setHeader('Content-type', type);
        return res.send(data);
      } else {
        res.setHeader('Content-disposition', `inline;filename="${name}"`);
        res.setHeader('Content-type', type);
        res.send(data);
      }
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }
};
