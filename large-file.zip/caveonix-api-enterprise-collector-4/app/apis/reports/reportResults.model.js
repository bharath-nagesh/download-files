const Sequelize = require('sequelize');

class ReportResults extends Sequelize.Model {
  /**
   * @swagger
   * components:
   *   schemas:
   *     Certificate:
   *       type: object
   *       required:
   *         - name
   *       properties:
   *         id:
   *           type: integer
   *         name:
   *           type: string
   * @param sequelize
   */
  static init(sequelize) {
    return super.init({
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      userId: { type: Sequelize.INTEGER, field: 'user_id' },
      organizationId: { type: Sequelize.INTEGER, field: 'organization_id' },
      name: { type: Sequelize.STRING, field: 'name' },
      reportTypeId: { type: Sequelize.INTEGER, field: 'report_type_id' },
      reportId: { type: Sequelize.INTEGER, field: 'report_id' },
      scheduleId: { type: Sequelize.INTEGER, field: 'schedule_id', allowNull: true },
      status: { type: Sequelize.STRING, field: 'status' },
      parameters: { type: Sequelize.STRING, field: 'parameters', allowNull: true },
      result: { type: Sequelize.STRING, field: 'result', allowNull: true },
      resultBin: { type: Sequelize.BLOB, field: 'result_bin', allowNull: true }
    },
    {
      sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'report_results',
      underscored: true
    });
  }

  static associate(models) {
    ReportResults.belongsTo(models.Report, { foreignKey: 'report_id' });
    ReportResults.belongsTo(models.Organization, { foreignKey: 'organization_id' });
    ReportResults.belongsTo(models.User, { foreignKey: 'user_id' });
    ReportResults.belongsTo(models.ReportType, { foreignKey: 'report_type_id' });
    ReportResults.belongsTo(models.ScheduleTask, { foreignKey: 'schedule_id' });
  };

}

module.exports = ReportResults;
