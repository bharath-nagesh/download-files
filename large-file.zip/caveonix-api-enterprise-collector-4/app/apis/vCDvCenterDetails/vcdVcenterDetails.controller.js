const checkId = require('../../../utils/checkId');
const checkName = require('../../../utils/checkName');
const errorHandler = require('../../../utils/errorHandler');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-application.controller'
});
const paginate = require('../../middlewares/paginate.middleware');
const VcdVcenterDetailsService = require('./vcdVcenterDetails.service');
const vcdVcenterDetailsService = new VcdVcenterDetailsService();

module.exports = class VcdVCenterDetailsController {
  async getVcdVcenterDetailsByOrgId(req, res) {
    const orgId = req.params.serviceProviderId;
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    const assetRepoId = req.query.assetRepoId ? req.query.assetRepoId : null;
    try{
      const results = await vcdVcenterDetailsService.getAllVcdVcenterDetails(orgId, limit, offset, assetRepoId);
      const itemCount = await vcdVcenterDetailsService.getVcdVcenterDetailsCount(orgId, assetRepoId);
      const pageCount = Math.ceil(itemCount / limit);
      res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        applicationTags: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getVcdVcenterDetailsById(req, res) {
    const vcdVcenterDetailId = req.params.vcdVcenterDetailId;
    const orgId = req.params.serviceProviderId;
    if (checkId(vcdVcenterDetailId)) {
      logger.error({ vcdVcenterDetailId }, 'Bad ApplicationTag Id');
      const error = new Error('Bad ApplicationTag Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try{
      const applicationTag = await vcdVcenterDetailsService.getVcdVcenterDetails(vcdVcenterDetailId, orgId);
      if (!applicationTag) {
        return res.sendStatus(404);
      }
      return res.json(applicationTag);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getVcdVcenterDetailsByName(req, res) {
    const vcdVcenterDetailName = req.params.vcdVcenterDetailName;
    const orgId = req.params.serviceProviderId;
    if (checkName(vcdVcenterDetailName)) {
      logger.error({ vcdVcenterDetailName }, 'Bad vcdVcenterDetail Name');
      const error = new Error('Bad vcdVcenterDetail Name');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try{
      const vcdVcenterDetail = await vcdVcenterDetailsService.getVcdVcenterDetailsByName(vcdVcenterDetailName, orgId);
      if (!vcdVcenterDetail) {
        return res.sendStatus(404);
      }
      return res.json(vcdVcenterDetail);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async updateVcdVcenterDetails(req, res) {
    const vcdVcenterDetailId = req.params.vcdVcenterDetailId;
    const orgId = req.params.serviceProviderId;
    const update = req.body;
    if (checkId(vcdVcenterDetailId)) {
      logger.error({ vcdVcenterDetailId }, 'Error with ApplicationTag Id');
      const error = new Error('Error with ApplicationTag Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try{
      const vcdVcenterDetail = await vcdVcenterDetailsService.updateVcdVcenterDetailsById(vcdVcenterDetailId, update, orgId);
      if (vcdVcenterDetail) {
        const result = await vcdVcenterDetailsService.getVcdVcenterDetailsId(vcdVcenterDetailId, orgId);
        return res.json(result);
      }
      return res.json(vcdVcenterDetail);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async createVcdVcenterDetails(req, res) {
    const params = req.body;
    try{
      const vcdVcenterDetail = await vcdVcenterDetailsService.createVcdVcenterDetails(params);
      return res.json(vcdVcenterDetail);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }
};
