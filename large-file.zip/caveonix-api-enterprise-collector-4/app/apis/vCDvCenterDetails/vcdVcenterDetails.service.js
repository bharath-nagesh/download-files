const vcdVcenterDetails = require('../../models/vcdVcenterDetails.model');
const sequelize = require('sequelize');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-vcdVcenterDetails.service'
});
const _ = require('lodash');

module.exports = class VcdVcenterDetailsService {
  constructor() {
    logger.debug('called constructor');
  }

  getAllVcdVcenterDetails(orgId, limit, offset, assetRepoId = null) {
    const options = {
      order: [['id', 'ASC']],
      limit: limit,
      offset: offset,
      include: [{ all: true }]
    };
    if(assetRepoId) options.where = { asset_repo_endpoint_vcd_id : assetRepoId };
    return vcdVcenterDetails.findAll(options);
  }

  getVcdVcenterDetailsCount(orgId, assetRepoId = null) {
    const options = {};
    if(assetRepoId) options.where = { asset_repo_endpoint_vcd_id : assetRepoId };
    return vcdVcenterDetails.count(options);
  }

  async getVcdVcenterDetails(vcdVcenterDetailId, orgId) {
    const vcdVDetails = await vcdVcenterDetails.findAll({
      where: { asset_repo_endpoint_vcd_id: vcdVcenterDetailId },
      include: [{ all: true }]
    });
    const newArr1 = [];
    let ctr1 = 0;
    const chain = [];
    let ctr2 = 0;
    _.map(vcdVDetails, function (a) {
      if (newArr1.length === 0) { // added first element in array
        newArr1[ctr1] = a;
        ctr1++;
        chain[ctr1] = a.vcenter_url;
        ctr2++;
      }
      if (!chain.includes(a.vcenter_url)) { // to check vcenter_url already exist in array if not then add new one
        newArr1[ctr1] = a;
        ctr1++;
        chain[ctr1] = a.vcenter_url;
        ctr2++;
      } else { // vcenter_url already exist in array then append just id with existing record of array
        let ctr3 = 0;
        _.map(newArr1, function (b) {
          if (b.vcenter_url === a.vcenter_url && b.id !== a.id) {
            const append = newArr1[ctr3].id + ',' + a.id;
            newArr1[ctr3].dataValues = _.set(newArr1[ctr3].dataValues, 'id', append);
          }
          ctr3++;
        });
      }
    });
    return newArr1;
  }

  getVcdVcenterDetailsId(vcdVcenterDetailId, orgId) {
    return vcdVcenterDetails.findOne({
      where: { id: vcdVcenterDetailId },
      include: [{ all: true }]
    });
  }

  updateVcdVcenterDetailsById(vcdVcenterDetailId, update, orgId) {
    return vcdVcenterDetails.update(update, {
      where: { id: vcdVcenterDetailId }
    });
  }

  getVcdVcenterDetailsByName(vcdVcenterDetailName) {
    return vcdVcenterDetails.findOne({
      where: { vcenter_url: sequelize.where(sequelize.fn('LOWER', sequelize.col('vcenter_url')), sequelize.fn('lower', vcdVcenterDetailName)) },
      include: [{ all: true }]
    });
  }

  checkUrlNameForUpdate(urlName, vcdVcenterDetailId) {
    return vcdVcenterDetails.findOne({
      where: {
        vcenter_url: sequelize.where(sequelize.fn('LOWER', sequelize.col('vcenter_url')), sequelize.fn('lower', urlName)),
        id: { $ne: vcdVcenterDetailId }
      }
    });
  }

  async createVcdVcenterDetails(params) {
    const createdRecords = [];
    let i;
    for (i = 0; i < params.length; i++) {
      const data = params[i];
      const url = data.vcenter_url;
      const existingRecord = await vcdVcenterDetails.findOne({ where: { vcenter_url: sequelize.where(sequelize.fn('LOWER', sequelize.col('vcenter_url')), sequelize.fn('lower', url)) } });
      if (!existingRecord) {
        const createdResult = await vcdVcenterDetails.create(data);
        createdRecords.push(createdResult);
      }
    }
    return createdRecords;
  }
};
