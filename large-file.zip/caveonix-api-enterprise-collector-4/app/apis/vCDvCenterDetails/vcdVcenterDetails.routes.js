const VcdVcenterDetailsController = require('./vcdVcenterDetails.controller');

/**
 * @swagger
 * tags:
 *  - name: VcdVcenterDetails
 *    description: vCD vCenter Details endpoints
 */
module.exports = class VcdVcenterDetailsRoutes {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.vCDvCenterDetailsController = new VcdVcenterDetailsController();

      // initializing route
      if (type === 'Service Provider') {
        this.initServiceProvider();
      } else {
        this.initOrganization();
      }
    }
  }

  initOrganization() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/vcdVcenterDetails:
     *   get:
     *     tags:
     *       - VcdVcenterDetails
     *     summary: Gets a list of vCD vCenter Details
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of policy groups
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/`, this.vCDvCenterDetailsController.getVcdVcenterDetailsByOrgId);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/vcdVcenterDetails/{vcdVcenterDetailId}:
     *   get:
     *     tags:
     *       - VcdVcenterDetails
     *     summary: Gets a vCDvCenterDetails by it's id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: vcdVcenterDetailId
     *         description: The id of the specified vCD vCenter Details.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: vCDvCenterDetails
     */
    this.router.get(`${this.path}/:vcdVcenterDetailId`, this.vCDvCenterDetailsController.getVcdVcenterDetailsById);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/vcdVcenterDetails:
     *   post:
     *     tags:
     *       - VcdVcenterDetails
     *     summary: Creates a vCD vCenter Details
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: vCDvCenterDetailsId
     *         description: The id of the specified vCD vCenter Details.
     *         in: path
     *         required: true
     *         type: string
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/VcdVcenterDetails'
     *     responses:
     *       200:
     *         description: vCDvCenterDetails
     */
    this.router.post(`${this.path}/`, this.vCDvCenterDetailsController.createVcdVcenterDetails);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/vcdVcenterDetails/{vcdVcenterDetailId}:
     *   put:
     *     tags:
     *       - VcdVcenterDetails
     *     summary: Updates a vCD vCenter Details
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: vCDvCenterDetailsId
     *         description: The id of the specified vCD vCenter Details.
     *         in: path
     *         required: true
     *         type: string
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/VcdVcenterDetails'
     *     responses:
     *       200:
     *         description: vCDvCenterDetails
     */
    this.router.put(`${this.path}/:vcdVcenterDetailId`, this.vCDvCenterDetailsController.updateVcdVcenterDetails);


  }

  initServiceProvider() {
    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/vcdVcenterDetails:
     *   get:
     *     tags:
     *       - VcdVcenterDetails
     *     summary: Gets a list of all vcd vcenter details
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: VcdVcenterDetails
     */
    this.router.get(`${this.path}/`, this.vCDvCenterDetailsController.getVcdVcenterDetailsByOrgId);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/vcdVcenterDetails/{vcdVcenterDetailId}:
     *   get:
     *     tags:
     *       - VcdVcenterDetails
     *     summary: Gets a vCD vCenter Details by it's id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: vcdVcenterDetailId
     *         description: The id of the specified vCD vCenter Details.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: vCDvCenterDetails
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/:vcdVcenterDetailId`, this.vCDvCenterDetailsController.getVcdVcenterDetailsById);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/vcdVcenterDetails:
     *   post:
     *     tags:
     *       - VcdVcenterDetails
     *     summary: Creates a vCD vCenter Details
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/VcdVcenterDetails'
     *     responses:
     *       200:
     *         description: vCD vCenter Details
     *       400:
     *          description: Bad Request
     */
    this.router.post(`${this.path}`, this.vCDvCenterDetailsController.createVcdVcenterDetails);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/organization/{orgId}/vCDvCenterDetails/{vcdVcenterDetailId}:
     *   put:
     *     tags:
     *       - VcdVcenterDetails
     *     summary: Updates a vCD vCenter Details
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: vcdVcenterDetailId
     *         description: The id of the specified vCDvCenterDetails.
     *         in: path
     *         required: true
     *         type: string
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/VcdVcenterDetails'
     *     responses:
     *       200:
     *         description: vCD vCenter Details
     *       400:
     *          description: Bad Request
     */
    this.router.put(`${this.path}/:vcdVcenterDetailId`, this.vCDvCenterDetailsController.updateVcdVcenterDetails);


  }
};
