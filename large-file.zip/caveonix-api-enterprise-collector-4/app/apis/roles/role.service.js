const checkId = require('../../../utils/checkId');
const db = require('../../../config/db.conf').getAllModels();
const sequelize = require('../../../config/db.conf').getConnection();
db.sequelize = sequelize;
const removeSpace = require('../../../utils/checkSpaces');
const Role = require('./role.model');
const Organization = require('../organization/organization.model');
const User = require('../user/user.model');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-role.service'
});

module.exports = class RoleService {
  constructor(services) {
    this.services = services;
    logger.debug('called RoleService constructor');
  }

  getRole(roleId, orgId, opts = null) {
    if (opts == null) {
      opts = {
        where: {
          organization_id: { $in: [orgId, null] }
        },
        include: [{ all: true }]
      };
    }
    return db.Role.findByPk(roleId, opts);
  }

  async getAllRoles(orgId) {
    let roleType;
    const orgInfo = await Organization.findByPk(orgId);
    if (orgInfo.type === 'Provider' || orgInfo.type === 'SaaSProvider') {
      roleType = 1;
    } else if (orgInfo.type === 'Organization') {
      roleType = 3;
    } else {
      roleType = 4;
    }
    return Role.findAll({
      includeIgnoreAttributes: false,
      attributes: ['id', 'isActive', 'description', 'name', [sequelize.fn('count', sequelize.col('Users.id')), 'userCount']],
      where: { isActive: ['true', 'enabled', 'disabled'], roleType: { $gte: roleType } },
      include: [{ model: User, attributes: [], through: { attributes: [] } }, { model: Organization }],
      group: ['Role.id', 'Role.is_active', 'Role.description', 'Role.name']
    });
    // const sqlVar = 'roles.is_active=' + '\'true\'' + ' or roles.is_active=' + '\'enabled\'' + ' or roles.is_active=' + '\'disabled\'' + '';
    // let result = await db.sequelize.query(`select roles.id,roles.name,roles.description,roles.organization_id,roles.role_type,roles.is_active,COALESCE(count(role_id), 0) as user_count
    //   from roles,org_user_role_members INNER JOIN users ON org_user_role_members.user_id=users.id
    //   where (users.is_active!='false')
    //   and org_user_role_members.role_id=roles.id and (` + roleTypeSqlVar + `) and (` + sqlVar + `)
    //   group by roles.name,roles.is_active,roles.id,roles.description,roles.organization_id,roles.role_type
    //   union
    //   select roles.id,roles.name,roles.description,roles.organization_id,roles.role_type,roles.is_active,0 as user_count
    //   from roles where id not in (select role_id from org_user_role_members ) and (` + roleTypeSqlVar + `) and (` + sqlVar + `)
    //   group by roles.name,roles.is_active,roles.id,roles.description,roles.organization_id,roles.role_type order by name ASC limit :limit offset :offset`, {
    //   replacements: { roleType, limit, offset },
    //   type: db.sequelize.QueryTypes.SELECT
    // });
    //
    // let idArr = result.map((a) => {
    //   return a.id;
    // });
    // let RMPermission = await db.RoleModulePermission.findAll({ where: { role_id: { $in: idArr } } });
    // let idArr1 = result.map((b) => {
    //   let idArr3 = RMPermission.map((c) => {
    //     if (b.id === c.role_id) {
    //       return c.dataValues;
    //     }
    //   });
    //   b = _.set(b, 'roleModulePermission', idArr3);
    //   return b;
    // });
    // return idArr1;
  }

  async getRoleActions(roleId, orgId) {
    const opts = { include: [{ model: db.Module, as: 'Modules' }] };
    let role = await this.getRole(roleId, orgId, opts);
    const permissions = role.Modules.map(m => {
      return { id: m.id, name: m.name, permission: m.RoleModulePermission.permission };
    });
    role = role.toJSON();
    delete role.Modules;
    role.permissions = permissions;
    logger.info({ role }, 'Role post permissions');
    return role;
  }

  async createRole(orgId, name, description, isActive, modulePermissions = []) {
    let roleType = 3;
    const newName = removeSpace.checkMultiSpace(name);
    const exists = await this.checkName(newName);

    if (exists) {
      logger.error({ newName }, 'Duplicate role name');
      const err = new Error('Duplicate role name');
      err.status = 400;
      throw err;
    }
    modulePermissions.map(modulePermission => {
      if (modulePermission.moduleId < 2) {
        roleType = 1;
      }
    });
    name = newName;
    const role = await db.Role.create({
      name,
      description,
      organization_id: orgId,
      roleType: roleType,
      isActive: isActive
    });

    const actions = modulePermissions.map(async modulePermission => {
      const mod = await db.Module.findByPk(modulePermission.moduleId);
      mod.RoleModulePermission = { permission: modulePermission.permissions };
      logger.info({ mod }, 'the module');
      return role.addModule(mod);

    });
    await Promise.all(actions);
    return role;

  }

  validateModulePermissions(modulePermissions = []) {
    logger.info(modulePermissions, 'Mod permissions being validated');
    const validArray = modulePermissions.map(mod => {
      mod.permissions = removeDuplicateCharacters(mod.permissions);
      if (checkId(mod.moduleId)) {
        logger.info({ id: mod.moduleId }, 'Invalid Module Id');
        return false;
      }
      if (this.checkPermissionString(mod.permissions)) {
        logger.info({ string: mod.permissions }, 'Invalid permission string');
        return false;
      }
      return true;
    });
    return validArray.every(elem => {
      return elem;
    });
  }

  checkPermissionString(permissionString) {
    const regex = /[^(CRUD)]/g;

    const m = permissionString.match(regex);
    return m !== null;
  }

  async updateRole(roleId, orgId, name, description, isActive, modulePermissions = []) {
    const newName = removeSpace.checkMultiSpace(name);
    logger.info({ roleId }, 'roleId');
    const exists = await this.checkNameForUpdate(newName, roleId);
    if (exists) {
      logger.error({ newName }, 'Duplicate role name');
      const err = new Error('Duplicate role name');
      err.status = 400;
      throw err;
    }
    if (!orgId) {
      logger.error({ orgId }, 'Action forbidden: not allowed to update Role');
      const err = new Error('Action forbidden: not allowed to update Role');
      err.status = 400;
      throw err;
    }
    const role = await db.Role.findByPk(roleId, { where: { organization_id: orgId } });

    if ((!role.organization_id && role.organization_id === 0) || role.organization_id == null) {
      logger.error('Cannot update a Default Role');
      const err = new Error('Cannot update a Default Role');
      err.status = 400;
      throw err;
    }
    const actions = modulePermissions.map(async modulePermission => {
      const mod = await db.Module.findByPk(modulePermission.moduleId);
      mod.RoleModulePermission = { permission: modulePermission.permissions };
      logger.info({ mod }, 'the module');
      return mod;
    });

    const mods = await Promise.all(actions);
    logger.info({ role }, 'role');
    await role.setModules(mods);
    name = newName;
    if (name) role.name = name;
    if (description) role.description = description;
    if (isActive) role.isActive = isActive;
    role.roleType = 3;
    modulePermissions.map(modulePermission => {
      if (modulePermission.moduleId < 2) role.roleType = 1;
    });
    return role.save();
  }

  async deleteRole(roleId, orgId) {
    await db.Role.update({ isActive: false }, { where: { id: roleId } });
    const orgMember = await db.OrgMembers.findAll({ where: { role_id: roleId } });
    const newArr = orgMember.map(object => {
      return object.dataValues.user_id;
    });
    await db.User.update({ isActive: false }, { where: { id: { $in: newArr } } });
    return db.Role.findAll({ where: { id: roleId }, include: [{ all: true }] });
  }

  async deleteMultipleRole(roleIdArr) {
    await db.Role.update({ isActive: false }, { where: { id: { $in: roleIdArr } } });
    const orgMember = await db.OrgMembers.findAll({ where: { role_id: { $in: roleIdArr } } });
    const newArr = orgMember.map(object => {
      return object.dataValues.user_id;
    });
    await db.User.update({ isActive: false }, { where: { id: { $in: newArr } } });
    return db.Role.findAll({ where: { id: { $in: roleIdArr } }, include: [{ all: true }] });
  }

  getModuleList(limit, offset) {
    return db.Module.findAll({ order: [['id', 'ASC']], limit: limit, offset: offset });
  }

  getModuleCount() {
    return db.Module.count();
  }

  destroy(params) {
    return db.Role.destroy({ where: params });
  }

  async getUsersByRoleId(roleId, orgId) {
    const orgMember = await db.OrgMembers.findAll({ where: { role_id: roleId } });
    const newArr = orgMember.map(object => {
      return object.dataValues.user_id;
    });
    return db.User.findAll({ where: { id: { $in: newArr } } });
  }

  checkName(name) {
    return db.Role.findOne({
      where: {
        name: sequelize.where(sequelize.fn('LOWER', sequelize.col('name')), sequelize.fn('lower', name)),
        $or: [{ isActive: { $ne: 'false' } }]
      }
    });
  }

  checkNameForUpdate(name, roleId) {
    return db.Role.findOne({
      where: {
        name: sequelize.where(sequelize.fn('LOWER', sequelize.col('name')), sequelize.fn('lower', name)),
        $or: [{ isActive: { $ne: 'false' } }],
        id: { $ne: roleId }
      }
    });
  }
};

// todo figure out why this is here
function removeDuplicateCharacters(string) {
  return string
    .split('')
    .filter(function (item, pos, self) {
      return self.indexOf(item) === pos;
    })
    .join('');
}
