const Sequelize = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-role.model'
});
const User = require('../user/user.model');

/**
 * @swagger
 * components:
 *   schemas:
 *     Role:
 *       type: object
 *       required:
 *         - name
 *         - description
 *         - roleType
 *         - isActive
 *       properties:
 *         name:
 *           type: string
 *         description:
 *           type: string
 *         roleType:
 *           type: integer
 *         isActive:
 *           type: string
 * @param sequelize
 */
class Role extends Sequelize.Model {
  static init(sequelize) {
    return super.init({
      name: { type: Sequelize.STRING },
      description: { type: Sequelize.STRING },
      roleType: { type: Sequelize.INTEGER, field: 'role_type', defaultValue: 3 },
      isActive: { type: Sequelize.STRING, field: 'is_active', defaultValue: true },
      is_active: { type: Sequelize.STRING, field: 'is_active' }
    },
    {
      sequelize,
      timestamps: false,
      freezeTableName: true,
      tableName: 'roles',
      underscored: true
    }
    );
  }

  static associate(models) {
    Role.belongsToMany(models.Module, { as: 'Modules', through: models.RoleModulePermission });
    Role.belongsTo(models.Organization, { allowNull: true });
    Role.belongsToMany(models.User, { through: models.OrgMembers });
    Role.belongsToMany(models.Organization, { through: models.OrgMembers });

  }
}

module.exports = Role;
