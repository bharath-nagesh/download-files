const checkId = require('../../../utils/checkId');
const errorHandler = require('../../../utils/errorHandler');
const Validator = require('../../../utils/validator');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-role.controller'
});
const paginate = require('../../middlewares/paginate.middleware');
const RoleService = require('./role.service');
const roleService = new RoleService();

module.exports = class RoleController {
  async getRole(req, res) {
    const orgId = req.params.orgId;
    const roleId = req.params.roleId;
    if (checkId(roleId)) {
      logger.error({ roleId }, 'Error with Role Id');
      const error = new Error('Error with Role Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const role = await roleService.getRole(roleId, orgId);
      if (!role) {
        logger.error({ roleId }, 'Role Not Found');
        return res.sendStatus(404);
      }
      return res.json(role);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getAllRoles(req, res) {
    const orgId = isNaN(req.query.id) ? req.params.orgId : req.query.id;
    const userRole = req.user.Organizations[0].OrgMembers.role_id;
    const list = req.query.list ? req.query.list : 'true';
    const listParam = list.toLowerCase();
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    try {
      const results = await roleService.getAllRoles(orgId, userRole, listParam, limit, offset);
      const itemCount = await roleService.getAllRoles(orgId, userRole, listParam, null, null);
      const pageCount = Math.ceil(itemCount.length / limit);
      res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount.length,
        page_number: pageNumber,
        roles: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getModuleList(req, res) {
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    try {
      const results = await roleService.getModuleList(limit, offset);
      const itemCount = await roleService.getModuleCount();
      const pageCount = Math.ceil(itemCount / limit);
      res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        Modules: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getRoleActions(req, res) {
    const orgId = req.params.orgId;
    const roleId = req.params.roleId;
    if (checkId(roleId)) {
      logger.error({ roleId }, 'Error with Role Id');
      const error = new Error('Error with Role Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const role = await roleService.getRoleActions(roleId, orgId);
      logger.silly({ role }, 'role');
      if (!role) {
        logger.error({ roleId }, 'Role Not Found');
        return res.sendStatus(404);
      }
      return res.json(role);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async updateRole(req, res) {
    const orgId = req.params.orgId;
    const roleId = req.params.roleId;
    const name = req.body.name;
    const modulePermissions = req.body.modulePermissions;
    const description = req.body.description;
    const params = req.body;
    if (modulePermissions.length > 0) {
      const valid = roleService.validateModulePermissions(modulePermissions);
      if (!valid) {
        logger.info({ valid }, 'is valid');
        const error = new Error('Invalid ModulesPermissions Array');
        error.status = 400;
        return errorHandler(req, res, error);
      }
    }
    try {
      params.isActive = params.isActive ? params.isActive.toString().toLowerCase() : 'enabled';
      await Validator.validateParams({
        isActive: 'required|in:enabled,disabled,true'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const isActive = params.isActive;
    try {
      const role = await roleService.updateRole(roleId, orgId, name, description, isActive, modulePermissions);
      return res.json(role);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async createRole(req, res) {
    const orgId = req.params.orgId;
    const name = req.body.name;
    const modulePermissions = req.body.modulePermissions;
    const description = req.body.description;
    const params = req.body;
    logger.info({ name, modulePermissions, description }, 'params');
    if (modulePermissions.length > 0) {
      const valid = roleService.validateModulePermissions(modulePermissions);
      if (!valid) {
        logger.info({ valid }, 'Is Valid');
        const error = new Error('Invalid ModulesPermissions Array');
        error.status = 400;
        return errorHandler(req, res, error);
      }
    }
    try {
      params.isActive = params.isActive ? params.isActive.toString().toLowerCase() : 'enabled';
      await Validator.validateParams({
        isActive: 'required|in:enabled,disabled,true'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    const isActive = params.isActive;
    try {
      const role = await roleService.createRole(orgId, name, description, isActive, modulePermissions);
      return res.json(role);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async deleteRole(req, res) {
    const roleId = req.params.roleId;
    if (checkId(roleId)) {
      logger.error({ roleId }, 'Error with Role Id');
      const error = new Error('Error with Role Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const update = await roleService.deleteRole(roleId);
      return res.json(update);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async deleteMultipleRoles(req, res) {
    const roleId = req.query.roles;
    if (roleId === undefined || roleId === '') {
      logger.error('Invalid Input');
      const error = new Error('Invalid Input');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const roleIdArr = roleId.split(',');
      const update = await roleService.deleteMultipleRole(roleIdArr);
      return res.json(update);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async getUsersByRoleId(req, res) {
    const orgId = req.params.orgId;
    const roleId = req.params.roleId;
    if (checkId(roleId)) {
      logger.error({ roleId }, 'Error with Role Id');
      const error = new Error('Error with Role Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try {
      const role = await roleService.getUsersByRoleId(roleId, orgId);
      logger.silly({ role }, 'role');
      if (!role) {
        logger.error({ roleId }, 'Role Not Found');
        return res.sendStatus(404);
      }
      return res.json(role);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }
};
