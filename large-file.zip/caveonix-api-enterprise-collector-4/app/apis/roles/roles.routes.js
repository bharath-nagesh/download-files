const RoleController = require('./roles.controller');

/**
 * @swagger
 * tags:
 *  - name: Role
 *    description: Role endpoints
 */
module.exports = class RoleRouter {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.roleController = new RoleController();

      // initializing route
      if (type === 'Service Provider') {
        this.initServiceProvider();
      } else {
        this.initOrganization();
      }
    }
  }

  /**
   * Route initialization and setup
   */
  initOrganization() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/role:
     *   get:
     *     tags:
     *       - Role
     *     summary: Gets a list of all roles
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: get all roles
     *       401:
     *         description: unauthorized
     */
    this.router.get(`${this.path}/`, this.roleController.getAllRoles);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/role/{roleId}:
     *   get:
     *     tags:
     *       - Role
     *     summary: Gets an role by its id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: roleId
     *         description: The id of the specified role.
     *         in: path
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: Role
     *       401:
     *         description: unauthorized
     */
    this.router.get(`${this.path}/:roleId`, this.roleController.getRole);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/role/:
     *   post:
     *     tags:
     *       - Role
     *     summary: Creates an role
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/Role'
     *     responses:
     *       200:
     *         description: role was created successfully
     *       401:
     *         description: unauthorized
     */
    this.router.post(`${this.path}/`, this.roleController.createRole);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/role:
     *   put:
     *     tags:
     *       - Role
     *     summary: Updates the specified role
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/Role'
     *     responses:
     *       200:
     *         description: Role
     *       401:
     *         description: unauthorized
     */
    this.router.put(`${this.path}/:roleId`, this.roleController.updateRole);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/role/{roleId}:
     *   delete:
     *     tags:
     *       - Role
     *     summary: Deletes an role by its id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: roleId
     *         description: The id of the specified role.
     *         in: path
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: deleted role
     *       401:
     *         description: unauthorized
     */
    this.router.delete(`${this.path}/:roleId`, this.roleController.deleteRole);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/role/{roleId}/actions:
     *   get:
     *     tags:
     *       - Role
     *     summary: Gets an role's actions by its id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: roleId
     *         description: The id of the specified role.
     *         in: path
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: Role
     *       401:
     *         description: unauthorized
     */
    this.router.get(`${this.path}/:roleId/actions`, this.roleController.getRoleActions);

  }

  /**
   * Route initialization and setup
   */
  initServiceProvider() {
    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/role/{roleId}:
     *   get:
     *     tags:
     *       - Role
     *     summary: Gets a role by its id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: serviceProviderId
     *         description: The Service Provider's Id
     *         in: path
     *         required: true
     *         type: string
     *       - name: roleId
     *         description: The id of the specified role.
     *         in: path
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: login
     *       401:
     *         description: unauthorized
     */
    this.router.get(`${this.path}/:roleId`, this.roleController.getRole);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/role/{roleId}/actions:
     *   get:
     *     tags:
     *       - Role
     *     summary: Gets a role's actions by its id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: serviceProviderId
     *         description: The Service Provider's Id
     *         in: path
     *         required: true
     *         type: string
     *       - name: roleId
     *         description: The id of the specified role.
     *         in: path
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: login
     *       401:
     *         description: unauthorized
     */
    this.router.get(`${this.path}/:roleId/actions`, this.roleController.getRoleActions);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/role/:
     *   post:
     *     tags:
     *       - Role
     *     summary: Creates a role
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: serviceProviderId
     *         description: The Service Provider's Id
     *         in: path
     *         required: true
     *         type: string
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/Role'
     *     responses:
     *       200:
     *         description: login
     *       401:
     *         description: unauthorized
     */
    this.router.post(`${this.path}/`, this.roleController.createRole);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/role/{roleId}:
     *   put:
     *     tags:
     *       - Role
     *     summary: Updates the specified role
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: roleId
     *         description: The id of the role
     *         in: path
     *         required: true
     *         type: string
     *       - name: serviceProviderId
     *         description: The Service Provider's Id
     *         in: path
     *         required: true
     *         type: string
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/Role'
     *     responses:
     *       200:
     *         description: login
     *       401:
     *         description: unauthorized
     */
    this.router.put(`${this.path}/:roleId`, this.roleController.updateRole);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/role/{roleId}:
     *   delete:
     *     tags:
     *       - Role
     *     summary: Deletes an role by its id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: serviceProviderId
     *         description: The Service Provider's Id
     *         in: path
     *         required: true
     *         type: string
     *       - name: roleId
     *         description: The id of the specified role.
     *         in: path
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: deleted role
     *       401:
     *         description: unauthorized
     */
    this.router.delete(`${this.path}/:roleId`, this.roleController.deleteRole);

  }
};
