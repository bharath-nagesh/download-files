const HostingProviderController = require('./hostingProvider.controller');

/**
 * @swagger
 * tags:
 *  - name: HostingProvider
 *    description: HostingProvider endpoints
 */
module.exports = class HostingProviderRoutes {
  constructor(path, router, type) {
    if (path && router) {
      // setting variables
      this.path = path;
      this.router = router;
      this.hostingProviderController = new HostingProviderController();

      // initializing route
      if (type === 'Service Provider') {
        this.initServiceProvider();
      } else {
        this.initOrganization();
      }
    }
  }

  initOrganization() {
    /**
     * @swagger
     *
     * /api/organization/{orgId}/hostingProvider:
     *   get:
     *     tags:
     *       - HostingProvider
     *     summary: Gets a list of  Hosting Providers
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of hostingProviders
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/`, this.hostingProviderController.getAllHostingProvider);

    /**
     * @swagger
     *
     * /api/organization/{orgId}/hostingProvider/{hostingProviderId}:
     *   get:
     *     tags:
     *       - HostingProvider
     *     summary: Gets a hostingProvider by it's id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: hostingProviderId
     *         description: The id of the specified hostingProvider.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: hostingProvider
     */
    this.router.get(`${this.path}/:hostingProviderId`, this.hostingProviderController.getHostingProviderById);

  }

  initServiceProvider() {
    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/hostingProvider:
     *   get:
     *     tags:
     *       - HostingProvider
     *     summary: Gets a list of Hosting Providers
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type:
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *          description: List of hostingProviders
     *       400:
     *          description: Bad Request
     */
    this.router.get(`${this.path}/`, this.hostingProviderController.getAllHostingProvider);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/hostingProvider/{hostingProviderId}:
     *   get:
     *     tags:
     *       - HostingProvider
     *     summary: Gets a hostingProvider by it's id
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: hostingProviderId
     *         description: The id of the specified hostingProvider.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: hostingProvider
     */
    this.router.get(`${this.path}/:hostingProviderId`, this.hostingProviderController.getHostingProviderById);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/hostingProvider/hostingProviderName/{hostingProviderName}:
     *   get:
     *     tags:
     *       - HostingProvider
     *     summary: Gets a hostingProvider by it's name
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: hostingProviderName
     *         description: The name of the specified hostingProvider.
     *         in: path
     *         required: true
     *         type: number
     *     responses:
     *       200:
     *         description: hostingProvider
     */
    this.router.get(`${this.path}/hostingProviderName/:hostingProviderName`, this.hostingProviderController.getHostingProviderByName);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/hostingProvider:
     *   post:
     *     tags:
     *       - HostingProvider
     *     summary: Creates a hosting provider
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/HostingProvider'
     *     responses:
     *       200:
     *         description: hostingProvider
     *       400:
     *          description: Bad Request
     */
    this.router.post(`${this.path}`, this.hostingProviderController.createHostingProvider);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/hostingProvider/{hostingProviderId}:
     *   put:
     *     tags:
     *       - HostingProvider
     *     summary: Updates a hostingProvider
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: hostingProviderId
     *         description: The Hosting Provider id.
     *         in: path
     *         required: true
     *         type: number
     *     requestBody:
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/HostingProvider'
     *     responses:
     *       200:
     *         description: hostingProvider
     *       400:
     *          description: Bad Request
     */
    this.router.put(`${this.path}/:hostingProviderId`, this.hostingProviderController.updateHostingProvider);

    /**
     * @swagger
     *
     * /api/serviceProvider/{serviceProviderId}/hostingProvider/MultihostingProvider:
     *   delete:
     *     tags:
     *       - HostingProvider
     *     summary: Deletes multiple hosting providers
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: orgId
     *         description: The organization's id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: serviceProviderId
     *         description: The Service Provider id.
     *         in: path
     *         required: true
     *         type: number
     *       - name: hostingProviderId
     *         description: The id of the specified hostingProvider.
     *         in: query
     *         required: true
     *         type: string
     *     responses:
     *       200:
     *         description: hostingProvider
     */
    this.router.delete(`${this.path}/`, this.hostingProviderController.deleteMultipleHostingProvider);

  }
};
