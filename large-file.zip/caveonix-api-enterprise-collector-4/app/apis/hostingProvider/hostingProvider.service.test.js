const expect = require('chai').expect;
const proxyquire = require('proxyquire').noCallThru();

describe('HostingProviderService', function () {
  beforeEach(() => {

  });

  describe('getAllHostingProvider', () => {
    it('getAllHostingProvider', async () => {
      
      const pocId = 1;
      const opts = {};
      const response = {
        data: 1
      };

      class HostingModelStub {
        constructor() { }

        static findAll() {
          return Promise.resolve(response);
        }
      };

      const HostingProviderService = proxyquire('./hostingProvider.service', {
        './hostingProvider.model': HostingModelStub
      });
      const hostingProviderService = new HostingProviderService();
      const data = await hostingProviderService.getAllHostingProvider(pocId, opts);
      expect(data).to.be.equal(response);
    });
  });

  describe('getHostingProviderCount', () => {
    it('getHostingProviderCount', async () => {
      
      const pocId = 1;
      const opts = {};
      const response = {
        data: 1
      };
      const responseCount = 1;
      class HostingModelStub {
        constructor() { }

        static count() {
          return Promise.resolve(responseCount);
        }
      };

      const HostingProviderService = proxyquire('./hostingProvider.service', {
        './hostingProvider.model': HostingModelStub
      });
      const hostingProviderService = new HostingProviderService();
      const data = await hostingProviderService.getHostingProviderCount(pocId, opts);
      expect(data).to.be.equal(responseCount);
    });
  });

  describe('getHostingProvider', () => {
    it('getHostingProvider', async () => {
      
      const pocId = 1;
      const opts = {};
      const response = {
        data: 1
      };
      const responseCount = 1;
      class HostingModelStub {
        constructor() { }

        static findByPk() {
          return Promise.resolve(response);
        }
      };

      const HostingProviderService = proxyquire('./hostingProvider.service', {
        './hostingProvider.model': HostingModelStub
      });
      const hostingProviderService = new HostingProviderService();
      const data = await hostingProviderService.getHostingProvider(pocId, opts);
      expect(data).to.be.equal(response);
    });
  });

  describe('getHostingProviderbyName', () => {
    it('getHostingProviderbyName', async () => {

      const pocId = 1;
      const opts = {};
      const response = {
        data: 1
      };

      class HostingModelStub {
        constructor() { }

        static findAll() {
          return Promise.resolve(response);
        }
      };

      const HostingProviderService = proxyquire('./hostingProvider.service', {
        './hostingProvider.model': HostingModelStub
      });
      const hostingProviderService = new HostingProviderService();
      const data = await hostingProviderService.getHostingProviderbyName(pocId, opts);
      expect(data).to.be.equal(response);
    });
  });


  describe('updateHostingProvider', () => {
    it('updateHostingProvider', async () => {

      const hostingProviderId = 1;

      const response = {
        data: 1,
        name:'test'
      };

      const update = {
        response,
        update(){
          return response;
        }
      };

      class HostingModelStub {
        constructor() { }

        static findByPk() {
          return Promise.resolve(update);
        }

        static findOne() {
          return false;
        }

      };

      const HostingProviderService = proxyquire('./hostingProvider.service', {
        './hostingProvider.model': HostingModelStub
      });
      const hostingProviderService = new HostingProviderService();
      const data = await hostingProviderService.updateHostingProvider(hostingProviderId, update);
      expect(data).to.be.equal(response);
    });
  });

  
  describe('create', () => {
    it('create', async () => {

      const response = {
        data: 1,
        name:'test'
      };

      const params = {
        response,
        update(){
          return response;
        }
      };

      class HostingModelStub {
        constructor() { }

        static create() {
          return Promise.resolve(params);
        }

        static findOne() {
          return false;
        }

      };

      const HostingProviderService = proxyquire('./hostingProvider.service', {
        './hostingProvider.model': HostingModelStub
      });
      const hostingProviderService = new HostingProviderService();
      const data = await hostingProviderService.create(params);
      expect(data).to.be.equal(params);
    });
  });

  describe('checkUserExists', () => {
    it('checkUserExists', async () => {
      const nameOfHostingProvider = 'test'
      const response = [{
        data: 1,
        name:'test'
      }];

      class HostingModelStub {
        constructor() { }

        static findAll() {
          return Promise.resolve(response);
        }

      };

      const HostingProviderService = proxyquire('./hostingProvider.service', {
        './hostingProvider.model': HostingModelStub
      });
      const hostingProviderService = new HostingProviderService();
      const data = await hostingProviderService.checkUserExists(nameOfHostingProvider);
      expect(data).to.be.equal(response);
    });
  });


  describe('deleteById', () => {
    it('deleteById', async () => {
      const hostingProviderId = '1';
      const response = {
        data: 1,
        name:'test'
      };

      class HostingModelStub {
        constructor() { }

        static update() {
          return Promise.resolve(response);
        }

      };

      const HostingProviderService = proxyquire('./hostingProvider.service', {
        './hostingProvider.model': HostingModelStub
      });
      const hostingProviderService = new HostingProviderService();
      const data = await hostingProviderService.deleteById(hostingProviderId);
      expect(data).to.be.equal(response);
    });
  });

  describe('deleteMultipleHostingProvider', () => {
    it('deleteMultipleHostingProvider', async () => {
      const hostingProviderIdIdArr = [1,2,3];
      const response = {
        data: 1,
        name:'test'
      };

      class HostingModelStub {
        constructor() { }

        static update() {
          return Promise.resolve(response);
        }

        static findAll() {
          return Promise.resolve(response);
        }

      };

      const HostingProviderService = proxyquire('./hostingProvider.service', {
        './hostingProvider.model': HostingModelStub
      });
      const hostingProviderService = new HostingProviderService();
      const data = await hostingProviderService.deleteMultipleHostingProvider(hostingProviderIdIdArr);
      expect(data).to.be.equal(response);
    });
  });

});
