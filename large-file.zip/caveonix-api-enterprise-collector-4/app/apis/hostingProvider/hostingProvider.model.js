const Sequelize = require('sequelize');
const sequelize = require('../../../config/db.conf').getConnection();
/**
 * @swagger
 * components:
 *   schemas:
 *     HostingProvider:
 *       type: object
 *       required:
 *         - name
 *         - isActive
 *       properties:
 *         name:
 *           type: string
 *         description:
 *           type: string
 *         pocName:
 *           type: string
 *         pocEmail:
 *           type: string
 *         pocPhone:
 *           type: string
 *         hostingType:
 *           type: string
 *         isActive:
 *           type: string
 * @param sequelize
 */

class HostingProvider extends Sequelize.Model {
  static init(sequelize) {
    return super.init({
      name: { type: Sequelize.STRING, allowNull: false },
      description: { type: Sequelize.STRING },
      pocName: { type: Sequelize.STRING, allowNull: true, field: 'poc_name' },
      pocEmail: { type: Sequelize.STRING, allowNull: true, field: 'poc_email' },
      pocPhone: { type: Sequelize.STRING, allowNull: true, field: 'poc_phone' },
      hostingType: { type: Sequelize.STRING, allowNull: true, field: 'hosting_type' },
      isActive: { type: Sequelize.STRING, allowNull: false, defaultValue: true, field: 'is_active' },
      is_active: { type: Sequelize.STRING, field: 'is_active' }
    },
    { sequelize,
      timestamps: true,
      freezeTableName: true,
      tableName: 'hosting_providers',
      underscored: true
    });
  }
}

module.exports = HostingProvider;
