const expect = require('chai').expect;
const proxyquire = require('proxyquire').noCallThru();
const httpMocks = require('node-mocks-http');

describe('HostingProviderController', function () {
  beforeEach(() => {

  });

  describe('HostingProviderController', () => {

    describe('getAllHostingProvider', () => {
      it('getAllHostingProvider', async () => {
        const resData = { data : 1 };
        const orgId = 1;
        const page = 1;
        const limit = 10;
        const offset = 0;
        const total_record_count = 10;
        const HostingResponse = {
          total_page_count: 1,
          pageLimit: limit,
          total_record_count: total_record_count,
          page_number: page,
          hostingProvider: resData,
          pages: [{
            number: 1,
            url: 'null?page=' + page
          }]
        };

        const HostingProviderService = class HostingProviderService {
          getAllHostingProvider(orgId, limit, offset, listParam){
            return Promise.resolve(resData);
          };

          getHostingProviderCount(orgId, listParam){
            return Promise.resolve(total_record_count);
          };
        };
        const HostingProviderController = proxyquire('./hostingProvider.controller', {
          './hostingProvider.service': HostingProviderService
        });

        const hostingProviderController = new HostingProviderController();
        const req = httpMocks.createRequest({ params: { orgId }, query: { page } });
        const res = httpMocks.createResponse({ locals: { paginate: { limit, offset, page } } });
        const details = await hostingProviderController.getAllHostingProvider(req, res);
        const hostingData = details._getData();
        expect(JSON.parse(hostingData)).to.deep.equal(HostingResponse);
      });
    });

    describe('getHostingProviderById', () => {
      it('getHostingProviderById', async () => {
        const resData = { data : 1 };
        const orgId = 1;
        const hostingProviderId = 1;

        const HostingProviderService = class HostingProviderService {
          getHostingProvider(orgId, limit, offset, listParam){
            return Promise.resolve(resData);
          };

        };
        const HostingProviderController = proxyquire('./hostingProvider.controller', {
          './hostingProvider.service': HostingProviderService
        });

        const hostingProviderController = new HostingProviderController();
        const req = httpMocks.createRequest({ params:{ hostingProviderId : hostingProviderId } });
        const res = httpMocks.createResponse();
        const details = await hostingProviderController.getHostingProviderById(req, res);
        const hostingData = details._getData();
        expect(JSON.parse(hostingData)).to.deep.equal(resData);
      });
    });

    describe('updateHostingProvider', () => {
      it('updateHostingProvider', async () => {
        
        const orgId = 1;
        const hostingProviderId = 1;
        const params = {
          name:'test',
          description:'desc',
          pocName:'name',
          pocEmail:'email@test.com',
          pocPhone:9999888989,
          hostingType:'types',
          isActive:'enabled'
        };

        const HostingProviderService = class HostingProviderService {
          updateHostingProvider(orgId, limit, offset, listParam){
            return Promise.resolve(params);
          };

        };
        const HostingProviderController = proxyquire('./hostingProvider.controller', {
          './hostingProvider.service': HostingProviderService
        });

        const hostingProviderController = new HostingProviderController();
        const req = httpMocks.createRequest({ params:{ hostingProviderId : hostingProviderId },body:params });
        const res = httpMocks.createResponse();
        const details = await hostingProviderController.updateHostingProvider(req, res);
        const hostingData = details._getData();
        expect(JSON.parse(hostingData)).to.deep.equal(params);
      });
    });

    
    describe('createHostingProvider', () => {
      it('createHostingProvider', async () => {
        
        const orgId = 1;
        const hostingProviderId = 1;
        const params = {
          name:'test',
          description:'desc',
          pocName:'name',
          pocEmail:'email@test.com',
          pocPhone:9999888989,
          hostingType:'types',
          isActive:'enabled'
        };

        const HostingProviderService = class HostingProviderService {
          create(orgId, limit, offset, listParam){
            return Promise.resolve(params);
          };

        };
        const HostingProviderController = proxyquire('./hostingProvider.controller', {
          './hostingProvider.service': HostingProviderService
        });

        const hostingProviderController = new HostingProviderController();
        const req = httpMocks.createRequest({ body:params });
        const res = httpMocks.createResponse();
        const details = await hostingProviderController.createHostingProvider(req, res);
        const hostingData = details._getData();
        expect(JSON.parse(hostingData)).to.deep.equal(params);
      });
    });

    describe('getHostingProviderByName', () => {
      it('getHostingProviderByName', async () => {
        
        const orgId = 1;
        const hostingProviderame = 'HostingProviderName';
        const params = {
          name:'test',
          description:'desc',
          pocName:'name',
          pocEmail:'email@test.com',
          pocPhone:9999888989,
          hostingType:'types',
          isActive:'enabled'
        };

        const HostingProviderService = class HostingProviderService {
          getHostingProviderbyName(){
            return Promise.resolve(params);
          };

        };
        const HostingProviderController = proxyquire('./hostingProvider.controller', {
          './hostingProvider.service': HostingProviderService
        });

        const hostingProviderController = new HostingProviderController();
        const req = httpMocks.createRequest({ params:{ hostingProviderName:hostingProviderame } , body:params });
        const res = httpMocks.createResponse();
        const details = await hostingProviderController.getHostingProviderByName(req, res);
        const hostingData = details._getData();
        expect(JSON.parse(hostingData)).to.deep.equal(params);
      });
    });

    describe('deleteMultipleHostingProvider', () => {
      it('deleteMultipleHostingProvider', async () => {
        
        const params = [{
          name:'test',
          description:'desc',
          pocName:'name',
          pocEmail:'email@test.com',
          pocPhone:9999888989,
          hostingType:'types',
          isActive:'diabled'
        }];

        const HostingProviderService = class HostingProviderService {
          deleteMultipleHostingProvider(){
            return Promise.resolve(params);
          };

        };
        const HostingProviderController = proxyquire('./hostingProvider.controller', {
          './hostingProvider.service': HostingProviderService
        });

        const hostingProviderController = new HostingProviderController();
        const req = httpMocks.createRequest({ query:{ id:'1,2' } });
        const res = httpMocks.createResponse();
        const details = await hostingProviderController.deleteMultipleHostingProvider(req, res);
        const hostingData = details._getData();
        expect(JSON.parse(hostingData)).to.deep.equal(params);
      });
    });

  });
});
