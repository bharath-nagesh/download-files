const paginate = require('../../middlewares/paginate.middleware');
const checkId = require('../../../utils/checkId');
const checkName = require('../../../utils/checkName');
const errorHandler = require('../../../utils/errorHandler');
const Validator = require('../../../utils/validator');
const HostingProviderService = require('./hostingProvider.service');
const hostingProviderService = new HostingProviderService();
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-hostingProvider.controller'
});

module.exports = class HostingProviderController {
  async getAllHostingProvider(req, res) {
    const limit = res.locals.paginate.limit;
    const offset = res.locals.paginate.offset;
    const pageNumber = res.locals.paginate.page;
    const dropdown = req.query.dropdown || false;
    const hostingProviderId = null;
    const opts = null;
    try{
      const results = await hostingProviderService.getAllHostingProvider(hostingProviderId, opts, limit, offset, dropdown);
      const itemCount = await hostingProviderService.getHostingProviderCount();
      const pageCount = Math.ceil(itemCount / limit);
      return res.json({
        total_page_count: pageCount,
        pageLimit: limit,
        total_record_count: itemCount,
        page_number: pageNumber,
        hostingProvider: results,
        pages: paginate.getArrayPages(req)(3, pageCount, req.query.page)
      });
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
  }

  async getHostingProviderById(req, res) {
    const hostingProviderId = req.params.hostingProviderId;
    if (checkId(hostingProviderId)) {
      logger.error({ hostingProviderId }, 'Error with HostingProvider Id');
      const error = new Error('Error with HostingProvider Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try{
      const hostingProvider = await hostingProviderService.getHostingProvider(hostingProviderId);
      return res.json(hostingProvider);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async updateHostingProvider(req, res) {
    const hostingProviderId = req.params.hostingProviderId;
    const params = req.body;
    try {
      params.isActive = params.isActive ? params.isActive.toString().toLowerCase() : null;
      await Validator.validateParams({
        name: 'required|string',
        description: 'nullable',
        pocName: 'nullable',
        pocEmail: 'nullable',
        pocPhone: 'nullable',
        hostingType: 'nullable',
        isActive: 'required|in:enabled,disabled'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    if (checkId(hostingProviderId)) {
      logger.error({ hostingProviderId }, 'Error with HostingProvider Id');
      const error = new Error('Error with HostingProvider Id');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try{
      const hostingProvider = await hostingProviderService.updateHostingProvider(hostingProviderId, params);
      return res.json(hostingProvider);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
  }

  async getHostingProviderByName(req, res) {
    const hostingProviderName = req.params.hostingProviderName;
    if (checkName(hostingProviderName)) {
      logger.error({ hostingProviderName }, 'Error with HostingProvider Name');
      const error = new Error('Error with HostingProvider Name');
      error.status = 400;
      return errorHandler(req, res, error);
    }
    try{
      const hostingProvider = await hostingProviderService.getHostingProviderbyName(hostingProviderName);
      return res.json(hostingProvider);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
  }

  async createHostingProvider(req, res) {
    const params = req.body;
    try {
      params.isActive = params.isActive ? params.isActive.toString().toLowerCase() : 'enabled';
      await Validator.validateParams({
        name: 'required|string',
        description: 'nullable',
        pocName: 'nullable',
        pocEmail: 'nullable',
        pocPhone: 'nullable',
        hostingType: 'nullable',
        isActive: 'required|in:enabled,disabled,true'
      }, params);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
    try{
      const hostingProvider = await hostingProviderService.create(params);
      return res.json(hostingProvider);
    } catch (error) {
      logger.error({ error, stack: error.stack }, 'error occurred');
      return errorHandler(req, res, error);
    }
  }

  async deleteMultipleHostingProvider(req, res) {
    const hostingProviderId = req.query.id || '';
    const hostingProviderIdIdArr = hostingProviderId.split(',');
    try{
      const update = await hostingProviderService.deleteMultipleHostingProvider(hostingProviderIdIdArr);
      return res.json(update);
    } catch (error) {
      logger.error({ error }, 'error occurred');
      error.status = 422;
      return errorHandler(req, res, error, { validationErrors: error.validationErrors });
    }
  }
};
