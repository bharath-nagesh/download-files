const HostingProvider = require('./hostingProvider.model');
const logger = require('../../../utils/logger').logger.child({
  sub_name: 'IdentityService-hostingProvider.service'
});
const removeSpace = require('../../../utils/checkSpaces');
const sequelize = require('sequelize');

module.exports = class HostingProviderService {
  constructor() {
    logger.debug('called HostingProvider constructor');
  }

  getAllHostingProvider(hostingProviderId, opts, limit, offset, dropdown = false) {
    let condition = ['false'];
    let attributes = { exclude: [] };
    if(dropdown && dropdown === 'true') {
      condition = ['false','disabled','unmanaged'];
      attributes = ['id','name','isActive'];
    }
    return HostingProvider.findAll({
      where: { $or: [{ isActive: { $notIn: condition } }] },
      attributes,
      order: [['name', 'ASC']],
      limit: limit,
      offset: offset
    });
  }

  getHostingProviderCount() {
    return HostingProvider.count({
      where: { $or: [{ isActive: { $ne: 'false' } }] }
    });
  }

  getHostingProvider(hostingProviderId, opts) {
    return HostingProvider.findByPk(hostingProviderId);
  }

  getHostingProviderbyName(hostingProviderName, opts) {
    return HostingProvider.findAll({
      where: {
        name: sequelize.where(sequelize.fn('LOWER', sequelize.col('name')),
          sequelize.fn('lower', hostingProviderName)),
        $or: [{ isActive: { $ne: 'false' } }]
      }
    });
  }

  async updateHostingProvider(hostingProviderId, update) {
    const name = update.name;
    const newName = removeSpace.checkMultiSpace(name);
    const exists = await this.checkNameForUpdate(newName, hostingProviderId);
    if (exists) {
      const err = new Error('Duplicate Hosting Provider name.');
      err.status = 400;
      throw err;
    }
    update.name = newName;
    const hostingProvider = await HostingProvider.findByPk(hostingProviderId);
    return hostingProvider.update(update);
  };

  async create(params) {
    const name = params.name;
    const newName = removeSpace.checkMultiSpace(name);
    const exists = await this.checkName(newName);
    if (exists) {
      const err = new Error('Duplicate Hosting Provider name.');
      err.status = 400;
      throw err;
    }
    params.name = newName;
    return HostingProvider.create(params);
  }

  checkUserExists(nameOfHostingProvider) {
    return HostingProvider.findAll({ where: { name: nameOfHostingProvider } });
  }

  deleteById(hostingProviderId) {
    return HostingProvider.update( { isActive: false },{ where: { id: hostingProviderId } });
  }

  async deleteMultipleHostingProvider(hostingProviderIdIdArr) {
    await HostingProvider.update({ isActive: false }, { where: { id: { $in: hostingProviderIdIdArr } } });
    return HostingProvider.findAll({ where: { id: { $in: hostingProviderIdIdArr } } });
  }

  checkName(name) {
    return HostingProvider.findOne({
      where: {
        name: sequelize.where(sequelize.fn('LOWER', sequelize.col('name')),
          sequelize.fn('lower', name)),
        $or: [{ isActive: { $ne: 'false' } }]
      }
    });
  }

  checkNameForUpdate(name, hostingProviderId) {
    return HostingProvider.findOne({
      where: {
        name: sequelize.where(sequelize.fn('LOWER', sequelize.col('name')),
          sequelize.fn('lower', name)),
        $or: [{ isActive: { $ne: 'false' } }],
        id: { $ne: hostingProviderId }
      }
    });
  }
};
