const where = require('./common');
const whereCondition = require('../../utils/whereParser.js');
const conditionFilter = require('../../utils/conditionFilter');
const logger = require('./../../utils/logger').logger.child({

  sub_name: 'IdentityService-reference.service'
});
module.exports = [

  {
    name: 'change me',
    route: '/applicationByRegulation',
    sql: {
      nist: function (condition, selector, date) {
        return `select at.id as application_grp_id, at.name as application_grp_name, c.name as regulation from application_tag_certificate_members atc join
      application_tags at on atc.application_tag_id = at.id
      join certificates c on atc.certificate_id = c.id where UPPER(c.name) = UPPER('${selector}')`;
      },
      'fedramp high': function (condition, selector, date) {
        return `select at.id as application_grp_id, at.name as application_grp_name, c.name as regulation from application_tag_certificate_members atc join
      application_tags at on atc.application_tag_id = at.id
      join certificates c on atc.certificate_id = c.id where UPPER(c.name) = UPPER('${selector}')`;
      },
      'fedramp moderate': function (condition, selector, date) {
        return `select at.id as application_grp_id, at.name as application_grp_name, c.name as regulation from application_tag_certificate_members atc join
      application_tags at on atc.application_tag_id = at.id
      join certificates c on atc.certificate_id = c.id where UPPER(c.name) = UPPER('${selector}')`;
      },
      'fedramp low': function (condition, selector, date) {
        return `select at.id as application_grp_id, at.name as application_grp_name, c.name as regulation from application_tag_certificate_members atc join
      application_tags at on atc.application_tag_id = at.id
      join certificates c on atc.certificate_id = c.id where UPPER(c.name) = UPPER('${selector}')`;
      },
      nesa: function (condition, selector, date) {
        return `select at.id as application_grp_id, at.name as application_grp_name, c.name as regulation from application_tag_certificate_members atc join
      application_tags at on atc.application_tag_id = at.id
      join certificates c on atc.certificate_id = c.id where UPPER(c.name) = UPPER('${selector}')`;
      },
      sama: function (condition, selector, date) {
        return `select at.id as application_grp_id, at.name as application_grp_name, c.name as regulation from application_tag_certificate_members atc join
      application_tags at on atc.application_tag_id = at.id
      join certificates c on atc.certificate_id = c.id where UPPER(c.name) = UPPER('${selector}')`;
      },
      pci: function (condition, selector, date) {
        return `select at.id as application_grp_id, at.name as application_grp_name, c.name as regulation from application_tag_certificate_members atc join
      application_tags at on atc.application_tag_id = at.id
      join certificates c on atc.certificate_id = c.id where UPPER(c.name) = UPPER('${selector}')`;
      },
      iso: function (condition, selector, date) {
        return `select at.id as application_grp_id, at.name as application_grp_name, c.name as regulation from application_tag_certificate_members atc join
      application_tags at on atc.application_tag_id = at.id
      join certificates c on atc.certificate_id = c.id where UPPER(c.name) = UPPER('${selector}')`;
      },
      gdpr: function (condition, selector, date) {
        return `select at.id as application_grp_id, at.name as application_grp_name, c.name as regulation from application_tag_certificate_members atc join
      application_tags at on atc.application_tag_id = at.id
      join certificates c on atc.certificate_id = c.id where UPPER(c.name) = UPPER('${selector}')`;
      },
      hipaa: function (condition, selector, date) {
        return `select at.id as application_grp_id, at.name as application_grp_name, c.name as regulation from application_tag_certificate_members atc join
      application_tags at on atc.application_tag_id = at.id
      join certificates c on atc.certificate_id = c.id where UPPER(c.name) = UPPER('${selector}')`;
      },
      custom: function (condition, selector, date) {
        return `select at.id as application_grp_id, at.name as application_grp_name, c.name as regulation from application_tag_certificate_members atc join
      application_tags at on atc.application_tag_id = at.id
      join certificates c on atc.certificate_id = c.id where UPPER(c.name) = UPPER('${selector}')`;
      },
      ffiec: function (condition, selector, date) {
        return `select at.id as application_grp_id, at.name as application_grp_name, c.name as regulation from application_tag_certificate_members atc join
      application_tags at on atc.application_tag_id = at.id
      join certificates c on atc.certificate_id = c.id where UPPER(c.name) = UPPER('${selector}')`;
      }

    }
  },

  {
    name: 'softwareListLookup',
    route: '/softwareLookup/:softwareName',
    sql: {
      default: function (condition, selector, date) {
        return `select st.name, st.version, ag.application_name as sub_application_name,ag.application_grp_name as application_name,ag.application_id as sub_application_id,ag.application_grp_id as application_id, asset_name, ag.id as asset_id from software_tags st join asset_software_tags_members astm on st.id = astm.software_tags_id join application_group_asset_view ag on ag.id = astm.asset_id
${whereCondition(
          where.common.orgChainFilter,
          'st.name like \'%\'||:softwareName||\'%\'',
          ...conditionFilter(condition)
        )} group by st.name, st.version, ag.application_name ,ag.application_grp_name ,ag.application_id ,ag.application_grp_id , asset_name, ag.id `;
      }

    },
    expected_params: ['orgId']
  },
  {
    name: 'scoreTrend',
    route: '/scoreTrend',
    sql: {
      cyber: function (condition, selector, date) {
        return ` select created_at::DATE, avg(score) from alert_results
       ${whereCondition('alert_scheduler_id = 1',
          `created_at between now()::DATE - interval '30 day' and now()::DATE`,
          where.common.orgChainFilter)}  group by created_at order by created_at desc limit 30`;
      },
      compliance: function (condition, selector, date) {
        return ` select created_at::DATE, avg(score) from alert_results 
        ${whereCondition('alert_scheduler_id = 4',
          `created_at between now()::DATE - interval '30 day' and now()::DATE`,
          where.common.orgChainFilter)}  group by created_at order by created_at desc limit 30`;
      }
    },
    expected_params: ['orgId']
  },
  {
    name: 'workFlowWidgets',
    route: '/tickets/counts',
    sql: {
      closed: function (condition, selector, date) {
        return `select count(distinct id) from workflow_tasks ${whereCondition(
          'is_active = \'closed\'',
          where.common.orgChainFilter
        )} ;`;
      },
      open: function (condition, selector, date) {
        return `select count(distinct id) from workflow_tasks ${whereCondition(
          'is_active != \'closed\'',
          `is_active != 'false'`,
          where.common.orgChainFilter
        )} ;`;
      }
    }
  },
  {
    name: 'workFlowWidgets',
    route: '/tickets/counts/user/:userId',
    sql: {
      open: function (condition, selector, date) {
        return `select count(distinct id) from workflow_tasks ${whereCondition(
          'is_active != \'closed\'',
          'assigned_user_id = :userId',
          where.common.orgChainFilter
        )} ;`;
      },

      closed: function (condition, selector, date) {
        return `select count(distinct id) from workflow_tasks ${whereCondition(
          'is_active = \'closed\'',
          'assigned_user_id = :userId',
          where.common.orgChainFilter
        )} ;`;
      }
    }
  }
];
