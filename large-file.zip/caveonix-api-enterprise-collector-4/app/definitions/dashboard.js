const where = require('./common');
const whereCondition = require('../../utils/whereParser.js');
const conditionFilter = require('../../utils/conditionFilter');
module.exports = [
  {
    name: 'RegulationTrendsWidget',
    route: '/compliance/regulationTrends',
    sql: {
      default: function (condition, selector, date) {
        return `select created_at, regulation_name, round(avg(failed_controls),2) as avg_failed_controls from daily_cloud_regulation_trends
        where organization_id in (SELECT reporting_org_chain_list(:orgId)) 
        and created_at in (select distinct created_at from daily_cloud_regulation_trends order by created_at desc limit 10)
        group by created_at, regulation_name order by created_at;`;
      }
    },
    // postStages: [
    //   {
    //     type: 'lodash',
    //     transformationType: 'map',
    //     transformer: (data) => {
    //       data[data.regulation_name] = data.avg_failed_controls;
    //       delete data.regulation_name;
    //       delete data.avg_failed_controls;
    //       return data;
    //     }
    //   }
    // ],
    expected_params: ['orgId']
  },
  {
    name: 'SecurityRiskTrendsWidget',
    route: '/compliance/securityRiskTrends',
    sql: {
      default: function (condition, selector, date) {
        return `select created_at, cloud_type, round(avg(score)::int,2) as avg_score from daily_cloud_security_risk_trends 
        where organization_id in (SELECT reporting_org_chain_list(:orgId)) and created_at in (select distinct created_at from daily_cloud_security_risk_trends order by created_at desc limit 10)
        group by created_at, cloud_type  order by created_at;`;
      }
    },
    // postStages: [
    //   {
    //     type: 'lodash',
    //     transformationType: 'map',
    //     transformer: (data) => {
    //       data[data.cloud_type] = data.avg_score;
    //       delete data.cloud_type;
    //       delete data.avg_score;
    //       return data;
    //     }
    //   }
    // ],
    expected_params: ['orgId']
  },
  {
    name: 'DashboardAssetView',
    route: '/compliance/assetView',
    sql: {
      default: function (condition, selector, date) {
        const cloudType = condition.cloud_type ? `and cloud_type = '${condition.cloud_type}'` : '';
        const type = condition.type ? `and type = '${condition.type}'` : '';
        const locationName = condition.location_name ? `and location_name = '${condition.location_name}'` : '';
        const organizationId = condition.organization_id ? `and organization_id = '${condition.organization_id}'` : '';
        return `select cloud_type, type, location_name, count(cloud_type) as total_asset from saas_dashboard_reporting_details where organization_id  in (select org_chain_list(:orgId))
        ${cloudType} ${type} ${locationName} ${organizationId}
        group by cloud_type, type, location_name`;
      }
    },
    expected_params: ['orgId']
  }
];
