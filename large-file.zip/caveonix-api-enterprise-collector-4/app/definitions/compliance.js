const where = require('./common');
const whereCondition = require('../../utils/whereParser.js');
const conditionFilter = require('../../utils/conditionFilter');
const _ = require('lodash');
const complianceSelector = require('./common/complianceSelector');
const ComplianceFactory = require('../compliancePackage/complianceFactory');
const complianceScore = require('./scoringModules/complianceScore.view');
const STANDARD_SELECT = ['source', 'asset_type', 'location', 'organization_name', 'application_grp_name', 'application_name', 'asset_id', 'asset_name', 'result', 'cci_id'];
module.exports = [
  {
    name: 'complianceRiskViewWidget',
    route: '/riskView',
    sql: {
      default: function (condition, selector, date) {

        return `select asset_type, location, o.organization_name, application_grp_name, application_name,o.id as asset_id,o.asset_name, round(o.final_count::numeric,2)::float as final_count, p.name as severity, round((o.final_count + o.impact_level::float + cast((CASE WHEN bai_value = 'Critical' then 9.5 WHEN bai_value = 'High' then 8 WHEN bai_value = 'Medium' then 5 WHEN bai_value = 'Low' THEN 2 ELSE 1 END) as float))::numeric/3,2)::float as temporal,round(o.final_count::numeric,2)::float as residual,source from (
        select asset_type, source,location,bai_value,impact_level, organization_name, application_grp_name, application_name, id,asset_name,(compliance_count::float/total_count) as final_count from (
        select  asset_type, source,location,organization_name, application_grp_name, application_name, dc.id,dc.asset_name, count(dc.id) as total_count, sum(case when lower(severity) ='low' then 2 when lower(severity) ='medium' then 5 when lower(severity) ='high' then 8 when lower(severity) ='critical' then 10 else 1 end) as compliance_count, impact_level, bai_value
        from ${where.compliance.viewWithNist} dc , xccdf_rules x
        ${whereCondition(
          ...conditionFilter(condition),
          'dc.rule_id=x.rule_id',
          where.compliance.resultFailFilter
        )} group by  asset_type, source,location, organization_name, application_grp_name, application_name,dc.id,dc.asset_name,impact_level,bai_value order by compliance_count desc ) as t) as o join priorities p on o.final_count <= p.max_value::float and o.final_count >= p.min_value::float`;

      }
    },
    postStages: [
      { type: '_removeUUID' },
      { type: 'setData' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'application_grp_name' },
          { label: 'Sub-Application', path: 'application_name' },
          { label: 'Asset', path: 'asset_name' },
          { label: 'Location', path: 'location' },
          { label: 'Severity', path: 'severity' },
          { label: 'Organization', path: 'organization_name' },
          { label: 'Scan Type', path: 'asset_type' },
          { label: 'Source', path: 'source' }
        ]
      },
      { type: 'orderSeverity' }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'complianceRiskViewWidget',
    route: '/riskView/temporal',
    whereTransform: {
      default: {
        apply: true,
        mapping: {
          organization_name: 'organization_name',
          location: 'location',
          application_grp_name: 'application_grp_name',
          application_name: 'application_name',
          asset_type: 'asset_type',
          Severity: 'p.name',
          severity: 'p.name'
        }
      }
    },
    sql: {
      default: function (condition, selector, date) {
        return `select score.raw_weighted_risk::float as temporal, score.raw_weighted_risk::float as residual, p.name as severity, dc.* from 
        (select asset_type, source,location, organization_name, application_grp_name, application_name,id,asset_name,impact_level,bai_value from 
        ${where.compliance.viewWithNist} x ${whereCondition(...conditionFilter(['organization_name', 'location', 'application_grp_name', 'application_name', 'asset_type'], condition), where.compliance.resultFailFilter)}  group by asset_type, source,location, organization_name, application_grp_name, application_name,id,asset_name,impact_level,bai_value) dc
         join (${complianceScore('asset_id', condition)}) score on dc.id = score.label
                  join priorities p on score.raw_weighted_risk <= p.max_value::float and score.raw_weighted_risk >= p.min_value::float ${whereCondition(...conditionFilter(['p.name'], condition))}`;
      }
    },
    postStages: [
      { type: 'setData' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'application_grp_name' },
          { label: 'Sub-Application', path: 'application_name' },
          { label: 'Asset', path: 'asset_name' },
          { label: 'Location', path: 'location' },
          { label: 'Severity', path: 'severity' },
          { label: 'Organization', path: 'organization_name' },
          { label: 'Scan Type', path: 'asset_type' },
          { label: 'Source', path: 'source' }

        ]
      },
      { type: 'orderSeverity' }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'complianceTopRegulationByComplianceWidget',
    route: ['/topApplicationByRegulation', '/topApplicationByRegulation/temporal'],
    sql: {
      default: function (condition, selector, date) {
        return `select application_name, name, certificate_id, severity, sum(failed_control_count) as failed_control_count, total_controls from
        (
        select application_grp_name as application_name, name, certificate_id, severity, failed_control_count, total_controls from
        (
        select application_grp_name, c.name,c.id as certificate_id,result.severity, result.failed_control_count,
        (select count (control_id) from regulation_controls where certificate_id = c.id) as total_controls
        From
        (select application_grp_id,application_grp_name, INITCAP(severity) as severity, rc.certificate_id,
        count(distinct rc.control_id) as failed_control_count
        from daily_scan_xccdf_results scan
        join xccdf_rules xr ON scan.rule_id = xr.rule_id and scan_result = 'FAIL' and scan.reference = xr.rule_identifiers
        join application_group_asset_view agsv on agsv.id = scan.asset_id and agsv.organization_id in (select org_chain_list(:orgId))
        and scan.organization_id = agsv.organization_id
        join (select asset_id, max(batch_id) as max_batch_id from daily_scan_xccdf_results where asset_id in (select id from assets
        where (is_active='enabled' or is_active='true' or is_active='disabled') and 
        ${condition.cloud_type ? `source = '${condition.cloud_type}'` : '1=1'} and
        organization_id in (select org_chain_list(:orgId)) )
        group by asset_id) as max_scanresult on scan.asset_id = max_scanresult.asset_id and scan.batch_id = max_scanresult.max_batch_id
        join control_correlation_identifier cci on scan.reference  = cci.cci_id
        join regulation_nist_mappings rnm on cci.nist_index = rnm.nist_id
        join regulation_controls rc on rnm.certificate_id = rc.certificate_id and rnm.mapping_id = rc.mapping_id and compliance = 'Auto'
        join application_tag_certificate_members atc on agsv.application_grp_id = atc.application_tag_id
        join certificates cert on cert.id = rc.certificate_id and cert.is_active is null
        where scan.organization_id in (select org_chain_list(:orgId)) and rc.certificate_id in (select distinct certificate_id From org_certificate_members where organization_id in (select org_chain_list(:orgId)) order by certificate_id) and 
        (scan.asset_id::varchar, scan.rule_id) NOT IN (select entity_arn,control_id from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) )
        group by application_grp_id,application_grp_name, severity, rc.certificate_id) result
        join certificates c on c.id = result.certificate_id and c.is_active is null
        -- where (result.certificate_id ||'-'||result.application_grp_id) NOT IN (select distinct certificate_id || '-'||application_id from application_tag_controls_members)
        order by application_grp_name
        ) compliance
        union all
        select application_name, c.name,c.id as certificate_id,result.severity, result.failed_control_count,
        (select count (control_id) from regulation_controls where certificate_id = c.id) as total_controls
        From
        (select agslv.application_name, cis.severity as severity, rc.certificate_id,
        count(distinct rc.mapping_id) as failed_control_count
        from
        infrastructure_services_compliance infra
        join (select batch_id, entity_arn, cloud_type from (select batch_id, entity_arn,cloud_type, row_number() OVER (PARTITION BY cloud_type,entity_arn ORDER BY batch_id DESC) as rank from infrastructure_services_compliance where organization_id in (select org_chain_list(:orgId) ) group by batch_id,cloud_type,entity_arn) isc where rank <= 1 ) as max_batch_infra on max_batch_infra.batch_id = infra.batch_id and max_batch_infra.entity_arn = infra.entity_arn and max_batch_infra.cloud_type = infra.cloud_type
        and max_batch_infra.entity_arn = infra.entity_arn and (infra.entity_arn, infra.cis_control_id) not in (select entity_arn,control_id from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) )
        join cis_webservices_controls cis on cis.control_id = infra.cis_control_id
        join nist_cis_mappings ncm on ncm.mapping_id = cis.control_id and ncm.cloud_type = cis.cloud_type
        join regulation_nist_mappings rnm on ncm.nist_id = rnm.nist_id
        join regulation_controls rc on rc.mapping_id = rnm.mapping_id and rnm.certificate_id = rc.certificate_id  and compliance = 'Auto' and
        ${condition.cloud_type ? `cis.cloud_type = '${condition.cloud_type}'` : '1=1'}
        join application_group_service_license_view agslv on agslv.entity_arn = infra.entity_arn and agslv.organization_id = infra.organization_id
        where result = 'FAIL' and rc.certificate_id in (select distinct certificate_id From org_certificate_members where organization_id in (select org_chain_list(:orgId)) order by certificate_id) and
        (infra.entity_arn, infra.cis_control_id) NOT IN (select entity_arn,control_id from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) )
        group by application_name, cis.severity, rc.certificate_id
        ) result join certificates c on c.id = result.certificate_id and c.is_active is null
        order by application_name, severity
        ) full_sql
        group by application_name, name, certificate_id, severity, total_controls
        order by application_name, name, severity`;
      },
      services(condition, selector, date) {
        const ncmCloudType = condition.cloud_type ? `ncm.cloud_type = '${condition.cloud_type}'` : '1=1';
        const cisCloudType = condition.cloud_type ? `cis.cloud_type = '${condition.cloud_type}'` : '1=1';
        return `select application_name, c.name,c.id as certificate_id,result.severity, result.failed_control_count,
     (select count (control_id) from regulation_controls where certificate_id = c.id) as total_controls
     From 
    (select agslv.application_name, cis.severity as severity, rc.certificate_id,
    count(distinct rc.mapping_id) as failed_control_count
  from 
  infrastructure_services_compliance infra 
 	 join (select batch_id, entity_arn, cloud_type from (select batch_id, entity_arn,cloud_type, row_number() OVER (PARTITION BY cloud_type,entity_arn ORDER BY batch_id DESC) as rank from infrastructure_services_compliance where organization_id in (select org_chain_list(:orgId) ) group by batch_id,cloud_type,entity_arn) isc where rank <= 1 ) as max_batch_infra on max_batch_infra.batch_id = infra.batch_id and max_batch_infra.entity_arn = infra.entity_arn and max_batch_infra.cloud_type = infra.cloud_type 
 	 and max_batch_infra.entity_arn = infra.entity_arn and (infra.entity_arn, infra.cis_control_id) not in (select entity_arn,control_id from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) ) 
 	 join cis_webservices_controls cis on cis.control_id = infra.cis_control_id and ${cisCloudType}
 	 join nist_cis_mappings ncm on ncm.mapping_id = cis.control_id and ${ncmCloudType}
 	 join regulation_nist_mappings rnm on ncm.nist_id = rnm.nist_id
 	 join regulation_controls rc on rc.mapping_id = rnm.mapping_id and rnm.certificate_id = rc.certificate_id 
 	 join application_group_service_license_view agslv on agslv.entity_arn = infra.entity_arn
 	 where result = 'FAIL' and rc.certificate_id in (select distinct certificate_id From org_certificate_members where organization_id in (select org_chain_list(:orgId)) order by certificate_id)
 	 group by application_name, cis.severity, rc.certificate_id
 	 ) result join certificates c on c.id = result.certificate_id and c.is_active is null
 	 order by application_name, severity`;
      }
    },
    postStages: [
      {
        type: 'join',
        accessor: (obj) => {
          return obj.application_grp_name;
        }
      }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'complianceTopRegulationByComplianceWidgettabular',
    route: ['/topApplicationByRegulation/tabular', '/topApplicationByRegulation/temporal/tabular'],
    whereTransform: {
      default: {
        apply: true,
        mapping: {
          organization_name: 'organization_name',
          location: 'location',
          application_grp_name: 'application_grp_name',
          application_name: 'application_name',
          asset_type: 'asset_type',
          Severity: 'p.name',
          severity: 'p.name'
        }
      }
    },
    sql: {
      default: function (condition, selector, date) {
        const RegulationClass = ComplianceFactory.getRegulationByName(selector);
        const regulation = new RegulationClass();
        return regulation.topApplicationByRegulationTabular(condition);
      }
    },
    postStages: [
      { type: '_removeUUID' },
      { type: 'setData' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'Application' },
          { label: 'Sub-Application', path: 'Sub-Application' },
          { label: 'Asset', path: 'Asset' },
          { label: 'Location', path: 'Location' },
          { label: 'Organization', path: 'Organization' }
        ]
      },
      { type: 'complianceMapping' }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'distributionRiskWidget',
    route: '/distribution/temporal/counts',
    sql: {
      default: function (condition, selector, date) {

        return `select severity as name, asset_ids from (select p.name as severity, array_agg(label) as asset_ids from (${complianceScore('asset_id', condition)}) as t join priorities p on t.raw_weighted_risk <= p.max_value::float and t.raw_weighted_risk >= p.min_value::float group by p.name) x 
        ${whereCondition(...conditionFilter(['severity'], condition))}`;

      },
      expected_params: ['orgId']
    }
  },
  {
    name: 'distributionRiskWidget',
    route: '/distribution/counts',
    sql: {
      default: function (condition, selector, date) {
        return `select p.name, array_agg(label) as asset_ids from (${complianceScore('asset_id', condition)}) as t join priorities p on t.raw_weighted_risk <= p.max_value::float and t.raw_weighted_risk >= p.min_value::float group by p.name`;
      },
      closed: function (condition, selector, date) {
        return `select count (distinct reference) from (      
        select distinct reference from daily_scan_xccdf_results ${whereCondition(
          `asset_id in (select id from assets where ${where.common.orgChainFilter})`,
          `date_trunc('hour', created_at) = (select distinct date_trunc('hour', created_at) 
from daily_scan_xccdf_results order by date_trunc('hour',created_at) DESC limit 1 offset 1)`
        )}) x
        ${whereCondition(`reference not in (select distinct reference from daily_scan_xccdf_results ${whereCondition(
          `asset_id in (select id from assets where ${where.common.orgChainFilter})`,
          `date_trunc('hour', created_at) = (select distinct date_trunc('hour', created_at) 
from daily_scan_xccdf_results order by date_trunc('hour',created_at) DESC limit 1)`
          )}`
        )}
      )`;
      },
      new: function (condition, selector, date) {
        return `select count (distinct reference) from (
        select distinct reference from daily_scan_xccdf_results ${whereCondition(
          `asset_id in (select id from assets where ${where.common.orgChainFilter})`,
          `date_trunc('hour', created_at) = (select distinct date_trunc('hour', created_at)
from daily_scan_xccdf_results order by date_trunc('hour',created_at) DESC limit 1 )`
        )}) x ${whereCondition(`reference not in (select distinct reference from daily_scan_xccdf_results ${whereCondition(
          `asset_id in (select id from assets where ${where.common.orgChainFilter})`,
          `date_trunc('hour', created_at) = (select distinct date_trunc('hour', created_at) 
from daily_scan_xccdf_results order by date_trunc('hour',created_at) DESC limit 1 offset 1)`
          )}`
        )})`;
      }
    },
    expected_params: ['orgId']

  },
  {
    name: 'distributionWidgetTotal',
    route: ['/distribution/total', '/distribution/total/temporal', '/distribution/temporal/total'],
    search_terms: ['compliance tabular data'],
    whereTransform: {
      tabular: {
        apply: true,
        mapping: {
          organization_id: 'dc.organization_id'
        }
      }
    },
    sql: {
      count: function (condition, selector, date) {
        return `select count(id) as compliance_count from ${where.compliance.viewWithNist} ${whereCondition(...conditionFilter(condition), where.compliance.resultFailFilter)}`;
      },
      average: function (condition, selector, date) {
        return complianceScore('parent_org_id', condition);
        // return `select round(compliance_count::numeric/total_count::numeric,2) as score from (select count(dc.id) as total_count, sum(case when lower(severity) ='low' then 2 when lower(severity) ='medium' then 5 when lower(severity) ='high' then 8 when lower(severity) ='critical' then 10 else 1 end) as compliance_count from ${where.compliance.viewWithNist} dc , xccdf_rules x ${whereCondition(
        //   ...conditionFilter(condition),
        //   'dc.rule_id=x.rule_id',
        //   where.compliance.resultFailFilter,
        // )}) as t`;
      },
      tabular: function (condition, selector, date) {
        return `select cci_id as reference_id, initcap(result) as result,dc.id as asset_id, dc.asset_type as asset_type, asset_name as "Asset", vmid, application_name as "Sub-Application", application_grp_name as "Application", organization_name as "Organization", dc.organization_id as "OrganizationId", dc.source as cloud_type, location as "Location", initcap(severity) as "Severity",dc.realm AS "registeredName" ,dc.network_ip as ipAddress, dc.asset_manager_id as "asset_manager_id", vcd.vcenter_url as vcenter_url, repo.connection_name from 
        ${where.compliance.viewWithNistTabular} dc join xccdf_rules x on x.rule_id = dc.rule_id 
        left join asset_repo_endpoints repo on repo.id  = dc.asset_manager_id
        left join vcd_vcenter_details vcd on vcd.id = dc.vcenter_url::int
        ${whereCondition(...conditionFilter(condition))} group by cci_id, result,dc.id, asset_name, asset_type, vmid, application_name,application_grp_name,organization_name,dc.organization_id,dc.source,location,severity,dc.realm,dc.network_ip,dc.asset_manager_id,vcd.vcenter_url,repo.connection_name `;
      }
    },
    postStages: [
      { type: '_removeUUID' },
      { type: 'setData' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'Application' },
          { label: 'Sub-Application', path: 'Sub-Application' },
          { label: 'Asset', path: 'Asset' },
          { label: 'Asset Type', path: 'asset_type' },
          { label: 'Location', path: 'Location' },
          { label: 'Organization', path: 'Organization' },
          { label: 'Severity', path: 'Severity' }
        ]
      },
      { type: 'orderSeverity' }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'distributionWidgetTotalRegulation',
    route: ['/distribution/totalRegulation', '/distribution/totalRegulation/temporal'],

    sql: {
      default: function (condition, selector, date) {
        return `select count(*) as regulation_count from org_certificate_members ${whereCondition(...conditionFilter(condition), 'organization_id=:orgId')}`;
      }
    },
    expected_params: ['orgId']
  },
  {
    name: 'distributionWidgetAsset',
    route: ['/distribution/asset', '/distribution/asset/temporal', '/distribution/temporal/asset'],
    search_terms: ['assets tabular data'],
    sql: {
      default: function (condition, selector, date) {
        return `select reference_id, result, asset_name, vmid, application_name, application_grp_name, organization, location from ${where.compliance.viewWithNist} ${whereCondition(
          where.common.orgChainFilter,
          ...conditionFilter(condition)
        )}`;
      },
      tabular: function (condition, selector, date) {
        return `select reference_id, result, asset_name as "Asset", vmid, application_name as "Sub-Application", application_grp_name as "Application", organization as "Organization" , location as "Location" dc.id as asset_id from ${where.compliance.viewWithNistTabular} dc ${whereCondition(
          where.common.orgChainFilter,
          ...conditionFilter(condition)
        )}`;
      },
      count: function (condition, selector, date) {
        return `select count(distinct dc.id) as asset_count from ${where.compliance.viewWithNist} dc ${whereCondition(where.common.orgChainFilter)}`;
      },
      percentChange: function (condition, selector, date) {
        return 'select 100*(-1+1/(count(id)::numeric/(select count(id) from assets where organization_id in ( WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id WHERE tn.organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id)))) as percent_change from assets where created_at >= now()- interval \'1 week\' and organization_id in ( WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id WHERE tn.organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id)';
      }
    },
    postStages: [
      { type: 'setData', contextCheck: 'selector', contextCheckValue: 'tabular' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'Application' },
          { label: 'Sub-Application', path: 'Sub-Application' },
          { label: 'Asset', path: 'Asset' },
          { label: 'Location', path: 'Location' },
          { label: 'Organization', path: 'Organization' }
        ]
      }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'distributionRiskWidget',
    route: '/distribution/cce/counts',
    sql: {
      default: function (condition, selector, date) {
        return `select coalesce(o.final_count,0) as final_count,compliance_count, coalesce(asset_count,0) as count, p.name from ( select compliance_count,asset_count,compliance_count::float/nullif(total_count,0)*10 as final_count from (select count(id) as total_count,count(distinct id) as asset_count, count(case when result='fail' then 1 end) as compliance_count from daily_compliance_cce_score_view where reference_id like 'CCE%' and id in (select id from assets where (is_active='enabled' or is_active='true' or is_active='disabled') and ${
          where.common.orgChainFilter
        } ) as t) as o right join priorities p on o.final_count <= p.max_value::float and o.final_count >= p.min_value::float`;
      },
      total: function (condition, selector, date) {
        return `( select compliance_count,asset_count,compliance_count::float/nullif(total_count,0)*10 as final_count from (select count(id) as total_count,count(distinct id) as asset_count, count(case when result='fail' then 1 end) as compliance_count from daily_compliance_cce_score_view where reference_id like 'CCE%' and id in (select id from assets where organization_id in (WITH RECURSIVE org_cte(organization_id) AS (SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id) ) ) as t) `;
      }
    },
    expected_params: ['orgId']
  },

  {
    name: 'distributionWidgetTotal',
    route: '/distribution/cce/total',
    search_terms: ['compliance tabular data'],
    sql: {
      count: function (condition, selector, date) {
        return `select count(id) as compliance_count from daily_compliance_cce_score_view where reference_id like 'CCE%' and result='fail' and id in (select id from assets where (is_active='enabled' or is_active='true' or is_active='disabled') and ${
          where.common.orgChainFilter
        })`;
      },
      average: function (condition, selector, date) {
        return `select round(cast((fail_count::float/coalesce(NULLIF(compliance_count::float, 0),1)*10) as numeric),2) as score from (select count(id) as compliance_count, count(case when result='fail' then 1 end ) as fail_count from daily_compliance_cce_score_view where reference_id like 'CCE%' and id in (select id from assets where (is_active='enabled' or is_active='true' or is_active='disabled') and ${where.common.orgChainFilter})) as t`;
      },
      percentChange: function (condition, selector, date) {
        return `select 100*(-1+1/(count(id)::numeric/( select count(id) as compliance_count from daily_compliance_cce_score_view where reference_id like 'CCE%' and result='fail' and created_at >= now() - interval '1 week' and id in (select id from assets where (is_active='enabled' or is_active='true' or is_active='disabled') and ${
          where.common.orgChainFilter
        }) ))) as percent_change from daily_compliance_cce_score_view where reference_id like 'CCE%' and result='fail' and id in (select id from assets where (is_active='enabled' or is_active='true' or is_active='disabled') and ${
          where.common.orgChainFilter
        })`;
      },
      default: function (condition, selector, date) {
        return `select round(cast((fail_count::float/coalesce(NULLIF(compliance_count::float, 0),1)*10) as numeric),2) as score from (select count(id) as compliance_count, count(case when result='fail' then 1 end ) as fail_count from daily_compliance_cce_score_view where reference_id like 'CCE%' and id in (select id from assets where (is_active='enabled' or is_active='true' or is_active='disabled') and ${where.common.orgChainFilter})) as t`;
      },
      tabular: function (condition, selector, date) {
        return `select reference_id, result, asset_name as \"Asset\", vmid, application_name as \"Sub-Application\", application_grp_name as \"Application\", organization as \"Organization\", location as \"Location\", dc.id as asset_id from daily_compliance_cce_score_view dc where reference_id like 'CCE%' and ${
          where.common.orgChainFilter
        }`;
      }
    },
    postStages: [
      { type: 'setData', contextCheck: 'selector', contextCheckValue: 'tabular' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'Application' },
          { label: 'Sub-Application', path: 'Sub-Application' },
          { label: 'Asset', path: 'Asset' },
          { label: 'Location', path: 'Location' },
          { label: 'Organization', path: 'Organization' }
        ]
      }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'distributionWidgetTotalRegulation',
    route: '/distribution/cce/totalRegulation',

    sql: {
      default: function (condition, selector, date) {
        return 'select 4 as count';
      }
    },
    expected_params: ['orgId']
  },
  {
    name: 'distributionWidgetAsset',
    route: '/distribution/cce/asset',
    search_terms: ['assets tabular data'],
    sql: {
      default: function (condition, selector, date) {
        return 'select reference_id, result, asset_name, vmid, application_name, application_grp_name, organization, location from daily_compliance_cce_score_view where reference_id like \'CCE%\' and organization_id in ( WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id WHERE tn.organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id)';
      },
      tabular: function (condition, selector, date) {
        return 'select reference_id, result, asset_name as "Asset", vmid, application_name as "Application", application_grp_name as "Application", organization as "Organization", location as "Location" from daily_compliance_cce_score_view where reference_id like \'CCE%\' and organization_id in ( WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id WHERE tn.organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id)';
      },
      count: function (condition, selector, date) {
        return 'select count(id) from assets where organization_id in ( WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id WHERE tn.organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id)';
      },
      percentChange: function (condition, selector, date) {
        return 'select count(id)::numeric/(select count(id) from assets where organization_id in ( WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id WHERE tn.organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id)) from assets where created_at >= now()- interval \'1 week\' and organization_id in ( WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id WHERE tn.organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id)';
      }
    },
    postStages: [
      { type: 'setData', contextCheck: 'selector', contextCheckValue: 'tabular' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'Application' },
          { label: 'Sub-Application', path: 'Sub-Application' },
          { label: 'Asset', path: 'Asset' },
          { label: 'Location', path: 'Location' },
          { label: 'Organization', path: 'Organization' }
        ]
      }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'complianceStatusWidget',
    route: ['/regulationStatus', '/regulationStatus/temporal'],

    sql: {
      default: function (condition, selector, date) {
        return `select name, certificate_id, severity, total_controls, sum(failed_control_count) as failed_control_count,
        round(sum(case 
        when lower(severity)='low' then (failed_control_count*1.1*3) 
        when lower(severity)='medium' then (failed_control_count*1.2*5)
        when lower(severity)='high' then (failed_control_count*1.3*7)
        when lower(severity)='critical' then (failed_control_count*1.5*9)  end)::numeric,2) as score
        from (
        select c.name,c.id as certificate_id,result.severity, result.failed_control_count,
        (select count (control_id) from regulation_controls where certificate_id = c.id and compliance = 'Auto') as total_controls
        From
        (select  INITCAP(severity) as severity, rc.certificate_id,
        count(distinct control_id) as failed_control_count
        from daily_scan_xccdf_results scan
        JOIN xccdf_rules xr ON scan.rule_id = xr.rule_id and scan_result = 'FAIL'
        join (select asset_id, max(batch_id) as max_batch_id from daily_scan_xccdf_results where asset_id in (select id from assets
        where (is_active='enabled' or is_active='true' or is_active='disabled') and 
        ${condition.cloud_type ? `source = '${condition.cloud_type}'` : '1=1'} and
        organization_id in (select org_chain_list(:orgId)) ) group by asset_id) as max_scanresult on scan.asset_id = max_scanresult.asset_id and scan.batch_id = max_scanresult.max_batch_id
        join control_correlation_identifier cci on scan.reference  = cci.cci_id
        join regulation_nist_mappings rnm on cci.nist_index = rnm.nist_id
        join regulation_controls rc on rnm.certificate_id = rc.certificate_id and rnm.mapping_id = rc.mapping_id and compliance = 'Auto' and
        ${condition.cloud_type ? `cloud_type = '${condition.cloud_type}'` : '1=1'}
        where scan.organization_id in (select org_chain_list(:orgId)) and rc.certificate_id in (select distinct certificate_id From org_certificate_members where organization_id in (select org_chain_list(:orgId)) order by certificate_id)
        group by severity, rc.certificate_id) result join certificates c on c.id = result.certificate_id and c.is_active is null
        union all
        select c.name,c.id as certificate_id,result.severity, result.failed_control_count,
        (select count (control_id) from regulation_controls where certificate_id = c.id and compliance = 'Auto') as total_controls
        From
        (select  cis.severity as severity, rc.certificate_id, count(distinct rc.mapping_id) as failed_control_count
        from
        infrastructure_services_compliance infra
        join (select batch_id, entity_arn, cloud_type from (select batch_id, entity_arn,cloud_type, row_number() OVER (PARTITION BY cloud_type,entity_arn ORDER BY batch_id DESC) as rank from infrastructure_services_compliance where organization_id in (select org_chain_list(:orgId) ) group by batch_id,cloud_type,entity_arn) isc where rank <= 1 ) as max_batch_infra on max_batch_infra.batch_id = infra.batch_id and max_batch_infra.entity_arn = infra.entity_arn and max_batch_infra.cloud_type = infra.cloud_type
        and max_batch_infra.entity_arn = infra.entity_arn and (infra.entity_arn, infra.cis_control_id) not in (select entity_arn,control_id from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) )
        join cis_webservices_controls cis on cis.control_id = infra.cis_control_id
        join nist_cis_mappings ncm on ncm.mapping_id = cis.control_id and ncm.cloud_type = cis.cloud_type
        join regulation_nist_mappings rnm on ncm.nist_id = rnm.nist_id
        join regulation_controls rc on rc.mapping_id = rnm.mapping_id and rnm.certificate_id = rc.certificate_id and compliance = 'Auto' and
        ${condition.cloud_type ? `cloud_type = '${condition.cloud_type}'` : '1=1'}
        where result = 'FAIL' and rc.certificate_id in (select distinct certificate_id From org_certificate_members where organization_id in (select org_chain_list(:orgId)) order by certificate_id)
        group by cis.severity, rc.certificate_id
        ) result join certificates c on c.id = result.certificate_id and c.is_active is null
        order by name, severity
        ) donut_result
        group by name, certificate_id, severity, total_controls`;
      },
      services(condition, selector, date) {
        return `select c.name,c.id as certificate_id,result.severity, result.failed_control_count,
     (select count (control_id) from regulation_controls where certificate_id = c.id) as total_controls
     From 
    (select  cis.severity as severity, rc.certificate_id,
    count(distinct rc.mapping_id) as failed_control_count
  from 
  infrastructure_services_compliance infra 
 	 join (select batch_id, entity_arn, cloud_type from (select batch_id, entity_arn,cloud_type, row_number() OVER (PARTITION BY cloud_type,entity_arn ORDER BY batch_id DESC) as rank from infrastructure_services_compliance where organization_id in (select org_chain_list(:orgId) ) group by batch_id,cloud_type,entity_arn) isc where rank <= 1 ) as max_batch_infra on max_batch_infra.batch_id = infra.batch_id and max_batch_infra.entity_arn = infra.entity_arn and max_batch_infra.cloud_type = infra.cloud_type 
 	 and max_batch_infra.entity_arn = infra.entity_arn and (infra.entity_arn, infra.cis_control_id) not in (select entity_arn,control_id from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) ) 
 	 join cis_webservices_controls cis on cis.control_id = infra.cis_control_id and cis.cloud_type = '${condition.cloud_type}'
 	 join nist_cis_mappings ncm on ncm.mapping_id = cis.control_id and ncm.cloud_type = '${condition.cloud_type}' 
 	 join regulation_nist_mappings rnm on ncm.nist_id = rnm.nist_id
 	 join regulation_controls rc on rc.mapping_id = rnm.mapping_id and rnm.certificate_id = rc.certificate_id 
 	 where result = 'FAIL' and rc.certificate_id in (select distinct certificate_id From org_certificate_members where organization_id in (select org_chain_list(:orgId)) order by certificate_id)
 	 group by cis.severity, rc.certificate_id
 	 ) result join certificates c on c.id = result.certificate_id and c.is_active is null
 	 order by name, severity`;
      }
    },
    postStages: [
      {
        type: 'lodash',
        transformationType: 'map',
        transformer: (elem) => {
          elem[`${elem.severity}_count`] = elem.failed_control_count;
          delete elem.failed_control_count;
          delete elem.severity;
          return elem;
        }
      },
      {
        type: 'lodash',
        transformationType: 'reduce',
        transformer: (result, v, index) => {
          result[v.name] = Object.assign({}, result[v.name], v);
          result[v.name]['total_score'] = !isNaN(parseFloat(result[v.name]['total_score'])) ? parseFloat(result[v.name]['total_score']) : parseFloat(0);
          result[v.name]['total_score'] = parseFloat(result[v.name]['total_score']) + parseFloat(v.score);
          result[v.name]['total_score'] = parseFloat(result[v.name]['total_score']).toFixed(2);
          delete result[v.name]['score'];
          return result;
        }
      },
      { type: 'lodash', transformationType: 'values' }

    ],
    expected_params: ['orgId']
  },
  {
    name: 'complianceTopFiveWidget',
    route: ['/topFive', '/topFive/temporal'],

    sql: {
      location: function (condition, selector, date) {

        return complianceScore('location', condition);
      },
      appGroup: function (condition, selector, date) {
        return complianceScore('application_grp_name', condition);
      },
      org: function (condition, selector, date) {
        return complianceScore('organization_name', condition);
      }
    },
    expected_params: ['orgId']
  },
  {
    name: 'complianceRiskReduction',
    route: ['/riskReductionView', '/riskReductionView/temporal'],
    whereTransform: {
      default: function (selector) {
        const RegulationClass = ComplianceFactory.getRegulationByName(selector);
        const regulation = new RegulationClass();
        return regulation.getWhereMapping(selector);
      }
    },
    sql: {
      default: function (condition, selector, date) {
        const RegulationClass = ComplianceFactory.getRegulationByName(selector);
        const regulation = new RegulationClass();
        return regulation.riskReductionView(condition);

      },
      cci: function (condition, selector, date) {
        return `select *, (case when cum_vul<=20 then '20%' when cum_vul <=40 and cum_vul>20 then '40%' when cum_vul <=60 and cum_vul>40 then '60%' when cum_vul>60 then '80%' end) as cum_vul_group  from (
        select rownum, cci,location,asset_type, organization_name, application_grp_name, application_name, asset_name,severity, asset_id,(compliance_score::numeric/total_count) as compliance_score,
        round((rownum*100)/ (max(rownum) over()) :: float) as cum_vul, round(sum(compliance_score*100/total_score:: float) over(order by rownum )) as cummulative_reduction from (
        select row_number() over () as rownum,cci, location,asset_type, organization_name, application_grp_name, application_name,asset_name,asset_id,total_count,severity,compliance_score,sum(compliance_score) over() as total_score from (
        select cci_id as cci, location,asset_type, organization_name, application_grp_name, application_name, asset_name,asset_id,severity, count(dc.asset_id) as total_count, sum(case when lower(severity) ='low' then 2 when lower(severity) ='medium' then 5 when lower(severity) ='high' then 8 when lower(severity) ='critical' then 10 else 1 end) as compliance_score from
         ${complianceSelector(['source', 'asset_type', 'location', 'organization_name', 'application_grp_name', 'application_name', 'asset_id', 'asset_name', 'result', 'cci_id', 'rule_id'])} dc ,
          xccdf_rules x ${whereCondition(
          ...conditionFilter(condition),
          'dc.rule_id=x.rule_id',
          where.compliance.resultFailFilter
        )}  group by cci_id, location,asset_type, organization_name, application_grp_name, application_name, asset_name,asset_id,severity ) t 
         group by cci,location,asset_type, organization_name, application_grp_name, application_name, asset_name, asset_id,severity,total_count,compliance_score order by compliance_score desc ) r) j`;
      }

    },
    postStages: [
      { type: 'setData' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Organization', path: 'organization_name' },
          { label: 'Asset', path: 'asset_name' },
          { label: 'Application', path: 'application_grp_name' },
          { label: 'Sub-Application', path: 'application_name' },
          { label: 'Location', path: 'location' },
          // { label: 'Reduction Grouping', path: 'cum_vul_group' }, TODO: because this whereCondition breaks other widgets, remove until a better solution in place
          { label: 'CVE Id', path: 'cve_id' },
          { label: 'Asset Type', path: 'asset_type' }
        ]
      },
      { type: 'complianceMapping' }
    ],
    expected_params: ['orgId']
  },

  {
    name: 'complianceRiskImprovementWidget',
    route: '/riskImprovement',
    whereTransform: {
      default: function (selector) {
        const RegulationClass = ComplianceFactory.getRegulationByName(selector);
        const regulation = new RegulationClass();
        return regulation.getWhereMapping(selector);
      }
    },
    sql: {
      default: function (condition, selector, date) {
        const RegulationClass = ComplianceFactory.getRegulationByName(selector);
        const regulation = new RegulationClass();
        return regulation.riskReductionView(condition);
      },
      cci: function (condition, selector, date) {
        return `select *, (case when cum_vul<=20 then '20%' when cum_vul <=40 and cum_vul>20 then '40%' when cum_vul <=60 and cum_vul>40 then '60%' when cum_vul>60 then '80%' end) as cum_vul_group  from (
        select rownum, cci,location,asset_type, organization_name, application_grp_name, application_name, asset_name,severity, asset_id,(compliance_score::numeric/total_count) as compliance_score,
        round((rownum*100)/ (max(rownum) over()) :: float) as cum_vul, round(sum(compliance_score*100/total_score:: float) over(order by rownum )) as cummulative_reduction from (
        select row_number() over () as rownum,cci, location,asset_type, organization_name, application_grp_name, application_name, asset_name,asset_id,total_count,severity,compliance_score,sum(compliance_score) over() as total_score from (
        select cci_id as cci, location,asset_type, organization_name, application_grp_name, application_name, asset_name,asset_id,severity, count(dc.asset_id) as total_count, sum(case when lower(severity) ='low' then 2 when lower(severity) ='medium' then 5 when lower(severity) ='high' then 8 when lower(severity) ='critical' then 10 else 1 end) as compliance_score from
         ${complianceSelector(['source', 'asset_type', 'location', 'organization_name', 'application_grp_name', 'application_name', 'asset_id', 'asset_name', 'result', 'cci_id', 'rule_id'])} dc ,
          xccdf_rules x ${whereCondition(
          ...conditionFilter(condition),
          'dc.rule_id=x.rule_id',
          where.compliance.resultFailFilter
        )}  group by cci_id, location,asset_type, organization_name, application_grp_name, application_name, asset_name,asset_id,severity ) t 
         group by cci,location,asset_type, organization_name, application_grp_name, application_name, asset_name, asset_id,severity,total_count,compliance_score order by compliance_score desc ) r) j`;
      }

    },
    postStages: [
      {
        type: 'lodash',
        transformationType: 'groupBy',
        transformer: (d) => {
          if (d.cum_vul < 21) {
            return '20%';
          } else if (d.cum_vul < 41) {
            return '40%';
          } else if (d.cum_vul < 61) {
            return '60%';
          } else {
            return '80%';
          }
        }
      },
      {
        type: 'lodash',
        transformationType: 'map',
        transformer: (elem, key, collection) => {
          return { [key]: _.maxBy(elem, 'cummulative_reduction') };
        }
      },
      {
        type: 'merge'
      },
      { type: 'complianceMapping' }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'complianceRiskImprovementWidget',
    route: '/riskImprovement/temporal',
    sql: {
      default: function (condition, selector, date) {
        return `select rownum,cci,compliance_score,round( (rownum*100)/ (max(rownum) over ()) :: float) as cum_vul, round(sum (compliance_score*100/total_score :: float) over(order by rownum )) as cummulative_reduction from (select row_number() over () as rownum,cci,compliance_score,sum(compliance_score) over() as total_score from (select cci_id as cci, count(case when result='fail' then 1 end) as compliance_score from ${where.compliance.viewWithNist} as d where id in ( select id from assets where organization_id in (WITH RECURSIVE org_cte(organization_id) AS (SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id) )group by cci order by compliance_score desc ) as p ORDER BY compliance_score desc) t; `;
      },
      cci: function (condition, selector, date) {
        return `select rownum,cci,compliance_score,round( (rownum*100)/ (max(rownum) over ()) :: float) as cum_vul, round(sum (compliance_score*100/total_score :: float) over(order by rownum )) as cummulative_reduction from (select row_number() over () as rownum,cci,compliance_score,sum(compliance_score) over() as total_score from (select cci_id as cci, count(case when result='fail' then 1 end) as compliance_score from ${where.compliance.viewWithNist} as d where id in ( select id from assets where organization_id in (WITH RECURSIVE org_cte(organization_id) AS (SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id) )group by cci order by compliance_score desc ) as p ORDER BY compliance_score desc) t; `;
      },
      cce: function (condition, selector, date) {
        return `select rownum,cce,compliance_score,round( (rownum*100)/ (max(rownum) over ()) :: float) as cum_vul, round(sum (compliance_score*100/total_score :: float) over(order by rownum )) as cummulative_reduction from (select row_number() over () as rownum,cce,compliance_score,sum(compliance_score) over() as total_score from (select reference_id as cce, count(case when result='fail' then 1 end) as compliance_score from daily_compliance_cce_score_view as d where reference_id like 'CCE%' and id in ( select id from assets where organization_name_id in (WITH RECURSIVE org_cte(organization_name_id) AS (SELECT tn.organization_name_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_name_id and organization_name_id = :orgId UNION ALL SELECT c.organization_name_id FROM org_cte AS p, org_chains AS c join organization_names as o on o.id = c.organization_name_id WHERE c.parent_organization_name_id = p.organization_name_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_name_id) )group by cce order by compliance_score desc ) as p ORDER BY compliance_score desc) t; `;
      }
    },
    postStages: [
      {
        type: 'lodash',
        transformationType: 'groupBy',
        transformer: '(d)=>{if(d.cum_vul<21){return \'20%\' }else if(d.cum_vul<41){return \'40%\' }else if(d.cum_vul<61){return \'60%\'} else return \'80%\'}'
      },
      {
        type: 'lodash',
        transformationType: 'map',
        transformer: (elem, key, collection) => {
          return { [key]: _.maxBy(elem, 'cummulative_reduction') };
        }
      },
      {
        type: 'merge'
      }
    ],
    expected_params: ['orgId']
  },

  {
    name: 'topControlFailuresWidget',
    route: ['/topControlFailure', '/topControlFailure/temporal'],
    whereTransform: {
      default: function (selector) {
        const RegulationClass = ComplianceFactory.getRegulationByName(selector);
        const regulation = new RegulationClass();
        return regulation.getWhereMapping(selector);
      }
    },
    sql: {
      default: function (condition, selector, date) {
        const RegulationClass = ComplianceFactory.getRegulationByName(selector);
        const regulation = new RegulationClass();
        return regulation.topControlFailure(condition);

      }

    },
    expected_params: ['orgId']
  },
  {
    name: 'topControlFailuresWidget',
    route: '/topControlFailure/tabular',
    whereTransform: {
      default: function (selector) {
        const RegulationClass = ComplianceFactory.getRegulationByName(selector);
        const regulation = new RegulationClass();
        return regulation.getWhereMapping(selector);
      }
    },
    sql: {
      default: function (condition, selector, date) {
        const RegulationClass = ComplianceFactory.getRegulationByName(selector);
        const regulation = new RegulationClass();
        return regulation.topControlFailureTabular(condition);
      }

    },
    postStages: [
      { type: '_removeUUID' },
      { type: 'setData', contextCheck: 'selector', contextCheckValue: 'tabular' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Regulation', path: 'regulation' },
          { label: 'Organization', path: 'organization_name' },
          { label: 'Location', path: 'location' },
          { label: 'Application', path: 'Application' },
          { label: 'Sub-Application', path: 'Sub-Application' },
          { label: 'CCI', path: 'CCI' },
          { label: 'Severity', path: 'severity' },
          { label: 'Asset', path: 'asset_hash' },
          { label: 'Result', path: 'result' },
          { label: 'Scan Type', path: 'asset_type' },
          { label: 'Control Id', path: 'mapping_id' }
        ]
      },
      { type: 'orderSeverity' },
      { type: 'complianceMapping' }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'complianceControlBreakdownCaveoCircleWidget',
    route: '/regulationControlView',
    whereTransform: {
      default: function (selector) {
        const RegulationClass = ComplianceFactory.getRegulationByName(selector);
        const regulation = new RegulationClass();
        return regulation.getWhereMapping(selector);
      }
    },
    sql: {
      default: function (condition, selector, date) {
        const RegulationClass = ComplianceFactory.getRegulationByName(selector);
        const regulation = new RegulationClass();
        return regulation.regulationControlView(condition);
      }
    },
    postStages: [

      { type: 'setData' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Domain ID', path: 'domain_id' },
          { label: 'Title', path: 'title' },
          { label: 'Control ID', path: 'control_id' },
          { label: 'Mapping ID', path: 'mapping_id' },
          { label: 'CCI ID', path: 'cci' },
          { label: 'Asset Type', path: 'product' },
          { label: 'Application', path: 'application_name' },
          { label: 'Source', path: 'source' },
          { label: 'Result', path: 'result' }
        ]
      },
      {
        type: 'lodash',
        dataPath: 'data',
        contextCheck: 'controlCount',
        transformationType: 'reduce',
        transformer: (result, v, index) => {
          result[v.mapping_id] = result[v.mapping_id] || [];
          let obj = result[v.mapping_id].find(elem => elem.application == v.application_name && elem.source == v.source && elem.asset_type == v.product);
          if (!obj) {
            obj = {
              domain_id: v.domain_id,
              family_id: v.family_id,
              domain_name: v.domain_name,
              family_name: v.family_name,
              title: v.title,
              control_id: v.control_id,
              control_name: v.control_name,
              sub_control_id: v.sub_control_id,
              sub_control_name: v.sub_control_name,
              short_description: v.short_description,
              asset_type: v.product,
              application: v.application_name,
              source: v.source,
              mapping_id: v.mapping_id,
              passCCI: [],
              pass: 0,
              failCCI: [],
              fail: 0,
              falsePositiveCCI: [],
              falsePositive: 0,
              exemptionCCI: [],
              exemption: 0,
              compensatoryCCI: [],
              compensatory: 0
            };
            result[v.mapping_id].push(obj);
          }
          if (v.result.toLowerCase() == 'fail') {
            obj.failCCI.push(v.cci);
            obj.failCCI = Array.from(new Set(obj.failCCI));
            obj.fail = obj.failCCI.length;
          }
          if (v.result.toLowerCase() == 'pass') {
            obj.passCCI.push(v.cci);
            obj.passCCI = Array.from(new Set(obj.passCCI));
            obj.pass = obj.passCCI.length;
          }
          if (v.result.toLowerCase() == 'false positive') {
            obj.falsePositiveCCI.push(v.cci);
            obj.falsePositiveCCI = Array.from(new Set(obj.falsePositiveCCI));
            obj.falsePositive = obj.falsePositiveCCI.length;
          }
          if (v.result.toLowerCase() == 'exemption') {
            obj.exemptionCCI.push(v.cci);
            obj.exemptionCCI = Array.from(new Set(obj.exemptionCCI));
            obj.exemption = obj.exemptionCCI.length;
          }
          if (v.result.toLowerCase() == 'compensatory') {
            obj.compensatoryCCI.push(v.cci);
            obj.compensatoryCCI = Array.from(new Set(obj.compensatoryCCI));
            obj.compensatory = obj.compensatoryCCI.length;
          }
          return result;
        }
      },
      {
        type: 'lodash',
        transformationType: 'values',
        dataPath: 'data',
        contextCheck: 'controlCount'
      },
      {
        type: 'lodash',
        transformationType: 'flatten',
        dataPath: 'data',
        contextCheck: 'controlCount'
      },
      { type: 'complianceMapping' }
    ],
    expected_params: ['orgId']
  },

  {
    name: 'complianceControlBreakdownCaveoCircleTabularWidget',
    route: '/regulationControlView/tabular',
    sql: {
      default: function (condition, selector, date) {
        const RegulationClass = ComplianceFactory.getRegulationByName(selector);
        const regulation = new RegulationClass();
        return regulation.regulationControlViewDownload(condition);

      }
    },
    postStages: [
      {
        type: 'setData'
      },
      {
        type: 'lodash',
        transformationType: 'reduce',
        transformer:
          (result, v, index) => {
            const o = result[v.cci] || {};
            o.cci = v.cci;
            o.applications = o.applications || [];
            if (!o.applications.find((a) => {
              return v.application_name === a.application && v.asset_name === a.asset_name;
            })) {
              o.applications.push({ application_name: v.application, asset_name: v.asset_name });
            }
            o.regulation = v.regulation;
            o.type = v.type;
            o.short_description = v.short_description;
            o.family_control = v.family_control;
            o.title = v.title;
            o.definition = v.definition;
            o.rule_identifiers = v.rule_identifiers;
            o.asset_name = o.asset_name || [];
            if (!o.asset_name.includes(v.asset_name)) o.asset_name.push(v.asset_name);
            result[v.cci] = o;
            if (index <= 1) return { [v.cci]: o };
            return result;
          }
      },
      {
        type: 'lodash',
        transformationType: 'values'
      },
      { type: 'complianceMapping' }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'regulationControlViewDownload',
    route: '/regulationControlView/download',
    sql: {
      default: function (condition, selector, date) {
        const RegulationClass = ComplianceFactory.getRegulationByName(selector);
        const regulation = new RegulationClass();
        return regulation.regulationControlViewDownload(condition);

      }
    },
    postStages: [
      { type: 'xml2Yaml', path: 'rule_desc' },
      {
        type: 'setData'
      },
      {
        type: 'lodash',
        transformationType: 'reduce',
        transformer:
          (result, v, index) => {
            const o = result[v.cci] || {};
            o.cci = v.cci;
            o.control_id = v.control_id;
            o.applications = o.applications || [];
            if (!o.applications.find((a) => {
              return v.application_name === a.application && v.asset_name === a.asset_name;
            })) {
              o.applications.push({ application_name: v.application, asset_name: v.asset_name });
            }
            o.rules = o.rules || [];
            if (!o.rules.find((rule) => {
              return rule.result === v.result && v.rule_id === rule.rule_id;
            })) {
              o.rules.push({
                rule_fix: v.rule_fix,
                rule_id: v.rule_id,
                rule_desc: v.rule_desc,
                result: v.result,
                applications: []
              });
            }
            const rule = o.rules.find((rule) => {
              return v.rule_id === rule.rule_id && rule.result == v.result;
            });
            if (!rule.applications.find((a) => {
              return v.application_name === a.application && v.asset_name === a.asset_name;
            })) {
              rule.applications.push({ application_name: v.application, asset_name: v.asset_name });
            }
            if (!rule.rule_title) rule.rule_title = v.rule_title;
            if (!rule.test_result) {
              try {
                rule.test_result = (v.test_result != null) ? JSON.parse(v.test_result) : {};
              } catch (e) {
                rule.test_result = {};
              }
            }
            o.regulation = v.regulation;
            o.scan_type = v.scan_type;
            o.short_description = v.short_description;
            o.family_control = v.family_control;
            o.title = v.title;
            o.definition = v.definition;
            o.rule_identifiers = v.rule_identifiers;
            o.asset_name = o.asset_name || [];
            if (!o.asset_name.includes(v.asset_name)) o.asset_name.push(v.asset_name);
            result[v.cci] = o;
            if (index <= 1) return { [v.cci]: o };
            return result;
          }
      },
      {
        type: 'lodash',
        transformationType: 'values'
      },
      { type: 'complianceMapping' }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'complianceControlBreakdownCaveoCircleDownloadWidget',
    route: '/regulationControlView/assetCentric/download',
    sql: {
      default: function (condition, selector, date) {
        const RegulationClass = ComplianceFactory.getRegulationByName(selector);
        const regulation = new RegulationClass();
        return regulation.regulationControlViewDownload(condition);

      }
    },
    postStages: [
      { type: 'xml2Yaml', path: 'rule_desc' },
      {
        type: 'lodash',
        transformationType: 'reduce',
        transformer:
          (result, v, index) => {
            const o = result[v.id] || {};
            o.asset_id = v.id;
            o.operating_system = v.operating_system;
            o.regulation = v.regulation;
            o.asset_name = v.asset_name;
            o.application = v.application;
            o.control_id = o.control_id ? o.control_id : [];
            o.control_id.push(v.control_id);
            o.control_id = _.uniq(o.control_id);
            o.family_control = o.family_control ? o.family_control : [];
            o.family_control.push(v.family_control);
            o.family_control = _.uniq(o.family_control);
            o.rules = o.rules || [];
            if (!o.rules.find((rule) => {
              return v.rule_id === rule.rule_id;
            })) {
              o.rules.push({
                sub_control: v.sub_control,
                family_control: v.family_control,
                cci: v.cci,
                severity: v.severity,
                control_id: v.control_id,
                rule_fix: v.rule_fix,
                rule_id: v.rule_id,
                rule_desc: v.rule_desc,
                result: v.result,
                short_description: v.short_description
              });
              o.rules.sort((rule1, rule2) => {
                if (rule1.control_id > rule2.control_id) return 1;
                if (rule1.control_id < rule2.control_id) return -1;
                if (rule1.control_id == rule2.control_id) return 0;
              });
            }
            o.rules.sort((r1, r2) => {
              if (r1.cci > r2.cci) return 1;
              if (r1.cci < r2.cci) return -1;
              return 0;
            });
            const rule = o.rules.find((rule) => {
              return v.rule_id === rule.rule_id;
            });
            if (!rule.rule_desc) rule.rule_desc = v.rule_desc;
            if (!rule.rule_fix) rule.rule_fix = v.rule_fix;
            o.definition = v.definition;
            o.rule_identifiers = v.rule_identifiers;
            if (!rule.rule_title) rule.rule_title = v.rule_title;
            if (!rule.test_result) {
              try {
                rule.test_result = (v.test_result != null) ? JSON.parse(v.test_result) : {};
              } catch (e) {
                rule.test_result = {};
              }
            }

            result[v.id] = o;
            if (index <= 1) return { [v.id]: o };
            o[v.control_id] = o.rules.map(a => {
              if (a.control_id === v.control_id) {
                return a;
              }
            });
            o[v.control_id] = o[v.control_id].filter(a => a);
            return result;
          }
      },
      {
        type: 'lodash',
        transformationType: 'values'
      },
      { type: 'complianceMapping' }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'complianceControlBreakdownCaveoCircleDownloadWidget',
    route: '/regulationControlView/appCentric/download',
    sql: {
      default: function (condition, selector, date) {
        const RegulationClass = ComplianceFactory.getRegulationByName(selector);
        const regulation = new RegulationClass();
        return regulation.regulationControlViewDownload(condition);

      }
    },
    postStages: [
      { type: 'xml2Yaml', path: 'rule_desc' },
      {
        type: 'lodash',
        transformationType: 'reduce',
        transformer:
          (result, v, index) => {
            result[v.result] = result[v.result] || {};
            const o = result[v.result][v.application] || {};
            o.application_name = v.application;
            o.regulation = v.regulation;
            o.severity = v.severity;
            o.result = _.every(o.controls, c => c.result == 'Fail') ? 'Fail' : v.result;
            o.controls = o.controls || [];
            let control = o.controls.find(control => control.control_id == v.control_id);
            if (!control) {
              control = {
                control_id: v.control_id,
                sub_control: v.sub_control,
                family_control: v.family_control,
                assets: []
              };
              o.controls.push(control);
            }
            control.result = _.every(control.asset, a => a.result == 'Fail') ? 'Fail' : v.result;

            let asset = control.assets.find(a => a.asset_id == v.id);
            if (!asset) {
              asset = { asset_name: v.asset_name, operating_system: v.operating_system, asset_id: v.id, ccis: [] };
              control.assets.push(asset);
            }
            asset.result = _.every(asset.ccis, cci => cci.result == 'Fail') ? 'Fail' : v.result;

            let cci = asset.ccis.find(cci => cci.cci_id == v.cci);
            if (!cci) {

              cci = {
                cci_id: v.cci,
                rules: []

              };
              asset.ccis.push(cci);
            }
            let rule = cci.rules.find(r => r.rule_id == v.rule_id);
            if (!rule) {
              let test_result = {};
              try {
                test_result = (v.test_result != null) ? JSON.parse(v.test_result) : {};
              } catch (e) {

              }
              rule = {
                rule_id: v.rule_id,
                rule_desc: v.rule_desc,
                rule_fix: v.rule_fix,
                definition: v.definition,
                rule_identifiers: v.rule_identifiers,
                rule_title: v.rule_title,
                result: v.result,
                severity: v.severity,
                test_result
              };
              cci.rules.push(rule);
            }
            result[v.result][v.application] = o;
            if (index <= 1) return { [v.result]: { [v.application]: o } };
            return result;
          }
      },
      { type: 'complianceMapping' }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'complianceControlBreakdownCaveoCircleSubControlWidget',
    route: '/regulationControlView/:subControl',
    sql: {
      default: function (condition, selector, date, params) {
        const { subControl } = params;
        const RegulationClass = ComplianceFactory.getRegulationByName(selector);
        const regulation = new RegulationClass();
        return regulation.regulationControlViewSubControl(condition, subControl);

      }

    },
    expected_params: ['orgId', 'subControl']
  },

  {
    name: 'cciIdLookupWidget',
    route: '/cciId/:cciId',
    sql: {
      default: function (condition, selector, date) {
        const cloudType = condition.cloud_type ? `cis.cloud_type = '${condition.cloud_type}' and` : '';
        const result = condition.result ? `where result = '${condition.result.toUpperCase()}'` : '';
        const assetId = condition.asset_id ? ` ags.service_id = '${condition.asset_id}' and` : '';
        return `select distinct r.rule_id, r.rule_fix, r.rule_desc,a.type as asset_type,dc.organization_name, dc.org_alias_name as alias_name, concat(dc.org_alias_name,' (',dc.organization_name,')') as full_name, dc.organization_id, dc.application_grp_name, dc.application_name, dc.asset_name, dc.asset_id::varchar, dc.source,dc.cci_id as cci_id,dc.result, dc.definition,r.rule_identifiers, dc.test_result,dc.rule_title,dc.scan_type  from 
        ${where.compliance.viewWithNistTabular} dc join assets a on a.id = dc.id join xccdf_rules r on r.rule_id = dc.rule_id ${whereCondition(...conditionFilter(condition), 'position(:cciId in rule_identifiers) > 0 and cci_id = :cciId')}
        UNION ALL
        select * from ( select 
        cis.control_id,  cis.remediation_procedure, cis.description,infra.product,o.name, o.alias_name, concat(o.alias_name,' (',o.name,')') as full_name,o.id, ags.application_name, ags.sub_app_name, infra.entity_name, infra.entity_arn, ags.cloud_type, cis.control_id,  ${where.compliance.exemptionServiceFilter} as result, cis.description, cis.control_id, infra.remediation, cis.title, 'services' as scan_type
        from infrastructure_services_compliance infra
        join (select batch_id, entity_arn, cloud_type from (select batch_id, entity_arn,cloud_type, row_number() OVER (PARTITION BY cloud_type,entity_arn ORDER BY batch_id DESC) as rank from infrastructure_services_compliance where organization_id in (select org_chain_list(:orgId) ) group by batch_id,cloud_type,entity_arn) isc where rank <= 1 ) as max_batch_infra on max_batch_infra.batch_id = infra.batch_id and max_batch_infra.entity_arn = infra.entity_arn and max_batch_infra.cloud_type = infra.cloud_type
        join cis_webservices_controls cis on cis.control_id = infra.cis_control_id and cis.cloud_type = infra.cloud_type
        join application_group_service_view ags on infra.entity_arn = ags.entity_arn and ags.organization_id in (select org_chain_list(:orgId))
        join organizations o on o.id = infra.organization_id
        where infra.organization_id in (select org_chain_list(:orgId)) and
        cis.control_id = :cciId and
        ${cloudType}
        ${assetId}
        1=1
        group by infra.entity_name, infra.entity_arn, cis.control_id, cis.remediation_procedure,ags.service_id,cis.title,infra.product,cis.description,o.id,o.name, ags.application_name,ags.application_name, ags.sub_app_name, ags.entity_name, ags.entity_arn, ags.cloud_type, cis.control_id, infra.result, cis.description, cis.control_id, infra.remediation, cis.title ) as outer_sql 
        ${result} `;
      },

      all: function (condition, selector, date) {
        return `select distinct r.rule_id, r.rule_fix, r.rule_desc, dc.application_grp_name, dc.application_name, dc.asset_name, dc.asset_id, dc.cci_id as cci_id,dc.result, dc.definition,r.rule_identifiers, dc.test_result,dc.rule_title from 
        ${where.compliance.viewWithNist} dc join xccdf_rules r on r.rule_id = dc.rule_id where  ${where.common.orgChainFilter}`;
      }

    },
    expected_params: ['orgId', 'cciId'],
    postStages: [
      { type: 'xml2Yaml', path: 'rule_desc' },
      {
        type: 'lodash',
        transformationType: 'reduce',
        transformer:
          (result, v, index) => {
            const o = result[v.cci_id] || {};
            o.cci_id = v.cci_id;
            o.source = v.source;
            o.organization_name = v.organization_name;
            o.organization_id = v.organization_id;
            o.alias_name = v.alias_name;
            o.full_name = v.full_name;
            o.asset_type = v.asset_type;
            o.applications = o.applications || [];
            if (!o.applications.find((a) => {
              return v.application_grp_name === a.application_grp_name && v.application_name === a.application_name && v.asset_name === a.asset_name && v.asset_id === a.asset_id;
            })) {
              o.applications.push({
                application_name: v.application_name,
                application_grp_name: v.application_grp_name,
                asset_name: v.asset_name,
                asset_id: v.asset_id
              });
            }
            o.rules = o.rules || [];
            if (!o.rules.find((rule) => {
              return v.rule_id === rule.rule_id;
            })) {
              o.rules.push({
                rule_fix: v.rule_fix,
                rule_id: v.rule_id,
                rule_desc: v.rule_desc,
                result: v.result,
                scan_type: v.scan_type
              });
            }
            const rule = o.rules.find((rule) => {
              return v.rule_id === rule.rule_id;
            });
            if (!rule.rule_desc) rule.rule_desc = v.rule_desc;
            if (!rule.rule_fix) rule.rule_fix = v.rule_fix;
            rule.assets = rule.assets || [];
            rule.assets.push(v.asset_name);
            rule.asset_ids = rule.asset_ids || [];
            rule.asset_ids.push(v.asset_id);
            rule.assets = Array.from(new Set(rule.assets));
            o.status = v.status;
            o.location = v.location;
            o.title = v.title;
            o.contributor = v.contributor;
            o.index = v.index;
            o.definition = v.definition;
            o.rule_identifiers = v.rule_identifiers;
            o.asset_name = o.asset_name || [];
            o.asset_id = o.asset_id || [];
            if (!rule.rule_title) rule.rule_title = v.rule_title;
            if (!rule.test_result) {
              try {
                rule.test_result = (v.test_result != null) ? JSON.parse(v.test_result) : {};
              } catch (e) {
                rule.test_result = {};
              }
            }
            if (!o.asset_name.includes(v.asset_name)) o.asset_name.push(v.asset_name);
            if (!o.asset_id.includes(v.asset_id)) o.asset_id.push(v.asset_id);
            result[v.cci_id] = o;
            if (index <= 1) return { [v.cci_id]: o };
            return result;
          }
      },
      {
        type: 'lodash',
        transformationType: 'values'
      }
    ]
  },
  {
    name: 'cciIdLookupWidget',
    route: '/cciId/:cciId/assetCentric',
    sql: {
      default: function (condition, selector, date) {
        return `select distinct dc.id, r.rule_id, r.rule_fix, r.rule_desc,a.type as asset_type, dc.application_grp_name, dc.application_name, dc.asset_name, dc.cci_id as cci_id,dc.result, dc.definition,r.rule_identifiers from 
        ${where.compliance.viewWithNist} dc join assets a on a.id = dc.id join xccdf_rules r on r.rule_id = dc.rule_id ${whereCondition(...conditionFilter(condition), 'r.rule_identifiers like \'%\'||:cciId||\'%\''// where.common.orgChainFilter,
          //where.compliance.resultFailFilter
        )}`;
      },
      all: function (condition, selector, date) {
        return `select distinct r.rule_id, r.rule_fix, r.rule_desc, dc.application_grp_name, dc.application_name, dc.asset_name, dc.cci_id as cci_id,dc.result, dc.definition,r.rule_identifiers from 
        ${where.compliance.viewWithNist} dc join xccdf_rules r on r.rule_id = dc.rule_id where  ${where.common.orgChainFilter}`;
      }

    },
    expected_params: ['orgId', 'cciId'],
    postStages: [
      { type: 'xml2Yaml', path: 'rule_desc' },
      {
        type: 'lodash',
        transformationType: 'reduce',
        transformer:
          (result, v, index) => {
            const o = result[v.id] || {};
            o.asset_id = v.id;
            o.asset_name = v.asset_name;
            o.applications = o.applications || [];
            if (!o.applications.find((a) => {
              return v.application_grp_name === a.application_grp_name && v.application_name === a.application_name && v.asset_name === a.asset_name;
            })) {
              o.applications.push({
                application_name: v.application_name,
                application_grp_name: v.application_grp_name,
                asset_name: v.asset_name
              });
            }
            o.rules = o.rules || [];
            if (!o.rules.find((rule) => {
              return v.rule_id === rule.rule_id;
            })) {
              o.rules.push({
                cci: v.cci_id,
                rule_fix: v.rule_fix,
                rule_id: v.rule_id,
                rule_desc: v.rule_desc,
                result: v.result
              });
            }
            const rule = o.rules.find((rule) => {
              return v.rule_id === rule.rule_id;
            });
            if (!rule.rule_desc) rule.rule_desc = v.rule_desc;
            if (!rule.rule_fix) rule.rule_fix = v.rule_fix;
            // rule.assets = rule.assets || []
            // rule.assets.push(v.asset_name); rule.assets = Array.from(new Set(rule.assets))
            o.status = v.status;
            o.location = v.location;
            o.title = v.title;
            o.contributor = v.contributor;
            o.index = v.index;
            o.definition = v.definition;
            o.rule_identifiers = v.rule_identifiers;
            o.asset_name = o.asset_name || [];
            if (!o.asset_name.includes(v.asset_name)) o.asset_name.push(v.asset_name);
            result[v.id] = o;
            if (index <= 1) return { [v.id]: o };
            return result;
          }
      },
      {
        type: 'lodash',
        transformationType: 'values'
      }
      // {
      //   type: 'lodash',
      //   transformationType: 'filter',
      //   transformer:" (val)=>{ return val.cci_id.includes(context.cciId )}"
      // }
    ]
  },
  {
    name: 'cceIdLookupWidget',
    route: '/cceId/:cceId',
    sql: {
      default: function (condition, selector, date) {
        return `select r.rule_id, dr.created_at, r.rule_fix, r.rule_desc, dr.application_grp_name, dr.application_name, 
        dr.asset_name,dr.reference_id as cce_id,r.rule_identifiers from daily_compliance_cce_score_view dr 
        join xccdf_rules r on r.rule_id = dr.rule_id where r.rule_identifiers like '%'||:cceId||'%' and dr.reference_id like '%CCE%' and ${where.common.orgChainFilter} `;
      }
    },
    expected_params: ['orgId', 'cceId'],
    postStages: [
      {
        type: 'lodash',
        transformationType: 'reduce',
        transformer:
          (result, v, index) => {
            const o = result[v.cce_id] || {};
            o.cce_id = v.cce_id;
            o.applications = o.applications || [];
            if (!o.applications.find((a) => {
              return v.application_grp_name == a.application_grp_name && v.application_name == a.application_name && v.asset_name == a.asset_name;
            })) {
              o.applications.push({
                application_name: v.application_name,
                application_grp_name: v.application_grp_name,
                asset_name: v.asset_name
              });
            }
            o.rules = o.rules || [];
            if (!o.rules.find((rule) => {
              return v.rule_id == rule.rule_id;
            })) {
              o.rules.push({ rule_fix: v.rule_fix, rule_id: v.rule_id, rule_desc: v.rule_desc });
            }
            o.status = v.status;
            o.location = v.location;
            o.title = v.title;
            o.contributor = v.contributor;
            o.index = v.index;
            o.definition = v.definition;
            o.rule_identifiers = v.rule_identifiers;
            o.asset_name = o.asset_name || [];
            if (!o.asset_name.includes(v.asset_name)) o.asset_name.push(v.asset_name);
            result[v.cce_id] = o;
            if (index <= 1) return { [v.cce_id]: o };
            return result;
          }
      },
      {
        type: 'lodash',
        transformationType: 'values'
      }
    ]
  },

  {
    name: 'assetLookUpWidget',
    route: '/assetLookup/:assetId/',
    sql: {
      default: function (condition, selector, date) {
        return `select r.rule_id, r.rule_fix, r.rule_desc,dr.network_ip as ip,dr.source,dr.managed,dr.realm, dr.vmid,
        dr.application_quarantine,dr.application_grp_quarantine,dr.location, dr.cpu_count, dr.memory_size,dr.result, dr.application_grp_name, dr.application_name, dr.asset_name,
         dr.contributor, dr.definition,dr.index,dr.status,dr.cci_id from ${where.compliance.viewWithNist} dr  
        join xccdf_rules r on r.rule_id = dr.rule_id 
        ${whereCondition(...conditionFilter(condition), 'dr.id = :assetId')} `;
      }
    },
    expected_params: ['orgId', 'assetId'],
    postStages: [
      { type: '_removeUUID' },
      { type: 'xml2Yaml', path: 'rule_desc' },
      {
        type: 'lodash',
        transformationType: 'reduce',
        transformer:
          (result, v, index) => {
            result.ccis = result.ccis || {};
            const o = result.ccis[v.cci_id] || {};
            o.cci_id = v.cci_id;
            result.applications = result.applications || [];
            if (!result.applications.find((a) => {
              return v.application_grp_name === a.application_grp_name && v.application_name === a.application_name && v.asset_name === a.asset_name;
            })) {
              result.applications.push({
                application_name: v.application_name,
                application_grp_name: v.application_grp_name,
                asset_name: v.asset_name,
                application_quarantine: v.application_grp_quarantine,
                sub_application_quarantine: v.application_quarantine
              });
            }
            o.rules = o.rules || [];
            if (!o.rules.find((rule) => {
              return v.rule_id === rule.rule_id;
            })) {
              o.rules.push({ rule_fix: v.rule_fix, rule_id: v.rule_id, result: v.result, rule_desc: v.rule_desc });
            }
            result.status = v.status;
            result.location = v.location;
            result.ip = v.ip;
            result.vmid = v.vmid;
            result.source = v.source;
            result.realm = v.realm;
            result.managed = v.managed;
            result.cpu_count = v.cpu_count;
            result.operating_system = v.operating_system;
            o.contributor = v.contributor;
            o.index = v.index;
            o.definition = v.definition;
            o.rule_identifiers = v.rule_identifiers;
            result.ccis[v.cci_id] = o;
            if (index <= 1) return { ccis: { [v.cci_id]: o } };
            return result;
          }
      }
    ]
  },
  {
    name: 'awsInfrastructureWidget',
    route: '/aws/infrastructure',
    sql: {
      default: function (condition, selector, date) {
        const filterClause = selector ? `lower(title) like lower('%${selector}%')` : '1=1';
        return `select * from infrastructure_services_compliance ${whereCondition(
          ...conditionFilter(condition),
          filterClause,
          where.common.orgChainFilter,
          'created_at::DATE = (select max(created_at::DATE) from infrastructure_services_compliance)'
        )}`;
      }
    },
    postStages: [
      {
        type: 'lodash',
        transformationType: 'map',
        transformer: (elem, key, collection) => {
          const obj = {};
          for (const k in elem) {
            if (k == 'remediation') {
              obj[k] = elem[k].split('^^');
            } else if (k == 'product') {
              obj[k] = elem[k]
                .replace('{', '')
                .replace('}', '')
                .replace(/aws\/securityhub\//g, '')
                .split(', ')
                .map((str) => {
                  return str.split('=');
                })
                .reduce((accumulator, currentValue) => {
                  accumulator[currentValue[0]] = currentValue[1];
                  return accumulator;
                }, {});
            } else if (k == 'title') {
              const [cis, ...title] = elem[k].split(' ');
              obj.cis = cis;
              obj.title = title.join(' ');
            } else {
              obj[k] = elem[k];
            }

          }
          return obj;
        }
      }
      // {type:'lodash','transformationType':'filter','transformer':(elem)=>{}}
    ]
  },
  {
    name: 's3Details',
    route: '/aws/s3',
    sql: {
      default(condition, selector, date) {
        return `select s3.name as bucket, detail, are.connection_name as region from aws_s3_details s3 
                join asset_repo_endpoints are on s3.asset_repo_endpoint_id = are.id ${whereCondition(
          `are.organization_id in (select org_chain_list(:orgId))`,
          's3.created_at::DATE = (select max(created_at::DATE) from aws_s3_details)'
        )}`;
      }
    }
    // postStages: [
    //   {
    //     type: 'lodash',
    //     transformationType: 'map',
    //     transformer: (elem) => {
    //       elem.detail = JSON.parse(elem.detail);
    //       return elem;
    //     }
    //   }
    // ]
  },
  {
    name: 'cisLookup',
    route: '/cloud/cis/:cisId',
    sql: {
      default(condition, selector, date) {
        return `select * from cis_controls ${whereCondition('mapping_id = :cisId')}`;
      }
    }
  },
  {
    name: 'topFailedControlFamilyWidget',
    route: '/topFailedControlFamily',
    whereTransform: {
      default: function (selector) {
        const RegulationClass = ComplianceFactory.getRegulationByName(selector);
        const regulation = new RegulationClass();
        return regulation.getWhereMapping(selector);
      }
    },
    sql: {
      default: function (condition, selector, date) {
        const RegulationClass = ComplianceFactory.getRegulationByName(selector);
        const regulation = new RegulationClass();
        return regulation.topFailedControlFamily(condition);

      }
    },
    expected_params: ['orgId']
  },
  {
    name: 'regulationDistributionWidget',
    route: '/regulationDistribution',
    whereTransform: {
      default: function (selector) {
        const RegulationClass = ComplianceFactory.getRegulationByName(selector);
        const regulation = new RegulationClass();
        return regulation.getWhereMapping(selector);
      }
    },
    sql: {
      default: function (condition, selector, date) {
        const RegulationClass = ComplianceFactory.getRegulationByName(selector);
        const regulation = new RegulationClass();
        return regulation.regulationDistribution(condition);
      }
    },
    expected_params: ['orgId']
  },
  {
    name: 'regulationDistributionWidget',
    route: '/regulationDistribution/total',
    whereTransform: {
      default: function (selector) {
        const RegulationClass = ComplianceFactory.getRegulationByName(selector);
        const regulation = new RegulationClass();
        return regulation.getWhereMapping(selector);
      }
    },
    sql: {
      default: function (condition, selector, date) {
        const RegulationClass = ComplianceFactory.getRegulationByName(selector);
        const regulation = new RegulationClass();
        return regulation.regulationDistributionTotals(condition);
      }
    },
    postStages: [

      { type: 'setData' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Name', path: 'Name' },
          { label: 'Description', path: 'Description' },
          { label: 'Compliance', path: 'Compliance' }
        ]
      },
      { type: 'complianceMapping' }
    ]
  },
  {
    name: 'regulationDistributionWidget',
    route: '/regulationDistribution/tabular',
    whereTransform: {
      default: function (selector) {
        const RegulationClass = ComplianceFactory.getRegulationByName(selector);
        const regulation = new RegulationClass();
        return regulation.getWhereMapping(selector);
      }
    },
    sql: {
      default: function (condition, selector, date) {
        const RegulationClass = ComplianceFactory.getRegulationByName(selector);
        const regulation = new RegulationClass();
        return regulation.regulationDistributionTabular(condition);
      }
    },
    postStages: [

      { type: '_removeUUID' },
      {
        type: 'setData'
      },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Asset', path: 'Asset' },
          { label: 'Organization', path: 'Organization' },
          { label: 'Application', path: 'Application' },
          { label: 'Sub-Application', path: 'Sub-Application' },
          { label: 'CCI', path: 'CCI' },
          { label: 'Result', path: 'Result' },
          { label: 'NIST Id', path: 'NIST Id' },
          { label: 'APRA-CPS Control', path: 'APRA-CPS Control' },
          { label: 'NESA Control', path: 'NESA Control' },
          { label: 'HIPAA Control', path: 'HIPAA Control' },
          { label: 'PCI Control', path: 'PCI Control' },
          { label: 'ISO Control', path: 'ISO Control' },
          { label: 'GDPR Control', path: 'GDPR Control' },
          { label: 'Severity', path: 'Severity' },
          { label: 'FEDRAMP HIGH Control', path: 'FEDRAMP HIGH Control' },
          { label: 'FEDRAMP LOW Control', path: 'FEDRAMP LOW Control' },
          { label: 'FEDRAMP MODERATE Control', path: 'FEDRAMP MODERATE Control' },
          { label: 'FFIEC Control', path: 'FFIEC Control' },
          { label: 'SAMA Control', path: 'SAMA Control' }
        ]
      },
      { type: 'complianceMapping' }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'softwareListLookup',
    route: '/reports/application/:applicationId',
    sql: {
      default: function (condition, selector, date) {
        const [regulationName, queryType] = selector.split('_');
        const RegulationClass = ComplianceFactory.getRegulationByName(regulationName);
        const regulation = new RegulationClass();
        switch (queryType) {
          case 'status':
            return regulation.applicationReportsStatus(condition);
          case 'controls':
            return regulation.applicationReportsControls(condition);
          default:
            return regulation.applicationReportsBase(condition);
        }

      }

    },

    postStages: [
      {
        type: 'join',
        accessor: (obj) => {
          return obj.sub_control;
        }
      },
      {
        type: 'lodash',
        transformationType: 'reduce',
        transformer:
          (result, v, index) => {
            const obj = result[v['sub_control']] || { Pass: [], Fail: [] };
            for (const key in v) {
              // if (key == 'sub_control') continue
              if (key == 'asset_name') continue;
              if (key == 'result') {
                obj[v[key]].push(v['asset_name']);
                obj[v[key]] = Array.from(new Set(obj[v[key]]));
                obj['Pass'] = obj['Pass'].filter(num => !obj['Fail'].includes(num));
                continue;
              }
              // if(v[key] == '') continue
              if (!obj[key] || obj[key] == '') {
                obj[key] = v[key];
              }
            }
            result[v['sub_control']] = obj;

            return result;
          }
      },
      { type: 'lodash', transformationType: 'values' },
      { type: 'lodash', transformationType: 'filter', transformer: (obj) => obj.found },
      { type: 'complianceMapping' }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'hytrust',
    sql: {
      default: function (condition, selector, date) {
        return `select * from nist_hytrust_mappings`;
      }
    }
  },
  {
    name: 'fortinet',
    sql: {
      default: function (condition, selector, date) {
        return `select * from nist_fortigate_mappings`;
      }
    }
  },
  {
    name: 'complianceScorer',
    route: '/scorer',
    sql: {
      default: function (condition, selector, date) {
        return complianceScore(selector, condition);
      },
      priority: function (condition, selector, date) {
        return `select * from priorities`;
      }
    }
  },
  {
    name: 'regulationDistributionCounts',
    route: '/regulationDistribution/counts',
    sql: {
      default: function (condition, selector, date) {
        const RegulationClass = ComplianceFactory.getRegulationByName(selector);
        const regulation = new RegulationClass();
        return regulation.regulationDistributionCounts(condition);
      }
    },
    postStages: [
      { type: 'complianceScorer' }

    ]
  },
  {
    name: 'regulationDistributionFamilyCounts',
    route: '/regulationDistributionFamily/counts',
    sql: {
      default: function (condition, selector, date) {
        const RegulationClass = ComplianceFactory.getRegulationByName(selector);
        const regulation = new RegulationClass();
        return regulation.regulationDistributionFamilyCounts(condition);
      }
    },
    postStages: [
      { type: 'complianceScorer' },
      { type: 'complianceMapping' }
    ]
  },
  {
    name: 'assetPassFailCount',
    route: '/asset/counts',
    sql: {
      default: function (condition, selector, date) {
        const RegulationClass = ComplianceFactory.getRegulationByName(selector);
        const regulation = new RegulationClass();
        return regulation.assetRegulationCounts(condition);
      },
      cci: function (condition, selector, date) {
        return `select asset_name, '${selector}' as regulation, every(result = 'pass') as passed from ${where.compliance.viewWithNist} dc ${whereCondition(...conditionFilter(condition))} group by asset_name`;
      }
    }
  },
  {
    name: 'applicationPassFailCount',
    route: '/application/counts',
    sql: {
      default: function (condition, selector, date) {
        const RegulationClass = ComplianceFactory.getRegulationByName(selector);
        const regulation = new RegulationClass();
        return regulation.applicationRegulationCounts(condition);
      },
      cci: function (condition, selector, date) {
        return `select ac.name,'${selector}' as regulation, every(result = 'pass') as passed from application_certifications ac left join ${where.compliance.viewWithNist} dc on ac.application_id = dc.application_grp_id ${whereCondition(...conditionFilter(condition))} group by ac.name`;
      }
    },
    postStages: [
      { type: 'lodash', transformationType: 'flattenDeep' },
      { type: 'lodash', transformationType: 'groupBy', transformer: 'regulation' },
    ]
  },
  {
    name: 'systemCountWidgets',
    route: '/system/counts',
    sql: {
      default: function (condition, selector, date) {
        return `select  quarter, status, count(distinct application_certification_id) from 
        (select application_certification_id, aa.status, CASE WHEN (aa.status = 'approved') THEN EXTRACT(QUARTER FROM ato_date) 
        WHEN (aa.status = 'in progress') THEN EXTRACT(QUARTER FROM aa.created_at)
        WHEN (aa.status = 'expired') THEN EXTRACT(QUARTER FROM aa.expiration_date)
        END as quarter 
        from application_authorize aa join application_certifications ac on ac.id = aa.application_certification_id
          ${whereCondition(`ac.organization_id = :orgId`)}
         
        ) as t group by quarter, status`;
      }
    }
  },
  {
    name: 'controlsPassFailCount',
    route: '/controls/counts',
    sql: {
      cci: function (condition, selector, date) {
        return `select * from (select case when passed = true then 'pass' else 'fail' end as result,organization_name, organization_id, count(distinct cci_id) from  
        (select cci_id, every(result = 'pass') as passed,organization_name,organization_id 
        from ${where.compliance.viewWithNist} dc ${whereCondition(...conditionFilter(condition))} group by cci_id,organization_name, organization_id) x
           group by passed,organization_name, organization_id) j join (select organization_id,count(distinct id) as total_count from ${where.compliance.viewWithNist} dc ${whereCondition(...conditionFilter(condition))} group by organization_id) counts on counts.organization_id::int = j.organization_id::int`;
      }
    }
  },
  {
    name: 'dashboardSummary',
    route: '/dashboard/summary',
    sql: {
      default: function (condition, selector, date) {
        return `select path,drd.organization_id, drd.name,org_type, drd.type, application, cloud_type, split_part(application, '-', 1) as display_app_name, sub_application, concat(split_part(sub_application, '-', 1),'-',split_part(sub_application, '-', 2)) as display_sub_app_name, location_name,
        inventory_result.severity as severity,
        coalesce((select (min_value+max_value)/2 from priorities where lower(name) = lower(inventory_result.severity)),0) as severity_number, 
        count(distinct drd.entity_arn) as total_count,
        count(distinct inventory_result.entity_arn) as severity_assets,
        sum(count_severity) as total_severity_count,
        alias_name
        from (
        select organization_id,cis.severity, isc.entity_arn, isc.product, count(*) as count_severity
        from infrastructure_services_compliance isc
        join (select batch_id, entity_arn, cloud_type from (select batch_id, entity_arn,cloud_type, row_number() OVER (PARTITION BY cloud_type,entity_arn ORDER BY batch_id DESC) as rank from infrastructure_services_compliance where organization_id in (select org_chain_list(:orgId) ) group by batch_id,cloud_type,entity_arn) isc where rank <= 1 ) as max_batch_infra on max_batch_infra.batch_id = isc.batch_id and max_batch_infra.entity_arn = isc.entity_arn and max_batch_infra.cloud_type = isc.cloud_type
        and (isc.entity_arn, isc.cis_control_id) not in (select entity_arn,control_id from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) ) and isc.result = 'FAIL'
        join cis_webservices_controls cis on cis.control_id = isc.cis_control_id
        join nist_cis_mappings ncm on ncm.mapping_id = cis.control_id and cis.cloud_type = ncm.cloud_type and
        ${condition.cloud_type ? `ncm.cloud_type = '${condition.cloud_type}'` : '1=1'}
        where organization_id in (select org_chain_list(:orgId)) and
        ${condition.cloud_type ? `isc.cloud_type = '${condition.cloud_type}'` : '1=1'} and
        (isc.entity_arn, cis_control_id) NOT IN (select entity_arn,control_id from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) )
        group by organization_id,isc.entity_arn, cis.severity, product
        union all
        select organization_id,severity as vm_severity, scan.asset_id::varchar as entity_arn, 'compute node' as product, count(*) as count_severity
        from daily_scan_xccdf_results scan
        join  xccdf_rules xr ON scan.rule_id = xr.rule_id and scan_result = 'FAIL' and scan.reference = xr.rule_identifiers
        join (select asset_id, max(batch_id) as max_batch_id from daily_scan_xccdf_results where asset_id in (select id from assets
        where (is_active='enabled' or is_active='true' or is_active='disabled') and 
        ${condition.cloud_type ? `source = '${condition.cloud_type}'` : '1=1'} and
        organization_id in (select org_chain_list(:orgId)) ) group by asset_id) as max_scanresult on scan.asset_id = max_scanresult.asset_id and scan.batch_id = max_scanresult.max_batch_id
        where organization_id in (select org_chain_list(:orgId)) and
        (scan.asset_id::varchar, scan.rule_id) NOT IN (select entity_arn,control_id from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) )
        group by organization_id,entity_arn, severity, product
        union all
        select organization_id,UPPER(pri.name) as vm_severity, scan.asset_id::varchar as entity_arn, 'compute node' as product, count(*) as count_severity
        from daily_scan_results scan
        join  common_vulnerabilities_exposures_base cveb ON scan_result = 'true' and trim(scan.reference) = trim(cveb.cve_id)
        join (select asset_id, max(batch_id) as max_batch_id from daily_scan_results where asset_id in (select id from assets
        where (is_active='enabled' or is_active='true' or is_active='disabled') and
        ${condition.cloud_type ? `source = '${condition.cloud_type}'` : '1=1'} and
        organization_id in (select org_chain_list(:orgId)) ) group by asset_id) as max_scanresult on scan.asset_id = max_scanresult.asset_id and scan.batch_id = max_scanresult.max_batch_id
        join priorities pri on cveb.score::FLOAT >= pri.min_value and cveb.score::FLOAT <= pri.max_value
        where organization_id in (select org_chain_list(:orgId)) and 
        (scan.asset_id::varchar, scan.rule_id) NOT IN (select entity_arn,control_id from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) )
        group by organization_id,pri.name, entity_arn, product, score
        ) as inventory_result
        right outer join saas_dashboard_reporting_details drd on drd.entity_arn = inventory_result.entity_arn and drd.organization_id = inventory_result.organization_id
        join  (select organization_id, path, alias_name from org_chain_view where organization_id || '-' || depth in (select concat(organization_id, '-' , max(depth))
        from org_chain_view group by organization_id )) as ocv on drd.organization_id = ocv.organization_id
        group by path,drd.organization_id,drd.name, drd.type, cloud_type, application, sub_application, location_name, org_type, alias_name, severity`;
      }
    },
    expected_params: ['orgId']
  }
];
