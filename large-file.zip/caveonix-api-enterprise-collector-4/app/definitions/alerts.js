const where = require('./common');
const whereCondition = require('../../utils/whereParser.js');
const conditionFilter = require('../../utils/conditionFilter');
module.exports = [
  {
    name: 'alertsTrendWidget',
    route: '/:orgId/alerts/trend',
    sql: {

      default(condition = []) {
        return `select lower(priority) as priority, created_at::DATE, count(id)::integer from alert_view 
        where organization_id  in (select org_chain_list(:orgId)) 
        group by priority, created_at::DATE order by created_at::DATE`;
      },
      cyber: function (condition = []) {
        return `select priority, created_at::DATE, count(id) from alert_view where (lower(priority) = 'critical' or lower(priority) = 'high') and type ='Cyber Risk' and organization_id  in  (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id  FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId  UNION ALL  SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id  WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL select :orgId as organization_id) group by priority, created_at::DATE order by created_at::DATE`;
      },
      compliance: function (condition = []) {
        return `select priority, created_at::DATE, count(id) from alert_view where (lower(priority) = 'critical' or lower(priority) = 'high') and type ='Compliance Risk' and organization_id  in  (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id  FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId  UNION ALL  SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id  WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL select :orgId as organization_id) group by priority, created_at::DATE order by created_at::DATE`;
      },
      tabular: function (condition = []) {
        return 'select name as "Entity Name" ,alert_name as "Type", created_at::DATE as date, type as "Risk Type",id,priority as "Priority"from alert_view where organization_id  in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId  UNION ALL  SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL select :orgId as organization_id) group by alert_name, type, id ,name, sub_name, priority, score, created_at::DATE order by created_at::DATE';
      }
    },
    postStages: [
      { type: 'setData' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Entity Name', path: 'Entity Name' },
          { label: 'Type', path: 'Type' },
          { label: 'Priority', path: 'Priority' },
          { label: 'Risk Type', path: 'Risk Type' }
        ]
      }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'alertsDistributionWidget',
    route: '/:orgId/alerts/distribution',
    sql: {
      default: function (condition = []) {
        return `select lower(priority) as priority, count(id)::integer from alert_results where created_at::DATE > now() - interval '7 days' and organization_id in (select org_chain_list(:orgId)) and lower(priority) in ('critical','high') group by lower(priority)`;
      },
      tabular: function (condition = []) {
        return `select name as "Entity Name" ,alert_name as "Type",type as "Risk Type", id, created_at::DATE as date, priority as "Priority",name as "Organization", score from alert_view 
        ${whereCondition(...conditionFilter(condition), where.common.orgChainFilter)}`;
      }
    },
    postStages: [
      { type: 'setData' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Entity Name', path: 'Entity Name' },
          { label: 'Type', path: 'Type' },
          { label: 'Priority', path: 'Priority' },
          { label: 'Risk Type', path: 'Risk Type' },
          { label: 'Organization', path: 'Organization' }
        ]
      }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'openAlertsByAgeWidget',
    route: '/:orgId/alerts/openAlertsByAge',
    sql: {
      default: function (condition = []) {
        return 'select priority,case when date_trunc(\'day\', created_at::date) > NOW() - interval \'30 days\' then \'0-30\' when date_trunc(\'day\', created_at::date) < NOW() - interval \'30 days\' and date_trunc(\'day\', created_at::date) > NOW() - interval \'60 days\' then \'30-60\' when date_trunc(\'day\', created_at::date) < NOW() - interval \'60 days\' then \'>60\' end bucket,count(*) as total from alert_view  where organization_id  in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId UNION ALL  SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id  WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL select :orgId  as organization_id) group by bucket, priority;';
      },
      cyber: function (condition = []) {
        return 'select priority,case when date_trunc(\'day\', created_at::date) > NOW() - interval \'30 days\' then \'0-30\' when date_trunc(\'day\', created_at::date) < NOW() - interval \'30 days\' and date_trunc(\'day\', created_at::date) > NOW() - interval \'60 days\' then \'30-60\' when date_trunc(\'day\', created_at::date) < NOW() - interval \'60 days\' then \'>60\' end bucket, count(*) as total from alert_view  where (lower(priority) = \'critical\' or lower(priority) = \'high\') and type = \'Cyber Risk\' and organization_id  in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId  UNION ALL  SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id  WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL select :orgId as organization_id)  group by bucket, priority';
      },
      compliance: function (condition = []) {
        return 'select priority, case when date_trunc(\'day\', created_at::date) > NOW() - interval \'30 days\' then \'0-30\' when date_trunc(\'day\', created_at::date) < NOW() - interval \'30 days\' and date_trunc(\'day\', created_at::date) > NOW() - interval \'60 days\' then \'30-60\' when date_trunc(\'day\', created_at::date) < NOW() - interval \'60 days\' then \'>60\' end bucket, count(*) as total from alert_view  where (lower(priority) = \'critical\' or lower(priority) = \'high\') and type = \'Compliance Risk\' and organization_id  in  (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id  FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId  UNION ALL  SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id  WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL select :orgId as organization_id) group by bucket, priority';
      },
      tabular: function (condition = []) {
        return 'select name as "Entity Name" ,alert_name as "Type", created_at::DATE as date, type as "Risk Type",id,priority as "Priority",case when date_trunc(\'day\', created_at::date) > NOW() - interval \'30 days\' then \'0-30\' when date_trunc(\'day\', created_at::date) < NOW() - interval \'30 days\' and date_trunc(\'day\', created_at::date) > NOW() - interval \'60 days\' then \'30-60\' when date_trunc(\'day\', created_at::date) < NOW() - interval \'60 days\' then \'>60\' end Age, count(*) as total from alert_view  where organization_id  in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId UNION ALL  SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id  WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL select :orgId as organization_id)  group by Age, name, alert_name,created_at::DATE,type, id, priority ;';
      }
    },
    postStages: [
      { type: 'setData' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Entity Name', path: 'Entity Name' },
          { label: 'Type', path: 'Type' },
          { label: 'Priority', path: 'Priority' },
          { label: 'Risk Type', path: 'Risk Type' },
          { label: 'Age', path: 'age' }
        ]
      }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'appGroupSeverityFrequencyWidget',
    route: '/:orgId/alerts/appGroupSeverityFrequency',
    sql: {

      cyber: function (condition = []) {
        return 'select priority, count(id) from alert_view where created_at::DATE > now() - interval \'30 days\' and alert_name = \'Organization\' and type = \'Cyber Risk\' and organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id  FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId  UNION ALL  SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id  WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL select :orgId as organization_id) group by priority';
      },
      compliance: function (condition = []) {
        return 'select priority, count(id) from alert_view where created_at::DATE > now() - interval \'30 days\' and alert_name = \'Organization\' and type = \'Compliance Risk\' and organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id  FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId  UNION ALL  SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id  WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL select :orgId as organization_id) group by priority';
      },
      tabular: function (condition = []) {
        return `select name as \"Entity Name\" , alert_name as \"Type\", created_at::DATE as date, type as \"Risk Type\", id, priority as \"Priority\", score from alert_view
         where created_at::DATE > now() - interval '30 days' and alert_name = 'Organization' and ${
          where.common.orgChainFilter
        } group by alert_name, type, id ,name, sub_name, priority, score, created_at::DATE`;
      }
    },
    postStages: [
      { type: 'setData' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Entity Name', path: 'Entity Name' },
          { label: 'Type', path: 'Type' },
          { label: 'Priority', path: 'Priority' },
          { label: 'Risk Type', path: 'Risk Type' }
        ]
      }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'AlertDetailWidget',
    route: '/:orgId/alerts/alertDetails',
    sql: {
      default: function (condition = []) {
        return `select id,organization_id,name,sub_name,lower(priority) as priority,subject,body,created_at,user_id 
        from alert_results where  organization_id in (select org_chain_list(:orgId))
        and created_at::DATE > now() - interval '7 days'
        and lower(priority) in ('critical','high')
        order by created_at DESC`;
      }
    },
    postStages: [
      {
        type: 'setData'

      },

      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Entity Name', path: 'Entity Name' },
          { label: 'Type', path: 'Type' },
          { label: 'Priority', path: 'Priority' },
          { label: 'Risk Type', path: 'Risk Type' }
        ]
      }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'AlertDetailCountsWidget',
    route: '/:orgId/alerts/alertDetailCounts',
    sql: {
      default: function (condition = []) {
        return 'select count(priority), priority, name as alert_name, alert_name as type, type as risk_type from alert_view where created_at::DATE > now()-interval \'30 days\' and organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id  FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId  UNION ALL  SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL select :orgId as organization_id) group by name, alert_name,priority,type order by type, alert_name, priority';
      },
      cyber: function (condition = []) {
        return 'select count(priority), priority, name as alert_name from alert_view where created_at::DATE > now()-interval \'30 days\' and organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id  FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId  UNION ALL  SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id  WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL select :orgId as organization_id) and type = \'Cyber Risk\' group by name, alert_name,priority order by  alert_name, priority';
      },
      compliance: function (condition = []) {
        return 'select count(priority), priority, name as alert_name from alert_view where created_at::DATE > now()-interval \'30 days\' and organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id  FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId  UNION ALL  SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id  WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL select :orgId as organization_id) and type = \'Compliance Risk\' group by name, alert_name,priority order by  alert_name, priority';
      }
    },
    expected_params: ['orgId']

  },
  {
    name: 'alertPriorityCounts',
    route: '/:orgId/alerts/alertPriorityCounts',
    sql: {
      default: function (condition = []) {
        return 'select count(*), priority from alert_view where created_at::DATE > now()-interval \'7 days\' and organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id  FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId  UNION ALL  SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL select :orgId as organization_id) group by priority';
      }
    },
    expected_params: ['orgId']
  },
  {
    name: 'NotificationsWidget',
    route: '/:orgId/alerts/notifications',
    sql: {
      default: function (condition = []) {
        return `select id,notification_action,notification_detail,is_active from caveo_notifications ${whereCondition(...conditionFilter(condition), where.common.orgChainFilter)}
        order by created_at desc`;
      }

    },
    postStages: [
      {
        type: 'lodash',
        transformationType: 'map',
        transformer: (elem, key, collection) => {
          const o = JSON.parse(elem.notification_detail);
          return { assetName: o['MachineName.keyword'], probability: o.probability, type: elem.notification_action };
        }
      }
    ],
    expected_params: ['orgId']
  }
];
