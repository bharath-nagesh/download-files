const _ = require('lodash');
const where = require('./common');
const whereCondition = require('../../utils/whereParser.js');
const conditionFilter = require('../../utils/conditionFilter');

module.exports = [
  {
    route: '/cloud/inventory',
    name: 'cloudServices',
    whereTransform: {
      tabular: {
        mapping: {
          source: 'cloud_type',
          product: 'product',
          org_name: 'o.name'
        }
      },
      historical: {
        mapping: {
          source: 'cloud_type',
          product: 'product',
          org_name: 'o.name'
        }
      },
      counts: {
        mapping: {
          source: 'cloud_type',
          org_name: 'o.name'
        }
      },
      accountPosture: {
        mapping: {
          source: 'cloud_type',
          org_name: 'o.name'
        }
      }
    },

    sql: {
      counts(condition, selector, date) {
        //TODO support one to many transformation step
        const source = condition.cloud_type ? `source in ('${condition.cloud_type}')` : '';
        return `select concat(o.alias_name,' (',o.name,')') as full_name, o.alias_name,o.name as org_name,o.id = :orgId as top_org,total_count::int,service,product,
        CASE WHEN x.organization_id is not null THEN x.organization_id::int ELSE x.organization_id::int END as organization_id from 
        (select product,product as service, organization_id, count(services.id) as total_count from services
        ${whereCondition(...conditionFilter(['product', 'cloud_type', 'organization_id'], condition), `organization_id in (select org_chain_list(:orgId))`)}
        group by product, organization_id) x inner join organizations o on x.organization_id = o.id 
        ${whereCondition(...conditionFilter(['o.name'], condition))}
        union all
        select concat(org_alias_name,' (',organization_name,')') as full_name, org_alias_name as alias_name,organization_name as org_name,organization_id = :orgId as top_org,count(*) as total_count, 'Compute Node' as service,'Compute Node' as  product,organization_id from application_group_asset_view 
        ${whereCondition(...conditionFilter(['organization_id', 'organization_name', 'source'], condition), `organization_id in (select org_chain_list(:orgId))`, source)} group by org_alias_name, organization_id, organization_name;`;
      },
      tabular(condition, selector, date) {
        const cloud_type = condition.cloud_type;
        return `select distinct x.* from 
        (select isc.cis_control_id,entity_name, isc.organization_id,o.name as organization_name,isc.product,case when e.type is not null then e.type else isc.result end as result, e.id as exemption_id,title,description,region, isc.entity_arn,aou.aws_user_name, isc.remediation, isc.cloud_type,isc.source, isc.severity, isc.created_at, isc.rational_statement, isc.remediation_procedure, isc.audit_procedure, string_agg(isc.nist_id , ',') as nist_id
        from (select ncm.nist_id, infra.id ,infra.entity_arn ,infra.organization_id ,infra.cis_control_id ,infra.asset_repo_id ,infra.region ,cis.title ,cis.description ,infra.result ,infra.remediation ,infra.product
        ,infra.cloud_type ,infra.source ,infra.organization_account_id ,infra.entity_name ,infra.batch_id, infra.created_at, cis.severity,
        cis.rational_statement, cis.remediation_procedure, cis.audit_procedure
        from infrastructure_services_compliance infra, cis_webservices_controls cis, nist_cis_mappings ncm
        where ncm.mapping_id = cis.control_id and cis.control_id = infra.cis_control_id and cis.cloud_type = infra.cloud_type and infra.organization_id in (select org_chain_list(:orgId))
        and ncm.cloud_type = cis.cloud_type and cis.cloud_type = '${cloud_type}'
        and (batch_id, infra.entity_arn)  in (select max(batch_id),entity_arn 
        from infrastructure_services_compliance  
        where organization_id in (select org_chain_list(:orgId)) group by entity_arn)) isc 
        left join exemptions e on e.entity_arn = isc.entity_arn and e.control_id = isc.cis_control_id and e.is_active != 'false' and e.organization_id = isc.organization_id
        and (exemption_valid_till >= NOW() or exemption_valid_till is null)  
        join aws_organization_users aou on aou.organization_id = isc.organization_id and aou.is_active ='enabled' join organizations o on o.id  = isc.organization_id  
        group by  cis_control_id,entity_name, isc.organization_id,o.name ,isc.product,result, e.id ,title,description,region, isc.entity_arn,aou.aws_user_name, isc.remediation,
        isc.cloud_type,isc.source, isc.severity, isc.created_at,isc.rational_statement, isc.remediation_procedure, isc.audit_procedure) x 
        ${whereCondition(...conditionFilter(['product', 'organization_id', 'cloud_type'], condition), `organization_id in (select org_chain_list(:orgId))`)}  order by product`;
      },
      historical(condition, selector, date) {
        // TODO: test distinct in the inner query to make sure we need this
        return `select distinct x.* from 
        (select cis_control_id,entity_name, isc.organization_id,product,result,title,description,region, entity_arn,date_trunc('hour',isc.created_at) as created_at, isc.remediation,isc.batch_id,cloud_type
         from infrastructure_services_compliance isc  ${whereCondition(...conditionFilter(condition), where.common.orgChainFilter, where.common.serviceExemptionFilter)}  order by batch_id desc limit 10) x 
        join cis_webservices_controls cac on x.cloud_type = cac.cloud_type and x.cis_control_id = cac.control_id join (select organization_id as org_id, aws_user_name from aws_organization_users where is_active = 'enabled') aou on aou.org_id = x.organization_id order by product`;
      }

    },
    expected_params: ['orgId'],
    postStages: [
      {
        type: 'lodash',
        transformationType: 'sortBy',
        contextCheck: 'selector',
        contextCheckValue: 'tabular',
        transformer: (data) => {
          const severityLookup = {
            critical: 0,
            high: 1,
            medium: 2,
            Low: 3,
            unknown: 4
          };

          return severityLookup[data.severity.toLowerCase()] || severityLookup.unknown;
        }
      },

      { type: 'setData', contextCheck: 'selector', contextCheckValue: 'tabular' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        contextCheck: 'selector',
        contextCheckValue: 'tabular',
        labels: [
          { label: 'Control Id', path: 'cis_control_id' },
          { label: 'Sub-Application', path: 'aws_user_name' },
          { label: 'Product', path: 'product' },
          { label: 'Region', path: 'region' },
          { label: 'Severity', path: 'severity' },
          { label: 'Nist ID', path: 'nist_id' },
          { label: 'Entity ARN', path: 'entity_arn' },
          { label: 'result', path: 'result' }
        ]
      },
      {
        type: 'lodash',
        contextCheck: 'selector',
        contextCheckValue: 'counts',
        transformationType: 'reduce',
        transformer: (result, v, index) => {
          result[`${v.product || v.service}__${v.organization_id}`] = result[`${v.product || v.service}__${v.organization_id}`] || v;
          if (v.result && v.result.toLowerCase() == 'fail') result[`${v.product || v.service}__${v.organization_id}`].fail_count = v.count;
          if (v.result && v.result.toLowerCase() == 'pass') result[`${v.product || v.service}__${v.organization_id}`].pass_count = v.count;
          delete result[`${v.product || v.service}__${v.organization_id}`].count;
          delete result[`${v.product || v.service}__${v.organization_id}`].result;

          return result;
        }
      },
      {
        type: 'lodash',
        transformationType: 'values',
        contextCheck: 'selector',
        contextCheckValue: 'counts'

      }
    ]
  },
  {
    route: '/cloud/account-posture',
    name: 'accountPosture',
    sql: {
      default(condition, selector, date) {
        return `select o.name as org_name,o.id = :orgId as top_org, count::int,total_count::int,service,result,product,o.alias_name, concat(o.alias_name,' (',o.name,')') as full_name,
             CASE WHEN x.organization_id is not null THEN x.organization_id::int ELSE service_count.organization_id::int END as organization_id from
        (select product as service, organization_id, count(id) as total_count from services
                            where  product='IAM' and organization_id in (select org_chain_list(:orgId))
                            group by product, organization_id) service_count
                            join 
        (select count(cis_control_id),organization_id,product,result,cloud_type from (select isc.cis_control_id,entity_name, isc.organization_id,o.name as organization_name,isc.product,case when e.type is not null then e.type else isc.result end as result, e.id as exemption_id,title,description,region, isc.entity_arn,aou.aws_user_name, isc.remediation,
          isc.cloud_type,isc.source, isc.severity, isc.created_at,
        string_agg(isc.nist_id , ',') as nist_id
           from (select ncm.nist_id, infra.id ,infra.entity_arn ,infra.organization_id ,infra.cis_control_id ,infra.asset_repo_id ,infra.region ,cis.title ,cis.description ,infra.result ,infra.remediation ,infra.product
      ,infra.cloud_type ,infra.source ,infra.organization_account_id ,infra.entity_name ,infra.batch_id, infra.created_at, cis.severity
     from infrastructure_services_compliance infra, cis_webservices_controls cis, nist_cis_mappings ncm
      where ncm.mapping_id = cis.control_id and cis.control_id = infra.cis_control_id and cis.cloud_type = infra.cloud_type and infra.organization_id in (select org_chain_list(:orgId))
      and (batch_id, infra.entity_arn)  in (select max(batch_id) ,entity_arn from infrastructure_services_compliance
      where organization_id in (select org_chain_list(:orgId)) group by entity_arn) ) isc
      left join exemptions e on e.entity_arn = isc.entity_arn and e.control_id = isc.cis_control_id and e.is_active != 'false' and e.organization_id = isc.organization_id
      and (exemption_valid_till >= NOW() or exemption_valid_till is null )
      join aws_organization_users aou on aou.organization_id = isc.organization_id and aou.is_active ='enabled' join organizations o on o.id  = isc.organization_id
          group by  cis_control_id,entity_name, isc.organization_id,o.name ,isc.product,result, e.id ,title,description,region, isc.entity_arn,aou.aws_user_name, isc.remediation,
          isc.cloud_type,isc.source, isc.severity, isc.created_at) inside ${whereCondition(...conditionFilter(condition), `product = 'IAM'`, `entity_name = 'ALL'`, `organization_id in (select org_chain_list(:orgId))`)} group by product,result,organization_id,cloud_type ) x on x.organization_id = service_count.organization_id
          join organizations o on x.organization_id = o.id or service_count.organization_id = o.id  order by product`;

      },
      tabular(condition, selector, date) {
        return `select distinct x.* from
        (select isc.cis_control_id,entity_name, isc.organization_id,o.name as organization_name,isc.product,case when e.type is not null then e.type else isc.result end as result, e.id as exemption_id,title,description,region, isc.entity_arn,aou.aws_user_name, isc.remediation,
          isc.cloud_type,isc.source, isc.severity, isc.created_at,
        string_agg(isc.nist_id , ',') as nist_id
           from (select ncm.nist_id, infra.id ,infra.entity_arn ,infra.organization_id ,infra.cis_control_id ,infra.asset_repo_id ,infra.region ,cis.title ,cis.description ,infra.result ,infra.remediation ,infra.product
      ,infra.cloud_type ,infra.source ,infra.organization_account_id ,infra.entity_name ,infra.batch_id, infra.created_at, cis.severity
     from infrastructure_services_compliance infra, cis_webservices_controls cis, nist_cis_mappings ncm
      where ncm.mapping_id = cis.control_id and cis.control_id = infra.cis_control_id and cis.cloud_type = infra.cloud_type and infra.organization_id in (select org_chain_list(:orgId))
      and (batch_id, infra.entity_arn)  in (select max(batch_id) ,entity_arn from infrastructure_services_compliance
      where organization_id in (select org_chain_list(:orgId)) group by entity_arn) ) isc
      left join exemptions e on e.entity_arn = isc.entity_arn and e.control_id = isc.cis_control_id and e.is_active != 'false' and e.organization_id = isc.organization_id
      and (exemption_valid_till >= NOW() or exemption_valid_till is null )
      join aws_organization_users aou on aou.organization_id = isc.organization_id and aou.is_active ='enabled' join organizations o on o.id  = isc.organization_id
          group by  cis_control_id,entity_name, isc.organization_id,o.name ,isc.product,result, e.id ,title,description,region, isc.entity_arn,aou.aws_user_name, isc.remediation,
          isc.cloud_type,isc.source, isc.severity, isc.created_at) x
    ${whereCondition(...conditionFilter(condition), `product = 'IAM'`, `entity_name = 'ALL'`, `organization_id in (select org_chain_list(:orgId))`)}  order by product`;
      }
    },
    postStages: [{
      type: 'lodash',
      transformationType: 'reduce',
      contextCheck: 'selector',
      contextCheckValue: 'default',
      transformer: (result, v, index) => {
        result[`${v.product || v.service}__${v.organization_id}`] = result[`${v.product || v.service}__${v.organization_id}`] || v;
        if (v.result && v.result.toLowerCase() == 'fail') result[`${v.product || v.service}__${v.organization_id}`].fail_count = v.count;
        if (v.result && v.result.toLowerCase() == 'pass') result[`${v.product || v.service}__${v.organization_id}`].pass_count = v.count;
        delete result[`${v.product || v.service}__${v.organization_id}`].count;
        delete result[`${v.product || v.service}__${v.organization_id}`].result;

        return result;
      }
    },
      { type: 'setData', contextCheck: 'selector', contextCheckValue: 'tabular' },

      {
        type: 'lodash',
        transformationType: 'values'

      }]
  },
  {
    route: '/cloud',
    name: 'cloudServices',
    whereTransform: {
      tabular: {
        mapping: {
          product: 's.product',
          organization_id: 's.organization_id',
          cloud_type: 's.cloud_type',
          org_name: 'o.name',
          source: 's.cloud_type'
        }
      }
    },
    sql: {
      counts(condition, selector, date) {
        return `select o.name as org_name, x.* from (select product,entity_name, organization_id, count(id) from services
         ${whereCondition(...conditionFilter(condition), where.common.orgChainFilter)}
         group by product, organization_id, entity_name) x join organizations o on x.organization_id = o.id`;
      },
      tabular(condition, selector, date) {
        return `select s.*, agsv.application_name, agsv.sub_app_name from services s join application_group_service_view agsv on agsv.entity_arn = s.entity_arn
         ${whereCondition(...conditionFilter(condition), `s.organization_id in (select org_chain_list(:orgId))`)}`;
      },
      score(condition, selector, date) {
        return `select organization_id,round(sum(case when lower(ds.severity)='low' then 3 when lower(ds.severity)='medium' then 5 when lower(ds.severity)='high' then 7 when lower(ds.severity)='critical' then 9  end)::numeric/count(ds.id),2) as score  
        from ${where.compliance.viewWithServices} ds
        ${whereCondition(...conditionFilter(condition), where.common.orgChainFilter)} group by organization_id
        `;
      }
    },
    expected_params: ['orgId']
  },
  {

    route: '/cloud/security-posture',
    sql: {
      default(condition, selector, date) {
        const cloudType = condition.cloud_type ? `upper(infra.cloud_type) = '${condition.cloud_type.toUpperCase()}'` : 'infra.cloud_type is not null';
        const cloudToSourceType = condition.cloud_type ? ` upper(source) = '${condition.cloud_type.toUpperCase()}' ` : '1=1';
        const infraOrganizationIdType = condition.organization_id ? `infra.organization_id = ${condition.organization_id}` : '1=1';
        const infraProductFilter = condition.product ? `infra.product = '${condition.product}'` : '1=1';
        const assetProductFilter = condition.product ? condition.product == 'Compute Node' : '1=1';
        return `select organization_id, organization_name as org_name, alias_name, concat(alias_name,' (',organization_name,')') as full_name, top_org,
        CASE WHEN product is null then organization_name else product END,
        sum(failed_controls) fail_count, sum(passed_controls) pass_count,
        round(sum(case when lower(name)='low' then (3*failed_controls*1.1) when lower(name)='medium' then (5*failed_controls*1.2)
        when lower(name)='high' then (7*failed_controls*1.3)
        when lower(name)='critical' then (9*failed_controls*1.5)  end)::numeric/sum(CASE WHEN failed_controls = 0 THEN 1 ELSE failed_controls END),2) as score, scan_date::varchar, cloud_type
        from (
        select infra.organization_id, o.alias_name, o.name as organization_name, o.id = :orgId as top_org,infra.product,
        sum(case when result = 'FAIL' then 1 else 0 end) as failed_controls,
        sum(case when result = 'PASS' then 1 else 0 end) as passed_controls,
        count(infra.cis_control_id) as total_controls,
        cis.severity as name,
        count(cis.severity) as severity_count, infra.created_at::DATE as scan_date, infra.cloud_type
        from infrastructure_services_compliance infra
        join (select batch_id, entity_arn, cloud_type from (select batch_id, entity_arn,cloud_type, row_number() OVER (PARTITION BY cloud_type,entity_arn ORDER BY batch_id DESC) as rank from infrastructure_services_compliance where organization_id in (select org_chain_list(:orgId) ) group by batch_id,cloud_type,entity_arn) isc where rank <= 1 ) as max_batch_infra on max_batch_infra.batch_id = infra.batch_id and max_batch_infra.entity_arn = infra.entity_arn and max_batch_infra.cloud_type = infra.cloud_type
        join cis_webservices_controls cis on cis.control_id = infra.cis_control_id and cis.cloud_type = infra.cloud_type
        join application_group_service_view ags on infra.entity_arn = ags.entity_arn and ags.organization_id in (select org_chain_list(:orgId))
        join organizations o on o.id = infra.organization_id
        where infra.organization_id in (select org_chain_list(:orgId)) and
        (infra.entity_arn, cis_control_id) NOT IN (select entity_arn,control_id from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) ) and
        ${infraProductFilter} and
        ${infraOrganizationIdType} and
        ${cloudType}
        group by infra.organization_id, o.alias_name, o.name, top_org, infra.product, cis.severity, infra.created_at, infra.cloud_type
        ) outer_sql
        group by
        grouping sets(
        (organization_id, organization_name, alias_name, product, top_org, scan_date, cloud_type),
        (organization_id, organization_name, alias_name, top_org, scan_date, cloud_type) )
        union all
        select organization_id, organization_name, alias_name, concat(alias_name,' (',organization_name,')') as full_name, top_org, product, sum(failed_controls),sum(passed_controls), round(avg(score),2)  as risk_score, null as scan_date, cloud_type
        from (
        select organization_id, organization_name, alias_name, top_org, product, sum(failed_controls) failed_controls, sum(passed_controls) passed_controls,
        round(sum(case when lower(name)='low' then (3*failed_controls*1.1) when lower(name)='medium' then (5*failed_controls*1.2)
        when lower(name)='high' then (7*failed_controls*1.3)
        when lower(name)='critical' then (9*failed_controls*1.5)  end)::numeric/sum(failed_controls),2) as score, cloud_type
        from (
        select scan.organization_id, o.alias_name, o.name as organization_name, o.id = :orgId as top_org, 'Compute Node' as product,
        sum(case when UPPER(scan_result) = 'FAIL' then 1 else 0 end) as failed_controls,
        sum(case when UPPER(scan_result) = 'PASS' then 1 else 0 end) as passed_controls,
        count(scan.rule_id) as total_count,
        severity as name, a.source as cloud_type
        from daily_scan_xccdf_results scan
        join assets a on scan.asset_id = a.id and (is_active='enabled' or is_active='true' or is_active='disabled')
        join xccdf_rules xr ON scan.rule_id = xr.rule_id and scan.reference = xr.rule_identifiers
        join organizations o on o.id = a.organization_id
        join (select asset_id, max(batch_id) as max_batch_id from daily_scan_xccdf_results where asset_id in (select id from assets
        where (is_active='enabled' or is_active='true' or is_active='disabled') and 
        ${cloudToSourceType} and
        ${infraOrganizationIdType} and
        organization_id in (select org_chain_list(:orgId))
        ) group by asset_id) as max_scanresult on scan.asset_id = max_scanresult.asset_id and scan.batch_id = max_scanresult.max_batch_id
        where scan.organization_id in (select org_chain_list(:orgId)) and
        (scan.asset_id::varchar, scan.rule_id) NOT IN (select entity_arn,control_id from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) )
        group by scan.organization_id, o.alias_name, o.name, top_org, severity, a.source
        ) outer_sql
        group by organization_id, organization_name, alias_name, top_org, product, cloud_type
        union all
        select organization_id, organization_name, alias_name, top_org, product,  sum(failed_controls) as failed_controls, sum(passed_controls) as passed_controls,
        round(sum(case when lower(name)='low' then (3*failed_controls*1.1) when lower(name)='medium' then (5*failed_controls*1.2)
        when lower(name)='high' then (7*failed_controls*1.3)
        when lower(name)='critical' then (9*failed_controls*1.5)  end)::numeric/sum(failed_controls),2) as score, cloud_type
        from (
        select scan.organization_id, o.alias_name, o.name organization_name, o.id = :orgId as top_org, 'Compute Node' as product,
        count(scan.rule_id) as failed_controls,
        0 as passed_controls,
        count(scan.rule_id) as total_count,
        pri.name, a.source as cloud_type
        from daily_scan_results scan
        join assets a on scan.asset_id = a.id and (is_active='enabled' or is_active='true' or is_active='disabled')
        join common_vulnerabilities_exposures_base cveb ON scan_result = 'true' and trim(scan.reference) = trim(cveb.cve_id)
        join (select asset_id, max(batch_id) as max_batch_id from daily_scan_results where asset_id in (select id from assets
        where (is_active='enabled' or is_active='true' or is_active='disabled') and 
        ${cloudToSourceType} and 
        ${infraOrganizationIdType} and
        organization_id in (select org_chain_list(:orgId))
        ) group by asset_id) as max_scanresult on scan.asset_id = max_scanresult.asset_id and scan.batch_id = max_scanresult.max_batch_id
        join organizations o on o.id = a.organization_id
        join priorities pri on cveb.score::FLOAT >= pri.min_value and cveb.score::FLOAT <= pri.max_value
        where scan.organization_id in (select org_chain_list(:orgId)) and
        (scan.asset_id::varchar, scan.rule_id) NOT IN (select entity_arn,control_id from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) )
        group by scan.organization_id, o.alias_name, o.name, top_org, pri.name, a.source
        ) outer_sql
        group by organization_id, organization_name, alias_name, top_org, product, cloud_type
        ) compute_score
        group by organization_id, organization_name, alias_name, top_org, product, scan_date, cloud_type`;
      }
    },
    postStages: [{
      type: 'lodash',
      transformationType: 'reduce',
      transformer: (result, v, index) => {
        result[`${v.product || v.service}__${v.organization_id}`] = result[`${v.product || v.service}__${v.organization_id}`] || v;
        if (v.result && v.result.toLowerCase() == 'fail') result[`${v.product || v.service}__${v.organization_id}`].fail_count = v.count;
        if (v.result && v.result.toLowerCase() == 'pass') result[`${v.product || v.service}__${v.organization_id}`].pass_count = v.count;
        delete result[`${v.product || v.service}__${v.organization_id}`].count;
        delete result[`${v.product || v.service}__${v.organization_id}`].result;

        return result;
      }
    },
      {
        type: 'lodash',
        transformationType: 'values'
      }]
  },

  {
    route: '/cloud/compliance-posture',
    sql: {
      default(condition, selector, date) {
        const cloudType = condition.cloud_type ? `cloud_type = '${condition.cloud_type.toUpperCase()}'` : 'cloud_type is not null';
        const cloudToSourceType = condition.cloud_type ? ` source = '${condition.cloud_type.toUpperCase()}' ` : '1=1';
        const infraOrganizationIdType = condition.organization_id ? `infra.organization_id = ${condition.organization_id}` : '1=1';
        const infraProductFilter = condition.product ? `infra.product = '${condition.product}'` : '1=1';
        const assetProductFilter = condition.product ? condition.product == 'Compute Node' : '1=1';
        const applicationFilter = condition.application_name ? `application_name = '${condition.application_name}'` : '1=1';
        const applicationGrpFilter = condition.application_name ? `application_grp_name = '${condition.application_name}'` : '1=1';
        return `select organization_id, organization_name as org_name, alias_name, concat(alias_name,' (',organization_name,')') as full_name, top_org, application_name, display_app_name,
        sum(failed_controls) fail_count, sum(passed_controls) pass_count,
        round(sum(case when lower(name)='low' then (3*failed_controls*1.1) when lower(name)='medium' then (5*failed_controls*1.2)
        when lower(name)='high' then (7*failed_controls*1.3)
        when lower(name)='critical' then (9*failed_controls*1.5)  end)::numeric/sum(CASE WHEN failed_controls = 0 THEN 1 ELSE failed_controls END),2) as score
        from (
        select infra.organization_id, o.name as organization_name, o.alias_name, o.id = :orgId as top_org, ags.application_name,split_part(ags.application_name, '-', 1) as display_app_name,
        sum(case when result = 'FAIL' then 1 else 0 end) as failed_controls,
        sum(case when result = 'PASS' then 1 else 0 end) as passed_controls,
        count(infra.cis_control_id) as total_controls,
        cis.severity as name,
        count(cis.severity) as severity_count
        from infrastructure_services_compliance infra
        join (select batch_id, entity_arn, cloud_type from (select batch_id, entity_arn,cloud_type, row_number() OVER (PARTITION BY cloud_type,entity_arn ORDER BY batch_id DESC) as rank from infrastructure_services_compliance where organization_id in (select org_chain_list(:orgId) ) group by batch_id,cloud_type,entity_arn) isc where rank <= 1 ) as max_batch_infra on max_batch_infra.batch_id = infra.batch_id and max_batch_infra.entity_arn = infra.entity_arn and max_batch_infra.cloud_type = infra.cloud_type
        join cis_webservices_controls cis on cis.control_id = infra.cis_control_id and cis.cloud_type = infra.cloud_type
        join application_group_service_view ags on infra.entity_arn = ags.entity_arn and ags.organization_id in (select org_chain_list(:orgId)) and ${applicationFilter}
        join organizations o on o.id = infra.organization_id
        where infra.organization_id in (select org_chain_list(:orgId)) and
        ${condition.cloud_type ? `infra.cloud_type = '${condition.cloud_type.toUpperCase()}'` : '1=1'} and
        (infra.entity_arn, cis_control_id) NOT IN (select entity_arn,control_id from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) )
        group by infra.organization_id, o.name, o.alias_name, top_org, ags.application_name, cis.severity
        ) outer_sql
        group by
        (organization_id, organization_name, application_name, top_org, alias_name, display_app_name)
        union all
        select organization_id, organization_name, alias_name, concat(alias_name,' (',organization_name,')') as full_name, top_org, application_name, display_app_name, sum(failed_controls),sum(passed_controls), round(avg(score),2)  as risk_score
        from (
        select organization_id, organization_name, alias_name, top_org, application_name, display_app_name, sum(failed_controls) failed_controls, sum(passed_controls) passed_controls,
        round(sum(case when lower(name)='low' then (3*failed_controls*1.1) when lower(name)='medium' then (5*failed_controls*1.2)
        when lower(name)='high' then (7*failed_controls*1.3)
        when lower(name)='critical' then (9*failed_controls*1.5)  end)::numeric/sum(failed_controls),2) as score
        from (
        select scan.organization_id, o.name as organization_name, o.alias_name, o.id = :orgId as top_org, application_grp_name as application_name, split_part(application_grp_name, '-', 1) as display_app_name,
        sum(case when UPPER(scan_result) = 'FAIL' then 1 else 0 end) as failed_controls,
        sum(case when UPPER(scan_result) = 'PASS' then 1 else 0 end) as passed_controls,
        count(scan.rule_id) as total_count,
        severity as name
        from daily_scan_xccdf_results scan
        join assets a on scan.asset_id = a.id and (is_active='enabled' or is_active='true' or is_active='disabled') and ${condition.cloud_type ? `source = '${condition.cloud_type.toUpperCase()}'` : '1=1'}
        join xccdf_rules xr ON scan.rule_id = xr.rule_id and scan.reference = xr.rule_identifiers
        join application_group_asset_view agsv on agsv.id = scan.asset_id and agsv.organization_id = scan.organization_id and ${applicationGrpFilter}
        join organizations o on o.id = a.organization_id
        join (select asset_id, max(batch_id) as max_batch_id from daily_scan_xccdf_results scan where asset_id in (select id from assets
        where (is_active='enabled' or is_active='true' or is_active='disabled') and 
        ${condition.cloud_type ? `source = '${condition.cloud_type.toUpperCase()}'` : '1=1'} and
        organization_id in (select org_chain_list(:orgId)) and 
        (scan.asset_id::varchar, scan.rule_id) NOT IN (select entity_arn,control_id from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) )
        ) group by asset_id) as max_scanresult on scan.asset_id = max_scanresult.asset_id and scan.batch_id = max_scanresult.max_batch_id
        where scan.organization_id in (select org_chain_list(:orgId))
        group by scan.organization_id,o.name,o.alias_name,top_org, application_grp_name,severity
        ) outer_sql
        group by organization_id, organization_name, alias_name, top_org, application_name,display_app_name
        union all
        select organization_id, organization_name,alias_name, top_org, application_name, display_app_name, sum(failed_controls) as failed_controls, sum(passed_controls) as passed_controls,
        round(sum(case when lower(name)='low' then (3*failed_controls*1.1) when lower(name)='medium' then (5*failed_controls*1.2)
        when lower(name)='high' then (7*failed_controls*1.3)
        when lower(name)='critical' then (9*failed_controls*1.5)  end)::numeric/sum(failed_controls),2) as score
        from (
        select scan.organization_id, o.name organization_name, o.alias_name, o.id = :orgId as top_org, application_grp_name as application_name, split_part(application_grp_name, '-', 1) as display_app_name,
        count(scan.rule_id) as failed_controls,
        0 as passed_controls,
        count(scan.rule_id) as total_count,
        pri.name
        from daily_scan_results scan
        join assets a on scan.asset_id = a.id and (is_active='enabled' or is_active='true' or is_active='disabled') and ${condition.cloud_type ? `source = '${condition.cloud_type.toUpperCase()}'` : '1=1'}
        join application_group_asset_view agsv on agsv.id = scan.asset_id and agsv.organization_id = scan.organization_id and ${applicationGrpFilter}
        join common_vulnerabilities_exposures_base cveb ON scan_result = 'true' and trim(scan.reference) = trim(cveb.cve_id)
        join (select asset_id, max(batch_id) as max_batch_id from daily_scan_results where asset_id in (select id from assets
        where (is_active='enabled' or is_active='true' or is_active='disabled') and 
        ${condition.cloud_type ? `source = '${condition.cloud_type.toUpperCase()}'` : '1=1'} and
        organization_id in (select org_chain_list(:orgId))
        ) group by asset_id) as max_scanresult on scan.asset_id = max_scanresult.asset_id and scan.batch_id = max_scanresult.max_batch_id
        join organizations o on o.id = a.organization_id
        join priorities pri on cveb.score::FLOAT >= pri.min_value and cveb.score::FLOAT <= pri.max_value
        where scan.organization_id in (select org_chain_list(:orgId)) and 
        (scan.asset_id::varchar, scan.rule_id) NOT IN (select entity_arn,control_id from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) )
        group by scan.organization_id, o.name,o.alias_name, top_org, application_grp_name,pri.name,display_app_name
        ) outer_sql
        group by organization_id, organization_name, top_org, application_name,alias_name, display_app_name
        ) compute_score
        group by organization_id, organization_name, top_org, application_name,alias_name, display_app_name`;
      }
    }
  },
  {
    route: '/cloud/scores',
    name: 'cloudServicesScores',
    whereTransform: {
      orgServices: {
        mapping: {
          source: 'cloud_type'
        }
      },
      appServices: {
        mapping: {
          source: 'cloud_type'
        }
      }
    },
    sql: {
      default(condition, selector, date) {
        return `select ${selector},round(sum(case when lower(ds.severity)='low' then 3 when lower(ds.severity)='medium' then 5 when lower(ds.severity)='high' then 7 when lower(ds.severity)='critical' then 9  end)::numeric/count(ds.cis_control_id),2) as score
                from ${where.compliance.viewWithNistAndServices} ds
                ${whereCondition(...conditionFilter(condition), where.common.orgChainFilter, `result='FAIL'`)} group by ${selector}`;
      }
    }
  },
  {
    route: '/cloud/riskView',
    name: 'cloudServicesRiskView',
    whereTransform: {
      default: {
        mapping: {
          source: 'cloud_type'
        }
      }
    },
    sql: {
      default(condition, selector, date) {
        return `select nist_id,asset_type, cis_control_id, asset_id,entity_arn,location, o.organization_name,o.organization_id, cloud_type as source, application_name, application_grp_name, o.asset_name, round(o.final_count::numeric,2)::float as final_count, p.name as severity, entity_type,round((o.final_count + o.impact_level::float + cast((CASE WHEN bai_value = 'Critical' then 9 WHEN bai_value = 'High' then 7 WHEN bai_value = 'Medium' then 5 WHEN bai_value = 'Low' then 3 ELSE 1 END) as float))::numeric/3,2)::float as temporal,round(o.final_count::numeric,2)::float as residual from (
          select cloud_type,nist_id,asset_type, cis_control_id, asset_id,entity_arn, location,bai_value,impact_level,organization_id, organization_name, application_name, application_grp_name, asset_name,(compliance_count::float/total_count) as final_count,entity_type from (
          select  cloud_type,nist_id,cis_control_id,asset_type,asset_id,entity_arn, location,organization_name,organization_id, application_grp_name, application_name, entity_name as asset_name, count(dc.organization_id) as total_count,entity_type, sum(case when lower(dc.severity) ='low' then 3 when lower(dc.severity) ='medium' then 5 when lower(dc.severity) ='high' then 7 when lower(dc.severity) ='critical' then 9 else 1 end) as compliance_count, impact_level, bai_value
          from ${where.compliance.viewWithNistAndServices} dc
          ${whereCondition(...conditionFilter(condition))}
          group by  cloud_type,nist_id,cis_control_id,asset_id,entity_name,asset_type,entity_arn, location, organization_name,organization_id, application_name, application_grp_name,impact_level,bai_value,entity_type order by compliance_count desc ) as t) as o join priorities p on o.final_count <= p.max_value::float and o.final_count >= p.min_value::float `;
      }
    },
    postStages: [
      { type: '_removeUUID' },
      { type: 'setData' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'application_grp_name' },
          { label: 'Sub-Application', path: 'application_name' },
          { label: 'Asset', path: 'asset_name' },
          { label: 'Location', path: 'location' },
          { label: 'Severity', path: 'severity' },
          { label: 'Organization', path: 'organization_name' },
          { label: 'Asset Type', path: 'asset_type' },
          { label: 'Source', path: 'source' }
        ]
      },
      { type: 'orderSeverity' }
    ],
    expected_params: ['orgId']
  },
  {
    route: '/cloud/caveo-circle',
    name: 'caveoCircle',
    whereTransform: {
      default: {
        mapping: {
          source: 'cloud_type'
        }
      }
    },
    sql: {
      default(condition, selector, date) {
        return `select  cloud_type, location, organization_name,organization_id,product, count(distinct entity_arn) as total_count,dc.severity
          from ${where.compliance.viewWithNistAndServices} dc
          ${whereCondition(...conditionFilter(condition))}
          group by  cloud_type, location, organization_name,organization_id,product, severity`;
      }
    },
    postStages: [
      { type: '_removeUUID' },
      { type: 'setData' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'application_grp_name' },
          { label: 'Sub-Application', path: 'application_name' },
          { label: 'Asset', path: 'asset_name' },
          { label: 'Location', path: 'location' },
          { label: 'Severity', path: 'severity' },
          { label: 'Organization', path: 'organization_name' },
          { label: 'Asset Type', path: 'asset_type' },
          { label: 'Source', path: 'source' }
        ]
      },
      { type: 'orderSeverity' }
    ],
    expected_params: ['orgId']
  }

];
