const _ = require('lodash');
const where = require('./common');
const whereCondition = require('../../utils/whereParser.js');
const NetworkFlowService = require('../apis/networkFlow/networkFlow.service');
const conditionFilter = require('../../utils/conditionFilter');
const complianceScore = require('./scoringModules/complianceScore.view');
const cyberScore = require('./scoringModules/cyberScore.view');
const logger = require('./../../utils/logger').logger.child({

  sub_name: 'IdentityService-compliance.js'
});

module.exports = [
  {
    name: 'assetTrendWidget',
    route: '/assetTrend',
    sql: {

      default: function (condition, selector, date) {
        return `select created_at, sum(sum_value) as count from
         (select dai.created_at,dai.organization_id, dai.organization_name, sum(dai.asset_count) as sum_value 
         from daily_asset_summary dai 
         ${whereCondition(...conditionFilter(condition), 'dai.created_at between now()::DATE - interval \'30 day\' and now()::DATE', '(is_active =\'true\' or is_active = \'enabled\')', 'dai.' + where.common.orgChainFilter)} 
         group by dai.created_at,dai.organization_id, dai.organization_name order by dai.created_at) out group by created_at`;
      },
      tabular: function (condition, selector, date) {
        return `select * from (select distinct id, organization_id, asset_name as \"Asset\", location as \"Location\", organization_name as \"Organization\",hosting_provider, unnest(string_to_array(network_ip,','))  as \"Network IP\", application_grp_name as \"Application\", application_name as \"Sub-Application\",created_at::DATE as \"Created Date\" from application_group_asset_view where organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id =:orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id)) x where isIPAddressCheck(network_ip)`;
      }
    },
    postStages: [
      { type: '_removeUUID' },
      { type: 'index', index: '()=>{if(context.selector == \'tabular\')return \'asset_name\'}' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application ', path: 'Application' },
          { label: 'Sub-Application', path: 'Sub-Application' },
          { label: 'Asset', path: 'Asset' },
          { label: 'Location', path: 'Location' },
          { label: 'Organization', path: 'Organization' },
          { label: 'Network IP', path: 'Network IP' }
        ]
      }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'assetTypeLookup',
    route: '/assetTypes',
    sql: {

      default: function (condition, selector, date) {
        return `select distinct type as type from assets ${whereCondition(...conditionFilter(['source'],condition))} union all select distinct product as type from services ${whereCondition(...conditionFilter(['source'],condition))}`;
      }
    },
    postStages: [
      {
        type: 'lodash',
        transformationType: 'map',
        transformer: (d) => {
          return d.type;
        }
      }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'assetSourceLookup',
    route: '/assetSources',
    sql: {

      default: function (condition, selector, date) {
        return `select distinct source from application_group_asset_view ${whereCondition(...conditionFilter(condition), where.common.orgChainFilter)}`;
      }
    },
    postStages: [
      {
        type: 'lodash',
        transformationType: 'map',
        transformer: (d) => {
          return d.source;
        }
      }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'assetView',
    route: '/assetView',
    whereTransform: {
      default: {
        apply: true,
        mapping: {
          organization_name: 'organization_name',
          asset_type: 'type',
          type: 'type',
          location: 'location',
          source: 'source',
          asset_name: 'asset_name',
          application_name: 'application_name'
        }
      }
    },
    sql: {
      default: function (condition, selector, date) {
        return `select distinct ag.id,ag.type as asset_type, ag.organization_id,ag.source, ag.asset_name, ag.location, ag.organization_name,ag.hosting_provider, network_ip, ag.application_grp_name as application_group, 
        CASE WHEN ag.operating_system ILIKE 'linux%' THEN 'linux' ELSE 'windows' END as operating_system, 
        ag.application_name,case when ag.created_at::DATE between (now()- interval '3 days')::date and now()::DATE then 'Yes' else 'No' end  as "New",ag.created_at as asset_created_at, ag.app_grp_created_at as application_group_created_at, ag.application_created_at 
        from application_group_asset_view ag 
        ${whereCondition(where.common.orgChainFilter, ...conditionFilter(condition))}`;
      }
    },
    postStages: [
      { type: '_removeUUID' },
      { type: 'index', index: '()=>{return \'cve_id\'}' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'application_group' },
          { label: 'Sub-Application', path: 'application_name' },
          { label: 'Asset', path: 'asset_name' },
          { label: 'Location', path: 'location' },
          { label: 'Organization', path: 'organization_name' },
          { label: 'New', path: 'New' },
          { label: 'Asset Type', path: 'asset_type' },
          { label: 'Source', path: 'source' }

        ]
      }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'getLocationView',
    route: '/locationView',
    sql: {

      default: function (condition, selector, date) {
        return `select loc as location,coalesce(asset_count,0) as asset_count,coalesce(round(dr.raw_weighted_risk,2),0) as cve_risk_score,coalesce(round(dc.raw_weighted_risk,2),0) as compliance_score from (select location,location as loc, count(distinct(id)) as asset_count from application_group_asset_view ${whereCondition(...conditionFilter(condition), where.common.orgChainFilter)} group by location) asset_set 
       left join (${complianceScore('location', condition)}) dc on dc.label = asset_set.location
       left join (${cyberScore('location', condition)}) dr on dr.label = asset_set.location`;

      }
    },
    expected_params: ['orgId']
  },
  {
    name: 'assetTopFiveWidget',
    route: '/assetTopFive',
    whereTransform: {
      location: {
        apply: true,
        mapping: {
          organization_name: 'organization_name',
          asset_type: 'type',
          type: 'type'
        }
      },
      appGroup: {
        apply: true,
        mapping: {
          organization_name: 'organization_name',
          asset_type: 'type',
          type: 'type'
        }
      },
      default: {
        apply: true,
        mapping: {
          organization_name: 'organization_name',
          asset_type: 'application_group_asset_view.type',
          type: 'application_group_asset_view.type',
          'application_group_asset_view.type': 'application_group_asset_view.type'
        }
      },
      org: {
        apply: true,
        mapping: {
          organization_name: 'organization_name',
          asset_type: 'type',
          type: 'type'
        }
      },
      organization: {
        apply: true,
        mapping: {
          organization_name: 'organization_name',
          asset_type: 'type',
          type: 'type'
        }
      }
    },
    sql: {
      default: function (condition, selector, date) {
        return `select organization_name as name,count,org.type from (select organization_name, count(distinct id), organization_id from application_group_asset_view
        ${whereCondition(...conditionFilter(condition), where.common.orgChainFilter)} group by organization_name,organization_id order by count desc) as d join organizations org on org.id = d.organization_id`;
      },

      org: function (condition, selector, date) {
        return `select organization_name as name, count(distinct id) from application_group_asset_view  
        ${whereCondition(...conditionFilter(condition), where.common.orgChainFilter)} group by organization_name order by count desc`;
      },
      appGroup: function (condition, selector, date) {
        return `select application_grp_name as name, count(distinct id) from application_group_asset_view 
        ${whereCondition(...conditionFilter(condition), where.common.orgChainFilter)} group by application_grp_name order by count desc`;
      },
      location: function (condition, selector, date) {
        return `select location as name, count(distinct id) from application_group_asset_view 
        ${whereCondition(...conditionFilter(condition), where.common.orgChainFilter)} group by location order by count desc`;
      }
    },
    expected_params: ['orgId']
  },

  {
    name: 'assetRiskSeverityWidget',
    route: '/assetRiskSeverity',
    whereTransform: {
      default: {
        apply: true,
        mapping: {
          organization_name: 'organization_name',
          asset_type: 'type',
          type: 'type',
          location: 'location',
          source: 'source',
          asset_name: 'asset_name',
          application_group: 'application_grp_name',
          application_grp_name: 'application_grp_name',
          application_name: 'application_name'
        }
      }
    },
    sql: {

      default: function (condition, selector, date) {
        return `select count(distinct d.id), p.name,sum(count) from (select id,count(distinct id), avg(score::float) as score from daily_risk_score_view dr ${whereCondition(...conditionFilter(condition),
          where.cyber.createdAtRiskFilter,
          where.cyber.riskViewAssetIdInOrgChainFilter)} group by id,dr.application_grp_name , dr.application_name) as d join priorities p on d.score::numeric >= p.min_value and d.score::numeric <= p.max_value group by p.name`;
      },
      critical: function (condition, selector, date) {
        return `select sum(cast (score as float))/count(cve_id) as avg_risk_score from daily_risk_score_view dr  ${whereCondition(...conditionFilter(condition),
          where.cyber.createdAtRiskFilter,
          where.cyber.riskViewAssetIdInOrgChainFilter)}`;
      },
      high: function (condition, selector, date) {
        return `select sum(cast (score as float))/count(cve_id) as avg_risk_score from daily_risk_score_view dr  ${whereCondition(...conditionFilter(condition),
          where.cyber.createdAtRiskFilter,
          where.cyber.riskViewAssetIdInOrgChainFilter)}`;
      },
      medium: function (condition, selector, date) {
        return `select sum(cast (score as float))/count(cve_id) as avg_risk_score from daily_risk_score_view dr  ${whereCondition(...conditionFilter(condition),
          where.cyber.createdAtRiskFilter,
          where.cyber.riskViewAssetIdInOrgChainFilter)}`;
      },
      low: function (condition, selector, date) {
        return `select sum(cast (score as float))/count(cve_id) as avg_risk_score from daily_risk_score_view dr  ${whereCondition(...conditionFilter(condition),
          where.cyber.createdAtRiskFilter,
          where.cyber.riskViewAssetIdInOrgChainFilter)}`;
      }
    },
    postStages: [
      {
        type: 'lodash',
        transformationType: 'reduce',
        transformer: (result, v, index) => {
          logger.info({ result, v, index }, 'result');
          result['Total'] = result['Total'] || 0;
          result['Total'] = parseInt(result['Total']) + parseInt(v.count);
          result[v.name] = v.count;
          return result;
        }
      }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'assetRiskSeverityWidget',
    route: '/assetRiskSeverity/tabular',
    whereTransform: {
      default: {
        apply: true,
        mapping: {
          organization_name: 'organization_name',
          location: 'location',
          application_grp_name: 'application_grp_name',
          application_name: 'application_name',
          asset_type: 'asset_type',
          Severity: 'p.name'
        }
      }
    },
    sql: {
      default: function (condition, selector, date) {

        return `select distinct location as "Location",ag.id as asset_id,asset_name as "Asset", vmid, organization_name as "Organization", application_grp_name as "Application",application_name as "Sub-Application",score.name as "Severity",ag.realm AS "registeredName" ,unnest(string_to_array(ag.network_ip,',')) as ipAddress from (
        select dr.id,dr.score,p.name from (
        select id, avg(score::float) as score from daily_risk_score_view dr  ${whereCondition(...conditionFilter(['organization_name', 'location', 'application_grp_name', 'application_name', 'asset_type'], condition),
          where.cyber.createdAtRiskFilter,
          where.cyber.riskViewAssetIdInOrgChainFilter)} group by id) as dr join priorities p on dr.score::numeric >= p.min_value and dr.score::numeric <= p.max_value ${whereCondition(...conditionFilter(['p.name'], condition))} group by dr.id,dr.score,p.name ) as score, application_group_asset_view ag ${whereCondition(...conditionFilter(['application_grp_name'], condition), 'score.id= ag.id')}`;
      }
    },
    postStages: [
      { type: '_removeUUID' },
      { type: 'index', index: '()=>{if(context.selector == \'tabular\')return \'application\'}' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'Application' },
          { label: 'Sub-Application', path: 'Sub-Application' },
          { label: 'Asset', path: 'Asset' },
          { label: 'Location', path: 'Location' },
          { label: 'Organization', path: 'Organization' },
          { label: 'Severity', path: 'Severity' }
        ]
      },
      { type: 'orderSeverity' }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'assetRiskSeverityWidget',
    route: '/assetRiskSeverity/temporal',
    sql: {
      default: function (condition, selector, date) {
        return `select count(*), p.name from (select id, avg(score::float) as score, bai_value,impact_level from daily_risk_score_view dr ${whereCondition(...conditionFilter(condition),
          where.cyber.createdAtRiskFilter,
          where.cyber.riskViewAssetIdInOrgChainFilter)} group by id,score, bai_value,impact_level) as d join priorities p on ((d.score::numeric+((CASE WHEN d.bai_value = 'Critical' THEN 5 WHEN d.bai_value = 'High' THEN 4 WHEN d.bai_value = 'Medium' 
          THEN 3 WHEN d.bai_value = 'Low' THEN 2 ELSE 1 END))::numeric+d.impact_level::numeric)/3)::numeric >= p.min_value and ((d.score::numeric+((CASE WHEN d.bai_value = 'Critical' THEN 5 WHEN d.bai_value = 'High' THEN 4 WHEN d.bai_value = 'Medium' 
          THEN 3 WHEN d.bai_value = 'Low' THEN 2 ELSE 1 END))::numeric+d.impact_level::numeric)/3)::numeric <= p.max_value group by p.name`;
      },
      critical: function (condition, selector, date) {
        return `select sum(cast (score as float))/count(cve_id) as avg_risk_score from daily_risk_score_view dr  ${whereCondition(...conditionFilter(condition),
          where.cyber.createdAtRiskFilter,
          where.cyber.riskViewAssetIdInOrgChainFilter)}`;
      },
      high: function (condition, selector, date) {
        return `select sum(cast (score as float))/count(cve_id) as avg_risk_score from daily_risk_score_view dr  ${whereCondition(...conditionFilter(condition),
          where.cyber.createdAtRiskFilter,
          where.cyber.riskViewAssetIdInOrgChainFilter)}`;
      },
      medium: function (condition, selector, date) {
        return `select sum(cast (score as float))/count(cve_id) as avg_risk_score from daily_risk_score_view dr  ${whereCondition(...conditionFilter(condition),
          where.cyber.createdAtRiskFilter,
          where.cyber.riskViewAssetIdInOrgChainFilter)}`;
      },
      low: function (condition, selector, date) {
        return `select sum(cast (score as float))/count(cve_id) as avg_risk_score from daily_risk_score_view dr  ${whereCondition(...conditionFilter(condition),
          where.cyber.createdAtRiskFilter,
          where.cyber.riskViewAssetIdInOrgChainFilter)}`;
      },
      tabular: function (condition, selector, date) {

        return `select distinct location as \"Location\",ag.id as asset_id,asset_name as \"Asset\", vmid, organization_name as \"Organization\", application_grp_name as \"Application\",application_name as \"Sub-Application\",score.name as \"Severity\" from (select dr.id,dr.score,p.name from (select id, avg(score::float) as score,bai_value,impact_level from daily_risk_score_view dr  ${whereCondition(...conditionFilter(condition),
          where.cyber.createdAtRiskFilter,
          where.cyber.riskViewAssetIdInOrgChainFilter)} group by id,bai_value,impact_level) as dr join priorities p on ((dr.score::numeric+((CASE WHEN dr.bai_value = 'Critical' then 9.5 WHEN dr.bai_value = 'High' then 8 WHEN dr.bai_value = 'Medium' 
          THEN 3 WHEN dr.bai_value = 'Low' THEN 2 ELSE 1 END))::numeric+dr.impact_level::numeric)/3)::numeric >= p.min_value and ((dr.score::numeric+((CASE WHEN dr.bai_value = 'Critical' then 9.5 WHEN dr.bai_value = 'High' then 8 WHEN dr.bai_value = 'Medium' 
          THEN 3 WHEN dr.bai_value = 'Low' THEN 2 ELSE 1 END))::numeric+dr.impact_level::numeric)/3)::numeric <= p.max_value group by dr.id,dr.score,p.name) as score, application_group_asset_view ag where score.id= ag.id`;
      }
    },
    postStages: [
      { type: 'index', index: '()=>{if(context.selector == \'tabular\')return \'application\'}' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'Application' },
          { label: 'Sub-Application', path: 'Sub-Application' },
          { label: 'Asset', path: 'Asset' },
          { label: 'Location', path: 'Location' },
          { label: 'Organization', path: 'Organization' },
          { label: 'Severity', path: 'Severity' }
        ]
      },
      { type: 'orderSeverity' }
    ],
    expected_params: ['orgId']
  },

  {
    name: 'distributionWidgetApplication',
    route: '/distribution/application',
    search_terms: ['sub-application tabular data'],
    whereTransform: {
      count: {
        apply: true,
        mapping: {
          organization_name: 'organization_name',
          location: 'location',
          application_group: 'application_grp_name',
          application: 'application_grp_name',
          application_name: 'application_name',
          asset_type: 'type',
          source: 'source'
        }
      },
      tabular: {
        apply: true,
        mapping: {
          organization_name: 'ag.organization_name',
          location: 'ag.location',
          application_group: 'ag.application_grp_name',
          application: 'ag.application_grp_name',
          application_name: 'ag.application_name',
          asset_type: 'ag.type',
          source: 'ag.source'
        }
      }
    },
    sql: {
      count: function (condition, selector, date) {
        return `select count(distinct application_name) from application_group_asset_view ${whereCondition(where.common.orgChainFilter, ...conditionFilter(condition))}`;
      },
      percentChange: function (condition, selector, date) {
        return `select 100*(-1+1/(coalesce(NULLIF(count(distinct at.id),0),1)::numeric/(select coalesce(NULLIF(count(distinct at.id),0),1) from application_tags at, sub_applications pg, sub_application_members psm where at.created_at::DATE = (select created_at::DATE from application_tags order by created_at::DATE desc limit 1 offset 1 ) and at.id = psm.source_id and pg.id = psm.policy_group_id and at.${
          where.common.orgChainFilter
        }))) as percent_change from application_tags at, sub_applications pg, sub_application_members psm where at.created_at::DATE = (select created_at::DATE from application_tags order by created_at::DATE desc limit 1 ) and at.id = psm.source_id and pg.id = psm.policy_group_id and at.${
          where.common.orgChainFilter
        }`;
      },
      default: function (condition, selector, date) {
        return `select distinct location as "Location",application_name as "Sub-Application",application_grp_name as "Application",ag.id as asset_id, asset_name as "Asset",network_ip as "Network IP", organization_name as "Organization",o.type as "Type" from application_group_asset_view ag join organizations o on o.id = ag.organization_id ${whereCondition(
          where.common.orgChainFilter,
          ...conditionFilter(condition)
        )}`;
      },
      tabular: function (condition, selector, date) {
        return `select location as "Location",asset_name as "Asset", vmid, organization_name as "Organization", application_grp_name as "Application",application_name as "Sub-Application",type as "Type", dr.asset_id , dr.realm AS "registeredName" ,unnest(string_to_array(dr.network_ip,',')) as "Network IP", asset_type from (select location ,asset_name, vmid, organization_name , application_grp_name ,application_name ,o.type as type, ag.id as asset_id, ag.realm , ag.network_ip, ag.type as asset_type  from application_group_asset_view ag join organizations o on o.id = ag.organization_id ${whereCondition(
          ...conditionFilter(condition),
          where.common.orgChainFilter
        )} group by location ,asset_name , vmid, organization_name , application_grp_name ,application_name ,o.type, asset_id, ag.realm, ag.network_ip, ag.type ) dr left join (select network_ip,asset_id,created_at from asset_vm_network_details vm where isipaddresscheck(vm.network_ip) group by network_ip,asset_id,created_at order by created_at desc limit 1) asset_vm on dr.asset_id=asset_vm.asset_id`;
      }
    },
    postStages: [
      { type: '_removeUUID' },
      { type: 'index', index: '()=>{if(context.selector == \'tabular\')return \'application\'}' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'Application' },
          { label: 'Sub-Application', path: 'Sub-Application' },
          { label: 'Asset', path: 'Asset' },
          { label: 'Asset Type', path: 'asset_type' },
          { label: 'Location', path: 'Location' },
          { label: 'Organization', path: 'Organization' },
          { label: 'Type', path: 'Type' }
        ]
      }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'distributionWidgetAppGroup',
    route: '/distribution/appGroup',
    search_terms: ['application tabular data'],
    whereTransform: {
      count: {
        apply: true,
        mapping: {
          organization_name: 'at.organization_name',
          location: 'at.location',
          application_group: 'at.application_grp_name',
          application_grp_name: 'at.application_grp_name',
          application_name: 'at.application_name',
          asset_type: 'at.type',
          type: 'at.type',
          source: 'at.source'
        }
      },
      tabular: {
        apply: true,
        mapping: {
          organization_name: 'ag.organization_name',
          location: 'ag.location',
          application_group: 'ag.application_grp_name',
          application_grp_name: 'ag.application_grp_name',
          application_name: 'ag.application_name',
          asset_type: 'ag.type',
          type: 'ag.type',
          source: 'ag.source'
        }
      }
    },
    sql: {
      default: function (condition, selector, date) {
        return `select application_name,application_grp_name, asset_name, organization_name,type as asset_type from application_group_asset_view ${whereCondition(
          where.common.orgChainFilter,
          ...conditionFilter(condition)
        )}`;
      },
      tabular: function (condition, selector, date) {
        return `select location as "Location",application_grp_name as "Application",application_name as "Sub-Application", asset_name as "Asset", organization_name as "Organization",o.type as "Type", ag.id as asset_id,unnest(string_to_array(network_ip,',')) as "Network IP" ,realm AS "registeredName",ag.type as asset_type from application_group_asset_view ag join organizations o on o.id = ag.organization_id ${whereCondition(
          where.common.orgChainFilter,
          ...conditionFilter(condition)
        )}`;
      },
      count: function (condition, selector, date) {
        return `select count(distinct application_grp_name) from application_group_asset_view at ${whereCondition(where.common.orgChainFilter, ...conditionFilter(condition))}`;
      },
      percentChange: function (condition, selector, date) {
        return `select 100*(-1+1/(coalesce(NULLIF(count(distinct id),0),1)::numeric/(select coalesce(NULLIF(count(distinct id),0),1) as count from application_tags where created_at::DATE = (select created_at::DATE from application_tags order by created_at::DATE desc limit 1 offset 1) and organization_id in (WITH RECURSIVE org_cte(organization_id) AS (SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id)))) as percent_change from application_tags where created_at::DATE = (select created_at::DATE from application_tags order by created_at::DATE desc limit 1 ) and organization_id in (WITH RECURSIVE org_cte(organization_id) AS (SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id)`;
      }
    },
    expected_params: ['orgId'],

    postStages: [
      { type: '_removeUUID' },
      { type: 'index', index: '()=>{if(context.selector == \'tabular\')return \'application_grp_name\'}' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'Application' },
          { label: 'Sub-Application', path: 'Sub-Application' },
          { label: 'Asset', path: 'Asset' },
          { label: 'Asset Type', path: 'asset_type' },
          { label: 'Location', path: 'Location' },
          { label: 'Organization', path: 'Organization' },
          { label: 'Organization Type', path: 'Type' }
        ]
      }
    ]
  },
  {
    name: 'distributionWidgetLocation',
    route: '/distribution/location',
    search_terms: ['location tabular data'],
    whereTransform: {
      tabular: {
        apply: true,
        mapping: {
          organization_name: 'organization_name',
          location: 'location',
          application_group: 'application_grp_name',
          application: 'application_grp_name',
          application_name: 'application_name',
          asset_type: 'ag.type',
          source: 'ag.source'
        }
      },
      count: {
        apply: true,
        mapping: {
          organization_name: 'organization_name',
          location: 'location',
          application_group: 'application_grp_name',
          application: 'application_grp_name',
          application_name: 'application_name',
          asset_type: 'ag.type',
          source: 'ag.source'
        }
      }
    },
    sql: {
      default: function (condition, selector, date) {
        return 'select * from assets a, asset_details ad , locations l where a.organization_id = ad.organization_id and ad.location_id = l.id and a.organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id)';
      },
      count: function (condition, selector, date) {
        return `select count(distinct location) as "count" from application_group_asset_view ag join organizations o on o.id = ag.organization_id ${whereCondition(
          ...conditionFilter(condition),
          where.common.orgChainFilter
        )}`;
      },
      tabular: function (condition, selector, date) {
        return `select location as "Location",asset_name as "Asset", vmid, name as "Organization", application_grp_name as "Application",application_name as "Sub-Application",type as "Type", dr.asset_id , dr.realm AS "registeredName" ,unnest(string_to_array(dr.network_ip,',')) as "Network IP", asset_type from (select location ,asset_name, vmid, organization_name , application_grp_name ,application_name ,o.type as type, o.name as name, ag.id as asset_id , ag.type as asset_type, ag.realm ,ag.network_ip from application_group_asset_view ag join organizations o on o.id = ag.organization_id ${whereCondition(
          ...conditionFilter(condition),
          where.common.orgChainFilter
        )} group by location ,asset_name , vmid, organization_name , application_grp_name ,application_name ,o.type,o.name, asset_id ,ag.realm ,ag.network_ip,ag.type ) dr left join (select network_ip,asset_id,created_at from asset_vm_network_details vm where isipaddresscheck(vm.network_ip) group by network_ip,asset_id,created_at order by created_at desc limit 1) asset_vm on dr.asset_id=asset_vm.asset_id`;
      },
      percentChange: function (condition, selector, date) {
        return 'select 100*(-1+1/( coalesce(NULLIF(count(distinct ad.location_id),0),1)::numeric/(select coalesce(NULLIF(count(distinct ad.location_id),0),1) as count from assets a, asset_details ad where a.organization_id = ad.organization_id and a.organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id)))) as percent_change from assets a, asset_details ad where ad.created_at >= now() - interval \'1 day\' and a.organization_id = ad.organization_id and a.organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id)';
      }
    },
    postStages: [
      { type: '_removeUUID' },
      { type: 'index', index: '()=>{if(context.selector == \'tabular\')return \'locations\'}' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'Application' },
          { label: 'Sub-Application', path: 'Sub-Application' },
          { label: 'Location', path: 'Location' },
          { label: 'Asset', path: 'Asset' },
          { label: 'Asset Type', path: 'asset_type' },
          { label: 'Organization', path: 'Organization' },
          { label: 'Organization Type', path: 'Type' }
        ]
      }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'distributionWidgetOrganization',
    route: '/distribution/subOrg',
    search_terms: ['sub-organization tabular data'],
    whereTransform: {
      count: {
        apply: true,
        mapping: {
          organization_name: 'ag.organization_name',
          source: 'ag.source',
          location: 'ag.location',
          application_grp_name: 'ag.application_grp_name',
          application_group: 'ag.application_grp_name',
          application_name: 'ag.application_name',
          asset_type: 'ag.type',
          type: 'ag.type',
          asset_name: 'ag.name'
        }
      },
      tabular: {
        apply: true,
        mapping: {
          organization_name: 'ag.organization_name',
          source: 'ag.source',
          location: 'ag.location',
          application_grp_name: 'ag.application_grp_name',
          application_group: 'ag.application_grp_name',
          application_name: 'ag.application_name',
          asset_type: 'ag.type',
          type: 'ag.type',
          asset_name: 'ag.name'
        }
      }
    },
    sql: {
      count: function (condition, selector, date) {
        return `select count(distinct o.name) as count from application_group_asset_view ag join organizations o on o.id = ag.organization_id ${whereCondition(
          ...conditionFilter(condition),
          where.common.orgChainFilter,
          'o.type=\'Sub-Organization\''
        )}`;
      },
      percentChange: function (condition, selector, date) {
        return `select 100*(-1+1/(coalesce(NULLIF(count(*),0),1)::numeric/ 
        (select coalesce(NULLIF(count(id),0),1) from organizations where
         id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id)))) as percent_change 
        from organizations where created_at >= now() - interval '1 day' and id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id)`;
      },
      tabular: function (condition, selector, date) {
        return `select location as "Location", o.name as "Organization" , application_grp_name as "Application",application_name as "Sub-Application", asset_name as "Asset" ,o.type as "Type",ag.type as "Asset-Type", ag.id as asset_id,ag.realm AS "registeredName" ,unnest(string_to_array(ag.network_ip,',')) as "Network IP" from application_group_asset_view ag join organizations o on o.id = ag.organization_id ${whereCondition(
          ...conditionFilter(condition),
          where.common.orgChainFilter,
          'o.type=\'Sub-Organization\''
        )}`;
      },
      default: function (condition, selector, date) {
        return 'select * from assets where organization_id in ( WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id WHERE tn.organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id)';
      }
    },
    postStages: [
      { type: '_removeUUID' },
      { type: 'index', index: '()=>{if(context.selector == \'tabular\')return \'subOrg\'}' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'Application' },
          { label: 'Sub-Application', path: 'Sub-Application' },
          { label: 'Asset', path: 'Asset' },
          { label: 'Asset Type', path: 'Asset-Type' },
          { label: 'Location', path: 'Location' },
          { label: 'Organization', path: 'Organization' },
          { label: 'Organization Type', path: 'Type' }
        ]
      }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'distributionWidgetOrganization',
    route: '/distribution/organization',
    whereTransform: {
      count: {
        apply: true,
        mapping: {
          organization_name: 'ag.organization_name',
          source: 'ag.source',
          location: 'ag.location',
          application_grp_name: 'ag.application_grp_name',
          application_group: 'ag.application_grp_name',
          application_name: 'ag.application_name',
          asset_type: 'ag.type',
          type: 'ag.type',
          asset_name: 'ag.name'
        }
      },
      tabular: {
        apply: true,
        mapping: {
          organization_name: 'ag.organization_name',
          source: 'ag.source',
          location: 'ag.location',
          application_grp_name: 'ag.application_grp_name',
          application_group: 'ag.application_grp_name',
          application_name: 'ag.application_name',
          asset_type: 'ag.type',
          type: 'ag.type',
          asset_name: 'ag.name'
        }
      }
    },
    sql: {
      count: function (condition, selector, date) {
        return `select count(distinct o.name) as count from application_group_asset_view ag join organizations o on o.id = ag.organization_id ${whereCondition(
          ...conditionFilter(condition),
          where.common.orgChainFilter
        )} and (o.type = 'Provider' or o.type = 'Organization' ) `;
      },
      percentChange: function (condition, selector, date) {
        return 'select 0 as percent_change';//"select  100*(-1+1/(coalesce(NULLIF(count(*),0),1)::numeric/ (select coalesce(NULLIF(count(id),0),1) from organizations where id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id)))) as percent_change from organizations where created_at >= now() - interval '1 week' and id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id)"
      },
      tabular: function (condition, selector, date) {
        return `select location as "Location",asset_name as "Asset", vmid, organization_name as "Organization", application_grp_name as "Application",application_name as "Sub-Application",type as "Type", dr.asset_id,dr.realm AS "registeredName" ,unnest(string_to_array(dr.network_ip,',')) as \"Network IP\",asset_type from (select location ,asset_name, vmid, organization_name , application_grp_name ,application_name ,o.type as type, ag.type as asset_type, ag.id as asset_id,ag.realm,ag.network_ip from application_group_asset_view ag join organizations o on o.id = ag.organization_id ${whereCondition(
          ...conditionFilter(condition),
          where.common.orgChainFilter,
          `o.type IN ('Organization','Provider')`
        )} group by location ,asset_name , vmid, organization_name , application_grp_name ,application_name ,o.type, asset_id, ag.realm ,ag.network_ip,ag.type) dr left join (select network_ip,asset_id,created_at from asset_vm_network_details vm where isipaddresscheck(vm.network_ip) group by network_ip,asset_id,created_at order by created_at desc limit 1) asset_vm on dr.asset_id=asset_vm.asset_id`;
      },
      default: function (condition, selector, date) {
        return 'select * from assets where organization_id in ( WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id WHERE tn.organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id)';
      }
    },
    postStages: [
      { type: '_removeUUID' },
      { type: 'index', index: '()=>{if(context.selector == \'tabular\')return \'organization_name\'}' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'Application' },
          { label: 'Sub-Application', path: 'Sub-Application' },
          { label: 'Asset', path: 'Asset' },
          { label: 'Asset Type', path: 'asset_type' },
          { label: 'Location', path: 'Location' },
          { label: 'Organization', path: 'Organization' },
          { label: 'Organization Type', path: 'Type' }
        ]
      }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'distributionWidgetAsset',
    route: '/distribution/asset',
    whereTransform: {
      count: {
        apply: true,
        mapping: {
          organization_name: 'organization_name',
          asset_type: 'ag.type',
          type: 'o.type',
          location: 'location',
          source: 'ag.source',
          asset_name: 'asset_name',
          application_name: 'ag.application_name',
          application_group: 'ag.application_grp_name'
        }
      },
      tabular: {
        apply: true,
        mapping: {
          organization_name: 'organization_name',
          asset_type: 'ag.type',
          type: 'o.type',
          location: 'location',
          source: 'ag.source',
          asset_name: 'asset_name',
          application_name: 'application_name',
          application_group: 'application_grp_name'
        }
      }
    },
    search_terms: ['assets tabular data'],
    sql: {
      default: function (condition, selector, date) {
        return 'select * from assets where organization_id in ( WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id WHERE tn.organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id)';
      },
      tabular: function (condition, selector, date) {
        return `select location as "Location",asset_name as "Asset", vmid, organization_name as "Organization", application_grp_name as "Application",application_name as "Sub-Application",o.type as "Type", ag.id as asset_id ,realm AS "registeredName", network_ip as "Network IP", ag.type as asset_type from application_group_asset_view ag join organizations o on o.id = ag.organization_id ${whereCondition(
          ...conditionFilter(condition),
          where.common.orgChainFilter
        )}`;
      },
      count: function (condition, selector, date) {
        return `select count(distinct(ag.id)) from application_group_asset_view ag join organizations o on o.id = ag.organization_id  ${whereCondition(
          ...conditionFilter(condition),
          where.common.orgChainFilter
        )}`;
      },
      percentChange: function (condition, selector, date) {
        return `select percent_change * 100 as percent_change from (select count/(sum(count) over () )::numeric as percent_change, rownum
from (select count(*), date , row_number() over () as rownum
from (select  ag.id, max(ag.created_at)::DATE as date from application_group_asset_view ag join organizations o on o.id = ag.organization_id   
where organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId UNION ALL 
SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id) group by ag.id order by date desc) foo group by date order by date desc) bar) g where rownum = 1`;
      }
    },
    postStages: [
      { type: '_removeUUID', index: '()=>{if(context.selector == \'tabular\')}' },
      { type: 'index', index: '()=>{if(context.selector == \'tabular\')return \'asset_name\'}' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'Application' },
          { label: 'Sub-Application', path: 'Sub-Application' },
          { label: 'Asset', path: 'Asset' },
          { label: 'Asset Type', path: 'asset_type' },
          { label: 'Location', path: 'Location' },
          { label: 'Organization', path: 'Organization' },
          { label: 'Type', path: 'Type' }
        ]
      }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'threatWidget',
    route: '/threatDetection',
    sql: {
      default: function (condition, selector, date) {
        return `select  
        distinct ta.vmid, ta.source, ta.destination, ta.direction, 
        case when direction='outgoing' then ta.source when direction='incoming' then ta.destination end as ip_address,
        ag.asset_name, ag.organization_name, ag.location, ag.application_grp_name, ag.application_name,
         ta.count, ta.max, ta.min 
        from 
        (select  vmid, source, destination, direction, count(id), max(created_at), min(created_at) 
        from threat_assets group by vmid, source, destination, direction ) ta 
        join application_group_asset_view ag on
         ta.vmid = ag.vmid and
         ((ta.source = ag.network_ip and direction='outgoing') or 
         (ta.destination = ag.network_ip and direction='incoming'))
        ${whereCondition(...conditionFilter(condition), where.common.orgChainFilter)}`;
      },
      count: function (condition, selector, date) {
        return ` select count(distinct ta.vmid) as asset_count,  count(distinct ta.source) as threat_count from threat_assets ta
        join application_group_asset_view ag 
        on ta.vmid = ag.vmid and ta.ip_address = ag.network_ip
                ${whereCondition(...conditionFilter(condition), where.common.orgChainFilter)}`;

      }
    }
  },
  {
    name: 'assetLookUpByNameAdvancedSearch',
    route: '/assetLookup/:assetId',
    sql: {
      asset: function (condition, selector, date) {
        return `select distinct ag.name,
        ag.network_ip,
        ag.network,
        ag.macaddress,
        ag.vmid,
        ag.source,
        ag.organization_name,
        ag.operating_system,
         ag.application_name, 
         ag.network_ip,
         ag.application_grp_name, 
         ag.asset_name,
         ag.id as asset_id,
         ag.realm,
         ag.memory_size,
         ag.cpu_count,
         ag.managed,
         ag.type,
         ag.repo_type,
         ag.connection_name,
         ag.location,
         ag.hosting_provider,
         ag.managed,
         ag.physical_host_name,
         ag.is_active as asset_status,
          ag.id,
          ag.asset_tags,
           avr.region, avr.vpc_name, avr.avail_zone
           from application_group_asset_view ag 
          left join  aws_vpc_regions avr on  avr.asset_id = ag.id
        ${whereCondition(where.common.orgChainFilter,
          'ag.id = :assetId',
          ...conditionFilter(condition))} `;
      },
      cyber: function (condition, selector, date) {
        return `select dr.result as cyber_result, dr.application_grp_name, dr.application_name, dr.asset_name,dr.score, cve_set.* from
         ${where.cyber.view} dr join common_vulnerabilities_exposures cve_set on cve_set.cve_id = dr.cve_id ${whereCondition(...conditionFilter(condition), 'dr.id = :assetId', where.cyber.createdAtRiskFilter)} `;
      },
      compliance: function (condition, selector, date) {
        return `select r.rule_id, r.rule_fix, r.rule_desc,dr.network_ip as ip,dr.source,dr.managed,dr.realm, dr.vmid,dr.application_quarantine,dr.application_grp_quarantine,dr.location, dr.cpu_count, dr.memory_size,dr.result as compliance_result, dr.application_grp_name, dr.application_name, dr.asset_name,
         dr.contributor, dr.definition,dr.index,dr.status,dr.cci_id from ${where.compliance.viewWithNist} dr  
        join xccdf_rules r on r.rule_id = dr.rule_id 
        ${whereCondition(...conditionFilter(condition), 'dr.id = :assetId')} `;
      },
      aws: function (condition, selector, date) {
        return `select * from aws_vpc_regions avr left join security_groups sg on sg.asset_id = avr.asset_id where avr.asset_id = :assetId`;
      },
      networkPolicy: function (condition, selector, date) {

        return `select distinct
                rule_direction,
                section_id,
                rule_id,
                rule_name,
                action,
                destination_port,
                protocol,
                destination_id as dfw_destination_id ,
                source_id as dfw_source_id ,
                destination_name as dfw_destination_name ,
                source_name as dfw_source_name,
                destination as dfw_destination,
                source as dfw_source from network_policy_view_table ${whereCondition(`asset_id = :assetId`, `security_group is not null`)}`;
      },
      networkFlows: async function (condition, selector, date, params) {
        const nf = new NetworkFlowService();
        const { orgId, assetId, token, authToken } = params;
        const d = await nf.getNetworkDataForAsset(orgId, assetId, token, authToken);
        return d;
      },
      software: function (condition, selector, date) {
        return `select 
        st.name as software_name,
        st.vendor as software_vendor, 
        st.part as software_part, 
        st.description as software_description,
        st.version as software_version,
        st.edition as software_edition,
        st.lang as software_lang,
        st.sw_edition as software_sw_edition,
        st.target_sw as software_target_sw,
        st.target_hw as software_target_hw,
        st.other as software_other,
        st.update as software_update,
        st.full_cpe as software_full_cpe,
        st.created_at as software_created_at
         from software_tags st join asset_software_tags_members astm on astm.software_tags_id = st.id join assets a on a.id = astm.asset_id 
        ${whereCondition(
          ...conditionFilter(condition),
          `a.id = :assetId`
        )}`;
      },
      name: function (condition, selector, date) {
        return `select distinct ag.name as organization_name,ag.network_ip,ag.macaddress,ag.vmid,ag.source,ag.organization_name, ag.application_name ,ag.application_grp_name, ag.asset_name,ag.realm,ag.memory_size,ag.cpu_count,ag.managed,ag.location, ag.id from application_group_asset_view ag 
        ${whereCondition(where.common.orgChainFilter,
          'ag.name like \'%\' ||:assetId||\'%\'',
          ...conditionFilter(condition))}`;
      }
    },
    expected_params: ['orgId', 'assetId'],
    postStages: [
      { type: 'lodash', transformationType: 'flattenDeep' },
      { type: 'xml2Yaml', path: 'rule_desc' },
      { type: '_removeUUID' },
      {
        type: 'lodash',
        transformationType: 'reduce',
        transformer:
          (result, v, index) => {

            result.cves = result.cves || {};
            result.flows = result.flows || [];
            if (v._type == 'flows') result.flows.push(v._source);
            const cve = result.cves[v.cve_id] || {};
            result.ccis = result.ccis || {};
            const cci = result.ccis[v.cci_id] || {};

            cve.cve_id = v.cve_id;
            cve.assessment_check_name = v.assessment_check_name;
            cve.summary = v.summary;
            cve.security_production = v.security_production;
            cve.assessment_check_system = v.assessment_check_system;
            cve.assessment_check_ref = v.assessment_check_ref;
            cve.score = v.score;
            cve.result = v.cyber_result;
            let asset_tag;
            try {
              asset_tag = JSON.parse(v.asset_tags);
            } catch (e) {
              asset_tag = v.asset_tags;
            }
            result.asset_tags = result.asset_tags || asset_tag;
            result.ip = v.network_ip || result.ip;
            result.assetStatus = v.asset_status || result.assetStatus;
            result.network = v.network || result.network;
            result.asset_id = result.asset_id || v.id;
            result.asset_name = result.asset_name || v.asset_name;
            result.physicalHostName = v.physical_host_name || result.physicalHostName;
            result.vmid = v.vmid || result.vmid;
            result.source = v.source || result.source;
            result.realm = v.realm || result.realm;
            result.managed = v.managed || result.managed;
            result.cpuCount = v.cpu_count || result.cpu_count;
            result.operatingSystem = v.operating_system || result.operatingSystem;
            result.hostingProvider = v.hosting_provider || result.hostingProvider;
            result.assetType = v.type || result.assetType;
            result.repoType = v.repo_type || result.repoType;
            result.macAddress = v.madaddress || result.macAddress;
            result.memorySize = v.memory_size || result.memorySize;
            result.locations = result.locations || [];
            result.locations.push(v.location);
            result.region = v.region || result.region;
            result.avail_zone = v.avail_zone || result.avail_zone;
            result.vpc_name = v.vpc_name || result.vpc_name;
            result.locations = Array.from(new Set(result.locations.filter(a => a)));
            // result.cyber_score = result.cyber_score|| 0
            // result.compliance_score = result.compliance_score || 0
            result.software = result.software || [];
            if (!result.software.find((software) => {
              return software.full_cpe == v.software_full_cpe;
            })) {
              if (v.software_name && v.software_name !== undefined) {
                result.software.push({
                  name: v.software_name,
                  vendor: v.software_vendor,
                  part: v.software_part,
                  description: v.software_description,
                  version: v.software_version,
                  edition: v.software_edition,
                  lang: v.software_lang,
                  full_cpe: v.software_full_cpe,
                  update: v.software_update,
                  sw_edition: v.software_sw_edition,
                  target_software: v.software_target_sw,
                  target_hardware: v.software_target_hw,
                  created_at: v.software_created_at
                });
              }
            }
            result.applications = result.applications || [];
            result.firewall_rules = result.firewall_rules || [];
            result.firewall_rules.push({
              dfw_direction: v.rule_direction,
              dfw_section_name: v.section_id,
              dfw_rule_id: v.rule_id,
              dfw_name: v.rule_name,
              dfw_action: v.action,
              dfw_port: v.destination_port,
              dfw_protocol: v.protocol,
              dfw_other_endpoint_id: v.rule_direction === 'OUTGOING' ? v.dfw_destination_id : v.dfw_source_id,
              dfw_other_ip_addresses: v.rule_direction === 'OUTGOING' ? v.dfw_destination_name : v.dfw_source_name,
              dfw_other_asset: v.rule_direction === 'OUTGOING' ? v.dfw_destination : v.dfw_source,
            });
            result.aws = result.aws || [];

            if (v.aws_sg_name && v.vpc_name && v.tags) {
              if (!result.aws.find((a) => v.vpc_name == a.vpc_name && v.tags == a.tags && v.aws_sg_name == a.aws_sg_name)) {
                result.aws.push({
                  region: v.region,
                  avail_zone: v.avail_zone,
                  vpc_name: v.vpc_name,

                  aws_sg_name: v.aws_sg_name,
                  description: v.description,
                  ip_permissions: v.ip_permissions,
                  tags: v.tags,
                  ip_permissions_egress: v.ip_permissions_egress,
                  links: v.links,
                  rules: v.rules
                });
              }
            }
            cci.cci_id = v.cci_id;
            cci.result = v.compliance_result;
            cci.rules = cci.rules || [];
            cci.contributor = v.contributor;
            cci.index = v.index;
            cci.definition = v.definition;
            if (!cci.rules.find((rule) => {
              return v.rule_id === rule.rule_id;
            })) {
              cci.rules.push({ rule_fix: v.rule_fix, rule_id: v.rule_id, result: v.result, rule_desc: v.rule_desc });
            }
            if (!result.applications.find((a) => {
              return v.application_grp_name == a.application_grp_name && v.application_name == a.application_name && v.asset_name == a.asset_name;
            })) {
              result.applications.push({
                application_name: v.application_name,
                application_grp_name: v.application_grp_name,
                asset_name: v.asset_name,
                asset_id: v.asset_id,
                application_quarantine: v.application_grp_quarantine,
                sub_application_quarantine: v.application_quarantine,
                organization_name: v.organization_name
              });
            }
            if (cve.cve_id) {

              const total_cyber_score = Object.values(result.cves).reduce((accumulator, obj) => {
                return accumulator + parseFloat(obj.score);
              }, 0);
              const count = Object.values(result.cves).length;
              result.cyber_score = total_cyber_score / count;
              result.cves[cve.cve_id] = cve;
            }
            if (cci.cci_id) {
              const total_compliance_count = Object.values(result.ccis).reduce((accumulator, obj) => {
                if (obj.result == 'fail') {
                  return accumulator + 1;
                } else {
                  return accumulator;
                }
              }, 0);
              const count = Object.values(result.ccis).length;
              result.compliance_score = 10 * (total_compliance_count / count);
              result.ccis[cci.cci_id] = cci;
            }
            result.software = _.filter(result.software, (o) => {
              return !_.isEmpty(o);
            });
            result.aws = _.filter(result.aws, (o) => {
              return !_.isEmpty(o);
            });
            result.firewall_rules = _.filter(result.firewall_rules, (o) => {
              return !_.isEmpty(o);
            });

            return result;
          }

      }
    ]
  },
  {
    name: 'distributionWidgetAsset',
    route: '/counts',
    search_terms: ['assets tabular data'],
    sql: {
      new: function (condition, selector, date) {
        return `select distinct name from application_group_asset_view ag 
            ${whereCondition(
          `ag.created_at::DATE between (now()- interval '3 days')::date and now()::DATE`,
          where.common.orgChainFilter,
          ...conditionFilter(condition)
        )}`;
      },
      missedScan: function (condition, selector, date) {
        logger.info({ where: where }, 'where ');
        return `select distinct id, name from assets a ${whereCondition(
          `id not in (select distinct asset_id from daily_scan_xccdf_results scan where scan.id in 
          ( select id from daily_scan_xccdf_results scan where date_trunc('hour', scan.created_at) in 
          (select max(date_trunc('hour', created_at)) from 
          daily_scan_xccdf_results)))`,
          where.common.orgChainFilter,
          where.assets.assetIsActiveFilter
        )}`;
      },
      tabular: function (condition, selector, date) {
        return `select distinct ag.id,ag.type as asset_type, ag.organization_id,ag.source, ag.asset_name, ag.location, ag.organization_name,ag.hosting_provider, unnest(string_to_array(ag.network_ip,',')) as \"Network IP\", ag.application_grp_name as application_group, ag.application_name, ag.created_at as asset_created_at, ag.app_grp_created_at as application_group_created_at, ag.application_created_at 
        from application_group_asset_view ag 
        ${whereCondition(
          `ag.created_at::DATE between (now()- interval '3 days')::date and now()::DATE`,
          where.common.orgChainFilter,
          ...conditionFilter(condition)
        )}`;
      }
    },
    postStages: [
      { type: 'setData' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'application_group' },
          { label: 'Sub-Application', path: 'application_name' },
          { label: 'Asset', path: 'asset_name' },
          { label: 'Location', path: 'location' },
          { label: 'Organization', path: 'organization_name' },
          { label: 'Asset Type', path: 'asset_type' },
          { label: 'Source', path: 'source' }

        ]
      },
      { type: 'count', dataPath: 'data' },
      {
        type: 'lodash', transformationType: 'map', dataPath: 'data', transformer: `(d)=>{
        if(context.selector != 'tabular'){
          return d.name
        }
        return d
      }`
      }
    ],
    expected_params: ['orgId']
  },
  {}
];
