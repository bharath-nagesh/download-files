module.exports = function(label){
  return `select label,
round((sum(weighted_risk_by_rating)/sum(weighted_count_by_rating))::NUMERIC, 2)  as raw_weighted_risk, name as severity
from
(select label,name, risk_weight , risk_used_for_calc , mod_rollup ,(risk_weight * risk_used_for_calc * mod_rollup)/100 as weighted_risk_by_rating,
(risk_weight * mod_rollup)/100::FLOAT as weighted_count_by_rating
from
(

select label,name, risk_used_for_calc,risk_weight, straight_count,cap_count,
CASE
WHEN (name = 'Low') THEN cap_rollup::integer
WHEN (name = 'Medium') THEN cap_rollup::integer
WHEN (name = 'High') THEN cap_rollup::integer
 WHEN (name = 'Critical') THEN (straight_count + LAG(cap_rollup) OVER w)::integer
END as cap_rollup,
CASE
WHEN (name = 'Low') THEN mod_rollup::integer
WHEN (name = 'Medium') THEN mod_rollup::integer
WHEN (name = 'High') THEN mod_rollup::integer
WHEN (name = 'Critical') THEN (straight_count + LAG(cap_rollup) OVER w)::integer
END as mod_rollup
from
(
select label, name, risk_used_for_calc,risk_weight, straight_count,cap_count,
CASE
WHEN (name = 'Low') THEN cap_rollup
WHEN (name = 'Medium') THEN cap_rollup
WHEN ((name = 'High') and (cap_count != 0)) THEN (straight_count + LAG(cap_rollup) OVER w)/cap_count
WHEN ((name = 'Critical') and (cap_count != 0)) THEN (straight_count + LAG(cap_rollup) OVER w)/cap_count
ELSE 0
END as cap_rollup,
CASE
WHEN (name = 'Low') THEN mod_rollup
WHEN (name = 'Medium') THEN mod_rollup
WHEN ((name = 'High') and (cap_count != 0))  THEN MOD((straight_count + LAG(cap_rollup) OVER w), cap_count)
WHEN ((name = 'Critical') and (cap_count != 0))  THEN MOD((straight_count + LAG(cap_rollup) OVER w), cap_count)
ELSE 0
END as mod_rollup
from
(
select label, name, risk_used_for_calc,risk_weight, straight_count,cap_count,
CASE
WHEN (name = 'Low') THEN cal_q
WHEN ((name = 'Medium') and (cap_count != 0))  THEN (straight_count +coalesce(LAG(cal_q) OVER w,0))/cap_count
WHEN ((name = 'High') and (cap_count != 0))  THEN (straight_count + coalesce(LAG(cal_q) OVER w,0))/cap_count
WHEN ((name = 'Critical') and (cap_count != 0))  THEN (straight_count + coalesce(LAG(cal_q) OVER w,0))/cap_count
ELSE 0
END as cap_rollup,
CASE
WHEN (name = 'Low') THEN cal_m
WHEN ((name = 'Medium') and (cap_count != 0))  THEN MOD((straight_count + coalesce(LAG(cal_q) OVER w,0)), cap_count)
WHEN ((name = 'High') and (cap_count != 0))  THEN MOD((straight_count + coalesce(LAG(cal_q) OVER w,0)), cap_count)
WHEN ((name = 'Critical') and (cap_count != 0))  THEN MOD((straight_count + coalesce(LAG(cal_q) OVER w,0)), cap_count)
ELSE 0
END as mod_rollup
from
(select label, name,risk_used_for_calc,risk_weight, straight_count,cap_count,
 CASE WHEN cap_count != 0 THEN div(straight_count,cap_count) ELSE 0 END as cal_q,
 CASE WHEN cap_count != 0 THEN mod(straight_count,cap_count) ELSE 0 END as cal_m
from
(select n.label, n.id, n.name,coalesce(risk_weight,0) as risk_weight, coalesce(cap_count,0) as cap_count,
coalesce(risk_used_for_calc,0) as risk_used_for_calc, coalesce(straight_count,0) as straight_count
from
(select id,label, concat(label,id) as idloc, comp_score.straight_count, comp_score.name, score as risk_used_for_calc,risk_weight,cap_count
from
(select ${label} as label, count (dc.id) as straight_count,lower(severity) as name,
 case when lower(severity)='low' then 2 when lower(severity)='medium' then 5.5
      when lower(severity)='high' then 8 when lower(severity)='critical' then 9.5  end as score from
(select asset_id,rule_id, scan_result as result,scan_type,ag.* from daily_scan_xccdf_results scan
join application_group_asset_view ag on ag.id = asset_id
where date_trunc('hour',scan.created_at::DATE) < date_trunc('hour',:date::DATE) and
date_trunc('hour', scan.created_at) || asset_id::text in (select max(date_trunc('hour', created_at)) || asset_id::text
from daily_scan_xccdf_results
where asset_id in (select id from assets where (is_active='enabled' or is_active='true' or is_active='disabled')
and organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn
join organizations as o on o.id = tn.organization_id and organization_id = :orgId UNION ALL
SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id
WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL
SELECT :orgId as  organization_id) ) group by asset_id) ) dc
join xccdf_rules x on dc.rule_id = x.rule_id
where result='FAIL' and dc.id in (select id from assets where (is_active='enabled' or is_active='true' or is_active='disabled') and
organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn
join organizations as o on o.id = tn.organization_id and organization_id = :orgId
UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id
WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as  organization_id) )
group by label, lower(severity) order by label) as comp_score right join priorities p on comp_score.name = lower(p.name))
as inner_group
full join (select concat(label,id) as idloc, label, name, id from priorities p1,
(select distinct ${label} as label from daily_compliance_score_view) as rm1) n
on (inner_group.idloc = n.idloc)
order by label, id desc  )
as interim_values
) as final_no
  WINDOW w AS (ROWS BETWEEN 1 PRECEDING AND CURRENT ROW)
  ) as final_no1
  WINDOW w AS (ROWS BETWEEN 1 PRECEDING AND CURRENT ROW)
  ) as final_no2
WINDOW w AS (ROWS BETWEEN 1 PRECEDING AND CURRENT ROW)
) as final_no3
WINDOW w AS (ROWS BETWEEN 1 PRECEDING AND CURRENT ROW)
) as final
group by label
`
}
