const where = require('../common');
const whereCondition = require('../../../utils/whereParser.js');
const conditionFilter = require('../../../utils/conditionFilter');
module.exports = function (label, condition = [],isServiceProvider=false) {
  const view = isServiceProvider ? where.cyber.serviceProvider.view : where.cyber.view;

  return `select label,
round((sum(weighted_risk_by_rating)/sum(weighted_count_by_rating))::NUMERIC, 2)  as raw_weighted_risk
from
(select label,name, risk_weight , risk_used_for_calc , mod_rollup ,(risk_weight * risk_used_for_calc * mod_rollup)/100 as weighted_risk_by_rating,
(risk_weight * mod_rollup)/100::FLOAT as weighted_count_by_rating
from
(
select label,name, risk_used_for_calc,risk_weight, straight_count,cap_count,
CASE
WHEN (name = 'Low') THEN cap_rollup::integer
WHEN (name = 'Medium') THEN cap_rollup::integer
WHEN (name = 'High') THEN cap_rollup::integer
 WHEN (name = 'Critical') THEN (straight_count + LAG(cap_rollup) OVER w)::integer
END as cap_rollup,
CASE
WHEN (name = 'Low') THEN mod_rollup::integer
WHEN (name = 'Medium') THEN mod_rollup::integer
WHEN (name = 'High') THEN mod_rollup::integer
WHEN (name = 'Critical') THEN (straight_count + LAG(cap_rollup) OVER w)::integer
END as mod_rollup
from
(
select label, name, risk_used_for_calc,risk_weight, straight_count,cap_count,
CASE
WHEN (name = 'Low') THEN cap_rollup
WHEN (name = 'Medium') THEN cap_rollup
WHEN ((name = 'High') and (cap_count != 0)) THEN (straight_count + LAG(cap_rollup) OVER w)/cap_count
WHEN ((name = 'Critical') and (cap_count != 0)) THEN (straight_count + LAG(cap_rollup) OVER w)/cap_count
ELSE 0
END as cap_rollup,
CASE
WHEN (name = 'Low') THEN mod_rollup
WHEN (name = 'Medium') THEN mod_rollup
WHEN ((name = 'High') and (cap_count != 0))  THEN MOD((straight_count + LAG(cap_rollup) OVER w), cap_count)
WHEN ((name = 'Critical') and (cap_count != 0))  THEN MOD((straight_count + LAG(cap_rollup) OVER w), cap_count)
ELSE 0
END as mod_rollup
from
(
select label, name, risk_used_for_calc,risk_weight, straight_count,cap_count,
CASE
WHEN (name = 'Low') THEN cal_q
WHEN ((name = 'Medium') and (cap_count != 0))  THEN (straight_count +coalesce(LAG(cal_q) OVER w,0))/cap_count
WHEN ((name = 'High') and (cap_count != 0))  THEN (straight_count + coalesce(LAG(cal_q) OVER w,0))/cap_count
WHEN ((name = 'Critical') and (cap_count != 0))  THEN (straight_count + coalesce(LAG(cal_q) OVER w,0))/cap_count
ELSE 0
END as cap_rollup,
CASE
WHEN (name = 'Low') THEN cal_m
WHEN ((name = 'Medium') and (cap_count != 0))  THEN MOD((straight_count + coalesce(LAG(cal_q) OVER w,0)), cap_count)
WHEN ((name = 'High') and (cap_count != 0))  THEN MOD((straight_count + coalesce(LAG(cal_q) OVER w,0)), cap_count)
WHEN ((name = 'Critical') and (cap_count != 0))  THEN MOD((straight_count + coalesce(LAG(cal_q) OVER w,0)), cap_count)
ELSE 0
END as mod_rollup
from
(select label, name,risk_used_for_calc,risk_weight, straight_count,cap_count,
 CASE WHEN cap_count != 0 THEN div(straight_count,cap_count) ELSE 0 END as cal_q,
 CASE WHEN cap_count != 0 THEN mod(straight_count,cap_count) ELSE 0 END as cal_m
from
(select n.label, n.id, n.name,coalesce(risk_weight,0) as risk_weight, coalesce(cap_count,0) as cap_count,
coalesce(risk_used_for_calc,0) as risk_used_for_calc, coalesce(straight_count,0) as straight_count
from
(select  idLoc, label, id, name,risk_weight, cap_count, coalesce(max(score), max_value) as risk_used_for_calc ,coalesce(count(no),0) as straight_count
from
(select concat(${label},priority_id) as idLoc, ${label} as label, score::numeric,priority_id as id, cap_count,  severity as name, priority_max_value as max_value, priority_risk_weight as risk_weight, dr.id as no
 from ${view} dr ${whereCondition(...conditionFilter(['source','asset_type','application_grp_name','result','application_name','asset_name','location_name','vmid','organization_name'], condition))}) as row_values
 group by idLoc, label, id, name, max_value, risk_weight, cap_count
ORDER BY idLoc desc)
as inner_group
full join (select concat(label,id) as idloc, label, name, id from priorities p1,
(select distinct ${label} as label from ${view} x) as rm1) n
on (inner_group.idloc = n.idloc)
order by label, id desc  )
as interim_values
) as final_no
  WINDOW w AS (ROWS BETWEEN 1 PRECEDING AND CURRENT ROW)
  ) as final_no1
  WINDOW w AS (ROWS BETWEEN 1 PRECEDING AND CURRENT ROW)
  ) as final_no2
WINDOW w AS (ROWS BETWEEN 1 PRECEDING AND CURRENT ROW)
) as final_no3
WINDOW w AS (ROWS BETWEEN 1 PRECEDING AND CURRENT ROW)
) as final WHERE risk_used_for_calc != 0 AND weighted_count_by_rating != 0
group by label
`;
};
