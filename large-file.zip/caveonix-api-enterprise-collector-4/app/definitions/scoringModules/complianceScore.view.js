const where = require('../common');
const whereCondition = require('../../../utils/whereParser.js');
const conditionFilter = require('../../../utils/conditionFilter.js');

module.exports = function (label, condition = [], isServiceProvider = false) {
  const view = isServiceProvider ? where.compliance.serviceProvider.viewWithNist : where.compliance.viewWithNist;
  return `SELECT * FROM (select label,
CASE when sum(weighted_count_by_rating)::NUMERIC != 0 then (round((sum(weighted_risk_by_rating)/sum(weighted_count_by_rating))::NUMERIC, 2) ) ELSE 0 END as raw_weighted_risk
-- CASE when sum(weighted_count_by_rating)::NUMERIC != 0 then name ELSE 'None' END as severity
from
(select label,name, risk_weight , risk_used_for_calc , mod_rollup ,(risk_weight * risk_used_for_calc * mod_rollup)/100 as weighted_risk_by_rating,
(risk_weight * mod_rollup)/100::FLOAT as weighted_count_by_rating
from
(

select label,name, risk_used_for_calc,risk_weight, straight_count,cap_count,
CASE
WHEN (name = 'Low') THEN cap_rollup::integer
WHEN (name = 'Medium') THEN cap_rollup::integer
WHEN (name = 'High') THEN cap_rollup::integer
 WHEN (name = 'Critical') THEN (straight_count + LAG(cap_rollup) OVER w)::integer
END as cap_rollup,
CASE
WHEN (name = 'Low') THEN mod_rollup::integer
WHEN (name = 'Medium') THEN mod_rollup::integer
WHEN (name = 'High') THEN mod_rollup::integer
WHEN (name = 'Critical') THEN (straight_count + LAG(cap_rollup) OVER w)::integer
END as mod_rollup
from
(
select label, name, risk_used_for_calc,risk_weight, straight_count,cap_count,
CASE
WHEN (name = 'Low') THEN cap_rollup
WHEN (name = 'Medium') THEN cap_rollup
WHEN ((name = 'High') and (cap_count != 0)) THEN (straight_count + LAG(cap_rollup) OVER w)/cap_count
WHEN ((name = 'Critical') and (cap_count != 0)) THEN (straight_count + LAG(cap_rollup) OVER w)/cap_count
ELSE 0
END as cap_rollup,
CASE
WHEN (name = 'Low') THEN mod_rollup
WHEN (name = 'Medium') THEN mod_rollup
WHEN ((name = 'High') and (cap_count != 0))  THEN MOD((straight_count + LAG(cap_rollup) OVER w), cap_count)
WHEN ((name = 'Critical') and (cap_count != 0))  THEN MOD((straight_count + LAG(cap_rollup) OVER w), cap_count)
ELSE 0
END as mod_rollup
from
(
select label, name, risk_used_for_calc,risk_weight, straight_count,cap_count,
CASE
WHEN (name = 'Low') THEN cal_q
WHEN ((name = 'Medium') and (cap_count != 0))  THEN (straight_count +coalesce(LAG(cal_q) OVER w,0))/cap_count
WHEN ((name = 'High') and (cap_count != 0))  THEN (straight_count + coalesce(LAG(cal_q) OVER w,0))/cap_count
WHEN ((name = 'Critical') and (cap_count != 0))  THEN (straight_count + coalesce(LAG(cal_q) OVER w,0))/cap_count
ELSE 0
END as cap_rollup,
CASE
WHEN (name = 'Low') THEN cal_m
WHEN ((name = 'Medium') and (cap_count != 0))  THEN MOD((straight_count + coalesce(LAG(cal_q) OVER w,0)), cap_count)
WHEN ((name = 'High') and (cap_count != 0))  THEN MOD((straight_count + coalesce(LAG(cal_q) OVER w,0)), cap_count)
WHEN ((name = 'Critical') and (cap_count != 0))  THEN MOD((straight_count + coalesce(LAG(cal_q) OVER w,0)), cap_count)
ELSE 0
END as mod_rollup
from
(select label, name,risk_used_for_calc,risk_weight, straight_count,cap_count,
 CASE WHEN cap_count != 0 THEN div(straight_count,cap_count) ELSE 0 END as cal_q,
 CASE WHEN cap_count != 0 THEN mod(straight_count,cap_count) ELSE 0 END as cal_m
from
(select n.label, n.id, n.name,coalesce(risk_weight,0) as risk_weight, coalesce(cap_count,0) as cap_count,
coalesce(risk_used_for_calc,0) as risk_used_for_calc, coalesce(straight_count,0) as straight_count
from
(select id,label, concat(label,id) as idloc, comp_score.straight_count, comp_score.name, score as risk_used_for_calc,risk_weight,cap_count
from
(select ${label} as label, count (dc.id) as straight_count,lower(severity) as name,
 case when lower(severity)='low' then 2 when lower(severity)='medium' then 5.5
      when lower(severity)='high' then 8 when lower(severity)='critical' then 9.5  end as score from
${view} dc
join xccdf_rules x on dc.rule_id = x.rule_id
${whereCondition(...conditionFilter(['source', 'asset_type', 'application_grp_name', 'result', 'application_name', 'asset_name', 'location_name', 'vmid', 'organization_name'], condition),
    `dc.rule_id=x.rule_id`,
    where.compliance.resultFailFilter
  )} 
group by label, lower(severity) order by label) as comp_score right join priorities p on comp_score.name = lower(p.name))
as inner_group
full join (select concat(label,id) as idloc, label, name, id from priorities p1,
(select distinct ${label} as label from ${view} z) as rm1) n
on (inner_group.idloc = n.idloc)
order by label, id desc  )
as interim_values
) as final_no
  WINDOW w AS (ROWS BETWEEN 1 PRECEDING AND CURRENT ROW)
  ) as final_no1
  WINDOW w AS (ROWS BETWEEN 1 PRECEDING AND CURRENT ROW)
  ) as final_no2
WINDOW w AS (ROWS BETWEEN 1 PRECEDING AND CURRENT ROW)
) as final_no3
WINDOW w AS (ROWS BETWEEN 1 PRECEDING AND CURRENT ROW)
) as final where label is not NULL
group by label) as cs WHERE cs.raw_weighted_risk != 0`;
};
