const where = require('./common');
const whereCondition = require('../../utils/whereParser.js');
const conditionFilter = require('../../utils/conditionFilter');
const logger = require('./../../utils/logger').logger.child({

  sub_name: 'IdentityService-compliance.js'
});
const _ = require('lodash');
module.exports = [
  {
    name: 'defaultPolicyCountWidget',
    route: '/distribution/counts',
    sql: {
      policyCount(condition, selector, date) {
        return `select count(distinct security_policy) from network_policy_view_table ${whereCondition(
          ...conditionFilter(condition),
          `(security_policy<>'none')`,
          `((vmid in (select vmid from assets where ${where.common.orgChainFilter}) 
          or ((vmid = 'UNKNOWN') and (network_repo_org_id in (select organization_id from assets where ${where.common.orgChainFilter})))
          or ((vmid = 'ANY') and (organization_name='ANY') and (organization_id is null))
          ))`
        )} `;
      },
      allowedPolicyCount: function (condition, selector, date) {
        return `select count(distinct security_policy) from network_policy_view_table ${whereCondition(
          ...conditionFilter(condition),
          `action = 'allow'`,
          `(security_policy<>'none')`,
          `((vmid in (select vmid from assets where ${where.common.orgChainFilter}) 
          or ((vmid = 'UNKNOWN') and (network_repo_org_id in (select organization_id from assets where ${where.common.orgChainFilter})))
          or ((vmid = 'ANY') and (organization_name='ANY') and (organization_id is null))
          ))`
        )} `;
      },
      blockedPolicyCount: function (condition, selector, date) {
        return `select count(distinct security_policy) from network_policy_view_table ${whereCondition(
          ...conditionFilter(condition),
          `((action = 'deny') or (action = 'block'))`,
          `(security_policy<>'none')`,
          `((vmid in (select vmid from assets where ${where.common.orgChainFilter}) 
          or ((vmid = 'UNKNOWN') and (network_repo_org_id in (select organization_id from assets where ${where.common.orgChainFilter})))
          or ((vmid = 'ANY') and (organization_name='ANY') and (organization_id is null))
          ))`
        )} `;
      },
      sourcePortCount: function (condition, selector, date) {
        return `select count(distinct source_port) from network_policy_view_table ${whereCondition(
          ...conditionFilter(condition),
          `(source_port<>'none')`,
          `((vmid in (select vmid from assets where ${where.common.orgChainFilter}) 
          or ((vmid = 'UNKNOWN') and (network_repo_org_id in (select organization_id from assets where ${where.common.orgChainFilter})))
          or ((vmid = 'ANY') and (organization_name='ANY') and (organization_id is null))
          ))`
        )}`;

      },
      incomingInternetRuleCount: function (condition, selector, date) {
        return `select count(distinct rule_id) from network_policy_view_table ${whereCondition(
          ...conditionFilter(condition),
          `(rule_direction='INCOMING')`,
          `(action='allow')`,
          `((source_name='ANY' or source_name='ANY_IPV4' or source_name='ANY_IPV6') or not (source_name='none' or try_cast_inet(source_name, null) is null or try_cast_cidr(source_name, null) is null or source_name::cidr << '10.0.0.0/8' or source_name::cidr << '172.16.0.0/12' or source_name::cidr << '192.168.0.0/16' or source_name::cidr << '127.0.0.0/8' or source_name::cidr << '169.254.0.0/16' or source_name::cidr << 'fd00::/8'))`,
          `((vmid in (select vmid from assets where ${where.common.orgChainFilter}) 
          or ((vmid = 'UNKNOWN') and (network_repo_org_id in (select organization_id from assets where ${where.common.orgChainFilter})))
          or ((vmid = 'ANY') and (organization_name='ANY') and (organization_id is null))
          ))`
        )}`;

      },
      destinationPortCount: function (condition, selector, date) {
        return `select count(distinct destination_port) from network_policy_view_table ${whereCondition(
          ...conditionFilter(condition),
          `(destination_port<>'none')`,
          `((vmid in (select vmid from assets where ${where.common.orgChainFilter}) 
          or ((vmid = 'UNKNOWN') and (network_repo_org_id in (select organization_id from assets where ${where.common.orgChainFilter})))
          or ((vmid = 'ANY') and (organization_name='ANY') and (organization_id is null))
          ))`
        )}`;

      },
      firewallCount: function (condition, selector, date) {
        return `select count(distinct rule_id) from network_policy_view_table ${whereCondition(
          ...conditionFilter(condition),
          `(rule_id <>(-1))`,
          `((vmid in (select vmid from assets where ${where.common.orgChainFilter}) 
          or ((vmid = 'UNKNOWN') and (network_repo_org_id in (select organization_id from assets where ${where.common.orgChainFilter})))
          or ((vmid = 'ANY') and (organization_name='ANY') and (organization_id is null))
          ))`
        )}`;
      },
      assetsCount: function (condition, selector, date) {
        return `select count(distinct vmid) from assets ${whereCondition(
          ...conditionFilter(condition),
          where.common.orgChainFilter,
          `(vmid is not null)`,
          `(is_active='enabled' or is_active='true')`
        )}`;
      },
      assetsNoPolicyCount: function (condition, selector, date) {
        return `select count(distinct id) from assets ${whereCondition(
          ...conditionFilter(condition),
          where.common.orgChainFilter,
          `(vmid is not null)`,
          `(is_active='enabled' or is_active='true')`,
          `(vmid not in (select distinct vmid from network_policy_view_table where security_policy<>'none'))`
        )}`;
      }
    },
    postStages: [],

    expected_params: ['orgId']
  },
  {
    name: 'defaultPolicyCountWidget',
    route: '/distribution/counts/tabular',
    sql: {
      policyCount(condition, selector, date) {
        return `select *, 
                asset_name as "Asset Name",
                rule_id as "Rule Id",
                rule_name as "Rule Name",
                action as "Action",
                security_policy as "Security Policy",
                source_group as "Source Group",
                source_name as "Source Asset",
                source as source_vmid,
                source_port as "Source Port",
                destination_group as "Destination Group",
                destination_name as "Destination Asset",
                destination as destination_vmid,
                destination_port as "Destination Port",
                network_repo_type as "Network Repo Type",
                network_repo_org_id as "Organization Id"
                from network_policy_view_table  ${whereCondition(
          ...conditionFilter(condition),
          `(security_policy<>'none')`,
          `((vmid in (select vmid from assets where ${where.common.orgChainFilter}) 
          or ((vmid = 'UNKNOWN') and (network_repo_org_id in (select organization_id from assets where ${where.common.orgChainFilter})))
          or ((vmid = 'ANY') and (organization_name='ANY') and (organization_id is null))
          ))`
        )}`;
      },
      allowedPolicyCount: function (condition, selector, date) {
        return `select * ,
        asset_name as "Asset Name",
        rule_id as "Rule Id",
        rule_name as "Rule Name",
        action as "Action",
        security_policy as "Security Policy",
        source_group as "Source Group",
        source_name as "Source Asset",
        source as source_vmid,
        source_port as "Source Port",
        destination_group as "Destination Group",
        destination_name as "Destination Asset",
        destination as destination_vmid,
        destination_port as "Destination Port",
        network_repo_type as "Network Repo Type",
        network_repo_org_id as "Organization Id"
        from network_policy_view_table  ${whereCondition(
          ...conditionFilter(condition),
          `action = 'allow'`,
          `(security_policy<>'none')`,
          `((vmid in (select vmid from assets where ${where.common.orgChainFilter}) 
          or ((vmid = 'UNKNOWN') and (network_repo_org_id in (select organization_id from assets where ${where.common.orgChainFilter})))
          or ((vmid = 'ANY') and (organization_name='ANY') and (organization_id is null))
          ))`
        )}`;
      },
      blockedPolicyCount: function (condition, selector, date) {
        return `select * ,
        asset_name as "Asset Name",
        rule_id as "Rule Id",
        rule_name as "Rule Name",
        action as "Action",
        security_policy as "Security Policy",
        source_group as "Source Group",
        source_name as "Source Asset",
        source as source_vmid,
        source_port as "Source Port",
        destination_group as "Destination Group",
        destination_name as "Destination Asset",
        destination as destination_vmid,
        destination_port as "Destination Port",
        network_repo_type as "Network Repo Type",
        network_repo_org_id as "Organization Id"
        from network_policy_view_table  ${whereCondition(
          ...conditionFilter(condition),
          `((action = 'deny') or (action = 'block'))`,
          `(security_policy<>'none')`,
          `((vmid in (select vmid from assets where ${where.common.orgChainFilter}) 
          or ((vmid = 'UNKNOWN') and (network_repo_org_id in (select organization_id from assets where ${where.common.orgChainFilter})))
          or ((vmid = 'ANY') and (organization_name='ANY') and (organization_id is null))
          ))`
        )}`;
      },
      sourcePortCount: function (condition, selector, date) {
        return `select * ,
        asset_name as "Asset Name",
        rule_id as "Rule Id",
        rule_name as "Rule Name",
        action as "Action",
        security_policy as "Security Policy",
        source_group as "Source Group",
        source_name as "Source Asset",
        source as source_vmid,
        source_port as "Source Port",
        destination_group as "Destination Group",
        destination_name as "Destination Asset",
        destination as destination_vmid,
        destination_port as "Destination Port",
        network_repo_type as "Network Repo Type",
        network_repo_org_id as "Organization Id"
        from network_policy_view_table  ${whereCondition(
          ...conditionFilter(condition),
          `(source_port<>'none')`,
          `((vmid in (select vmid from assets where ${where.common.orgChainFilter}) 
          or ((vmid = 'UNKNOWN') and (network_repo_org_id in (select organization_id from assets where ${where.common.orgChainFilter})))
          or ((vmid = 'ANY') and (organization_name='ANY') and (organization_id is null))
          ))`
        )}`;

      },
      incomingInternetRuleCount: function (condition, selector, date) {
        return `select * ,
        asset_name as "Asset Name",
        rule_id as "Rule Id",
        rule_name as "Rule Name",
        action as "Action",
        security_policy as "Security Policy",
        source_group as "Source Group",
        source_name as "Source Asset",
        source as source_vmid,
        source_port as "Source Port",
        destination_group as "Destination Group",
        destination_name as "Destination Asset",
        destination as destination_vmid,
        destination_port as "Destination Port",
        network_repo_type as "Network Repo Type",
        network_repo_org_id as "Organization Id"
        from network_policy_view_table  ${whereCondition(
          ...conditionFilter(condition),
          `(rule_direction='INCOMING')`,
          `(action='allow')`,
          `((source_name='ANY' or source_name='ANY_IPV4' or source_name='ANY_IPV6') or not (source_name='none' or try_cast_inet(source_name, null) is null or source_name::cidr << '10.0.0.0/8' or source_name::cidr << '172.16.0.0/12' or source_name::cidr << '192.168.0.0/16' or source_name::cidr << '127.0.0.0/8' or source_name::cidr << '169.254.0.0/16' or source_name::cidr << 'fd00::/8'))`,
          `((vmid in (select vmid from assets where ${where.common.orgChainFilter}) 
          or ((vmid = 'UNKNOWN') and (network_repo_org_id in (select organization_id from assets where ${where.common.orgChainFilter})))
          or ((vmid = 'ANY') and (organization_name='ANY') and (organization_id is null))
          ))`
        )}`;
      },
      destinationPortCount: function (condition, selector, date) {
        return `select * ,
        asset_name as "Asset Name",
        rule_id as "Rule Id",
        rule_name as "Rule Name",
        action as "Action",
        security_policy as "Security Policy",
        source_group as "Source Group",
        source_name as "Source Asset",
        source as source_vmid,
        source_port as "Source Port",
        destination_group as "Destination Group",
        destination_name as "Destination Asset",
        destination as destination_vmid,
        destination_port as "Destination Port",
        network_repo_type as "Network Repo Type",
        network_repo_org_id as "Organization Id"
        from network_policy_view_table  ${whereCondition(
          ...conditionFilter(condition),
          `(destination_port<>'none')`,
          `((vmid in (select vmid from assets where ${where.common.orgChainFilter}) 
          or ((vmid = 'UNKNOWN') and (network_repo_org_id in (select organization_id from assets where ${where.common.orgChainFilter})))
          or ((vmid = 'ANY') and (organization_name='ANY') and (organization_id is null))
          ))`
        )}`;

      },
      firewallCount: function (condition, selector, date) {
        return `select * ,
        asset_name as "Asset Name",
        rule_id as "Rule Id",
        rule_name as "Rule Name",
        action as "Action",
        security_policy as "Security Policy",
        source_group as "Source Group",
        source_name as "Source Asset",
        source as source_vmid,
        source_port as "Source Port",
        destination_group as "Destination Group",
        destination_name as "Destination Asset",
        destination as destination_vmid,
        destination_port as "Destination Port",
        network_repo_type as "Network Repo Type",
        network_repo_org_id as "Organization Id"
        from network_policy_view_table  ${whereCondition(
          ...conditionFilter(condition),
          `(rule_id <>(-1))`,
          `((vmid in (select vmid from assets where ${where.common.orgChainFilter}) 
          or ((vmid = 'UNKNOWN') and (network_repo_org_id in (select organization_id from assets where ${where.common.orgChainFilter})))
          or ((vmid = 'ANY') and (organization_name='ANY') and (organization_id is null))
          ))`
        )}`;
      },
      assetsCount: function (condition, selector, date) {
        return `select distinct *, 
        a.name as "Asset Name",
        CASE when npv.rule_id is null then (-1) else npv.rule_id END as "Rule Id",
        CASE when npv.rule_name is null then 'none' else npv.rule_name END as "Rule Name",
        CASE when npv.action is null then 'none' else npv.action END as "Action",
        CASE when npv.security_policy is null then 'none' else npv.security_policy END as "Security Policy",
        CASE when npv.source_group is null then 'none' else npv.source_group END as "Source Group",
        CASE when npv.source_name is null then 'none' else npv.source_name END as "Source Asset",
        CASE when npv.source is null then 'none' else npv.source END as source_vmid,
        CASE when npv.source_port is null then 'none' else npv.source_port END as "Source Port",
        CASE when npv.destination_group is null then 'none' else npv.destination_group END as "Destination Group",
        CASE when npv.destination_name is null then 'none' else npv.destination_name END as "Destination Asset",
        CASE when npv.destination is null then 'none' else npv.destination END as destination_vmid,
        CASE when npv.destination_port is null then 'none' else npv.destination_port END as "Destination Port"
        from assets a left join network_policy_view_table npv on npv.vmid=a.vmid ${whereCondition(
          ...conditionFilter(condition),
          `a.organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id)`,
          `(a.vmid is not null)`,
          `(a.is_active='enabled' or a.is_active='true')`
        )}`;
      },
      assetsNoPolicyCount: function (condition, selector, date) {
        return `select name        as asset_name,
                                  vmid,
                                  (-1)              as ruleId,
                                  'none'            as ruleName,
                                  'none'            as action,
                                  'none'            as securityPolicy,
                                  'none'            as sourceGroup,
                                  'none'            as source,
                                  'none'            as source_name,
                                  'none'            as sourcePort,
                                  'none'            as destinationGroup,
                                  'none'            as destination,
                                  'none'            as destination_name,
                                  'none'            as destinationPort,
                                  'none'            as application,
                                  'none'            as destination_asset,
                                  'none'            as source_asset,
                                  0                 as risk_priority,
                                  0                 as compliance_priority,
                                            name    as "Asset Name",
                                            'none' as "Rule Id",
                                            'none' as "Rule Name",
                                            'none' as "Action",
                                            'none' as "Security Policy",
                                            'none' as "Source Group",
                                            'none' as "Source Asset",
                                            'none' as source_vmid,
                                            'none' as "Source Port",
                                            'none' as "Destination Group",
                                            'none' as "Destination Asset",
                                            'none' as destination_vmid,
                                            'none' as "Destination Port"
                           from assets ${whereCondition(
          ...conditionFilter(condition),
          where.common.orgChainFilter,
          `(vmid is not null)`,
          `(is_active='enabled' or is_active='true')`,
          `(vmid not in (select distinct vmid from network_policy_view_table where security_policy<>'none'))`
        )}`;
      }
    },
    postStages: [
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Security Policy', path: 'policy_name' },
          { label: 'Rule Name', path: 'dfw_name' },
          { label: 'Asset Name', path: 'asset_name' },
          { label: 'Source Group', path: 'security_group_name' },
          { label: 'Direction', path: 'dfw_direction' },
          { label: 'Destination Group', path: 'dfw_other_security_tag' },
          { label: 'Destination Port', path: 'dfw_other_port' },
          { label: 'Action', path: 'dfw_action' },
          { label: 'Source Asset', path: 'asset_name' },
          { label: 'Destination Asset', path: 'dfw_other_asset' }
        ]
      }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'topTenPolicyCount',
    route: '/topTenPolicyCount',
    sql: {
      default: function (condition, selector, date) {
        return `select security_policy as policy_name, count(distinct vmid) from network_policy_view_table ${whereCondition(
          ...conditionFilter(condition),
          `(security_policy<>'none')`,
          `((vmid in (select vmid from assets where ${where.common.orgChainFilter}) 
          or ((vmid = 'UNKNOWN') and (network_repo_org_id in (select organization_id from assets where ${where.common.orgChainFilter})))
          or ((vmid = 'ANY') and (organization_name='ANY') and (organization_id is null))
          ))`
        )} group by security_policy order by count(distinct vmid) desc`;
      }
    },
    postStages: [
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Security Policy', path: 'policy_name' },
          { label: 'Rule Name', path: 'dfw_name' },
          { label: 'Asset Name', path: 'asset_name' },
          { label: 'Source Group', path: 'security_group_name' },
          { label: 'Direction', path: 'dfw_direction' },
          { label: 'Destination Group', path: 'dfw_other_security_tag' },
          { label: 'Destination Port', path: 'dfw_other_port' },
          { label: 'Action', path: 'dfw_action' },
          { label: 'Source Asset', path: 'asset_name' },
          { label: 'Destination Asset', path: 'dfw_other_asset' }

        ]
      }
    ]
  },
  {
    name: 'topTenPolicyCount',
    route: '/topTenPolicyCount/tabular',
    sql: {
      default: function (condition, selector, date) {
        return `select *, 
                asset_name as "Asset Name",
                rule_id as "Rule Id",
                rule_name as "Rule Name",
                action as "Action",
                security_policy as "Security Policy",
                source_group as "Source Group",
                source_name as "Source Asset",
                source as source_vmid,
                source_port as "Source Port",
                destination_group as "Destination Group",
                destination_name as "Destination Asset",
                destination as destination_vmid,
                destination_port as "Destination Port"
                from network_policy_view_table  ${whereCondition(
          ...conditionFilter(condition),
          `(security_policy<>'none')`,
          `((vmid in (select vmid from assets where ${where.common.orgChainFilter}) 
          or ((vmid = 'UNKNOWN') and (network_repo_org_id in (select organization_id from assets where ${where.common.orgChainFilter})))
          or ((vmid = 'ANY') and (organization_name='ANY') and (organization_id is null))
          ))`
        )}`;
      }
    },
    postStages: [
      { type: 'setData' },

      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Security Policy', path: 'policy_name' },
          { label: 'Rule Name', path: 'dfw_name' },
          { label: 'Asset Name', path: 'asset_name' },
          { label: 'Source Group', path: 'security_group_name' },
          { label: 'Direction', path: 'dfw_direction' },
          { label: 'Destination Group', path: 'dfw_other_security_tag' },
          { label: 'Destination Port', path: 'dfw_other_port' },
          { label: 'Action', path: 'dfw_action' },
          { label: 'Source Asset', path: 'asset_name' },
          { label: 'Destination Asset', path: 'dfw_other_asset' }

        ]
      }
    ]
  },
  {
    name: 'firewallPoliciesByApplication',
    route: '/firewallPoliciesByApplication',
    sql: {
      default: function (condition, selector, date) {
        return `select application, count(distinct policy_id) from network_policy_view_table ${whereCondition(
          ...conditionFilter(condition),
          `(application<>'none')`,
          `((vmid in (select vmid from assets where ${where.common.orgChainFilter}) 
          or ((vmid = 'UNKNOWN') and (network_repo_org_id in (select organization_id from assets where ${where.common.orgChainFilter})))
          or ((vmid = 'ANY') and (organization_name='ANY') and (organization_id is null))
          ))`
        )} group by application order by count(distinct policy_id) desc`;
      }
    },
    postStages: [
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Security Policy', path: 'policy_name' },
          { label: 'Rule Name', path: 'dfw_name' },
          { label: 'Asset Name', path: 'asset_name' },
          { label: 'Source Group', path: 'security_group_name' },
          { label: 'Direction', path: 'dfw_direction' },
          { label: 'Destination Group', path: 'dfw_other_security_tag' },
          { label: 'Destination Port', path: 'dfw_other_port' },
          { label: 'Action', path: 'dfw_action' },
          { label: 'Source Asset', path: 'asset_name' },
          { label: 'Destination Asset', path: 'dfw_other_asset' }

        ]
      }
    ]
  },
  {
    name: 'firewallPoliciesByApplication',
    route: '/firewallPoliciesByApplication/tabular',
    sql: {
      default: function (condition, selector, date) {
        return `select *, 
                asset_name as "Asset Name",
                rule_id as "Rule Id",
                rule_name as "Rule Name",
                action as "Action",
                security_policy as "Security Policy",
                source_group as "Source Group",
                source_name as "Source Asset",
                source as source_vmid,
                source_port as "Source Port",
                destination_group as "Destination Group",
                destination_name as "Destination Asset",
                destination as destination_vmid,
                destination_port as "Destination Port"
                from network_policy_view_table  ${whereCondition(
          ...conditionFilter(condition),
          `(application<>'none')`,
          `((vmid in (select vmid from assets where ${where.common.orgChainFilter}) 
          or ((vmid = 'UNKNOWN') and (network_repo_org_id in (select organization_id from assets where ${where.common.orgChainFilter})))
          or ((vmid = 'ANY') and (organization_name='ANY') and (organization_id is null))
          ))`
        )}`;
      }
    },
    postStages: [
      { type: 'setData' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Security Policy', path: 'policy_name' },
          { label: 'Rule Name', path: 'dfw_name' },
          { label: 'Asset Name', path: 'asset_name' },
          { label: 'Source Group', path: 'security_group_name' },
          { label: 'Direction', path: 'dfw_direction' },
          { label: 'Destination Group', path: 'dfw_other_security_tag' },
          { label: 'Destination Port', path: 'dfw_other_port' },
          { label: 'Action', path: 'dfw_action' },
          { label: 'Source Asset', path: 'asset_name' },
          { label: 'Destination Asset', path: 'dfw_other_asset' }

        ]
      }
    ]
  },
  {
    name: 'policyTabularData',
    route: '/policies/tabular',
    sql: {
      default: function (condition, selector, date) {
        return `select distinct * from network_policy_view_table ${whereCondition(...conditionFilter(condition), where.common.orgChainFilter)}`;
      }
    }
  }
];
