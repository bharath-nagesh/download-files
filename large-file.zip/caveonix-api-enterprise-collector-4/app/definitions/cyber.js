const where = require('./common');
const whereCondition = require('../../utils/whereParser.js');
const conditionFilter = require('../../utils/conditionFilter');
const _ = require('lodash');
const cyberScore = require('./scoringModules/cyberScore.view');

const logger = require('./../../utils/logger').logger.child({

  sub_name: 'IdentityService-compliance.js'
});
module.exports = [
  {
    name: 'getApplicationView',
    route: '/getRiskScore/',
    sql: {
      default: function (condition, selector, date) {
        return 'select l.name as location, hp.name as hosting_provider, at.name as application_grp_name, pg.name as application_name, a.name as asset_name,avnd.network_ip , avnd.network, a.macaddress, pg.sequence_num from application_tags at, assets a, sub_applications pg, sub_application_members psm, sub_application_asset_members pgam, asset_vm_network_details avnd, locations l , hosting_providers hp, asset_details ad where a.organization_id = at.organization_id and a.organization_id = :orgId and pg.id = psm.policy_group_id and psm.source_id = at.id and pg.id = pgam.policy_group_id and pgam.asset_id = a. id and avnd.asset_id = a.id and a.id = ad.asset_id and ad.location_id = l.id and ad.hosting_provider_id = hp.id;';

      },
      percentChange: function (condition, selector) {
        return `select 100 * ( -1+1/(p_score::float/count)::numeric/((select p_score::float/count as score from (select sum(cast (score as float)) as p_score, count(dr.id) from ${where.cyber.view} dr, organizations o, application_tags at where dr.created_at::DATE in (select max(created_at::DATE) -1 from daily_scan_results where scan_type like '%vul%' group by asset_id ) and dr.organization_id = o.id and dr.application_grp_id = at.id and dr.id in (select id from assets where (is_active='enabled' or is_active='true' or is_active='disabled') and organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id) ) ) as y))) as percent_change from (select sum(cast (score as float)) as p_score, count(dr.id) from ${where.cyber.view} dr, organizations o, application_tags at where date_trunc('hour', dr.created_at) in (select max(date_trunc('hour', created_at)) from daily_scan_results group by asset_id ) and dr.organization_id = o.id and dr.application_grp_id = at.id and dr.id in (select id from assets where (is_active='enabled' or is_active='true' or is_active='disabled') and organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id) ) ) as t`;
      }
    },
    postStages: [
      {
        type: 'setData'
      },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'application_grp_name' },
          { label: 'Sub-Application', path: 'application_name' },
          { label: 'Asset', path: 'asset_name' },
          { label: 'Location', path: 'location' },
          { label: 'CVE Id', path: 'cve' }
        ]
      }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'cveTopFiveWidget',
    route: '/cveTopFive',
    whereTransform: {
      org: {
        apply: true,
        mapping: {
          asset_type: 'asset_type',
          type: 'asset_type',
          vulnerability_type: 'vulnerability_type',
          location: 'location',
          application_grp_name: 'application_grp_name',
          asset_name: 'asset_name'
        }
      }
    },
    sql: {
      default: function (condition, selector, date) {
        return `select n.organization as id, p.name , count(distinct cve_id) from (select distinct d.id, d.score, d.organization, cve_id from ${where.cyber.view} as d, (select created_at::DATE,id, sum(score::float) as total_score, sum(case when result='false' then score::float end) as risk_score from ${where.cyber.view} dr
         ${whereCondition(...conditionFilter(condition),
          where.cyber.createdAtRiskFilter, where.cyber.riskViewAssetIdInOrgChainFilter
        )} group by id,created_at::DATE order by risk_score desc limit 10 ) as t where d.created_at::DATE = t.created_at and d.id = t.id ) as n join priorities p on n.score::float <= p.max_value and n.score::float >= p.min_value group by n.organization, p.name order by name, count desc limit 40`;
      },
      location: function (condition, selector, date) {
        return `select n.location ,p.name , count(cve_id) from (select distinct dr.cve_id, dr.score, dr.location,dr.asset_name as "Asset",dr.application_name as "Sub-Application",
        dr.id from ${where.cyber.view} as dr ${whereCondition(...conditionFilter(condition), where.cyber.createdAtRiskFilter, where.cyber.riskViewAssetIdInOrgChainFilter)}
        )as n join priorities p on n.score::numeric <= p.max_value::float and n.score::numeric >= p.min_value::float group by n.location, p.name order by name, count desc limit 40`;
      },
      appGroup: function (condition, selector, date) {
        return `select n.application_grp_name ,p.name , count(cve_id) from(select distinct dr.cve_id, dr.score, dr.location,dr.asset_name as "Asset",dr.application_name as "Sub-Application",dr.application_grp_name ,
        dr.id from ${where.cyber.view} as dr ${whereCondition(...conditionFilter(condition), where.cyber.createdAtRiskFilter, where.cyber.riskViewAssetIdInOrgChainFilter)}
        )as n join priorities p on n.score::numeric <= p.max_value::float and n.score::numeric >= p.min_value::float group by n.application_grp_name, p.name order by name, count desc limit 40`;
      },
      application: function (condition, selector, date) {
        return `select n.application_name ,p.name , count(cve_id) from(select distinct dr.cve_id, dr.score, dr.location,dr.asset_name as "Asset",dr.application_name ,dr.application_grp_name ,dr.organization_name as organization,
        dr.id from ${where.cyber.view} as dr ${whereCondition(...conditionFilter(condition), where.cyber.createdAtRiskFilter, where.cyber.riskViewAssetIdInOrgChainFilter)}
        )as n join priorities p on n.score::numeric <= p.max_value::float and n.score::numeric >= p.min_value::float group by n.application_name, p.name order by name, count desc limit 40`;
      },
      org: function (condition, selector, date) {
        return `select n.organization ,p.name , count(cve_id) from(select distinct dr.cve_id, dr.score, dr.location,dr.asset_name as "Asset",
        dr.application_name as "Sub-Application",dr.application_grp_name ,
        dr.organization_name as organization,
        dr.id from ${where.cyber.view} as dr ${whereCondition(...conditionFilter(condition), where.cyber.createdAtRiskFilter, where.cyber.riskViewAssetIdInOrgChainFilter)}
        )as n join priorities p on n.score::numeric <= p.max_value::float and n.score::numeric >= p.min_value::float group by n.organization, p.name order by name, count desc limit 40`;
      }
    },
    expected_params: ['orgId']
  },
  {
    name: 'cveTopFiveWidget',
    route: '/cveTopFive/temporal',
    sql: {
      default: function (condition, selector, date) {

        return `select n.organization as id, p.name , count(distinct cve_id) from (select distinct d.id, ((d.score::numeric+((CASE WHEN d.bai_value = 'Critical' then 9.5 WHEN d.bai_value = 'High' then 8 WHEN d.bai_value = 'Medium' 
        THEN 3 WHEN d.bai_value = 'Low' THEN 2 ELSE 1 END))::numeric+d.impact_level::numeric)/3)::numeric as score, d.organization, cve_id from ${where.cyber.view} as d, (select created_at::DATE,id, sum(score::float) as total_score, sum(case when result='false' then score::float end) as risk_score from ${where.cyber.view} dr 
         ${whereCondition(...conditionFilter(condition),
          where.cyber.createdAtRiskFilter, where.cyber.riskViewAssetIdInOrgChainFilter
        )} group by id,created_at::DATE order by risk_score desc limit 10 ) as t where d.created_at::DATE = t.created_at and d.id = t.id ) as n join priorities p on n.score::float <= p.max_value and n.score::float >= p.min_value group by n.organization, p.name order by name, count desc limit 40`;
      },
      location: function (condition, selector, date) {

        return `select n.location as id, p.name , count(distinct cve_id) from (select distinct d.id, ((d.score::numeric+((CASE WHEN d.bai_value = 'Critical' then 9.5 WHEN d.bai_value = 'High' then 8 WHEN d.bai_value = 'Medium' 
        THEN 3 WHEN d.bai_value = 'Low' THEN 2 ELSE 1 END))::numeric+d.impact_level::numeric)/3)::numeric as score, d.location, cve_id from ${where.cyber.view} as d, (select created_at::DATE,id, sum(score::float) as total_score, sum(case when result='false' then score::float end) as risk_score from ${where.cyber.view} dr ${whereCondition(...conditionFilter(condition),
          where.cyber.createdAtRiskFilter, where.cyber.riskViewAssetIdInOrgChainFilter
        )} group by id,created_at::DATE order by risk_score desc limit 10 ) as t where d.created_at::DATE = t.created_at and d.id = t.id ) as n join priorities p on n.score::float <= p.max_value and n.score::float >= p.min_value group by n.location, p.name order by name, count desc limit 40`;
      },
      appGroup: function (condition, selector, date) {

        return `select n.application_grp_name as id, p.name , count(distinct cve_id) from (select distinct d.id, ((d.score::numeric+((CASE WHEN d.bai_value = 'Critical' then 9.5 WHEN d.bai_value = 'High' then 8 WHEN d.bai_value = 'Medium' 
        THEN 3 WHEN d.bai_value = 'Low' THEN 2 ELSE 1 END))::numeric+d.impact_level::numeric)/3)::numeric as score, d.application_grp_name, cve_id from ${where.cyber.view} as d, (select created_at::DATE,id, sum(score::float) as total_score, sum(case when result='false' then score::float end) as risk_score from ${where.cyber.view} dr ${whereCondition(...conditionFilter(condition),
          where.cyber.createdAtRiskFilter, where.cyber.riskViewAssetIdInOrgChainFilter
        )} group by id,created_at::DATE order by risk_score desc limit 10 ) as t where d.created_at::DATE = t.created_at and d.id = t.id ) as n join priorities p on n.score::float <= p.max_value and n.score::float >= p.min_value group by n.application_grp_name, p.name order by name, count desc limit 40`;
      },
      application: function (condition, selector, date) {

        return `select n.application_name as id, p.name , count(distinct cve_id) from (select distinct d.id,((d.score::numeric+((CASE WHEN d.bai_value = 'Critical' then 9.5 WHEN d.bai_value = 'High' then 8 WHEN d.bai_value = 'Medium' 
        THEN 3 WHEN d.bai_value = 'Low' THEN 2 ELSE 1 END))::numeric+d.impact_level::numeric)/3)::numeric as score, d.application_name, cve_id from ${where.cyber.view} as d, (select created_at::DATE,id, sum(score::float) as total_score, sum(case when result='false' then score::float end) as risk_score from ${where.cyber.view} dr ${whereCondition(...conditionFilter(condition),
          where.cyber.createdAtRiskFilter, where.cyber.riskViewAssetIdInOrgChainFilter
        )} group by id,created_at::DATE order by risk_score desc limit 10 ) as t where d.created_at::DATE = t.created_at and d.id = t.id ) as n join priorities p on n.score::float <= p.max_value and n.score::float >= p.min_value group by n.application_name, p.name order by name, count desc limit 40`;
      },
      org: function (condition, selector, date) {

        return `select n.organization as id, p.name , count(distinct cve_id) from (select distinct d.id, ((d.score::numeric+((CASE WHEN d.bai_value = 'Critical' then 9.5 WHEN d.bai_value = 'High' then 8 WHEN d.bai_value = 'Medium' 
        THEN 3 WHEN d.bai_value = 'Low' THEN 2 ELSE 1 END))::numeric+d.impact_level::numeric)/3)::numeric as score, d.organization, cve_id from ${where.cyber.view} as d, (select created_at::DATE,id, sum(score::float) as total_score, sum(case when result='false' then score::float end) as risk_score from ${where.cyber.view} dr ${whereCondition(...conditionFilter(condition),
          where.cyber.createdAtRiskFilter, where.cyber.riskViewAssetIdInOrgChainFilter
        )} group by id,created_at::DATE order by risk_score desc limit 10 ) as t where d.created_at::DATE = t.created_at and d.id = t.id ) as n join priorities p on n.score::float <= p.max_value and n.score::float >= p.min_value group by n.organization, p.name order by name, count desc limit 40`;
      }
    },
    expected_params: ['orgId']
  },

  {
    name: 'mostImpactedAssetsBySeverityWidget',
    route: '/mostImpactedAssetsBySeverity',
    whereTransform: {
      default: {
        apply: true,
        mapping: {
          asset_type: 'asset_type',
          type: 'asset_type',
          vulnerability_type: 'vulnerability_type',
          location: 'location',
          application_grp_name: 'application_grp_name',
          asset_name: 'asset_name'
        }
      }
    },
    sql: {
      default: function (condition, selector, date) {
        return `select asset_name, severity, count(distinct cve_id) from ${where.cyber.view} dr ${whereCondition(...conditionFilter(condition),
          where.cyber.createdAtRiskFilter, where.cyber.riskViewAssetIdInOrgChainFilter)} group by asset_name, severity order by severity, count desc limit 40`;
      }
    },
    expected_params: ['orgId']
  },
  {
    name: 'riskScore',
    route: '/risk',
    sql: {
      default: function (condition, selector, date) {
        return `select raw_weighted_risk as avg_risk_score from (${cyberScore('parent_org_id',condition)}) dr limit 1`;
      },
      count: function (condition, selector, date) {
        return `select count(cve_id) as avg_risk_score from ${where.cyber.view} dr ${whereCondition(
          where.cyber.createdAtRiskFilter,
          where.cyber.riskViewAssetIdInOrgChainFilter
        )}`;
      },
      total: function (condition, selector, date) {
        return `select sum(cast (score as float)) as total_risk_score from ${where.cyber.view} dr ${whereCondition(
          where.cyber.createdAtRiskFilter,
          where.cyber.riskViewAssetIdInOrgChainFilter
        )}`;
      },
      average: function (condition, selector, date) {
        return `select round(sum(cast (score as float))/count(cve_id), 2) as avg_risk_score from ${where.cyber.view} dr ${whereCondition(
          where.cyber.createdAtRiskFilter,
          where.cyber.riskViewAssetIdInOrgChainFilter
        )}`;
      }
    },
    expected_params: ['orgId']
  },
  {
    name: 'vulnerabilityTrendWidget',
    route: '/vulnerabilityTrend',
    sql: {
      default: function (condition, selector, date) {
        return `select created_at::DATE,count(*), sum(cast (score as float)) as total_risk_score from ${where.cyber.view} ${whereCondition(...conditionFilter(condition),
          where.cyber.createdAtRiskFilter, where.cyber.riskViewAssetIdInOrgChainFilter
        )} group by created_at::DATE;`;
      },
      closed: function (condition, selector, date) {
        return `select created_at::DATE,lag(sum(case when result='false' THEN 1 ELSE 0 END), 1) over (order by created_at::date) - sum(case when result='false' THEN 1 ELSE 0 END) as fixed from ${where.cyber.view} group by created_at::date`;
      },
      open: function (condition, selector, date) {
        return `select created_at::DATE,count(*), sum(cast (score as float)) as total_risk_score from ${where.cyber.viewTabular} dr ${whereCondition(...conditionFilter(condition),
          where.cyber.createdAtRiskFilter, where.cyber.riskViewAssetIdInOrgChainFilter
        )} group by created_at::DATE;`;
      },
      tabular: function (condition, selector, date) {
        return `select dr.id as asset_id, dr.asset_name as \"Asset\",dr.application_name as \"Sub-Application\",dr.application_grp_name as \"Application\",dr.organization_name as \"Organization\",dr.location \"Location\",network_ip as \"Network IP\",cve_id as \"CVE\",score as Score,result as Result,created_at::DATE as \"Created Date\",dr.realm AS "registeredName" ,dr.network_ip as ipAddress from ${where.cyber.viewTabular} dr ${whereCondition(
          where.cyber.createdAtRiskFilter,
          where.common.orgChainFilter,
          ...conditionFilter(condition)
        )} `;
      }
    },
    postStages: [
      { type: 'setData', contextCheck: 'selector', contextCheckValue: 'tabular' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'Application' },
          { label: 'Sub-Application', path: 'Sub-Application' },
          { label: 'Asset', path: 'Asset' },
          { label: 'Location', path: 'Location' },
          { label: 'CVE', path: 'CVE' },
          { label: 'Organization', path: 'Organization' }
        ]
      }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'cyberRiskHeatMapWidget',
    route: '/heatMap',
    sql: {
      default: function (condition, selector, date) {
        // `select * from ${where.cyber.view} dr ${whereCondition()}`
        return `select  o.vulnerability_type, p.name as severity,organization_name,source, location, application_grp_name, application_name, o.id,asset_name,round(CVE_risk_score::numeric,2)::float as CVE_risk_score, round((o.CVE_risk_score + o.impact_level::float + cast((CASE WHEN o.bai_value = 'Critical' then 9.5 WHEN o.bai_value = 'High' then 8 WHEN o.bai_value = 'Medium' then 5 WHEN o.bai_value = 'Low' THEN 2 ELSE 1 END) as float))::numeric/3,2)::float as temporal, round(o.CVE_risk_score::numeric,2)::float as residual,asset_type  from 
        (select dr.vulnerability_type,source,organization_name, location, application_grp_name, application_name, dr.id,asset_name, sum(cast (score as float))/count(cve_id) as CVE_risk_score, impact_level,bai_value,asset_type from 
       ${where.cyber.view} dr  ${whereCondition(
          ...conditionFilter(condition),
          where.cyber.createdAtRiskFilter,
          where.cyber.riskViewAssetIdInOrgChainFilter
        )} group by dr.vulnerability_type,source, organization_name,source, location, application_grp_name, application_name, dr.id,asset_name, impact_level,bai_value,asset_type order by CVE_risk_score desc) o join priorities p on o.CVE_risk_score <= p.max_value::float and o.CVE_risk_score >= p.min_value::float 
                 ${whereCondition(...conditionFilter(condition))}`;
      }
    },
    postStages: [
      { type: 'setData' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'application_grp_name' },
          { label: 'Sub-Application', path: 'application_name' },
          { label: 'Vulnerability-Type', path: 'vulnerability_type' },
          { label: 'Asset', path: 'asset_name' },
          { label: 'Location', path: 'location' },
          { label: 'Severity', path: 'severity' },
          { label: 'Organization', path: 'organization_name' },
          { label: 'Source', path: 'source' },
          { label: 'Asset Type', path: 'asset_type' }
        ]
      },
      { type: 'orderSeverity' }
    ],
    expected_params: ['orgId']
  },

  {
    name: 'cyberRiskHeatMapWidget',
    route: '/heatMap/temporal',
    sql: {
      default: function (condition, selector, date) {
        return `select score.raw_weighted_risk::float as temporal,score.raw_weighted_risk as residual, p.name as severity, dr.* from 
        (select vulnerability_type,source, organization_name,source, location, application_grp_name, application_name, id,asset_name, impact_level,bai_value,asset_type from 
        ${where.cyber.view} x ${whereCondition(...conditionFilter(condition))} group by vulnerability_type,organization_name, source,location, application_grp_name, application_name, asset_type, x.id,asset_name, impact_level,bai_value) dr
         join (${cyberScore('id', condition)}) score on dr.id = score.label
         join priorities p on score.raw_weighted_risk <= p.max_value::float and score.raw_weighted_risk >= p.min_value::float`;

      }
    },
    postStages: [
      { type: 'setData' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'application_grp_name' },
          { label: 'Sub-Application', path: 'application_name' },
          { label: 'Vulnerability-Type', path: 'vulnerability_type' },
          { label: 'Asset', path: 'asset_name' },
          { label: 'Location', path: 'location' },
          { label: 'Severity', path: 'severity' },
          { label: 'Organization', path: 'organization_name' },
          { label: 'Source', path: 'source' },
          { label: 'Asset Type', path: 'asset_type' }
        ]
      },
      { type: 'orderSeverity' }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'cyberRiskDeltaScore',
    route: '/deltaReport',
    sql: {
      default: function (condition, selector, date) {
        return `select created_date, total, failed, case when fixed < 0 THEN 0 ELSE fixed END from (select created_at::date as created_date, count(cve_id) total, sum(case when result='true' THEN 1 ELSE 0 END) as failed, lag(sum(case when result='true' THEN 1 ELSE 0 END), 1) over (order by created_at::date) - sum(case when result='true' THEN 1 ELSE 0 END) as fixed from ${where.cyber.view} dr ${whereCondition(
          where.cyber.createdAtRiskFilter,
          where.cyber.riskViewAssetIdInOrgChainFilter,
          ...conditionFilter(condition)
        )} group by 1 ) t limit 5`;
      },
      tabular: function (condition, selector, date) {
        return `select dr.vulnerability_type, dr.software ,dr.version, dr.id as asset_id,dr.asset_name as "Asset",dr.application_name as "Sub-Application",dr.application_grp_name as "Application",dr.organization_name as "Organization",dr.location "Location",dr.network_ip as "Network IP",cve_id as "CVE",score as Score,result as Result,created_at::DATE as "Created Date" from ${where.cyber.viewTabular} dr ${whereCondition(
          where.cyber.createdAtRiskFilter,
          where.cyber.riskViewAssetIdInOrgChainFilter,
          ...conditionFilter(condition)
        )}`;
      }
    },
    postStages: [
      { type: 'setData', contextCheck: 'selector', contextCheckValue: 'tabular' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'Application' },
          { label: 'Sub-Application', path: 'Sub-Application' },
          { label: 'Vulnerability-Type', path: 'vulnerability_type' },
          { label: 'Asset', path: 'Asset' },
          { label: 'Location', path: 'Location' },
          { label: 'CVE', path: 'CVE' },
          { label: 'Organization', path: 'Organization' }
        ]
      }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'distribution',
    route: '/distribution/percentChange',
    search_terms: ['cyberRisk tabular data'],
    sql: {
      temporal: function (condition, selector, date) {

        return `select 100*( 1 - (p_score::float/(3*count))::numeric/(select (p_score::float/(3*count)) as percent_change from (select sum(cast (score as float) * cast(at.impact_level as float)* cast((CASE WHEN dr.bai_value = 'Critical' then 9.5 WHEN dr.bai_value = 'High' then 8 WHEN dr.bai_value = 'Medium' then 5 WHEN dr.bai_value = 'Low' THEN 2 ELSE 1 END) as float)) as p_score, count(dr.id) from ${where.cyber.view} dr, organizations o, application_tags at where date_trunc('hour', dr.created_at) in (select max(date_trunc('hour', created_at)) from daily_scan_results group by asset_id ) and dr.organization_id = o.id and dr.application_grp_id = at.id and dr.id in (select id from assets where (is_active='enabled' or is_active='true' or is_active='disabled') and organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id))) as t)) as percent_change from (select sum(cast (score as float) * cast(at.impact_level as float)* cast((CASE WHEN dr.bai_value = 'Critical' then 9.5 WHEN dr.bai_value = 'High' then 8 WHEN dr.bai_value = 'Medium' then 5 WHEN dr.bai_value = 'Low' THEN 2 ELSE 1 END) as float)) as p_score, count(dr.id) from ${where.cyber.view} dr, organizations o, application_tags at where date_trunc('hour', dr.created_at) in (select max(date_trunc('hour', created_at)) from daily_scan_results group by asset_id ) and dr.organization_id = o.id and dr.application_grp_id = at.id and dr.id in (select id from assets where (is_active='enabled' or is_active='true' or is_active='disabled') and organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id))) as t`;
      },
      raw: function (condition, selector, date) {
        return `select 100 * ( 1 - (p_score::float/count)::numeric/((select p_score::float/count as score from (select sum(cast (score as float)) as p_score, count(dr.id) from ${where.cyber.view} dr, organizations o, application_tags at where dr.created_at::DATE in (select max(created_at::DATE) -1 from daily_scan_results where scan_type like '%vul%' group by asset_id ) and dr.organization_id = o.id and dr.application_grp_id = at.id and dr.id in (select id from assets where (is_active='enabled' or is_active='true' or is_active='disabled') and organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id) ) ) as y))) as percent_change from (select sum(cast (score as float)) as p_score, count(dr.id) from ${where.cyber.view} dr, organizations o, application_tags at where date_trunc('hour', dr.created_at) in (select max(date_trunc('hour', created_at)) from daily_scan_results group by asset_id ) and dr.organization_id = o.id and dr.application_grp_id = at.id and dr.id in (select id from assets where (is_active='enabled' or is_active='true' or is_active='disabled') and organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id) ) ) as t`;
      },
      residual: function (condition, selector, date) {
        return `select 100*(-1+1/(p_score::float/count)::numeric/(select p_score::float/count as score from (select sum(cast (score as float) * (select (p.max_value::float+p.min_value::float)/2 as score from priorities p where o.bai_value = p.name)) as p_score, count(dr.id) from ${where.cyber.view} dr, organizations o, application_tags at where dr.created_at::DATE in (select max(created_at::DATE) -1 from daily_scan_results where scan_type like '%vul%' group by asset_id ) and dr.organization_id = o.id and dr.application_grp_id = at.id and dr.id in (select id from assets where (is_active='enabled' or is_active='true' or is_active='disabled') and organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id) )) as t)) as percent_change from (select sum(cast (score as float) * (select (p.max_value::float+p.min_value::float)/2 as score from priorities p where o.bai_value = p.name)) as p_score, count(dr.id) from ${where.cyber.view} dr, organizations o, application_tags at where date_trunc('hour', dr.created_at) in (select max(date_trunc('hour', created_at)) from daily_scan_results group by asset_id ) and dr.organization_id = o.id and dr.application_grp_id = at.id and dr.id in (select id from assets where (is_active='enabled' or is_active='true' or is_active='disabled') and organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id) )) as t`;
      },
      critical: function (condition, selector, date) {
        return `select round(sum(cast (score as numeric))/count(cve_id), 2)::numeric/(select round(sum(cast (score as numeric))/count(cve_id), 2)::numeric from ${where.cyber.view} dr join priorities p on dr.score::float <= p.max_value::float and dr.score::float >= p.min_value::float where ${
          where.cyber.createdAtRiskFilter
        } and  cve_id like 'CVE%' and p.name ='Critical' and dr.id in (select id from assets where (is_active='enabled' or is_active='true' or is_active='disabled') and ${
          where.common.orgChainFilter
        }) group by p.name) as percent_change from ${where.cyber.view} dr join priorities p on dr.score::float <= p.max_value::float and dr.score::float >= p.min_value::float where ${
          where.cyber.createdAtRiskFilter
        } and  cve_id like 'CVE%' and p.name ='Critical' and dr.id in (select id from assets where (is_active='enabled' or is_active='true' or is_active='disabled') and ${
          where.common.orgChainFilter
        }) group by p.name`;
      },
      high: function (condition, selector, date) {
        return `select round(sum(cast (score as numeric))/count(cve_id), 2)::numeric/(select round(sum(cast (score as numeric))/count(cve_id), 2)::numeric from ${where.cyber.view} dr join priorities p on dr.score::float <= p.max_value::float and dr.score::float >= p.min_value::float where ${
          where.cyber.createdAtRiskFilter
        } and  cve_id like 'CVE%' and p.name ='High' and dr.id in (select id from assets where (is_active='enabled' or is_active='true' or is_active='disabled') and ${
          where.common.orgChainFilter
        }) group by p.name) as percent_change from ${where.cyber.view} dr join priorities p on dr.score::float <= p.max_value::float and dr.score::float >= p.min_value::float where ${
          where.cyber.createdAtRiskFilter
        } and  cve_id like 'CVE%' and p.name ='High' and dr.id in (select id from assets where (is_active='enabled' or is_active='true' or is_active='disabled') and ${
          where.common.orgChainFilter
        }) group by p.name`;
      },
      medium: function (condition, selector, date) {
        return `select round(sum(cast (score as numeric))/count(cve_id), 2)::numeric/(select round(sum(cast (score as numeric))/count(cve_id), 2)::numeric from ${where.cyber.view} dr join priorities p on dr.score::float <= p.max_value::float and dr.score::float >= p.min_value::float where ${
          where.cyber.createdAtRiskFilter
        } and  cve_id like 'CVE%' and p.name ='Medium' and dr.id in (select id from assets where (is_active='enabled' or is_active='true' or is_active='disabled') and ${
          where.common.orgChainFilter
        }) group by p.name) as percent_change from ${where.cyber.view} dr join priorities p on dr.score::float <= p.max_value::float and dr.score::float >= p.min_value::float where ${
          where.cyber.createdAtRiskFilter
        } and  cve_id like 'CVE%' and p.name ='Medium' and dr.id in (select id from assets where (is_active='enabled' or is_active='true' or is_active='disabled') and ${
          where.common.orgChainFilter
        }) group by p.name`;
      }
    },
    expected_params: ['orgId']
  },
  {
    name: 'distribution',
    route: ['/distribution', '/distribution/temporal'],
    search_terms: ['cyberRisk tabular data'],
    whereTransform: {
      tabular: {
        apply: true,
        mapping: {
          CVE: 'cve_id',
          cve_id: 'cve_id',
          cve: 'cve_id',
          vulnerability_type: 'vulnerability_type',
          organization_name: 'organization_name',
          location: 'location',
          application_grp_name: 'application_grp_name',
          application_name: 'application_name',
          asset_type: 'asset_type',
          source: 'source',
          severity: 'severity'
        }
      },
      scores: {
        apply: true,
        mapping: {
          CVE: 'cve_id',
          cve_id: 'cve_id',
          cve: 'cve_id',
          vulnerability_type: 'vulnerability_type',
          organization_name: 'organization_name',
          location: 'location',
          application_grp_name: 'application_grp_name',
          application_name: 'application_name',
          asset_type: 'asset_type',
          source: 'source',
          severity: 'severity'
        }
      }
    },
    sql: {
      default: function (condition, selector, date) {
        return `select asset_name,location from ${where.cyber.view} dr ${whereCondition(where.common.orgChainFilter, ...conditionFilter(condition))} limit 5`;
      },
      scores: function (condition, selector, date) {
        return `select round(avg(score::numeric),2) as raw,
        round(avg(score::numeric),2) as residual,
        round(avg((score::numeric + dr.impact_level::numeric + (CASE WHEN bai_value = 'Critical' then 9.5 WHEN bai_value = 'High' then 8 WHEN bai_value = 'Medium' then 5 WHEN bai_value = 'Low' THEN 2 ELSE 1 END)::numeric)::numeric)/3,2) as temporal
         
        from ${where.cyber.view} dr  ${whereCondition(
          where.cyber.riskViewAssetIdInOrgChainFilter,
          where.common.orgChainFilter,
          where.cyber.createdAtRiskFilter,
          ...conditionFilter(condition)
        )}`;
      },
      tabular: function (condition, selector, date) {

        return `select dr.vulnerability_type, dr.software ,dr.version, round(score::numeric/cast(coalesce(NULLIF(count(dr.id),0),1) as numeric),2) as "Raw",round(cast( score::numeric + (select (p.max_value::numeric+p.min_value::float)/2 as score from priorities p where dr.bai_value = p.name)/coalesce(NULLIF(count(dr.id),0),1) as numeric),2) as "Risk Residual",
        round(((dr.score::numeric + 
        dr.impact_level::numeric +
        (CASE WHEN dr.bai_value = 'Critical' then 9.5 WHEN dr.bai_value = 'High' then 8 
        WHEN dr.bai_value = 'Medium' then 5 WHEN dr.bai_value = 'Low' THEN 2 ELSE 1 END))/coalesce(NULLIF((3*count(dr.id)),0),1)),2) as "Temporal",    
        cve_id as "CVE",score,result,asset_name as "Asset",asset_type,dr.source as cloud_type,vmid,macaddress, location as "Location", organization_name as "Organization",organization_id as "OrganizationId",hosting_provider,application_grp_name as "Application",application_name as "Sub-Application",bai_value,p.name as "Severity", dr.id as asset_id,dr.realm AS "registeredName" ,dr.network_ip as ipAddress from ${where.cyber.viewTabular} dr join priorities p on dr.score::numeric >= p.min_value and dr.score::numeric <= p.max_value ${whereCondition(
          where.cyber.riskViewAssetIdInOrgChainFilter,
          // where.common.orgChainFilter,
          where.cyber.createdAtRiskFilter,
          ...conditionFilter(condition)
        )} group by dr.vulnerability_type,dr.software ,dr.version,asset_name,asset_type,dr.source,vmid,macaddress, location, organization_name,organization_id,hosting_provider,application_grp_name,application_name,bai_value,impact_level,cve_id,result,score,p.name,dr.id,dr.realm,dr.network_ip`;
      },
      count: function (condition, selector, date) {
        return `select severity as name, asset_ids from (select p.name as severity,array_agg(label) as asset_ids from (${cyberScore('asset_id', condition)}) as dr join priorities p on dr.raw_weighted_risk::numeric >= p.min_value and dr.raw_weighted_risk::numeric <= p.max_value group by p.name) x ${whereCondition(...conditionFilter(['severity'], condition))}`;
      },
      temporal: function (condition, selector, date) {
        return `select round(p_score::numeric/(3*count),2) as score from (select sum(cast (score as float) + cast(dr.impact_level as float)+ cast((CASE WHEN dr.bai_value = 'Critical' then 9.5 WHEN dr.bai_value = 'High' then 8 WHEN dr.bai_value = 'Medium' then 5 WHEN dr.bai_value = 'Low' THEN 2 ELSE 1 END) as float)) as p_score, count( dr.id) from ${where.cyber.view} dr ${whereCondition(
          where.cyber.riskViewAssetIdInOrgChainFilter,
          where.common.orgChainFilter,
          where.cyber.createdAtRiskFilter,
          ...conditionFilter(condition)
        )}) as t`;
      },
      raw: function (condition, selector, date) {
        return `select round(p_score::numeric/count,2) as score from (select sum(cast (score as float)) as p_score, count( dr.id) from ${where.cyber.view} dr${whereCondition(
          where.cyber.riskViewAssetIdInOrgChainFilter,
          where.common.orgChainFilter,
          where.cyber.createdAtRiskFilter,
          ...conditionFilter(condition)
        )}) as t`;
      },
      residual: function (condition, selector, date) {
        return `select round(p_score::numeric/count,2) as score from (select sum(cast (score as float) * (select (p.max_value::float+p.min_value::float)/2 as score from priorities p where dr.bai_value = p.name)) as p_score, count( dr.id) from ${where.cyber.view} dr ${whereCondition(
          where.cyber.riskViewAssetIdInOrgChainFilter,
          where.common.orgChainFilter,
          where.cyber.createdAtRiskFilter,
          ...conditionFilter(condition)
        )}) as t;`;
      },
      critical: function (condition, selector, date) {
        return `select p.name ,sum(cast (score as float))/count(cve_id) as avg_risk_score, count(distinct dr.id) as asset_count,count(cve_id) as count from ${where.cyber.view} dr join priorities p on dr.score::float <= p.max_value::float and dr.score::float >= p.min_value::float${whereCondition(
          where.cyber.riskViewAssetIdInOrgChainFilter,
          where.common.orgChainFilter,
          where.cyber.createdAtRiskFilter,
          ...conditionFilter(condition)
        )} group by p.name`;
      },
      high: function (condition, selector, date) {
        return `select p.name ,sum(cast (score as float))/count(cve_id) as avg_risk_score, count(distinct dr.id) as asset_count,count(cve_id) as count from ${where.cyber.view} dr join priorities p on dr.score::float <= p.max_value::float and dr.score::float >= p.min_value::float${whereCondition(
          where.cyber.riskViewAssetIdInOrgChainFilter,
          where.common.orgChainFilter,
          where.cyber.createdAtRiskFilter,
          ...conditionFilter(condition)
        )} group by p.name`;
      },
      medium: function (condition, selector, date) {
        return `select p.name ,sum(cast (score as float))/count(cve_id) as avg_risk_score, count(distinct dr.id) as asset_count,count(cve_id) as count from ${where.cyber.view} dr join priorities p on dr.score::float <= p.max_value::float and dr.score::float >= p.min_value::float${whereCondition(
          where.cyber.riskViewAssetIdInOrgChainFilter,
          where.common.orgChainFilter,
          where.cyber.createdAtRiskFilter,
          ...conditionFilter(condition)
        )} group by p.name`;
      }
    },
    postStages: [
      { type: '_removeUUID' },
      {
        type: 'setData',
        contextCheck: 'selector',
        contextCheckValue: 'tabular'
      },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'Application' },
          { label: 'Sub-Application', path: 'Sub-Application' },
          { label: 'Vulnerability-Type', path: 'vulnerability_type' },
          { label: 'Asset', path: 'Asset' },
          { label: 'asset_id', path: 'asset_id' },
          { label: 'Location', path: 'Location' },
          { label: 'Severity', path: 'Severity' },
          { label: 'CVE', path: 'CVE' },
          { label: 'Organization', path: 'Organization' }
        ]
      },
      { type: 'orderSeverity' }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'vulnerabilityAppGroupApplicationWidget',
    route: '/vulnerabilityAppGroupApplication',
    sql: {
      default: function (condition, selector, date) {
        return `select * from (select application_grp_name, application_name, cve_id as cve, p.name , score, count(distinct n.id) as asset_count, row_number() over (partition by p.name order by count(score) ) as rownum from (select application_grp_name, application_name, id, cve_id,score, asset_name from ${where.cyber.view} as d where id in (select id from (select id, sum(score::float) as total_score, sum(case when result='false' then score::float end) as risk_score from ${where.cyber.view} ${whereCondition(...conditionFilter(condition),
          where.cyber.createdAtRiskFilter, where.cyber.riskViewAssetIdInOrgChainFilter
        )} group by id order by risk_score desc limit 5 ) as t ) ) as n join priorities p on n.score::float <= p.max_value and n.score::float >= p.min_value group by n.application_grp_name, n.application_name,n.cve_id, p.name, score order by name ) AS listP where rownum < 50 ;`;
      },
      critical: function (condition, selector, date) {
        return `select o.application_grp_name, o.application_name, o.cve_id, o.id, o.avg_risk_score, p.name from ( select application_grp_name, application_name,cve_id, id, sum(cast (score as float))/count(cve_id) as avg_risk_score from ${where.cyber.view} ${whereCondition(...conditionFilter(condition),
          where.cyber.createdAtRiskFilter, where.cyber.riskViewAssetIdInOrgChainFilter
        )} group by application_grp_name, application_name,cve_id,id order by avg_risk_score desc ) as o join priorities p on o.avg_risk_score <= p.max_value::float and o.avg_risk_score >= p.min_value::float where name ='Critical'`;
      },
      medium: function (condition, selector, date) {
        return `select o.application_grp_name, o.application_name, o.cve_id, o.id, o.avg_risk_score, p.name from ( select application_grp_name, application_name,cve_id, id, sum(cast (score as float))/count(cve_id) as avg_risk_score from ${where.cyber.view} ${whereCondition(...conditionFilter(condition),
          where.cyber.createdAtRiskFilter, where.cyber.riskViewAssetIdInOrgChainFilter
        )} group by application_grp_name, application_name,cve_id,id order by avg_risk_score desc ) as o join priorities p on o.avg_risk_score <= p.max_value::float and o.avg_risk_score >= p.min_value::float where name ='Medium'`;
      },
      high: function (condition, selector, date) {
        return `select o.application_grp_name, o.application_name, o.cve_id, o.id, o.avg_risk_score, p.name from ( select application_grp_name, application_name,cve_id, id, sum(cast (score as float))/count(cve_id) as avg_risk_score from ${where.cyber.view}${whereCondition(...conditionFilter(condition),
          where.cyber.createdAtRiskFilter, where.cyber.riskViewAssetIdInOrgChainFilter
        )} group by application_grp_name, application_name,cve_id,id order by avg_risk_score desc ) as o join priorities p on o.avg_risk_score <= p.max_value::float and o.avg_risk_score >= p.min_value::float where name ='High'`;
      }
    },
    expected_params: ['orgId']
  },
  {
    name: 'vulnerabilityView',
    route: '/vulnerabilityView',
    whereTransform: {
      default: {
        apply: true,
        mapping: {
          asset_type: 'asset_type',
          type: 'asset_type',
          vulnerability_type: 'vulnerability_type',
          location: 'location',
          application_grp_name: 'application_grp_name',
          asset_name: 'asset_name'
        }
      },
      critical: {
        apply: true,
        mapping: {
          asset_type: 'asset_type',
          type: 'asset_type',
          vulnerability_type: 'vulnerability_type',
          location: 'location',
          application_grp_name: 'application_grp_name',
          asset_name: 'asset_name'
        }
      },
      medium: {
        apply: true,
        mapping: {
          asset_type: 'asset_type',
          type: 'asset_type',
          vulnerability_type: 'vulnerability_type',
          location: 'location',
          application_grp_name: 'application_grp_name',
          asset_name: 'asset_name'
        }
      },
      high: {
        apply: true,
        mapping: {
          asset_type: 'asset_type',
          type: 'asset_type',
          vulnerability_type: 'vulnerability_type',
          location: 'location',
          application_grp_name: 'application_grp_name',
          asset_name: 'asset_name'
        }
      },
      low: {
        apply: true,
        mapping: {
          asset_type: 'asset_type',
          type: 'asset_type',
          vulnerability_type: 'vulnerability_type',
          location: 'location',
          application_grp_name: 'application_grp_name',
          asset_name: 'asset_name'
        }
      }
    },
    sql: {
      default: function (condition, selector, date) {
        return `select dr.vulnerability_type, dr.software ,dr.version, location, application_grp_name,asset_name, application_name,score, cve_id as "CVE",asset_type as type from ${where.cyber.view} dr  ${whereCondition(
          ...conditionFilter(condition)
        )} group by dr.vulnerabilitytype,dr.software,dr.version, location, application_grp_name,asset_name,score, application_name, cve_id,asset_type order by cve_id `;
      },
      critical: function (condition, selector, date) {
        return `select  dr.vulnerability_type, dr.software ,dr.version, location, application_grp_name,asset_name, application_name,score, cve_id as "CVE",asset_type as type from ${where.cyber.view} dr  ${whereCondition(
          ...conditionFilter(condition),
          `severity = 'Critical'`
        )} group by dr.vulnerability_type,dr.software,dr.version, location, application_grp_name,asset_name,score, application_name, cve_id,asset_type order by cve_id `;
      },
      medium: function (condition, selector, date) {
        return `select dr.vulnerability_type, dr.software ,dr.version, location, application_grp_name,asset_name, application_name,score, cve_id as "CVE",asset_type as type from ${where.cyber.view} dr  ${whereCondition(
          ...conditionFilter(condition),
          `severity = 'Medium'`
        )} group by dr.vulnerability_type,dr.software,dr.version, location, application_grp_name,asset_name,score, application_name, cve_id,asset_type order by cve_id `;
      },
      high: function (condition, selector, date) {
        return `select dr.vulnerability_type, dr.software ,dr.version, location, application_grp_name,asset_name, application_name,score, cve_id as "CVE",asset_type as type from ${where.cyber.view} dr  ${whereCondition(
          ...conditionFilter(condition),
          `severity = 'High'`
        )} group by dr.vulnerability_type,dr.software,dr.version, location, application_grp_name,asset_name,score, application_name, cve_id,asset_type order by cve_id `;
      },
      low: function (condition, selector, date) {
        return `select dr.vulnerability_type, dr.software ,dr.version, location, application_grp_name,asset_name, application_name,score, cve_id as "CVE",asset_type as type from ${where.cyber.view} dr  ${whereCondition(
          ...conditionFilter(condition),
          `severity = 'Low'`
        )} group by dr.vulnerability_type,dr.software,dr.version, location, application_grp_name,asset_name,score, application_name, cve_id,asset_type order by cve_id `;
      }
    },
    postStages: [
      { type: '_removeUUID' },
      { type: 'setData' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'application_grp_name' },
          { label: 'Sub-Application', path: 'application_name' },
          { label: 'Vulnerability-Type', path: 'vulnerability_type' },
          { label: 'Asset', path: 'asset_name' },
          { label: 'Location', path: 'location' },
          { label: 'CVE', path: 'CVE' },
          { label: 'Asset Type', path: 'type' }
        ]
      },
      {
        type: 'lodash',
        transformationType: 'groupBy',
        dataPath: 'data',
        transformer: 'CVE'
      }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'vulnerabilityDistribution',
    route: '/vulnerabilityDistribution',
    search_terms: ['Vulnerability tabular data'],
    whereTransform: {
      default: {
        apply: true,
        mapping: {
          asset_type: 'asset_type',
          type: 'asset_type',
          vulnerability_type: 'vulnerability_type',
          location: 'location',
          application_grp_name: 'application_grp_name',
          asset_name: 'asset_name'
        }
      },
      tabular: {
        apply: true,
        mapping: {
          asset_type: 'asset_type',
          type: 'asset_type',
          vulnerability_type: 'vulnerability_type',
          location: 'location',
          application_grp_name: 'application_grp_name',
          application_name: 'application_name',
          asset_name: 'asset_name'
        }
      },
      new: {
        apply: true,
        mapping: {
          asset_type: 'asset_type',
          type: 'asset_type',
          vulnerability_type: 'vulnerability_type',
          location: 'location',
          application_grp_name: 'application_grp_name',
          asset_name: 'asset_name'
        }
      },
      total: {
        apply: true,
        mapping: {
          asset_type: 'asset_type',
          type: 'asset_type',
          vulnerability_type: 'vulnerability_type',
          location: 'location',
          application_grp_name: 'application_grp_name',
          asset_name: 'asset_name'
        }
      }
    },
    sql: {
      default: function (condition, selector, date) {
        return `select array_agg(distinct cve_id) as cve_ids, name from ${where.cyber.view} dr join priorities p on score::numeric <= p.max_value::float and score::numeric >= p.min_value::float ${whereCondition(
          where.cyber.riskViewAssetIdInOrgChainFilter,
          where.cyber.createdAtRiskFilter,
          ...conditionFilter(condition)
        )} group by p.name`;
      },
      total: function (condition, selector, date) {
        return `select array_agg(distinct cve_id) as cve_ids from ${where.cyber.view} dr join priorities p on score::numeric <= p.max_value::float and score::numeric >= p.min_value::float ${whereCondition(
          where.cyber.riskViewAssetIdInOrgChainFilter,
          where.cyber.createdAtRiskFilter,
          ...conditionFilter(condition)
        )}`;
      },
      new: function (condition, selector, date) {
        return `select array_agg(distinct cve_id) as cve_ids from ${where.cyber.view} dr join priorities p on score::numeric <= p.max_value::float and score::numeric >= p.min_value::float ${whereCondition(
          where.cyber.riskViewAssetIdInOrgChainFilter,
          where.cyber.createdAtRiskFilter,
          'created_at::DATE between (now()- interval \'3 days\')::date and  now()::DATE',
          ...conditionFilter(condition)
        )}`;
      },
      tabular: function (condition, selector, date) {
        return `select distinct dr.vulnerability_type, dr.result, dr.software, dr.version, dr.cve_id as \"CVE\",p.name as \"Severity\",dr.score,dr.id as asset_id,dr.asset_name as \"Asset\",dr.application_name as \"Sub-Application\",dr.application_grp_name as \"Application\",dr.organization_name as \"Organization\",dr.organization_id as \"OrganizationId\", dr.source as cloud_type,dr.asset_type as asset_type, dr.location as \"Location\", dr.id as asset_id,dr.realm AS "registeredName" ,dr.network_ip as ipAddress,
        case when created_at::DATE between (now()- interval '3 days')::date and  now()::DATE then 'yes' else 'no' end as "New" from ${where.cyber.viewTabular} dr join priorities p on score::numeric <= p.max_value::float and score::numeric >= p.min_value::float ${whereCondition(
          ...conditionFilter(condition)
        )}`;
      }
    },
    postStages: [
      { type: '_removeUUID' },
      { type: 'setData', contextCheck: 'selector', contextCheckValue: 'tabular' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'Application' },
          { label: 'Sub-Application', path: 'Sub-Application' },
          { label: 'Asset', path: 'Asset' },
          { label: 'CVE', path: 'CVE' },
          { label: 'Organization', path: 'Organization' },
          { label: 'Severity', path: 'Severity' },
          { label: 'Vulnerability-Type', path: 'vulnerability_type' },
          { label: 'New', path: 'New' },
          { label: 'cloud_type', path: 'cloud_type' },
          { label: 'asset_type', path: 'asset_type' },
          { label: 'Source', path: 'source' }
        ]
      },
      { type: 'orderSeverity' }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'vulnerabilityDistributionTablePercentChange',
    route: '/vulnerabilityDistribution/percentChange',
    sql: {
      low: function (condition, selector, date) {
        return `select 100*(-1+1/(count(distinct cve_id)::numeric/(select count(distinct cve_id) as sum from ${where.cyber.view} dr join priorities p on score::numeric <= p.max_value::float and score::numeric >= p.min_value::float where p.name = 'Low' and created_at::DATE in (select max(created_at::DATE) - 1 from daily_scan_results where scan_type like '%vul%' group by asset_id ) and  dr.id in (select id from assets where ${
          where.common.orgChainFilter
        } ) group by p.name))) as percent_change from ${where.cyber.view} dr join priorities p on score::numeric <= p.max_value::float and score::numeric >= p.min_value::float where p.name = 'Low' and ${
          where.cyber.createdAtRiskFilter
        } and  dr.id in (select id from assets where ${where.common.orgChainFilter} ) group by p.name`;
      },
      medium: function (condition, selector, date) {
        return `select 100*(-1+1/(count(distinct cve_id)::numeric/(select count(distinct cve_id) as sum from ${where.cyber.view} dr join priorities p on score::numeric <= p.max_value::float and score::numeric >= p.min_value::float where p.name = 'Medium' and created_at::DATE in (select max(created_at::DATE) - 1 from daily_scan_results where scan_type like '%vul%' group by asset_id ) and  dr.id in (select id from assets where ${
          where.common.orgChainFilter
        } ) group by p.name))) as percent_change from ${where.cyber.view} dr join priorities p on score::numeric <= p.max_value::float and score::numeric >= p.min_value::float where p.name = 'Medium' and ${
          where.cyber.createdAtRiskFilter
        } and  dr.id in (select id from assets where ${where.common.orgChainFilter} ) group by p.name`;
      },
      high: function (condition, selector, date) {
        return `select 100*(-1+1/(count(distinct cve_id)::numeric/(select count(distinct cve_id) as sum from ${where.cyber.view} dr join priorities p on score::numeric <= p.max_value::float and score::numeric >= p.min_value::float where p.name = 'High' and created_at::DATE in (select max(created_at::DATE) - 1 from daily_scan_results where scan_type like '%vul%' group by asset_id ) and  dr.id in (select id from assets where ${
          where.common.orgChainFilter
        } ) group by p.name))) as percent_change from ${where.cyber.view} dr join priorities p on score::numeric <= p.max_value::float and score::numeric >= p.min_value::float where p.name = 'High' and ${
          where.cyber.createdAtRiskFilter
        } and  dr.id in (select id from assets where ${where.common.orgChainFilter} ) group by p.name`;
      },
      critical: function (condition, selector, date) {
        return `select 100*(-1+1/(count(distinct cve_id)::numeric/(select count(distinct cve_id) as sum from ${where.cyber.view} dr join priorities p on score::numeric <= p.max_value::float and score::numeric >= p.min_value::float where p.name = 'Critical' and created_at::DATE in (select max(created_at::DATE) - 1 from daily_scan_results where scan_type like '%vul%' group by asset_id ) and  dr.id in (select id from assets where ${
          where.common.orgChainFilter
        } ) group by p.name))) as percent_change from ${where.cyber.view} dr join priorities p on score::numeric <= p.max_value::float and score::numeric >= p.min_value::float where p.name = 'Critical' and ${
          where.cyber.createdAtRiskFilter
        } and  dr.id in (select id from assets where ${where.common.orgChainFilter} ) group by p.name`;
      },
      total: function (condition, selector, date) {
        return `select 100*(-1+1/(round(coalesce(NULLIF(count(distinct cve_id),0),1),2)::float/(select round(coalesce(NULLIF(count(distinct cve_id),0),1),2)::float as total_count from ${where.cyber.view} where created_at::DATE in (select max(created_at::DATE) - 1 from daily_scan_results where scan_type like '%vul%' group by asset_id ) and  id in (select id from assets where ${
          where.common.orgChainFilter
        } ) ))) as percent_change from ${where.cyber.view} where ${where.cyber.createdAtRiskFilter} and  id in (select id from assets where ${
          where.common.orgChainFilter
        } ) `;
      },
      new: function (condition, selector, date) {
        return `select 100*(-1+1/(round(coalesce(NULLIF(count(distinct cve_id),0),1),2)::numeric/(select coalesce(NULLIF(count(distinct cve_id),0),1) as total_count from ${where.cyber.view} where created_at::DATE in (select max(created_at::DATE) -1 from daily_scan_results where scan_type like '%vul%' ) and  id in (select id from assets where ${
          where.common.orgChainFilter
        } )) )) as percent_change from ${where.cyber.view} where ${where.cyber.createdAtRiskFilter} and  id in (select id from assets where ${
          where.common.orgChainFilter
        } ) `;
      }
    },
    expected_params: ['orgId']
  },
  {
    name: 'impactAssessmentByVulnerability',
    route: '/impactAssessmentByVulnerability',
    whereTransform: {
      default: {
        apply: true,
        mapping: {
          CVE: 'dr.cve_id',
          cve: 'dr.cve_id',
          cve_id: 'dr.cve_id',
          vulnerability_type: 'vulnerability_type',
          organization_name: 'organization_name',
          location: 'location',
          application_grp_name: 'application_grp_name',
          application_group: 'application_grp_name',
          application_name: 'application_name',
          asset_type: 'asset_type',
          source: 'source',
          severity: 'severity'
        }
      },
    },
    sql: {
      default: function (condition, selector, date) {
        return `select cis_control_id,control_count,severity from 
          (select cis_control_id,control_count::integer,initcap(severity) as severity, 
              row_number() OVER (PARTITION BY severity ORDER BY severity DESC) AS outerrownum from (
              select * from (select isc.cis_control_id, count(distinct isc.entity_arn) as control_count, LOWER(cis.severity) as severity,
              row_number() OVER (PARTITION BY LOWER(cis.severity) ORDER BY cis.severity DESC) AS rownum
              from infrastructure_services_compliance isc
              join cis_webservices_controls cis on cis.control_id = isc.cis_control_id
              join (select max(batch_id) as max_batch_id,entity_arn from infrastructure_services_compliance where organization_id in (select org_chain_list(:orgId) ) group by entity_arn ) as max_batch_infra on max_batch_infra.max_batch_id = isc.batch_id and max_batch_infra.entity_arn = isc.entity_arn
              where isc.organization_id in (select org_chain_list(:orgId))
              group by isc.cis_control_id, cis.severity
              order by cis.severity,control_count desc
              ) a where rownum <= 10
              UNION ALL
              select * from (select scan.reference , count(distinct scan.asset_id) as control_count, LOWER(p.name) as severity,
              row_number() OVER (PARTITION BY LOWER(p.name) ORDER BY p.name  DESC) AS rownum
              from daily_scan_results scan          
              join common_vulnerabilities_exposures_base cve on cve.cve_id = btrim(scan.reference)
              join priorities p on cve.score::numeric <= p.max_value and cve.score::numeric >= p.min_value
              join (select asset_id, max(batch_id) as max_batch_id from daily_scan_results where asset_id in (select id from assets
              where (is_active='enabled' or is_active='true' or is_active='disabled') and
              organization_id in (select org_chain_list(:orgId)) ) group by asset_id) as max_scanresult on scan.asset_id = max_scanresult.asset_id and scan.batch_id = max_scanresult.max_batch_id
              where scan.batch_id in (select MAX(batch_id) from daily_scan_results where organization_id in (select org_chain_list(:orgId)) group by asset_id)
              and scan.organization_id in (select org_chain_list(:orgId))
              group by scan.reference, p.name
              order by control_count desc
              ) b where rownum <= 10
              UNION ALL
              select * from (select scan.reference , count(distinct scan.asset_id) as control_count, LOWER(xr.severity) as severity,
              row_number() OVER (PARTITION BY LOWER(xr.severity) ORDER BY xr.severity  DESC) AS rownum
              from daily_scan_xccdf_results scan
              join xccdf_rules xr ON scan.rule_id = xr.rule_id
              join (select asset_id, max(batch_id) as max_batch_id from daily_scan_xccdf_results where asset_id in (select id from assets
              where (is_active='enabled' or is_active='true' or is_active='disabled') and
              organization_id in (select org_chain_list(:orgId)) )
              group by asset_id) as max_scanresult on scan.asset_id = max_scanresult.asset_id and scan.batch_id = max_scanresult.max_batch_id
              where 
              scan.organization_id in (select org_chain_list(:orgId))
              group by scan.reference, xr.severity  
              order by control_count desc 
              ) c where rownum <= 10
            ) d
          ) outer_sql where outerrownum <= 10 and severity in ('Critical','High','Medium','Low')
          order by severity, control_count desc`;
      }
    },
    expected_params: ['orgId']
  },
  {
    name: 'impactAssessmentByVulnerability',
    route: '/impactAssessmentByVulnerability/temporal',
    sql: {
      default: function (condition, selector, date) {

        return `(select o.cve_id, o.asset_count, o.avg_risk_score, name ,o.summary from (select dr.cve_id, cve_set.summary, count(distinct dr.id) as asset_count,(sum(cast (score as float))+cast((CASE WHEN bai_value = 'Critical' then 9.5 WHEN bai_value = 'High' then 8 WHEN bai_value = 'Medium' then 5 WHEN bai_value = 'Low' THEN 2 ELSE 1 END) as numeric)+impact_level::numeric)/(3*count(dr.cve_id)) as avg_risk_score from ${where.cyber.view} dr join common_vulnerabilities_exposures cve_set on cve_set.cve_id = dr.cve_id ${whereCondition(where.cyber.riskViewAssetIdInOrgChainFilter, where.cyber.createdAtRiskFilter, ...conditionFilter(condition))} group by dr.cve_id, cve_set.summary,bai_value,impact_level order by asset_count desc limit 10) as o join priorities p on o.avg_risk_score <= p.max_value::float and o.avg_risk_score >= p.min_value::float where name = 'Critical' order by asset_count desc limit 10) UNION ALL (select o.cve_id, o.asset_count, o.avg_risk_score, name ,o.summary from (select dr.cve_id, cve_set.summary, count(distinct dr.id) as asset_count,sum(cast (score as float))/count(dr.cve_id) as avg_risk_score from ${where.cyber.view} dr join common_vulnerabilities_exposures cve_set on cve_set.cve_id = dr.cve_id ${whereCondition(where.cyber.riskViewAssetIdInOrgChainFilter, where.cyber.createdAtRiskFilter, ...conditionFilter(condition))} group by dr.cve_id, cve_set.summary order by asset_count desc limit 10) as o join priorities p on o.avg_risk_score <= p.max_value::float and o.avg_risk_score >= p.min_value::float where name = 'High' order by asset_count desc limit 10) UNION ALL (select o.cve_id, o.asset_count, o.avg_risk_score, name ,o.summary from (select dr.cve_id, cve_set.summary, count(distinct dr.id) as asset_count,sum(cast (score as float))/count(dr.cve_id) as avg_risk_score from ${where.cyber.view} dr join common_vulnerabilities_exposures cve_set on cve_set.cve_id = dr.cve_id ${whereCondition(where.cyber.riskViewAssetIdInOrgChainFilter, where.cyber.createdAtRiskFilter, ...conditionFilter(condition))} group by dr.cve_id, cve_set.summary order by asset_count desc limit 10) as o join priorities p on o.avg_risk_score <= p.max_value::float and o.avg_risk_score >= p.min_value::float where name = 'Medium' order by asset_count desc limit 10) UNION ALL (select o.cve_id, o.asset_count, o.avg_risk_score, name ,o.summary from (select dr.cve_id, cve_set.summary, count(distinct dr.id) as asset_count,sum(cast (score as float))/count(dr.cve_id) as avg_risk_score from ${where.cyber.view} dr join common_vulnerabilities_exposures cve_set on cve_set.cve_id = dr.cve_id ${whereCondition(where.cyber.riskViewAssetIdInOrgChainFilter, where.cyber.createdAtRiskFilter, ...conditionFilter(condition))} group by dr.cve_id, cve_set.summary order by asset_count desc limit 10) as o join priorities p on o.avg_risk_score <= p.max_value::float and o.avg_risk_score >= p.min_value::float where name = 'Low' order by asset_count desc limit 10)`;
      },
      critical: function (condition, selector, date) {
        return `select o.cve_id, o.asset_count, o.avg_risk_score, name ,o.summary from (select dr.cve_id, cve_set.summary, count(distinct dr.id) as asset_count,(sum(cast (score as float))+cast((CASE WHEN bai_value = 'Critical' then 9.5 WHEN bai_value = 'High' then 8 WHEN bai_value = 'Medium' then 5 WHEN bai_value = 'Low' THEN 2 ELSE 1 END) as numeric)+impact_level::numeric)/(3*count(dr.cve_id)) as avg_risk_score from ${where.cyber.view} dr join common_vulnerabilities_exposures cve_set on cve_set.cve_id = dr.cve_id ${whereCondition(where.cyber.riskViewAssetIdInOrgChainFilter, where.cyber.createdAtRiskFilter, ...conditionFilter(condition))} group by dr.cve_id, cve_set.summary,bai_value,impact_level order by asset_count desc limit 10) as o join priorities p on o.avg_risk_score <= p.max_value::float and o.avg_risk_score >= p.min_value::float where name = 'Critical' order by asset_count desc limit 10`;
      },
      high: function (condition, selector, date) {
        return `select o.cve_id, o.asset_count, o.avg_risk_score, name ,o.summary from (select dr.cve_id, cve_set.summary, count(distinct dr.id) as asset_count,(sum(cast (score as float))+cast((CASE WHEN bai_value = 'Critical' then 9.5 WHEN bai_value = 'High' then 8 WHEN bai_value = 'Medium' then 5 WHEN bai_value = 'Low' THEN 2 ELSE 1 END) as numeric)+impact_level::numeric)/(3*count(dr.cve_id)) as avg_risk_score from ${where.cyber.view} dr join common_vulnerabilities_exposures cve_set on cve_set.cve_id = dr.cve_id ${whereCondition(where.cyber.riskViewAssetIdInOrgChainFilter, where.cyber.createdAtRiskFilter, ...conditionFilter(condition))} group by dr.cve_id, cve_set.summary,bai_value,impact_level order by asset_count desc limit 10) as o join priorities p on o.avg_risk_score <= p.max_value::float and o.avg_risk_score >= p.min_value::float where name = 'High' order by asset_count desc limit 10`;
      },
      medium: function (condition, selector, date) {
        return `select o.cve_id, o.asset_count, o.avg_risk_score, name ,o.summary from (select dr.cve_id, cve_set.summary, count(distinct dr.id) as asset_count,(sum(cast (score as float))+cast((CASE WHEN bai_value = 'Critical' then 9.5 WHEN bai_value = 'High' then 8 WHEN bai_value = 'Medium' then 5 WHEN bai_value = 'Low' THEN 2 ELSE 1 END) as numeric)+impact_level::numeric)/(3*count(dr.cve_id)) as avg_risk_score from ${where.cyber.view} dr join common_vulnerabilities_exposures cve_set on cve_set.cve_id = dr.cve_id ${whereCondition(where.cyber.riskViewAssetIdInOrgChainFilter, where.cyber.createdAtRiskFilter, ...conditionFilter(condition))} group by dr.cve_id, cve_set.summary,bai_value,impact_level order by asset_count desc limit 10) as o join priorities p on o.avg_risk_score <= p.max_value::float and o.avg_risk_score >= p.min_value::float where name = 'Medium' order by asset_count desc limit 10`;
      },
      low: function (condition, selector, date) {
        return `select o.cve_id, o.asset_count, o.avg_risk_score, name ,o.summary from (select dr.cve_id, cve_set.summary, count(distinct dr.id) as asset_count,(sum(cast (score as float))+cast((CASE WHEN bai_value = 'Critical' then 9.5 WHEN bai_value = 'High' then 8 WHEN bai_value = 'Medium' then 5 WHEN bai_value = 'Low' THEN 2 ELSE 1 END) as numeric)+impact_level::numeric)/(3*count(dr.cve_id)) as avg_risk_score from ${where.cyber.view} dr join common_vulnerabilities_exposures cve_set on cve_set.cve_id = dr.cve_id ${whereCondition(where.cyber.riskViewAssetIdInOrgChainFilter, where.cyber.createdAtRiskFilter, ...conditionFilter(condition))} group by dr.cve_id, cve_set.summary,bai_value,impact_level order by asset_count desc limit 10) as o join priorities p on o.avg_risk_score <= p.max_value::float and o.avg_risk_score >= p.min_value::float where name = 'Low' order by asset_count desc limit 10`;
      }
    },
    expected_params: ['orgId']
  },
  {
    name: 'riskTopFiveWidget',
    route: '/riskTopFive',
    whereTransform: {
      subapplication: {
        apply: true,
        mapping: {
          CVE: 'cve_id',
          cve_id: 'cve_id',
          cve: 'cve_id',
          vulnerability_type: 'vulnerability_type',
          organization_name: 'organization_name',
          location: 'location',
          application_grp_name: 'application_grp_name',
          application_name: 'application_name',
          asset_type: 'asset_type',
          source: 'source',
          severity: 'severity'
        }
      }
    },
    sql: {

      application: function (condition, selector, date) {
        return `select application_grp_name, (sum(cast (score as float))/coalesce(NULLIF(count(cve_id),0),1)) as total_risk_score from ${where.cyber.view} dr
        ${whereCondition(
          where.cyber.createdAtRiskFilter,
          where.cyber.riskViewAssetIdInOrgChainFilter,
          ...conditionFilter(condition)
        )} group by application_grp_name order by total_risk_score limit 5`;
      },
      subapplication: function (condition, selector, date) {
        return `select application_name,application_grp_name, (sum(cast (score as float))/coalesce(NULLIF(count(cve_id),0),1)) as total_risk_score from ${where.cyber.view} dr
        ${whereCondition(
          where.cyber.createdAtRiskFilter,
          where.cyber.riskViewAssetIdInOrgChainFilter,
          ...conditionFilter(condition)
        )} group by application_name,application_grp_name order by total_risk_score limit 5`;
      },
      location: function (condition, selector, date) {
        return `select location, (sum(cast (score as float))/coalesce(NULLIF(count(cve_id),0),1)) as total_risk_score from ${where.cyber.view} dr
        ${whereCondition(
          where.cyber.createdAtRiskFilter,
          where.cyber.riskViewAssetIdInOrgChainFilter,
          ...conditionFilter(condition)
        )} group by location order by total_risk_score limit 5`;
      },
      org: function (condition, selector, date) {
        return `select organization_name as organization, (sum(cast (score as float))/coalesce(NULLIF(count(cve_id),0),1)) as total_risk_score from ${where.cyber.view} dr
        ${whereCondition(
          where.cyber.createdAtRiskFilter,
          where.cyber.riskViewAssetIdInOrgChainFilter,
          ...conditionFilter(condition)
        )} group by organization_name order by total_risk_score limit 5`;
      },
      asset: function (condition, selector, date) {
        return `select id,asset_name, (sum(cast (score as float))/coalesce(NULLIF(count(cve_id),0),1)) as total_risk_score from ${where.cyber.view} dr
  ${whereCondition(
          where.cyber.createdAtRiskFilter,
          where.cyber.riskViewAssetIdInOrgChainFilter,
          ...conditionFilter(condition)
        )} group by id,asset_name order by total_risk_score desc limit 5`;
      }
    },
    expected_params: ['orgId']
  },
  {
    name: 'topFiveVulnerabilityByWidget',
    route: '/vulnerabilityTopFive',
    sql: {
      default: function (condition, selector, date) {
        return `select cve_id, (sum(cast (score as float))/coalesce(NULLIF(count(cve_id),0),1)) as total_risk_score from ${where.cyber.view} ${whereCondition(...conditionFilter(condition),
          where.cyber.createdAtRiskFilter, where.cyber.riskViewAssetIdInOrgChainFilter
        )} group by cve_id order by total_risk_score desc limit 5 `;
      },
      application: function (condition, selector, date) {
        return `select application_grp_name, application_name, (sum(cast (score as float))/coalesce(NULLIF(count(cve_id),0), 1)) as total_risk_score from ${where.cyber.view} ${whereCondition(...conditionFilter(condition),
          where.cyber.createdAtRiskFilter, where.cyber.riskViewAssetIdInOrgChainFilter
        )} group by application_grp_name,application_name order by total_risk_score limit 5`;
      },
      location: function (condition, selector, date) {
        return `select location, (sum(cast (score as float))/coalesce(NULLIF(count(cve_id),0),1)) as total_risk_score from ${where.cyber.view} ${whereCondition(...conditionFilter(condition),
          where.cyber.createdAtRiskFilter, where.cyber.riskViewAssetIdInOrgChainFilter
        )} group by location order by total_risk_score limit 5 `;
      },
      org: function (condition, selector, date) {
        return `select organization_name as organization, (sum(cast (score as float))/coalesce(NULLIF(count(cve_id),0),1)) as total_risk_score from ${where.cyber.view} ${whereCondition(...conditionFilter(condition),
          where.cyber.createdAtRiskFilter, where.cyber.riskViewAssetIdInOrgChainFilter
        )} group by organization order by total_risk_score limit 5`;
      }
    },
    expected_params: ['orgId']
  },
  {
    name: 'riskTopTenVulnerabilitiesWidget',
    route: '/topTenVulnerabilities',
    sql: {
      default: function (condition, selector, date) {
        return `select cve_id, count(id) as asset_count from ${where.cyber.view} ${whereCondition(...conditionFilter(condition),
          where.cyber.createdAtRiskFilter, where.cyber.riskViewAssetIdInOrgChainFilter
        )} group by cve_id order by asset_count desc limit 10;`;
      }
    },
    expected_params: ['orgId']
  },
  {
    name: 'cyberRiskReduction',
    route: ['/riskReductionView/temporal', '/riskReductionView'],
    sql: {
      default: function (condition, selector, date) {
        return `select *, (case when cum_vul<=20 then '20%' when cum_vul <=40 and cum_vul>20 then '40%' when cum_vul <=60 and cum_vul>40 then '60%' when cum_vul>60 then '80%' end) as cum_vul_group from (
       select *,round(sum(total_cve_score*100/total_score:: float) over(order by rownum )) as cummulative_reduction from (
       select *, sum(total_cve_score) over() as total_score, rownum*100/(max(rownum) over()) as cum_vul from (
       select *, row_number() over( order by total_cve_score desc) as rownum from  ( 
       select cve_id, sum(score::numeric) as total_cve_score,location, organization_name, application_grp_name, source,application_name,vulnerability_type, score::float as cve_risk_score,severity,asset_name,asset_id   from  ${where.cyber.view} dr  ${whereCondition(
          ...conditionFilter(condition)
        )}  group by asset_name,asset_id,cve_id,score,location, organization_name, application_grp_name, application_name,vulnerability_type,severity,source) cve_scoring ) x) j) k `;
        //TODO make this cyberSelector
        // ${cyberSelector(['source', 'asset_type', 'location', 'organization_name', 'application_grp_name', 'application_name', 'asset_id', 'asset_name','result','cve_id','rule_id'])}
      }
    },
    postStages: [
      { type: 'setData' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Asset', path: 'asset_name' },
          { label: 'Application', path: 'application_grp_name' },
          { label: 'Sub-Application', path: 'application_name' },
          { label: 'Location', path: 'location' },
          { label: 'Vulnerability-Type', path: 'vulnerability_type' },
          // { label: 'Reduction Grouping', path: 'cum_vul_group' }, TODO: because this whereCOndition breaks other widgets, remove until a better solution in place
          { label: 'CVE', path: 'cve_id' },
          { label: 'Asset Type', path: 'asset_type' },
          { label: 'Organization', path: 'organization_name' },
          { label: 'Source', path: 'source' }
        ]
      },
      { type: 'getAssets', riskType: 'cyber', elem: 'asset_name', label: 'Asset' }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'cyberRiskImprovementWidget',
    route: '/riskImprovement',
    whereTransform: {
      default: {
        apply: true,
        mapping: {
          CVE: 'cve_id',
          cve_id: 'cve_id',
          vulnerability_type: 'vulnerability_type',
          organization_name: 'organization_name',
          location: 'location',
          application_grp_name: 'application_grp_name',
          application_name: 'application_name',
          asset_type: 'asset_type',
          source: 'source',
          severity: 'severity'
        }
      }
    },
    sql: {
      default: function (condition, selector, date) {
        return `select *, (case when cum_vul<=20 then '20%' when cum_vul <=40 and cum_vul>20 then '40%' when cum_vul <=60 and cum_vul>40 then '60%' when cum_vul>60 then '80%' end) as cum_vul_group from (
       select *,round(sum(total_cve_score*100/total_score:: float) over(order by rownum )) as cummulative_reduction from (
       select *, sum(total_cve_score) over() as total_score, rownum*100/(max(rownum) over()) as cum_vul from (
       select *, row_number() over( order by total_cve_score desc) as rownum from  ( select cve_id, sum(score::numeric) as total_cve_score,location, organization_name, application_grp_name, application_name  from  ${where.cyber.view} dr  ${whereCondition(
          ...conditionFilter(condition)
        )}  group by cve_id,location, organization_name, application_grp_name, application_name) cve_scoring ) x) j) k `;
      }
    },
    postStages: [
      {
        type: 'lodash',
        transformationType: 'groupBy',
        transformer: (d) => {
          if (d.cum_vul < 21) {
            return '20%';
          } else if (d.cum_vul < 41) {
            return '40%';
          } else if (d.cum_vul < 61) {
            return '60%';
          } else {
            return '80%';
          }
        }
      },
      {
        type: 'lodash',
        transformationType: 'map',
        transformer: (elem, key, collection) => {
          return { [key]: _.maxBy(elem, 'cummulative_reduction') };
        }
      },
      {
        type: 'merge'
      }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'cyberRiskImprovementWidgettabular',
    route: '/riskImprovement/donut',
    sql: {
      default: function (condition, selector, date) {
        return `select rownum,cve,cyber_score,round( (rownum*100)/ (max(rownum) over ()) :: float) as cum_vul, round(sum (cyber_score*100/total_score :: float) over(order by rownum )) as cummulative_reduction from (select row_number() over () as rownum,cve,cyber_score,sum(cyber_score) over() as total_score from (select cve_id as cve, round(sum(score::float)) as cyber_score from ${where.cyber.view} as dr ${whereCondition(...conditionFilter(condition), where.cyber.createdAtRiskFilter, where.cyber.riskViewAssetIdInOrgChainFilter)} group by cve order by cyber_score desc ) as p ORDER BY cyber_score desc) t; `;
      },
      tabular: function (condition, selector, date) {
        return `select dr.id as asset_id,cve_id as cve, location as \"Location\", organization as \"Organization\",application_grp_name as \"Application\",application_name as \"Sub-Application\",dc.asset_name as \"Asset\", round(sum(score::float)) as \"Cyber Score\",impact_level, bai_value from ${where.cyber.viewTabular} dr ${whereCondition(...conditionFilter(condition), where.cyber.createdAtRiskFilter, where.cyber.riskViewAssetIdInOrgChainFilter)} group by dr.id,cve,location, organization,application_grp_name,application_name,dc.asset_name,impact_level, bai_value order by \"Cyber Score\" desc; `;
      }
    },
    postStages: [
      { type: 'setData', contextCheck: 'selector', contextCheckValue: 'tabular' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'Application' },
          { label: 'Sub-Application', path: 'Sub-Application' },
          { label: 'Asset', path: 'Asset' },
          { label: 'Location', path: 'Location' },
          { label: 'Organization', path: 'Organization' }
        ]
      }
    ],
    expected_params: ['orgId']
  },
  {
    name: 'cveIdLookupWidget',
    route: '/cveId/:cveId',
    whereTransform: {
      default: {
        apply: true,
        mapping: {
          asset_type: 'asset_type',
          type: 'asset_type',
        }
      },
      like: {
        apply: true,
        mapping: {
          asset_type: 'asset_type',
          type: 'asset_type',
        }
      }
    },
    sql: {
      default: function (condition, selector, date) {
        return `select dr.application_grp_name, dr.application_name, dr.asset_name, dr.asset_id, cve_set.*, cve_ref.source as cve_source, cve_ref.href as cve_href, cve_ref.value as cve_value, cve_ref.ref_type as cve_type from ${where.cyber.view} dr join common_vulnerabilities_exposures cve_set on cve_set.cve_id = dr.cve_id left join common_vulnerabilities_exposures_ref cve_ref on cve_ref.cve_id = dr.cve_id
 ${whereCondition(...conditionFilter(condition), 'dr.cve_id = :cveId')} `;
      },
      like: function (condition, selector, date) {
        return `select dr.application_grp_name, dr.application_name, dr.asset_name, dr.asset_id, cve_set.*, cve_ref.source as cve_source, cve_ref.href as cve_href, cve_ref.value as cve_value, cve_ref.ref_type as cve_type from ${where.cyber.view} dr join common_vulnerabilities_exposures cve_set on cve_set.cve_id = dr.cve_id join common_vulnerabilities_exposures_ref cve_ref on cve_ref.cve_id = dr.cve_id where dr.cve_id like  '%'||:cveId||'%' and ${
          where.cyber.createdAtRiskFilter
        } and ${where.common.orgChainFilter}`;
      }
    },
    expected_params: ['orgId', 'cveId'],
    postStages: [
      {
        type: 'lodash',
        transformationType: 'reduce',
        transformer:
          (result, v, index) => {
            const o = result[v.cve_id] || {};
            o.cve_id = v.cve_id;
            o.assessment_check_name = v.assessment_check_name;
            o.summary = v.summary;
            o.security_production = v.security_production;
            o.location = v.location;
            o.assessment_check_system = v.assessment_check_system;
            o.assessment_check_ref = v.assessment_check_ref;
            o.index = v.index;
            o.definition = v.definition;
            o.asset_name = o.asset_name || [];
            if (!o.asset_name.includes(v.asset_name)) o.asset_name.push(v.asset_name);
            o.asset_id = o.asset_id || [];
            if (!o.asset_id.includes(v.asset_id)) o.asset_id.push(v.asset_id);
            o.cve_ref = o.cve_ref || [];
            if (!o.cve_ref.find((cve_ref) => {
              return cve_ref.source === v.cve_source && cve_ref.href === v.cve_href && cve_ref.value === v.cve_value && cve_ref.type === v.cve_type;
            })) {
              o.cve_ref.push({ source: v.cve_source, href: v.cve_href, value: v.cve_value, type: v.cve_type });
            }
            o.applications = o.applications || [];
            if (!o.applications.find((a) => {
              return v.application_grp_name == a.application_grp_name && v.application_name == a.application_name && v.asset_name == a.asset_name && v.asset_id == a.asset_id;
            })) {
              o.applications.push({
                application_name: v.application_name,
                application_grp_name: v.application_grp_name,
                asset_name: v.asset_name,
                asset_id: v.asset_id
              });
            }
            result[v.cve_id] = o;
            if (index <= 1) return { [v.cve_id]: o };
            return result;
          }
      },
      {
        type: 'lodash',
        transformationType: 'values'
      }
    ]
  },
  {
    name: 'assetLookUpWidget',
    route: '/cyberReport',
    sql: {

      default: function (condition, selector, date) {

        return `select asset_id, ip, r1.source, vmid,score, location, result, application_grp_name, application_name, asset_name, asset_type, cve_ref.cve_id, r1.summary,
        cve_ref.source as cve_source, cve_ref.href as cve_href, cve_ref.value as cve_value, cve_ref.ref_type as cve_type, severity  from
(select distinct asset_id, ip, dr.source as source, vmid,score, location, result, application_grp_name, application_name, asset_name, asset_type,severity, cve_set.*
  from
(select distinct dr.id as asset_id,dr.asset_type, dr.network_ip as ip,dr.source,dr.vmid,dr.location,dr.result, dr.application_grp_name, dr.application_name, dr.asset_name,dr.score, dr.cve_id, p.name as severity
from ${where.cyber.view} dr join priorities p on dr.score::float <= p.max_value and dr.score::float >= p.min_value ${whereCondition(...conditionFilter(condition))} ) dr,
common_vulnerabilities_exposures cve_set
${whereCondition('dr.cve_id = cve_set.cve_id')}  ) r1 , common_vulnerabilities_exposures_ref cve_ref
where r1.cve_id = cve_ref.cve_id`;

      }
    },
    expected_params: ['orgId'],
    postStages: [
      {
        type: 'lodash',
        transformationType: 'reduce',
        transformer: (result, v, index) => {
          const o = result[v.asset_id] || {};
          o.cves = o.cves || {};
          const cve = o.cves[v.cve_id] || {};
          if (!cve.cve_id) cve.cve_id = v.cve_id;
          if (!cve.assessment_check_name) cve.assessment_check_name = v.assessment_check_name;
          if (!cve.summary) cve.summary = v.summary;
          if (!cve.security_production) cve.security_production = v.security_production;
          if (!cve.assessment_check_system) cve.assessment_check_system = v.assessment_check_system;
          if (!cve.assessment_check_ref) cve.assessment_check_ref = v.assessment_check_ref;
          cve.cve_ref = cve.cve_ref || [];
          if (!cve.cve_ref.find((cve_ref) => {
            return cve_ref.source === v.cve_source && cve_ref.href === v.cve_href && cve_ref.value === v.cve_value && cve_ref.type === v.cve_type;
          })) {
            cve.cve_ref.push({ source: v.cve_source, href: v.cve_href, value: v.cve_value, type: v.cve_type });
          }

          o.asset_name = v.asset_name;
          o.asset_id = v.asset_id;
          o.ip = v.ip;
          o.type = v.asset_type;
          o.vmid = v.vmid;
          o.source = v.source;
          o.realm = v.realm;
          o.managed = v.managed;
          o.cpu_count = v.cpu_count;
          o.operating_system = v.operating_system;
          o.locations = o.locations || [];
          if (!o.locations.includes(v.location)) o.locations.push(v.location);
          cve.index = v.index;
          cve.definition = v.definition;
          cve.score = v.score;
          cve.severity = v.severity;
          cve.cve_id = v.cve_id;
          o.applications = o.applications || [];
          if (!o.applications.find((a) => {
            return v.application_grp_name == a.application_grp_name && v.application_name == a.application_name;
          })) {
            o.applications.push({
              application_name: v.application_name,
              application_grp_name: v.application_grp_name,
              application_quarantine: v.application_grp_quarantine,
              sub_application_quarantine: v.application_quarantine
            });
          }
          o.cves[v.cve_id] = cve;
          result[v.asset_id] = o;

          return result;
        }

      },
      {
        type: 'custom',
        transformer: (context, data) => {

          for (const key in data) {
            data[key].cves = Object.values(data[key].cves);
          }
          return data;
        }
      },
      { type: 'lodash', transformationType: 'values' }
    ]
  },
  {
    name: 'assetLookUpWidget',
    route: '/assetLookup/:assetId',
    sql: {

      default: function (condition, selector, date) {
        return `select dr.network_ip as ip,dr.source,dr.vmid,dr.location,dr.result, dr.application_grp_name, dr.application_name, dr.asset_name,dr.score, cve_set.* from
         ${where.cyber.view} dr join common_vulnerabilities_exposures cve_set on cve_set.cve_id = dr.cve_id ${whereCondition(...conditionFilter(condition), 'dr.id = :assetId', where.cyber.createdAtRiskFilter)}`;
      }
    },
    expected_params: ['orgId', 'assetId'],
    postStages: [
      { type: '_removeUUID' },
      {
        type: 'lodash',
        transformationType: 'reduce',
        transformer: (result, v, index) => {
          result.cves = result.cves || {};
          const o = result.cves[v.cve_id] || {};
          o.cve_id = v.cve_id;
          o.assessment_check_name = v.assessment_check_name;
          o.summary = v.summary;
          o.security_production = v.security_production;
          o.assessment_check_system = v.assessment_check_system;
          o.assessment_check_ref = v.assessment_check_ref;
          result.ip = v.ip;
          result.vmid = v.vmid;
          result.source = v.source;
          result.realm = v.realm;
          result.managed = v.managed;
          result.cpu_count = v.cpu_count;
          result.operating_system = v.operating_system;
          result.locations = result.locations || [];
          if (!result.locations.includes(v.location)) result.locations.push(v.location);
          o.index = v.index;
          o.definition = v.definition;
          o.score = v.score;
          result.applications = result.applications || [];
          if (!result.applications.find((a) => {
            return v.application_grp_name == a.application_grp_name && v.application_name == a.application_name && v.asset_name == a.asset_name;
          })) {
            result.applications.push({
              application_name: v.application_name,
              application_grp_name: v.application_grp_name,
              asset_name: v.asset_name,
              application_quarantine: v.application_grp_quarantine,
              sub_application_quarantine: v.application_quarantine
            });
          }
          result.cves[v.cve_id] = o;
          if (index <= 1) return { cves: { [v.cve_id]: o } };
          return result;
        }

      }
    ]
  },
  {
    name: 'cyberScorer',
    route: '/scorer',
    sql: {
      default: function (condition, selector, date) {
        return cyberScore(selector, condition);
      },
      priority: function (condition, selector, date) {
        return `select * from priorities`;
      }
    },

  }

];
