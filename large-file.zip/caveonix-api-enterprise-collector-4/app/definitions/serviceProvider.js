const where = require('./common');
const whereCondition = require('../../utils/whereParser.js');
const conditionFilter = require('../../utils/conditionFilter');
const complianceScore = require('./scoringModules/complianceScore.view');
const cyberScore = require('./scoringModules/cyberScore.view');
const logger = require('./../../utils/logger').logger.child({

  sub_name: 'IdentityService-reference.service'
});
module.exports = [
  {
    name: 'locationViewWidget',
    route: '/:orgId/locationView',
    search_terms: [],
    sql: {
      instanceTypeCount: function (condition = []) {
        return 'select l.name as location, l.id as location_id ,art.name, count(are.id) from asset_repo_endpoints are join  asset_repo_types art on are.asset_repo_type_id = art.id join locations l on l.id = are.location_id group by art.name, l.name, l.id';
      },
      tenantCount: function (condition = []) {
        return 'select location, count(distinct case when o.type=\'Organization\' then organization_id end) as tenant_count, count(distinct ag.id) from application_group_asset_view ag join organizations o on ag.organization_id = o.id  group by location ';
      },
      assetCount: function (condition = []) {
        return `select location,location as loc, count(distinct(id)) as service_provider_asset_count from application_group_asset_view ${whereCondition(...conditionFilter(condition), where.common.orgChainFilter)} group by location`;
      },
      riskScore: function (condition) {
        return `select label as location, raw_weighted_risk as cve_risk_score from (${cyberScore('location', condition,true)}) x `;
      },
      complianceScore: function (condition = []) {
        return `select label as location, raw_weighted_risk as compliance_score from (${complianceScore('location', condition,true)}) x `;
        // return `select location, round(cast(compliance_score as numeric),1) as compliance_score from (select n.location, n.compliance_count, n.total_count,(n.compliance_count::float / n.total_count::float) as compliance_score from (select location, count (dc.id) as total_count,sum(case when lower(severity)='low' then 2 when lower(severity)='medium' then 5 when lower(severity)='high' then 8 when lower(severity)='critical' then 10 else 1 end) as compliance_count from ${where.compliance.viewWithNist} dc join xccdf_rules x on dc.rule_id = x.rule_id ${whereCondition(...conditionFilter(condition),where.compliance.resultFailFilter)} group by location) as n) as t`
      }
    },
    expected_params: ['orgId'],
    postStages: [{
      type: 'join',
      accessor: (obj) => {
        return obj.location;
      }
    }]
  },
  {
    name: 'totalAssetsWidget',
    route: '/:serviceProviderId/totalAssets',
    search_terms: [],
    sql: {
      default: function (condition = []) {
        // `join organizations o on o.id = a.organization_id  and (o.is_active='enabled' or o.is_active='true')`;
        // 'parent_org_id=:serviceProviderId';
        return `select count(distinct a.id) from assets a ${whereCondition(...conditionFilter(condition),
          `a.is_active!='false' and a.is_active!= 'disabled'`)} `;
      },
      percentChange: function () {
        return `select percent_change * 100 as percent_change from (select count/(sum(count) over () )::numeric as percent_change, rownum
from (select count(*), date , row_number() over () as rownum
from (select  ag.id, max(ag.created_at)::DATE as date from application_group_asset_view ag join organizations o on o.id = ag.organization_id   
where ag.parent_org_id = :serviceProviderId group by ag.id order by date desc) foo group by date order by date desc) bar) g where rownum = 1`;
      }
    },
    expected_params: ['serviceProviderId']
  },
  {
    name: 'getTenantCountWidget',
    route: '/:serviceProviderId/getTenantCount',
    search_terms: [],
    sql: {
      default: function (condition = []) {
        return 'select count(distinct agav.organization_id) from application_group_asset_view agav join organizations o on agav.organization_id=o.id where o.type = \'Organization\' and (o.is_active=\'enabled\' or o.is_active=\'true\')';
      },
      percentChange: function (condition = []) {
        return 'select 100*(total_count-prev_count)::numeric/coalesce(NULLIF(total_count,0),1) as percentage from (select count(id)::numeric AS total_count from organizations where type = \'Organization\' and (is_active=\'true\' or is_active=\'enabled\' or is_active=\'disabled\')) as t1,(select count(id) as prev_count from organizations where created_at >= now()- interval \'1 week\' and type = \'Organization\' and (is_active=\'true\' or is_active=\'enabled\' or is_active=\'disabled\')) as t2';
      }
    },
    expected_params: ['serviceProviderId']
  },
  {
    name: 'topAssetsByTenantWidget',
    route: '/:serviceProviderId/topAssetsByTenant',
    search_terms: [],
    sql: {
      default: function (condition = []) {
        return `select o.name,x.organization_id, sum(count) as count from (select  n.parent_organization_id as organization_id, count(distinct ag.id) from application_group_asset_view ag
         join ${where.common.orgChainParentSet} n on n.parent_organization_id = ag.organization_id ${whereCondition(
  'ag.' + where.commonSP.orgChainFilter,
  ...conditionFilter(condition),
  `(ag.is_active='enabled' or ag.is_active='true')`
)} group by n.parent_organization_id) x join organizations o on o.id = x.organization_id group by o.name, x.organization_id order by count desc limit 10`;
      },
      tabular: function (condition = []) {
        return `select ag.id as asset_id, location as "Location",o.name as "Organization", application_grp_name as "Application",application_name as "Sub-Application", asset_name as "Asset" ,o.type as "Type" from application_group_asset_view ag join organizations o on o.id = ag.organization_id ${whereCondition(
          where.commonSP.orgChainFilter,
          ...conditionFilter(condition)
        )} and (ag.is_active='enabled' or ag.is_active='true')`;
      }
    },
    postStages: [
      { type: 'index', index: '()=>{if(context.selector == \'tabular\')return \'organization_name\'}' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'Application' },
          { label: 'Sub-Application', path: 'Sub-Application' },
          { label: 'Asset', path: 'Asset' },
          { label: 'Location', path: 'Location' },
          { label: 'Organization', path: 'Organization' },
          { label: 'Type', path: 'Type' }
        ]
      }
    ],
    expected_params: ['serviceProviderId']
  },
  {
    name: 'complianceDistributionWidgetTotal',
    route: '/:orgId/getComplianceScore',
    search_terms: [],
    sql: {
      percentChange: function (condition = []) {
        // return `select 100*(-1+1/(coalesce(NULLIF(count(id), 0),1)::numeric/( select coalesce(NULLIF(count(id), 0),1) as compliance_count from ${where.common.viewWithNist} where result='fail' and created_at >= now() - interval '1 week' and id in (select id from assets where (is_active='enabled' or is_active='true' or is_active='disabled') and ${where.common.orgChainFilter}) ) )) as percent_change from ${where.common.viewWithNist} where result='fail' and id in (select id from assets where (is_active='enabled' or is_active='true' or is_active='disabled') and ${where.common.orgChainFilter})`;
        return `select 0`;
      },
      default: function (condition = []) {
        //condition.push({ '':`parent_org_id in (select distinct id from organizations where type = 'Provider')` });
        return `select raw_weighted_risk as compliance_score from (${complianceScore('parent_org_id')}) x `;

        // return `select round(cast(compliance_score as numeric),2) as compliance_score from (select n.compliance_count, n.total_count,(n.compliance_count::float / n.total_count::float) as compliance_score from (select count (dc.id) as total_count,sum(case when lower(severity)='low' then 2 when lower(severity)='medium' then 5 when lower(severity)='high' then 8 when lower(severity)='critical' then 10 else 1 end) as compliance_count from ${where.compliance.viewWithNist} dc join xccdf_rules x on dc.rule_id = x.rule_id ${whereCondition(...conditionFilter(condition), where.compliance.resultFailFilter)}) n ) x`;
      },
      tabular: function (condition = []) {
        return 'select * from application_tags at, sub_applications pg,  sub_application_members psm where at.id = psm.source_id and pg.id = psm.policy_group_id and organization_id  = :serviceProviderId';
      }
    },
    expected_params: ['orgId']
  },
  {
    name: 'riskScore',
    route: '/:serviceProviderId/getRiskScore',
    sql: {
      default: function (condition = []) {
        return 'select sum(cast (score as float))/count(cve_id) as CVE_risk_score, count(cve_id) as vulnerability_count from daily_risk_score_view where date_trunc(\'hour\',created_at) in (select max(date_trunc(\'hour\', created_at)) from daily_scan_results group by asset_id ) and id in (select id from assets where (is_active=\'enabled\' or is_active=\'true\' or is_active=\'disabled\') and organization_id in (WITH RECURSIVE org_cte(organization_id) AS (SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :serviceProviderId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :serviceProviderId as organization_id) ) order by CVE_risk_score desc';
      },
      count: function (condition = []) {
        return 'select count(cve_id) as avg_risk_score from daily_risk_score_view where  created_at::DATE in (select distinct max(created_at::DATE) from daily_scan_results where scan_type like \'%vul%\' group by asset_id ) and result=\'false\' and cve_id like \'CVE%\' and id in (select id from assets where organization_id =:serviceProviderId)';
      },
      total: function (condition = []) {
        return 'select sum(cast (score as float)) as total_risk_score from daily_risk_score_view where result=\'false\' and id in (select id from assets where organization_id =:serviceProviderId)';
      },
      average: function (condition = []) {
        return 'select coalesce(sum(cast (score as float))/count(cve_id),0) as avg_risk_score from daily_risk_score_view where result=\'false\' and id in (select id from assets where organization_id =:serviceProviderId )';
      },
      percentChange: function (condition = []) {
        return `select 100 * ( -1+1/(p_score::float/count)::numeric/((select p_score::float/count as score from (select sum(cast (score as float)) as p_score, count(dr.id) from daily_risk_score_view dr, organizations o, application_tags at where dr.created_at::DATE in (select max(created_at::DATE) -1 from daily_scan_results where scan_type like '%vul%' group by asset_id ) and dr.organization_id = o.id and dr.application_grp_id = at.id and dr.id in (select id from assets where (is_active='enabled' or is_active='true' or is_active='disabled') and organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :serviceProviderId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :serviceProviderId as organization_id) ) ) as y))) as percent_change from (select sum(cast (score as float)) as p_score, count(dr.id) from daily_risk_score_view dr, organizations o, application_tags at where date_trunc('hour', dr.created_at) in (select max(date_trunc('hour', created_at)) from daily_scan_results group by asset_id ) and dr.organization_id = o.id and dr.application_grp_id = at.id and dr.id in (select id from assets where (is_active='enabled' or is_active='true' or is_active='disabled') and organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :serviceProviderId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :serviceProviderId as organization_id) ) ) as t`;
      }
    },
    expected_params: ['serviceProviderId']
  },
  {
    name: 'tenantAssetTrendWidget',
    route: '/:serviceProviderId/tenantAssetTrend',
    search_terms: [],
    sql: {
      default: function (condition = []) {
        return 'select created_at, sum(sum_value) as count from (select dai.created_at,dai.organization_id, dai.organization_name, sum(dai.asset_count) as sum_value from daily_asset_summary dai where  dai.created_at between now()::DATE - interval \'30 day\' and now()::DATE and (is_active =\'true\' or is_active = \'enabled\') and dai.organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :serviceProviderId UNION ALL  SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :serviceProviderId as organiation_id)  group by  dai.created_at,dai.organization_id, dai.organization_name  order by dai.created_at) out group by created_at';
      },
      tabular: function (condition = []) {
        return `select a.id as asset_id,
         a.name as "Asset",
        pg.name as "Sub-Application",
        at.name as "Application",
         l.name as "Location",
        o.name as "Organization",
        o.type,
        a.vmid
        from assets a
        left join organizations o on a.organization_id = o.id
        left join sub_application_asset_members pgam on pgam.asset_id = a.id 
        left join sub_applications pg on pg.id = pgam.policy_group_id 
        left join sub_application_members psm on psm.policy_group_id = pg.id
        left join application_tags at on at.id = psm.source_id
        left join asset_details ad on ad.asset_id = a.id
        left join locations l on l.id = ad.location_id
        ${whereCondition(...conditionFilter(condition), `a.is_active!='false' and a.is_active!= 'disabled'`)}`;
        // return `select location as "Location",
        // asset_name as "Asset", vmid,
        //  organization_name as "Organization",
        //  application_grp_name as "Application",
        // application_name as "Sub-Application",type as "Type", dr.asset_id from (select location ,asset_name, vmid, organization_name ,
        //  application_grp_name ,
        // application_name ,
        // o.type as type, ag.id as asset_id
        // from application_group_asset_view ag join organizations o on o.id = ag.organization_id
        //   where organization_id in(select id from organizations where is_active='enabled' or is_active='true')
        //   group by location ,asset_name , vmid, organization_name , application_grp_name ,application_name ,o.type, asset_id ) dr
        //   left join (select network_ip,asset_id,created_at from asset_vm_network_details vm where isipaddresscheck(vm.network_ip) group by network_ip,asset_id,created_at order by created_at desc) asset_vm on dr.asset_id=asset_vm.asset_id`
      }
    },
    postStages: [
      { type: '_removeUUID' },
      { type: 'index', index: '()=>{if(context.selector == \'tabular\')return \'asset_name\'}' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'Application' },
          { label: 'Sub-Application', path: 'Sub-Application' },
          { label: 'Asset', path: 'Asset' },
          { label: 'Location', path: 'Location' },
          { label: 'Organization', path: 'Organization' },
          { label: 'Network IP', path: 'Network IP' },
          { label: 'Source', path: 'Source' }
        ]
      }
    ],
    expected_params: ['serviceProviderId']
  },
  {
    name: 'physicalHostCountWidget',
    route: '/:serviceProviderId/physicalHostCount',
    search_terms: [],
    sql: {
      default: function (condition = []) {
        return 'select count( distinct physical_host_name), CASE WHEN organization_id = :serviceProviderId THEN \'Management zone\' ELSE \'Customer zone\' END from application_group_asset_view GROUP BY CASE WHEN organization_id = :serviceProviderId THEN \'Management zone\' ELSE \'Customer zone\' END ';
      },
      tabular: function (condition = []) {
        return 'select  CASE WHEN organization_id =:serviceProviderId THEN \'Management zone\' ELSE \'Customer zone\' END  as "Zone", location as "Location", organization_name as "Organization",id as asset_id, asset_name as "Asset",application_grp_name as "Application", application_name as "Sub-Application", source as "Source",connection_name as "Connection Name",physical_host_name as "Host"  from application_group_asset_view group by organization_id,organization_name, id, asset_name,application_grp_name, application_name,source,connection_name,physical_host_name,location';
      }
    },
    postStages: [
      { type: 'index', index: '()=>{if(context.selector == \'tabular\')return \'case\'}' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'Application' },
          { label: 'Sub-Application', path: 'Sub-Application' },
          { label: 'Asset', path: 'Asset' },
          { label: 'Location', path: 'Location' },
          { label: 'Organization', path: 'Organization' },
          { label: 'Source', path: 'Source' },
          { label: 'Zone', path: 'Zone' },
          { label: 'Host', path: 'Host' },
          { label: 'Connection Name', path: 'Connection Name' }
        ]
      }
    ],
    expected_params: ['serviceProviderId']
  },
  {
    name: 'getTopologyInstanceTypesWidget',
    route: '/:serviceProviderId/getInstanceCount',
    sql: {
      default: function (condition = []) {
        return '(select repo_type, count(distinct connection_name) from application_group_asset_view group by repo_type) UNION ALL(select \'NSX\' as repo_type,count (distinct are.id) from application_group_asset_view agav,asset_repo_endpoints are ,asset_repo_endpoint_members arem where asset_manager_id=arem.asset_repo_enpoint_id_source_id and are.id=arem.asset_repo_enpoint_id_link_id and are.asset_repo_type_id in (select id from asset_repo_types where name=\'NSX-V\' or name=\'NSX-T\') and  (are.is_active=\'true\' or are.is_active=\'enabled\'))';
      },
      tabular: function (condition = []) {
        return `select agav.source as "Source",agav.location as "Location", agav.organization_name as "Organization",agav.id as asset_id, agav.asset_name as "Asset",agav.application_grp_name as "Application", agav.application_name as "Sub-Application",CASE WHEN agav.organization_id =0 THEN 'Management zone' ELSE 'Customer zone' END as "Zone",agav.connection_name as "Asset Repository",agav.repo_type as "Asset Repo Type",agav.physical_host_name as "Host" from application_group_asset_view agav`;
      }
    },
    postStages: [
      { type: '_removeUUID' },
      { type: 'index', index: '()=>{if(context.selector == \'tabular\')return \'source\'}' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'Application' },
          { label: 'Sub-Application', path: 'Sub-Application' },
          { label: 'Asset', path: 'Asset' },
          { label: 'Location', path: 'Location' },
          { label: 'Organization', path: 'Organization' },
          { label: 'Asset Repo Type', path: 'Asset Repo Type' },
          { label: 'Zone', path: 'Zone' },
          { label: 'Host', path: 'Host' },
          { label: 'Asset Repository', path: 'Asset Repository' },
          { label: 'NSX', path: 'NSX' }
        ]
      }
    ],
    expected_params: ['serviceProviderId']
  },
  {
    name: 'getTopologyInstanceTypesWidgetNSX',
    route: '/:serviceProviderId/getNSXInstance',
    sql: {
      default: function (condition = []) {
        return '(select repo_type, count(distinct repo_type) from application_group_asset_view group by repo_type) UNION ALL(select \'NSX\' as repo_type,count (distinct are.id) from application_group_asset_view agav,asset_repo_endpoints are ,asset_repo_endpoint_members arem where asset_manager_id=arem.asset_repo_enpoint_id_source_id and are.id=arem.asset_repo_enpoint_id_link_id and are.asset_repo_type_id in (select id from asset_repo_types where name=\'NSX\') and  (are.is_active=\'true\' or are.is_active=\'enabled\'))';
      },
      tabular: function (condition = []) {
        return 'select agav.source as "Source",agav.location as "Location", agav.organization_name as "Organization",agav.id as asset_id, agav.asset_name as "Asset",agav.application_grp_name as "Application", agav.application_name as "Sub-Application",CASE WHEN agav.organization_id =0 THEN \'Management zone\' ELSE \'Customer zone\' END as "Zone",agav.connection_name as "Asset Repository",agav.repo_type as "Asset Repo Type",are.id as "NXS Id",are.connection_name as "NSX",agav.physical_host_name as "Host" from application_group_asset_view agav,asset_repo_endpoints are ,asset_repo_endpoint_members arem where asset_manager_id=arem.asset_repo_enpoint_id_source_id and are.id=arem.asset_repo_enpoint_id_link_id and are.asset_repo_type_id in (select id from asset_repo_types where name=\'NSX-V\' or name=\'NSX-T\') and  (are.is_active=\'true\' or are.is_active=\'enabled\')';
      }
    },
    postStages: [
      { type: '_removeUUID' },
      { type: 'index', index: '()=>{if(context.selector == \'tabular\')return \'source\'}' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'Application' },
          { label: 'Sub-Application', path: 'Sub-Application' },
          { label: 'Asset', path: 'Asset' },
          { label: 'Location', path: 'Location' },
          { label: 'Organization', path: 'Organization' },
          { label: 'Asset Repo Type', path: 'Asset Repo Type' },
          { label: 'Zone', path: 'Zone' },
          { label: 'Host', path: 'Host' },
          { label: 'Asset Repository', path: 'Asset Repository' },
          { label: 'NSX', path: 'NSX' }
        ]
      }
    ],
    expected_params: ['serviceProviderId']
  },
  {
    name: 'getLocationCountWidget',
    route: '/:serviceProviderId/getLocationCount',
    sql: {
      default: function (condition = []) {
        return 'select count(distinct location) from application_group_asset_view';
      },
      tabular: function (condition = []) {
        return 'select location as "Location",organization_name as "Organization",ag.id as asset_id,asset_name as "Asset",application_grp_name as "Application",application_name as "Sub-Application",ag.source as "Source",CASE WHEN organization_id =:serviceProviderId THEN \'Management zone\' ELSE \'Customer zone\' END as "Zone",connection_name as "Connection Name",physical_host_name as "Host" , o.type as "Type" from application_group_asset_view ag join organizations o on o.id = ag.organization_id ';
      }
    },
    postStages: [
      { type: '_removeUUID' },
      { type: 'index', index: '()=>{if(context.selector == \'tabular\')return \'location\'}' },
      {
        type: 'uniqueList',
        dataPath: 'data',
        labels: [
          { label: 'Application', path: 'Application' },
          { label: 'Sub-Application', path: 'Sub-Application' },
          { label: 'Asset', path: 'Asset' },
          { label: 'Location', path: 'Location' },
          { label: 'Organization', path: 'Organization' },
          { label: 'Source', path: 'Source' },
          { label: 'Zone', path: 'Zone' },
          { label: 'Connection Name', path: 'Connection Name' }
        ]
      }
    ],
    expected_params: ['serviceProviderId']
  },
  {
    name: 'scoreTrend',
    route: '/:serviceProviderId/tenantBreakdown',
    sql: {
      assetCount: function (condition = []) {
        return `select o.name,x.organization_id, sum(count) as count from (select  n.parent_organization_id as organization_id, count(distinct ag.id) from application_group_asset_view ag
         join ${where.common.orgChainParentSet} n on n.parent_organization_id = ag.organization_id ${whereCondition(
  'ag.' + where.commonSP.orgChainFilter,
  ...conditionFilter(condition),
  `(ag.is_active='enabled' or ag.is_active='true')`
)} group by n.parent_organization_id) x join organizations o on o.id = x.organization_id WHERE o.type != 'Provider' group by o.name, x.organization_id order by count desc`;
      },
      cyber: function (condition = []) {
        return `select organization_id, r.created_at, cyber_score from (
  select created_at::DATE,
n.parent_organization_id as organization_id,
avg(score::float) as cyber_score,
  rank() over(partition by n.parent_organization_id order by created_at desc)  from
alert_results ar join ${where.common.orgChainParentSet} n on n.parent_organization_id = ar.organization_id or n.organization_id = ar.organization_id where alert_scheduler_id = 1
group by created_at, n.parent_organization_id order by n.parent_organization_id, created_at desc ) as r left join organizations o on o.id=r.organization_id
where r.rank <=30 and o.type != 'Provider' and (o.is_active='enabled' or o.is_active='true')`;
      },
      compliance: function (condition = []) {
        return `select organization_id, r.created_at, compliance_score from (
  select created_at::DATE,
n.parent_organization_id as organization_id,
avg(score::float) as compliance_score,
  rank() over(partition by n.parent_organization_id order by created_at desc)  from
alert_results ar join ${where.common.orgChainParentSet} n on n.parent_organization_id = ar.organization_id or n.organization_id = ar.organization_id where alert_scheduler_id = 4
group by created_at, n.parent_organization_id order by n.parent_organization_id, created_at desc ) as r left join organizations o on o.id=r.organization_id
where r.rank <=30 and o.type != 'Provider' and (o.is_active='enabled' or o.is_active='true')
`;
      },
      expected_params: ['orgId']
    },
    postStages: [
      {
        type: 'join',
        accessor: (obj) => {
          return (obj.organization_id, obj.created_at);
        }
      },
      {
        type: 'lodash',
        transformationType: 'reduce',
        transformer:
          (result, v, index) => {
            result[v.organization_id] = result[v.organization_id] || { complianceTrend: [], cyberTrend: [] };
            const orgObj = result[v.organization_id];
            orgObj.organization_id = orgObj.organization_id || v.organization_id;
            if (v.count) {
              orgObj.tenantAssetCount = v.count;
            }
            if (v.name) {
              orgObj.organizationName = v.name;
            }

            if (v.cyber_score) {
              orgObj.cyberTrend.push({ cyber_score: v.cyber_score, created_at: v.created_at });
            }
            if (v.compliance_score) {
              orgObj.complianceTrend.push({ compliance_score: v.compliance_score, created_at: v.created_at });
            }
            return result;
          }
      },
      {
        type: 'lodash',
        transformationType: 'values'
      },
      {
        type: 'lodash',
        transformationType: 'filter',
        transformer: (v) => {
          return v.organizationName;
        }
      }
    ],
    expected_params: ['serviceProviderId']
  }
];
