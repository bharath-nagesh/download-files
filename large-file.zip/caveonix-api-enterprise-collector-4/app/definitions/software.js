const where = require('./common');
const whereCondition = require('../../utils/whereParser.js');
const conditionFilter = require('../../utils/conditionFilter');

module.exports = [
  {
    name: 'softwareCountWidget',
    route: '/counts',
    sql: {
      new: function (condition, selector, date) {
        return `select count(distinct st.id) as new_count from software_tags st
        ${whereCondition(
    `st.created_at::DATE between (now()- interval '3 days')::date and now()::DATE`,
    ...conditionFilter(condition)
  )} `;
      },
      tabular: function (condition, selector, date) {
        return `select distinct st.id, st.part, st.vendor, st.name, st.description, st.version, st.update, st.edition, st.sw_edition, st.full_cpe, st.hash_cpe, st.created_at from software_tags st 
        ${whereCondition(
    `st.created_at::DATE between (now()- interval '3 days')::date and now()::DATE`,
    ...conditionFilter(condition)
  )} `;
      }
    },
    expected_params: ['orgId']
  }
];
