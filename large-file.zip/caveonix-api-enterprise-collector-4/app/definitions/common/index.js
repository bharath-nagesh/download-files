let path = require('path');
let fs = require('fs');
let basename = path.basename(module.filename);

let commons = {};

fs
  .readdirSync(__dirname)
  .filter(function(file) {
    return file.indexOf('.') !== 0 && file !== basename && file.slice(-3) === '.js';
  })
  .forEach(function(file) {
    let object = require('./' + file);

    let name = file.split('.')[0];
    commons[name] = object;

  });

module.exports = commons;
