const where = {
  createdAtComplianceFilter: '1=1',
  exemptionFilter: `(CASE WHEN (select type from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) and (entity_arn = asset_id::varchar or entity_arn is null) and control_id = scan.rule_id limit 1) is not null THEN
  (select type from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) and (entity_arn = asset_id::varchar or entity_arn is null) and control_id = scan.rule_id limit 1) ELSE scan_result END)`,
  exemptionServiceFilter: `(CASE WHEN (select type from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) and (entity_arn = infra.entity_arn or entity_arn is null) and control_id = cis.control_id limit 1) is not null THEN
  (select type from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) and (entity_arn = infra.entity_arn or entity_arn is null) and control_id = cis.control_id limit 1) ELSE infra.result END)`,
  // "date_trunc('hour', created_at) in (select max(scan.scan_epoch) from daily_scan_xccdf_results group by asset_id )",
  resultFailFilter: `result='FAIL'`,
  viewWithServices: `(select  ncm.nist_id, infra.id ,infra.entity_arn ,infra.organization_id ,infra.cis_control_id ,infra.asset_repo_id ,infra.region ,cis.title ,cis.description ,infra.result ,infra.remediation ,infra.product ,
  infra.cloud_type ,infra.source ,infra.organization_account_id ,infra.entity_name ,infra.batch_id, 
    ags.service_id, ags.asset_repo_endpoint_id, ags.tags_json, ags.account_arn, ags.application_name, ags.app_desc, ags.impact_level, ags.cia_value, ags.sub_app_name, ags.subapp_desc, ags.organization_name, ags.bai_value,ags.org_type,
    cis.severity
   from infrastructure_services_compliance infra, cis_webservices_controls cis,application_group_service_view ags, nist_cis_mappings ncm
    where ncm.mapping_id = cis.control_id and cis.control_id = infra.cis_control_id and infra.entity_arn = ags.entity_arn and ags.organization_id in (select org_chain_list(:orgId))
  and batch_id::text || '__' || infra.entity_arn  in (select max(batch_id) || '__' || entity_arn`+
   // and date_trunc('sec', infra.created_at) || '__' || infra.entity_arn  in (select max(date_trunc('sec', created_at)) || '__' || entity_arn
   ` from infrastructure_services_compliance where organization_id in (select org_chain_list(:orgId)) group by entity_arn))`,
  viewWithNist: ` (select bb.*, ag.*, ag.type as asset_type, cci.contributor
 ,cci.definition ,cci.type as cci_type ,cci.creator ,cci.status,cci.publish_date, cci.title ,cci.version
 ,cci.index ,cci.nist_index, cci.cci_id  from
     (select distinct asset_id,scan.rule_id,
   scan_result as result,scan_type,test_result as test_result,xr.rule_title,
   scan.reference from daily_scan_xccdf_results scan  INNER JOIN xccdf_rules xr ON scan.rule_id = xr.rule_id and scan.reference = xr.rule_identifiers
where organization_id in (select org_chain_list(:orgId)) and scan.id in (select id from daily_scan_xccdf_results scan where
date_trunc('hour', scan.created_at) || asset_id::text in (select
max(date_trunc('hour', created_at)) || asset_id::text from
daily_scan_xccdf_results where organization_id in (select org_chain_list(:orgId)) and asset_id in (select id from assets where
(is_active='enabled' or is_active='true' or is_active='disabled') and
organization_id in (select org_chain_list(:orgId)) ) group by
asset_id)) ) bb , control_correlation_identifier cci, application_group_asset_view ag
where cci.cci_id = reference and ag.id = asset_id )`,

  viewWithNistTabular: ` (select bb.*, ag.*, ag.type as asset_type, cci.contributor
  ,cci.definition ,cci.type as cci_type ,cci.creator ,cci.status,cci.publish_date, cci.title ,cci.version
  ,cci.index ,cci.nist_index, cci.cci_id  from
      (select distinct asset_id,scan.rule_id,
       (CASE WHEN (select type from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) and (entity_arn = asset_id::varchar or entity_arn is null) and control_id = scan.rule_id limit 1) is not null THEN
       (select type from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) and (entity_arn = asset_id::varchar or entity_arn is null) and control_id = scan.rule_id limit 1) ELSE scan_result END) as result,scan_type,test_result as test_result,xr.rule_title,
    scan.reference from daily_scan_xccdf_results scan  INNER JOIN xccdf_rules xr ON scan.rule_id = xr.rule_id
 where organization_id in (select org_chain_list(:orgId)) and scan.id in (select id from daily_scan_xccdf_results scan where
 date_trunc('hour', scan.created_at) || asset_id::text in (select
 max(date_trunc('hour', created_at)) || asset_id::text from
 daily_scan_xccdf_results where organization_id in (select org_chain_list(:orgId)) and asset_id in (select id from assets where
 (is_active='enabled' or is_active='true' or is_active='disabled') and
 organization_id in (select org_chain_list(:orgId)) ) group by
 asset_id)) ) bb , control_correlation_identifier cci, application_group_asset_view ag
 where cci.cci_id = reference and ag.id = asset_id)`,

  viewWithNistAndServices: ` (select nist_id,organization_id,cis_control_id::varchar,asset_repo_id,region::varchar,severity::varchar,title::varchar,description::varchar,result::varchar,remediation::varchar,created_at,cloud_type::varchar,
    organization_account_id::varchar,entity_name::varchar,batch_id::varchar,service_id::varchar,asset_repo_endpoint_id::varchar,entity_arn::varchar,product::varchar,tags_json::varchar,account_arn::varchar,region::varchar,application_name as application_grp_name,
    app_desc::varchar,impact_level::varchar,cia_value::varchar,sub_app_name as application_name,subapp_desc::varchar,organization_name::varchar,   org_type::varchar,
     null as asset_id,null as rule_id,null as scan_type,null as test_result,null as rule_title,
     null as scan_type,null as reference, organization_name as org_name, region as location, region as location_name, null as location_id, null as hosting_provider, null as
     hosting_provider_id, null as application_grp_org_id, null as application_grp_id, null as application_id, null as
    bai_value, null as network_ip, null as network, null as sequence_num, null as physical_host_name, null as repo_type, null as connection_name, null as
    name, null as vmid, null as macaddress, null as parent_org_id, null as type, null as managed, null as cpu_count, null as memory_size, null as ad_managed, null as realm, null as
    operating_system, null as vcenter_url, null as os_type, null as asset_tags, 'service' as asset_type, null as contributor, null as definition, null as cci_type, title, null as version, null as index, nist_id as nist_index, null as cci_id,'service' as entity_type
             from   (select  ncm.nist_id, infra.id ,infra.entity_arn ,infra.organization_id ,infra.cis_control_id ,infra.asset_repo_id ,infra.region ,cis.title ,cis.description ,infra.result ,infra.remediation ,infra.product ,
    infra.created_at ,infra.cloud_type ,infra.source ,infra.organization_account_id ,infra.entity_name ,infra.batch_id, 
    ags.service_id, ags.asset_repo_endpoint_id, ags.tags_json, ags.account_arn, ags.application_name, ags.app_desc, ags.impact_level, ags.cia_value, ags.sub_app_name, ags.subapp_desc, ags.organization_name,ags.bai_value,ags.organization_type as org_type,
    cis.severity
   from infrastructure_services_compliance infra, cis_webservices_controls cis,application_group_service_view ags, nist_cis_mappings ncm
    where ncm.mapping_id = cis.control_id and cis.control_id = infra.cis_control_id and infra.entity_arn = ags.entity_arn and ags.organization_id in (select org_chain_list(:orgId))
  and batch_id::text || '__' || infra.entity_arn  in (select max(batch_id) || '__' || entity_arn`+
  // and date_trunc('sec', infra.created_at) || '__' || infra.entity_arn  in (select max(date_trunc('sec', created_at)) || '__' || entity_arn
  ` from infrastructure_services_compliance where organization_id in (select org_chain_list(:orgId)) group by entity_arn)) ds
   -- above is services
    union all 
   -- below is workloads
   select nist_index,organization_id,null as cis_control_id,asset_manager_id,null,null,null,result::varchar,null,null,application_created_at,
   source::varchar,null,asset_name::varchar,null,null,asset_manager_id::varchar,null,null,null,null,null,application_grp_name::varchar,null,
   impact_level::varchar,null,application_name::varchar,null,  null,source::varchar,
   asset_id::text,dr.rule_id,scan_type,test_result::varchar,dr.rule_title::varchar,scan_type::varchar,reference,organization_name,location,location_name,location_id,hosting_provider,
   hosting_provider_id::varchar,application_grp_org_id::varchar,application_grp_id::varchar,application_id::varchar,
  bai_value::varchar,network_ip::varchar,network::varchar,sequence_num::varchar,physical_host_name::varchar,repo_type::varchar,connection_name::varchar,
  name::varchar,vmid::varchar,macaddress::varchar,parent_org_id::varchar,type::varchar,managed::varchar,cpu_count::varchar,memory_size::varchar,ad_managed,realm,
  operating_system::varchar,vcenter_url::varchar,os_type::varchar,asset_tags::varchar,asset_type::varchar,contributor::varchar,definition::varchar,cci_type,title,version,index,nist_index,cci_id,'workload' as entity_type
   from (select bb.*, ag.*, ag.type as asset_type, cci.contributor
 ,cci.definition ,cci.type as cci_type ,cci.creator ,cci.status,cci.publish_date, cci.title ,cci.version
 ,cci.index ,cci.nist_index, cci.cci_id  from
     (select distinct asset_id,scan.rule_id,
   scan_result as result,scan_type,test_result as test_result,xr.rule_title,
   scan.reference from daily_scan_xccdf_results scan  INNER JOIN xccdf_rules xr ON scan.rule_id = xr.rule_id and scan.reference = xr.rule_identifiers
where organization_id in (select org_chain_list(:orgId)) and scan.id in (select id from daily_scan_xccdf_results scan where
date_trunc('hour', scan.created_at) || asset_id::text in (select
max(date_trunc('hour', created_at)) || asset_id::text from
daily_scan_xccdf_results where organization_id in (select org_chain_list(:orgId)) and asset_id in (select id from assets where
(is_active='enabled' or is_active='true' or is_active='disabled') and
organization_id in (select org_chain_list(:orgId)) ) group by
asset_id)) ) bb , control_correlation_identifier cci, application_group_asset_view ag
where cci.cci_id = reference and ag.id = asset_id ) dr  join xccdf_rules x on dr.rule_id=x.rule_id)`,

  serviceProvider: {
    complianceViewAssetIdInOrgChainFilter:
      'dc.id in (select id from assets where (is_active=\'enabled\' or is_active=\'true\' or is_active=\'disabled\') and organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id =:serviceProviderId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :serviceProviderId as  organization_id) )',

    view: `(select asset_id,rule_id, scan_result as result,scan_type,ag.* from daily_scan_xccdf_results scan join application_group_asset_view ag on ag.id = asset_id where scan.scan_epoch < extract(epoch from :date::DATE) and scan.scan_epoch || asset_id::text in
(select max(scan.scan_epoch) || asset_id::text from daily_scan_xccdf_results  where asset_id in (select id from assets where (is_active='enabled' or is_active='true' or is_active='disabled') 
and organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :serviceProviderId UNION ALL 
SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :serviceProviderId as  organization_id) ) group by asset_id) )`,
    viewWithNist: `(select bb.*, ag.*, ag.type as asset_type, cci.contributor
 ,cci.definition ,cci.type as cci_type ,cci.creator ,cci.status,cci.publish_date, cci.title ,cci.version
 ,cci.index ,cci.nist_index, cci.cci_id  from
     (select distinct asset_id,scan.rule_id,
   scan_result as result,scan_type,test_result as test_result,xr.rule_title,
   scan.reference from daily_scan_xccdf_results scan  INNER JOIN xccdf_rules xr ON scan.rule_id = xr.rule_id and scan.reference = xr.rule_identifiers
where scan.id in (select id from daily_scan_xccdf_results scan where
date_trunc('hour', scan.created_at) || asset_id::text in (select
max(date_trunc('hour', created_at)) || asset_id::text from
daily_scan_xccdf_results where asset_id in (select id from assets where
(is_active='enabled' or is_active='true' or is_active='disabled') ) group by
asset_id)) ) bb , control_correlation_identifier cci, application_group_asset_view ag
where cci.cci_id = reference and ag.id = asset_id )`
  }
};

module.exports = where;
