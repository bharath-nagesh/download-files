module.exports = {
  orgChainFilter:
    'a.organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id)',
  assetIsActiveFilter: "(a.is_active='enabled' or a.is_active='true' or a.is_active='disabled')"
}
