module.exports = {
  createdAtRiskFilter: 'date_trunc(\'hour\', dr.created_at) in (select max(date_trunc(\'hour\', created_at)) from daily_scan_results group by asset_id )',
  saveMeCreatedAtRiskFilter: `scan_date < (:date::DATE) 
and scan_epoch||dr.id::TEXT in (select max(scan_epoch)||dr.id::TEXT from 
daily_scan_results  where asset_id in (select id from assets where
(is_active='enabled' or is_active='true' or is_active='disabled') and
organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT
tn.organization_id FROM org_chains AS tn join organizations as o on o.id
= tn.organization_id and organization_id = :orgId UNION ALL SELECT
c.organization_id FROM org_cte AS p, org_chains AS c join organizations
as o on o.id = c.organization_id WHERE c.parent_organization_id =
p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as 
organization_id) ) group by asset_id)`,
  riskViewAssetIdInOrgChainFilter:
    'dr.id in (select id from assets where (is_active=\'enabled\' or is_active=\'true\' or is_active=\'disabled\') and organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :orgId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as organization_id))',
  view: `(select (CASE WHEN scan.type = 'software' then 'Software' else 'Operating System' END) as vulnerability_type,scan.software,scan.version, cve.cve_id, cve.cwe_id, cve.score, cve.source as cve_source, cve.exploit_sub_score, asset_id,rule_id,(CASE WHEN (select type from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) and (entity_arn = asset_id::varchar or entity_arn is null) and control_id = scan.reference limit 1) is not null THEN
  (select type from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) and (entity_arn = asset_id::varchar or entity_arn is null) and control_id = scan.reference limit 1) ELSE scan_result END) as result,scan_type,scan.created_at,
 ag.application_grp_id,ag.application_grp_name,
ag.id,ag.organization_id, ag.organization_name, ag.application_id,ag.parent_org_id,
ag.operating_system,ag.source,ag.macaddress,ag.hosting_provider,
ag.application_name,ag.location,ag.impact_level,ag.bai_value,ag.
asset_name,ag.vmid,ag.realm,ag.network_ip, ag.type as asset_type,
 p.name as severity, p.id as priority_id, p.cap_count, p.max_value as priority_max_value, p.risk_weight as priority_risk_weight from
daily_scan_results scan join application_group_asset_view ag on
ag.id = asset_id join common_vulnerabilities_exposures_base cve on cve.cve_id =
btrim(scan.reference) join priorities p 
on cve.score::numeric <= p.max_value and cve.score::numeric >= p.min_value where scan_date <= (:date::DATE) 
and scan_epoch||asset_id::TEXT in (select max(scan_epoch)||asset_id::TEXT from 
daily_scan_results  where asset_id in (select id from assets where
(is_active='enabled' or is_active='true' or is_active='disabled') and
organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT
tn.organization_id FROM org_chains AS tn join organizations as o on o.id
= tn.organization_id and organization_id = :orgId UNION ALL SELECT
c.organization_id FROM org_cte AS p, org_chains AS c join organizations
as o on o.id = c.organization_id WHERE c.parent_organization_id =
p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :orgId as 
organization_id) ) group by asset_id)  and (asset_id::varchar, cve.cve_id) NOT IN (select entity_arn,control_id from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) ))`,
  viewTabular: `(select (CASE WHEN scan.type = 'software' then 'Software' else 'Operating System' END) as vulnerability_type,scan.software,scan.version, cve.cve_id, cve.cwe_id, cve.score, cve.source as cve_source, cve.exploit_sub_score, asset_id,rule_id,(CASE WHEN (select type from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) and (entity_arn = asset_id::varchar or entity_arn is null) and control_id = scan.reference limit 1) is not null THEN
(select type from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) and (entity_arn = asset_id::varchar or entity_arn is null) and control_id = scan.reference limit 1) ELSE scan_result END) as result,scan_type,scan.created_at,
ag.application_grp_id,ag.application_grp_name,
ag.id,ag.organization_id, ag.organization_name, ag.application_id,ag.parent_org_id,
ag.operating_system,ag.source,ag.macaddress,ag.hosting_provider,
ag.application_name,ag.location,ag.impact_level,ag.bai_value,ag.
asset_name,ag.vmid,ag.realm,ag.network_ip, ag.type as asset_type,
p.name as severity, p.id as priority_id, p.cap_count, p.max_value as priority_max_value, p.risk_weight as priority_risk_weight from
daily_scan_results scan join application_group_asset_view ag on
ag.id = asset_id join common_vulnerabilities_exposures_base cve on cve.cve_id =
btrim(scan.reference) join priorities p 
on cve.score::numeric <= p.max_value and cve.score::numeric >= p.min_value where scan_date <= (:date::DATE) 
and (batch_id, asset_id) in (select max(batch_id),asset_id from 
daily_scan_results  where asset_id in (select id from assets where
(is_active='enabled' or is_active='true' or is_active='disabled') and
organization_id in (select org_chain_list(:orgId))) group by asset_id))`,
  serviceProvider: {
    riskViewAssetIdInOrgChainFilter:
      'dr.id in (select id from assets where (is_active=\'enabled\' or is_active=\'true\' or is_active=\'disabled\') and organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :serviceProviderId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :serviceProviderId as organization_id))',
    view: `(select (CASE WHEN scan.type = 'software' then 'Software' else 'Operating System' END) as vulnerability_type,scan.software,scan.version, cve.cve_id, cve.cwe_id, cve.score, cve.source as cve_source, cve.exploit_sub_score, asset_id,rule_id, scan_result as result,scan_type,scan.created_at,
 ag.application_grp_id,ag.application_grp_name,
ag.id,ag.organization_id, ag.organization_name, ag.application_id,ag.parent_org_id,
ag.operating_system,ag.source,ag.macaddress,ag.hosting_provider,
ag.application_name,ag.location,ag.impact_level,ag.bai_value,ag.
asset_name,ag.vmid,ag.realm,ag.network_ip, ag.type as asset_type,
 p.name as severity, p.id as priority_id, p.cap_count, p.max_value as priority_max_value, p.risk_weight as priority_risk_weight from
daily_scan_results scan join application_group_asset_view ag on
ag.id = asset_id join common_vulnerabilities_exposures_base cve on cve.cve_id =
btrim(scan.reference) join priorities p 
on cve.score::numeric <= p.max_value and cve.score::numeric >= p.min_value where scan_date <= (:date::DATE) 
and scan_epoch||asset_id::TEXT in (select max(scan_epoch)||asset_id::TEXT from 
daily_scan_results  where asset_id in (select id from assets where
(is_active='enabled' or is_active='true' or is_active='disabled') ) group by asset_id))`
  }
};
