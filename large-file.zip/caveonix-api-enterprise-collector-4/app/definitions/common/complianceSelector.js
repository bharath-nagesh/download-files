const _ = require('lodash');
const STANDARD_RETURN = `bb.*, ag.*, ag.type as asset_type, cci.contributor
 ,cci.definition ,cci.type as cci_type ,cci.creator ,cci.status,cci.publish_date, cci.title ,cci.version
 ,cci.index ,cci.nist_index, cci.cci_id`;

module.exports = function (selectedColumns) {
  const selected = selectedColumns ? _.map(selectedColumns, mapToPrefix).join(', ') : STANDARD_RETURN;
  return `(select ${selected} from
     (select distinct asset_id,scan.rule_id,
   scan_result as result,scan_type,test_result as test_result,xr.rule_title,
   scan.reference from daily_scan_xccdf_results scan  INNER JOIN xccdf_rules xr ON scan.rule_id = xr.rule_id and scan.reference = xr.rule_identifiers
where organization_id in (select org_chain_list(:orgId)) and scan.id in (select id from daily_scan_xccdf_results scan where
date_trunc('hour', scan.created_at) || asset_id::text in (select
max(date_trunc('hour', created_at)) || asset_id::text from
daily_scan_xccdf_results where organization_id in (select org_chain_list(:orgId)) and asset_id in (select id from assets where
(is_active='enabled' or is_active='true' or is_active='disabled') and
organization_id in (select org_chain_list(:orgId)) ) group by
asset_id)) ) bb , control_correlation_identifier cci, application_group_asset_view ag
where cci.cci_id = bb.reference and ag.id = asset_id )`;
};

function mapToPrefix(column) {
  const entry = Object.entries(mapper).find(([prefix, values]) => values.includes(column));

  const prefix = entry ? entry[0] : 'ag';
  const asMap = asMapper[column] ? `${asMapper[column]} as ` : '';
  return `${prefix}.${asMap}${column}`;
}

const mapper = {
  bb: ['rule_id', 'result', 'scan_type', 'reference', 'rule_title'],
  cci: ['cci_type', 'title', 'version', 'nist_index', 'index', 'definition', 'status', 'publish_date', 'creator','cci_id']

};
const asMapper = {
  asset_type: 'type',
  asset_id: 'id'
};
