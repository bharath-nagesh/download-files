module.exports = {
  orgChainFilter:
    "organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and (is_active='enabled' or is_active='true' or is_active='disabled') and organization_id in (select id from organizations where type = 'Organization') UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id and (is_active='enabled' or is_active='true' or is_active='disabled') WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n )"
}
