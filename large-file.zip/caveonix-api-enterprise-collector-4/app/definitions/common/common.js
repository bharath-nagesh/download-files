module.exports = {
  exemptionFilter:`(entity_arn, cis_control_id) not in (select entity_arn,control_id from exemptions where is_active != 'false' and (exemption_valid_till >= NOW() or exemption_valid_till is null) and organization_id in (select org_chain_list(:orgId)) )`,
  orgChainFilter:
    'organization_id in (select org_chain_list(:orgId))',
  SPOrgChainFilter:
    'organization_id in (WITH RECURSIVE org_cte(organization_id) AS ( SELECT tn.organization_id FROM org_chains AS tn join organizations as o on o.id = tn.organization_id and organization_id = :serviceProviderId UNION ALL SELECT c.organization_id FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id WHERE c.parent_organization_id = p.organization_id ) SELECT * FROM org_cte AS n UNION ALL SELECT :serviceProviderId as organization_id)',
  topLevelOrgFilter: `(select organization_id from (WITH RECURSIVE org_cte(organization_id, name, type, parent_organization_id, depth, path) AS ( SELECT tn.organization_id, o.name,o.type, tn.parent_organization_id, 1::INT AS depth, o.name::TEXT AS path FROM org_chains AS tn join organizations as o on o.id = tn.organization_id WHERE  o.is_active!='false' and tn.organization_id = :orgId UNION ALL SELECT c.organization_id, o.name, o.type,c.parent_organization_id,  p.depth + 1 AS depth, (p.path || '->' || o.name::TEXT) FROM org_cte AS p, org_chains AS c join organizations as o on o.id = c.organization_id  WHERE c.organization_id = p.parent_organization_id and o.is_active!='false') SELECT * FROM org_cte AS n UNION ALL (SELECT  id as organization_id,name,type, null as parent_organization_id, 0 as depth, name::TEXT as path from organizations where id = :orgId) order by depth desc  limit 1 ) a)`,
  orgChainParentSet: `(WITH RECURSIVE org_cte(organization_id,parent_organization_id)
AS ( SELECT tn.organization_id,
  case when tn.parent_organization_id = -1 then tn.organization_id else tn.parent_organization_id end as parent_organization_id FROM
org_chains AS tn join organizations as o on o.id = tn.organization_id where type = 'Organization'
UNION 
select oc.organization_id, org_cte.parent_organization_id from org_chains oc,org_cte 
where org_cte.organization_id = oc.parent_organization_id   )
 select * from org_cte)`
};
