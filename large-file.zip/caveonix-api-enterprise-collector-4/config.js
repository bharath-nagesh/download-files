
var program = require('commander');
let { version }= require('./package.json');
program
  .version(version)
  .option('-c, --config <path>', 'json config file')
  .parse(process.argv);

let configFilePath = program.config || './config.json';
if (!configFilePath) {
  console.log('ERROR: no config file path');
}
let cFile;
if (configFilePath[0] == '/') {
  cFile = configFilePath;
} else {
  cFile = process.cwd() + '/' + configFilePath;
}
console.log(cFile);
let config = require(cFile);
if (!config) {
  console.log('ERROR: no config file found');
}
console.log(config);
config.version = version;
module.exports = config;
