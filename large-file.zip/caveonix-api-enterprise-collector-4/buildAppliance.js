const { exec } = require('pkg');
const fs = require('fs');
const isAppliance = 'module.exports = () => true;';
fs.writeFileSync('./utils/isAppliance.js', isAppliance);
exec(['.', '--target', 'macos,linux', '--output', 'appliance']);
