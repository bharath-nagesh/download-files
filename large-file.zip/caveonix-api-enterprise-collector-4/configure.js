let config = require('./config');

const get = () => {
  return config;
};
const set = configObj => {
  if (!config) config = configObj;
};
module.exports = {
  get: get,
  set: set
};
