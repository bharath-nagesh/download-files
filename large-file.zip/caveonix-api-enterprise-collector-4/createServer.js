const https = require('https');
const http = require('http');
const fs = require('fs');
let config = require('./configure').get();
module.exports = app => {
  if (config.https) {
    const options = {
      key: fs.readFileSync(config.keyFile),
      cert: fs.readFileSync(config.certFile)
    };

    return https.createServer(options, app);
  }
  return http.createServer(app);
};
