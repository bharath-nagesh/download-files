module.exports = {
  "alerts": [
    {
      "date": "2019-07-31 15:39:48 UTC",
      "message": "Encrypt operation failed for centos-swap on centos-4-121 (Cloud VM Set:\nvcenter-4.13), TaskId: 368931ae-b3a8-11e9-b5d6-000c295f923a, err: encrypt task\nvalidation failed, device: centos-swap is not available for encryption",
      "id": "6dff6394-b3a9-11e9-a13d-000c295f923a",
      "uri": "https://10.11.4.25/v5/alerts/6dff6394-b3a9-11e9-a13d-000c295f923a/"
    },
    {
      "date": "2019-07-31 15:24:48 UTC",
      "message": "Virtual Machine centos-4-121 (Cloud VM Set: vcenter-4.13) re-connected,\nauthentication pending",
      "id": "5554145e-b3a7-11e9-82d6-000c295f923a",
      "uri": "https://10.11.4.25/v5/alerts/5554145e-b3a7-11e9-82d6-000c295f923a/"
    },
    {
      "date": "2019-07-31 15:22:49 UTC",
      "message": "Heartbeat failed for Virtual Machine centos-4-121 (Cloud VM Set: vcenter-4.13).\nGrace period expired, reauthentication required.",
      "id": "0e8eb01c-b3a7-11e9-90d7-000c295f923a",
      "uri": "https://10.11.4.25/v5/alerts/0e8eb01c-b3a7-11e9-90d7-000c295f923a/"
    },
    {
      "date": "2019-07-31 13:21:20 UTC",
      "message": "Virtual Machine centos4-122 (Cloud VM Set: vcenter-4.13) HTcrypt driver update\n-- linux kernel version changed from '3.10.0-957.el7.x86_64' to\n'3.10.0-957.21.3.el7.x86_64'",
      "id": "159d2bc2-b396-11e9-bf6a-000c295f923a",
      "uri": "https://10.11.4.25/v5/alerts/159d2bc2-b396-11e9-bf6a-000c295f923a/"
    },
    {
      "date": "2019-07-31 12:45:10 UTC",
      "message": "Virtual Machine centos-4-121 (Cloud VM Set: vcenter-4.13) HTcrypt driver update\n-- linux kernel version changed from '3.10.0-862.14.4.el7.x86_64' to\n'3.10.0-957.21.3.el7.x86_64'",
      "id": "0878f142-b391-11e9-b6e7-000c295f923a",
      "uri": "https://10.11.4.25/v5/alerts/0878f142-b391-11e9-b6e7-000c295f923a/"
    },
    {
      "date": "2019-07-31 12:38:16 UTC",
      "message": "Virtual Machine centos-4-121 (Cloud VM Set: vcenter-4.13) rebooted,\nreauthentication required",
      "id": "11690ed4-b390-11e9-8b16-000c295f923a",
      "uri": "https://10.11.4.25/v5/alerts/11690ed4-b390-11e9-8b16-000c295f923a/"
    },
    {
      "date": "2019-07-31 12:36:06 UTC",
      "message": "Virtual Machine centos-4-121 (Cloud VM Set: vcenter-4.13) rebooted,\nreauthentication required",
      "id": "c41ae682-b38f-11e9-a14d-000c295f923a",
      "uri": "https://10.11.4.25/v5/alerts/c41ae682-b38f-11e9-a14d-000c295f923a/"
    },
    {
      "date": "2019-07-31 10:27:32 UTC",
      "message": "Regenerated Admin Key. Reason: Added user - hytrust with SEC_ADMIN privilege",
      "id": "ce956a19-b37d-11e9-a45c-000c295f923a",
      "uri": "https://10.11.4.25/v5/alerts/ce956a19-b37d-11e9-a45c-000c295f923a/"
    },
    {
      "date": "2019-07-31 10:25:54 UTC",
      "message": "Regenerated Admin Key. Reason: Added user - Caveo1 with SEC_ADMIN privilege",
      "id": "93ed4782-b37d-11e9-9070-000c295f923a",
      "uri": "https://10.11.4.25/v5/alerts/93ed4782-b37d-11e9-9070-000c295f923a/"
    },
    {
      "date": "2019-07-31 09:20:22 UTC",
      "message": "KMIP Server start: 10.11.4.25 SUCCESS",
      "id": "6c38def0-b374-11e9-92ed-000c295f923a",
      "uri": "https://10.11.4.25/v5/alerts/6c38def0-b374-11e9-92ed-000c295f923a/"
    },
    {
      "date": "2019-07-29 15:34:13 UTC",
      "message": "Added Virtual Machine centos4-122 (Cloud VM Set: vcenter-4.13), authentication\npending",
      "id": "51245c82-b216-11e9-808a-000c295f923a",
      "uri": "https://10.11.4.25/v5/alerts/51245c82-b216-11e9-808a-000c295f923a/"
    },
    {
      "date": "2019-07-29 14:27:53 UTC",
      "message": "Mapping operation failed for Caveo-Mapping on centos-4-121 (Cloud VM Set:\nvcenter-4.13), TaskId: c750af28-b20c-11e9-9dc1-000c295f923a, err: Getting\nKeyControl Mapping information by guid  KeyControl Mapping: Caveo-Mapping server\ndescription Caveo_Control_Mapping, ip 10.11.4.121, port 443",
      "id": "0d19cde8-b20d-11e9-bdcc-000c295f923a",
      "uri": "https://10.11.4.25/v5/alerts/0d19cde8-b20d-11e9-bdcc-000c295f923a/"
    },
    {
      "date": "2019-07-29 12:57:05 UTC",
      "message": "Added Virtual Machine centos-4-121 (Cloud VM Set: vcenter-4.13), authentication\npending",
      "id": "5df636c0-b200-11e9-8489-000c295f923a",
      "uri": "https://10.11.4.25/v5/alerts/5df636c0-b200-11e9-8489-000c295f923a/"
    },
    {
      "date": "2019-07-29 12:03:17 UTC",
      "message": "KMIP Server: Client certificate caveoclient created",
      "id": "d9b42ca8-b1f8-11e9-9b45-000c295f923a",
      "uri": "https://10.11.4.25/v5/alerts/d9b42ca8-b1f8-11e9-9b45-000c295f923a/"
    },
    {
      "date": "2019-07-29 09:33:21 UTC",
      "message": "KMIP Server: Client certificate caveokmipcertificate created",
      "id": "e7e0c707-b1e3-11e9-993e-000c295f923a",
      "uri": "https://10.11.4.25/v5/alerts/e7e0c707-b1e3-11e9-993e-000c295f923a/"
    },
    {
      "date": "2019-07-29 08:20:36 UTC",
      "message": "KMIP Server start: 10.11.4.25 SUCCESS",
      "id": "bde4db73-b1d9-11e9-97d6-000c295f923a",
      "uri": "https://10.11.4.25/v5/alerts/bde4db73-b1d9-11e9-97d6-000c295f923a/"
    },
    {
      "date": "2019-07-26 06:33:04 UTC",
      "message": "Created Cloud VM Set vcenter-4.13",
      "id": "38ddf987-af6f-11e9-a5d0-000c295f923a",
      "uri": "https://10.11.4.25/v5/alerts/38ddf987-af6f-11e9-a5d0-000c295f923a/"
    },
    {
      "date": "2019-07-21 19:13:27 UTC",
      "message": "Regenerated Admin Key. Reason: Generated by secroot",
      "id": "9e6c424f-abeb-11e9-b58a-000c295f923a",
      "uri": "https://10.11.4.25/v5/alerts/9e6c424f-abeb-11e9-b58a-000c295f923a/"
    }
  ],
  "result": "success"
}
